package org.eclipse.jdt.core.dom;

public abstract class Node {

}

