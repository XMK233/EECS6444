/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;

/**
* record initialization status during definite assignment analysis
*
* no caching of pre-allocated instances.
*/
public class unconditionalflowinfo extends flowinfo {
// coverage tests
/**
* exception raised when unexpected behavior is detected during coverage
* tests.
*/
public static class assertionfailedexception extends runtimeexception {
private static final long serialversionuid = 1827352841030089703l;

public assertionfailedexception(string message) {
super(message);
}
}

// coverage tests need that the code be instrumented. the following flag
// controls whether the instrumented code is compiled in or not, and whether
// the coverage tests methods run or not.
public final static boolean coverage_test_flag = false;
// never release with the coveragetestflag set to true
public static int coveragetestid;

// assignment bits - first segment
public long definiteinits;
public long potentialinits;

// null bits - first segment
public long
nullbit1,
nullbit2,
nullbit3,
nullbit4;
/*
nullbit1
nullbit2...
0000	start
0001	pot. unknown
0010	pot. non null
0011	pot. nn & pot. un
0100	pot. null
0101	pot. n & pot. un
0110	pot. n & pot. nn
1001	def. unknown
1010	def. non null
1011	pot. nn & prot. nn
1100	def. null
1101	pot. n & prot. n
1110	prot. null
1111	prot. non null
*/

// extra segments
public static final int extralength = 6;
public long extra[][];
// extra bit fields for larger numbers of fields/variables
// extra[0] holds definiteinits values, extra[1] potentialinits, etc.
// lifecycle is extra == null or else all extra[]'s are allocated
// arrays which have the same size

public int maxfieldcount; // limit between fields and locals

// constants
public static final int bitcachesize = 64; // 64 bits in a long.
public int[] nullstatuschangedinassert; // https://bugs.eclipse.org/bugs/show_bug.cgi?id=303448

public flowinfo addinitializationsfrom(flowinfo inits) {
if (this == dead_end)
return this;
if (inits == dead_end)
return this;
unconditionalflowinfo otherinits = inits.unconditionalinits();

// union of definitely assigned variables,
this.definiteinits |= otherinits.definiteinits;
// union of potentially set ones
this.potentialinits |= otherinits.potentialinits;
// combine null information
boolean thishadnulls = (this.tagbits & null_flag_mask) != 0,
otherhasnulls = (otherinits.tagbits & null_flag_mask) != 0;
long
a1, a2, a3, a4,
na1, na2, na3, na4,
b1, b2, b3, b4,
nb1, nb2, nb3, nb4;
if (otherhasnulls) {
if (!thishadnulls) {
this.nullbit1 = otherinits.nullbit1;
this.nullbit2 = otherinits.nullbit2;
this.nullbit3 = otherinits.nullbit3;
this.nullbit4 = otherinits.nullbit4;
if (coverage_test_flag) {
if (coveragetestid == 1) {
this.nullbit4 = ~0;
}
}
}
else {
this.nullbit1 = (b1 = otherinits.nullbit1)
| (a1 = this.nullbit1) & ((a3 = this.nullbit3)
& (a4 = this.nullbit4) & (nb2 = ~(b2 = otherinits.nullbit2))
& (nb4 = ~(b4 = otherinits.nullbit4))
| ((na4 = ~a4) | (na3 = ~a3))
& ((na2 = ~(a2 = this.nullbit2)) & nb2
| a2 & (nb3 = ~(b3 = otherinits.nullbit3)) & nb4));
this.nullbit2  = b2 & (nb4 | nb3)
| na3 & na4 & b2
| a2 & (nb3 & nb4
| (nb1 = ~b1) & (na3 | (na1 = ~a1))
| a1 & b2);
this.nullbit3 = b3 & (nb1 & (b2 | a2 | na1)
| b1 & (b4 | nb2 | a1 & a3)
| na1 & na2 & na4)
| a3 & nb2 & nb4
| nb1 & ((na2 & a4 | na1) & a3
| a1 & na2 & na4 & b2);
this.nullbit4 = nb1 & (a4 & (na3 & nb3	| (a3 | na2) & nb2)
| a1 & (a3 & nb2 & b4
| a2 & b2 & (b4	| a3 & na4 & nb3)))
| b1 & (a3 & a4 & b4
| na2 & na4 & nb3 & b4
| a2 & ((b3 | a4) & b4
| na3 & a4 & b2 & b3)
| na1 & (b4	| (a4 | a2) & b2 & b3))
| (na1 & (na3 & nb3 | na2 & nb2)
| a1 & (nb2 & nb3 | a2 & a3)) & b4;
if (coverage_test_flag) {
if (coveragetestid == 2) {
this.nullbit4 = ~0;
}
}
}
this.tagbits |= null_flag_mask; // in all cases - avoid forgetting extras
}
// treating extra storage
if (this.extra != null || otherinits.extra != null) {
int mergelimit = 0, copylimit = 0;
if (this.extra != null) {
if (otherinits.extra != null) {
// both sides have extra storage
int length, otherlength;
if ((length = this.extra[0].length) <
(otherlength = otherinits.extra[0].length)) {
// current storage is shorter -> grow current
for (int j = 0; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
(this.extra[j] = new long[otherlength]), 0, length);
}
mergelimit = length;
copylimit = otherlength;
if (coverage_test_flag) {
if (coveragetestid == 3) {
throw new assertionfailedexception("coverage 3"); //$non-nls-1$
}
}
} else {
// current storage is longer
mergelimit = otherlength;
if (coverage_test_flag) {
if (coveragetestid == 4) {
throw new assertionfailedexception("coverage 4"); //$non-nls-1$
}
}
}
}
} else if (otherinits.extra != null) {
// no storage here, but other has extra storage.
// shortcut regular copy because array copy is better
int otherlength;
this.extra = new long[extralength][];
system.arraycopy(otherinits.extra[0], 0,
(this.extra[0] = new long[otherlength =
otherinits.extra[0].length]), 0, otherlength);
system.arraycopy(otherinits.extra[1], 0,
(this.extra[1] = new long[otherlength]), 0, otherlength);
if (otherhasnulls) {
for (int j = 2; j < extralength; j++) {
system.arraycopy(otherinits.extra[j], 0,
(this.extra[j] = new long[otherlength]), 0, otherlength);
}
if (coverage_test_flag) {
if (coveragetestid == 5) {
this.extra[5][otherlength - 1] = ~0;
}
}
}
else {
for (int j = 2; j < extralength; j++) {
this.extra[j] = new long[otherlength];
}
if (coverage_test_flag) {
if (coveragetestid == 6) {
throw new assertionfailedexception("coverage 6"); //$non-nls-1$
}
}
}
}
int i;
// manage definite assignment info
for (i = 0; i < mergelimit; i++) {
this.extra[0][i] |= otherinits.extra[0][i];
this.extra[1][i] |= otherinits.extra[1][i];
}
for (; i < copylimit; i++) {
this.extra[0][i] = otherinits.extra[0][i];
this.extra[1][i] = otherinits.extra[1][i];
}
// tweak limits for nulls
if (!thishadnulls) {
if (copylimit < mergelimit) {
copylimit = mergelimit;
}
mergelimit = 0;
}
if (!otherhasnulls) {
copylimit = 0;
mergelimit = 0;
}
for (i = 0; i < mergelimit; i++) {
this.extra[1 + 1][i] = (b1 = otherinits.extra[1 + 1][i])
| (a1 = this.extra[1 + 1][i]) & ((a3 = this.extra[3 + 1][i])
& (a4 = this.extra[4 + 1][i]) & (nb2 = ~(b2 = otherinits.extra[2 + 1][i]))
& (nb4 = ~(b4 = otherinits.extra[4 + 1][i]))
| ((na4 = ~a4) | (na3 = ~a3))
& ((na2 = ~(a2 = this.extra[2 + 1][i])) & nb2
| a2 & (nb3 = ~(b3 = otherinits.extra[3 + 1][i])) & nb4));
this.extra[2 + 1][i]  = b2 & (nb4 | nb3)
| na3 & na4 & b2
| a2 & (nb3 & nb4
| (nb1 = ~b1) & (na3 | (na1 = ~a1))
| a1 & b2);
this.extra[3 + 1][i] = b3 & (nb1 & (b2 | a2 | na1)
| b1 & (b4 | nb2 | a1 & a3)
| na1 & na2 & na4)
| a3 & nb2 & nb4
| nb1 & ((na2 & a4 | na1) & a3
| a1 & na2 & na4 & b2);
this.extra[4 + 1][i] = nb1 & (a4 & (na3 & nb3	| (a3 | na2) & nb2)
| a1 & (a3 & nb2 & b4
| a2 & b2 & (b4	| a3 & na4 & nb3)))
| b1 & (a3 & a4 & b4
| na2 & na4 & nb3 & b4
| a2 & ((b3 | a4) & b4
| na3 & a4 & b2 & b3)
| na1 & (b4	| (a4 | a2) & b2 & b3))
| (na1 & (na3 & nb3 | na2 & nb2)
| a1 & (nb2 & nb3 | a2 & a3)) & b4;
if (coverage_test_flag) {
if (coveragetestid == 7) {
this.extra[5][i] = ~0;
}
}
}
for (; i < copylimit; i++) {
for (int j = 2; j < extralength; j++) {
this.extra[j][i] = otherinits.extra[j][i];
}
if (coverage_test_flag) {
if (coveragetestid == 8) {
this.extra[5][i] = ~0;
}
}
}
}
combinenullstatuschangeinassertinfo(otherinits);
return this;
}

public flowinfo addpotentialinitializationsfrom(flowinfo inits) {
if (this == dead_end){
return this;
}
if (inits == dead_end){
return this;
}
unconditionalflowinfo otherinits = inits.unconditionalinits();
// union of potentially set ones
this.potentialinits |= otherinits.potentialinits;
// treating extra storage
if (this.extra != null) {
if (otherinits.extra != null) {
// both sides have extra storage
int i = 0, length, otherlength;
if ((length = this.extra[0].length) < (otherlength = otherinits.extra[0].length)) {
// current storage is shorter -> grow current
for (int j = 0; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
(this.extra[j] = new long[otherlength]), 0, length);
}
for (; i < length; i++) {
this.extra[1][i] |= otherinits.extra[1][i];
}
for (; i < otherlength; i++) {
this.extra[1][i] = otherinits.extra[1][i];
}
}
else {
// current storage is longer
for (; i < otherlength; i++) {
this.extra[1][i] |= otherinits.extra[1][i];
}
}
}
}
else if (otherinits.extra != null) {
// no storage here, but other has extra storage.
int otherlength = otherinits.extra[0].length;
this.extra = new long[extralength][];
for (int j = 0; j < extralength; j++) {
this.extra[j] = new long[otherlength];
}
system.arraycopy(otherinits.extra[1], 0, this.extra[1], 0,
otherlength);
}
addpotentialnullinfofrom(otherinits);
return this;
}

/**
* compose other inits over this flow info, then return this. the operation
* semantics are to wave into this flow info the consequences upon null
* information of a possible path into the operations that resulted into
* otherinits. the fact that this path may be left unexecuted under peculiar
* conditions results into less specific results than
* {@@link #addinitializationsfrom(flowinfo) addinitializationsfrom}; moreover,
* only the null information is affected.
* @@param otherinits other null inits to compose over this
* @@return this, modified according to otherinits information
*/
public unconditionalflowinfo addpotentialnullinfofrom(
unconditionalflowinfo otherinits) {
if ((this.tagbits & unreachable) != 0 ||
(otherinits.tagbits & unreachable) != 0 ||
(otherinits.tagbits & null_flag_mask) == 0) {
return this;
}
// if we get here, otherinits has some null info
boolean thishadnulls = (this.tagbits & null_flag_mask) != 0,
thishasnulls = false;
long a1, a2, a3, a4,
na1, na2, na3, na4,
b1, b2, b3, b4,
nb1, nb2, nb3, nb4;
if (thishadnulls) {
this.nullbit1  = (a1 = this.nullbit1)
& ((a3 = this.nullbit3) & (a4 = this.nullbit4)
& ((nb2 = ~(b2 = otherinits.nullbit2))
& (nb4 = ~(b4 = otherinits.nullbit4))
| (b1 = otherinits.nullbit1) & (b3 = otherinits.nullbit3))
| (na2 = ~(a2 = this.nullbit2))
& (b1 & b3 | ((na4 = ~a4) | (na3 = ~a3)) & nb2)
| a2 & ((na4 | na3) & ((nb3 = ~b3) & nb4 | b1 & b2)));
this.nullbit2 = b2 & (nb3 | (nb1 = ~b1))
| a2 & (nb3 & nb4 | b2 | na3 | (na1 = ~a1));
this.nullbit3 = b3 & (nb1 & b2
| a2 & (nb2	| a3)
| na1 & nb2
| a1 & na2 & na4 & b1)
| a3 & (nb2 & nb4 | na2 & a4 | na1)
| a1 & na2 & na4 & b2;
this.nullbit4 = na3 & (nb1 & nb3 & b4
| a4 & (nb3 | b1 & b2))
| nb2 & (na3 & b1 & nb3	| na2 & (nb1 & b4 | b1 & nb3 | a4))
| a3 & (a4 & (nb2 | b1 & b3)
| a1 & a2 & (nb1 & b4 | na4 & (b2 | b1) & nb3));
if (coverage_test_flag) {
if (coveragetestid == 9) {
this.nullbit4 = ~0;
}
}
if ((this.nullbit2 | this.nullbit3 | this.nullbit4) != 0) { //  bit1 is redundant
thishasnulls = true;
}
} else {
this.nullbit1 = 0;
this.nullbit2 = (b2 = otherinits.nullbit2)
& ((nb3 = ~(b3 = otherinits.nullbit3)) |
(nb1 = ~(b1 = otherinits.nullbit1)));
this.nullbit3 = b3 & (nb1 | (nb2 = ~b2));
this.nullbit4 = ~b1 & ~b3 & (b4 = otherinits.nullbit4) | ~b2 & (b1 & ~b3 | ~b1 & b4);
if (coverage_test_flag) {
if (coveragetestid == 10) {
this.nullbit4 = ~0;
}
}
if ((this.nullbit2 | this.nullbit3 | this.nullbit4) != 0) { //  bit1 is redundant
thishasnulls = true;
}
}
// extra storage management
if (otherinits.extra != null) {
int mergelimit = 0, copylimit = otherinits.extra[0].length;
if (this.extra == null) {
this.extra = new long[extralength][];
for (int j = 0; j < extralength; j++) {
this.extra[j] = new long[copylimit];
}
if (coverage_test_flag) {
if (coveragetestid == 11) {
throw new assertionfailedexception("coverage 11"); //$non-nls-1$
}
}
} else {
mergelimit = copylimit;
if (mergelimit > this.extra[0].length) {
mergelimit = this.extra[0].length;
for (int j = 0; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
this.extra[j] = new long[copylimit], 0,
mergelimit);
}
if (! thishadnulls) {
mergelimit = 0;
// will do with a copy -- caveat: only valid because definite assignment bits copied above
if (coverage_test_flag) {
if (coveragetestid == 12) {
throw new assertionfailedexception("coverage 12"); //$non-nls-1$
}
}
}
}
}
// premature skip operations for fields
int i;
for (i = 0 ; i < mergelimit ; i++) {
this.extra[1 + 1][i]  = (a1 = this.extra[1 + 1][i])
& ((a3 = this.extra[3 + 1][i]) & (a4 = this.extra[4 + 1][i])
& ((nb2 = ~(b2 = otherinits.extra[2 + 1][i]))
& (nb4 = ~(b4 = otherinits.extra[4 + 1][i]))
| (b1 = otherinits.extra[1 + 1][i]) & (b3 = otherinits.extra[3 + 1][i]))
| (na2 = ~(a2 = this.extra[2 + 1][i]))
& (b1 & b3 | ((na4 = ~a4) | (na3 = ~a3)) & nb2)
| a2 & ((na4 | na3) & ((nb3 = ~b3) & nb4 | b1 & b2)));
this.extra[2 + 1][i] = b2 & (nb3 | (nb1 = ~b1))
| a2 & (nb3 & nb4 | b2 | na3 | (na1 = ~a1));
this.extra[3 + 1][i] = b3 & (nb1 & b2
| a2 & (nb2	| a3)
| na1 & nb2
| a1 & na2 & na4 & b1)
| a3 & (nb2 & nb4 | na2 & a4 | na1)
| a1 & na2 & na4 & b2;
this.extra[4 + 1][i] = na3 & (nb1 & nb3 & b4
| a4 & (nb3 | b1 & b2))
| nb2 & (na3 & b1 & nb3	| na2 & (nb1 & b4 | b1 & nb3 | a4))
| a3 & (a4 & (nb2 | b1 & b3)
| a1 & a2 & (nb1 & b4 | na4 & (b2 | b1) & nb3));
if ((this.extra[2 + 1][i] | this.extra[3 + 1][i] | this.extra[4 + 1][i]) != 0) { //  bit1 is redundant
thishasnulls = true;
}
if (coverage_test_flag) {
if (coveragetestid == 13) {
this.nullbit4 = ~0;
}
}
}
for (; i < copylimit; i++) {
this.extra[1 + 1][i] = 0;
this.extra[2 + 1][i] = (b2 = otherinits.extra[2 + 1][i])
& ((nb3 = ~(b3 = otherinits.extra[3 + 1][i])) |
(nb1 = ~(b1 = otherinits.extra[1 + 1][i])));
this.extra[3 + 1][i] = b3 & (nb1 | (nb2 = ~b2));
this.extra[4 + 1][i] = ~b1 & ~b3 & (b4 = otherinits.extra[4 + 1][i]) | ~b2 & (b1 & ~b3 | ~b1 & b4);
if ((this.extra[2 + 1][i] | this.extra[3 + 1][i] | this.extra[4 + 1][i]) != 0) { //  bit1 is redundant
thishasnulls = true;
}
if (coverage_test_flag) {
if (coveragetestid == 14) {
this.extra[5][i] = ~0;
}
}
}
}
combinenullstatuschangeinassertinfo(otherinits);
if (thishasnulls) {
this.tagbits |= null_flag_mask;
}
else {
this.tagbits &= null_flag_mask;
}
return this;
}

final public boolean cannotbedefinitelynullornonnull(localvariablebinding local) {
if ((this.tagbits & null_flag_mask) == 0 ||
(local.type.tagbits & tagbits.isbasetype) != 0) {
return false;
}
int position;
if ((position = local.id + this.maxfieldcount) < bitcachesize) {
// use bits
return (
(~this.nullbit1
& (this.nullbit2 & this.nullbit3 | this.nullbit4)
| ~this.nullbit2 & ~this.nullbit3 & this.nullbit4)
& (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1) >=
this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
long a2, a3, a4;
return (
(~this.extra[2][vectorindex]
& ((a2 = this.extra[3][vectorindex]) & (a3 = this.extra[4][vectorindex]) | (a4 = this.extra[5][vectorindex]))
| ~a2 & ~a3 & a4)
& (1l << (position % bitcachesize))) != 0;
}

final public boolean cannotbenull(localvariablebinding local) {
if ((this.tagbits & null_flag_mask) == 0 ||
(local.type.tagbits & tagbits.isbasetype) != 0) {
return false;
}
int position;
if ((position = local.id + this.maxfieldcount) < bitcachesize) {
// use bits
return (this.nullbit1 & this.nullbit3
& ((this.nullbit2 & this.nullbit4) | ~this.nullbit2)
& (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1) >=
this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return (this.extra[2][vectorindex] & this.extra[4][vectorindex]
& ((this.extra[3][vectorindex] & this.extra[5][vectorindex]) |
~this.extra[3][vectorindex])
& (1l << (position % bitcachesize))) != 0;
}

final public boolean canonlybenull(localvariablebinding local) {
if ((this.tagbits & null_flag_mask) == 0 ||
(local.type.tagbits & tagbits.isbasetype) != 0) {
return false;
}
int position;
if ((position = local.id + this.maxfieldcount) < bitcachesize) {
// use bits
return (this.nullbit1 & this.nullbit2
& (~this.nullbit3 | ~this.nullbit4)
& (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1) >=
this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return (this.extra[2][vectorindex] & this.extra[3][vectorindex]
& (~this.extra[4][vectorindex] | ~this.extra[5][vectorindex])
& (1l << (position % bitcachesize))) != 0;
}

public flowinfo copy() {
// do not clone the deadend
if (this == dead_end) {
return this;
}
unconditionalflowinfo copy = new unconditionalflowinfo();
// copy slots
copy.definiteinits = this.definiteinits;
copy.potentialinits = this.potentialinits;
boolean hasnullinfo = (this.tagbits & null_flag_mask) != 0;
if (hasnullinfo) {
copy.nullbit1 = this.nullbit1;
copy.nullbit2 = this.nullbit2;
copy.nullbit3 = this.nullbit3;
copy.nullbit4 = this.nullbit4;
}
copy.tagbits = this.tagbits;
copy.maxfieldcount = this.maxfieldcount;
if (this.extra != null) {
int length;
copy.extra = new long[extralength][];
system.arraycopy(this.extra[0], 0,
(copy.extra[0] = new long[length = this.extra[0].length]), 0,
length);
system.arraycopy(this.extra[1], 0,
(copy.extra[1] = new long[length]), 0, length);
if (hasnullinfo) {
for (int j = 2; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
(copy.extra[j] = new long[length]), 0, length);
}
}
else {
for (int j = 2; j < extralength; j++) {
copy.extra[j] = new long[length];
}
}
}
copy.nullstatuschangedinassert = this.nullstatuschangedinassert;
return copy;
}

/**
* discard definite inits and potential inits from this, then return this.
* the returned flow info only holds null related information.
* @@return this flow info, minus definite inits and potential inits
*/
public unconditionalflowinfo discardinitializationinfo() {
if (this == dead_end) {
return this;
}
this.definiteinits =
this.potentialinits = 0;
if (this.extra != null) {
for (int i = 0, length = this.extra[0].length; i < length; i++) {
this.extra[0][i] = this.extra[1][i] = 0;
}
}
return this;
}

/**
* remove local variables information from this flow info and return this.
* @@return this, deprived from any local variable information
*/
public unconditionalflowinfo discardnonfieldinitializations() {
int limit = this.maxfieldcount;
if (limit < bitcachesize) {
long mask = (1l << limit)-1;
this.definiteinits &= mask;
this.potentialinits &= mask;
this.nullbit1 &= mask;
this.nullbit2 &= mask;
this.nullbit3 &= mask;
this.nullbit4 &= mask;
}
// use extra vector
if (this.extra == null) {
return this; // if vector not yet allocated, then not initialized
}
int vectorindex, length = this.extra[0].length;
if ((vectorindex = (limit / bitcachesize) - 1) >= length) {
return this; // not enough room yet
}
if (vectorindex >= 0) {
// else we only have complete non field array items left
long mask = (1l << (limit % bitcachesize))-1;
for (int j = 0; j < extralength; j++) {
this.extra[j][vectorindex] &= mask;
}
}
for (int i = vectorindex + 1; i < length; i++) {
for (int j = 0; j < extralength; j++) {
this.extra[j][i] = 0;
}
}
return this;
}

public flowinfo initswhenfalse() {
return this;
}

public flowinfo initswhentrue() {
return this;
}

/**
* check status of definite assignment at a given position.
* it deals with the dual representation of the initializationinfo2:
* bits for the first 64 entries, then an array of booleans.
*/
final private boolean isdefinitelyassigned(int position) {
if (position < bitcachesize) {
// use bits
return (this.definiteinits & (1l << position)) != 0;
}
// use extra vector
if (this.extra == null)
return false; // if vector not yet allocated, then not initialized
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1)
>= this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return ((this.extra[0][vectorindex]) &
(1l << (position % bitcachesize))) != 0;
}

final public boolean isdefinitelyassigned(fieldbinding field) {
// mirrored in codestream.isdefinitelyassigned(..)
// do not want to complain in unreachable code
if ((this.tagbits & unreachable) != 0) {
return true;
}
return isdefinitelyassigned(field.id);
}

final public boolean isdefinitelyassigned(localvariablebinding local) {
// do not want to complain in unreachable code if local declared in reachable code
if ((this.tagbits & unreachable) != 0 && (local.declaration.bits & astnode.islocaldeclarationreachable) != 0) {
return true;
}
return isdefinitelyassigned(local.id + this.maxfieldcount);
}

final public boolean isdefinitelynonnull(localvariablebinding local) {
// do not want to complain in unreachable code
if ((this.tagbits & unreachable) != 0 ||
(this.tagbits & null_flag_mask) == 0) {
return false;
}
if ((local.type.tagbits & tagbits.isbasetype) != 0 ||
local.constant() != constant.notaconstant) { // string instances
return true;
}
int position = local.id + this.maxfieldcount;
if (position < bitcachesize) { // use bits
return ((this.nullbit1 & this.nullbit3 & (~this.nullbit2 | this.nullbit4))
& (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1)
>= this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return ((this.extra[2][vectorindex] & this.extra[4][vectorindex]
& (~this.extra[3][vectorindex] | this.extra[5][vectorindex]))
& (1l << (position % bitcachesize))) != 0;
}

final public boolean isdefinitelynull(localvariablebinding local) {
// do not want to complain in unreachable code
if ((this.tagbits & unreachable) != 0 ||
(this.tagbits & null_flag_mask) == 0 ||
(local.type.tagbits & tagbits.isbasetype) != 0) {
return false;
}
int position = local.id + this.maxfieldcount;
if (position < bitcachesize) { // use bits
return ((this.nullbit1 & this.nullbit2
& (~this.nullbit3 | ~this.nullbit4))
& (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1) >=
this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return ((this.extra[2][vectorindex] & this.extra[3][vectorindex]
& (~this.extra[4][vectorindex] | ~this.extra[5][vectorindex]))
& (1l << (position % bitcachesize))) != 0;
}

final public boolean isdefinitelyunknown(localvariablebinding local) {
// do not want to complain in unreachable code
if ((this.tagbits & unreachable) != 0 ||
(this.tagbits & null_flag_mask) == 0) {
return false;
}
int position = local.id + this.maxfieldcount;
if (position < bitcachesize) { // use bits
return ((this.nullbit1 & this.nullbit4
& ~this.nullbit2 & ~this.nullbit3) & (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1) >=
this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return ((this.extra[2][vectorindex] & this.extra[5][vectorindex]
& ~this.extra[3][vectorindex] & ~this.extra[4][vectorindex])
& (1l << (position % bitcachesize))) != 0;
}

/**
* check status of potential assignment at a given position.
*/
final private boolean ispotentiallyassigned(int position) {
// id is zero-based
if (position < bitcachesize) {
// use bits
return (this.potentialinits & (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1)
>= this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return ((this.extra[1][vectorindex]) &
(1l << (position % bitcachesize))) != 0;
}

final public boolean ispotentiallyassigned(fieldbinding field) {
return ispotentiallyassigned(field.id);
}

final public boolean ispotentiallyassigned(localvariablebinding local) {
// final constants are inlined, and thus considered as always initialized
if (local.constant() != constant.notaconstant) {
return true;
}
return ispotentiallyassigned(local.id + this.maxfieldcount);
}

final public boolean ispotentiallynonnull(localvariablebinding local) {
if ((this.tagbits & null_flag_mask) == 0 ||
(local.type.tagbits & tagbits.isbasetype) != 0) {
return false;
}
int position;
if ((position = local.id + this.maxfieldcount) < bitcachesize) {
// use bits
return ((this.nullbit3 & (~this.nullbit1 | ~this.nullbit2))
& (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1) >=
this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return ((this.extra[4][vectorindex]
& (~this.extra[2][vectorindex] | ~this.extra[3][vectorindex]))
& (1l << (position % bitcachesize))) != 0;
}

final public boolean ispotentiallynull(localvariablebinding local) {
if ((this.tagbits & null_flag_mask) == 0 ||
(local.type.tagbits & tagbits.isbasetype) != 0) {
return false;
}
int position;
if ((position = local.id + this.maxfieldcount) < bitcachesize) {
// use bits
return ((this.nullbit2 & (~this.nullbit1 | ~this.nullbit3))
& (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1) >=
this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return ((this.extra[3][vectorindex]
& (~this.extra[2][vectorindex] | ~this.extra[4][vectorindex]))
& (1l << (position % bitcachesize))) != 0;
}

final public boolean ispotentiallyunknown(localvariablebinding local) {
// do not want to complain in unreachable code
if ((this.tagbits & unreachable) != 0 ||
(this.tagbits & null_flag_mask) == 0) {
return false;
}
int position = local.id + this.maxfieldcount;
if (position < bitcachesize) { // use bits
return (this.nullbit4
& (~this.nullbit1 | ~this.nullbit2 & ~this.nullbit3)
& (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1) >=
this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return (this.extra[5][vectorindex]
& (~this.extra[2][vectorindex]
| ~this.extra[3][vectorindex] & ~this.extra[4][vectorindex])
& (1l << (position % bitcachesize))) != 0;
}

final public boolean isprotectednonnull(localvariablebinding local) {
if ((this.tagbits & null_flag_mask) == 0 ||
(local.type.tagbits & tagbits.isbasetype) != 0) {
return false;
}
int position;
if ((position = local.id + this.maxfieldcount) < bitcachesize) {
// use bits
return (this.nullbit1 & this.nullbit3 & this.nullbit4 & (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1) >=
this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return (this.extra[2][vectorindex]
& this.extra[4][vectorindex]
& this.extra[5][vectorindex]
& (1l << (position % bitcachesize))) != 0;
}

final public boolean isprotectednull(localvariablebinding local) {
if ((this.tagbits & null_flag_mask) == 0 ||
(local.type.tagbits & tagbits.isbasetype) != 0) {
return false;
}
int position;
if ((position = local.id + this.maxfieldcount) < bitcachesize) {
// use bits
return (this.nullbit1 & this.nullbit2
& (this.nullbit3 ^ this.nullbit4)
& (1l << position)) != 0;
}
// use extra vector
if (this.extra == null) {
return false; // if vector not yet allocated, then not initialized
}
int vectorindex;
if ((vectorindex = (position / bitcachesize) - 1) >=
this.extra[0].length) {
return false; // if not enough room in vector, then not initialized
}
return (this.extra[2][vectorindex] & this.extra[3][vectorindex]
& (this.extra[4][vectorindex] ^ this.extra[5][vectorindex])
& (1l << (position % bitcachesize))) != 0;
}

public void markascomparedequaltononnull(localvariablebinding local) {
// protected from non-object locals in calling methods
if (this != dead_end) {
this.tagbits |= null_flag_mask;
int position;
long mask;
long a1, a2, a3, a4, na2;
// position is zero-based
if ((position = local.id + this.maxfieldcount) < bitcachesize) {
// use bits
if (((mask = 1l << position)
& (a1 = this.nullbit1)
& (na2 = ~(a2 = this.nullbit2))
& ~(a3 = this.nullbit3)
& (a4 = this.nullbit4))
!= 0) {
this.nullbit4 &= ~mask;
} else if ((mask & a1 & na2 & a3) == 0) {
this.nullbit4 |= mask;
if ((mask & a1) == 0) {
if ((mask & a2 & (a3 ^ a4)) != 0) {
this.nullbit2 &= ~mask;
}
else if ((mask & (a2 | a3 | a4)) == 0) {
this.nullbit2 |= mask;
}
}
}
this.nullbit1 |= mask;
this.nullbit3 |= mask;
if (coverage_test_flag) {
if (coveragetestid == 15) {
this.nullbit4 = ~0;
}
}
}
else {
// use extra vector
int vectorindex = (position / bitcachesize) - 1;
if (this.extra == null) {
int length = vectorindex + 1;
this.extra = new long[extralength][];
for (int j = 0; j < extralength; j++) {
this.extra[j] = new long[length];
}
if (coverage_test_flag) {
if (coveragetestid == 16) {
throw new assertionfailedexception("coverage 16"); //$non-nls-1$
}
}
}
else {
int oldlength;
if (vectorindex >= (oldlength = this.extra[0].length)) {
int newlength = vectorindex + 1;
for (int j = 0; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
(this.extra[j] = new long[newlength]), 0,
oldlength);
}
if (coverage_test_flag) {
if (coveragetestid == 17) {
throw new assertionfailedexception("coverage 17"); //$non-nls-1$
}
}
}
}
// macro :'b,'es/nullbit\(.\)/extra[\1 + 1][vectorindex]/gc
if (((mask = 1l << (position % bitcachesize))
& (a1 = this.extra[1 + 1][vectorindex])
& (na2 = ~(a2 = this.extra[2 + 1][vectorindex]))
& ~(a3 = this.extra[3 + 1][vectorindex])
& (a4 = this.extra[4 + 1][vectorindex]))
!= 0) {
this.extra[4 + 1][vectorindex] &= ~mask;
} else if ((mask & a1 & na2 & a3) == 0) {
this.extra[4 + 1][vectorindex] |= mask;
if ((mask & a1) == 0) {
if ((mask & a2 & (a3 ^ a4)) != 0) {
this.extra[2 + 1][vectorindex] &= ~mask;
}
else if ((mask & (a2 | a3 | a4)) == 0) {
this.extra[2 + 1][vectorindex] |= mask;
}
}
}
this.extra[1 + 1][vectorindex] |= mask;
this.extra[3 + 1][vectorindex] |= mask;
if (coverage_test_flag) {
if (coveragetestid == 18) {
this.extra[5][vectorindex] = ~0;
}
}
}
}
}

public void markascomparedequaltonull(localvariablebinding local) {
// protected from non-object locals in calling methods
if (this != dead_end) {
this.tagbits |= null_flag_mask;
int position;
long mask;
// position is zero-based
if ((position = local.id + this.maxfieldcount) < bitcachesize) {
// use bits
if (((mask = 1l << position) & this.nullbit1) != 0) {
if ((mask
& (~this.nullbit2 | this.nullbit3
| ~this.nullbit4)) != 0) {
this.nullbit4 &= ~mask;
}
} else if ((mask & this.nullbit4) != 0) {
this.nullbit3 &= ~mask;
} else {
if ((mask & this.nullbit2) != 0) {
this.nullbit3 &= ~mask;
this.nullbit4 |= mask;
} else {
this.nullbit3 |= mask;
}
}
this.nullbit1 |= mask;
this.nullbit2 |= mask;
if (coverage_test_flag) {
if (coveragetestid == 19) {
this.nullbit4 = ~0;
}
}
}
else {
// use extra vector
int vectorindex = (position / bitcachesize) - 1;
mask = 1l << (position % bitcachesize);
if (this.extra == null) {
int length = vectorindex + 1;
this.extra = new long[extralength][];
for (int j = 0; j < extralength; j++) {
this.extra[j] = new long[length ];
}
if (coverage_test_flag) {
if(coveragetestid == 20) {
throw new assertionfailedexception("coverage 20"); //$non-nls-1$
}
}
}
else {
int oldlength;
if (vectorindex >= (oldlength = this.extra[0].length)) {
int newlength = vectorindex + 1;
for (int j = 0; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
(this.extra[j] = new long[newlength]), 0,
oldlength);
}
if (coverage_test_flag) {
if(coveragetestid == 21) {
throw new assertionfailedexception("coverage 21"); //$non-nls-1$
}
}
}
}
if ((mask & this.extra[1 + 1][vectorindex]) != 0) {
if ((mask
& (~this.extra[2 + 1][vectorindex] | this.extra[3 + 1][vectorindex]
| ~this.extra[4 + 1][vectorindex])) != 0) {
this.extra[4 + 1][vectorindex] &= ~mask;
}
} else if ((mask & this.extra[4 + 1][vectorindex]) != 0) {
this.extra[3 + 1][vectorindex] &= ~mask;
} else {
if ((mask & this.extra[2 + 1][vectorindex]) != 0) {
this.extra[3 + 1][vectorindex] &= ~mask;
this.extra[4 + 1][vectorindex] |= mask;
} else {
this.extra[3 + 1][vectorindex] |= mask;
}
}
this.extra[1 + 1][vectorindex] |= mask;
this.extra[2 + 1][vectorindex] |= mask;
}
}
}

/**
* record a definite assignment at a given position.
*/
final private void markasdefinitelyassigned(int position) {

if (this != dead_end) {
// position is zero-based
if (position < bitcachesize) {
// use bits
long mask;
this.definiteinits |= (mask = 1l << position);
this.potentialinits |= mask;
}
else {
// use extra vector
int vectorindex = (position / bitcachesize) - 1;
if (this.extra == null) {
int length = vectorindex + 1;
this.extra = new long[extralength][];
for (int j = 0; j < extralength; j++) {
this.extra[j] = new long[length];
}
}
else {
int oldlength; // might need to grow the arrays
if (vectorindex >= (oldlength = this.extra[0].length)) {
for (int j = 0; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
(this.extra[j] = new long[vectorindex + 1]), 0,
oldlength);
}
}
}
long mask;
this.extra[0][vectorindex] |=
(mask = 1l << (position % bitcachesize));
this.extra[1][vectorindex] |= mask;
}
}
}

public void markasdefinitelyassigned(fieldbinding field) {
if (this != dead_end)
markasdefinitelyassigned(field.id);
}

public void markasdefinitelyassigned(localvariablebinding local) {
if (this != dead_end)
markasdefinitelyassigned(local.id + this.maxfieldcount);
}

public void markasdefinitelynonnull(localvariablebinding local) {
// protected from non-object locals in calling methods
if (this != dead_end) {
this.tagbits |= null_flag_mask;
long mask;
int position;
// position is zero-based
if ((position = local.id + this.maxfieldcount) < bitcachesize) { // use bits
// set assigned non null
this.nullbit1 |= (mask = 1l << position);
this.nullbit3 |= mask;
// clear others
this.nullbit2 &= (mask = ~mask);
this.nullbit4 &= mask;
if (coverage_test_flag) {
if(coveragetestid == 22) {
this.nullbit1 = 0;
}
}
}
else {
// use extra vector
int vectorindex ;
this.extra[2][vectorindex = (position / bitcachesize) - 1]
|= (mask = 1l << (position % bitcachesize));
this.extra[4][vectorindex] |= mask;
this.extra[3][vectorindex] &= (mask = ~mask);
this.extra[5][vectorindex] &= mask;
if (coverage_test_flag) {
if(coveragetestid == 23) {
this.extra[2][vectorindex] = 0;
}
}
}
}
}

public void markasdefinitelynull(localvariablebinding local) {
// protected from non-object locals in calling methods
if (this != dead_end) {
this.tagbits |= null_flag_mask;
long mask;
int position;
// position is zero-based
if ((position = local.id + this.maxfieldcount) < bitcachesize) { // use bits
// mark assigned null
this.nullbit1 |= (mask = 1l << position);
this.nullbit2 |= mask;
// clear others
this.nullbit3 &= (mask = ~mask);
this.nullbit4 &= mask;
if (coverage_test_flag) {
if(coveragetestid == 24) {
this.nullbit4 = ~0;
}
}
}
else {
// use extra vector
int vectorindex ;
this.extra[2][vectorindex = (position / bitcachesize) - 1]
|= (mask = 1l << (position % bitcachesize));
this.extra[3][vectorindex] |= mask;
this.extra[4][vectorindex] &= (mask = ~mask);
this.extra[5][vectorindex] &= mask;
if (coverage_test_flag) {
if(coveragetestid == 25) {
this.extra[5][vectorindex] = ~0;
}
}
}
}
}

/**
* mark a local as having been assigned to an unknown value.
* @@param local the local to mark
*/
// premature may try to get closer to markasdefinitelyassigned, but not
//			 obvious
public void markasdefinitelyunknown(localvariablebinding local) {
// protected from non-object locals in calling methods
if (this != dead_end) {
this.tagbits |= null_flag_mask;
long mask;
int position;
// position is zero-based
if ((position = local.id + this.maxfieldcount) < bitcachesize) {
// use bits
// mark assigned null
this.nullbit1 |= (mask = 1l << position);
this.nullbit4 |= mask;
// clear others
this.nullbit2 &= (mask = ~mask);
this.nullbit3 &= mask;
if (coverage_test_flag) {
if(coveragetestid == 26) {
this.nullbit4 = 0;
}
}
}
else {
// use extra vector
int vectorindex ;
this.extra[2][vectorindex = (position / bitcachesize) - 1]
|= (mask = 1l << (position % bitcachesize));
this.extra[5][vectorindex] |= mask;
this.extra[3][vectorindex] &= (mask = ~mask);
this.extra[4][vectorindex] &= mask;
if (coverage_test_flag) {
if(coveragetestid == 27) {
this.extra[5][vectorindex] = 0;
}
}
}
}
}

public unconditionalflowinfo mergedwith(unconditionalflowinfo otherinits) {
if ((otherinits.tagbits & unreachable) != 0 && this != dead_end) {
if (coverage_test_flag) {
if(coveragetestid == 28) {
throw new assertionfailedexception("coverage 28"); //$non-nls-1$
}
}
return this;
}
if ((this.tagbits & unreachable) != 0) {
if (coverage_test_flag) {
if(coveragetestid == 29) {
throw new assertionfailedexception("coverage 29"); //$non-nls-1$
}
}
return (unconditionalflowinfo) otherinits.copy(); // make sure otherinits won't be affected
}

// intersection of definitely assigned variables,
this.definiteinits &= otherinits.definiteinits;
// union of potentially set ones
this.potentialinits |= otherinits.potentialinits;

// null combinations
boolean
thishasnulls = (this.tagbits & null_flag_mask) != 0,
otherhasnulls = (otherinits.tagbits & null_flag_mask) != 0,
thishadnulls = thishasnulls;
long
a1, a2, a3, a4,
na1, na2, na3, na4,
nb1, nb2, nb3, nb4,
b1, b2, b3, b4;
if (thishadnulls) {
if (otherhasnulls) {
this.nullbit1 = (a2 = this.nullbit2) & (a3 = this.nullbit3)
& (a4 = this.nullbit4) & (b1 = otherinits.nullbit1)
& (nb2 = ~(b2 = otherinits.nullbit2))
| (a1 = this.nullbit1) & (b1 & (a3 & a4 & (b3 = otherinits.nullbit3)
& (b4 = otherinits.nullbit4)
| (na2 = ~a2) & nb2
& ((nb4 = ~b4) | (na4 = ~a4)
| (na3 = ~a3) & (nb3 = ~b3))
| a2 & b2 & ((na4 | na3) & (nb4	| nb3)))
| na2 & b2 & b3 & b4);
this.nullbit2 = b2 & (nb3 | (nb1 = ~b1) | a3 & (a4 | (na1 = ~a1)) & nb4)
| a2 & (b2 | na4 & b3 & (b4 | nb1) | na3 | na1);
this.nullbit3 = b3 & (nb2 & b4 | nb1 | a3 & (na4 & nb4 | a4 & b4))
| a3 & (na2 & a4 | na1)
| (a2 | na1) & b1 & nb2 & nb4
| a1 & na2 & na4 & (b2 | nb1);
this.nullbit4 = na3 & (nb1 & nb3 & b4
| b1 & (nb2 & nb3 | a4 & b2 & nb4)
| na1 & a4 & (nb3 | b1 & b2))
| a3 & a4 & (b3 & b4 | b1 & nb2)
| na2 & (nb1 & b4 | b1 & nb3 | na1 & a4) & nb2
| a1 & (na3 & (nb3 & b4
| b1 & b2 & b3 & nb4
| na2 & (nb3 | nb2))
| na2 & b3 & b4
| a2 & (nb1 & b4 | a3 & na4 & b1) & nb3);
if (coverage_test_flag) {
if(coveragetestid == 30) {
this.nullbit4 = ~0;
}
}
} else { // other has no null info
a1 = this.nullbit1;
this.nullbit1 = 0;
this.nullbit2 = (a2 = this.nullbit2) & (na3 = ~(a3 = this.nullbit3) | (na1 = ~a1));
this.nullbit3 = a3 & ((na2 = ~a2) & (a4 = this.nullbit4) | na1) | a1 & na2 & ~a4;
this.nullbit4 = (na3 | na2) & na1 & a4	| a1 & na3 & na2;
if (coverage_test_flag) {
if(coveragetestid == 31) {
this.nullbit4 = ~0;
}
}
}
} else if (otherhasnulls) { // only other had nulls
this.nullbit1 = 0;
this.nullbit2 = (b2 = otherinits.nullbit2) & (nb3 = ~(b3 = otherinits.nullbit3) | (nb1 = ~(b1 = otherinits.nullbit1)));
this.nullbit3 = b3 & ((nb2 = ~b2) & (b4 = otherinits.nullbit4) | nb1) | b1 & nb2 & ~b4;
this.nullbit4 = (nb3 | nb2) & nb1 & b4	| b1 & nb3 & nb2;
if (coverage_test_flag) {
if(coveragetestid == 32) {
this.nullbit4 = ~0;
}
}
thishasnulls =
// redundant with the three following ones
this.nullbit2 != 0 ||
this.nullbit3 != 0 ||
this.nullbit4 != 0;
}

// treating extra storage
if (this.extra != null || otherinits.extra != null) {
int mergelimit = 0, copylimit = 0, resetlimit = 0;
int i;
if (this.extra != null) {
if (otherinits.extra != null) {
// both sides have extra storage
int length, otherlength;
if ((length = this.extra[0].length) <
(otherlength = otherinits.extra[0].length)) {
// current storage is shorter -> grow current
for (int j = 0; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
(this.extra[j] = new long[otherlength]), 0, length);
}
mergelimit = length;
copylimit = otherlength;
if (coverage_test_flag) {
if(coveragetestid == 33) {
throw new assertionfailedexception("coverage 33"); //$non-nls-1$
}
}
}
else {
// current storage is longer
mergelimit = otherlength;
resetlimit = length;
if (coverage_test_flag) {
if(coveragetestid == 34) {
throw new assertionfailedexception("coverage 34"); //$non-nls-1$
}
}
}
}
else {
resetlimit = this.extra[0].length;
if (coverage_test_flag) {
if(coveragetestid == 35) {
throw new assertionfailedexception("coverage 35"); //$non-nls-1$
}
}
}
}
else if (otherinits.extra != null) {
// no storage here, but other has extra storage.
int otherlength = otherinits.extra[0].length;
this.extra = new long[extralength][];
for (int j = 0; j < extralength; j++) {
this.extra[j] = new long[otherlength];
}
system.arraycopy(otherinits.extra[1], 0,
this.extra[1], 0, otherlength);
copylimit = otherlength;
if (coverage_test_flag) {
if(coveragetestid == 36) {
throw new assertionfailedexception("coverage 36"); //$non-nls-1$
}
}
}
// macro :'b,'es/nullbit\(.\)/extra[\1 + 1][i]/g
// manage definite assignment
for (i = 0; i < mergelimit; i++) {
this.extra[0][i] &= otherinits.extra[0][i];
this.extra[1][i] |= otherinits.extra[1][i];
}
for (; i < copylimit; i++) {
this.extra[1][i] = otherinits.extra[1][i];
}
for (; i < resetlimit; i++) {
this.extra[0][i] = 0;
}
// refine null bits requirements
if (!otherhasnulls) {
if (resetlimit < mergelimit) {
resetlimit = mergelimit;
}
copylimit = 0; // no need to carry inexisting nulls
mergelimit = 0;
}
if (!thishadnulls) {
resetlimit = 0; // no need to reset anything
}
// compose nulls
for (i = 0; i < mergelimit; i++) {
this.extra[1 + 1][i] = (a2 = this.extra[2 + 1][i]) & (a3 = this.extra[3 + 1][i])
& (a4 = this.extra[4 + 1][i]) & (b1 = otherinits.extra[1 + 1][i])
& (nb2 = ~(b2 = otherinits.extra[2 + 1][i]))
| (a1 = this.extra[1 + 1][i]) & (b1 & (a3 & a4 & (b3 = otherinits.extra[3 + 1][i])
& (b4 = otherinits.extra[4 + 1][i])
| (na2 = ~a2) & nb2
& ((nb4 = ~b4) | (na4 = ~a4)
| (na3 = ~a3) & (nb3 = ~b3))
| a2 & b2 & ((na4 | na3) & (nb4	| nb3)))
| na2 & b2 & b3 & b4);
this.extra[2 + 1][i] = b2 & (nb3 | (nb1 = ~b1) | a3 & (a4 | (na1 = ~a1)) & nb4)
| a2 & (b2 | na4 & b3 & (b4 | nb1) | na3 | na1);
this.extra[3 + 1][i] = b3 & (nb2 & b4 | nb1 | a3 & (na4 & nb4 | a4 & b4))
| a3 & (na2 & a4 | na1)
| (a2 | na1) & b1 & nb2 & nb4
| a1 & na2 & na4 & (b2 | nb1);
this.extra[4 + 1][i] = na3 & (nb1 & nb3 & b4
| b1 & (nb2 & nb3 | a4 & b2 & nb4)
| na1 & a4 & (nb3 | b1 & b2))
| a3 & a4 & (b3 & b4 | b1 & nb2)
| na2 & (nb1 & b4 | b1 & nb3 | na1 & a4) & nb2
| a1 & (na3 & (nb3 & b4
| b1 & b2 & b3 & nb4
| na2 & (nb3 | nb2))
| na2 & b3 & b4
| a2 & (nb1 & b4 | a3 & na4 & b1) & nb3);
thishasnulls = thishasnulls ||
this.extra[3][i] != 0 ||
this.extra[4][i] != 0 ||
this.extra[5][i] != 0 ;
if (coverage_test_flag) {
if(coveragetestid == 37) {
this.extra[5][i] = ~0;
}
}
}
for (; i < copylimit; i++) {
this.extra[1 + 1][i] = 0;
this.extra[2 + 1][i] = (b2 = otherinits.extra[2 + 1][i]) & (nb3 = ~(b3 = otherinits.extra[3 + 1][i]) | (nb1 = ~(b1 = otherinits.extra[1 + 1][i])));
this.extra[3 + 1][i] = b3 & ((nb2 = ~b2) & (b4 = otherinits.extra[4 + 1][i]) | nb1) | b1 & nb2 & ~b4;
this.extra[4 + 1][i] = (nb3 | nb2) & nb1 & b4	| b1 & nb3 & nb2;
thishasnulls = thishasnulls ||
this.extra[3][i] != 0 ||
this.extra[4][i] != 0 ||
this.extra[5][i] != 0;
if (coverage_test_flag) {
if(coveragetestid == 38) {
this.extra[5][i] = ~0;
}
}
}
for (; i < resetlimit; i++) {
a1 = this.extra[1 + 1][i];
this.extra[1 + 1][i] = 0;
this.extra[2 + 1][i] = (a2 = this.extra[2 + 1][i]) & (na3 = ~(a3 = this.extra[3 + 1][i]) | (na1 = ~a1));
this.extra[3 + 1][i] = a3 & ((na2 = ~a2) & (a4 = this.extra[4 + 1][i]) | na1) | a1 & na2 & ~a4;
this.extra[4 + 1][i] = (na3 | na2) & na1 & a4	| a1 & na3 & na2;
thishasnulls = thishasnulls ||
this.extra[3][i] != 0 ||
this.extra[4][i] != 0 ||
this.extra[5][i] != 0;
if (coverage_test_flag) {
if(coveragetestid == 39) {
this.extra[5][i] = ~0;
}
}
}
}
combinenullstatuschangeinassertinfo(otherinits);
if (thishasnulls) {
this.tagbits |= null_flag_mask;
}
else {
this.tagbits &= ~null_flag_mask;
}
return this;
}

/*
* answer the total number of fields in enclosing types of a given type
*/
static int numberofenclosingfields(referencebinding type){
int count = 0;
type = type.enclosingtype();
while(type != null) {
count += type.fieldcount();
type = type.enclosingtype();
}
return count;
}

public unconditionalflowinfo nullinfolessunconditionalcopy() {
if (this == dead_end) {
return this;
}
unconditionalflowinfo copy = new unconditionalflowinfo();
copy.definiteinits = this.definiteinits;
copy.potentialinits = this.potentialinits;
copy.tagbits = this.tagbits & ~null_flag_mask;
copy.maxfieldcount = this.maxfieldcount;
if (this.extra != null) {
int length;
copy.extra = new long[extralength][];
system.arraycopy(this.extra[0], 0,
(copy.extra[0] =
new long[length = this.extra[0].length]), 0, length);
system.arraycopy(this.extra[1], 0,
(copy.extra[1] = new long[length]), 0, length);
for (int j = 2; j < extralength; j++) {
copy.extra[j] = new long[length];
}
}
return copy;
}

public flowinfo safeinitswhentrue() {
return copy();
}

public flowinfo setreachmode(int reachmode) {
if (this == dead_end) {// cannot modify dead_end
return this;
}
if (reachmode == reachable ) {
this.tagbits &= ~unreachable;
} else {
if ((this.tagbits & unreachable) == 0) {
// reset optional inits when becoming unreachable
// see initializationtest#test090 (and others)
this.potentialinits = 0;
if (this.extra != null) {
for (int i = 0, length = this.extra[0].length;
i < length; i++) {
this.extra[1][i] = 0;
}
}
}
this.tagbits |= unreachable;
}
return this;
}

public string tostring(){
// premature consider printing bit fields as 0001 0001 1000 0001...
if (this == dead_end){
return "flowinfo.dead_end"; //$non-nls-1$
}
if ((this.tagbits & null_flag_mask) != 0) {
if (this.extra == null) {
return "flowinfo<def: " + this.definiteinits //$non-nls-1$
+", pot: " + this.potentialinits  //$non-nls-1$
+ ", reachable:" + ((this.tagbits & unreachable) == 0) //$non-nls-1$
+", null: " + this.nullbit1 //$non-nls-1$
+ this.nullbit2 + this.nullbit3 + this.nullbit4
+">"; //$non-nls-1$
}
else {
string def = "flowinfo<def:[" + this.definiteinits, //$non-nls-1$
pot = "], pot:[" + this.potentialinits, //$non-nls-1$
nulls = ", null:[" + this.nullbit1 //$non-nls-1$
+ this.nullbit2 + this.nullbit3 + this.nullbit4;
int i, ceil;
for (i = 0, ceil = this.extra[0].length > 3 ?
3 :
this.extra[0].length;
i < ceil; i++) {
def += "," + this.extra[0][i]; //$non-nls-1$
pot += "," + this.extra[1][i]; //$non-nls-1$
nulls += "," + this.extra[2][i] //$non-nls-1$
+ this.extra[3][i] + this.extra[4][i] + this.extra[5][i];
}
if (ceil < this.extra[0].length) {
def += ",..."; //$non-nls-1$
pot += ",..."; //$non-nls-1$
nulls += ",..."; //$non-nls-1$
}
return def + pot
+ "], reachable:" + ((this.tagbits & unreachable) == 0) //$non-nls-1$
+ nulls
+ "]>"; //$non-nls-1$
}
}
else {
if (this.extra == null) {
return "flowinfo<def: " + this.definiteinits //$non-nls-1$
+", pot: " + this.potentialinits  //$non-nls-1$
+ ", reachable:" + ((this.tagbits & unreachable) == 0) //$non-nls-1$
+", no null info>"; //$non-nls-1$
}
else {
string def = "flowinfo<def:[" + this.definiteinits, //$non-nls-1$
pot = "], pot:[" + this.potentialinits; //$non-nls-1$
int i, ceil;
for (i = 0, ceil = this.extra[0].length > 3 ?
3 :
this.extra[0].length;
i < ceil; i++) {
def += "," + this.extra[0][i]; //$non-nls-1$
pot += "," + this.extra[1][i]; //$non-nls-1$
}
if (ceil < this.extra[0].length) {
def += ",..."; //$non-nls-1$
pot += ",..."; //$non-nls-1$
}
return def + pot
+ "], reachable:" + ((this.tagbits & unreachable) == 0) //$non-nls-1$
+ ", no null info>"; //$non-nls-1$
}
}
}

public unconditionalflowinfo unconditionalcopy() {
return (unconditionalflowinfo) copy();
}

public unconditionalflowinfo unconditionalfieldlesscopy() {
// todo (maxime) may consider leveraging null contribution verification as it is done in copy
unconditionalflowinfo copy = new unconditionalflowinfo();
copy.tagbits = this.tagbits;
copy.maxfieldcount = this.maxfieldcount;
int limit = this.maxfieldcount;
if (limit < bitcachesize) {
long mask;
copy.definiteinits = this.definiteinits & (mask = ~((1l << limit)-1));
copy.potentialinits = this.potentialinits & mask;
copy.nullbit1 = this.nullbit1 & mask;
copy.nullbit2 = this.nullbit2 & mask;
copy.nullbit3 = this.nullbit3 & mask;
copy.nullbit4 = this.nullbit4 & mask;
}
copy.nullstatuschangedinassert = this.nullstatuschangedinassert;
// use extra vector
if (this.extra == null) {
return copy; // if vector not yet allocated, then not initialized
}
int vectorindex, length, copystart;
if ((vectorindex = (limit / bitcachesize) - 1) >=
(length = this.extra[0].length)) {
return copy; // not enough room yet
}
long mask;
copy.extra = new long[extralength][];
if ((copystart = vectorindex + 1) < length) {
int copylength = length - copystart;
for (int j = 0; j < extralength; j++) {
system.arraycopy(this.extra[j], copystart,
(copy.extra[j] = new long[length]), copystart,
copylength);
}
}
else if (vectorindex >= 0) {
for (int j = 0; j < extralength; j++) {
copy.extra[j] = new long[length];
}
}
if (vectorindex >= 0) {
mask = ~((1l << (limit % bitcachesize))-1);
for (int j = 0; j < extralength; j++) {
copy.extra[j][vectorindex] =
this.extra[j][vectorindex] & mask;
}
}
return copy;
}

public unconditionalflowinfo unconditionalinits() {
// also see conditional inits, where it requests them to merge
return this;
}

public unconditionalflowinfo unconditionalinitswithoutsideeffect() {
return this;
}

public void markedasnullornonnullinassertexpression(localvariablebinding local) {
int position = local.id + this.maxfieldcount;
int oldlength;
if (this.nullstatuschangedinassert == null) {
this.nullstatuschangedinassert = new int[position + 1];
}
else {
if(position >= (oldlength = this.nullstatuschangedinassert.length)) {
system.arraycopy(this.nullstatuschangedinassert, 0, (this.nullstatuschangedinassert = new int[position + 1]), 0, oldlength);
}
}
this.nullstatuschangedinassert[position] = 1;
}

public boolean ismarkedasnullornonnullinassertexpression(localvariablebinding local) {
int position = local.id + this.maxfieldcount;
if(this.nullstatuschangedinassert == null || position >= this.nullstatuschangedinassert.length) {
return false;
}
if(this.nullstatuschangedinassert[position] == 1) {
return true;
}
return false;
}

/**
* combine the null status changes in assert expressions info
* @@param otherinits
*/
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=303448
private void combinenullstatuschangeinassertinfo(unconditionalflowinfo otherinits) {
if (this.nullstatuschangedinassert != null || otherinits.nullstatuschangedinassert != null) {
int mergedlength, length;
if (this.nullstatuschangedinassert != null) {
if (otherinits.nullstatuschangedinassert != null) {
if(otherinits.nullstatuschangedinassert.length > this.nullstatuschangedinassert.length) {
mergedlength = otherinits.nullstatuschangedinassert.length;
length = this.nullstatuschangedinassert.length;
system.arraycopy(this.nullstatuschangedinassert, 0, (this.nullstatuschangedinassert = new int[mergedlength]), 0, length);
for(int i = 0; i < length; i ++) {
this.nullstatuschangedinassert[i] |= otherinits.nullstatuschangedinassert[i];
}
system.arraycopy(otherinits.nullstatuschangedinassert, length, this.nullstatuschangedinassert, length, mergedlength - length);
} else {
for(int i = 0; i < otherinits.nullstatuschangedinassert.length; i ++) {
this.nullstatuschangedinassert[i] |= otherinits.nullstatuschangedinassert[i];
}
}
}
} else if (otherinits.nullstatuschangedinassert != null) {
this.nullstatuschangedinassert = otherinits.nullstatuschangedinassert;
}
}
}
}

