/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce an exception type reference containing the completion identifier.
* e.g.
*
*	class x {
*    void foo() {
*      try {
*        bar();
*      } catch (ioexc[cursor] e) {
*      }
*    }
*  }
*
*	---> class x {
*         void foo() {
*           try {
*             bar();
*           } catch (<completeonexception:ioexc> e) {
*           }
*         }
*       }
*
* the source range of the completion node denotes the source range
* which should be replaced by the completion.
*/
public class completiononexceptionreference extends completiononsingletypereference {

public completiononexceptionreference(char[] source, long pos) {

super(source, pos);
}

public stringbuffer printexpression(int indent, stringbuffer output) {

return output.append("<completeonexception:").append(this.token).append('>'); //$non-nls-1$
}
}
