/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class argument extends localdeclaration {

// prefix for setter method (to recognize special hiding argument)
private final static char[] set = "set".tochararray(); //$non-nls-1$

public argument(char[] name, long posnom, typereference tr, int modifiers) {

super(name, (int) (posnom >>> 32), (int) posnom);
this.declarationsourceend = (int) posnom;
this.modifiers = modifiers;
this.type = tr;
this.bits |= islocaldeclarationreachable;
}

public void bind(methodscope scope, typebinding typebinding, boolean used) {

// record the resolved type into the type reference
binding existingvariable = scope.getbinding(this.name, binding.variable, this, false /*do not resolve hidden field*/);
if (existingvariable != null && existingvariable.isvalidbinding()){
if (existingvariable instanceof localvariablebinding && this.hiddenvariabledepth == 0) {
scope.problemreporter().redefineargument(this);
} else {
boolean isspecialargument = false;
if (existingvariable instanceof fieldbinding) {
if (scope.isinsideconstructor()) {
isspecialargument = true; // constructor argument
} else {
abstractmethoddeclaration methoddecl = scope.referencemethod();
if (methoddecl != null && charoperation.prefixequals(set, methoddecl.selector)) {
isspecialargument = true; // setter argument
}
}
}
scope.problemreporter().localvariablehiding(this, existingvariable, isspecialargument);
}
}

if (this.binding == null) {
this.binding = new localvariablebinding(this, typebinding, this.modifiers, true);
} else if (!this.binding.type.isvalidbinding()) {
abstractmethoddeclaration methoddecl = scope.referencemethod();
if (methoddecl != null) {
methodbinding methodbinding = methoddecl.binding;
if (methodbinding != null) {
methodbinding.tagbits |= tagbits.hasunresolvedarguments;
}
}
}
scope.addlocalvariable(this.binding);
resolveannotations(scope, this.annotations, this.binding);
//true stand for argument instead of just local
this.binding.declaration = this;
this.binding.useflag = used ? localvariablebinding.used : localvariablebinding.unused;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.abstractvariabledeclaration#getkind()
*/
public int getkind() {
return parameter;
}

public boolean isvarargs() {
return this.type != null &&  (this.type.bits & isvarargs) != 0;
}

public stringbuffer print(int indent, stringbuffer output) {

printindent(indent, output);
printmodifiers(this.modifiers, output);
if (this.annotations != null) printannotations(this.annotations, output);

if (this.type == null) {
output.append("<no type> "); //$non-nls-1$
} else {
this.type.print(0, output).append(' ');
}
return output.append(this.name);
}

public stringbuffer printstatement(int indent, stringbuffer output) {

return print(indent, output).append(';');
}

public typebinding resolveforcatch(blockscope scope) {
// resolution on an argument of a catch clause
// provide the scope with a side effect : insertion of a local
// that represents the argument. the type must be from javathrowable

typebinding exceptiontype = this.type.resolvetype(scope, true /* check bounds*/);
boolean haserror;
if (exceptiontype == null) {
haserror = true;
} else {
haserror = false;
switch(exceptiontype.kind()) {
case binding.parameterized_type :
if (exceptiontype.isboundparameterizedtype()) {
haserror = true;
scope.problemreporter().invalidparameterizedexceptiontype(exceptiontype, this);
// fall thru to create the variable - avoids additional errors because the variable is missing
}
break;
case binding.type_parameter :
scope.problemreporter().invalidtypevariableasexception(exceptiontype, this);
haserror = true;
// fall thru to create the variable - avoids additional errors because the variable is missing
break;
case binding.array_type :
if (((arraybinding) exceptiontype).leafcomponenttype == typebinding.void) {
scope.problemreporter().variabletypecannotbevoidarray(this);
haserror = true;
// fall thru to create the variable - avoids additional errors because the variable is missing
}
break;
}
if (exceptiontype.findsupertypeoriginatingfrom(typeids.t_javalangthrowable, true) == null && exceptiontype.isvalidbinding()) {
scope.problemreporter().cannotthrowtype(this.type, exceptiontype);
haserror = true;
// fall thru to create the variable - avoids additional errors because the variable is missing
}
}
binding existingvariable = scope.getbinding(this.name, binding.variable, this, false /*do not resolve hidden field*/);
if (existingvariable != null && existingvariable.isvalidbinding()){
if (existingvariable instanceof localvariablebinding && this.hiddenvariabledepth == 0) {
scope.problemreporter().redefineargument(this);
} else {
scope.problemreporter().localvariablehiding(this, existingvariable, false);
}
}

this.binding = new localvariablebinding(this, exceptiontype, this.modifiers, false); // argument decl, but local var  (where isargument = false)
resolveannotations(scope, this.annotations, this.binding);

scope.addlocalvariable(this.binding);
this.binding.setconstant(constant.notaconstant);
if (haserror) return null;
return exceptiontype;
}

public void traverse(astvisitor visitor, blockscope scope) {

if (visitor.visit(this, scope)) {
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, scope);
}
if (this.type != null)
this.type.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
public void traverse(astvisitor visitor, classscope scope) {

if (visitor.visit(this, scope)) {
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, scope);
}
if (this.type != null)
this.type.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
