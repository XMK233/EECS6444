/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

//dedicated treatment for the &&
public class and_and_expression extends binaryexpression {

int rightinitstateindex = -1;
int mergedinitstateindex = -1;

public and_and_expression(expression left, expression right, int operator) {
super(left, right, operator);
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {

constant cst = this.left.optimizedbooleanconstant();
boolean isleftoptimizedtrue = cst != constant.notaconstant && cst.booleanvalue() == true;
boolean isleftoptimizedfalse = cst != constant.notaconstant && cst.booleanvalue() == false;

if (isleftoptimizedtrue) {
// true && anything
// need to be careful of scenario:
//  (x && y) && !z, if passing the left info to the right, it would
// be swapped by the !
flowinfo mergedinfo = this.left.analysecode(currentscope, flowcontext, flowinfo)
.unconditionalinits();
mergedinfo = this.right.analysecode(currentscope, flowcontext, mergedinfo);
this.mergedinitstateindex = currentscope.methodscope()
.recordinitializationstates(mergedinfo);
return mergedinfo;
}

flowinfo leftinfo = this.left.analysecode(currentscope, flowcontext, flowinfo);
// need to be careful of scenario:
//  (x && y) && !z, if passing the left info to the right, it would be
// swapped by the !
flowinfo rightinfo = leftinfo.initswhentrue().unconditionalcopy();
this.rightinitstateindex = currentscope.methodscope().recordinitializationstates(rightinfo);

int previousmode = rightinfo.reachmode();
if (isleftoptimizedfalse) {
if ((rightinfo.reachmode() & flowinfo.unreachable) == 0) {
currentscope.problemreporter().fakereachable(this.right);
rightinfo.setreachmode(flowinfo.unreachable);
}
}
rightinfo = this.right.analysecode(currentscope, flowcontext, rightinfo);
flowinfo mergedinfo = flowinfo.conditional(
rightinfo.safeinitswhentrue(),
leftinfo.initswhenfalse().unconditionalinits().mergedwith(
rightinfo.initswhenfalse().setreachmode(previousmode).unconditionalinits()));
// reset after truemergedinfo got extracted
this.mergedinitstateindex = currentscope.methodscope().recordinitializationstates(mergedinfo);
return mergedinfo;
}

/**
* code generation for a binary operation
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {

int pc = codestream.position;
if (this.constant != constant.notaconstant) {
// inlined value
if (valuerequired)
codestream.generateconstant(this.constant, this.implicitconversion);
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
constant cst = this.right.constant;
if (cst != constant.notaconstant) {
// <expr> && true --> <expr>
if (cst.booleanvalue() == true) {
this.left.generatecode(currentscope, codestream, valuerequired);
} else {
// <expr> && false --> false
this.left.generatecode(currentscope, codestream, false);
if (valuerequired) codestream.iconst_0();
}
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
codestream.generateimplicitconversion(this.implicitconversion);
codestream.updatelastrecordedendpc(currentscope, codestream.position);
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}

branchlabel falselabel = new branchlabel(codestream), endlabel;
cst = this.left.optimizedbooleanconstant();
boolean leftisconst = cst != constant.notaconstant;
boolean leftistrue = leftisconst && cst.booleanvalue() == true;

cst = this.right.optimizedbooleanconstant();
boolean rightisconst = cst != constant.notaconstant;
boolean rightistrue = rightisconst && cst.booleanvalue() == true;

generateoperands : {
if (leftisconst) {
this.left.generatecode(currentscope, codestream, false);
if (!leftistrue) {
break generateoperands; // no need to generate right operand
}
} else {
this.left.generateoptimizedboolean(currentscope, codestream, null, falselabel, true);
// need value, e.g. if (a == 1 && ((b = 2) > 0)) {} -> shouldn't initialize 'b' if a!=1
}
if (this.rightinitstateindex != -1) {
codestream.adddefinitelyassignedvariables(currentscope, this.rightinitstateindex);
}
if (rightisconst) {
this.right.generatecode(currentscope, codestream, false);
} else {
this.right.generateoptimizedboolean(currentscope, codestream, null, falselabel, valuerequired);
}
}
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
/*
* improving code gen for such a case: boolean b = i < 0 && false since
* the label has never been used, we have the inlined value on the
* stack.
*/
if (valuerequired) {
if (leftisconst && !leftistrue) {
codestream.iconst_0();
codestream.updatelastrecordedendpc(currentscope, codestream.position);
} else {
if (rightisconst && !rightistrue) {
codestream.iconst_0();
codestream.updatelastrecordedendpc(currentscope, codestream.position);
} else {
codestream.iconst_1();
}
if (falselabel.forwardreferencecount() > 0) {
if ((this.bits & isreturnedvalue) != 0) {
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
falselabel.place();
codestream.iconst_0();
} else {
codestream.goto_(endlabel = new branchlabel(codestream));
codestream.decrstacksize(1);
falselabel.place();
codestream.iconst_0();
endlabel.place();
}
} else {
falselabel.place();
}
}
codestream.generateimplicitconversion(this.implicitconversion);
codestream.updatelastrecordedendpc(currentscope, codestream.position);
} else {
falselabel.place();
}
}

/**
* boolean operator code generation optimized operations are: &&
*/
public void generateoptimizedboolean(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {

if (this.constant != constant.notaconstant) {
super.generateoptimizedboolean(currentscope, codestream, truelabel, falselabel,
valuerequired);
return;
}

// <expr> && true --> <expr>
constant cst = this.right.constant;
if (cst != constant.notaconstant && cst.booleanvalue() == true) {
int pc = codestream.position;
this.left.generateoptimizedboolean(currentscope, codestream, truelabel, falselabel, valuerequired);
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
cst = this.left.optimizedbooleanconstant();
boolean leftisconst = cst != constant.notaconstant;
boolean leftistrue = leftisconst && cst.booleanvalue() == true;

cst = this.right.optimizedbooleanconstant();
boolean rightisconst = cst != constant.notaconstant;
boolean rightistrue = rightisconst && cst.booleanvalue() == true;

// default case
generateoperands : {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
branchlabel internalfalselabel = new branchlabel(codestream);
this.left.generateoptimizedboolean(currentscope, codestream, null, internalfalselabel, !leftisconst);
// need value, e.g. if (a == 1 && ((b = 2) > 0)) {} -> shouldn't initialize 'b' if a!=1
if (leftisconst && !leftistrue) {
internalfalselabel.place();
break generateoperands; // no need to generate right operand
}
if (this.rightinitstateindex != -1) {
codestream
.adddefinitelyassignedvariables(currentscope, this.rightinitstateindex);
}
this.right.generateoptimizedboolean(currentscope, codestream, truelabel, null,
valuerequired && !rightisconst);
if (valuerequired && rightisconst && rightistrue) {
codestream.goto_(truelabel);
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}
internalfalselabel.place();
}
} else {
// implicit falling through the true case
if (truelabel == null) {
this.left.generateoptimizedboolean(currentscope, codestream, null, falselabel, !leftisconst);
// need value, e.g. if (a == 1 && ((b = 2) > 0)) {} -> shouldn't initialize 'b' if a!=1
if (leftisconst && !leftistrue) {
if (valuerequired) codestream.goto_(falselabel);
codestream.updatelastrecordedendpc(currentscope, codestream.position);
break generateoperands; // no need to generate right operand
}
if (this.rightinitstateindex != -1) {
codestream
.adddefinitelyassignedvariables(currentscope, this.rightinitstateindex);
}
this.right.generateoptimizedboolean(currentscope, codestream, null, falselabel, valuerequired && !rightisconst);
if (valuerequired && rightisconst && !rightistrue) {
codestream.goto_(falselabel);
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}
} else {
// no implicit fall through true/false --> should never occur
}
}
}
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
}

public boolean iscompactableoperation() {
return false;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.binaryexpression#resolvetype(org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public typebinding resolvetype(blockscope scope) {
typebinding result = super.resolvetype(scope);
// check whether comparing identical expressions
binding leftdirect = expression.getdirectbinding(this.left);
if (leftdirect != null && leftdirect == expression.getdirectbinding(this.right)) {
if (!(this.right instanceof assignment))
scope.problemreporter().comparingidenticalexpressions(this);
}
return result;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
this.left.traverse(visitor, scope);
this.right.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
