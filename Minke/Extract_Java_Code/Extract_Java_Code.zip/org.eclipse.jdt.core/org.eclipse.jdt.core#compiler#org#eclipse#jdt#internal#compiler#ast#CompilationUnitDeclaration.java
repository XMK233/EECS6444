/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     stephan herrmann  - contribution for bug 295551
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import java.util.arrays;
import java.util.comparator;

import org.eclipse.jdt.core.compiler.categorizedproblem;
import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfile;
import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.impl.irritantset;
import org.eclipse.jdt.internal.compiler.impl.referencecontext;
import org.eclipse.jdt.internal.compiler.lookup.compilationunitscope;
import org.eclipse.jdt.internal.compiler.lookup.importbinding;
import org.eclipse.jdt.internal.compiler.lookup.localtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.typeconstants;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.parser.nlstag;
import org.eclipse.jdt.internal.compiler.problem.abortcompilationunit;
import org.eclipse.jdt.internal.compiler.problem.abortmethod;
import org.eclipse.jdt.internal.compiler.problem.aborttype;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;
import org.eclipse.jdt.internal.compiler.util.hashsetofint;

public class compilationunitdeclaration extends astnode implements problemseverities, referencecontext {

private static final comparator string_literal_comparator = new comparator() {
public int compare(object o1, object o2) {
stringliteral literal1 = (stringliteral) o1;
stringliteral literal2 = (stringliteral) o2;
return literal1.sourcestart - literal2.sourcestart;
}
};
private static final int string_literals_increment = 10;

public importreference currentpackage;
public importreference[] imports;
public typedeclaration[] types;
public int[][] comments;

public boolean ignorefurtherinvestigation = false; // once pointless to investigate due to errors
public boolean ignoremethodbodies = false;
public compilationunitscope scope;
public problemreporter problemreporter;
public compilationresult compilationresult;

public localtypebinding[] localtypes;
public int localtypecount = 0;

public boolean ispropagatinginnerclassemulation;

public javadoc javadoc; // 1.5 addition for package-info.java

public nlstag[] nlstags;
private stringliteral[] stringliterals;
private int stringliteralsptr;
private hashsetofint stringliteralsstart;

irritantset[] suppresswarningirritants;  // irritant for suppressed warnings
annotation[] suppresswarningannotations;
long[] suppresswarningscopepositions; // (start << 32) + end
int suppresswarningscount;

public compilationunitdeclaration(problemreporter problemreporter, compilationresult compilationresult, 	int sourcelength) {
this.problemreporter = problemreporter;
this.compilationresult = compilationresult;
//by definition of a compilation unit....
this.sourcestart = 0;
this.sourceend = sourcelength - 1;
}

/*
*	we cause the compilation task to abort to a given extent.
*/
public void abort(int abortlevel, categorizedproblem problem) {
switch (abortlevel) {
case aborttype :
throw new aborttype(this.compilationresult, problem);
case abortmethod :
throw new abortmethod(this.compilationresult, problem);
default :
throw new abortcompilationunit(this.compilationresult, problem);
}
}

/*
* dispatch code analysis and request saturation of inner emulation
*/
public void analysecode() {
if (this.ignorefurtherinvestigation)
return;
try {
if (this.types != null) {
for (int i = 0, count = this.types.length; i < count; i++) {
this.types[i].analysecode(this.scope);
}
}
// request inner emulation propagation
propagateinneremulationforalllocaltypes();
} catch (abortcompilationunit e) {
this.ignorefurtherinvestigation = true;
return;
}
}

/*
* when unit result is about to be accepted, removed back pointers
* to compiler structures.
*/
public void cleanup() {
if (this.types != null) {
for (int i = 0, max = this.types.length; i < max; i++) {
cleanup(this.types[i]);
}
for (int i = 0, max = this.localtypecount; i < max; i++) {
localtypebinding localtype = this.localtypes[i];
// null out the type's scope backpointers
localtype.scope = null; // local members are already in the list
localtype.enclosingcase = null;
}
}

this.compilationresult.recoveryscannerdata = null; // recovery is already done

classfile[] classfiles = this.compilationresult.getclassfiles();
for (int i = 0, max = classfiles.length; i < max; i++) {
// clear the classfile back pointer to the bindings
classfile classfile = classfiles[i];
// null out the classfile backpointer to a type binding
classfile.referencebinding = null;
classfile.innerclassesbindings = null;
classfile.missingtypes = null;
classfile.visitedtypes = null;
}

this.suppresswarningannotations = null;
}

private void cleanup(typedeclaration type) {
if (type.membertypes != null) {
for (int i = 0, max = type.membertypes.length; i < max; i++){
cleanup(type.membertypes[i]);
}
}
if (type.binding != null && type.binding.isannotationtype())
this.compilationresult.hasannotations = true;
if (type.binding != null) {
// null out the type's scope backpointers
type.binding.scope = null;
}
}

public void checkunusedimports(){
if (this.scope.imports != null){
for (int i = 0, max = this.scope.imports.length; i < max; i++){
importbinding importbinding = this.scope.imports[i];
importreference importreference = importbinding.reference;
if (importreference != null && ((importreference.bits & astnode.used) == 0)){
this.scope.problemreporter().unusedimport(importreference);
}
}
}
}

public compilationresult compilationresult() {
return this.compilationresult;
}

public void createpackageinfotype() {
typedeclaration declaration = new typedeclaration(this.compilationresult);
declaration.name = typeconstants.package_info_name;
declaration.modifiers = classfileconstants.accdefault | classfileconstants.accinterface;
declaration.javadoc = this.javadoc;
this.types[0] = declaration; // assumes the first slot is meant for this type
}

/*
* finds the matching type amoung this compilation unit types.
* returns null if no type with this name is found.
* the type name is a compound name
* e.g. if we're looking for x.a.b then a type name would be {x, a, b}
*/
public typedeclaration declarationoftype(char[][] typename) {
for (int i = 0; i < this.types.length; i++) {
typedeclaration typedecl = this.types[i].declarationoftype(typename);
if (typedecl != null) {
return typedecl;
}
}
return null;
}

public void finalizeproblems() {
if (this.suppresswarningscount == 0) return;
int removed = 0;
categorizedproblem[] problems = this.compilationresult.problems;
int problemcount = this.compilationresult.problemcount;
irritantset[] foundirritants = new irritantset[this.suppresswarningscount];
compileroptions options = this.scope.compileroptions();
boolean hasmandatoryerrors = false;
nextproblem: for (int iproblem = 0, length = problemcount; iproblem < length; iproblem++) {
categorizedproblem problem = problems[iproblem];
int problemid = problem.getid();
int irritant = problemreporter.getirritant(problemid);
if (problem.iserror()) {
if (irritant == 0) {
// tolerate unused warning tokens when mandatory errors
hasmandatoryerrors = true;
continue;
}
if (!options.suppressoptionalerrors) {
continue;
}
}
int start = problem.getsourcestart();
int end = problem.getsourceend();
nextsuppress: for (int isuppress = 0, suppresscount = this.suppresswarningscount; isuppress < suppresscount; isuppress++) {
long position = this.suppresswarningscopepositions[isuppress];
int startsuppress = (int) (position >>> 32);
int endsuppress = (int) position;
if (start < startsuppress) continue nextsuppress;
if (end > endsuppress) continue nextsuppress;
if (!this.suppresswarningirritants[isuppress].isset(irritant))
continue nextsuppress;
// discard suppressed warning
removed++;
problems[iproblem] = null;
if (this.compilationresult.problemsmap != null) this.compilationresult.problemsmap.remove(problem);
if (this.compilationresult.firsterrors != null) this.compilationresult.firsterrors.remove(problem);
if (foundirritants[isuppress] == null){
foundirritants[isuppress] = new irritantset(irritant);
} else {
foundirritants[isuppress].set(irritant);
}
continue nextproblem;
}
}
// compact remaining problems
if (removed > 0) {
for (int i = 0, index = 0; i < problemcount; i++) {
categorizedproblem problem;
if ((problem = problems[i]) != null) {
if (i > index) {
problems[index++] = problem;
} else {
index++;
}
}
}
this.compilationresult.problemcount -= removed;
}
// flag suppresswarnings which had no effect (only if no (mandatory) error got detected within unit
if (!hasmandatoryerrors) {
int severity = options.getseverity(compileroptions.unusedwarningtoken);
if (severity != problemseverities.ignore) {
boolean unusedwarningtokeniswarning = (severity & problemseverities.error) == 0;
for (int isuppress = 0, suppresscount = this.suppresswarningscount; isuppress < suppresscount; isuppress++) {
annotation annotation = this.suppresswarningannotations[isuppress];
if (annotation == null) continue; // implicit annotation
irritantset irritants = this.suppresswarningirritants[isuppress];
if (unusedwarningtokeniswarning && irritants.areallset()) continue; // @@suppresswarnings("all") also suppresses unused warning token
if (irritants != foundirritants[isuppress]) { // mismatch, some warning tokens were unused
membervaluepair[] pairs = annotation.membervaluepairs();
pairloop: for (int ipair = 0, paircount = pairs.length; ipair < paircount; ipair++) {
membervaluepair pair = pairs[ipair];
if (charoperation.equals(pair.name, typeconstants.value)) {
expression value = pair.value;
if (value instanceof arrayinitializer) {
arrayinitializer initializer = (arrayinitializer) value;
expression[] inits = initializer.expressions;
if (inits != null) {
for (int itoken = 0, tokencount = inits.length; itoken < tokencount; itoken++) {
constant cst = inits[itoken].constant;
if (cst != constant.notaconstant && cst.typeid() == typeids.t_javalangstring) {
irritantset tokenirritants = compileroptions.warningtokentoirritants(cst.stringvalue());
if (tokenirritants != null
&& !tokenirritants.areallset() // no complaint against @@suppresswarnings("all")
&& options.isanyenabled(tokenirritants) // if irritant is effectively enabled
&& (foundirritants[isuppress] == null || !foundirritants[isuppress].isanyset(tokenirritants))) { // if irritant had no matching problem
if (unusedwarningtokeniswarning) {
int start = value.sourcestart, end = value.sourceend;
nextsuppress: for (int jsuppress = isuppress - 1; jsuppress >= 0; jsuppress--) {
long position = this.suppresswarningscopepositions[jsuppress];
int startsuppress = (int) (position >>> 32);
int endsuppress = (int) position;
if (start < startsuppress) continue nextsuppress;
if (end > endsuppress) continue nextsuppress;
if (this.suppresswarningirritants[jsuppress].areallset()) break pairloop; // suppress all?
}
}
this.scope.problemreporter().unusedwarningtoken(inits[itoken]);
}
}
}
}
} else {
constant cst = value.constant;
if (cst != constant.notaconstant && cst.typeid() == t_javalangstring) {
irritantset tokenirritants = compileroptions.warningtokentoirritants(cst.stringvalue());
if (tokenirritants != null
&& !tokenirritants.areallset() // no complaint against @@suppresswarnings("all")
&& options.isanyenabled(tokenirritants) // if irritant is effectevely enabled
&& (foundirritants[isuppress] == null || !foundirritants[isuppress].isanyset(tokenirritants))) { // if irritant had no matching problem
if (unusedwarningtokeniswarning) {
int start = value.sourcestart, end = value.sourceend;
nextsuppress: for (int jsuppress = isuppress - 1; jsuppress >= 0; jsuppress--) {
long position = this.suppresswarningscopepositions[jsuppress];
int startsuppress = (int) (position >>> 32);
int endsuppress = (int) position;
if (start < startsuppress) continue nextsuppress;
if (end > endsuppress) continue nextsuppress;
if (this.suppresswarningirritants[jsuppress].areallset()) break pairloop; // suppress all?
}
}
this.scope.problemreporter().unusedwarningtoken(value);
}
}
}
break pairloop;
}
}
}
}
}
}
}

/**
* bytecode generation
*/
public void generatecode() {
if (this.ignorefurtherinvestigation) {
if (this.types != null) {
for (int i = 0, count = this.types.length; i < count; i++) {
this.types[i].ignorefurtherinvestigation = true;
// propagate the flag to request problem type creation
this.types[i].generatecode(this.scope);
}
}
return;
}
try {
if (this.types != null) {
for (int i = 0, count = this.types.length; i < count; i++)
this.types[i].generatecode(this.scope);
}
} catch (abortcompilationunit e) {
// ignore
}
}

public char[] getfilename() {
return this.compilationresult.getfilename();
}

public char[] getmaintypename() {
if (this.compilationresult.compilationunit == null) {
char[] filename = this.compilationresult.getfilename();

int start = charoperation.lastindexof('/', filename) + 1;
if (start == 0 || start < charoperation.lastindexof('\\', filename))
start = charoperation.lastindexof('\\', filename) + 1;

int end = charoperation.lastindexof('.', filename);
if (end == -1)
end = filename.length;

return charoperation.subarray(filename, start, end);
} else {
return this.compilationresult.compilationunit.getmaintypename();
}
}

public boolean isempty() {
return (this.currentpackage == null) && (this.imports == null) && (this.types == null);
}

public boolean ispackageinfo() {
return charoperation.equals(getmaintypename(), typeconstants.package_info_name);
}

public boolean haserrors() {
return this.ignorefurtherinvestigation;
}

public stringbuffer print(int indent, stringbuffer output) {
if (this.currentpackage != null) {
printindent(indent, output).append("package "); //$non-nls-1$
this.currentpackage.print(0, output, false).append(";\n"); //$non-nls-1$
}
if (this.imports != null)
for (int i = 0; i < this.imports.length; i++) {
printindent(indent, output).append("import "); //$non-nls-1$
importreference currentimport = this.imports[i];
if (currentimport.isstatic()) {
output.append("static "); //$non-nls-1$
}
currentimport.print(0, output).append(";\n"); //$non-nls-1$
}

if (this.types != null) {
for (int i = 0; i < this.types.length; i++) {
this.types[i].print(indent, output).append("\n"); //$non-nls-1$
}
}
return output;
}

/*
* force inner local types to update their innerclass emulation
*/
public void propagateinneremulationforalllocaltypes() {
this.ispropagatinginnerclassemulation = true;
for (int i = 0, max = this.localtypecount; i < max; i++) {
localtypebinding localtype = this.localtypes[i];
// only propagate for reachable local types
if ((localtype.scope.referencetype().bits & isreachable) != 0) {
localtype.updateinneremulationdependents();
}
}
}

public void recordstringliteral(stringliteral literal, boolean fromrecovery) {
if (this.stringliteralsstart != null) {
if (this.stringliteralsstart.contains(literal.sourcestart)) return;
this.stringliteralsstart.add(literal.sourcestart);
} else if (fromrecovery) {
this.stringliteralsstart = new hashsetofint(this.stringliteralsptr + string_literals_increment);
for (int i = 0; i < this.stringliteralsptr; i++) {
this.stringliteralsstart.add(this.stringliterals[i].sourcestart);
}

if (this.stringliteralsstart.contains(literal.sourcestart)) return;
this.stringliteralsstart.add(literal.sourcestart);
}

if (this.stringliterals == null) {
this.stringliterals = new stringliteral[string_literals_increment];
this.stringliteralsptr = 0;
} else {
int stacklength = this.stringliterals.length;
if (this.stringliteralsptr == stacklength) {
system.arraycopy(
this.stringliterals,
0,
this.stringliterals = new stringliteral[stacklength + string_literals_increment],
0,
stacklength);
}
}
this.stringliterals[this.stringliteralsptr++] = literal;
}

public void recordsuppresswarnings(irritantset irritants, annotation annotation, int scopestart, int scopeend) {
if (this.suppresswarningirritants == null) {
this.suppresswarningirritants = new irritantset[3];
this.suppresswarningannotations = new annotation[3];
this.suppresswarningscopepositions = new long[3];
} else if (this.suppresswarningirritants.length == this.suppresswarningscount) {
system.arraycopy(this.suppresswarningirritants, 0,this.suppresswarningirritants = new irritantset[2*this.suppresswarningscount], 0, this.suppresswarningscount);
system.arraycopy(this.suppresswarningannotations, 0,this.suppresswarningannotations = new annotation[2*this.suppresswarningscount], 0, this.suppresswarningscount);
system.arraycopy(this.suppresswarningscopepositions, 0,this.suppresswarningscopepositions = new long[2*this.suppresswarningscount], 0, this.suppresswarningscount);
}
final long scopepositions = ((long)scopestart<<32) + scopeend;
for (int i = 0, max = this.suppresswarningscount; i < max; i++) {
if (this.suppresswarningannotations[i] == annotation
&& this.suppresswarningscopepositions[i] == scopepositions
&& this.suppresswarningirritants[i].hassameirritants(irritants)) {
// annotation data already recorded
return;
}
}
this.suppresswarningirritants[this.suppresswarningscount] = irritants;
this.suppresswarningannotations[this.suppresswarningscount] = annotation;
this.suppresswarningscopepositions[this.suppresswarningscount++] = scopepositions;
}

/*
* keep track of all local types, so as to update their innerclass
* emulation later on.
*/
public void record(localtypebinding localtype) {
if (this.localtypecount == 0) {
this.localtypes = new localtypebinding[5];
} else if (this.localtypecount == this.localtypes.length) {
system.arraycopy(this.localtypes, 0, (this.localtypes = new localtypebinding[this.localtypecount * 2]), 0, this.localtypecount);
}
this.localtypes[this.localtypecount++] = localtype;
}

public void resolve() {
int startingtypeindex = 0;
boolean ispackageinfo = ispackageinfo();
if (this.types != null && ispackageinfo) {
// resolve synthetic type declaration
final typedeclaration synthetictypedeclaration = this.types[0];
// set empty javadoc to avoid missing warning (see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=95286)
if (synthetictypedeclaration.javadoc == null) {
synthetictypedeclaration.javadoc = new javadoc(synthetictypedeclaration.declarationsourcestart, synthetictypedeclaration.declarationsourcestart);
}
synthetictypedeclaration.resolve(this.scope);
/*
* resolve javadoc package if any, skip this step if we don't have a valid scope due to an earlier error (bug 252555)
* we do it now as the javadoc in the fake type won't be resolved. the peculiar usage of methodscope to resolve the
* package level javadoc is because the cu level resolve method	is a nop to mimic javadoc's behavior and can't be used
* as such.
*/
if (this.javadoc != null && synthetictypedeclaration.staticinitializerscope != null) {
this.javadoc.resolve(synthetictypedeclaration.staticinitializerscope);
}
startingtypeindex = 1;
} else {
// resolve compilation unit javadoc package if any
if (this.javadoc != null) {
this.javadoc.resolve(this.scope);
}
}
if (this.currentpackage != null && this.currentpackage.annotations != null && !ispackageinfo) {
this.scope.problemreporter().invalidfilenameforpackageannotations(this.currentpackage.annotations[0]);
}
try {
if (this.types != null) {
for (int i = startingtypeindex, count = this.types.length; i < count; i++) {
this.types[i].resolve(this.scope);
}
}
if (!this.compilationresult.haserrors()) checkunusedimports();
reportnlsproblems();
} catch (abortcompilationunit e) {
this.ignorefurtherinvestigation = true;
return;
}
}

private void reportnlsproblems() {
if (this.nlstags != null || this.stringliterals != null) {
final int stringliteralslength = this.stringliteralsptr;
final int nlstagslength = this.nlstags == null ? 0 : this.nlstags.length;
if (stringliteralslength == 0) {
if (nlstagslength != 0) {
for (int i = 0; i < nlstagslength; i++) {
nlstag tag = this.nlstags[i];
if (tag != null) {
this.scope.problemreporter().unnecessarynlstags(tag.start, tag.end);
}
}
}
} else if (nlstagslength == 0) {
// resize string literals
if (this.stringliterals.length != stringliteralslength) {
system.arraycopy(this.stringliterals, 0, (this.stringliterals = new stringliteral[stringliteralslength]), 0, stringliteralslength);
}
arrays.sort(this.stringliterals, string_literal_comparator);
for (int i = 0; i < stringliteralslength; i++) {
this.scope.problemreporter().nonexternalizedstringliteral(this.stringliterals[i]);
}
} else {
// need to iterate both arrays to find non matching elements
if (this.stringliterals.length != stringliteralslength) {
system.arraycopy(this.stringliterals, 0, (this.stringliterals = new stringliteral[stringliteralslength]), 0, stringliteralslength);
}
arrays.sort(this.stringliterals, string_literal_comparator);
int indexinline = 1;
int lastlinenumber = -1;
stringliteral literal = null;
int index = 0;
int i = 0;
stringliteralsloop: for (; i < stringliteralslength; i++) {
literal = this.stringliterals[i];
final int literallinenumber = literal.linenumber;
if (lastlinenumber != literallinenumber) {
indexinline = 1;
lastlinenumber = literallinenumber;
} else {
indexinline++;
}
if (index < nlstagslength) {
nlstagsloop: for (; index < nlstagslength; index++) {
nlstag tag = this.nlstags[index];
if (tag == null) continue nlstagsloop;
int taglinenumber = tag.linenumber;
if (literallinenumber < taglinenumber) {
this.scope.problemreporter().nonexternalizedstringliteral(literal);
continue stringliteralsloop;
} else if (literallinenumber == taglinenumber) {
if (tag.index == indexinline) {
this.nlstags[index] = null;
index++;
continue stringliteralsloop;
} else {
nlstagsloop2: for (int index2 = index + 1; index2 < nlstagslength; index2++) {
nlstag tag2 = this.nlstags[index2];
if (tag2 == null) continue nlstagsloop2;
int taglinenumber2 = tag2.linenumber;
if (literallinenumber == taglinenumber2) {
if (tag2.index == indexinline) {
this.nlstags[index2] = null;
continue stringliteralsloop;
} else {
continue nlstagsloop2;
}
} else {
this.scope.problemreporter().nonexternalizedstringliteral(literal);
continue stringliteralsloop;
}
}
this.scope.problemreporter().nonexternalizedstringliteral(literal);
continue stringliteralsloop;
}
} else {
this.scope.problemreporter().unnecessarynlstags(tag.start, tag.end);
continue nlstagsloop;
}
}
}
// all nls tags have been processed, so remaining string literals are not externalized
break stringliteralsloop;
}
for (; i < stringliteralslength; i++) {
this.scope.problemreporter().nonexternalizedstringliteral(this.stringliterals[i]);
}
if (index < nlstagslength) {
for (; index < nlstagslength; index++) {
nlstag tag = this.nlstags[index];
if (tag != null) {
this.scope.problemreporter().unnecessarynlstags(tag.start, tag.end);
}
}
}
}
}
}

public void tagashavingerrors() {
this.ignorefurtherinvestigation = true;
}

public void traverse(astvisitor visitor, compilationunitscope unitscope) {
if (this.ignorefurtherinvestigation)
return;
try {
if (visitor.visit(this, this.scope)) {
if (this.types != null && ispackageinfo()) {
// resolve synthetic type declaration
final typedeclaration synthetictypedeclaration = this.types[0];
// resolve javadoc package if any
final methodscope methodscope = synthetictypedeclaration.staticinitializerscope;
// don't traverse in null scope and invite trouble a la bug 252555.
if (this.javadoc != null && methodscope != null) {
this.javadoc.traverse(visitor, methodscope);
}
// don't traverse in null scope and invite trouble a la bug 252555.
if (this.currentpackage != null && methodscope != null) {
final annotation[] annotations = this.currentpackage.annotations;
if (annotations != null) {
int annotationslength = annotations.length;
for (int i = 0; i < annotationslength; i++) {
annotations[i].traverse(visitor, methodscope);
}
}
}
}
if (this.currentpackage != null) {
this.currentpackage.traverse(visitor, this.scope);
}
if (this.imports != null) {
int importlength = this.imports.length;
for (int i = 0; i < importlength; i++) {
this.imports[i].traverse(visitor, this.scope);
}
}
if (this.types != null) {
int typeslength = this.types.length;
for (int i = 0; i < typeslength; i++) {
this.types[i].traverse(visitor, this.scope);
}
}
}
visitor.endvisit(this, this.scope);
} catch (abortcompilationunit e) {
// ignore
}
}
}
