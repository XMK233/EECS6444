package org.eclipse.jdt.internal.codeassist;

/*
* (c) copyright ibm corp. 2000, 2001.
* all rights reserved.
*/
import org.eclipse.jdt.internal.compiler.*;

/**
* a completion requestor accepts results as they are computed and is aware
* of source positions to complete the various different results.
*/
public interface icompletionrequestor {

/**
* code assist notification of a class completion.
*
* @@return void - nothing is answered back to code assist engine
*
* @@param packagename char[] - declaring package name of the class.
* @@param classname char[] - name of the class.
* @@param completionname char[] - the completion for the class.
*   can include ';' for imported classes.
* @@param modifiers int - the modifiers of the class.
*	 	@@see com.ibm.compiler.java.ast.modifiers
* @@param completionstart int - the start position of insertion of the name of the class.
* @@param completionend int - the end position of insertion of the name of the class.
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*/
void acceptclass(
char[] packagename,
char[] classname,
char[] completionname,
int modifiers,
int completionstart,
int completionend);
/**
* code assist notification of a compilation error detected during completion.
*
*  @@return void - nothing is answered back to code assist engine
*
*  @@param error com.ibm.compiler.java.api.problem.iproblem
*      only problems which are categorized as errors are notified to the requestor,
*		warnings are silently ignored.
*		in case an error got signaled, no other completions might be available,
*		therefore the problem message should be presented to the user.
*		the source positions of the problem are related to the source where it was
*		detected (might be in another compilation unit, if it was indirectly requested
*		during the code assist process).
*      note: the problem knows its originating file name.
*/
void accepterror(iproblem error);
/**
* code assist notification of a field completion.
*
* @@return void - nothing is answered back to code assist engine
*
* @@param declaringtypepackagename char[] - name of the package in which the type that contains this field is declared.
* @@param declaringtypename char[] - name of the type declaring this new field.
* @@param name char[] - name of the field.
* @@param typepackagename char[] - name of the package in which the type of this field is declared.
* @@param typename char[] - name of the type of this field.
* @@param completionname char[] - the completion for the field.
* @@param modifiers int - the modifiers of this field.
* @@param completionstart int - the start position of insertion of the name of this field.
* @@param completionend int - the end position of insertion of the name of this field.
* @@see com.ibm.compiler.java.ast.modifiers
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    base types are in the form "int" or "boolean".
*    array types are in the qualified form "m[]" or "int[]".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*/
void acceptfield(
char[] declaringtypepackagename,
char[] declaringtypename,
char[] name,
char[] typepackagename,
char[] typename,
char[] completionname,
int modifiers,
int completionstart,
int completionend);
/**
* code assist notification of an interface completion.
*
* @@return void - nothing is answered back to code assist engine
*
* @@param packagename char[] - declaring package name of the interface.
* @@param classname char[] - name of the interface.
* @@param completionname char[] - the completion for the interface.
*   can include ';' for imported interfaces.
* @@param modifiers int - the modifiers of the interface.
*	 	@@see com.ibm.compiler.java.ast.modifiers
* @@param completionstart int - the start position of insertion of the name of the interface.
* @@param completionend int - the end position of insertion of the name of the interface.
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*/
void acceptinterface(
char[] packagename,
char[] interfacename,
char[] completionname,
int modifiers,
int completionstart,
int completionend);
/**
* code assist notification of a keyword completion.
*
* @@return void - nothing is answered back to code assist engine
*
* @@param keywordname char[] - the keyword source.
* @@param completionstart int - the start position of insertion of the name of this keyword.
* @@param completionend int - the end position of insertion of the name of this keyword.
*/
void acceptkeyword(char[] keywordname, int completionstart, int completionend);
/**
* code assist notification of a label completion.
*
* @@return void - nothing is answered back to code assist engine
*
* @@param labelname char[] - the label source.
* @@param completionstart int - the start position of insertion of the name of this label.
* @@param completionend int - the end position of insertion of the name of this label.
*/
void acceptlabel(char[] labelname, int completionstart, int completionend);
/**
* code assist notification of a local variable completion.
*
* @@return void - nothing is answered back to code assist engine
*
* @@param name char[] - name of the new local variable.
* @@param typepackagename char[] - name of the package in which the type of this new local variable is declared.
* @@param typename char[] - name of the type of this new local variable.
* @@param modifiers int - the modifiers of this new local variable.
* @@param completionstart int - the start position of insertion of the name of this new local variable.
* @@param completionend int - the end position of insertion of the name of this new local variable.
* @@see com.ibm.compiler.java.ast.modifiers
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    base types are in the form "int" or "boolean".
*    array types are in the qualified form "m[]" or "int[]".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*/
void acceptlocalvariable(
char[] name,
char[] typepackagename,
char[] typename,
int modifiers,
int completionstart,
int completionend);
/**
* code assist notification of a method completion.
*
* @@return void - nothing is answered back to code assist engine
*
* @@param declaringtypepackagename char[] - name of the package in which the type that contains this new method is declared.
* @@param declaringtypename char[] - name of the type declaring this new method.
* @@param selector char[] - name of the new method.
* @@param parameterpackagenames char[][] -  names of the packages in which the parameter types are declared.
*    should contain as many elements as parametertypenames.
* @@param parametertypenames char[][] - names of the parameters types.
*    should contain as many elements as parameterpackagenames.
* @@param parameternames char[][] - names of the parameters.
*    should contain as many elements as parameterpackagenames.
* @@param returntypepackagename char[] - name of the package in which the return type is declared.
* @@param returntypename char[] - name of the return type of this new method, should be null for a constructor.
* @@param completionname char[] - the completion for the method.
*   can include zero, one or two brackets. if the closing bracket is included, then the cursor should be placed before it.
* @@param modifiers int - the modifiers of this new method.
* @@param completionstart int - the start position of insertion of the name of this new method.
* @@param completionend int - the end position of insertion of the name of this new method.
* @@see com.ibm.compiler.java.ast.modifiers
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    base types are in the form "int" or "boolean".
*    array types are in the qualified form "m[]" or "int[]".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*
* note: parameter names can be retrieved from the source model after the user selects a specific method.
*/
void acceptmethod(
char[] declaringtypepackagename,
char[] declaringtypename,
char[] selector,
char[][] parameterpackagenames,
char[][] parametertypenames,
char[][] parameternames,
char[] returntypepackagename,
char[] returntypename,
char[] completionname,
int modifiers,
int completionstart,
int completionend);

void acceptmethoddeclaration(
char[] declaringtypepackagename,
char[] declaringtypename,
char[] selector,
char[][] parameterpackagenames,
char[][] parametertypenames,
char[][] parameternames,
char[] returntypepackagename,
char[] returntypename,
char[] completionname,
int modifiers,
int completionstart,
int completionend);
/**
* code assist notification of a modifier completion.
*
* @@return void - nothing is answered back to code assist engine
*
* @@param modifiername char[] - the new modifier.
* @@param completionstart int - the start position of insertion of the name of this new modifier.
* @@param completionend int - the end position of insertion of the name of this new modifier.
*/
void acceptmodifier(
char[] modifiername,
int completionstart,
int completionend);

/**
* code assist notification of a package completion.
*
* @@return void - nothing is answered back to code assist engine
*
* @@param packagename char[] - the package name.
* @@param completionname char[] - the completion for the package.
*   can include '.*;' for imports.
* @@param completionstart int - the start position of insertion of the name of this new package.
* @@param completionend int - the end position of insertion of the name of this new package.
*
* note - all package names are presented in their readable form:
*    package names are in the form "a.b.c".
*    the default package is represented by an empty array.
*/
void acceptpackage(
char[] packagename,
char[] completionname,
int completionstart,
int completionend);
/**
* code assist notification of a type completion.
*
* @@return void - nothing is answered back to code assist engine
*
* @@param packagename char[] - declaring package name of the type.
* @@param typename char[] - name of the type.
* @@param completionname char[] - the completion for the type.
*   can include ';' for imported types.
* @@param completionstart int - the start position of insertion of the name of the type.
* @@param completionend int - the end position of insertion of the name of the type.
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*/
void accepttype(
char[] packagename,
char[] typename,
char[] completionname,
int completionstart,
int completionend);

/**
* code assist notification of a variable name completion.
*
* @@return void - nothing is answered back to code assist engine
*
* @@param typepackagename char[] - name of the package in which the type of this variable is declared.
* @@param typename char[] - name of the type of this variable.
* @@param name char[] - name of the variable.
* @@param completionname char[] - the completion for the variable.
* @@param completionstart int - the start position of insertion of the name of this variable.
* @@param completionend int - the end position of insertion of the name of this variable.
* @@see com.ibm.compiler.java.ast.modifiers
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    base types are in the form "int" or "boolean".
*    array types are in the qualified form "m[]" or "int[]".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*/
void acceptvariablename(
char[] typepackagename,
char[] typename,
char[] name,
char[] completionname,
int completionstart,
int completionend);
}

