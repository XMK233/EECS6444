/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.expression;
import org.eclipse.jdt.internal.compiler.ast.reference;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.lookup.variablebinding;

/**
* reflects the context of code analysis, keeping track of enclosing
*	try statements, exception handlers, etc...
*/
public class finallyflowcontext extends flowcontext {

reference[] finalassignments;
variablebinding[] finalvariables;
int assigncount;

localvariablebinding[] nulllocals;
expression[] nullreferences;
int[] nullchecktypes;
int nullcount;

public finallyflowcontext(flowcontext parent, astnode associatednode) {
super(parent, associatednode);
}

/**
* given some contextual initialization info (derived from a try block or a catch block), this
* code will check that the subroutine context does not also initialize a final variable potentially set
* redundantly.
*/
public void complainondeferredchecks(flowinfo flowinfo, blockscope scope) {

// check redundant final assignments
for (int i = 0; i < this.assigncount; i++) {
variablebinding variable = this.finalvariables[i];
if (variable == null) continue;

boolean complained = false; // remember if have complained on this final assignment
if (variable instanceof fieldbinding) {
// final field
if (flowinfo.ispotentiallyassigned((fieldbinding)variable)) {
complained = true;
scope.problemreporter().duplicateinitializationofblankfinalfield((fieldbinding)variable, this.finalassignments[i]);
}
} else {
// final local variable
if (flowinfo.ispotentiallyassigned((localvariablebinding) variable)) {
complained = true;
scope.problemreporter().duplicateinitializationoffinallocal(
(localvariablebinding) variable,
this.finalassignments[i]);
}
}
// any reference reported at this level is removed from the parent context
// where it could also be reported again
if (complained) {
flowcontext currentcontext = this.parent;
while (currentcontext != null) {
//if (currentcontext.issubroutine()) {
currentcontext.removefinalassignmentifany(this.finalassignments[i]);
//}
currentcontext = currentcontext.parent;
}
}
}

// check inconsistent null checks
if ((this.tagbits & flowcontext.defer_null_diagnostic) != 0) { // within an enclosing loop, be conservative
for (int i = 0; i < this.nullcount; i++) {
this.parent.recordusingnullreference(scope, this.nulllocals[i],
this.nullreferences[i],	this.nullchecktypes[i], flowinfo);
}
}
else { // no enclosing loop, be as precise as possible right now
for (int i = 0; i < this.nullcount; i++) {
expression expression = this.nullreferences[i];
// final local variable
localvariablebinding local = this.nulllocals[i];
switch (this.nullchecktypes[i]) {
case can_only_null_non_null | in_comparison_null:
case can_only_null_non_null | in_comparison_non_null:
if (flowinfo.isdefinitelynonnull(local)) {
if (this.nullchecktypes[i] == (can_only_null_non_null | in_comparison_non_null)) {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnonnull(local, expression);
}
} else {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenonnullcomparedtonull(local, expression);
}
}
continue;
}
//$fall-through$
case can_only_null | in_comparison_null:
case can_only_null | in_comparison_non_null:
case can_only_null | in_assignment:
case can_only_null | in_instanceof:
if (flowinfo.isdefinitelynull(local)) {
switch(this.nullchecktypes[i] & context_mask) {
case flowcontext.in_comparison_null:
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, expression);
continue;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnull(local, expression);
}
continue;
case flowcontext.in_comparison_non_null:
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, expression);
continue;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenullcomparedtononnull(local, expression);
}
continue;
case flowcontext.in_assignment:
scope.problemreporter().localvariableredundantnullassignment(local, expression);
continue;
case flowcontext.in_instanceof:
scope.problemreporter().localvariablenullinstanceof(local, expression);
continue;
}
} else if (flowinfo.ispotentiallynull(local)) {
switch(this.nullchecktypes[i] & context_mask) {
case flowcontext.in_comparison_null:
this.nullreferences[i] = null;
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, expression);
continue;
}
break;
case flowcontext.in_comparison_non_null:
this.nullreferences[i] = null;
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, expression);
continue;
}
break;
}
}
break;
case may_null:
if (flowinfo.isdefinitelynull(local)) {
scope.problemreporter().localvariablenullreference(local, expression);
continue;
}
if (flowinfo.ispotentiallynull(local)) {
scope.problemreporter().localvariablepotentialnullreference(local, expression);
}
break;
default:
// should not happen
}
}
}
}

public string individualtostring() {

stringbuffer buffer = new stringbuffer("finally flow context"); //$non-nls-1$
buffer.append("[finalassignments count - ").append(this.assigncount).append(']'); //$non-nls-1$
buffer.append("[nullreferences count - ").append(this.nullcount).append(']'); //$non-nls-1$
return buffer.tostring();
}

public boolean issubroutine() {
return true;
}

protected boolean recordfinalassignment(
variablebinding binding,
reference finalassignment) {
if (this.assigncount == 0) {
this.finalassignments = new reference[5];
this.finalvariables = new variablebinding[5];
} else {
if (this.assigncount == this.finalassignments.length)
system.arraycopy(
this.finalassignments,
0,
(this.finalassignments = new reference[this.assigncount * 2]),
0,
this.assigncount);
system.arraycopy(
this.finalvariables,
0,
(this.finalvariables = new variablebinding[this.assigncount * 2]),
0,
this.assigncount);
}
this.finalassignments[this.assigncount] = finalassignment;
this.finalvariables[this.assigncount++] = binding;
return true;
}

public void recordusingnullreference(scope scope, localvariablebinding local,
expression reference, int checktype, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0 && !flowinfo.isdefinitelyunknown(local))	{
if ((this.tagbits & flowcontext.defer_null_diagnostic) != 0) { // within an enclosing loop, be conservative
switch (checktype) {
case can_only_null_non_null | in_comparison_null:
case can_only_null_non_null | in_comparison_non_null:
case can_only_null | in_comparison_null:
case can_only_null | in_comparison_non_null:
case can_only_null | in_assignment:
case can_only_null | in_instanceof:
if (flowinfo.cannotbenull(local)) {
if (checktype == (can_only_null_non_null | in_comparison_non_null)) {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnonnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhenfalse().setreachmode(flowinfo.unreachable);
}
} else if (checktype == (can_only_null_non_null | in_comparison_null)) {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenonnullcomparedtonull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhentrue().setreachmode(flowinfo.unreachable);
}
}
return;
}
if (flowinfo.canonlybenull(local)) {
switch(checktype & context_mask) {
case flowcontext.in_comparison_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhenfalse().setreachmode(flowinfo.unreachable);
}
return;
case flowcontext.in_comparison_non_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenullcomparedtononnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhentrue().setreachmode(flowinfo.unreachable);
}
return;
case flowcontext.in_assignment:
scope.problemreporter().localvariableredundantnullassignment(local, reference);
return;
case flowcontext.in_instanceof:
scope.problemreporter().localvariablenullinstanceof(local, reference);
return;
}
} else if (flowinfo.ispotentiallynull(local)) {
switch(checktype & context_mask) {
case flowcontext.in_comparison_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, reference);
return;
}
break;
case flowcontext.in_comparison_non_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, reference);
return;
}
break;
}
}
break;
case may_null :
if (flowinfo.cannotbenull(local)) {
return;
}
if (flowinfo.canonlybenull(local)) {
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
break;
default:
// never happens
}
}
else { // no enclosing loop, be as precise as possible right now
switch (checktype) {
case can_only_null_non_null | in_comparison_null:
case can_only_null_non_null | in_comparison_non_null:
if (flowinfo.isdefinitelynonnull(local)) {
if (checktype == (can_only_null_non_null | in_comparison_non_null)) {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnonnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhenfalse().setreachmode(flowinfo.unreachable);
}
} else {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenonnullcomparedtonull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhentrue().setreachmode(flowinfo.unreachable);
}
}
return;
}
//$fall-through$
case can_only_null | in_comparison_null:
case can_only_null | in_comparison_non_null:
case can_only_null | in_assignment:
case can_only_null | in_instanceof:
if (flowinfo.isdefinitelynull(local)) {
switch(checktype & context_mask) {
case flowcontext.in_comparison_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhenfalse().setreachmode(flowinfo.unreachable);
}
return;
case flowcontext.in_comparison_non_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenullcomparedtononnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhentrue().setreachmode(flowinfo.unreachable);
}
return;
case flowcontext.in_assignment:
scope.problemreporter().localvariableredundantnullassignment(local, reference);
return;
case flowcontext.in_instanceof:
scope.problemreporter().localvariablenullinstanceof(local, reference);
return;
}
} else if (flowinfo.ispotentiallynull(local)) {
switch(checktype & context_mask) {
case flowcontext.in_comparison_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, reference);
return;
}
break;
case flowcontext.in_comparison_non_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, reference);
return;
}
break;
}
}
break;
case may_null :
if (flowinfo.isdefinitelynull(local)) {
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
if (flowinfo.ispotentiallynull(local)) {
scope.problemreporter().localvariablepotentialnullreference(local, reference);
return;
}
if (flowinfo.isdefinitelynonnull(local)) {
return; // shortcut: cannot be null
}
break;
default:
// never happens
}
}
// if the contention is inside assert statement, we want to avoid null warnings only in case of
// comparisons and not in case of assignment, instanceof, or may be null.
if(((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) || checktype == may_null
|| (checktype & context_mask) == flowcontext.in_assignment
|| (checktype & context_mask) == flowcontext.in_instanceof) {
recordnullreference(local, reference, checktype);
}
// prepare to re-check with try/catch flow info
}
}

void removefinalassignmentifany(reference reference) {
for (int i = 0; i < this.assigncount; i++) {
if (this.finalassignments[i] == reference) {
this.finalassignments[i] = null;
this.finalvariables[i] = null;
return;
}
}
}

protected void recordnullreference(localvariablebinding local,
expression expression, int status) {
if (this.nullcount == 0) {
this.nulllocals = new localvariablebinding[5];
this.nullreferences = new expression[5];
this.nullchecktypes = new int[5];
}
else if (this.nullcount == this.nulllocals.length) {
int newlength = this.nullcount * 2;
system.arraycopy(this.nulllocals, 0,
this.nulllocals = new localvariablebinding[newlength], 0,
this.nullcount);
system.arraycopy(this.nullreferences, 0,
this.nullreferences = new expression[newlength], 0,
this.nullcount);
system.arraycopy(this.nullchecktypes, 0,
this.nullchecktypes = new int[newlength], 0,
this.nullcount);
}
this.nulllocals[this.nullcount] = local;
this.nullreferences[this.nullcount] = expression;
this.nullchecktypes[this.nullcount++] = status;
}
}
