/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;

/**
* record conditional initialization status during definite assignment analysis
*
*/
public class conditionalflowinfo extends flowinfo {

public flowinfo initswhentrue;
public flowinfo initswhenfalse;

conditionalflowinfo(flowinfo initswhentrue, flowinfo initswhenfalse){

this.initswhentrue = initswhentrue;
this.initswhenfalse = initswhenfalse;
}

public flowinfo addinitializationsfrom(flowinfo otherinits) {

this.initswhentrue.addinitializationsfrom(otherinits);
this.initswhenfalse.addinitializationsfrom(otherinits);
return this;
}

public flowinfo addpotentialinitializationsfrom(flowinfo otherinits) {

this.initswhentrue.addpotentialinitializationsfrom(otherinits);
this.initswhenfalse.addpotentialinitializationsfrom(otherinits);
return this;
}

public flowinfo asnegatedcondition() {

flowinfo extra = this.initswhentrue;
this.initswhentrue = this.initswhenfalse;
this.initswhenfalse = extra;
return this;
}

public flowinfo copy() {

return new conditionalflowinfo(this.initswhentrue.copy(), this.initswhenfalse.copy());
}

public flowinfo initswhenfalse() {

return this.initswhenfalse;
}

public flowinfo initswhentrue() {

return this.initswhentrue;
}

public boolean isdefinitelyassigned(fieldbinding field) {

return this.initswhentrue.isdefinitelyassigned(field)
&& this.initswhenfalse.isdefinitelyassigned(field);
}

public boolean isdefinitelyassigned(localvariablebinding local) {

return this.initswhentrue.isdefinitelyassigned(local)
&& this.initswhenfalse.isdefinitelyassigned(local);
}

public boolean isdefinitelynonnull(localvariablebinding local) {
return this.initswhentrue.isdefinitelynonnull(local)
&& this.initswhenfalse.isdefinitelynonnull(local);
}

public boolean isdefinitelynull(localvariablebinding local) {
return this.initswhentrue.isdefinitelynull(local)
&& this.initswhenfalse.isdefinitelynull(local);
}

public boolean isdefinitelyunknown(localvariablebinding local) {
return this.initswhentrue.isdefinitelyunknown(local)
&& this.initswhenfalse.isdefinitelyunknown(local);
}

public boolean ispotentiallyassigned(fieldbinding field) {
return this.initswhentrue.ispotentiallyassigned(field)
|| this.initswhenfalse.ispotentiallyassigned(field);
}

public boolean ispotentiallyassigned(localvariablebinding local) {
return this.initswhentrue.ispotentiallyassigned(local)
|| this.initswhenfalse.ispotentiallyassigned(local);
}

public boolean ispotentiallynonnull(localvariablebinding local) {
return this.initswhentrue.ispotentiallynonnull(local)
|| this.initswhenfalse.ispotentiallynonnull(local);
}

public boolean ispotentiallynull(localvariablebinding local) {
return this.initswhentrue.ispotentiallynull(local)
|| this.initswhenfalse.ispotentiallynull(local);
}

public boolean ispotentiallyunknown(localvariablebinding local) {
return this.initswhentrue.ispotentiallyunknown(local)
|| this.initswhenfalse.ispotentiallyunknown(local);
}

public boolean isprotectednonnull(localvariablebinding local) {
return this.initswhentrue.isprotectednonnull(local)
&& this.initswhenfalse.isprotectednonnull(local);
}

public boolean isprotectednull(localvariablebinding local) {
return this.initswhentrue.isprotectednull(local)
&& this.initswhenfalse.isprotectednull(local);
}

public void markascomparedequaltononnull(localvariablebinding local) {
this.initswhentrue.markascomparedequaltononnull(local);
this.initswhenfalse.markascomparedequaltononnull(local);
}

public void markascomparedequaltonull(localvariablebinding local) {
this.initswhentrue.markascomparedequaltonull(local);
this.initswhenfalse.markascomparedequaltonull(local);
}

public void markasdefinitelyassigned(fieldbinding field) {
this.initswhentrue.markasdefinitelyassigned(field);
this.initswhenfalse.markasdefinitelyassigned(field);
}

public void markasdefinitelyassigned(localvariablebinding local) {
this.initswhentrue.markasdefinitelyassigned(local);
this.initswhenfalse.markasdefinitelyassigned(local);
}

public void markasdefinitelynonnull(localvariablebinding local) {
this.initswhentrue.markasdefinitelynonnull(local);
this.initswhenfalse.markasdefinitelynonnull(local);
}

public void markasdefinitelynull(localvariablebinding local) {
this.initswhentrue.markasdefinitelynull(local);
this.initswhenfalse.markasdefinitelynull(local);
}

public void markasdefinitelyunknown(localvariablebinding local) {
this.initswhentrue.markasdefinitelyunknown(local);
this.initswhenfalse.markasdefinitelyunknown(local);
}

public flowinfo setreachmode(int reachmode) {
if (reachmode == reachable) {
this.tagbits &= ~unreachable;
}
else {
this.tagbits |= unreachable;
}
this.initswhentrue.setreachmode(reachmode);
this.initswhenfalse.setreachmode(reachmode);
return this;
}

public unconditionalflowinfo mergedwith(unconditionalflowinfo otherinits) {
return unconditionalinits().mergedwith(otherinits);
}

public unconditionalflowinfo nullinfolessunconditionalcopy() {
return unconditionalinitswithoutsideeffect().
nullinfolessunconditionalcopy();
}

public string tostring() {

return "flowinfo<true: " + this.initswhentrue.tostring() + ", false: " + this.initswhenfalse.tostring() + ">"; //$non-nls-1$ //$non-nls-3$ //$non-nls-2$
}

public flowinfo safeinitswhentrue() {
return this.initswhentrue;
}

public unconditionalflowinfo unconditionalcopy() {
return this.initswhentrue.unconditionalcopy().
mergedwith(this.initswhenfalse.unconditionalinits());
}

public unconditionalflowinfo unconditionalfieldlesscopy() {
return this.initswhentrue.unconditionalfieldlesscopy().
mergedwith(this.initswhenfalse.unconditionalfieldlesscopy());
// should never happen, hence suboptimal does not hurt
}

public unconditionalflowinfo unconditionalinits() {
return this.initswhentrue.unconditionalinits().
mergedwith(this.initswhenfalse.unconditionalinits());
}

public unconditionalflowinfo unconditionalinitswithoutsideeffect() {
// cannot do better here than unconditionalcopy - but still a different
// operation for unconditionalflowinfo
return this.initswhentrue.unconditionalcopy().
mergedwith(this.initswhenfalse.unconditionalinits());
}

public void markedasnullornonnullinassertexpression(localvariablebinding local) {
this.initswhentrue.markedasnullornonnullinassertexpression(local);
this.initswhenfalse.markedasnullornonnullinassertexpression(local);
}

public boolean ismarkedasnullornonnullinassertexpression(localvariablebinding local) {
return (this.initswhentrue.ismarkedasnullornonnullinassertexpression(local)
|| this.initswhenfalse.ismarkedasnullornonnullinassertexpression(local));
}
}
