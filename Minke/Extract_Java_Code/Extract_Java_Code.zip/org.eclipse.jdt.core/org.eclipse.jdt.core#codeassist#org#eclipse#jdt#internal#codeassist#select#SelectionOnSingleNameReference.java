/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

/*
* selection node build by the parser in any case it was intending to
* reduce a single name reference containing the assist identifier.
* e.g.
*
*	class x {
*    void foo() {
*      [start]ba[end]
*    }
*  }
*
*	---> class x {
*         void foo() {
*           <selectonname:ba>
*         }
*       }
*
*/

import org.eclipse.jdt.internal.compiler.ast.singlenamereference;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.missingtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.problemfieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.problemreferencebinding;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class selectiononsinglenamereference extends singlenamereference {
public selectiononsinglenamereference(char[] source, long pos) {
super(source, pos);
}
public typebinding resolvetype(blockscope scope) {
if (this.actualreceivertype != null) {
this.binding = scope.getfield(this.actualreceivertype, this.token, this);
if (this.binding != null && this.binding.isvalidbinding()) {
throw new selectionnodefound(this.binding);
}
}
// it can be a package, type, member type, local variable or field
this.binding = scope.getbinding(this.token, binding.variable | binding.type | binding.package, this, true /*resolve*/);
if (!this.binding.isvalidbinding()) {
if (this.binding instanceof problemfieldbinding) {
// tolerate some error cases
if (this.binding.problemid() == problemreasons.notvisible
|| this.binding.problemid() == problemreasons.inheritednamehidesenclosingname
|| this.binding.problemid() == problemreasons.nonstaticreferenceinconstructorinvocation
|| this.binding.problemid() == problemreasons.nonstaticreferenceinstaticcontext){
throw new selectionnodefound(this.binding);
}
scope.problemreporter().invalidfield(this, (fieldbinding) this.binding);
} else if (this.binding instanceof problemreferencebinding || this.binding instanceof missingtypebinding) {
// tolerate some error cases
if (this.binding.problemid() == problemreasons.notvisible){
throw new selectionnodefound(this.binding);
}
scope.problemreporter().invalidtype(this, (typebinding) this.binding);
} else {
scope.problemreporter().unresolvablereference(this, this.binding);
}
throw new selectionnodefound();
}

throw new selectionnodefound(this.binding);
}
public stringbuffer printexpression(int indent, stringbuffer output) {
output.append("<selectonname:"); //$non-nls-1$
return super.printexpression(0, output).append('>');
}
}
