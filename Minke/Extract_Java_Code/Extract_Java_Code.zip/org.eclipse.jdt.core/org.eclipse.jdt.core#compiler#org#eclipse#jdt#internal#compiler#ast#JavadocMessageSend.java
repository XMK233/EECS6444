/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;


public class javadocmessagesend extends messagesend {

public int tagsourcestart, tagsourceend;
public int tagvalue;

public javadocmessagesend(char[] name, long pos) {
this.selector = name;
this.namesourceposition = pos;
this.sourcestart = (int) (this.namesourceposition >>> 32);
this.sourceend = (int) this.namesourceposition;
this.bits |= insidejavadoc;
}
public javadocmessagesend(char[] name, long pos, javadocargumentexpression[] arguments) {
this(name, pos);
this.arguments = arguments;
}

/*
* resolves type on a block or class scope.
*/
private typebinding internalresolvetype(scope scope) {
// answer the signature return type
// base type promotion
this.constant = constant.notaconstant;
if (this.receiver == null) {
this.actualreceivertype = scope.enclosingreceivertype();
} else if (scope.kind == scope.class_scope) {
this.actualreceivertype = this.receiver.resolvetype((classscope) scope);
} else {
this.actualreceivertype = this.receiver.resolvetype((blockscope) scope);
}

// will check for null after args are resolved

typebinding[] argumenttypes = binding.no_parameters;
boolean hasargstypevar = false;
if (this.arguments != null) {
boolean arghaserror = false; // typechecks all arguments
int length = this.arguments.length;
argumenttypes = new typebinding[length];
for (int i = 0; i < length; i++){
expression argument = this.arguments[i];
if (scope.kind == scope.class_scope) {
argumenttypes[i] = argument.resolvetype((classscope)scope);
} else {
argumenttypes[i] = argument.resolvetype((blockscope)scope);
}
if (argumenttypes[i] == null) {
arghaserror = true;
} else if (!hasargstypevar) {
hasargstypevar = argumenttypes[i].istypevariable();
}
}
if (arghaserror) {
return null;
}
}

// check receiver type
if (this.actualreceivertype == null) {
return null;
}
this.actualreceivertype = scope.environment().converttorawtype(this.receiver.resolvedtype, true /*force the conversion of enclosing types*/);
referencebinding enclosingtype = scope.enclosingreceivertype();
if (enclosingtype==null ? false : enclosingtype.iscompatiblewith(this.actualreceivertype)) {
this.bits |= astnode.superaccess;
}

// base type cannot receive any message
if (this.actualreceivertype.isbasetype()) {
scope.problemreporter().javadocerrornomethodfor(this, this.actualreceivertype, argumenttypes, scope.getdeclarationmodifiers());
return null;
}
this.binding = scope.getmethod(this.actualreceivertype, this.selector, argumenttypes, this);
if (!this.binding.isvalidbinding()) {
// try method in enclosing types
typebinding enclosingtypebinding = this.actualreceivertype;
methodbinding methodbinding = this.binding;
while (!methodbinding.isvalidbinding() && (enclosingtypebinding.ismembertype() || enclosingtypebinding.islocaltype())) {
enclosingtypebinding = enclosingtypebinding.enclosingtype();
methodbinding = scope.getmethod(enclosingtypebinding, this.selector, argumenttypes, this);
}
if (methodbinding.isvalidbinding()) {
this.binding = methodbinding;
} else {
// try to search a constructor instead
enclosingtypebinding = this.actualreceivertype;
methodbinding contructorbinding = this.binding;
while (!contructorbinding.isvalidbinding() && (enclosingtypebinding.ismembertype() || enclosingtypebinding.islocaltype())) {
enclosingtypebinding = enclosingtypebinding.enclosingtype();
if (charoperation.equals(this.selector, enclosingtypebinding.shortreadablename())) {
contructorbinding = scope.getconstructor((referencebinding)enclosingtypebinding, argumenttypes, this);
}
}
if (contructorbinding.isvalidbinding()) {
this.binding = contructorbinding;
}
}
}
if (!this.binding.isvalidbinding()) {
// implicit lookup may discover issues due to static/constructor contexts. javadoc must be resilient
switch (this.binding.problemid()) {
case problemreasons.nonstaticreferenceinconstructorinvocation:
case problemreasons.nonstaticreferenceinstaticcontext:
case problemreasons.inheritednamehidesenclosingname :
case problemreasons.ambiguous:
methodbinding closestmatch = ((problemmethodbinding)this.binding).closestmatch;
if (closestmatch != null) {
this.binding = closestmatch; // ignore problem if can reach target method through it
}
}
}
if (!this.binding.isvalidbinding()) {
if (this.receiver.resolvedtype instanceof problemreferencebinding) {
// problem already got signaled on receiver, do not report secondary problem
return null;
}
if (this.binding.declaringclass == null) {
if (this.actualreceivertype instanceof referencebinding) {
this.binding.declaringclass = (referencebinding) this.actualreceivertype;
} else {
scope.problemreporter().javadocerrornomethodfor(this, this.actualreceivertype, argumenttypes, scope.getdeclarationmodifiers());
return null;
}
}
scope.problemreporter().javadocinvalidmethod(this, this.binding, scope.getdeclarationmodifiers());
// record the closest match, for clients who may still need hint about possible method match
if (this.binding instanceof problemmethodbinding) {
methodbinding closestmatch = ((problemmethodbinding)this.binding).closestmatch;
if (closestmatch != null) this.binding = closestmatch;
}
return this.resolvedtype = this.binding == null ? null : this.binding.returntype;
} else if (hasargstypevar) {
methodbinding problem = new problemmethodbinding(this.binding, this.selector, argumenttypes, problemreasons.notfound);
scope.problemreporter().javadocinvalidmethod(this, problem, scope.getdeclarationmodifiers());
} else if (this.binding.isvarargs()) {
int length = argumenttypes.length;
if (!(this.binding.parameters.length == length && argumenttypes[length-1].isarraytype())) {
methodbinding problem = new problemmethodbinding(this.binding, this.selector, argumenttypes, problemreasons.notfound);
scope.problemreporter().javadocinvalidmethod(this, problem, scope.getdeclarationmodifiers());
}
} else {
int length = argumenttypes.length;
for (int i=0; i<length; i++) {
if (this.binding.parameters[i].erasure() != argumenttypes[i].erasure()) {
methodbinding problem = new problemmethodbinding(this.binding, this.selector, argumenttypes, problemreasons.notfound);
scope.problemreporter().javadocinvalidmethod(this, problem, scope.getdeclarationmodifiers());
break;
}
}
}
if (ismethodusedeprecated(this.binding, scope, true)) {
scope.problemreporter().javadocdeprecatedmethod(this.binding, this, scope.getdeclarationmodifiers());
}

return this.resolvedtype = this.binding.returntype;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#issuperaccess()
*/
public boolean issuperaccess() {
return (this.bits & astnode.superaccess) != 0;
}

public stringbuffer printexpression(int indent, stringbuffer output){

if (this.receiver != null) {
this.receiver.printexpression(0, output);
}
output.append('#').append(this.selector).append('(');
if (this.arguments != null) {
for (int i = 0; i < this.arguments.length ; i ++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.arguments[i].printexpression(0, output);
}
}
return output.append(')');
}

public typebinding resolvetype(blockscope scope) {
return internalresolvetype(scope);
}

public typebinding resolvetype(classscope scope) {
return internalresolvetype(scope);
}

/* (non-javadoc)
* redefine to capture javadoc specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.astvisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(astvisitor visitor, blockscope blockscope) {
if (visitor.visit(this, blockscope)) {
if (this.receiver != null) {
this.receiver.traverse(visitor, blockscope);
}
if (this.arguments != null) {
int argumentslength = this.arguments.length;
for (int i = 0; i < argumentslength; i++)
this.arguments[i].traverse(visitor, blockscope);
}
}
visitor.endvisit(this, blockscope);
}
/* (non-javadoc)
* redefine to capture javadoc specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.astvisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(astvisitor visitor, classscope scope) {
if (visitor.visit(this, scope)) {
if (this.receiver != null) {
this.receiver.traverse(visitor, scope);
}
if (this.arguments != null) {
int argumentslength = this.arguments.length;
for (int i = 0; i < argumentslength; i++)
this.arguments[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
