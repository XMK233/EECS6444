/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

/*
* selection node build by the parser in any case it was intending to
* reduce an package statement containing the assist identifier.
* e.g.
*
*  package java.[start]io[end];
*	class x {
*    void foo() {
*    }
*  }
*
*	---> <selectonpackage:java.io>
*		 class x {
*         void foo() {
*         }
*       }
*
*/

import org.eclipse.jdt.internal.compiler.ast.importreference;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;

public class selectiononpackagereference extends importreference {
public selectiononpackagereference(char[][] tokens , long[] positions) {
super(tokens, positions, true, classfileconstants.accdefault);
}
public stringbuffer print(int tab, stringbuffer output, boolean withondemand) {
printindent(tab, output).append("<selectonpackage:"); //$non-nls-1$
for (int i = 0; i < this.tokens.length; i++) {
if (i > 0) output.append('.');
output.append(this.tokens[i]);
}
return output.append('>');
}
}
