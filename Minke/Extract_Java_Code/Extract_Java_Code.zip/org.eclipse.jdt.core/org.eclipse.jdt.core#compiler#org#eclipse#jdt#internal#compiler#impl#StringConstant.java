/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.impl;

public class stringconstant extends constant {

private string value;

public static constant fromvalue(string value) {
return new stringconstant(value);
}

private stringconstant(string value) {
this.value = value;
}

public string stringvalue() {
// spec 15.17.11

// the next line do not go into the tostring() send....!
return this.value;
/*
* string s = value.tostring() ; if (s == null) return "null"; else return s;
*/
}

public string tostring() {
return "(string)\"" + this.value + "\""; //$non-nls-2$ //$non-nls-1$
}

public int typeid() {
return t_javalangstring;
}
}
