/*******************************************************************************
* copyright (c) 2000, 2001, 2002 international business machines corp. and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v0.5
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v05.html
*
* contributors:
*     ibm corporation - initial api and implementation
******************************************************************************/
package org.eclipse.jdt.internal.compiler.impl;

public class nullconstant extends constant {

public static final nullconstant default = new nullconstant();
public static final string nullstring = new stringbuffer(4).append((string)null).tostring();

private nullconstant() {
}

public string stringvalue() {

return nullstring;
}

public string tostring(){

return "(null)" + null ;  //$non-nls-1$
}

public int typeid() {

return t_null;
}
}
