/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class javadocallocationexpression extends allocationexpression {

public int tagsourcestart, tagsourceend;
public int tagvalue, memberstart;
public char[][] qualification;

public javadocallocationexpression(int start, int end) {
this.sourcestart = start;
this.sourceend = end;
this.bits |= insidejavadoc;
}
public javadocallocationexpression(long pos) {
this((int) (pos >>> 32), (int) pos);
}

typebinding internalresolvetype(scope scope) {

// propagate the type checking to the arguments, and check if the constructor is defined.
this.constant = constant.notaconstant;
if (this.type == null) {
this.resolvedtype = scope.enclosingsourcetype();
} else if (scope.kind == scope.class_scope) {
this.resolvedtype = this.type.resolvetype((classscope)scope);
} else {
this.resolvedtype = this.type.resolvetype((blockscope)scope, true /* check bounds*/);
}

// buffering the arguments' types
typebinding[] argumenttypes = binding.no_parameters;
boolean hastypevarargs = false;
if (this.arguments != null) {
boolean arghaserror = false;
int length = this.arguments.length;
argumenttypes = new typebinding[length];
for (int i = 0; i < length; i++) {
expression argument = this.arguments[i];
if (scope.kind == scope.class_scope) {
argumenttypes[i] = argument.resolvetype((classscope)scope);
} else {
argumenttypes[i] = argument.resolvetype((blockscope)scope);
}
if (argumenttypes[i] == null) {
arghaserror = true;
} else if (!hastypevarargs) {
hastypevarargs = argumenttypes[i].istypevariable();
}
}
if (arghaserror) {
return null;
}
}

// check resolved type
if (this.resolvedtype == null) {
return null;
}
this.resolvedtype = scope.environment().converttorawtype(this.type.resolvedtype,  true /*force the conversion of enclosing types*/);
sourcetypebinding enclosingtype = scope.enclosingsourcetype();
if (enclosingtype == null ? false : enclosingtype.iscompatiblewith(this.resolvedtype)) {
this.bits |= astnode.superaccess;
}

referencebinding allocationtype = (referencebinding) this.resolvedtype;
this.binding = scope.getconstructor(allocationtype, argumenttypes, this);
if (!this.binding.isvalidbinding()) {
referencebinding enclosingtypebinding = allocationtype;
methodbinding contructorbinding = this.binding;
while (!contructorbinding.isvalidbinding() && (enclosingtypebinding.ismembertype() || enclosingtypebinding.islocaltype())) {
enclosingtypebinding = enclosingtypebinding.enclosingtype();
contructorbinding = scope.getconstructor(enclosingtypebinding, argumenttypes, this);
}
if (contructorbinding.isvalidbinding()) {
this.binding = contructorbinding;
}
}
if (!this.binding.isvalidbinding()) {
// first try to search a method instead
methodbinding methodbinding = scope.getmethod(this.resolvedtype, this.resolvedtype.sourcename(), argumenttypes, this);
if (methodbinding.isvalidbinding()) {
this.binding = methodbinding;
} else {
if (this.binding.declaringclass == null) {
this.binding.declaringclass = allocationtype;
}
scope.problemreporter().javadocinvalidconstructor(this, this.binding, scope.getdeclarationmodifiers());
}
return this.resolvedtype;
} else if (this.binding.isvarargs()) {
int length = argumenttypes.length;
if (!(this.binding.parameters.length == length && argumenttypes[length-1].isarraytype())) {
methodbinding problem = new problemmethodbinding(this.binding, this.binding.selector, argumenttypes, problemreasons.notfound);
scope.problemreporter().javadocinvalidconstructor(this, problem, scope.getdeclarationmodifiers());
}
} else if (hastypevarargs) {
methodbinding problem = new problemmethodbinding(this.binding, this.binding.selector, argumenttypes, problemreasons.notfound);
scope.problemreporter().javadocinvalidconstructor(this, problem, scope.getdeclarationmodifiers());
} else if (this.binding instanceof parameterizedmethodbinding) {
parameterizedmethodbinding parammethodbinding = (parameterizedmethodbinding) this.binding;
if (parammethodbinding.hassubstitutedparameters()) {
int length = argumenttypes.length;
for (int i=0; i<length; i++) {
if (parammethodbinding.parameters[i] != argumenttypes[i] &&
parammethodbinding.parameters[i].erasure() != argumenttypes[i].erasure()) {
methodbinding problem = new problemmethodbinding(this.binding, this.binding.selector, argumenttypes, problemreasons.notfound);
scope.problemreporter().javadocinvalidconstructor(this, problem, scope.getdeclarationmodifiers());
break;
}
}
}
} else if (this.resolvedtype.ismembertype()) {
int length = this.qualification.length;
if (length > 1) { // accept qualified member class constructor reference => see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=103304
referencebinding enclosingtypebinding = allocationtype;
if (this.type instanceof javadocqualifiedtypereference && ((javadocqualifiedtypereference)this.type).tokens.length != length) {
scope.problemreporter().javadocinvalidmembertypequalification(this.memberstart+1, this.sourceend, scope.getdeclarationmodifiers());
} else {
int idx = length;
while (idx > 0 && charoperation.equals(this.qualification[--idx], enclosingtypebinding.sourcename) && (enclosingtypebinding = enclosingtypebinding.enclosingtype()) != null) {
// verify that each qualification token matches enclosing types
}
if (idx > 0 || enclosingtypebinding != null) {
scope.problemreporter().javadocinvalidmembertypequalification(this.memberstart+1, this.sourceend, scope.getdeclarationmodifiers());
}
}
}
}
if (ismethodusedeprecated(this.binding, scope, true)) {
scope.problemreporter().javadocdeprecatedmethod(this.binding, this, scope.getdeclarationmodifiers());
}
return allocationtype;
}

public boolean issuperaccess() {
return (this.bits & astnode.superaccess) != 0;
}

public typebinding resolvetype(blockscope scope) {
return internalresolvetype(scope);
}

public typebinding resolvetype(classscope scope) {
return internalresolvetype(scope);
}
public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.typearguments != null) {
for (int i = 0, typeargumentslength = this.typearguments.length; i < typeargumentslength; i++) {
this.typearguments[i].traverse(visitor, scope);
}
}
if (this.type != null) { // enum constant scenario
this.type.traverse(visitor, scope);
}
if (this.arguments != null) {
for (int i = 0, argumentslength = this.arguments.length; i < argumentslength; i++)
this.arguments[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
public void traverse(astvisitor visitor, classscope scope) {
if (visitor.visit(this, scope)) {
if (this.typearguments != null) {
for (int i = 0, typeargumentslength = this.typearguments.length; i < typeargumentslength; i++) {
this.typearguments[i].traverse(visitor, scope);
}
}
if (this.type != null) { // enum constant scenario
this.type.traverse(visitor, scope);
}
if (this.arguments != null) {
for (int i = 0, argumentslength = this.arguments.length; i < argumentslength; i++)
this.arguments[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
