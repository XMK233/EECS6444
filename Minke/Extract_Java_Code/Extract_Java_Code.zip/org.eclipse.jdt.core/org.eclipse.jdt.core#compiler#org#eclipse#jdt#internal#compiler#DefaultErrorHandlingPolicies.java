/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

public class defaulterrorhandlingpolicies {

/*
* accumulate all problems, then exit without proceeding.
*
* typically, the #proceedwithproblems(problem[]) should
* show the problems.
*
*/
public static ierrorhandlingpolicy exitafterallproblems() {
return new ierrorhandlingpolicy() {
public boolean stoponfirsterror() {
return false;
}
public boolean proceedonerrors(){
return false;
}
};
}
/*
* exit without proceeding on the first problem wich appears
* to be an error.
*
*/
public static ierrorhandlingpolicy exitonfirsterror() {
return new ierrorhandlingpolicy() {
public boolean stoponfirsterror() {
return true;
}
public boolean proceedonerrors(){
return false;
}
};
}
/*
* proceed on the first error met.
*
*/
public static ierrorhandlingpolicy proceedonfirsterror() {
return new ierrorhandlingpolicy() {
public boolean stoponfirsterror() {
return true;
}
public boolean proceedonerrors(){
return true;
}
};
}
/*
* accumulate all problems, then proceed with them.
*
*/
public static ierrorhandlingpolicy proceedwithallproblems() {
return new ierrorhandlingpolicy() {
public boolean stoponfirsterror() {
return false;
}
public boolean proceedonerrors(){
return true;
}
};
}
}
