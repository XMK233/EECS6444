/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

public interface invocationsite {

typebinding[] generictypearguments();
boolean issuperaccess();
boolean istypeaccess();
// in case the receiver type does not match the actual receiver type
// e.g. pkg.type.c (receiver type of c is type of source context,
//		but actual receiver type is pkg.type)
// e.g2. in presence of implicit access to enclosing type
void setactualreceivertype(referencebinding receivertype);
void setdepth(int depth);
void setfieldindex(int depth);
int sourceend();
int sourcestart();
}
