/*******************************************************************************
* copyright (c) 2000, 2006 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

/*
* selection node build by the parser in any case it was intending to
* reduce a super reference containing the assist identifier.
* e.g.
*
*	class x extends z {
*    class y {
*    	void foo() {
*      	[start]super[end].bar();
*      }
*    }
*  }
*
*	---> class x {
*		   class y {
*           void foo() {
*             <selectonqualifiedsuper:super>
*           }
*         }
*       }
*
*/

import org.eclipse.jdt.internal.compiler.ast.superreference;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class selectiononsuperreference extends superreference {

public selectiononsuperreference(int pos, int sourceend) {
super(pos, sourceend);
}
public stringbuffer printexpression(int indent, stringbuffer output){

output.append("<selectonsuper:"); //$non-nls-1$
return super.printexpression(0, output).append('>');
}
public typebinding resolvetype(blockscope scope) {
typebinding binding = super.resolvetype(scope);

if (binding == null || !binding.isvalidbinding())
throw new selectionnodefound();
else
throw new selectionnodefound(binding);
}
}
