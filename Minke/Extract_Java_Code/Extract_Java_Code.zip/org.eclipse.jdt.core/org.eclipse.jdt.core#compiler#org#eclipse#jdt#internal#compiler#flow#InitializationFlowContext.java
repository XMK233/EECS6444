/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

/**
* reflects the context of code analysis, keeping track of enclosing
*	try statements, exception handlers, etc...
*/
public class initializationflowcontext extends exceptionhandlingflowcontext {
public int exceptioncount;
public typebinding[] thrownexceptions = new typebinding[5];
public astnode[] exceptionthrowers = new astnode[5];
public flowinfo[] exceptionthrowerflowinfos = new flowinfo[5];
public flowinfo	initsbeforecontext;

public initializationflowcontext(flowcontext parent, astnode associatednode, flowinfo initsbeforecontext, flowcontext initializationparent, blockscope scope) {
super(
parent,
associatednode,
binding.no_exceptions, // no exception allowed by default
initializationparent,
scope,
flowinfo.dead_end);
this.initsbeforecontext = initsbeforecontext;
}

public void checkinitializerexceptions(
blockscope currentscope,
flowcontext initializercontext,
flowinfo flowinfo) {
for (int i = 0; i < this.exceptioncount; i++) {
initializercontext.checkexceptionhandlers(
this.thrownexceptions[i],
this.exceptionthrowers[i],
this.exceptionthrowerflowinfos[i],
currentscope);
}
}

public string individualtostring() {

stringbuffer buffer = new stringbuffer("initialization flow context"); //$non-nls-1$
for (int i = 0; i < this.exceptioncount; i++) {
buffer.append('[').append(this.thrownexceptions[i].readablename());
buffer.append('-').append(this.exceptionthrowerflowinfos[i].tostring()).append(']');
}
return buffer.tostring();
}

public void recordhandlingexception(
referencebinding exceptiontype,
unconditionalflowinfo flowinfo,
typebinding raisedexception,
astnode invocationsite,
boolean wasmasked) {

// even if unreachable code, need to perform unhandled exception diagnosis
int size = this.thrownexceptions.length;
if (this.exceptioncount == size) {
system.arraycopy(
this.thrownexceptions,
0,
(this.thrownexceptions = new typebinding[size * 2]),
0,
size);
system.arraycopy(
this.exceptionthrowers,
0,
(this.exceptionthrowers = new astnode[size * 2]),
0,
size);
system.arraycopy(
this.exceptionthrowerflowinfos,
0,
(this.exceptionthrowerflowinfos = new flowinfo[size * 2]),
0,
size);
}
this.thrownexceptions[this.exceptioncount] = raisedexception;
this.exceptionthrowers[this.exceptioncount] = invocationsite;
this.exceptionthrowerflowinfos[this.exceptioncount++] = flowinfo.copy();
}
}
