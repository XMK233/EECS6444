/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.batch;

import java.io.file;
import java.io.ioexception;
import java.io.inputstream;
import java.util.arraylist;
import java.util.enumeration;
import java.util.hashtable;
import java.util.iterator;
import java.util.list;
import java.util.zip.zipentry;
import java.util.zip.zipfile;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.classfmt.classfilereader;
import org.eclipse.jdt.internal.compiler.classfmt.classformatexception;
import org.eclipse.jdt.internal.compiler.env.accessruleset;
import org.eclipse.jdt.internal.compiler.env.nameenvironmentanswer;
import org.eclipse.jdt.internal.compiler.util.manifestanalyzer;
import org.eclipse.jdt.internal.compiler.util.util;

public class classpathjar extends classpathlocation {

protected file file;
protected zipfile zipfile;
protected boolean closezipfileatend;
protected hashtable packagecache;

public classpathjar(file file, boolean closezipfileatend,
accessruleset accessruleset, string destinationpath) {
super(accessruleset, destinationpath);
this.file = file;
this.closezipfileatend = closezipfileatend;
}

public list fetchlinkedjars(filesystem.classpathsectionproblemreporter problemreporter) {
// expected to be called once only - if multiple calls desired, consider
// using a cache
inputstream inputstream = null;
try {
initialize();
arraylist result = new arraylist();
zipentry manifest = this.zipfile.getentry("meta-inf/manifest.mf"); //$non-nls-1$
if (manifest != null) { // non-null implies regular file
inputstream = this.zipfile.getinputstream(manifest);
manifestanalyzer analyzer = new manifestanalyzer();
boolean success = analyzer.analyzemanifestcontents(inputstream);
list calledfilenames = analyzer.getcalledfilenames();
if (problemreporter != null) {
if (!success || analyzer.getclasspathsectionscount() == 1 &&  calledfilenames == null) {
problemreporter.invalidclasspathsection(getpath());
} else if (analyzer.getclasspathsectionscount() > 1) {
problemreporter.multipleclasspathsections(getpath());
}
}
if (calledfilenames != null) {
iterator calledfilesiterator = calledfilenames.iterator();
string directorypath = getpath();
int lastseparator = directorypath.lastindexof(file.separatorchar);
directorypath = directorypath.substring(0, lastseparator + 1); // potentially empty (see bug 214731)
while (calledfilesiterator.hasnext()) {
result.add(new classpathjar(new file(directorypath + (string) calledfilesiterator.next()), this.closezipfileatend, this.accessruleset, this.destinationpath));
}
}
}
return result;
} catch (ioexception e) {
return null;
} finally {
if (inputstream != null) {
try {
inputstream.close();
} catch (ioexception e) {
// best effort
}
}
}
}
public nameenvironmentanswer findclass(char[] typename, string qualifiedpackagename, string qualifiedbinaryfilename) {
return findclass(typename, qualifiedpackagename, qualifiedbinaryfilename, false);
}
public nameenvironmentanswer findclass(char[] typename, string qualifiedpackagename, string qualifiedbinaryfilename, boolean asbinaryonly) {
if (!ispackage(qualifiedpackagename))
return null; // most common case

try {
classfilereader reader = classfilereader.read(this.zipfile, qualifiedbinaryfilename);
if (reader != null)
return new nameenvironmentanswer(reader, fetchaccessrestriction(qualifiedbinaryfilename));
} catch(classformatexception e) {
// treat as if class file is missing
} catch (ioexception e) {
// treat as if class file is missing
}
return null;
}
public char[][][] findtypenames(string qualifiedpackagename) {
if (!ispackage(qualifiedpackagename))
return null; // most common case

arraylist answers = new arraylist();
nextentry : for (enumeration e = this.zipfile.entries(); e.hasmoreelements(); ) {
string filename = ((zipentry) e.nextelement()).getname();

// add the package name & all of its parent packages
int last = filename.lastindexof('/');
while (last > 0) {
// extract the package name
string packagename = filename.substring(0, last);
if (!qualifiedpackagename.equals(packagename))
continue nextentry;
int indexofdot = filename.lastindexof('.');
if (indexofdot != -1) {
string typename = filename.substring(last + 1, indexofdot);
char[] packagearray = packagename.tochararray();
answers.add(
charoperation.arrayconcat(
charoperation.spliton('/', packagearray),
typename.tochararray()));
}
}
}
int size = answers.size();
if (size != 0) {
char[][][] result = new char[size][][];
answers.toarray(result);
return null;
}
return null;
}
public void initialize() throws ioexception {
if (this.zipfile == null) {
this.zipfile = new zipfile(this.file);
}
}
public boolean ispackage(string qualifiedpackagename) {
if (this.packagecache != null)
return this.packagecache.containskey(qualifiedpackagename);

this.packagecache = new hashtable(41);
this.packagecache.put(util.empty_string, util.empty_string);

nextentry : for (enumeration e = this.zipfile.entries(); e.hasmoreelements(); ) {
string filename = ((zipentry) e.nextelement()).getname();

// add the package name & all of its parent packages
int last = filename.lastindexof('/');
while (last > 0) {
// extract the package name
string packagename = filename.substring(0, last);
if (this.packagecache.containskey(packagename))
continue nextentry;
this.packagecache.put(packagename, packagename);
last = packagename.lastindexof('/');
}
}
return this.packagecache.containskey(qualifiedpackagename);
}
public void reset() {
if (this.zipfile != null && this.closezipfileatend) {
try {
this.zipfile.close();
} catch(ioexception e) {
// ignore
}
this.zipfile = null;
}
this.packagecache = null;
}
public string tostring() {
return "classpath for jar file " + this.file.getpath(); //$non-nls-1$
}
public char[] normalizedpath() {
if (this.normalizedpath == null) {
string path2 = this.getpath();
char[] rawname = path2.tochararray();
if (file.separatorchar == '\\') {
charoperation.replace(rawname, '\\', '/');
}
this.normalizedpath = charoperation.subarray(rawname, 0, charoperation.lastindexof('.', rawname));
}
return this.normalizedpath;
}
public string getpath() {
if (this.path == null) {
try {
this.path = this.file.getcanonicalpath();
} catch (ioexception e) {
// in case of error, simply return the absolute path
this.path = this.file.getabsolutepath();
}
}
return this.path;
}
}
