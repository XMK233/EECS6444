/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class annotationsinglenamereference extends singlenamereference {

public int tagsourcestart, tagsourceend;

public annotationsinglenamereference(char[] name, int startposition, int endposition) {
super(name, (((long) startposition) << 32) + endposition);
this.bits |= insideannotation;
}

public void resolve(blockscope scope) {

localvariablebinding variablebinding = scope.findvariable(token);
if (variablebinding != null && variablebinding.isvalidbinding() && variablebinding.isargument) {
this.binding = variablebinding;
return;
}
scope.problemreporter().annotationinvalidparamname(this, false);
}

/* (non-javadoc)
* redefine to capture annotation specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(iabstractsyntaxtreevisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
