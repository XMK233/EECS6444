package org.eclipse.jdt.internal.core.ant;

/*
* (c) copyright ibm corp. 2000, 2001.
* all rights reserved.
*/

import java.util.*;

public class util {


/* bundle containing messages */
protected static resourcebundle bundle;
private final static string bundlename = "org.eclipse.jdt.internal.core.ant.messages"; //$non-nls-1$


static {
relocalize();
}

/**
* lookup the message with the given id in this catalog
*/
public static string bind(string id) {
return bind(id, (string[])null);
}

/**
* lookup the message with the given id in this catalog and bind its
* substitution locations with the given string values.
*/
public static string bind(string id, string[] bindings) {
if (id == null)
return "no message available"; //$non-nls-1$
string message = null;
try {
message = bundle.getstring(id);
} catch (missingresourceexception e) {
// if we got an exception looking for the message, fail gracefully by just returning
// the id we were looking for.  in most cases this is semi-informative so is not too bad.
return "missing message: " + id + " in: " + bundlename; //$non-nls-2$ //$non-nls-1$
}
if (bindings == null)
return message;
int length = message.length();
int start = -1;
int end = length;
stringbuffer output = new stringbuffer(80);
while (true) {
if ((end = message.indexof('{', start)) > -1) {
output.append(message.substring(start + 1, end));
if ((start = message.indexof('}', end)) > -1) {
int index = -1;
try {
index = integer.parseint(message.substring(end + 1, start));
output.append(bindings[index]);
} catch (numberformatexception nfe) {
output.append(message.substring(end + 1, start + 1));
} catch (arrayindexoutofboundsexception e) {
output.append("{missing " + integer.tostring(index) + "}"); //$non-nls-2$ //$non-nls-1$
}
} else {
output.append(message.substring(end, length));
break;
}
} else {
output.append(message.substring(start + 1, length));
break;
}
}
return output.tostring();
}

/**
* lookup the message with the given id in this catalog and bind its
* substitution locations with the given string.
*/
public static string bind(string id, string binding) {
return bind(id, new string[] {binding});
}

/**
* lookup the message with the given id in this catalog and bind its
* substitution locations with the given strings.
*/
public static string bind(string id, string binding1, string binding2) {
return bind(id, new string[] {binding1, binding2});
}

/**
* creates a nls catalog for the given locale.
*/
public static void relocalize() {
bundle = resourcebundle.getbundle(bundlename, locale.getdefault());
}
}
