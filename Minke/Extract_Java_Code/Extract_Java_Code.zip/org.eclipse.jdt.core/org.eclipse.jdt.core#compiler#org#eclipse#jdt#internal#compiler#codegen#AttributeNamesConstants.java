/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

public interface attributenamesconstants {
final char[] syntheticname = "synthetic".tochararray(); //$non-nls-1$
final char[] constantvaluename = "constantvalue".tochararray(); //$non-nls-1$
final char[] linenumbertablename = "linenumbertable".tochararray(); //$non-nls-1$
final char[] localvariabletablename = "localvariabletable".tochararray(); //$non-nls-1$
final char[] innerclassname = "innerclasses".tochararray(); //$non-nls-1$
final char[] codename = "code".tochararray(); //$non-nls-1$
final char[] exceptionsname = "exceptions".tochararray(); //$non-nls-1$
final char[] sourcename = "sourcefile".tochararray(); //$non-nls-1$
final char[] deprecatedname = "deprecated".tochararray(); //$non-nls-1$
final char[] signaturename = "signature".tochararray(); //$non-nls-1$
final char[] localvariabletypetablename = "localvariabletypetable".tochararray(); //$non-nls-1$
final char[] enclosingmethodname = "enclosingmethod".tochararray(); //$non-nls-1$
final char[] annotationdefaultname = "annotationdefault".tochararray(); //$non-nls-1$
final char[] runtimeinvisibleannotationsname = "runtimeinvisibleannotations".tochararray(); //$non-nls-1$
final char[] runtimevisibleannotationsname = "runtimevisibleannotations".tochararray(); //$non-nls-1$
final char[] runtimeinvisibleparameterannotationsname = "runtimeinvisibleparameterannotations".tochararray(); //$non-nls-1$
final char[] runtimevisibleparameterannotationsname = "runtimevisibleparameterannotations".tochararray(); //$non-nls-1$
final char[] stackmaptablename = "stackmaptable".tochararray(); //$non-nls-1$
final char[] inconsistenthierarchy = "inconsistenthierarchy".tochararray(); //$non-nls-1$
final char[] varargsname = "varargs".tochararray(); //$non-nls-1$
final char[] stackmapname = "stackmap".tochararray(); //$non-nls-1$
final char[] missingtypesname = "missingtypes".tochararray(); //$non-nls-1$
}
