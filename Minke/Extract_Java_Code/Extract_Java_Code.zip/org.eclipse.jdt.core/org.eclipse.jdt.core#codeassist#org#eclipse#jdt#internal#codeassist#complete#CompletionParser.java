/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* parser able to build specific completion parse nodes, given a cursorlocation.
*
* cursor location denotes the position of the last character behind which completion
* got requested:
*  -1 means completion at the very beginning of the source
*	0  means completion behind the first character
*  n  means completion behind the n-th character
*/

import java.util.hashset;

import org.eclipse.jdt.internal.compiler.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.env.*;

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.parser.*;
import org.eclipse.jdt.internal.compiler.problem.*;
import org.eclipse.jdt.internal.compiler.util.hashtableofobjecttoint;
import org.eclipse.jdt.internal.compiler.util.util;
import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.codeassist.impl.*;

public class completionparser extends assistparser {
// owner
protected static final int completion_parser = 1024;
protected static final int completion_or_assist_parser = assist_parser + completion_parser;

// kind : all values known by completionparser are between 1025 and 1549
protected static final int k_block_delimiter = completion_parser + 1; // whether we are inside a block
protected static final int k_selector_invocation_type = completion_parser + 2; // whether we are inside a message send
protected static final int k_selector_qualifier = completion_parser + 3; // whether we are inside a message send
protected static final int k_between_catch_and_right_paren = completion_parser + 4; // whether we are between the keyword 'catch' and the following ')'
protected static final int k_next_typeref_is_class = completion_parser + 5; // whether the next type reference is a class
protected static final int k_next_typeref_is_interface = completion_parser + 6; // whether the next type reference is an interface
protected static final int k_next_typeref_is_exception = completion_parser + 7; // whether the next type reference is an exception
protected static final int k_between_new_and_left_bracket = completion_parser + 8; // whether we are between the keyword 'new' and the following left braket, i.e. '[', '(' or '{'
protected static final int k_inside_throw_statement = completion_parser + 9; // whether we are between the keyword 'throw' and the end of a throw statement
protected static final int k_inside_return_statement = completion_parser + 10; // whether we are between the keyword 'return' and the end of a return statement
protected static final int k_cast_statement = completion_parser + 11; // whether we are between ')' and the end of a cast statement
protected static final int k_local_initializer_delimiter = completion_parser + 12;
protected static final int k_array_initializer = completion_parser + 13;
protected static final int k_array_creation = completion_parser + 14;
protected static final int k_unary_operator = completion_parser + 15;
protected static final int k_binary_operator = completion_parser + 16;
protected static final int k_assisgnment_operator = completion_parser + 17;
protected static final int k_conditional_operator = completion_parser + 18;
protected static final int k_between_if_and_right_paren = completion_parser + 19;
protected static final int k_between_while_and_right_paren = completion_parser + 20;
protected static final int k_between_for_and_right_paren = completion_parser + 21;
protected static final int k_between_switch_and_right_paren = completion_parser + 22;
protected static final int k_between_synchronized_and_right_paren = completion_parser + 23;
protected static final int k_inside_assert_statement = completion_parser + 24;
protected static final int k_switch_label= completion_parser + 25;
protected static final int k_between_case_and_colon = completion_parser + 26;
protected static final int k_between_default_and_colon = completion_parser + 27;
protected static final int k_between_left_and_right_bracket = completion_parser + 28;
protected static final int k_extends_keyword = completion_parser + 29;
protected static final int k_parameterized_method_invocation = completion_parser + 30;
protected static final int k_parameterized_allocation = completion_parser + 31;
protected static final int k_parameterized_cast = completion_parser + 32;
protected static final int k_between_annotation_name_and_rparen = completion_parser + 33;
protected static final int k_inside_break_statement = completion_parser + 34;
protected static final int k_inside_continue_statement = completion_parser + 35;
protected static final int k_label = completion_parser + 36;
protected static final int k_member_value_array_initializer = completion_parser + 37;
protected static final int k_control_statement_delimiter = completion_parser + 38;
protected static final int k_inside_assert_exception = completion_parser + 39;
protected static final int k_inside_for_conditional = completion_parser + 40;
// added for https://bugs.eclipse.org/bugs/show_bug.cgi?id=261534
protected static final int k_between_instanceof_and_rparen = completion_parser + 41;


public final static char[] fake_type_name = new char[]{' '};
public final static char[] fake_method_name = new char[]{' '};
public final static char[] fake_argument_name = new char[]{' '};
public final static char[] value = new char[]{'v', 'a', 'l', 'u', 'e'};

/* public fields */

public int cursorlocation;
public astnode assistnodeparent; // the parent node of assist node
public astnode enclosingnode; // an enclosing node used by proposals inference

/* the following fields are internal flags */

// block kind
static final int if = 1;
static final int try = 2;
static final int catch = 3;
static final int while = 4;
static final int switch = 5;
static final int for = 6;
static final int do = 7;
static final int synchronized = 8;

// label kind
static final int default = 1;

// invocation type constants
static final int explicit_receiver = 0;
static final int no_receiver = -1;
static final int super_receiver = -2;
static final int name_receiver = -3;
static final int allocation = -4;
static final int qualified_allocation = -5;

static final int question = 1;
static final int colon = 2;

// k_between_annotation_name_and_rparen arguments
static final int lparen_not_consumed = 1;
static final int lparen_consumed = 2;
static final int annotation_name_completion = 4;

// k_parameterized_method_invocation arguments
static final int inside_name = 1;

// the type of the current invocation (one of the invocation type constants)
int invocationtype;

// a pointer in the expression stack to the qualifier of a invocation
int qualifier;

// used to find if there is unused modifiers when building completion inside a method or an initializer
boolean hasunusedmodifiers;

// show if the current token can be an explicit constructor
int canbeexplicitconstructor = no;
static final int no = 0;
static final int nexttoken = 1;
static final int yes = 2;

protected static final int labelstackincrement = 10;
char[][] labelstack = new char[labelstackincrement][];
int labelptr = -1;

boolean isalreadyattached;

public boolean record = false;
public boolean skiprecord = false;
public int recordfrom;
public int recordto;
public int potentialvariablenamesptr;
public char[][] potentialvariablenames;
public int[] potentialvariablenamestarts;
public int[] potentialvariablenameends;

completiononannotationoftype pendingannotation;

private boolean storesourceends;
public hashtableofobjecttoint sourceends;

public completionparser(problemreporter problemreporter, boolean storeextrasourceends) {
super(problemreporter);
this.reportsyntaxerrorisrequired = false;
this.javadocparser.checkdoccomment = true;
this.annotationrecoveryactivated = false;
if (storeextrasourceends) {
this.storesourceends = true;
this.sourceends = new hashtableofobjecttoint();
}
}
private void addpotentialname(char[] potentialvariablename, int start, int end) {
int length = this.potentialvariablenames.length;
if (this.potentialvariablenamesptr >= length - 1) {
system.arraycopy(
this.potentialvariablenames,
0,
this.potentialvariablenames = new char[length * 2][],
0,
length);
system.arraycopy(
this.potentialvariablenamestarts,
0,
this.potentialvariablenamestarts = new int[length * 2],
0,
length);
system.arraycopy(
this.potentialvariablenameends,
0,
this.potentialvariablenameends = new int[length * 2],
0,
length);
}
this.potentialvariablenames[++this.potentialvariablenamesptr] = potentialvariablename;
this.potentialvariablenamestarts[this.potentialvariablenamesptr] = start;
this.potentialvariablenameends[this.potentialvariablenamesptr] = end;
}
public void startrecordingidentifiers(int from, int to) {
this.record = true;
this.skiprecord = false;
this.recordfrom = from;
this.recordto = to;

this.potentialvariablenamesptr = -1;
this.potentialvariablenames = new char[10][];
this.potentialvariablenamestarts = new int[10];
this.potentialvariablenameends = new int[10];
}
public void stoprecordingidentifiers() {
this.record = true;
this.skiprecord = false;
}
public char[] assistidentifier(){
return ((completionscanner)this.scanner).completionidentifier;
}
protected void attachorphancompletionnode(){
if(this.assistnode == null || this.isalreadyattached) return;

this.isalreadyattached = true;

if (this.isorphancompletionnode) {
astnode orphan = this.assistnode;
this.isorphancompletionnode = false;

if (this.currentelement instanceof recoveredunit){
if (orphan instanceof importreference){
this.currentelement.add((importreference)orphan, 0);
}
}

/* if in context of a type, then persists the identifier into a fake field return type */
if (this.currentelement instanceof recoveredtype){
recoveredtype recoveredtype = (recoveredtype)this.currentelement;
/* filter out cases where scanner is still inside type header */
if (recoveredtype.foundopeningbrace) {
/* generate a pseudo field with a completion on type reference */
if (orphan instanceof typereference){
typereference fieldtype;

int kind = topknownelementkind(completion_or_assist_parser);
int info = topknownelementinfo(completion_or_assist_parser);
if(kind == k_binary_operator && info == less && this.identifierptr > -1) {
if(this.genericslengthstack[this.genericslengthptr] > 0) {
consumetypearguments();
}
pushongenericsstack(orphan);
consumetypearguments();
fieldtype = gettypereference(0);
this.assistnodeparent = fieldtype;
} else {
fieldtype = (typereference)orphan;
}

completiononfieldtype fielddeclaration = new completiononfieldtype(fieldtype, false);

// retrieve annotations if any
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr]) != 0 &&
this.expressionstack[this.expressionptr] instanceof annotation) {
system.arraycopy(
this.expressionstack,
this.expressionptr - length + 1,
fielddeclaration.annotations = new annotation[length],
0,
length);
}

// retrieve available modifiers if any
if (this.intptr >= 2 && this.intstack[this.intptr-1] == this.lastmodifiersstart && this.intstack[this.intptr-2] == this.lastmodifiers){
fielddeclaration.modifierssourcestart = this.intstack[this.intptr-1];
fielddeclaration.modifiers = this.intstack[this.intptr-2];
}

this.currentelement = this.currentelement.add(fielddeclaration, 0);
return;
}
}
}
/* if in context of a method, persists if inside arguments as a type */
if (this.currentelement instanceof recoveredmethod){
recoveredmethod recoveredmethod = (recoveredmethod)this.currentelement;
/* only consider if inside method header */
if (!recoveredmethod.foundopeningbrace) {
//if (rparenpos < lparenpos){ // inside arguments
if (orphan instanceof typereference){
this.currentelement = this.currentelement.parent.add(
new completiononfieldtype((typereference)orphan, true), 0);
return;
}

if(orphan instanceof annotation) {
completiononannotationoftype faketype =
new completiononannotationoftype(
fake_type_name,
this.compilationunit.compilationresult(),
(annotation)orphan);
faketype.isparameter = true;
this.currentelement.parent.add(faketype, 0);
this.pendingannotation = faketype;
return;
}
}
}

if(orphan instanceof membervaluepair) {
buildmoreannotationcompletioncontext((membervaluepair) orphan);
return;
}

if(orphan instanceof annotation) {
popuntilcompletedannotationifnecessary();

completiononannotationoftype faketype =
new completiononannotationoftype(
fake_type_name,
this.compilationunit.compilationresult(),
(annotation)orphan);
this.currentelement.add(faketype, 0);

if (!isinsideannotation()) {
this.pendingannotation = faketype;
}

return;
}

if ((topknownelementkind(completion_or_assist_parser) == k_between_catch_and_right_paren)) {
if (this.assistnode instanceof completiononsingletypereference &&
((completiononsingletypereference)this.assistnode).isexception()) {
buildmoretrystatementcompletioncontext((typereference)this.assistnode);
return;
} else if (this.assistnode instanceof completiononqualifiedtypereference &&
((completiononqualifiedtypereference)this.assistnode).isexception()) {
buildmoretrystatementcompletioncontext((typereference)this.assistnode);
return;
} else if (this.assistnode instanceof completiononparameterizedqualifiedtypereference &&
((completiononparameterizedqualifiedtypereference)this.assistnode).isexception()) {
buildmoretrystatementcompletioncontext((typereference)this.assistnode);
return;
}
}

// add the completion node to the method declaration or constructor declaration
if (orphan instanceof statement) {
/* check for completion at the beginning of method body
behind an invalid signature
*/
recoveredmethod method = this.currentelement.enclosingmethod();
if (method != null){
abstractmethoddeclaration methoddecl = method.methoddeclaration;
if ((methoddecl.bodystart == methoddecl.sourceend+1) // was missing opening brace
&& (util.getlinenumber(orphan.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr)
== util.getlinenumber(methoddecl.sourceend, this.scanner.lineends, 0, this.scanner.lineptr))){
return;
}
}
// add the completion node as a statement to the list of block statements
this.currentelement = this.currentelement.add((statement)orphan, 0);
return;
}
}

if (isinsideannotation()) {
// push top expression on ast stack if it contains the completion node
expression expression;
if (this.expressionptr > -1) {
expression = this.expressionstack[this.expressionptr];
if(expression == this.assistnode) {
if (this.topknownelementkind(completion_or_assist_parser) == k_member_value_array_initializer ) {
arrayinitializer arrayinitializer = new arrayinitializer();
arrayinitializer.expressions = new expression[]{expression};

membervaluepair valuepair =
new membervaluepair(value, expression.sourcestart, expression.sourceend, arrayinitializer);
buildmoreannotationcompletioncontext(valuepair);
} else if(this.topknownelementkind(completion_or_assist_parser) == k_between_annotation_name_and_rparen) {
if (expression instanceof singlenamereference) {
singlenamereference namereference = (singlenamereference) expression;
completiononmembervaluename membervaluename = new completiononmembervaluename(namereference.token, namereference.sourcestart, namereference.sourceend);

buildmoreannotationcompletioncontext(membervaluename);
return;
} else if (expression instanceof qualifiednamereference || expression instanceof stringliteral) {
membervaluepair valuepair =
new membervaluepair(value, expression.sourcestart, expression.sourceend, expression);
buildmoreannotationcompletioncontext(valuepair);
}
} else {
int index;
if((index = lastindexofelement(k_attribute_value_delimiter)) != -1) {
int attributeindentifierptr = this.elementinfostack[index];
int identlengthptr = this.identifierlengthptr;
int identptr = this.identifierptr;
while (attributeindentifierptr < identptr) {
identptr -= this.identifierlengthstack[identlengthptr--];
}

if(attributeindentifierptr != identptr) return;

this.identifierlengthptr = identlengthptr;
this.identifierptr = identptr;

this.identifierlengthptr--;
membervaluepair membervaluepair = new membervaluepair(
this.identifierstack[this.identifierptr--],
expression.sourcestart,
expression.sourceend,
expression);

buildmoreannotationcompletioncontext(membervaluepair);
return;
}
}
} else {
completionnodedetector detector =  new completionnodedetector(this.assistnode, expression);
if(detector.containscompletionnode()) {
membervaluepair valuepair =
new membervaluepair(value, expression.sourcestart, expression.sourceend, expression);
buildmoreannotationcompletioncontext(valuepair);
}
}
}

if (this.astptr > -1) {
astnode node = this.aststack[this.astptr];
if(node instanceof membervaluepair) {
membervaluepair membervaluepair = (membervaluepair) node;
completionnodedetector detector =  new completionnodedetector(this.assistnode, membervaluepair);
if(detector.containscompletionnode()) {
buildmoreannotationcompletioncontext(membervaluepair);
this.assistnodeparent = detector.getcompletionnodeparent();
return;
}
}
}
}

if(this.genericsptr > -1) {
astnode node = this.genericsstack[this.genericsptr];
if(node instanceof wildcard && ((wildcard)node).bound == this.assistnode){
int kind = topknownelementkind(completion_or_assist_parser);
if (kind == k_binary_operator) {
int info = topknownelementinfo(completion_or_assist_parser);
if (info == less) {
buildmoregenericscompletioncontext(node, true);
return;
}
}
if(this.identifierlengthptr > -1 && this.identifierlengthstack[this.identifierlengthptr]!= 0) {
this.pushonelementstack(k_binary_operator, less);
buildmoregenericscompletioncontext(node, false);
return;
}
}
}

if(this.currentelement instanceof recoveredtype || this.currentelement instanceof recoveredmethod) {
if(this.currentelement instanceof recoveredtype) {
recoveredtype recoveredtype = (recoveredtype)this.currentelement;
if(recoveredtype.foundopeningbrace && this.genericsptr > -1) {
if(this.genericsstack[this.genericsptr] instanceof typeparameter) {
typeparameter typeparameter = (typeparameter) this.genericsstack[this.genericsptr];
completionnodedetector detector =  new completionnodedetector(this.assistnode, typeparameter);
if(detector.containscompletionnode()) {
this.currentelement.add(new completiononmethodtypeparameter(new typeparameter[]{typeparameter},this.compilationunit.compilationresult()), 0);
}
return;
}
}
}

if ((!isinsidemethod() && !isinsidefieldinitialization())) {
if(this.genericsptr > -1 && this.genericslengthptr > -1 && this.genericsidentifierslengthptr > -1) {
int kind = topknownelementkind(completion_or_assist_parser);
int info = topknownelementinfo(completion_or_assist_parser);
if(kind == k_binary_operator && info == less) {
consumetypearguments();
}
int numberofidentifiers = this.genericsidentifierslengthstack[this.genericsidentifierslengthptr];
int genptr = this.genericsptr;
done : for(int i = 0; i <= this.identifierlengthptr && numberofidentifiers > 0; i++){
int identifierlength = this.identifierlengthstack[this.identifierlengthptr - i];
int length = this.genericslengthstack[this.genericslengthptr - i];
for(int j = 0; j < length; j++) {
astnode node = this.genericsstack[genptr - j];
completionnodedetector detector = new completionnodedetector(this.assistnode, node);
if(detector.containscompletionnode()) {
if(node == this.assistnode){
if(this.identifierlengthptr > -1 &&	this.identifierlengthstack[this.identifierlengthptr]!= 0) {
typereference ref = this.gettypereference(0);
this.assistnodeparent = ref;
}
} else {
this.assistnodeparent = detector.getcompletionnodeparent();
}
break done;
}
}
genptr -= length;
numberofidentifiers -= identifierlength;
}
if(this.assistnodeparent != null && this.assistnodeparent instanceof typereference) {
if(this.currentelement instanceof recoveredtype) {
this.currentelement = this.currentelement.add(new completiononfieldtype((typereference)this.assistnodeparent, false), 0);
} else {
this.currentelement = this.currentelement.add((typereference)this.assistnodeparent, 0);
}
}
}
}
}

// the following code applies only in methods, constructors or initializers
if ((!isinsidemethod() && !isinsidefieldinitialization() && !isinsideattributevalue())) {
return;
}

if(this.genericsptr > -1) {
astnode node = this.genericsstack[this.genericsptr];
completionnodedetector detector = new completionnodedetector(this.assistnode, node);
if(detector.containscompletionnode()) {
/* check for completion at the beginning of method body
behind an invalid signature
*/
recoveredmethod method = this.currentelement.enclosingmethod();
if (method != null){
abstractmethoddeclaration methoddecl = method.methoddeclaration;
if ((methoddecl.bodystart == methoddecl.sourceend+1) // was missing opening brace
&& (util.getlinenumber(node.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr)
== util.getlinenumber(methoddecl.sourceend, this.scanner.lineends, 0, this.scanner.lineptr))){
return;
}
}
if(node == this.assistnode){
buildmoregenericscompletioncontext(node, true);
}
}
}

// push top expression on ast stack if it contains the completion node
expression expression;
if (this.expressionptr > -1) {
expression = this.expressionstack[this.expressionptr];
completionnodedetector detector = new completionnodedetector(this.assistnode, expression);
if(detector.containscompletionnode()) {
/* check for completion at the beginning of method body
behind an invalid signature
*/
recoveredmethod method = this.currentelement.enclosingmethod();
if (method != null){
abstractmethoddeclaration methoddecl = method.methoddeclaration;
if ((methoddecl.bodystart == methoddecl.sourceend+1) // was missing opening brace
&& (util.getlinenumber(expression.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr)
== util.getlinenumber(methoddecl.sourceend, this.scanner.lineends, 0, this.scanner.lineptr))){
return;
}
}
if(expression == this.assistnode
|| (expression instanceof assignment	// https://bugs.eclipse.org/bugs/show_bug.cgi?id=287939
&& ((assignment)expression).expression == this.assistnode
&& ((this.expressionptr > 0 && this.expressionstack[this.expressionptr - 1] instanceof instanceofexpression)
|| (this.elementptr >= 0 && this.elementobjectinfostack[this.elementptr] instanceof instanceofexpression)))
|| (expression instanceof allocationexpression
&& ((allocationexpression)expression).type == this.assistnode)
|| (expression instanceof and_and_expression
&& (this.elementptr >= 0 && this.elementobjectinfostack[this.elementptr] instanceof instanceofexpression))){
buildmorecompletioncontext(expression);
if (this.assistnodeparent == null
&& expression instanceof assignment) {
this.assistnodeparent = detector.getcompletionnodeparent();
}
return;
} else {
this.assistnodeparent = detector.getcompletionnodeparent();
if(this.assistnodeparent != null) {
this.currentelement = this.currentelement.add((statement)this.assistnodeparent, 0);
} else {
this.currentelement = this.currentelement.add(expression, 0);
}
return;
}
}
}
if (this.astptr > -1 && this.aststack[this.astptr] instanceof localdeclaration) { // https://bugs.eclipse.org/bugs/show_bug.cgi?id=287939
// to take care of:  if (a instance of x)  int i = a.|
localdeclaration local = (localdeclaration) this.aststack[this.astptr];
if (local.initialization == this.assistnode) {
statement enclosing = buildmorecompletionenclosingcontext(local);
if (enclosing instanceof ifstatement) {
if (this.currentelement instanceof recoveredblock) {
// recoveredlocalvariable must be removed from its parent because the ifstatement will be added instead
recoveredblock recoveredblock = (recoveredblock) this.currentelement;
recoveredblock.statements[--recoveredblock.statementcount] = null;
this.currentelement = this.currentelement.add(enclosing, 0);
}
}
}
}
}
public object becomesimpleparser() {
completionscanner completionscanner = (completionscanner)this.scanner;
int[] parserstate = new int[] {this.cursorlocation, completionscanner.cursorlocation};

this.cursorlocation = integer.max_value;
completionscanner.cursorlocation = integer.max_value;

return parserstate;
}
private void buildmoreannotationcompletioncontext(membervaluepair membervaluepair) {
if(this.identifierptr < 0 || this.identifierlengthptr < 0 ) return;

typereference typereference = getannotationtype();

int nodestoremove = this.astptr > -1 && this.aststack[this.astptr] == membervaluepair ? 1 : 0;

normalannotation annotation;
if (membervaluepair instanceof completiononmembervaluename) {
membervaluepair[] membervaluepairs = null;
int length;
if (this.astlengthptr > -1 && (length = this.astlengthstack[this.astlengthptr--]) > nodestoremove) {
if (this.aststack[this.astptr] instanceof membervaluepair) {
system.arraycopy(
this.aststack,
(this.astptr -= length) + 1,
membervaluepairs = new membervaluepair[length - nodestoremove],
0,
length - nodestoremove);
}
}
annotation =
new completiononannotationmembervaluepair(
typereference,
this.intstack[this.intptr--],
membervaluepairs,
membervaluepair);

this.assistnode = membervaluepair;
this.assistnodeparent = annotation;

if (membervaluepair.sourceend >= this.lastcheckpoint) {
this.lastcheckpoint = membervaluepair.sourceend + 1;
}
} else {
membervaluepair[] membervaluepairs = null;
int length = 0;
if (this.astlengthptr > -1 && (length = this.astlengthstack[this.astlengthptr--]) > nodestoremove) {
if (this.aststack[this.astptr] instanceof membervaluepair) {
system.arraycopy(
this.aststack,
(this.astptr -= length) + 1,
membervaluepairs = new membervaluepair[length - nodestoremove + 1],
0,
length - nodestoremove);
}
if(membervaluepairs != null) {
membervaluepairs[length - nodestoremove] = membervaluepair;
} else {
membervaluepairs = new membervaluepair[]{membervaluepair};
}
} else {
membervaluepairs = new membervaluepair[]{membervaluepair};
}

annotation =
new normalannotation(
typereference,
this.intstack[this.intptr--]);
annotation.membervaluepairs = membervaluepairs;

}
completiononannotationoftype faketype =
new completiononannotationoftype(
fake_type_name,
this.compilationunit.compilationresult(),
annotation);

this.currentelement.add(faketype, 0);
this.pendingannotation = faketype;
}
private void buildmorecompletioncontext(expression expression) {
statement statement = expression;
int kind = topknownelementkind(completion_or_assist_parser);
if(kind != 0) {
int info = topknownelementinfo(completion_or_assist_parser);
nextelement : switch (kind) {
case k_selector_qualifier :
int selector = topknownelementinfo(completion_or_assist_parser, 2);
if(selector == this_constructor || selector == super_constructor) {
explicitconstructorcall call = new explicitconstructorcall(
(selector == this_constructor) ?
explicitconstructorcall.this :
explicitconstructorcall.super
);
call.arguments = new expression[] {expression};
call.sourcestart = expression.sourcestart;
call.sourceend = expression.sourceend;
this.assistnodeparent = call;
} else {
int invoctype = topknownelementinfo(completion_or_assist_parser,1);
int qualifierexprptr = info;

// find arguments
int length = this.expressionlengthstack[this.expressionlengthptr];

// search previous arguments if missing
if(this.expressionptr > 0 && this.expressionlengthptr > 0 && length == 1) {
int start = (int) (this.identifierpositionstack[selector] >>> 32);
if(this.expressionstack[this.expressionptr-1] != null && this.expressionstack[this.expressionptr-1].sourcestart > start) {
length += this.expressionlengthstack[this.expressionlengthptr-1];
}

}

expression[] arguments = null;
if (length != 0) {
arguments = new expression[length];
this.expressionptr -= length;
system.arraycopy(this.expressionstack, this.expressionptr + 1, arguments, 0, length-1);
arguments[length-1] = expression;
}

if(invoctype != allocation && invoctype != qualified_allocation) {
messagesend messagesend = new messagesend();
messagesend.selector = this.identifierstack[selector];
messagesend.arguments = arguments;

// find receiver
switch (invoctype) {
case no_receiver:
messagesend.receiver = thisreference.implicitthis();
break;
case name_receiver:
// remove special flags for primitive types
while (this.identifierlengthptr >= 0 && this.identifierlengthstack[this.identifierlengthptr] < 0) {
this.identifierlengthptr--;
}

// remove selector
this.identifierptr--;
if(this.genericsptr > -1 && this.genericslengthptr > -1 && this.genericslengthstack[this.genericslengthptr] > 0) {
// is inside a paremeterized method: bar.<x>.foo
this.identifierlengthptr--;
} else {
this.identifierlengthstack[this.identifierlengthptr]--;
}
// consume the receiver
int identifierlength = this.identifierlengthstack[this.identifierlengthptr];
if(this.identifierptr > -1 && identifierlength > 0 && this.identifierptr + 1 >= identifierlength) {
messagesend.receiver = getunspecifiedreference();
} else {
messagesend = null;
}
break;
case super_receiver:
messagesend.receiver = new superreference(0, 0);
break;
case explicit_receiver:
messagesend.receiver = this.expressionstack[qualifierexprptr];
break;
default :
messagesend.receiver = thisreference.implicitthis();
break;
}
this.assistnodeparent = messagesend;
} else {
if(invoctype == allocation) {
allocationexpression allocationexpr = new allocationexpression();
allocationexpr.arguments = arguments;
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0);
allocationexpr.type = gettypereference(0);
this.assistnodeparent = allocationexpr;
} else {
qualifiedallocationexpression allocationexpr = new qualifiedallocationexpression();
allocationexpr.enclosinginstance = this.expressionstack[qualifierexprptr];
allocationexpr.arguments = arguments;
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0);

allocationexpr.type = gettypereference(0);
this.assistnodeparent = allocationexpr;
}
}
}
break nextelement;
case k_inside_return_statement :
if(info == this.bracketdepth) {
returnstatement returnstatement = new returnstatement(expression, expression.sourcestart, expression.sourceend);
this.assistnodeparent = returnstatement;
}
break nextelement;
case k_cast_statement :
expression casttype;
if(this.expressionptr > 0
&& ((casttype = this.expressionstack[this.expressionptr-1]) instanceof typereference)) {
castexpression cast = new castexpression(expression, casttype);
cast.sourcestart = casttype.sourcestart;
cast.sourceend= expression.sourceend;
this.assistnodeparent = cast;
}
break nextelement;
case k_unary_operator :
if(this.expressionptr > -1) {
expression operatorexpression = null;
switch (info) {
case plus_plus :
operatorexpression = new prefixexpression(expression,intliteral.one, plus, expression.sourcestart);
break;
case minus_minus :
operatorexpression = new prefixexpression(expression,intliteral.one, minus, expression.sourcestart);
break;
default :
operatorexpression = new unaryexpression(expression, info);
break;
}
this.assistnodeparent = operatorexpression;
}
break nextelement;
case k_binary_operator :
if(this.expressionptr > -1) {
expression operatorexpression = null;
expression left = null;
if(this.expressionptr == 0) {
// it is  a ***_notname rule
if(this.identifierptr > -1) {
left = getunspecifiedreferenceoptimized();
}
} else {
left = this.expressionstack[this.expressionptr-1];
// is it a ***_notname rule ?
if(this.identifierptr > -1) {
int start = (int) (this.identifierpositionstack[this.identifierptr] >>> 32);
if(left.sourcestart < start) {
left = getunspecifiedreferenceoptimized();
}
}
}

if(left != null) {
switch (info) {
case and_and :
operatorexpression = new and_and_expression(left, expression, info);
break;
case or_or :
operatorexpression = new or_or_expression(left, expression, info);
break;
case equal_equal :
case not_equal :
operatorexpression = new equalexpression(left, expression, info);
break;
default :
operatorexpression = new binaryexpression(left, expression, info);
break;
}
}
if(operatorexpression != null) {
this.assistnodeparent = operatorexpression;
}
}
break nextelement;
case k_array_initializer :
arrayinitializer arrayinitializer = new arrayinitializer();
arrayinitializer.expressions = new expression[]{expression};
this.expressionptr -= this.expressionlengthstack[this.expressionlengthptr--];

if(this.expressionlengthptr > -1
&& this.expressionptr > -1
&& this.expressionstack[this.expressionptr] != null
&& this.expressionstack[this.expressionptr].sourcestart > info) {
this.expressionlengthptr--;
}

this.lastcheckpoint = this.scanner.currentposition;

if(topknownelementkind(completion_or_assist_parser, 1) == k_array_creation) {
arrayallocationexpression allocationexpression = new arrayallocationexpression();
pushongenericslengthstack(0);
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
allocationexpression.type = gettypereference(0);
allocationexpression.type.bits |= astnode.ignorerawtypecheck; // no need to worry about raw type usage
int length = this.expressionlengthstack[this.expressionlengthptr];
allocationexpression.dimensions = new expression[length];

allocationexpression.initializer = arrayinitializer;
this.assistnodeparent = allocationexpression;
} else if(this.currentelement instanceof recoveredfield && !(this.currentelement instanceof recoveredinitializer)) {
recoveredfield recoveredfield = (recoveredfield) this.currentelement;
if(recoveredfield.fielddeclaration.type.dimensions() == 0) {
block block = new block(0);
block.sourcestart = info;
this.currentelement = this.currentelement.add(block, 1);
} else {
statement = arrayinitializer;
}
} else if(this.currentelement instanceof recoveredlocalvariable) {
recoveredlocalvariable recoveredlocalvariable = (recoveredlocalvariable) this.currentelement;
if(recoveredlocalvariable.localdeclaration.type.dimensions() == 0) {
block block = new block(0);
block.sourcestart = info;
this.currentelement = this.currentelement.add(block, 1);
} else {
statement = arrayinitializer;
}
} else {
statement = arrayinitializer;
}
break nextelement;
case k_array_creation :
arrayallocationexpression allocationexpression = new arrayallocationexpression();
allocationexpression.type = gettypereference(0);
allocationexpression.dimensions = new expression[]{expression};

this.assistnodeparent = allocationexpression;
break nextelement;
case k_assisgnment_operator :
if(this.expressionptr > 0 && this.expressionstack[this.expressionptr - 1] != null) {
assignment assignment;
if(info == equal) {
assignment = new assignment(
this.expressionstack[this.expressionptr - 1],
expression,
expression.sourceend
);
} else {
assignment = new compoundassignment(
this.expressionstack[this.expressionptr - 1],
expression,
info,
expression.sourceend
);
}
this.assistnodeparent = assignment;
}
break nextelement;
case k_conditional_operator :
if(info == question) {
if(this.expressionptr > 0) {
this.expressionptr--;
this.expressionlengthptr--;
this.expressionstack[this.expressionptr] = this.expressionstack[this.expressionptr+1];
popelement(k_conditional_operator);
buildmorecompletioncontext(expression);
return;
}
} else {
if(this.expressionptr > 1) {
this.expressionptr = this.expressionptr - 2;
this.expressionlengthptr = this.expressionlengthptr - 2;
this.expressionstack[this.expressionptr] = this.expressionstack[this.expressionptr+2];
popelement(k_conditional_operator);
buildmorecompletioncontext(expression);
return;
}
}
break nextelement;
case k_between_left_and_right_bracket :
arrayreference arrayreference;
if(this.identifierptr < 0 && this.expressionptr > 0 && this.expressionstack[this.expressionptr] == expression) {
arrayreference =
new arrayreference(
this.expressionstack[this.expressionptr-1],
expression);
} else {
arrayreference =
new arrayreference(
getunspecifiedreferenceoptimized(),
expression);
}
this.assistnodeparent = arrayreference;
break;
case k_between_case_and_colon :
if(this.expressionptr > 0) {
switchstatement switchstatement = new switchstatement();
switchstatement.expression = this.expressionstack[this.expressionptr - 1];
if(this.astlengthptr > -1 && this.astptr > -1) {
int length = this.astlengthstack[this.astlengthptr];
int newastptr = this.astptr - length;
astnode firstnode = this.aststack[newastptr + 1];
if(length != 0 && firstnode.sourcestart > switchstatement.expression.sourceend) {
switchstatement.statements = new statement[length + 1];
system.arraycopy(
this.aststack,
newastptr + 1,
switchstatement.statements,
0,
length);
}
}
casestatement casestatement = new casestatement(expression, expression.sourcestart, expression.sourceend);
if(switchstatement.statements == null) {
switchstatement.statements = new statement[]{casestatement};
} else {
switchstatement.statements[switchstatement.statements.length - 1] = casestatement;
}
this.assistnodeparent = switchstatement;
}
break;
case k_between_if_and_right_paren :
ifstatement ifstatement = new ifstatement(expression, new emptystatement(expression.sourceend, expression.sourceend), expression.sourcestart, expression.sourceend);
this.assistnodeparent = ifstatement;
break nextelement;
case k_between_while_and_right_paren :
whilestatement whilestatement = new whilestatement(expression, new emptystatement(expression.sourceend, expression.sourceend), expression.sourcestart, expression.sourceend);
this.assistnodeparent = whilestatement;
break nextelement;
case k_inside_for_conditional: // https://bugs.eclipse.org/bugs/show_bug.cgi?id=253008
forstatement forstatement = new forstatement(new statement[0], expression, new statement[0],
new emptystatement(expression.sourceend, expression.sourceend),
false,
expression.sourcestart, expression.sourceend);
this.assistnodeparent = forstatement;
break nextelement;
case k_between_switch_and_right_paren:
switchstatement switchstatement = new switchstatement();
switchstatement.expression = expression;
switchstatement.statements = new statement[0];
this.assistnodeparent = switchstatement;
break nextelement;
case k_between_synchronized_and_right_paren :
synchronizedstatement synchronizedstatement = new synchronizedstatement(expression, new block(0), expression.sourcestart, expression.sourceend);
this.assistnodeparent = synchronizedstatement;
break nextelement;
case k_inside_throw_statement:
if(info == this.bracketdepth) {
throwstatement throwstatement = new throwstatement(expression, expression.sourcestart, expression.sourceend);
this.assistnodeparent = throwstatement;
}
break nextelement;
case k_inside_assert_statement:
if(info == this.bracketdepth) {
assertstatement assertstatement = new assertstatement(expression, expression.sourcestart);
this.assistnodeparent = assertstatement;
}
break nextelement;
case k_inside_assert_exception:
if(info == this.bracketdepth) {
assertstatement assertstatement = new assertstatement(expression, new trueliteral(expression.sourcestart, expression.sourcestart), expression.sourcestart);
this.assistnodeparent = assertstatement;
}
break nextelement;
}
}
if(this.assistnodeparent != null) {
this.currentelement = this.currentelement.add(buildmorecompletionenclosingcontext((statement)this.assistnodeparent), 0);
} else {
if(this.currentelement instanceof recoveredfield && !(this.currentelement instanceof recoveredinitializer)
&& ((recoveredfield) this.currentelement).fielddeclaration.initialization == null) {

this.assistnodeparent = ((recoveredfield) this.currentelement).fielddeclaration;
this.currentelement = this.currentelement.add(buildmorecompletionenclosingcontext(statement), 0);
} else if(this.currentelement instanceof recoveredlocalvariable
&& ((recoveredlocalvariable) this.currentelement).localdeclaration.initialization == null) {

this.assistnodeparent = ((recoveredlocalvariable) this.currentelement).localdeclaration;
this.currentelement = this.currentelement.add(buildmorecompletionenclosingcontext(statement), 0);
} else {
this.currentelement = this.currentelement.add(buildmorecompletionenclosingcontext(expression), 0);
}
}
}
private statement buildmorecompletionenclosingcontext(statement statement) {

int blockindex = lastindexofelement(k_block_delimiter);
int controlindex = lastindexofelement(k_control_statement_delimiter);
int index;
if (controlindex != -1) {
index = blockindex != -1 && controlindex < blockindex ? blockindex : controlindex;
} else {
// to handle the case when the completion is requested before enclosing r_paren
// and an instanceof expression is also present
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=261534
int instanceofindex = lastindexofelement(k_between_instanceof_and_rparen);
index = blockindex != -1 && instanceofindex < blockindex ? blockindex : instanceofindex;
}
if (index != -1 && this.elementinfostack[index] == if && this.elementobjectinfostack[index] != null) {
expression condition = (expression)this.elementobjectinfostack[index];

// if currentelement is a recoveredlocalvariable then it can be contained in the if statement
if (this.currentelement instanceof recoveredlocalvariable &&
this.currentelement.parent instanceof recoveredblock) {
recoveredlocalvariable recoveredlocalvariable = (recoveredlocalvariable) this.currentelement;
if (recoveredlocalvariable.localdeclaration.initialization == null &&
statement instanceof expression &&
condition.sourcestart < recoveredlocalvariable.localdeclaration.sourcestart) {
this.currentelement.add(statement, 0);

statement = recoveredlocalvariable.updatedstatement(0, new hashset());

// recoveredlocalvariable must be removed from its parent because the ifstatement will be added instead
recoveredblock recoveredblock =  (recoveredblock) recoveredlocalvariable.parent;
recoveredblock.statements[--recoveredblock.statementcount] = null;

this.currentelement = recoveredblock;

}
}
if (statement instanceof and_and_expression && this.assistnode instanceof statement) {
statement = (statement) this.assistnode;
}
ifstatement ifstatement =
new ifstatement(
condition,
statement,
condition.sourcestart,
statement.sourceend);
this.enclosingnode = ifstatement;
return ifstatement;
}

return statement;
}
private void buildmoregenericscompletioncontext(astnode node, boolean consumetypearguments) {
int kind = topknownelementkind(completion_or_assist_parser);
if(kind != 0) {
int info = topknownelementinfo(completion_or_assist_parser);
nextelement : switch (kind) {
case k_binary_operator :
int prevkind = topknownelementkind(completion_or_assist_parser, 1);
switch (prevkind) {
case k_parameterized_allocation :
if(this.invocationtype == allocation || this.invocationtype == qualified_allocation) {
this.currentelement = this.currentelement.add((typereference)node, 0);
}
break nextelement;
case k_parameterized_method_invocation :
if(topknownelementinfo(completion_or_assist_parser, 1) == 0) {
this.currentelement = this.currentelement.add((typereference)node, 0);
break nextelement;
}
}
if(info == less && node instanceof typereference) {
if(this.identifierlengthptr > -1 && this.identifierlengthstack[this.identifierlengthptr]!= 0) {
if (consumetypearguments) consumetypearguments();
typereference ref = this.gettypereference(0);
if(prevkind == k_parameterized_cast) {
ref = computequalifiedgenericsfromrightside(ref, 0);
}
if(this.currentelement instanceof recoveredtype) {
this.currentelement = this.currentelement.add(new completiononfieldtype(ref, false), 0);
} else {
this.currentelement = this.currentelement.add(ref, 0);
}
} else if (this.currentelement.enclosingmethod() != null &&
this.currentelement.enclosingmethod().methoddeclaration.isconstructor()) {
this.currentelement = this.currentelement.add((typereference)node, 0);
}
}
break;
}
}
}
private void buildmoretrystatementcompletioncontext(typereference exceptionref) {
if (this.astlengthptr > -1 &&
this.astptr > 1 &&
this.aststack[this.astptr] instanceof block &&
this.aststack[this.astptr - 1] instanceof argument) {
trystatement trystatement = new trystatement();

int newastptr = this.astptr;

int length = this.astlengthstack[this.astlengthptr];
block[] bks = (trystatement.catchblocks = new block[length + 1]);
argument[] args = (trystatement.catcharguments = new argument[length + 1]);
if (length != 0) {
while (length-- > 0) {
bks[length] = (block) this.aststack[newastptr--];
bks[length].statements = null; // statements of catch block won't be used
args[length] = (argument) this.aststack[newastptr--];
}
}

bks[bks.length - 1] = new block(0);
args[args.length - 1] = new argument(fake_argument_name,0,exceptionref,0);

trystatement.tryblock = (block) this.aststack[newastptr--];

this.assistnodeparent = trystatement;

this.currentelement.add(trystatement, 0);
} else if (this.astlengthptr > -1 &&
this.astptr > -1 &&
this.aststack[this.astptr] instanceof block) {
trystatement trystatement = new trystatement();

int newastptr = this.astptr;

block[] bks = (trystatement.catchblocks = new block[1]);
argument[] args = (trystatement.catcharguments = new argument[1]);

bks[0] = new block(0);
args[0] = new argument(fake_argument_name,0,exceptionref,0);

trystatement.tryblock = (block) this.aststack[newastptr--];

this.assistnodeparent = trystatement;

this.currentelement.add(trystatement, 0);
}else {
this.currentelement = this.currentelement.add(exceptionref, 0);
}
}
public int bodyend(abstractmethoddeclaration method){
return this.cursorlocation;
}
public int bodyend(initializer initializer){
return this.cursorlocation;
}
protected void checkandsetmodifiers(int flag) {
super.checkandsetmodifiers(flag);

if (isinsidemethod()) {
this.hasunusedmodifiers = true;
}
}
/**
* checks if the completion is on the exception type of a catch clause.
* returns whether we found a completion node.
*/
private boolean checkcatchclause() {
if ((topknownelementkind(completion_or_assist_parser) == k_between_catch_and_right_paren) && this.identifierptr > -1) {
// nb: if the cursor is on the variable, then it has been reduced (so identifierptr is -1),
//     thus this can only be a completion on the type of the catch clause
pushonelementstack(k_next_typeref_is_exception);
this.assistnode = gettypereference(0);
popelement(k_next_typeref_is_exception);
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
return true;
}
return false;
}
/**
* checks if the completion is on the type following a 'new'.
* returns whether we found a completion node.
*/
private boolean checkclassinstancecreation() {
if (topknownelementkind(completion_or_assist_parser) == k_between_new_and_left_bracket) {
int length = this.identifierlengthstack[this.identifierlengthptr];
int numberofidentifiers = this.genericsidentifierslengthstack[this.genericsidentifierslengthptr];
if (length != numberofidentifiers || this.genericslengthstack[this.genericslengthptr] != 0) {
// no class instance creation with a parameterized type
return true;
}

// completion on type inside an allocation expression

typereference type;
if (this.invocationtype == allocation) {
// non qualified allocation expression
allocationexpression allocexpr = new allocationexpression();
if (topknownelementkind(completion_or_assist_parser, 1) == k_inside_throw_statement
&& topknownelementinfo(completion_or_assist_parser, 1) == this.bracketdepth) {
pushonelementstack(k_next_typeref_is_exception);
type = gettypereference(0);
popelement(k_next_typeref_is_exception);
} else {
type = gettypereference(0);
}
if(type instanceof completiononsingletypereference) {
((completiononsingletypereference)type).isconstructortype = true;
} else if (type instanceof completiononqualifiedtypereference) {
((completiononqualifiedtypereference)type).isconstructortype = true;
}
allocexpr.type = type;
allocexpr.sourcestart = type.sourcestart;
allocexpr.sourceend = type.sourceend;
pushonexpressionstack(allocexpr);
this.isorphancompletionnode = false;
} else {
// qualified allocation expression
qualifiedallocationexpression allocexpr = new qualifiedallocationexpression();
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0);
if (topknownelementkind(completion_or_assist_parser, 1) == k_inside_throw_statement
&& topknownelementinfo(completion_or_assist_parser, 1) == this.bracketdepth) {
pushonelementstack(k_next_typeref_is_exception);
type = gettypereference(0);
popelement(k_next_typeref_is_exception);
} else {
type = gettypereference(0);
}
if(type instanceof completiononsingletypereference) {
((completiononsingletypereference)type).isconstructortype = true;
}
allocexpr.type = type;
allocexpr.enclosinginstance = this.expressionstack[this.qualifier];
allocexpr.sourcestart = this.intstack[this.intptr--];
allocexpr.sourceend = type.sourceend;
this.expressionstack[this.qualifier] = allocexpr; // attach it now (it replaces the qualifier expression)
this.isorphancompletionnode = false;
}
this.assistnode = type;
this.lastcheckpoint = type.sourceend + 1;

popelement(k_between_new_and_left_bracket);
return true;
}
return false;
}
/**
* checks if the completion is on the dot following an array type,
* a primitive type or an primitive array type.
* returns whether we found a completion node.
*/
private boolean checkclassliteralaccess() {
if (this.identifierlengthptr >= 1 && this.previoustoken == tokennamedot) { // (nb: the top id length is 1 and it is for the completion identifier)
int length;
// if the penultimate id length is negative,
// the completion is after a primitive type or a primitive array type
if ((length = this.identifierlengthstack[this.identifierlengthptr-1]) < 0) {
// build the primitive type node
int dim = isafterarraytype() ? this.intstack[this.intptr--] : 0;
singletypereference typeref = (singletypereference)typereference.basetypereference(-length, dim);
typeref.sourcestart = this.intstack[this.intptr--];
if (dim == 0) {
typeref.sourceend = this.intstack[this.intptr--];
} else {
this.intptr--;
typeref.sourceend = this.endposition;
}
//typeref.sourceend = typeref.sourcestart + typeref.token.length; // nb: it's ok to use the length of the token since it doesn't contain any unicode

// find the completion identifier and its source positions
char[] source = this.identifierstack[this.identifierptr];
long pos = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--; // it can only be a simple identifier (so its length is one)

// build the completion on class literal access node
completiononclassliteralaccess access = new completiononclassliteralaccess(pos, typeref);
access.completionidentifier = source;
this.identifierlengthptr--; // pop the length that was used to say it is a primitive type
this.assistnode = access;
this.isorphancompletionnode = true;
return true;
}

// if the completion is after a regular array type
if (isafterarraytype()) {
// find the completion identifier and its source positions
char[] source = this.identifierstack[this.identifierptr];
long pos = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--; // it can only be a simple identifier (so its length is one)

// get the type reference
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0);

typereference typeref = gettypereference(this.intstack[this.intptr--]);

// build the completion on class literal access node
completiononclassliteralaccess access = new completiononclassliteralaccess(pos, typeref);
access.completionidentifier = source;
this.assistnode = access;
this.isorphancompletionnode = true;
return true;
}

}
return false;
}
private boolean checkkeyword() {
if (this.currentelement instanceof recoveredunit) {
recoveredunit unit = (recoveredunit) this.currentelement;
int index = -1;
if ((index = this.indexofassistidentifier()) > -1) {
int ptr = this.identifierptr - this.identifierlengthstack[this.identifierlengthptr] + index + 1;

char[] ident = this.identifierstack[ptr];
long pos = this.identifierpositionstack[ptr];

char[][] keywords = new char[keywords.count][];
int count = 0;
if(unit.typecount == 0
&& this.lastmodifiers == classfileconstants.accdefault) {
keywords[count++] = keywords.import;
}
if(unit.typecount == 0
&& unit.importcount == 0
&& this.lastmodifiers == classfileconstants.accdefault
&& this.compilationunit.currentpackage == null) {
keywords[count++] = keywords.package;
}
if((this.lastmodifiers & classfileconstants.accpublic) == 0) {
boolean hasnopublictype = true;
for (int i = 0; i < unit.typecount; i++) {
if((unit.types[i].typedeclaration.modifiers & classfileconstants.accpublic) != 0) {
hasnopublictype = false;
}
}
if(hasnopublictype) {
keywords[count++] = keywords.public;
}
}
if((this.lastmodifiers & classfileconstants.accabstract) == 0
&& (this.lastmodifiers & classfileconstants.accfinal) == 0) {
keywords[count++] = keywords.abstract;
}
if((this.lastmodifiers & classfileconstants.accabstract) == 0
&& (this.lastmodifiers & classfileconstants.accfinal) == 0) {
keywords[count++] = keywords.final;
}

keywords[count++] = keywords.class;
if (this.options.compliancelevel >= classfileconstants.jdk1_5) {
keywords[count++] = keywords.enum;
}

if((this.lastmodifiers & classfileconstants.accfinal) == 0) {
keywords[count++] = keywords.interface;
}
if(count != 0) {
system.arraycopy(keywords, 0, keywords = new char[count][], 0, count);

this.assistnode = new completiononkeyword2(ident, pos, keywords);
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
return true;
}
}
}
return false;
}
private boolean checkinstanceofkeyword() {
if(isinsidemethod()) {
int kind = topknownelementkind(completion_or_assist_parser);
int index;
if(kind != k_block_delimiter
&& (index = indexofassistidentifier()) > -1
&& this.expressionptr > -1
&& this.expressionlengthstack[this.expressionptr] == 1) {

int ptr = this.identifierptr - this.identifierlengthstack[this.identifierlengthptr] + index + 1;
if(this.identifierstack[ptr].length > 0 && charoperation.prefixequals(this.identifierstack[ptr], keywords.instanceof)) {
this.assistnode = new completiononkeyword3(
this.identifierstack[ptr],
this.identifierpositionstack[ptr],
keywords.instanceof);
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
return true;
}
}
}
return false;
}
/**
* checks if the completion is inside a method invocation or a constructor invocation.
* returns whether we found a completion node.
*/
private boolean checkinvocation() {
expression topexpression = this.expressionptr >= 0 ?
this.expressionstack[this.expressionptr] :
null;
boolean isemptynamecompletion = false;
boolean isemptyassistidentifier = false;
if (topknownelementkind(completion_or_assist_parser) == k_selector_qualifier
&& ((isemptynamecompletion = topexpression == this.assistnode && isemptynamecompletion()) // e.g. it is something like "this.fred([cursor]" but it is not something like "this.fred(1 + [cursor]"
|| (isemptyassistidentifier = this.indexofassistidentifier() >= 0 && this.identifierstack[this.identifierptr].length == 0))) { // e.g. it is something like "this.fred(1 [cursor]"

// pop empty name completion
if (isemptynamecompletion) {
this.expressionptr--;
this.expressionlengthstack[this.expressionlengthptr]--;
} else if (isemptyassistidentifier) {
this.identifierptr--;
this.identifierlengthptr--;
}

// find receiver and qualifier
int invoctype = topknownelementinfo(completion_or_assist_parser, 1);
int qualifierexprptr = topknownelementinfo(completion_or_assist_parser);

// find arguments
int numargs = this.expressionptr - qualifierexprptr;
int argstart = qualifierexprptr + 1;
expression[] arguments = null;
if (numargs > 0) {
// remember the arguments
arguments = new expression[numargs];
system.arraycopy(this.expressionstack, argstart, arguments, 0, numargs);

// consume the expression arguments
this.expressionptr -= numargs;
int count = numargs;
while (count > 0) {
count -= this.expressionlengthstack[this.expressionlengthptr--];
}
}

// build ast node
if (invoctype != allocation && invoctype != qualified_allocation) {
// creates completion on message send
completiononmessagesend messagesend = new completiononmessagesend();
messagesend.arguments = arguments;
switch (invoctype) {
case no_receiver:
// implicit this
messagesend.receiver = thisreference.implicitthis();
break;
case name_receiver:
// remove special flags for primitive types
while (this.identifierlengthptr >= 0 && this.identifierlengthstack[this.identifierlengthptr] < 0) {
this.identifierlengthptr--;
}

// remove selector
this.identifierptr--;
if(this.genericsptr > -1 && this.genericslengthptr > -1 && this.genericslengthstack[this.genericslengthptr] > 0) {
// is inside a paremeterized method: bar.<x>.foo
this.identifierlengthptr--;
} else {
this.identifierlengthstack[this.identifierlengthptr]--;
}
// consume the receiver
messagesend.receiver = getunspecifiedreference();
break;
case super_receiver:
messagesend.receiver = new superreference(0, 0);
break;
case explicit_receiver:
messagesend.receiver = this.expressionstack[qualifierexprptr];
}

// set selector
int selectorptr = topknownelementinfo(completion_or_assist_parser, 2);
messagesend.selector = this.identifierstack[selectorptr];
// remove selector
if (this.identifierlengthptr >=0 && this.identifierlengthstack[this.identifierlengthptr] == 1) {
this.identifierptr--;
this.identifierlengthptr--;
}

// the entire message may be replaced in case qualification is needed
messagesend.sourcestart = (int)(this.identifierpositionstack[selectorptr] >> 32); //this.cursorlocation + 1;
messagesend.sourceend = this.cursorlocation;

// remember the message send as an orphan completion node
this.assistnode = messagesend;
this.lastcheckpoint = messagesend.sourceend + 1;
this.isorphancompletionnode = true;
return true;
} else {
int selectorptr = topknownelementinfo(completion_or_assist_parser, 2);
if (selectorptr == this_constructor || selectorptr == super_constructor) {
// creates an explicit constructor call
completiononexplicitconstructorcall call = new completiononexplicitconstructorcall(
(selectorptr == this_constructor) ? explicitconstructorcall.this : explicitconstructorcall.super);
call.arguments = arguments;
if (invoctype == qualified_allocation) {
call.qualification = this.expressionstack[qualifierexprptr];
}

// no source is going to be replaced
call.sourcestart = this.cursorlocation + 1;
call.sourceend = this.cursorlocation;

// remember the explicit constructor call as an orphan completion node
this.assistnode = call;
this.lastcheckpoint = call.sourceend + 1;
this.isorphancompletionnode = true;
return true;
} else {
// creates an allocation expression
completiononqualifiedallocationexpression allocexpr = new completiononqualifiedallocationexpression();
allocexpr.arguments = arguments;
if(this.genericslengthptr < 0) {
pushongenericslengthstack(0);
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
}
allocexpr.type = super.gettypereference(0); // we don't want a completion node here, so call super
if (invoctype == qualified_allocation) {
allocexpr.enclosinginstance = this.expressionstack[qualifierexprptr];
}
// no source is going to be replaced
allocexpr.sourcestart = this.cursorlocation + 1;
allocexpr.sourceend = this.cursorlocation;

// remember the allocation expression as an orphan completion node
this.assistnode = allocexpr;
this.lastcheckpoint = allocexpr.sourceend + 1;
this.isorphancompletionnode = true;
return true;
}
}
}
return false;
}
private boolean checklabelstatement() {
if(isinsidemethod() || isinsidefieldinitialization()) {

int kind = this.topknownelementkind(completion_or_assist_parser);
if(kind != k_inside_break_statement && kind != k_inside_continue_statement) return false;

if (indexofassistidentifier() != 0) return false;

char[][] labels = new char[this.labelptr + 1][];
int labelcount = 0;

int labelkind = kind;
int index = 1;
while(labelkind != 0 && labelkind != k_method_delimiter) {
labelkind = this.topknownelementkind(completion_or_assist_parser, index);
if(labelkind == k_label) {
int ptr = this.topknownelementinfo(completion_or_assist_parser, index);
labels[labelcount++] = this.labelstack[ptr];
}
index++;
}
system.arraycopy(labels, 0, labels = new char[labelcount][], 0, labelcount);

long position = this.identifierpositionstack[this.identifierptr];
completiononbranchstatementlabel statementlabel =
new completiononbranchstatementlabel(
kind == k_inside_break_statement ? completiononbranchstatementlabel.break : completiononbranchstatementlabel.continue,
this.identifierstack[this.identifierptr--],
(int) (position >>> 32),
(int)position,
labels);

this.assistnode = statementlabel;
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
return true;
}
return false;
}
/**
* checks if the completion is on a member access (i.e. in an identifier following a dot).
* returns whether we found a completion node.
*/
private boolean checkmemberaccess() {
if (this.previoustoken == tokennamedot && this.qualifier > -1 && this.expressionptr == this.qualifier) {
if (this.identifierlengthptr > 1 && this.identifierlengthstack[this.identifierlengthptr - 1] < 0) {
// its not a  member access because the receiver is a base type
// fix for bug: https://bugs.eclipse.org/bugs/show_bug.cgi?id=137623
return false;
}
// the receiver is an expression
pushcompletiononmemberaccessonexpressionstack(false);
return true;
}
return false;
}
/**
* checks if the completion is on a name reference.
* returns whether we found a completion node.
*/
private boolean checknamecompletion() {
/*
we didn't find any other completion, but the completion identifier is on the identifier stack,
so it can only be a completion on name.
note that we allow the completion on a name even if nothing is expected (e.g. foo() b[cursor] would
be a completion on 'b'). this policy gives more to the user than he/she would expect, but this
simplifies the problem. to fix this, the recovery must be changed to work at a 'statement' granularity
instead of at the 'expression' granularity as it does right now.
*/

// nb: at this point the completion identifier is on the identifier stack
this.assistnode = getunspecifiedreferenceoptimized();
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
if (this.hasunusedmodifiers &&
this.assistnode instanceof completiononsinglenamereference) {
((completiononsinglenamereference)this.assistnode).isprecededbymodifiers = true;
}
return true;
}
private boolean checkparemeterizedmethodname() {
if(topknownelementkind(completion_or_assist_parser) == k_parameterized_method_invocation &&
topknownelementinfo(completion_or_assist_parser) == inside_name) {
if(this.identifierlengthptr > -1 && this.genericslengthptr > -1 && this.genericsidentifierslengthptr == -1) {
completiononmessagesendname m = null;
switch (this.invocationtype) {
case explicit_receiver:
case no_receiver: // this case occurs with 'bar().foo'
if(this.expressionptr > -1 && this.expressionlengthstack[this.expressionlengthptr] == 1) {
char[] selector = this.identifierstack[this.identifierptr];
long position = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;
int end = (int) position;
int start = (int) (position >>> 32);
m = new completiononmessagesendname(selector, start, end);

// handle type arguments
int length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, m.typearguments = new typereference[length], 0, length);
this.intptr--;

m.receiver = this.expressionstack[this.expressionptr--];
this.expressionlengthptr--;
}
break;
case name_receiver:
if(this.identifierptr > 0) {
char[] selector = this.identifierstack[this.identifierptr];
long position = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;
int end = (int) position;
int start = (int) (position >>> 32);
m = new completiononmessagesendname(selector, start, end);

// handle type arguments
int length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, m.typearguments = new typereference[length], 0, length);
this.intptr--;

m.receiver = getunspecifiedreference();
}
break;
case super_receiver:
char[] selector = this.identifierstack[this.identifierptr];
long position = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;
int end = (int) position;
int start = (int) (position >>> 32);
m = new completiononmessagesendname(selector, start, end);

// handle type arguments
int length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, m.typearguments = new typereference[length], 0, length);
this.intptr--;

m.receiver = new superreference(start, end);
break;
}

if(m != null) {
pushonexpressionstack(m);

this.assistnode = m;
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
return true;
}
}
}
return false;
}
private boolean checkparemeterizedtype() {
if(this.identifierlengthptr > -1 && this.genericslengthptr > -1 && this.genericsidentifierslengthptr > -1) {
int length = this.identifierlengthstack[this.identifierlengthptr];
int numberofidentifiers = this.genericsidentifierslengthstack[this.genericsidentifierslengthptr];
if (length != numberofidentifiers || this.genericslengthstack[this.genericslengthptr] != 0) {
this.genericsidentifierslengthptr--;
this.identifierlengthptr--;
// generic type
this.assistnode = getassisttypereferenceforgenerictype(0, length, numberofidentifiers);
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
return true;
} else if(this.genericsptr > -1 && this.genericsstack[this.genericsptr] instanceof typereference) {
// type of a cast expression
numberofidentifiers++;

this.genericsidentifierslengthptr--;
this.identifierlengthptr--;
// generic type
this.assistnode = getassisttypereferenceforgenerictype(0, length, numberofidentifiers);
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
return true;
}
}
return false;
}
/**
* checks if the completion is in the context of a method and on the type of one of its arguments
* returns whether we found a completion node.
*/
private boolean checkrecoveredmethod() {
if (this.currentelement instanceof recoveredmethod){
/* check if current awaiting identifier is the completion identifier */
if (this.indexofassistidentifier() < 0) return false;

/* check if on line with an error already - to avoid completing inside
illegal type names e.g.  int[<cursor> */
if (this.lasterrorendposition <= this.cursorlocation
&& util.getlinenumber(this.lasterrorendposition, this.scanner.lineends, 0, this.scanner.lineptr)
== util.getlinenumber(((completionscanner)this.scanner).completedidentifierstart, this.scanner.lineends, 0, this.scanner.lineptr)){
return false;
}
recoveredmethod recoveredmethod = (recoveredmethod)this.currentelement;
/* only consider if inside method header */
if (!recoveredmethod.foundopeningbrace
&& this.lastignoredtoken == -1) {
//if (rparenpos < lparenpos){ // inside arguments
this.assistnode = this.gettypereference(0);
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
return true;
}
}
return false;
}
private boolean checkmembervaluename() {
/* check if current awaiting identifier is the completion identifier */
if (this.indexofassistidentifier() < 0) return false;

if (this.topknownelementkind(completion_or_assist_parser) != k_between_annotation_name_and_rparen) return false;

if(this.identifierptr > -1 && this.identifierlengthptr > -1 && this.identifierlengthstack[this.identifierlengthptr] == 1) {
char[] simplename = this.identifierstack[this.identifierptr];
long position = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;
int end = (int) position;
int start = (int) (position >>> 32);


completiononmembervaluename membervaluename = new completiononmembervaluename(simplename,start, end);
this.assistnode = membervaluename;
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;

return true;
}
return false;
}
/**
* checks if the completion is in the context of a type and on a type reference in this type.
* persists the identifier into a fake field return type
* returns whether we found a completion node.
*/
private boolean checkrecoveredtype() {
if (this.currentelement instanceof recoveredtype){
/* check if current awaiting identifier is the completion identifier */
if (this.indexofassistidentifier() < 0) return false;

/* check if on line with an error already - to avoid completing inside
illegal type names e.g.  int[<cursor> */
if (this.lasterrorendposition <= this.cursorlocation
&& ((recoveredtype)this.currentelement).lastmemberend() < this.lasterrorendposition
&& util.getlinenumber(this.lasterrorendposition, this.scanner.lineends, 0, this.scanner.lineptr)
== util.getlinenumber(((completionscanner)this.scanner).completedidentifierstart, this.scanner.lineends, 0, this.scanner.lineptr)){
return false;
}
recoveredtype recoveredtype = (recoveredtype)this.currentelement;
/* filter out cases where scanner is still inside type header */
if (recoveredtype.foundopeningbrace) {
// complete generics stack if necessary
if((this.genericsidentifierslengthptr < 0 && this.identifierptr > -1)
|| (this.genericsidentifierslengthstack[this.genericsidentifierslengthptr] <= this.identifierptr)) {
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0); // handle type arguments
}
this.assistnode = this.gettypereference(0);
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
return true;
} else {
if(recoveredtype.typedeclaration.superclass == null &&
this.topknownelementkind(completion_or_assist_parser) == k_extends_keyword) {
consumeclassorinterfacename();
this.pushonelementstack(k_next_typeref_is_class);
this.assistnode = this.gettypereference(0);
popelement(k_next_typeref_is_class);
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
return true;
}
}
}
return false;
}
private void classheaderextendsorimplements(boolean isinterface) {
if (this.currentelement != null
&& this.currenttoken == tokennameidentifier
&& this.cursorlocation+1 >= this.scanner.startposition
&& this.cursorlocation < this.scanner.currentposition){
this.pushidentifier();
int index = -1;
/* check if current awaiting identifier is the completion identifier */
if ((index = this.indexofassistidentifier()) > -1) {
int ptr = this.identifierptr - this.identifierlengthstack[this.identifierlengthptr] + index + 1;
recoveredtype recoveredtype = (recoveredtype)this.currentelement;
/* filter out cases where scanner is still inside type header */
if (!recoveredtype.foundopeningbrace) {
typedeclaration type = recoveredtype.typedeclaration;
if(!isinterface) {
char[][] keywords = new char[keywords.count][];
int count = 0;


if(type.superinterfaces == null) {
if(type.superclass == null) {
keywords[count++] = keywords.extends;
}
keywords[count++] = keywords.implements;
}

system.arraycopy(keywords, 0, keywords = new char[count][], 0, count);

if(count > 0) {
completiononkeyword1 completiononkeyword = new completiononkeyword1(
this.identifierstack[ptr],
this.identifierpositionstack[ptr],
keywords);
completiononkeyword.cancompleteemptytoken = true;
type.superclass = completiononkeyword;
type.superclass.bits |= astnode.issupertype;
this.assistnode = completiononkeyword;
this.lastcheckpoint = completiononkeyword.sourceend + 1;
}
} else {
if(type.superinterfaces == null) {
completiononkeyword1 completiononkeyword = new completiononkeyword1(
this.identifierstack[ptr],
this.identifierpositionstack[ptr],
keywords.extends);
completiononkeyword.cancompleteemptytoken = true;
type.superinterfaces = new typereference[]{completiononkeyword};
type.superinterfaces[0].bits |= astnode.issupertype;
this.assistnode = completiononkeyword;
this.lastcheckpoint = completiononkeyword.sourceend + 1;
}
}
}
}
}
}
/*
* check whether about to shift beyond the completion token.
* if so, depending on the context, a special node might need to be created
* and attached to the existing recovered structure so as to be remember in the
* resulting parsed structure.
*/
public void completionidentifiercheck(){
//if (assistnode != null) return;

if (checkmembervaluename()) return;
if (checkkeyword()) return;
if (checkrecoveredtype()) return;
if (checkrecoveredmethod()) return;

// if not in a method in non diet mode and if not inside a field initializer, only record references attached to types
if (!(isinsidemethod() && !this.diet)
&& !isindirectlyinsidefieldinitialization()
&& !isinsideattributevalue()) return;

/*
in some cases, the completion identifier may not have yet been consumed,
e.g.  int.[cursor]
this is because the grammar does not allow any (empty) identifier to follow
a base type. we thus have to manually force the identifier to be consumed
(that is, pushed).
*/
if (assistidentifier() == null && this.currenttoken == tokennameidentifier) { // test below copied from completionscanner.getcurrentidentifiersource()
if (this.cursorlocation < this.scanner.startposition && this.scanner.currentposition == this.scanner.startposition){ // fake empty identifier got issued
this.pushidentifier();
} else if (this.cursorlocation+1 >= this.scanner.startposition && this.cursorlocation < this.scanner.currentposition){
this.pushidentifier();
}
}

// check for different scenarii
// no need to go further if we found a non empty completion node
// (we still need to store labels though)
if (this.assistnode != null) {
// however inside an invocation, the completion identifier may already have been consumed into an empty name
// completion, so this check should be before we check that we are at the cursor location
if (!isemptynamecompletion() || checkinvocation()) return;
}

// no need to check further if we are not at the cursor location
if (this.indexofassistidentifier() < 0) return;

if (checkclassinstancecreation()) return;
if (checkcatchclause()) return;
if (checkmemberaccess()) return;
if (checkclassliteralaccess()) return;
if (checkinstanceofkeyword()) return;

// if the completion was not on an empty name, it can still be inside an invocation (e.g. this.fred("abc"[cursor])
// (nb: put this check before checknamecompletion() because the selector of the invocation can be on the identifier stack)
if (checkinvocation()) return;

if (checkparemeterizedtype()) return;
if (checkparemeterizedmethodname()) return;
if (checklabelstatement()) return;
if (checknamecompletion()) return;
}
protected void consumearraycreationexpressionwithinitializer() {
super.consumearraycreationexpressionwithinitializer();
popelement(k_array_creation);
}
protected void consumearraycreationexpressionwithoutinitializer() {
super.consumearraycreationexpressionwithoutinitializer();
popelement(k_array_creation);
}
protected void consumearraycreationheader() {
// nothing to do
}
protected void consumeassignment() {
popelement(k_assisgnment_operator);
super.consumeassignment();
}
protected void consumeassignmentoperator(int pos) {
super.consumeassignmentoperator(pos);
pushonelementstack(k_assisgnment_operator, pos);
}
protected void consumebinaryexpression(int op) {
super.consumebinaryexpression(op);
popelement(k_binary_operator);

if(this.expressionstack[this.expressionptr] instanceof binaryexpression) {
binaryexpression exp = (binaryexpression) this.expressionstack[this.expressionptr];
if(this.assistnode != null && exp.right == this.assistnode) {
this.assistnodeparent = exp;
}
}
}
protected void consumebinaryexpressionwithname(int op) {
super.consumebinaryexpressionwithname(op);
popelement(k_binary_operator);

if(this.expressionstack[this.expressionptr] instanceof binaryexpression) {
binaryexpression exp = (binaryexpression) this.expressionstack[this.expressionptr];
if(this.assistnode != null && exp.right == this.assistnode) {
this.assistnodeparent = exp;
}
}
}
protected void consumecaselabel() {
super.consumecaselabel();
if(topknownelementkind(completion_or_assist_parser) != k_switch_label) {
pushonelementstack(k_switch_label);
}
}
protected void consumecastexpressionwithprimitivetype() {
popelement(k_cast_statement);

expression exp, cast, casttype;
this.expressionptr--;
this.expressionlengthptr--;
this.expressionstack[this.expressionptr] = cast = new castexpression(exp = this.expressionstack[this.expressionptr+1], casttype = this.expressionstack[this.expressionptr]);
cast.sourcestart = casttype.sourcestart - 1;
cast.sourceend = exp.sourceend;
}
protected void consumecastexpressionwithgenericsarray() {
popelement(k_cast_statement);

expression exp, cast, casttype;
this.expressionptr--;
this.expressionlengthptr--;
this.expressionstack[this.expressionptr] = cast = new castexpression(exp = this.expressionstack[this.expressionptr + 1], casttype = this.expressionstack[this.expressionptr]);
cast.sourcestart = casttype.sourcestart - 1;
cast.sourceend = exp.sourceend;
}

protected void consumecastexpressionwithqualifiedgenericsarray() {
popelement(k_cast_statement);

expression exp, cast, casttype;
this.expressionptr--;
this.expressionlengthptr--;
this.expressionstack[this.expressionptr] = cast = new castexpression(exp = this.expressionstack[this.expressionptr + 1], casttype = this.expressionstack[this.expressionptr]);
cast.sourcestart = casttype.sourcestart - 1;
cast.sourceend = exp.sourceend;
}
protected void consumecastexpressionwithnamearray() {
// castexpression ::= pushlparen name dims pushrparen insidecastexpression unaryexpressionnotplusminus
popelement(k_cast_statement);

expression exp, cast, casttype;

this.expressionptr--;
this.expressionlengthptr--;
this.expressionstack[this.expressionptr] = cast = new castexpression(exp = this.expressionstack[this.expressionptr+1], casttype = this.expressionstack[this.expressionptr]);
cast.sourcestart = casttype.sourcestart - 1;
cast.sourceend = exp.sourceend;
}
protected void consumecastexpressionll1() {
popelement(k_cast_statement);
super.consumecastexpressionll1();
}
protected void consumeclassbodydeclaration() {
popelement(k_block_delimiter);
super.consumeclassbodydeclaration();
this.pendingannotation = null; // the pending annotation cannot be attached to next nodes
}
protected void consumeclassbodyopt() {
popelement(k_selector_qualifier);
popelement(k_selector_invocation_type);
super.consumeclassbodyopt();
}
/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.parser#consumeclassdeclaration()
*/
protected void consumeclassdeclaration() {
if (this.astptr >= 0) {
int length = this.astlengthstack[this.astlengthptr];
typedeclaration typedeclaration = (typedeclaration) this.aststack[this.astptr-length];
this.javadoc = null;
completionjavadocparser completionjavadocparser = (completionjavadocparser)this.javadocparser;
completionjavadocparser.allpossibletags = true;
checkcomment();
if (this.javadoc != null && this.cursorlocation > this.javadoc.sourcestart && this.cursorlocation < this.javadoc.sourceend) {
// completion is in an orphan javadoc comment => replace in last read declaration to allow completion resolution
typedeclaration.javadoc = this.javadoc;
}
completionjavadocparser.allpossibletags = false;
}
super.consumeclassdeclaration();
}
protected void consumeclassheadername1() {
super.consumeclassheadername1();
this.hasunusedmodifiers = false;
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
classheaderextendsorimplements(false);
}

protected void consumeclassheaderextends() {
pushonelementstack(k_next_typeref_is_class);
super.consumeclassheaderextends();
if (this.assistnode != null && this.assistnodeparent == null) {
typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];
if (typedecl != null && typedecl.superclass == this.assistnode)
this.assistnodeparent = typedecl;
}
popelement(k_next_typeref_is_class);
popelement(k_extends_keyword);

if (this.currentelement != null
&& this.currenttoken == tokennameidentifier
&& this.cursorlocation+1 >= this.scanner.startposition
&& this.cursorlocation < this.scanner.currentposition){
this.pushidentifier();

int index = -1;
/* check if current awaiting identifier is the completion identifier */
if ((index = this.indexofassistidentifier()) > -1) {
int ptr = this.identifierptr - this.identifierlengthstack[this.identifierlengthptr] + index + 1;
recoveredtype recoveredtype = (recoveredtype)this.currentelement;
/* filter out cases where scanner is still inside type header */
if (!recoveredtype.foundopeningbrace) {
typedeclaration type = recoveredtype.typedeclaration;
if(type.superinterfaces == null) {
type.superclass = new completiononkeyword1(
this.identifierstack[ptr],
this.identifierpositionstack[ptr],
keywords.implements);
type.superclass.bits |= astnode.issupertype;
this.assistnode = type.superclass;
this.lastcheckpoint = type.superclass.sourceend + 1;
}
}
}
}
}
protected void consumeclasstypeelt() {
pushonelementstack(k_next_typeref_is_exception);
super.consumeclasstypeelt();
popelement(k_next_typeref_is_exception);
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.parser#consumecompilationunit()
*/
protected void consumecompilationunit() {
this.javadoc = null;
checkcomment();
if (this.javadoc != null && this.cursorlocation > this.javadoc.sourcestart && this.cursorlocation < this.javadoc.sourceend) {
// completion is in an orphan javadoc comment => replace compilation unit one to allow completion resolution
this.compilationunit.javadoc = this.javadoc;
// create a fake interface declaration to allow resolution
if (this.compilationunit.types == null) {
this.compilationunit.types = new typedeclaration[1];
typedeclaration declaration = new typedeclaration(this.compilationunit.compilationresult);
declaration.name = fake_type_name;
declaration.modifiers = classfileconstants.accdefault | classfileconstants.accinterface;
this.compilationunit.types[0] = declaration;
}
}
super.consumecompilationunit();
}
protected void consumeconditionalexpression(int op) {
popelement(k_conditional_operator);
super.consumeconditionalexpression(op);
}
protected void consumeconditionalexpressionwithname(int op) {
popelement(k_conditional_operator);
super.consumeconditionalexpressionwithname(op);
}
protected void consumeconstructorbody() {
popelement(k_block_delimiter);
super.consumeconstructorbody();
}
protected void consumeconstructorheader() {
super.consumeconstructorheader();
pushonelementstack(k_block_delimiter);
}
protected void consumeconstructorheadername() {

/* no need to take action if not inside assist identifiers */
if (indexofassistidentifier() < 0) {
long selectorsourcepositions = this.identifierpositionstack[this.identifierptr];
int selectorsourceend = (int) selectorsourcepositions;
int currentastptr = this.astptr;
/* recovering - might be an empty message send */
if (this.currentelement != null && this.lastignoredtoken == tokennamenew){ // was an allocation expression
super.consumeconstructorheadername();
} else {
super.consumeconstructorheadername();
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
}
if (this.sourceends != null && this.astptr > currentastptr) { // if ast node was pushed on the ast stack
this.sourceends.put(this.aststack[this.astptr], selectorsourceend);
}
return;
}

/* force to start recovering in order to get fake field behavior */
if (this.currentelement == null){
this.hasreportederror = true; // do not report any error
}
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0); // handle type arguments
this.restartrecovery = true;
}
protected void consumeconstructorheadernamewithtypeparameters() {
long selectorsourcepositions = this.identifierpositionstack[this.identifierptr];
int selectorsourceend = (int) selectorsourcepositions;
int currentastptr = this.astptr;
if (this.currentelement != null && this.lastignoredtoken == tokennamenew){ // was an allocation expression
super.consumeconstructorheadernamewithtypeparameters();
} else {
super.consumeconstructorheadernamewithtypeparameters();
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
}
if (this.sourceends != null && this.astptr > currentastptr) { // if ast node was pushed on the ast stack
this.sourceends.put(this.aststack[this.astptr], selectorsourceend);
}
}
protected void consumedefaultlabel() {
super.consumedefaultlabel();
if(topknownelementkind(completion_or_assist_parser) == k_switch_label) {
popelement(k_switch_label);
}
pushonelementstack(k_switch_label, default);
}
protected void consumedimwithorwithoutexpr() {
// dimwithorwithoutexpr ::= '[' ']'
pushonexpressionstack(null);
}
protected void consumeenhancedforstatement() {
super.consumeenhancedforstatement();

if (topknownelementkind(completion_or_assist_parser) == k_control_statement_delimiter) {
popelement(k_control_statement_delimiter);
}
}
protected void consumeenhancedforstatementheaderinit(boolean hasmodifiers) {
super.consumeenhancedforstatementheaderinit(hasmodifiers);
this.hasunusedmodifiers = false;
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
}
protected void consumeenteranonymousclassbody(boolean qualified) {
popelement(k_selector_qualifier);
popelement(k_selector_invocation_type);
super.consumeenteranonymousclassbody(qualified);
}
protected void consumeentervariable() {
this.identifierptr--;
this.identifierlengthptr--;

boolean islocaldeclaration = this.nestedmethod[this.nestedtype] != 0;
int variableindex = this.variablescounter[this.nestedtype];

this.hasunusedmodifiers = false;

if(islocaldeclaration || indexofassistidentifier() < 0 || variableindex != 0) {
this.identifierptr++;
this.identifierlengthptr++;

if (this.pendingannotation != null &&
this.assistnode != null &&
this.currentelement != null &&
this.currentelement instanceof recoveredmethod &&
!this.currentelement.foundopeningbrace &&
((recoveredmethod)this.currentelement).methoddeclaration.declarationsourceend == 0) {
// this is a method parameter
super.consumeentervariable();
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation.isparameter = true;
this.pendingannotation = null;

} else {
super.consumeentervariable();
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
}
} else {
this.restartrecovery = true;

// recovery
if (this.currentelement != null) {
if(!checkkeyword() && !(this.currentelement instanceof recoveredunit && ((recoveredunit)this.currentelement).typecount == 0)) {
int namesourcestart = (int)(this.identifierpositionstack[this.identifierptr] >>> 32);
this.intptr--;
typereference type = gettypereference(this.intstack[this.intptr--]);
this.intptr--;

if (!(this.currentelement instanceof recoveredtype)
&& (this.currenttoken == tokennamedot
|| (util.getlinenumber(type.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr)
!= util.getlinenumber(namesourcestart, this.scanner.lineends, 0, this.scanner.lineptr)))){
this.lastcheckpoint = namesourcestart;
this.restartrecovery = true;
return;
}

fielddeclaration completionfielddecl = new completiononfieldtype(type, false);
// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
completionfielddecl.annotations = new annotation[length],
0,
length);
}
completionfielddecl.modifiers = this.intstack[this.intptr--];
this.assistnode = completionfielddecl;
this.lastcheckpoint = type.sourceend + 1;
this.currentelement = this.currentelement.add(completionfielddecl, 0);
this.lastignoredtoken = -1;
}
}
}
}
protected void consumeenumconstantheadername() {
if (this.currentelement != null) {
if (!(this.currentelement instanceof recoveredtype
|| (this.currentelement instanceof recoveredfield && ((recoveredfield)this.currentelement).fielddeclaration.type == null))
|| (this.lastignoredtoken == tokennamedot)) {
super.consumeenumconstantheadername();
return;
}
}
super.consumeenumconstantheadername();
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
}
protected void consumeenumconstantnoclassbody() {
super.consumeenumconstantnoclassbody();
if ((this.currenttoken == tokennamecomma || this.currenttoken == tokennamesemicolon)
&& this.aststack[this.astptr] instanceof fielddeclaration) {
if (this.sourceends != null) {
this.sourceends.put(this.aststack[this.astptr], this.scanner.currentposition - 1);
}
}
}
protected void consumeenumconstantwithclassbody() {
super.consumeenumconstantwithclassbody();
if ((this.currenttoken == tokennamecomma || this.currenttoken == tokennamesemicolon)
&& this.aststack[this.astptr] instanceof fielddeclaration) {
if (this.sourceends != null) {
this.sourceends.put(this.aststack[this.astptr], this.scanner.currentposition - 1);
}
}
}
protected void consumeenumheadername() {
super.consumeenumheadername();
this.hasunusedmodifiers = false;
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
}
protected void consumeenumheadernamewithtypeparameters() {
super.consumeenumheadernamewithtypeparameters();
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
}
protected void consumeequalityexpression(int op) {
super.consumeequalityexpression(op);
popelement(k_binary_operator);

binaryexpression exp = (binaryexpression) this.expressionstack[this.expressionptr];
if(this.assistnode != null && exp.right == this.assistnode) {
this.assistnodeparent = exp;
}
}
protected void consumeequalityexpressionwithname(int op) {
super.consumeequalityexpressionwithname(op);
popelement(k_binary_operator);

binaryexpression exp = (binaryexpression) this.expressionstack[this.expressionptr];
if(this.assistnode != null && exp.right == this.assistnode) {
this.assistnodeparent = exp;
}
}
protected void consumeexitvariablewithinitialization() {
super.consumeexitvariablewithinitialization();
if ((this.currenttoken == tokennamecomma || this.currenttoken == tokennamesemicolon)
&& this.aststack[this.astptr] instanceof fielddeclaration) {
if (this.sourceends != null) {
this.sourceends.put(this.aststack[this.astptr], this.scanner.currentposition - 1);
}
}

// does not keep the initialization if completion is not inside
abstractvariabledeclaration variable = (abstractvariabledeclaration) this.aststack[this.astptr];
if (this.cursorlocation + 1 < variable.initialization.sourcestart ||
this.cursorlocation > variable.initialization.sourceend) {
variable.initialization = null;
} else if (this.assistnode != null && this.assistnode == variable.initialization) {
this.assistnodeparent = variable;
}
}
protected void consumeexitvariablewithoutinitialization() {
// exitvariablewithoutinitialization ::= $empty
// do nothing by default
super.consumeexitvariablewithoutinitialization();
if ((this.currenttoken == tokennamecomma || this.currenttoken == tokennamesemicolon)
&& this.aststack[this.astptr] instanceof fielddeclaration) {
if (this.sourceends != null) {
this.sourceends.put(this.aststack[this.astptr], this.scanner.currentposition - 1);
}
}
}
protected void consumeexplicitconstructorinvocation(int flag, int recflag) {
popelement(k_selector_qualifier);
popelement(k_selector_invocation_type);
super.consumeexplicitconstructorinvocation(flag, recflag);
}
/*
* copy of code from superclass with the following change:
* if the cursor location is on the field access, then create a
* completiononmemberaccess instead.
*/
protected void consumefieldaccess(boolean issuperaccess) {
// fieldaccess ::= primary '.' 'identifier'
// fieldaccess ::= 'super' '.' 'identifier'

// potential receiver is being poped, so reset potential receiver
this.invocationtype = no_receiver;
this.qualifier = -1;

if (this.indexofassistidentifier() < 0) {
super.consumefieldaccess(issuperaccess);
} else {
pushcompletiononmemberaccessonexpressionstack(issuperaccess);
}
}
protected void consumeforcenodiet() {
super.consumeforcenodiet();
if (isinsidemethod()) {
pushonelementstack(k_local_initializer_delimiter);
}
}
protected void consumeformalparameter(boolean isvarargs) {
if (this.indexofassistidentifier() < 0) {
super.consumeformalparameter(isvarargs);
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
} else {

this.identifierlengthptr--;
char[] identifiername = this.identifierstack[this.identifierptr];
long namepositions = this.identifierpositionstack[this.identifierptr--];
int extendeddimensions = this.intstack[this.intptr--];
int endofellipsis = 0;
if (isvarargs) {
endofellipsis = this.intstack[this.intptr--];
}
int firstdimensions = this.intstack[this.intptr--];
final int typedimensions = firstdimensions + extendeddimensions;
typereference type = gettypereference(typedimensions);
if (isvarargs) {
type = copydims(type, typedimensions + 1);
if (extendeddimensions == 0) {
type.sourceend = endofellipsis;
}
type.bits |= astnode.isvarargs; // set isvarargs
}
this.intptr -= 2;
completiononargumentname arg =
new completiononargumentname(
identifiername,
namepositions,
type,
this.intstack[this.intptr + 1] & ~classfileconstants.accdeprecated); // modifiers
// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
arg.annotations = new annotation[length],
0,
length);
}

arg.iscatchargument = topknownelementkind(completion_or_assist_parser) == k_between_catch_and_right_paren;
pushonaststack(arg);

this.assistnode = arg;
this.lastcheckpoint = (int) namepositions;
this.isorphancompletionnode = true;

/* if incomplete method header, listlength counter will not have been reset,
indicating that some arguments are available on the stack */
this.listlength++;
}
}
protected void consumestatementfor() {
super.consumestatementfor();

if (topknownelementkind(completion_or_assist_parser) == k_control_statement_delimiter) {
popelement(k_control_statement_delimiter);
}
}
protected void consumestatementifnoelse() {
super.consumestatementifnoelse();

if (topknownelementkind(completion_or_assist_parser) == k_control_statement_delimiter) {
popelement(k_control_statement_delimiter);
}
}
protected void consumestatementifwithelse() {
super.consumestatementifwithelse();

if (topknownelementkind(completion_or_assist_parser) == k_control_statement_delimiter) {
popelement(k_control_statement_delimiter);
}
}
protected void consumeinsidecastexpression() {
int end = this.intstack[this.intptr--];
boolean isparameterized =(topknownelementkind(completion_or_assist_parser) == k_parameterized_cast);
if(isparameterized) {
popelement(k_parameterized_cast);

if(this.identifierlengthstack[this.identifierlengthptr] > 0) {
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
}
} else {
if(this.identifierlengthstack[this.identifierlengthptr] > 0) {
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0);
}
}
expression casttype = gettypereference(this.intstack[this.intptr--]);
if(isparameterized) {
this.intptr--;
}
casttype.sourceend = end - 1;
casttype.sourcestart = this.intstack[this.intptr--] + 1;
pushonexpressionstack(casttype);

pushonelementstack(k_cast_statement);
}
protected void consumeinsidecastexpressionll1() {
if(topknownelementkind(completion_or_assist_parser) == k_parameterized_cast) {
popelement(k_parameterized_cast);
}
if (!this.record) {
super.consumeinsidecastexpressionll1();
} else {
boolean temp = this.skiprecord;
try {
this.skiprecord = true;
super.consumeinsidecastexpressionll1();
if (this.record) {
expression typereference = this.expressionstack[this.expressionptr];
if (!isalreadypotentialname(typereference.sourcestart)) {
addpotentialname(null, typereference.sourcestart, typereference.sourceend);
}
}
} finally {
this.skiprecord = temp;
}
}
pushonelementstack(k_cast_statement);
}
protected void consumeinsidecastexpressionwithqualifiedgenerics() {
popelement(k_parameterized_cast);

expression casttype;
int end = this.intstack[this.intptr--];

int dim = this.intstack[this.intptr--];
typereference rightside = gettypereference(0);

casttype = computequalifiedgenericsfromrightside(rightside, dim);
this.intptr--;
casttype.sourceend = end - 1;
casttype.sourcestart = this.intstack[this.intptr--] + 1;
pushonexpressionstack(casttype);

pushonelementstack(k_cast_statement);
}
protected void consumeinstanceofexpression() {
super.consumeinstanceofexpression();
popelement(k_binary_operator);
// to handle https://bugs.eclipse.org/bugs/show_bug.cgi?id=261534
if (topknownelementkind(completion_or_assist_parser) == k_between_if_and_right_paren) {
pushonelementstack(k_between_instanceof_and_rparen, if, this.expressionstack[this.expressionptr]);
}

instanceofexpression exp = (instanceofexpression) this.expressionstack[this.expressionptr];
if(this.assistnode != null && exp.type == this.assistnode) {
this.assistnodeparent = exp;
}
}
protected void consumeinstanceofexpressionwithname() {
super.consumeinstanceofexpressionwithname();
popelement(k_binary_operator);

instanceofexpression exp = (instanceofexpression) this.expressionstack[this.expressionptr];
if(this.assistnode != null && exp.type == this.assistnode) {
this.assistnodeparent = exp;
}
}
protected void consumeinterfaceheadername1() {
super.consumeinterfaceheadername1();
this.hasunusedmodifiers = false;
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
classheaderextendsorimplements(true);
}
protected void consumeinterfaceheaderextends() {
super.consumeinterfaceheaderextends();
popelement(k_extends_keyword);
}
protected void consumeinterfacetype() {
pushonelementstack(k_next_typeref_is_interface);
super.consumeinterfacetype();
popelement(k_next_typeref_is_interface);
}
protected void consumemethodinvocationname() {
popelement(k_selector_qualifier);
popelement(k_selector_invocation_type);
super.consumemethodinvocationname();
}
protected void consumemethodinvocationnamewithtypearguments() {
popelement(k_selector_qualifier);
popelement(k_selector_invocation_type);
super.consumemethodinvocationnamewithtypearguments();
}
protected void consumemethodinvocationprimary() {
popelement(k_selector_qualifier);
popelement(k_selector_invocation_type);
super.consumemethodinvocationprimary();
}
protected void consumemethodinvocationprimarywithtypearguments() {
popelement(k_selector_qualifier);
popelement(k_selector_invocation_type);
super.consumemethodinvocationprimarywithtypearguments();
}
protected void consumemethodinvocationsuper() {
popelement(k_selector_qualifier);
popelement(k_selector_invocation_type);
super.consumemethodinvocationsuper();
}
protected void consumemethodinvocationsuperwithtypearguments() {
popelement(k_selector_qualifier);
popelement(k_selector_invocation_type);
super.consumemethodinvocationsuperwithtypearguments();
}
protected void consumemethodheadername(boolean isannotationmethod) {
if(this.indexofassistidentifier() < 0) {
this.identifierptr--;
this.identifierlengthptr--;
if(this.indexofassistidentifier() != 0 ||
this.identifierlengthstack[this.identifierlengthptr] != this.genericsidentifierslengthstack[this.genericsidentifierslengthptr]) {
this.identifierptr++;
this.identifierlengthptr++;
long selectorsourcepositions = this.identifierpositionstack[this.identifierptr];
int selectorsourceend = (int) selectorsourcepositions;
int currentastptr = this.astptr;
super.consumemethodheadername(isannotationmethod);
if (this.sourceends != null && this.astptr > currentastptr) { // if ast node was pushed on the ast stack
this.sourceends.put(this.aststack[this.astptr], selectorsourceend);
}
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
} else {
this.restartrecovery = true;

// recovery
if (this.currentelement != null) {
//name
char[] selector = this.identifierstack[this.identifierptr + 1];
long selectorsource = this.identifierpositionstack[this.identifierptr + 1];

//type
typereference type = gettypereference(this.intstack[this.intptr--]);
((completiononsingletypereference)type).iscompletionnode = false;
//modifiers
int declarationsourcestart = this.intstack[this.intptr--];
int mod = this.intstack[this.intptr--];

if(util.getlinenumber(type.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr)
!= util.getlinenumber((int) (selectorsource >>> 32), this.scanner.lineends, 0, this.scanner.lineptr)) {
fielddeclaration completionfielddecl = new completiononfieldtype(type, false);
// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
completionfielddecl.annotations = new annotation[length],
0,
length);
}
completionfielddecl.modifiers = mod;
this.assistnode = completionfielddecl;
this.lastcheckpoint = type.sourceend + 1;
this.currentelement = this.currentelement.add(completionfielddecl, 0);
this.lastignoredtoken = -1;
} else {
completiononmethodreturntype md = new completiononmethodreturntype(type, this.compilationunit.compilationresult);
// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
md.annotations = new annotation[length],
0,
length);
}
md.selector = selector;
md.declarationsourcestart = declarationsourcestart;
md.modifiers = mod;
md.bodystart = this.lparenpos+1;
this.listlength = 0; // initialize listlength before reading parameters/throws
this.assistnode = md;
this.lastcheckpoint = md.bodystart;
this.currentelement = this.currentelement.add(md, 0);
this.lastignoredtoken = -1;
// javadoc
md.javadoc = this.javadoc;
this.javadoc = null;
}
}
}
} else {
// methodheadername ::= modifiersopt type 'identifier' '('
completiononmethodname md = new completiononmethodname(this.compilationunit.compilationresult);

//name
md.selector = this.identifierstack[this.identifierptr];
long selectorsource = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;
//type
md.returntype = gettypereference(this.intstack[this.intptr--]);
//modifiers
md.declarationsourcestart = this.intstack[this.intptr--];
md.modifiers = this.intstack[this.intptr--];
// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
md.annotations = new annotation[length],
0,
length);
}
// javadoc
md.javadoc = this.javadoc;
this.javadoc = null;

//highlight starts at selector start
md.sourcestart = (int) (selectorsource >>> 32);
md.selectorend = (int) selectorsource;
pushonaststack(md);
md.sourceend = this.lparenpos;
md.bodystart = this.lparenpos+1;
this.listlength = 0; // initialize listlength before reading parameters/throws

this.assistnode = md;
this.lastcheckpoint = md.sourceend;
// recovery
if (this.currentelement != null){
if (this.currentelement instanceof recoveredtype
//|| md.modifiers != 0
|| (util.getlinenumber(md.returntype.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr)
== util.getlinenumber(md.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr))){
this.lastcheckpoint = md.bodystart;
this.currentelement = this.currentelement.add(md, 0);
this.lastignoredtoken = -1;
} else {
this.lastcheckpoint = md.sourcestart;
this.restartrecovery = true;
}
}
}
}
protected void consumemethodheadernamewithtypeparameters( boolean isannotationmethod) {
long selectorsourcepositions = this.identifierpositionstack[this.identifierptr];
int selectorsourceend = (int) selectorsourcepositions;
int currentastptr = this.astptr;
super.consumemethodheadernamewithtypeparameters(isannotationmethod);
if (this.sourceends != null && this.astptr > currentastptr) {// if ast node was pushed on the ast stack
this.sourceends.put(this.aststack[this.astptr], selectorsourceend);
}
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
}
protected void consumemethodheaderrightparen() {
super.consumemethodheaderrightparen();

if (this.currentelement != null
&& this.currenttoken == tokennameidentifier
&& this.cursorlocation+1 >= this.scanner.startposition
&& this.cursorlocation < this.scanner.currentposition){
this.pushidentifier();

int index = -1;
/* check if current awaiting identifier is the completion identifier */
if ((index = this.indexofassistidentifier()) > -1) {
int ptr = this.identifierptr - this.identifierlengthstack[this.identifierlengthptr] + index + 1;
if (this.currentelement instanceof recoveredmethod){
recoveredmethod recoveredmethod = (recoveredmethod)this.currentelement;
/* filter out cases where scanner is still inside type header */
if (!recoveredmethod.foundopeningbrace) {
abstractmethoddeclaration method = recoveredmethod.methoddeclaration;
if(method.thrownexceptions == null) {
completiononkeyword1 completiononkeyword = new completiononkeyword1(
this.identifierstack[ptr],
this.identifierpositionstack[ptr],
keywords.throws);
method.thrownexceptions = new typereference[]{completiononkeyword};
recoveredmethod.foundopeningbrace = true;
this.assistnode = completiononkeyword;
this.lastcheckpoint = completiononkeyword.sourceend + 1;
}
}
}
}
}
}
protected void consumemethodheaderextendeddims() {
super.consumemethodheaderextendeddims();

if (this.currentelement != null
&& this.currenttoken == tokennameidentifier
&& this.cursorlocation+1 >= this.scanner.startposition
&& this.cursorlocation < this.scanner.currentposition){
this.pushidentifier();

int index = -1;
/* check if current awaiting identifier is the completion identifier */
if ((index = this.indexofassistidentifier()) > -1) {
int ptr = this.identifierptr - this.identifierlengthstack[this.identifierlengthptr] + index + 1;
recoveredmethod recoveredmethod = (recoveredmethod)this.currentelement;
/* filter out cases where scanner is still inside type header */
if (!recoveredmethod.foundopeningbrace) {
abstractmethoddeclaration method = recoveredmethod.methoddeclaration;
if(method.thrownexceptions == null) {
completiononkeyword1 completiononkeyword = new completiononkeyword1(
this.identifierstack[ptr],
this.identifierpositionstack[ptr],
keywords.throws);
method.thrownexceptions = new typereference[]{completiononkeyword};
recoveredmethod.foundopeningbrace = true;
this.assistnode = completiononkeyword;
this.lastcheckpoint = completiononkeyword.sourceend + 1;
}
}
}
}
}
protected void consumeannotationasmodifier() {
super.consumeannotationasmodifier();

if (isinsidemethod()) {
this.hasunusedmodifiers = true;
}
}
protected void consumeadditionalbound() {
super.consumeadditionalbound();
astnode node = this.genericsstack[this.genericsptr];
if (node instanceof completiononsingletypereference) {
((completiononsingletypereference) node).setkind(completiononqualifiedtypereference.k_interface);
} else if (node instanceof completiononqualifiedtypereference) {
((completiononqualifiedtypereference) node).setkind(completiononqualifiedtypereference.k_interface);
}
}
protected void consumeadditionalbound1() {
super.consumeadditionalbound1();
astnode node = this.genericsstack[this.genericsptr];
if (node instanceof completiononsingletypereference) {
((completiononsingletypereference) node).setkind(completiononqualifiedtypereference.k_interface);
} else if (node instanceof completiononqualifiedtypereference) {
((completiononqualifiedtypereference) node).setkind(completiononqualifiedtypereference.k_interface);
}
}
protected void consumeannotationname() {
int index;

if ((index = this.indexofassistidentifier()) < 0) {
super.consumeannotationname();
this.pushonelementstack(k_between_annotation_name_and_rparen, lparen_not_consumed);
return;
}

markerannotation markerannotation = null;
int length = this.identifierlengthstack[this.identifierlengthptr];
typereference typereference;

/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */

char[][] subset = identifiersubset(index);
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist on type reference */

if (index == 0) {
/* assist inside first identifier */
typereference = createsingleassisttypereference(
assistidentifier(),
positions[0]);
} else {
/* assist inside subsequent identifier */
typereference =	createqualifiedassisttypereference(
subset,
assistidentifier(),
positions);
}

markerannotation = new completiononmarkerannotationname(typereference, typereference.sourcestart);
this.intptr--;
markerannotation.declarationsourceend = markerannotation.sourceend;
pushonexpressionstack(markerannotation);

this.assistnode = markerannotation;
this.isorphancompletionnode = true;

this.lastcheckpoint = markerannotation.sourceend + 1;

this.pushonelementstack(k_between_annotation_name_and_rparen, lparen_not_consumed | annotation_name_completion);
}
protected void consumeannotationtypedeclarationheadername() {
super.consumeannotationtypedeclarationheadername();
this.hasunusedmodifiers = false;
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
}
protected void consumeannotationtypedeclarationheadernamewithtypeparameters() {
super.consumeannotationtypedeclarationheadernamewithtypeparameters();
this.hasunusedmodifiers = false;
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.aststack[this.astptr];
this.pendingannotation = null;
}
}
protected void consumelabel() {
super.consumelabel();
pushonlabelstack(this.identifierstack[this.identifierptr]);
this.pushonelementstack(k_label, this.labelptr);
}
protected void consumemarkerannotation() {
if (this.topknownelementkind(completion_or_assist_parser) == k_between_annotation_name_and_rparen &&
(this.topknownelementinfo(completion_or_assist_parser) & annotation_name_completion) != 0 ) {
popelement(k_between_annotation_name_and_rparen);
this.restartrecovery = true;
} else {
popelement(k_between_annotation_name_and_rparen);
super.consumemarkerannotation();
}
}
protected void consumemembervaluepair() {
/* check if current awaiting identifier is the completion identifier */
if (this.indexofassistidentifier() < 0){
super.consumemembervaluepair();
membervaluepair membervaluepair = (membervaluepair) this.aststack[this.astptr];
if(this.assistnode != null && membervaluepair.value == this.assistnode) {
this.assistnodeparent = membervaluepair;
}
return;
}

char[] simplename = this.identifierstack[this.identifierptr];
long position = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;
int end = (int) position;
int start = (int) (position >>> 32);

this.expressionptr--;
this.expressionlengthptr--;

completiononmembervaluename membervaluename = new completiononmembervaluename(simplename,start, end);
pushonaststack(membervaluename);
this.assistnode = membervaluename;
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;

this.restartrecovery = true;
}
protected void consumemembervalueasname() {
if ((indexofassistidentifier()) < 0) {
super.consumemembervalueasname();
} else {
super.consumemembervalueasname();
if(this.topknownelementkind(completion_or_assist_parser) == k_between_annotation_name_and_rparen) {
this.restartrecovery = true;
}
}
}
protected void consumemethodbody() {
popelement(k_block_delimiter);
super.consumemethodbody();
}
protected void consumemethodheader() {
super.consumemethodheader();
pushonelementstack(k_block_delimiter);
}
protected void consumemethoddeclaration(boolean isnotabstract) {
if (!isnotabstract) {
popelement(k_block_delimiter);
}
super.consumemethoddeclaration(isnotabstract);
}
protected void consumemodifiers() {
super.consumemodifiers();
// save from stack values
this.lastmodifiersstart = this.intstack[this.intptr];
this.lastmodifiers = 	this.intstack[this.intptr-1];
}
protected void consumereferencetype() {
if (this.identifierlengthstack[this.identifierlengthptr] > 1) { // reducing a qualified name
// potential receiver is being poped, so reset potential receiver
this.invocationtype = no_receiver;
this.qualifier = -1;
}
super.consumereferencetype();
}
protected void consumerestorediet() {
super.consumerestorediet();
if (isinsidemethod()) {
popelement(k_local_initializer_delimiter);
}
}
protected void consumesinglememberannotation() {
if (this.topknownelementkind(completion_or_assist_parser) == k_between_annotation_name_and_rparen &&
(this.topknownelementinfo(completion_or_assist_parser) & annotation_name_completion) != 0 ) {
popelement(k_between_annotation_name_and_rparen);
this.restartrecovery = true;
} else {
popelement(k_between_annotation_name_and_rparen);
super.consumesinglememberannotation();
}
}
protected void consumesinglestaticimportdeclarationname() {
super.consumesinglestaticimportdeclarationname();
this.pendingannotation = null; // the pending annotation cannot be attached to next nodes
}
protected void consumesingletypeimportdeclarationname() {
super.consumesingletypeimportdeclarationname();
this.pendingannotation = null; // the pending annotation cannot be attached to next nodes
}
protected void consumestatementbreakwithlabel() {
super.consumestatementbreakwithlabel();
if (this.record) {
astnode breakstatement = this.aststack[this.astptr];
if (!isalreadypotentialname(breakstatement.sourcestart)) {
addpotentialname(null, breakstatement.sourcestart, breakstatement.sourceend);
}
}

}
protected void consumestatementlabel() {
popelement(k_label);
super.consumestatementlabel();
}
protected void consumestatementswitch() {
super.consumestatementswitch();
if(topknownelementkind(completion_or_assist_parser) == k_switch_label) {
popelement(k_switch_label);
popelement(k_block_delimiter);
}
}
protected void consumestatementwhile() {
super.consumestatementwhile();
if (topknownelementkind(completion_or_assist_parser) == k_control_statement_delimiter) {
popelement(k_control_statement_delimiter);
}
}
protected void consumestaticimportondemanddeclarationname() {
super.consumestaticimportondemanddeclarationname();
this.pendingannotation = null; // the pending annotation cannot be attached to next nodes
}
protected void consumestaticinitializer() {
super.consumestaticinitializer();
this.pendingannotation = null; // the pending annotation cannot be attached to next nodes
}
protected void consumenestedmethod() {
super.consumenestedmethod();
if(!(topknownelementkind(completion_or_assist_parser) == k_block_delimiter)) pushonelementstack(k_block_delimiter);
}
protected void consumenormalannotation() {
if (this.topknownelementkind(completion_or_assist_parser) == k_between_annotation_name_and_rparen &&
(this.topknownelementinfo(completion_or_assist_parser) & annotation_name_completion) != 0 ) {
popelement(k_between_annotation_name_and_rparen);
this.restartrecovery = true;
} else {
popelement(k_between_annotation_name_and_rparen);
super.consumenormalannotation();
}
}
protected void consumepackagedeclarationname() {
super.consumepackagedeclarationname();
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.compilationunit.currentpackage;
this.pendingannotation = null;
}
}
protected void consumepackagedeclarationnamewithmodifiers() {
super.consumepackagedeclarationnamewithmodifiers();
if (this.pendingannotation != null) {
this.pendingannotation.potentialannotatednode = this.compilationunit.currentpackage;
this.pendingannotation = null;
}
}
protected void consumeprimarynonewarrayname() {
// this is class literal access, so reset potential receiver
this.invocationtype = no_receiver;
this.qualifier = -1;

super.consumeprimarynonewarrayname();
}
protected void consumeprimarynonewarraynamesuper() {
// this is class literal access, so reset potential receiver
this.invocationtype = no_receiver;
this.qualifier = -1;

super.consumeprimarynonewarraynamesuper();
}
protected void consumeprimarynonewarraynamethis() {
// this is class literal access, so reset potential receiver
this.invocationtype = no_receiver;
this.qualifier = -1;

super.consumeprimarynonewarraynamethis();
}
protected void consumepushposition() {
super.consumepushposition();
if(topknownelementkind(completion_or_assist_parser) == k_binary_operator) {
int info = topknownelementinfo(completion_or_assist_parser);
popelement(k_binary_operator);
pushonelementstack(k_unary_operator, info);
}
}
protected void consumetoken(int token) {
if(this.isfirst) {
super.consumetoken(token);
return;
}
if(this.canbeexplicitconstructor == nexttoken) {
this.canbeexplicitconstructor = yes;
} else {
this.canbeexplicitconstructor = no;
}

int previous = this.previoustoken;
int previdentifierptr = this.previousidentifierptr;

if (isinsidemethod() || isinsidefieldinitialization() || isinsideannotation()) {
switch(token) {
case tokennamelparen:
if(previous == tokennameidentifier &&
topknownelementkind(completion_or_assist_parser) == k_parameterized_method_invocation) {
popelement(k_parameterized_method_invocation);
} else {
popelement(k_between_new_and_left_bracket);
}
break;
case tokennamelbrace:
popelement(k_between_new_and_left_bracket);
break;
case tokennamelbracket:
if(topknownelementkind(completion_or_assist_parser) == k_between_new_and_left_bracket) {
popelement(k_between_new_and_left_bracket);
pushonelementstack(k_array_creation);
}
break;
case tokennamerbrace:
int kind = topknownelementkind(completion_or_assist_parser);
switch (kind) {
case k_block_delimiter:
popelement(k_block_delimiter);
break;
case k_member_value_array_initializer:
popelement(k_member_value_array_initializer);
break;
default:
popelement(k_array_initializer);
break;
}
break;
case tokennamerbracket:
if(topknownelementkind(completion_or_assist_parser) == k_between_left_and_right_bracket) {
popelement(k_between_left_and_right_bracket);
}
break;

}
}
super.consumetoken(token);

// if in field initializer (directly or not), on the completion identifier and not in recovery mode yet
// then position end of file at cursor location (so that we have the same behavior as
// in method bodies)
if (token == tokennameidentifier
&& this.identifierstack[this.identifierptr] == assistidentifier()
&& this.currentelement == null
&& isindirectlyinsidefieldinitialization()) {
this.scanner.eofposition = this.cursorlocation < integer.max_value ? this.cursorlocation+1 : this.cursorlocation;
}

// if in a method or if in a field initializer
if (isinsidemethod() || isinsidefieldinitialization() || isinsideattributevalue()) {
switch (token) {
case tokennamedot:
switch (previous) {
case tokennamethis: // e.g. this[.]fred()
this.invocationtype = explicit_receiver;
break;
case tokennamesuper: // e.g. super[.]fred()
this.invocationtype = super_receiver;
break;
case tokennameidentifier: // e.g. bar[.]fred()
if (topknownelementkind(completion_or_assist_parser) != k_between_new_and_left_bracket) {
if (this.identifierptr != previdentifierptr) { // if identifier has been consumed, e.g. this.x[.]fred()
this.invocationtype = explicit_receiver;
} else {
this.invocationtype = name_receiver;
}
}
break;
}
break;
case tokennameidentifier:
if (previous == tokennamedot) { // e.g. foo().[fred]()
if (this.invocationtype != super_receiver // e.g. not super.[fred]()
&& this.invocationtype != name_receiver // e.g. not bar.[fred]()
&& this.invocationtype != allocation // e.g. not new foo.[bar]()
&& this.invocationtype != qualified_allocation) { // e.g. not fred().new foo.[bar]()

this.invocationtype = explicit_receiver;
this.qualifier = this.expressionptr;
}
}
if (previous == tokennamegreater) { // e.g. foo().<x>[fred]()
if (this.invocationtype != super_receiver // e.g. not super.<x>[fred]()
&& this.invocationtype != name_receiver // e.g. not bar.<x>[fred]()
&& this.invocationtype != allocation // e.g. not new foo.<x>[bar]()
&& this.invocationtype != qualified_allocation) { // e.g. not fred().new foo.<x>[bar]()

if (topknownelementkind(completion_or_assist_parser) == k_parameterized_method_invocation) {
this.invocationtype = explicit_receiver;
this.qualifier = this.expressionptr;
}
}
}
break;
case tokennamenew:
pushonelementstack(k_between_new_and_left_bracket);
this.qualifier = this.expressionptr; // nb: even if there is no qualification, set it to the expression ptr so that the number of arguments are correctly computed
if (previous == tokennamedot) { // e.g. fred().[new] x()
this.invocationtype = qualified_allocation;
} else { // e.g. [new] x()
this.invocationtype = allocation;
}
break;
case tokennamethis:
if (previous == tokennamedot) { // e.g. fred().[this]()
this.invocationtype = qualified_allocation;
this.qualifier = this.expressionptr;
}
break;
case tokennamesuper:
if (previous == tokennamedot) { // e.g. fred().[super]()
this.invocationtype = qualified_allocation;
this.qualifier = this.expressionptr;
}
break;
case tokennamecatch:
pushonelementstack(k_between_catch_and_right_paren);
break;
case tokennamelparen:
if (this.invocationtype == no_receiver || this.invocationtype == name_receiver || this.invocationtype == super_receiver) {
this.qualifier = this.expressionptr; // remenber the last expression so that arguments are correctly computed
}
switch (previous) {
case tokennameidentifier: // e.g. fred[(]) or foo.fred[(])
if (topknownelementkind(completion_or_assist_parser) == k_selector) {
int info = 0;
if(topknownelementkind(completion_or_assist_parser,1) == k_between_annotation_name_and_rparen &&
(info=topknownelementinfo(completion_or_assist_parser,1) & lparen_not_consumed) != 0) {
popelement(k_selector);
popelement(k_between_annotation_name_and_rparen);
if ((info & annotation_name_completion) != 0) {
this.pushonelementstack(k_between_annotation_name_and_rparen, lparen_consumed | annotation_name_completion);
} else {
this.pushonelementstack(k_between_annotation_name_and_rparen, lparen_consumed);
}
} else {
this.pushonelementstack(k_selector_invocation_type, this.invocationtype);
this.pushonelementstack(k_selector_qualifier, this.qualifier);
}
}
this.qualifier = -1;
this.invocationtype = no_receiver;
break;
case tokennamethis: // explicit constructor invocation, e.g. this[(]1, 2)
if (topknownelementkind(completion_or_assist_parser) == k_selector) {
this.pushonelementstack(k_selector_invocation_type, (this.invocationtype == qualified_allocation) ? qualified_allocation : allocation);
this.pushonelementstack(k_selector_qualifier, this.qualifier);
}
this.qualifier = -1;
this.invocationtype = no_receiver;
break;
case tokennamesuper: // explicit constructor invocation, e.g. super[(]1, 2)
if (topknownelementkind(completion_or_assist_parser) == k_selector) {
this.pushonelementstack(k_selector_invocation_type, (this.invocationtype == qualified_allocation) ? qualified_allocation : allocation);
this.pushonelementstack(k_selector_qualifier, this.qualifier);
}
this.qualifier = -1;
this.invocationtype = no_receiver;
break;
case tokennamegreater: // explicit constructor invocation, e.g. fred<x>[(]1, 2)
case tokennameright_shift: // or fred<x<x>>[(]1, 2)
case tokennameunsigned_right_shift: //or fred<x<x<x>>>[(]1, 2)
if (topknownelementkind(completion_or_assist_parser) == k_selector) {
int info;
if (topknownelementkind(completion_or_assist_parser, 1) == k_binary_operator &&
((info = topknownelementinfo(completion_or_assist_parser, 1)) == greater || info == right_shift || info == unsigned_right_shift)) {
// it's not a selector invocation
popelement(k_selector);
} else {
this.pushonelementstack(k_selector_invocation_type, (this.invocationtype == qualified_allocation) ? qualified_allocation : allocation);
this.pushonelementstack(k_selector_qualifier, this.qualifier);
}
}
this.qualifier = -1;
this.invocationtype = no_receiver;
break;
}
break;
case tokennamelbrace:
int kind = topknownelementkind(completion_or_assist_parser);
if(kind == k_field_initializer_delimiter
|| kind == k_local_initializer_delimiter
|| kind == k_array_creation) {
pushonelementstack(k_array_initializer, this.endposition);
} else if (kind == k_between_annotation_name_and_rparen) {
pushonelementstack(k_member_value_array_initializer, this.endposition);
} else {
if (kind == k_control_statement_delimiter) {
int info = topknownelementinfo(completion_or_assist_parser);
popelement(k_control_statement_delimiter);
if (info == if) {
pushonelementstack(k_block_delimiter, if, this.expressionstack[this.expressionptr]);
} else {
pushonelementstack(k_block_delimiter, info);
}
} else {
switch(previous) {
case tokennamerparen :
switch(this.previouskind) {
case k_between_catch_and_right_paren :
pushonelementstack(k_block_delimiter, catch);
break;
case k_between_switch_and_right_paren :
pushonelementstack(k_block_delimiter, switch);
break;
case k_between_synchronized_and_right_paren :
pushonelementstack(k_block_delimiter, synchronized);
break;
default :
pushonelementstack(k_block_delimiter);
break;
}
break;
case tokennametry :
pushonelementstack(k_block_delimiter, try);
break;
case tokennamedo:
pushonelementstack(k_block_delimiter, do);
break;
default :
pushonelementstack(k_block_delimiter);
break;
}
}
}
break;
case tokennamelbracket:
if(topknownelementkind(completion_or_assist_parser) != k_array_creation) {
pushonelementstack(k_between_left_and_right_bracket);
} else {
switch (previous) {
case tokennameidentifier:
case tokennameboolean:
case tokennamebyte:
case tokennamechar:
case tokennamedouble:
case tokennamefloat:
case tokennameint:
case tokennamelong:
case tokennameshort:
case tokennamegreater:
case tokennameright_shift:
case tokennameunsigned_right_shift:
this.invocationtype = no_receiver;
this.qualifier = -1;
break;
}
}
break;
case tokennamerparen:
switch(topknownelementkind(completion_or_assist_parser)) {
case k_between_catch_and_right_paren :
popelement(k_between_catch_and_right_paren);
break;
case k_between_instanceof_and_rparen :
popelement(k_between_instanceof_and_rparen);
//$fall-through$
case k_between_if_and_right_paren :
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth) {
popelement(k_between_if_and_right_paren);
pushonelementstack(k_control_statement_delimiter, if, this.expressionstack[this.expressionptr]);
}
break;
case k_between_while_and_right_paren :
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth) {
popelement(k_between_while_and_right_paren);
pushonelementstack(k_control_statement_delimiter, while);
}
break;
case k_between_for_and_right_paren :
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth) {
popelement(k_between_for_and_right_paren);
pushonelementstack(k_control_statement_delimiter, for);
}
break;
case k_between_switch_and_right_paren :
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth) {
popelement(k_between_switch_and_right_paren);
}
break;
case k_between_synchronized_and_right_paren :
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth) {
popelement(k_between_synchronized_and_right_paren);
}
break;
}
break;
case tokennamethrow:
pushonelementstack(k_inside_throw_statement, this.bracketdepth);
break;
case tokennamesemicolon:
switch(topknownelementkind(completion_or_assist_parser)) {
case k_inside_throw_statement :
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth) {
popelement(k_inside_throw_statement);
}
break;
case k_inside_return_statement :
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth) {
popelement(k_inside_return_statement);
}
break;
case k_inside_assert_statement :
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth) {
popelement(k_inside_assert_statement);
}
break;
case k_inside_assert_exception :
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth) {
popelement(k_inside_assert_exception);
popelement(k_inside_assert_statement);
}
break;
case k_inside_break_statement:
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth) {
popelement(k_inside_break_statement);
}
break;
case k_inside_continue_statement:
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth) {
popelement(k_inside_continue_statement);
}
break;
case k_between_for_and_right_paren:
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth - 1) {
popelement(k_between_for_and_right_paren);
pushonelementstack(k_inside_for_conditional, this.bracketdepth - 1);
}
break;
case k_inside_for_conditional:
if(topknownelementinfo(completion_or_assist_parser) == this.bracketdepth - 1) {
popelement(k_inside_for_conditional);
pushonelementstack(k_between_for_and_right_paren, this.bracketdepth - 1);
}
break;
}
break;
case tokennamereturn:
pushonelementstack(k_inside_return_statement, this.bracketdepth);
break;
case tokennamemultiply:
pushonelementstack(k_binary_operator, multiply);
break;
case tokennamedivide:
pushonelementstack(k_binary_operator, divide);
break;
case tokennameremainder:
pushonelementstack(k_binary_operator, remainder);
break;
case tokennameplus:
pushonelementstack(k_binary_operator, plus);
break;
case tokennameminus:
pushonelementstack(k_binary_operator, minus);
break;
case tokennameleft_shift:
pushonelementstack(k_binary_operator, left_shift);
break;
case tokennameright_shift:
pushonelementstack(k_binary_operator, right_shift);
break;
case tokennameunsigned_right_shift:
pushonelementstack(k_binary_operator, unsigned_right_shift);
break;
case tokennameless:
switch(previous) {
case tokennamedot :
pushonelementstack(k_parameterized_method_invocation);
break;
case tokennamenew :
pushonelementstack(k_parameterized_allocation);
break;
}
pushonelementstack(k_binary_operator, less);
break;
case tokennamegreater:
pushonelementstack(k_binary_operator, greater);
break;
case tokennameless_equal:
pushonelementstack(k_binary_operator, less_equal);
break;
case tokennamegreater_equal:
pushonelementstack(k_binary_operator, greater_equal);
break;
case tokennameand:
pushonelementstack(k_binary_operator, and);
break;
case tokennamexor:
pushonelementstack(k_binary_operator, xor);
break;
case tokennameor:
pushonelementstack(k_binary_operator, or);
break;
case tokennameand_and:
pushonelementstack(k_binary_operator, and_and);
break;
case tokennameor_or:
pushonelementstack(k_binary_operator, or_or);
break;
case tokennameplus_plus:
pushonelementstack(k_unary_operator, plus_plus);
break;
case tokennameminus_minus:
pushonelementstack(k_unary_operator, minus_minus);
break;
case tokennametwiddle:
pushonelementstack(k_unary_operator, twiddle);
break;
case tokennamenot:
pushonelementstack(k_unary_operator, not);
break;
case tokennameequal_equal:
pushonelementstack(k_binary_operator, equal_equal);
break;
case tokennamenot_equal:
pushonelementstack(k_binary_operator, not_equal);
break;
case tokennameinstanceof:
pushonelementstack(k_binary_operator, instanceof);
break;
case tokennamequestion:
if(previous != tokennameless && previous != tokennamecomma) {
pushonelementstack(k_conditional_operator, question);
}
break;
case tokennamecolon:
switch (topknownelementkind(completion_or_assist_parser)) {
case k_conditional_operator:
if (topknownelementinfo(completion_or_assist_parser) == question) {
popelement(k_conditional_operator);
pushonelementstack(k_conditional_operator, colon);
}
break;
case k_between_case_and_colon:
popelement(k_between_case_and_colon);
break;
case k_between_default_and_colon:
popelement(k_between_default_and_colon);
break;
case k_inside_assert_statement:
pushonelementstack(k_inside_assert_exception, this.bracketdepth);
break;
}
break;
case tokennameif:
pushonelementstack(k_between_if_and_right_paren, this.bracketdepth);
break;
case tokennameelse:
if (topknownelementkind(completion_or_assist_parser) == k_control_statement_delimiter) {
popelement(k_control_statement_delimiter);
}
pushonelementstack(k_control_statement_delimiter);
break;
case tokennamewhile:
pushonelementstack(k_between_while_and_right_paren, this.bracketdepth);
break;
case tokennamefor:
pushonelementstack(k_between_for_and_right_paren, this.bracketdepth);
break;
case tokennameswitch:
pushonelementstack(k_between_switch_and_right_paren, this.bracketdepth);
break;
case tokennamesynchronized:
pushonelementstack(k_between_synchronized_and_right_paren, this.bracketdepth);
break;
case tokennameassert:
pushonelementstack(k_inside_assert_statement, this.bracketdepth);
break;
case tokennamecase :
pushonelementstack(k_between_case_and_colon);
break;
case tokennamedefault :
pushonelementstack(k_between_default_and_colon);
break;
case tokennameextends:
pushonelementstack(k_extends_keyword);
break;
case tokennamebreak:
pushonelementstack(k_inside_break_statement, this.bracketdepth);
break;
case tokennamecontinue:
pushonelementstack(k_inside_continue_statement, this.bracketdepth);
break;
}
} else if (isinsideannotation()){
switch (token) {
case tokennamelbrace:
this.bracketdepth++;
int kind = topknownelementkind(completion_or_assist_parser);
if (kind == k_between_annotation_name_and_rparen) {
pushonelementstack(k_member_value_array_initializer, this.endposition);
}
break;
}
} else {
switch(token) {
case tokennameextends:
pushonelementstack(k_extends_keyword);
break;
case tokennameless:
pushonelementstack(k_binary_operator, less);
break;
case tokennamegreater:
pushonelementstack(k_binary_operator, greater);
break;
case tokennameright_shift:
pushonelementstack(k_binary_operator, right_shift);
break;
case tokennameunsigned_right_shift:
pushonelementstack(k_binary_operator, unsigned_right_shift);
break;

}
}
}
protected void consumeonlysynchronized() {
super.consumeonlysynchronized();
this.hasunusedmodifiers = false;
}
protected void consumeonlytypearguments() {
super.consumeonlytypearguments();
popelement(k_binary_operator);
if(topknownelementkind(completion_or_assist_parser) == k_parameterized_method_invocation) {
popelement(k_parameterized_method_invocation);
pushonelementstack(k_parameterized_method_invocation, inside_name);
} else {
popelement(k_parameterized_allocation);
}
}
protected void consumeonlytypeargumentsforcastexpression() {
super.consumeonlytypeargumentsforcastexpression();
pushonelementstack(k_parameterized_cast);
}
protected void consumeopenfakeblock() {
super.consumeopenfakeblock();
pushonelementstack(k_block_delimiter);
}
protected void consumerightparen() {
super.consumerightparen();
}
protected void consumereferencetype1() {
super.consumereferencetype1();
popelement(k_binary_operator);
}
protected void consumereferencetype2() {
super.consumereferencetype2();
popelement(k_binary_operator);
}
protected void consumereferencetype3() {
super.consumereferencetype3();
popelement(k_binary_operator);
}
protected void consumetypeargumentreferencetype1() {
super.consumetypeargumentreferencetype1();
popelement(k_binary_operator);
}
protected void consumetypeargumentreferencetype2() {
super.consumetypeargumentreferencetype2();
popelement(k_binary_operator);
}
protected void consumetypearguments() {
super.consumetypearguments();
popelement(k_binary_operator);
}
protected void consumetypeheadernamewithtypeparameters() {
super.consumetypeheadernamewithtypeparameters();

typedeclaration typedecl = (typedeclaration)this.aststack[this.astptr];
classheaderextendsorimplements((typedecl.modifiers & classfileconstants.accinterface) != 0);
}
protected void consumetypeimportondemanddeclarationname() {
super.consumetypeimportondemanddeclarationname();
this.pendingannotation = null; // the pending annotation cannot be attached to next nodes
}
protected void consumetypeparameters() {
super.consumetypeparameters();
popelement(k_binary_operator);
}
protected void consumetypeparameterheader() {
super.consumetypeparameterheader();
typeparameter typeparameter = (typeparameter) this.genericsstack[this.genericsptr];
if(typeparameter.type != null || (typeparameter.bounds != null && typeparameter.bounds.length > 0)) return;

if (assistidentifier() == null && this.currenttoken == tokennameidentifier) { // test below copied from completionscanner.getcurrentidentifiersource()
if (this.cursorlocation < this.scanner.startposition && this.scanner.currentposition == this.scanner.startposition){ // fake empty identifier got issued
this.pushidentifier();
} else if (this.cursorlocation+1 >= this.scanner.startposition && this.cursorlocation < this.scanner.currentposition){
this.pushidentifier();
} else {
return;
}
} else {
return;
}

completiononkeyword1 keyword = new completiononkeyword1(
this.identifierstack[this.identifierptr],
this.identifierpositionstack[this.identifierptr],
keywords.extends);
keyword.cancompleteemptytoken = true;
typeparameter.type = keyword;

this.identifierptr--;
this.identifierlengthptr--;

this.assistnode = typeparameter.type;
this.lastcheckpoint = typeparameter.type.sourceend + 1;
}
protected void consumetypeparameter1() {
super.consumetypeparameter1();
popelement(k_binary_operator);
}
protected void consumetypeparameterwithextends() {
super.consumetypeparameterwithextends();
if (this.assistnode != null && this.assistnodeparent == null) {
typeparameter typeparameter = (typeparameter) this.genericsstack[this.genericsptr];
if (typeparameter != null && typeparameter.type == this.assistnode)
this.assistnodeparent = typeparameter;
}
popelement(k_extends_keyword);
}
protected void consumetypeparameterwithextendsandbounds() {
super.consumetypeparameterwithextendsandbounds();
if (this.assistnode != null && this.assistnodeparent == null) {
typeparameter typeparameter = (typeparameter) this.genericsstack[this.genericsptr];
if (typeparameter != null && typeparameter.type == this.assistnode)
this.assistnodeparent = typeparameter;
}
popelement(k_extends_keyword);
}
protected void consumetypeparameter1withextends() {
super.consumetypeparameter1withextends();
if (this.assistnode != null && this.assistnodeparent == null) {
typeparameter typeparameter = (typeparameter) this.genericsstack[this.genericsptr];
if (typeparameter != null && typeparameter.type == this.assistnode)
this.assistnodeparent = typeparameter;
}
popelement(k_extends_keyword);
}
protected void consumetypeparameter1withextendsandbounds() {
super.consumetypeparameter1withextendsandbounds();
if (this.assistnode != null && this.assistnodeparent == null) {
typeparameter typeparameter = (typeparameter) this.genericsstack[this.genericsptr];
if (typeparameter != null && typeparameter.type == this.assistnode)
this.assistnodeparent = typeparameter;
}
popelement(k_extends_keyword);
}
protected void consumewildcard() {
super.consumewildcard();
if (assistidentifier() == null && this.currenttoken == tokennameidentifier) { // test below copied from completionscanner.getcurrentidentifiersource()
if (this.cursorlocation < this.scanner.startposition && this.scanner.currentposition == this.scanner.startposition){ // fake empty identifier got issued
this.pushidentifier();
} else if (this.cursorlocation+1 >= this.scanner.startposition && this.cursorlocation < this.scanner.currentposition){
this.pushidentifier();
} else {
return;
}
} else {
return;
}
wildcard wildcard = (wildcard) this.genericsstack[this.genericsptr];
completiononkeyword1 keyword = new completiononkeyword1(
this.identifierstack[this.identifierptr],
this.identifierpositionstack[this.identifierptr],
new char[][]{keywords.extends, keywords.super} );
keyword.cancompleteemptytoken = true;
wildcard.kind = wildcard.extends;
wildcard.bound = keyword;

this.identifierptr--;
this.identifierlengthptr--;

this.assistnode = wildcard.bound;
this.lastcheckpoint = wildcard.bound.sourceend + 1;
}
protected void consumewildcard1() {
super.consumewildcard1();
popelement(k_binary_operator);
}
protected void consumewildcard2() {
super.consumewildcard2();
popelement(k_binary_operator);
}
protected void consumewildcard3() {
super.consumewildcard3();
popelement(k_binary_operator);
}
protected void consumewildcardboundsextends() {
super.consumewildcardboundsextends();
if (this.assistnode != null && this.assistnodeparent == null) {
wildcard wildcard = (wildcard) this.genericsstack[this.genericsptr];
if (wildcard != null && wildcard.bound == this.assistnode)
this.assistnodeparent = wildcard;
}
popelement(k_extends_keyword);
}
protected void consumewildcardbounds1extends() {
super.consumewildcardbounds1extends();
if (this.assistnode != null && this.assistnodeparent == null) {
wildcard wildcard = (wildcard) this.genericsstack[this.genericsptr];
if (wildcard != null && wildcard.bound == this.assistnode)
this.assistnodeparent = wildcard;
}
popelement(k_extends_keyword);
}
protected void consumewildcardbounds2extends() {
super.consumewildcardbounds2extends();
if (this.assistnode != null && this.assistnodeparent == null) {
wildcard wildcard = (wildcard) this.genericsstack[this.genericsptr];
if (wildcard != null && wildcard.bound == this.assistnode)
this.assistnodeparent = wildcard;
}
popelement(k_extends_keyword);
}
protected void consumewildcardbounds3extends() {
super.consumewildcardbounds3extends();
if (this.assistnode != null && this.assistnodeparent == null) {
wildcard wildcard = (wildcard) this.genericsstack[this.genericsptr];
if (wildcard != null && wildcard.bound == this.assistnode)
this.assistnodeparent = wildcard;
}
popelement(k_extends_keyword);
}
protected void consumeunaryexpression(int op) {
super.consumeunaryexpression(op);
popelement(k_unary_operator);

if(this.expressionstack[this.expressionptr] instanceof unaryexpression) {
unaryexpression exp = (unaryexpression) this.expressionstack[this.expressionptr];
if(this.assistnode != null && exp.expression == this.assistnode) {
this.assistnodeparent = exp;
}
}
}
protected void consumeunaryexpression(int op, boolean post) {
super.consumeunaryexpression(op, post);
popelement(k_unary_operator);

if(this.expressionstack[this.expressionptr] instanceof unaryexpression) {
unaryexpression exp = (unaryexpression) this.expressionstack[this.expressionptr];
if(this.assistnode != null && exp.expression == this.assistnode) {
this.assistnodeparent = exp;
}
}
}
public methoddeclaration converttomethoddeclaration(constructordeclaration c, compilationresult compilationresult) {
methoddeclaration methoddeclaration = super.converttomethoddeclaration(c, compilationresult);
if (this.sourceends != null) {
int selectorsourceend = this.sourceends.removekey(c);
if (selectorsourceend != -1)
this.sourceends.put(methoddeclaration, selectorsourceend);
}
return methoddeclaration;
}
public importreference createassistimportreference(char[][] tokens, long[] positions, int mod){
return new completiononimportreference(tokens, positions, mod);
}
public importreference createassistpackagereference(char[][] tokens, long[] positions){
return new completiononpackagereference(tokens, positions);
}
public namereference createqualifiedassistnamereference(char[][] previousidentifiers, char[] assistname, long[] positions){
return new completiononqualifiednamereference(
previousidentifiers,
assistname,
positions,
isinsideattributevalue());
}
public typereference createqualifiedassisttypereference(char[][] previousidentifiers, char[] assistname, long[] positions){
switch (topknownelementkind(completion_or_assist_parser)) {
case k_next_typeref_is_exception :
return new completiononqualifiedtypereference(
previousidentifiers,
assistname,
positions,
completiononqualifiedtypereference.k_exception);
case k_next_typeref_is_class :
return new completiononqualifiedtypereference(
previousidentifiers,
assistname,
positions,
completiononqualifiedtypereference.k_class);
case k_next_typeref_is_interface :
return new completiononqualifiedtypereference(
previousidentifiers,
assistname,
positions,
completiononqualifiedtypereference.k_interface);
default :
return new completiononqualifiedtypereference(
previousidentifiers,
assistname,
positions);
}
}
public typereference createparameterizedqualifiedassisttypereference(char[][] previousidentifiers, typereference[][] typearguments, char[] assistname, typereference[] assisttypearguments, long[] positions) {
boolean isparameterized = false;
for (int i = 0; i < typearguments.length; i++) {
if(typearguments[i] != null) {
isparameterized = true;
}
}
if(!isparameterized) {
return createqualifiedassisttypereference(previousidentifiers, assistname, positions);
} else {
switch (topknownelementkind(completion_or_assist_parser)) {
case k_next_typeref_is_exception :
return new completiononparameterizedqualifiedtypereference(
previousidentifiers,
typearguments,
assistname,
positions,
completiononparameterizedqualifiedtypereference.k_exception);
case k_next_typeref_is_class :
return new completiononparameterizedqualifiedtypereference(
previousidentifiers,
typearguments,
assistname,
positions,
completiononparameterizedqualifiedtypereference.k_class);
case k_next_typeref_is_interface :
return new completiononparameterizedqualifiedtypereference(
previousidentifiers,
typearguments,
assistname,
positions,
completiononparameterizedqualifiedtypereference.k_interface);
default :
return new completiononparameterizedqualifiedtypereference(
previousidentifiers,
typearguments,
assistname,
positions);
}
}
}
public namereference createsingleassistnamereference(char[] assistname, long position) {
int kind = topknownelementkind(completion_or_assist_parser);
if(!isinsidemethod()) {
if (isinsidefieldinitialization()) {
return new completiononsinglenamereference(
assistname,
position,
new char[][]{keywords.false, keywords.true},
false,
isinsideattributevalue());
}
return new completiononsinglenamereference(assistname, position, isinsideattributevalue());
} else {
boolean canbeexplicitconstructorcall = false;
if(kind == k_block_delimiter
&& this.previouskind == k_block_delimiter
&& this.previousinfo == do) {
return new completiononkeyword3(assistname, position, keywords.while);
} else if(kind == k_block_delimiter
&& this.previouskind == k_block_delimiter
&& this.previousinfo == try) {
return new completiononkeyword3(assistname, position, new char[][]{keywords.catch, keywords.finally});
} else if(kind == k_block_delimiter
&& topknownelementinfo(completion_or_assist_parser) == switch) {
return new completiononkeyword3(assistname, position, new char[][]{keywords.case, keywords.default});
} else {
char[][] keywords = new char[keywords.count][];
int count = 0;

if((this.lastmodifiers & classfileconstants.accstatic) == 0) {
keywords[count++]= keywords.super;
keywords[count++]= keywords.this;
}
keywords[count++]= keywords.new;
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=269493: keywords are not proposed in a for
// loop without block. completion while at k_control_statement_delimiter case needs to handled
// similar to the k_block_delimiter with minor differences.
if(kind == k_block_delimiter || kind == k_control_statement_delimiter) {
if(this.canbeexplicitconstructor == yes) {
canbeexplicitconstructorcall = true;
}
if (this.options.compliancelevel >= classfileconstants.jdk1_4) {
keywords[count++]= keywords.assert;
}
keywords[count++]= keywords.do;
keywords[count++]= keywords.for;
keywords[count++]= keywords.if;
keywords[count++]= keywords.return;
keywords[count++]= keywords.switch;
keywords[count++]= keywords.synchronized;
keywords[count++]= keywords.throw;
keywords[count++]= keywords.try;
keywords[count++]= keywords.while;

keywords[count++]= keywords.final;
keywords[count++]= keywords.class;

if(this.previouskind == k_block_delimiter) {
switch (this.previousinfo) {
case if :
keywords[count++]= keywords.else;
break;
case catch :
keywords[count++]= keywords.catch;
keywords[count++]= keywords.finally;
break;
}
} else if(this.previouskind == k_control_statement_delimiter && this.previousinfo == if) {
keywords[count++]= keywords.else;
}
if(isinsideloop()) {
keywords[count++]= keywords.continue;
}
if(isinsidebreakable()) {
keywords[count++]= keywords.break;
}
} else if(kind != k_between_case_and_colon && kind != k_between_default_and_colon) {
keywords[count++]= keywords.true;
keywords[count++]= keywords.false;
keywords[count++]= keywords.null;

if(kind == k_switch_label) {
if(topknownelementinfo(completion_or_assist_parser) != default) {
keywords[count++]= keywords.default;
}
keywords[count++]= keywords.break;
keywords[count++]= keywords.case;
if (this.options.compliancelevel >= classfileconstants.jdk1_4) {
keywords[count++]= keywords.assert;
}
keywords[count++]= keywords.do;
keywords[count++]= keywords.for;
keywords[count++]= keywords.if;
keywords[count++]= keywords.return;
keywords[count++]= keywords.switch;
keywords[count++]= keywords.synchronized;
keywords[count++]= keywords.throw;
keywords[count++]= keywords.try;
keywords[count++]= keywords.while;

keywords[count++]= keywords.final;
keywords[count++]= keywords.class;

if(isinsideloop()) {
keywords[count++]= keywords.continue;
}
}
}
system.arraycopy(keywords, 0 , keywords = new char[count][], 0, count);

return new completiononsinglenamereference(assistname, position, keywords, canbeexplicitconstructorcall, isinsideattributevalue());
}
}
}
public typereference createsingleassisttypereference(char[] assistname, long position) {
switch (topknownelementkind(completion_or_assist_parser)) {
case k_next_typeref_is_exception :
return new completiononsingletypereference(assistname, position, completiononsingletypereference.k_exception) ;
case k_next_typeref_is_class :
return new completiononsingletypereference(assistname, position, completiononsingletypereference.k_class);
case k_next_typeref_is_interface :
return new completiononsingletypereference(assistname, position, completiononsingletypereference.k_interface);
default :
return new completiononsingletypereference(assistname, position);
}
}
public typereference createparameterizedsingleassisttypereference(typereference[] typearguments, char[] assistname, long position) {
return createsingleassisttypereference(assistname, position);
}
protected stringliteral createstringliteral(char[] token, int start, int end, int linenumber) {
if (start <= this.cursorlocation && this.cursorlocation <= end){
char[] source = this.scanner.source;

int contentstart = start;
int contentend = end;

// " could be as unicode \u0022
int pos = contentstart;
if(source[pos] == '\"') {
contentstart = pos + 1;
} else if(source[pos] == '\\' && source[pos+1] == 'u') {
pos += 2;
while (source[pos] == 'u') {
pos++;
}
if(source[pos] == 0 && source[pos + 1] == 0 && source[pos + 2] == 2 && source[pos + 3] == 2) {
contentstart = pos + 4;
}
}

pos = contentend;
if(source[pos] == '\"') {
contentend = pos - 1;
} else if(source.length > 5 && source[pos-4] == 'u') {
if(source[pos - 3] == 0 && source[pos - 2] == 0 && source[pos - 1] == 2 && source[pos] == 2) {
pos -= 5;
while (pos > -1 && source[pos] == 'u') {
pos--;
}
if(pos > -1 && source[pos] == '\\') {
contentend = pos - 1;
}
}
}

if(contentend < start) {
contentend = end;
}

if(this.cursorlocation != end || end == contentend) {
completiononstringliteral stringliteral = new completiononstringliteral(
token,
start,
end,
contentstart,
contentend,
linenumber);

this.assistnode = stringliteral;
this.restartrecovery = true;
this.lastcheckpoint = end;

return stringliteral;
}
}
return super.createstringliteral(token, start, end, linenumber);
}
protected typereference copydims(typereference typeref, int dim) {
if (this.assistnode == typeref) {
return typeref;
}
typereference result = super.copydims(typeref, dim);
if (this.assistnodeparent == typeref) {
this.assistnodeparent = result;
}
return result;
}
public compilationunitdeclaration dietparse(icompilationunit sourceunit, compilationresult compilationresult, int cursorloc) {

this.cursorlocation = cursorloc;
completionscanner completionscanner = (completionscanner)this.scanner;
completionscanner.completionidentifier = null;
completionscanner.cursorlocation = cursorloc;
return this.dietparse(sourceunit, compilationresult);
}
/*
* flush parser/scanner state regarding to code assist
*/
public void flushassiststate() {

super.flushassiststate();
this.isorphancompletionnode = false;
this.isalreadyattached = false;
this.assistnodeparent = null;
completionscanner completionscanner = (completionscanner)this.scanner;
completionscanner.completedidentifierstart = 0;
completionscanner.completedidentifierend = -1;
}

protected typereference gettypereferenceforgenerictype(int dim,	int identifierlength, int numberofidentifiers) {
typereference ref = super.gettypereferenceforgenerictype(dim, identifierlength, numberofidentifiers);

if(this.assistnode != null) {
if (identifierlength == 1 && numberofidentifiers == 1) {
parameterizedsingletypereference singleref = (parameterizedsingletypereference) ref;
typereference[] typearguments = singleref.typearguments;
for (int i = 0; i < typearguments.length; i++) {
if(typearguments[i] == this.assistnode) {
this.assistnodeparent = ref;
return ref;
}
}
} else {
parameterizedqualifiedtypereference qualifiedref = (parameterizedqualifiedtypereference) ref;
typereference[][] typearguments = qualifiedref.typearguments;
for (int i = 0; i < typearguments.length; i++) {
if(typearguments[i] != null) {
for (int j = 0; j < typearguments[i].length; j++) {
if(typearguments[i][j] == this.assistnode) {
this.assistnodeparent = ref;
return ref;
}
}
}
}

}
}

return ref;
}
protected namereference getunspecifiedreference() {
namereference namereference = super.getunspecifiedreference();
if (this.record) {
recordreference(namereference);
}
return namereference;
}
protected namereference getunspecifiedreferenceoptimized() {
if (this.identifierlengthstack[this.identifierlengthptr] > 1) { // reducing a qualified name
// potential receiver is being poped, so reset potential receiver
this.invocationtype = no_receiver;
this.qualifier = -1;
}
namereference namereference = super.getunspecifiedreferenceoptimized();
if (this.record) {
recordreference(namereference);
}
return namereference;
}
private boolean isalreadypotentialname(int identifierstart) {
if (this.potentialvariablenamesptr < 0) return false;

return identifierstart <= this.potentialvariablenameends[this.potentialvariablenamesptr];
}
protected int indexofassistidentifier(boolean usegenericsstack) {
if (this.record) return -1; // when names are recorded there is no assist identifier
return super.indexofassistidentifier(usegenericsstack);
}
public void initialize() {
super.initialize();
this.labelptr = -1;
initializeforblockstatements();
}
public void initialize(boolean initializenls) {
super.initialize(initializenls);
this.labelptr = -1;
initializeforblockstatements();
}
/*
* initializes the state of the parser that is about to go for blockstatements.
*/
private void initializeforblockstatements() {
this.previoustoken = -1;
this.previousidentifierptr = -1;
this.invocationtype = no_receiver;
this.qualifier = -1;
popuntilelement(k_switch_label);
if(topknownelementkind(completion_or_assist_parser) != k_switch_label) {
if (topknownelementkind(completion_or_assist_parser) == k_array_initializer) {
// if recovery is taking place in an array initializer, we should prevent popping
// up to the enclosing block until the array initializer is properly closed
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=249704
popuntilelement(k_array_initializer);
} else {
popuntilelement(k_block_delimiter);
}
}
}
public void initializescanner(){
this.scanner = new completionscanner(this.options.sourcelevel);
}
/**
* returns whether the completion is just after an array type
* e.g. string[].[cursor]
*/
private boolean isafterarraytype() {
// tbd: the following relies on the fact that array dimensions are small: it says that if the
//      top of the intstack is less than 11, then it must be a dimension
//      (smallest position of array type in a compilation unit is 11 as in "class x{y[]")
if ((this.intptr > -1) && (this.intstack[this.intptr] < 11)) {
return true;
}
return false;
}
private boolean isemptynamecompletion() {
return
this.assistnode != null &&
this.assistnode instanceof completiononsinglenamereference &&
(((completiononsinglenamereference)this.assistnode).token.length == 0);
}
protected boolean isinsideannotation() {
int i = this.elementptr;
while(i > -1) {
if(this.elementkindstack[i] == k_between_annotation_name_and_rparen)
return true;
i--;
}
return false;
}

protected boolean isindirectlyinsideblock(){
int i = this.elementptr;
while(i > -1) {
if(this.elementkindstack[i] == k_block_delimiter)
return true;
i--;
}
return false;
}

protected boolean isinsideblock(){
int i = this.elementptr;
while(i > -1) {
switch (this.elementkindstack[i]) {
case k_type_delimiter : return false;
case k_method_delimiter : return false;
case k_field_initializer_delimiter : return false;
case k_block_delimiter : return true;
}
i--;
}
return false;
}
protected boolean isinsidebreakable(){
int i = this.elementptr;
while(i > -1) {
switch (this.elementkindstack[i]) {
case k_type_delimiter : return false;
case k_method_delimiter : return false;
case k_field_initializer_delimiter : return false;
case k_switch_label : return true;
case k_block_delimiter :
case k_control_statement_delimiter:
switch(this.elementinfostack[i]) {
case for :
case do :
case while :
return true;
}
}
i--;
}
return false;
}
protected boolean isinsideloop(){
int i = this.elementptr;
while(i > -1) {
switch (this.elementkindstack[i]) {
case k_type_delimiter : return false;
case k_method_delimiter : return false;
case k_field_initializer_delimiter : return false;
case k_block_delimiter :
case k_control_statement_delimiter:
switch(this.elementinfostack[i]) {
case for :
case do :
case while :
return true;
}
}
i--;
}
return false;
}
protected boolean isinsidereturn(){
int i = this.elementptr;
while(i > -1) {
switch (this.elementkindstack[i]) {
case k_type_delimiter : return false;
case k_method_delimiter : return false;
case k_field_initializer_delimiter : return false;
case k_block_delimiter : return false;
case k_control_statement_delimiter: return false; // fwiw
case k_inside_return_statement : return true;
}
i--;
}
return false;
}
public compilationunitdeclaration parse(icompilationunit sourceunit, compilationresult compilationresult, int cursorloc) {

this.cursorlocation = cursorloc;
completionscanner completionscanner = (completionscanner)this.scanner;
completionscanner.completionidentifier = null;
completionscanner.cursorlocation = cursorloc;
return this.parse(sourceunit, compilationresult);
}
public void parseblockstatements(
constructordeclaration cd,
compilationunitdeclaration unit) {
this.canbeexplicitconstructor = 1;
super.parseblockstatements(cd, unit);
}
public methoddeclaration parsesomestatements(int start, int end, int fakeblockscount, compilationunitdeclaration unit) {
this.methodrecoveryactivated = true;

initialize();

// simulate goformethodbody except that we don't want to balance brackets because they are not going to be balanced
goforblockstatementsopt();

methoddeclaration fakemethod = new methoddeclaration(unit.compilationresult());
fakemethod.selector = fake_method_name;
fakemethod.bodystart = start;
fakemethod.bodyend = end;
fakemethod.declarationsourcestart = start;
fakemethod.declarationsourceend = end;
fakemethod.sourcestart = start;
fakemethod.sourceend = start; //fake method must ignore the method header

this.referencecontext = fakemethod;
this.compilationunit = unit;

this.diet = false;
this.restartrecovery = true;

this.scanner.resetto(start, end);
consumenestedmethod();
for (int i = 0; i < fakeblockscount; i++) {
consumeopenfakeblock();
}
try {
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
} finally {
this.nestedmethod[this.nestedtype]--;
}
if (!this.haserror) {
int length;
if (this.astlengthptr > -1 && (length = this.astlengthstack[this.astlengthptr--]) != 0) {
system.arraycopy(
this.aststack,
(this.astptr -= length) + 1,
fakemethod.statements = new statement[length],
0,
length);
}
}

return fakemethod;
}
protected void popuntilcompletedannotationifnecessary() {
if(this.elementptr < 0) return;

int i = this.elementptr;
while(i > -1 &&
(this.elementkindstack[i] != k_between_annotation_name_and_rparen ||
(this.elementinfostack[i] & annotation_name_completion) == 0)) {
i--;
}

if(i >= 0) {
this.previouskind = this.elementkindstack[i];
this.previousinfo = this.elementinfostack[i];
this.previousobjectinfo = this.elementobjectinfostack[i];

for (int j = i; j <= this.elementptr; j++) {
this.elementobjectinfostack[j] = null;
}

this.elementptr = i - 1;
}
}
/*
* prepares the state of the parser to go for blockstatements.
*/
protected void prepareforblockstatements() {
this.nestedmethod[this.nestedtype = 0] = 1;
this.variablescounter[this.nestedtype] = 0;
this.realblockstack[this.realblockptr = 1] = 0;

initializeforblockstatements();
}
protected void pushonlabelstack(char[] label){
if (this.labelptr < -1) return;

int stacklength = this.labelstack.length;
if (++this.labelptr >= stacklength) {
system.arraycopy(
this.labelstack, 0,
this.labelstack = new char[stacklength + labelstackincrement][], 0,
stacklength);
}
this.labelstack[this.labelptr] = label;
}
/**
* creates a completion on member access node and push it
* on the expression stack.
*/
private void pushcompletiononmemberaccessonexpressionstack(boolean issuperaccess) {
char[] source = this.identifierstack[this.identifierptr];
long pos = this.identifierpositionstack[this.identifierptr--];
completiononmemberaccess fr = new completiononmemberaccess(source, pos, isinsideannotation());
this.assistnode = fr;
this.lastcheckpoint = fr.sourceend + 1;
this.identifierlengthptr--;
if (issuperaccess) { //considerates the fieldreference beginning at the 'super' ....
fr.sourcestart = this.intstack[this.intptr--];
fr.receiver = new superreference(fr.sourcestart, this.endposition);
pushonexpressionstack(fr);
} else { //optimize push/pop
if ((fr.receiver = this.expressionstack[this.expressionptr]).isthis()) { //fieldreference begins at the this
fr.sourcestart = fr.receiver.sourcestart;
}
this.expressionstack[this.expressionptr] = fr;
}
}
private void recordreference(namereference namereference) {
if (!this.skiprecord &&
this.recordfrom <= namereference.sourcestart &&
namereference.sourceend <= this.recordto &&
!isalreadypotentialname(namereference.sourcestart)) {
char[] token;
if (namereference instanceof singlenamereference) {
token = ((singlenamereference) namereference).token;
} else {
token = ((qualifiednamereference) namereference).tokens[0];
}

// most of the time a name which start with an uppercase is a type name.
// as we don't want to resolve names to avoid to slow down performances then this name will be ignored
if (character.isuppercase(token[0])) return;

addpotentialname(token, namereference.sourcestart, namereference.sourceend);
}
}
public void recoveryexitfromvariable() {
if(this.currentelement != null && this.currentelement instanceof recoveredlocalvariable) {
recoveredelement oldelement = this.currentelement;
super.recoveryexitfromvariable();
if(oldelement != this.currentelement) {
popelement(k_local_initializer_delimiter);
}
} else {
super.recoveryexitfromvariable();
}
}
public void recoverytokencheck() {
recoveredelement oldelement = this.currentelement;
switch (this.currenttoken) {
case tokennamelbrace :
if(!this.ignorenextopeningbrace) {
this.pendingannotation = null; // the pending annotation cannot be attached to next nodes
}
super.recoverytokencheck();
break;
case tokennamerbrace :
super.recoverytokencheck();
if(this.currentelement != oldelement && oldelement instanceof recoveredblock) {
if (topknownelementkind(completion_or_assist_parser) == k_array_initializer) {
// when inside an array initializer, we should not prematurely pop the enclosing block
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=249704
popelement(k_array_initializer);
} else {
popelement(k_block_delimiter);
}
}
break;
case tokennamecase :
super.recoverytokencheck();
if(topknownelementkind(completion_or_assist_parser) == k_block_delimiter
&& topknownelementinfo(completion_or_assist_parser) == switch) {
pushonelementstack(k_switch_label);
}
break;
case tokennamedefault :
super.recoverytokencheck();
if(topknownelementkind(completion_or_assist_parser) == k_block_delimiter
&& topknownelementinfo(completion_or_assist_parser) == switch) {
pushonelementstack(k_switch_label, default);
} else if(topknownelementkind(completion_or_assist_parser) == k_switch_label) {
popelement(k_switch_label);
pushonelementstack(k_switch_label, default);
}
break;
default :
super.recoverytokencheck();
break;
}
}
/*
* reset internal state after completion is over
*/

public void reset() {
super.reset();
this.cursorlocation = 0;
if (this.storesourceends) {
this.sourceends = new hashtableofobjecttoint();
}
}
/*
* reset internal state after completion is over
*/

public void resetaftercompletion() {
this.cursorlocation = 0;
flushassiststate();
}
public void restoreassistparser(object parserstate) {
int[] state = (int[]) parserstate;

completionscanner completionscanner = (completionscanner)this.scanner;

this.cursorlocation = state[0];
completionscanner.cursorlocation = state[1];
}
/*
* reset context so as to resume to regular parse loop
* if unable to reset for resuming, answers false.
*
* move checkpoint location, reset internal stacks and
* decide which grammar goal is activated.
*/
protected boolean resumeafterrecovery() {
this.hasunusedmodifiers = false;
if (this.assistnode != null) {
/* if reached [eof] inside method body, but still inside nested type,
or inside a field initializer, should continue in diet mode until
the end of the method body or compilation unit */
if ((this.scanner.eofposition == this.cursorlocation+1)
&& (!(this.referencecontext instanceof compilationunitdeclaration)
|| isindirectlyinsidefieldinitialization()
|| this.assistnodeparent instanceof fielddeclaration && !(this.assistnodeparent instanceof initializer))) {

/*	disabled since does not handle possible field/message refs, that is, obj[assist here]ect.registernatives()
// consume extra tokens which were part of the qualified reference
//   so that the replaced source comprises them as well
if (this.assistnode instanceof namereference){
int oldeof = scanner.eofposition;
scanner.eofposition = currentelement.topelement().sourceend()+1;
scanner.currentposition = this.cursorlocation+1;
int token = -1;
try {
do {
// first token might not have to be a dot
if (token >= 0 || !this.completionbehinddot){
if ((token = scanner.getnexttoken()) != tokennamedot) break;
}
if ((token = scanner.getnexttoken()) != tokennameidentifier) break;
this.assistnode.sourceend = scanner.currentposition - 1;
} while (token != tokennameeof);
} catch (invalidinputexception e){
} finally {
scanner.eofposition = oldeof;
}
}
*/
/* restart in diet mode for finding sibling constructs */
if (this.currentelement instanceof recoveredtype
|| this.currentelement.enclosingtype() != null){

this.pendingannotation = null;

if(this.lastcheckpoint <= this.assistnode.sourceend) {
this.lastcheckpoint = this.assistnode.sourceend+1;
}
int end = this.currentelement.topelement().sourceend();
this.scanner.eofposition = end < integer.max_value ? end + 1 : end;
} else {
resetstacks();
return false;
}
}
}
return super.resumeafterrecovery();
}
public void setassistidentifier(char[] assistident){
((completionscanner)this.scanner).completionidentifier = assistident;
}
public  string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append("elementkindstack : int[] = {"); //$non-nls-1$
for (int i = 0; i <= this.elementptr; i++) {
buffer.append(string.valueof(this.elementkindstack[i])).append(',');
}
buffer.append("}\n"); //$non-nls-1$
buffer.append("elementinfostack : int[] = {"); //$non-nls-1$
for (int i = 0; i <= this.elementptr; i++) {
buffer.append(string.valueof(this.elementinfostack[i])).append(',');
}
buffer.append("}\n"); //$non-nls-1$
buffer.append(super.tostring());
return string.valueof(buffer);
}

/*
* update recovery state based on current parser/scanner state
*/
protected void updaterecoverystate() {

/* expose parser state to recovery state */
this.currentelement.updatefromparserstate();

/* may be able to retrieve completionnode as an orphan, and then attach it */
completionidentifiercheck();
attachorphancompletionnode();

// if an assist node has been found and a recovered element exists,
// mark enclosing blocks as to be preserved
if (this.assistnode != null && this.currentelement != null) {
this.currentelement.preserveenclosingblocks();
}

/* check and update recovered state based on current token,
this action is also performed when shifting token after recovery
got activated once.
*/
recoverytokencheck();

recoveryexitfromvariable();
}

protected localdeclaration createlocaldeclaration(char[] assistname, int sourcestart, int sourceend) {
if (this.indexofassistidentifier() < 0) {
return super.createlocaldeclaration(assistname, sourcestart, sourceend);
} else {
completiononlocalname local = new completiononlocalname(assistname, sourcestart, sourceend);
this.assistnode = local;
this.lastcheckpoint = sourceend + 1;
return local;
}
}

protected javadocparser createjavadocparser() {
return new completionjavadocparser(this);
}

protected fielddeclaration createfielddeclaration(char[] assistname, int sourcestart, int sourceend) {
if (this.indexofassistidentifier() < 0 || (this.currentelement instanceof recoveredunit && ((recoveredunit)this.currentelement).typecount == 0)) {
return super.createfielddeclaration(assistname, sourcestart, sourceend);
} else {
completiononfieldname field = new completiononfieldname(assistname, sourcestart, sourceend);
this.assistnode = field;
this.lastcheckpoint = sourceend + 1;
return field;
}
}
}@


1.215
log
@head - fix for 313706
