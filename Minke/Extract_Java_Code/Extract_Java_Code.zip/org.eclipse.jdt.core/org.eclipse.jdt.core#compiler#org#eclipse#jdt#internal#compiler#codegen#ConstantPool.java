/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.classfile;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeconstants;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.util.hashtableofobject;
import org.eclipse.jdt.internal.compiler.util.util;
/**
* this type is used to store all the constant pool entries.
*/
public class constantpool implements classfileconstants, typeids {
public static final int double_initial_size = 5;
public static final int float_initial_size = 3;
public static final int int_initial_size = 248;
public static final int long_initial_size = 5;
public static final int utf8_initial_size = 778;
public static final int string_initial_size = 761;
public static final int methods_and_fields_initial_size = 450;
public static final int class_initial_size = 86;
public static final int nameandtype_initial_size = 272;
public static final int constantpool_initial_size = 2000;
public static final int constantpool_grow_size = 6000;
protected doublecache doublecache;
protected floatcache floatcache;
protected integercache intcache;
protected longcache longcache;
public chararraycache utf8cache;
protected chararraycache stringcache;
protected hashtableofobject methodsandfieldscache;
protected chararraycache classcache;
protected hashtableofobject nameandtypecacheforfieldsandmethods;
public byte[] poolcontent;
public int currentindex = 1;
public int currentoffset;
public int[] offsets;

public classfile classfile;
public static final char[] append = "append".tochararray(); //$non-nls-1$
public static final char[] array_newinstance_name = "newinstance".tochararray(); //$non-nls-1$
public static final char[] array_newinstance_signature = "(ljava/lang/class;[i)ljava/lang/object;".tochararray(); //$non-nls-1$
public static final char[] arraycopy = "arraycopy".tochararray(); //$non-nls-1$
public static final char[] arraycopysignature = "(ljava/lang/object;iljava/lang/object;ii)v".tochararray(); //$non-nls-1$
public static final char[] arrayjavalangclassconstantpoolname = "[ljava/lang/class;".tochararray(); //$non-nls-1$
public static final char[] arrayjavalangobjectconstantpoolname = "[ljava/lang/object;".tochararray(); //$non-nls-1$
public static final char[] booleanbooleansignature = "(z)ljava/lang/boolean;".tochararray(); //$non-nls-1$
public static final char[] booleanconstrsignature = "(z)v".tochararray(); //$non-nls-1$
public static final char[] booleanvalue_boolean_method_name = "booleanvalue".tochararray(); //$non-nls-1$
public static final char[] booleanvalue_boolean_method_signature = "()z".tochararray(); //$non-nls-1$
public static final char[] bytebytesignature = "(b)ljava/lang/byte;".tochararray(); //$non-nls-1$
public static final char[] byteconstrsignature = "(b)v".tochararray(); //$non-nls-1$
public static final char[] bytevalue_byte_method_name = "bytevalue".tochararray(); //$non-nls-1$
public static final char[] bytevalue_byte_method_signature = "()b".tochararray(); //$non-nls-1$
public static final char[] charcharactersignature = "(c)ljava/lang/character;".tochararray(); //$non-nls-1$
public static final char[] charconstrsignature = "(c)v".tochararray(); //$non-nls-1$
public static final char[] charvalue_character_method_name = "charvalue".tochararray(); //$non-nls-1$
public static final char[] charvalue_character_method_signature = "()c".tochararray(); //$non-nls-1$
public static final char[] clinit = "<clinit>".tochararray(); //$non-nls-1$
public static final char[] defaultconstructorsignature = "()v".tochararray(); //$non-nls-1$
public static final char[] clinitsignature = defaultconstructorsignature;
public static final char[] desiredassertionstatus = "desiredassertionstatus".tochararray(); //$non-nls-1$
public static final char[] desiredassertionstatussignature = "()z".tochararray(); //$non-nls-1$
public static final char[] doubleconstrsignature = "(d)v".tochararray(); //$non-nls-1$
public static final char[] doubledoublesignature = "(d)ljava/lang/double;".tochararray(); //$non-nls-1$
public static final char[] doublevalue_double_method_name = "doublevalue".tochararray(); //$non-nls-1$
public static final char[] doublevalue_double_method_signature = "()d".tochararray(); //$non-nls-1$
public static final char[] exit = "exit".tochararray(); //$non-nls-1$
public static final char[] exitintsignature = "(i)v".tochararray(); //$non-nls-1$
public static final char[] floatconstrsignature = "(f)v".tochararray(); //$non-nls-1$
public static final char[] floatfloatsignature = "(f)ljava/lang/float;".tochararray(); //$non-nls-1$
public static final char[] floatvalue_float_method_name = "floatvalue".tochararray(); //$non-nls-1$
public static final char[] floatvalue_float_method_signature = "()f".tochararray(); //$non-nls-1$
public static final char[] forname = "forname".tochararray(); //$non-nls-1$
public static final char[] fornamesignature = "(ljava/lang/string;)ljava/lang/class;".tochararray(); //$non-nls-1$
public static final char[] get_boolean_method_name = "getboolean".tochararray(); //$non-nls-1$
public static final char[] get_boolean_method_signature = "(ljava/lang/object;)z".tochararray(); //$non-nls-1$
public static final char[] get_byte_method_name = "getbyte".tochararray(); //$non-nls-1$
public static final char[] get_byte_method_signature = "(ljava/lang/object;)b".tochararray(); //$non-nls-1$
public static final char[] get_char_method_name = "getchar".tochararray(); //$non-nls-1$
public static final char[] get_char_method_signature = "(ljava/lang/object;)c".tochararray(); //$non-nls-1$
public static final char[] get_double_method_name = "getdouble".tochararray(); //$non-nls-1$
public static final char[] get_double_method_signature = "(ljava/lang/object;)d".tochararray(); //$non-nls-1$
public static final char[] get_float_method_name = "getfloat".tochararray(); //$non-nls-1$
public static final char[] get_float_method_signature = "(ljava/lang/object;)f".tochararray(); //$non-nls-1$
public static final char[] get_int_method_name = "getint".tochararray(); //$non-nls-1$
public static final char[] get_int_method_signature = "(ljava/lang/object;)i".tochararray(); //$non-nls-1$
public static final char[] get_long_method_name = "getlong".tochararray(); //$non-nls-1$
public static final char[] get_long_method_signature = "(ljava/lang/object;)j".tochararray(); //$non-nls-1$
public static final char[] get_object_method_name = "get".tochararray(); //$non-nls-1$
public static final char[] get_object_method_signature = "(ljava/lang/object;)ljava/lang/object;".tochararray(); //$non-nls-1$
public static final char[] get_short_method_name = "getshort".tochararray(); //$non-nls-1$
public static final char[] get_short_method_signature = "(ljava/lang/object;)s".tochararray(); //$non-nls-1$
public static final char[] getclass = "getclass".tochararray(); //$non-nls-1$
public static final char[] getclasssignature = "()ljava/lang/class;".tochararray(); //$non-nls-1$
public static final char[] getcomponenttype = "getcomponenttype".tochararray(); //$non-nls-1$
public static final char[] getcomponenttypesignature = getclasssignature;
public static final char[] getconstructor = "getconstructor".tochararray(); //$non-nls-1$
public static final char[] getconstructorsignature = "([ljava/lang/class;)ljava/lang/reflect/constructor;".tochararray(); //$non-nls-1$
public static final char[] getdeclaredconstructor_name = "getdeclaredconstructor".tochararray(); //$non-nls-1$
public static final char[] getdeclaredconstructor_signature = "([ljava/lang/class;)ljava/lang/reflect/constructor;".tochararray(); //$non-nls-1$
// predefined methods constant names
public static final char[] getdeclaredfield_name = "getdeclaredfield".tochararray(); //$non-nls-1$
public static final char[] getdeclaredfield_signature = "(ljava/lang/string;)ljava/lang/reflect/field;".tochararray(); //$non-nls-1$
public static final char[] getdeclaredmethod_name = "getdeclaredmethod".tochararray(); //$non-nls-1$
public static final char[] getdeclaredmethod_signature = "(ljava/lang/string;[ljava/lang/class;)ljava/lang/reflect/method;".tochararray(); //$non-nls-1$
public static final char[] getmessage = "getmessage".tochararray(); //$non-nls-1$
public static final char[] getmessagesignature = "()ljava/lang/string;".tochararray(); //$non-nls-1$
public static final char[] hasnext = "hasnext".tochararray();//$non-nls-1$
public static final char[] hasnextsignature = "()z".tochararray();//$non-nls-1$
public static final char[] init = "<init>".tochararray(); //$non-nls-1$
public static final char[] intconstrsignature = "(i)v".tochararray(); //$non-nls-1$
public static final char[] iterator_name = "iterator".tochararray(); //$non-nls-1$
public static final char[] iterator_signature = "()ljava/util/iterator;".tochararray(); //$non-nls-1$
public static final char[] intern = "intern".tochararray(); //$non-nls-1$
public static final char[] internsignature = getmessagesignature;
public static final char[] intintegersignature = "(i)ljava/lang/integer;".tochararray(); //$non-nls-1$
public static final char[] intvalue_integer_method_name = "intvalue".tochararray(); //$non-nls-1$
public static final char[] intvalue_integer_method_signature = "()i".tochararray(); //$non-nls-1$
public static final char[] invoke_method_method_name = "invoke".tochararray(); //$non-nls-1$
public static final char[] invoke_method_method_signature = "(ljava/lang/object;[ljava/lang/object;)ljava/lang/object;".tochararray(); //$non-nls-1$
public static final char[][] java_lang_reflect_accessibleobject = new char[][] {typeconstants.java, typeconstants.lang, typeconstants.reflect, "accessibleobject".tochararray()}; //$non-nls-1$
public static final char[][] java_lang_reflect_array = new char[][] {typeconstants.java, typeconstants.lang, typeconstants.reflect, "array".tochararray()}; //$non-nls-1$
// predefined type constant names
public static final char[] javaioprintstreamsignature = "ljava/io/printstream;".tochararray(); //$non-nls-1$
public static final char[] javalangassertionerrorconstantpoolname = "java/lang/assertionerror".tochararray(); //$non-nls-1$
public static final char[] javalangbooleanconstantpoolname = "java/lang/boolean".tochararray(); //$non-nls-1$
public static final char[] javalangbyteconstantpoolname = "java/lang/byte".tochararray(); //$non-nls-1$
public static final char[] javalangcharacterconstantpoolname = "java/lang/character".tochararray(); //$non-nls-1$
public static final char[] javalangclassconstantpoolname = "java/lang/class".tochararray(); //$non-nls-1$
public static final char[] javalangclassnotfoundexceptionconstantpoolname = "java/lang/classnotfoundexception".tochararray(); //$non-nls-1$
public static final char[] javalangclasssignature = "ljava/lang/class;".tochararray(); //$non-nls-1$
public static final char[] javalangdoubleconstantpoolname = "java/lang/double".tochararray(); //$non-nls-1$
public static final char[] javalangenumconstantpoolname = "java/lang/enum".tochararray(); //$non-nls-1$
public static final char[] javalangerrorconstantpoolname = "java/lang/error".tochararray(); //$non-nls-1$
public static final char[] javalangexceptionconstantpoolname = "java/lang/exception".tochararray(); //$non-nls-1$
public static final char[] javalangfloatconstantpoolname = "java/lang/float".tochararray(); //$non-nls-1$
public static final char[] javalangintegerconstantpoolname = "java/lang/integer".tochararray(); //$non-nls-1$
public static final char[] javalanglongconstantpoolname = "java/lang/long".tochararray(); //$non-nls-1$
public static final char[] javalangnoclassdeffounderrorconstantpoolname = "java/lang/noclassdeffounderror".tochararray(); //$non-nls-1$
public static final char[] javalangnosuchfielderrorconstantpoolname = "java/lang/nosuchfielderror".tochararray(); //$non-nls-1$
public static final char[] javalangobjectconstantpoolname = "java/lang/object".tochararray(); //$non-nls-1$
public static final char[] javalangreflectaccessibleobject_constantpoolname = "java/lang/reflect/accessibleobject".tochararray(); //$non-nls-1$
public static final char[] javalangreflectarray_constantpoolname = "java/lang/reflect/array".tochararray(); //$non-nls-1$
public static final char[] javalangreflectconstructorconstantpoolname = "java/lang/reflect/constructor".tochararray();   //$non-nls-1$
public static final char[] javalangreflectconstructornewinstancesignature = "([ljava/lang/object;)ljava/lang/object;".tochararray(); //$non-nls-1$
public static final char[] javalangreflectfield_constantpoolname = "java/lang/reflect/field".tochararray(); //$non-nls-1$
public static final char[] javalangreflectmethod_constantpoolname = "java/lang/reflect/method".tochararray(); //$non-nls-1$
public static final char[] javalangshortconstantpoolname = "java/lang/short".tochararray(); //$non-nls-1$
public static final char[] javalangstringbufferconstantpoolname = "java/lang/stringbuffer".tochararray(); //$non-nls-1$
public static final char[] javalangstringbuilderconstantpoolname = "java/lang/stringbuilder".tochararray(); //$non-nls-1$
public static final char[] javalangstringconstantpoolname = "java/lang/string".tochararray(); //$non-nls-1$
public static final char[] javalangstringsignature = "ljava/lang/string;".tochararray(); //$non-nls-1$
public static final char[] javalangobjectsignature = "ljava/lang/object;".tochararray(); //$non-nls-1$
public static final char[] javalangsystemconstantpoolname = "java/lang/system".tochararray(); //$non-nls-1$
public static final char[] javalangthrowableconstantpoolname = "java/lang/throwable".tochararray(); //$non-nls-1$
public static final char[] javalangvoidconstantpoolname = "java/lang/void".tochararray(); //$non-nls-1$
public static final char[] javautiliteratorconstantpoolname = "java/util/iterator".tochararray(); //$non-nls-1$
public static final char[] longconstrsignature = "(j)v".tochararray(); //$non-nls-1$
public static final char[] longlongsignature = "(j)ljava/lang/long;".tochararray(); //$non-nls-1$
public static final char[] longvalue_long_method_name = "longvalue".tochararray(); //$non-nls-1$
public static final char[] longvalue_long_method_signature = "()j".tochararray(); //$non-nls-1$
public static final char[] newinstance = "newinstance".tochararray(); //$non-nls-1$
public static final char[] newinstancesignature = "(ljava/lang/class;[i)ljava/lang/object;".tochararray(); //$non-nls-1$
public static final char[] next = "next".tochararray();//$non-nls-1$
public static final char[] nextsignature = "()ljava/lang/object;".tochararray();//$non-nls-1$
public static final char[] objectconstrsignature = "(ljava/lang/object;)v".tochararray(); //$non-nls-1$
public static final char[] objectsignature = "ljava/lang/object;".tochararray(); //$non-nls-1$
public static final char[] ordinal = "ordinal".tochararray(); //$non-nls-1$
public static final char[] ordinalsignature = "()i".tochararray(); //$non-nls-1$
public static final char[] out = "out".tochararray(); //$non-nls-1$
public static final char[] set_boolean_method_name = "setboolean".tochararray(); //$non-nls-1$
public static final char[] set_boolean_method_signature = "(ljava/lang/object;z)v".tochararray(); //$non-nls-1$
public static final char[] set_byte_method_name = "setbyte".tochararray(); //$non-nls-1$
public static final char[] set_byte_method_signature = "(ljava/lang/object;b)v".tochararray(); //$non-nls-1$
public static final char[] set_char_method_name = "setchar".tochararray(); //$non-nls-1$
public static final char[] set_char_method_signature = "(ljava/lang/object;c)v".tochararray(); //$non-nls-1$
public static final char[] set_double_method_name = "setdouble".tochararray(); //$non-nls-1$
public static final char[] set_double_method_signature = "(ljava/lang/object;d)v".tochararray(); //$non-nls-1$
public static final char[] set_float_method_name = "setfloat".tochararray(); //$non-nls-1$
public static final char[] set_float_method_signature = "(ljava/lang/object;f)v".tochararray(); //$non-nls-1$
public static final char[] set_int_method_name = "setint".tochararray(); //$non-nls-1$
public static final char[] set_int_method_signature = "(ljava/lang/object;i)v".tochararray(); //$non-nls-1$
public static final char[] set_long_method_name = "setlong".tochararray(); //$non-nls-1$
public static final char[] set_long_method_signature = "(ljava/lang/object;j)v".tochararray(); //$non-nls-1$
public static final char[] set_object_method_name = "set".tochararray(); //$non-nls-1$
public static final char[] set_object_method_signature = "(ljava/lang/object;ljava/lang/object;)v".tochararray(); //$non-nls-1$
public static final char[] set_short_method_name = "setshort".tochararray(); //$non-nls-1$
public static final char[] set_short_method_signature = "(ljava/lang/object;s)v".tochararray(); //$non-nls-1$
public static final char[] setaccessible_name = "setaccessible".tochararray(); //$non-nls-1$
public static final char[] setaccessible_signature = "(z)v".tochararray(); //$non-nls-1$
public static final char[] shortconstrsignature = "(s)v".tochararray(); //$non-nls-1$
public static final char[] shortshortsignature = "(s)ljava/lang/short;".tochararray(); //$non-nls-1$
public static final char[] shortvalue_short_method_name = "shortvalue".tochararray(); //$non-nls-1$
public static final char[] shortvalue_short_method_signature = "()s".tochararray(); //$non-nls-1$
public static final char[] stringbufferappendbooleansignature = "(z)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
public static final char[] stringbufferappendcharsignature = "(c)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
public static final char[] stringbufferappenddoublesignature = "(d)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
public static final char[] stringbufferappendfloatsignature = "(f)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
public static final char[] stringbufferappendintsignature = "(i)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
public static final char[] stringbufferappendlongsignature = "(j)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
public static final char[] stringbufferappendobjectsignature = "(ljava/lang/object;)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
public static final char[] stringbufferappendstringsignature = "(ljava/lang/string;)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
public static final char[] stringbuilderappendbooleansignature = "(z)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
public static final char[] stringbuilderappendcharsignature = "(c)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
public static final char[] stringbuilderappenddoublesignature = "(d)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
public static final char[] stringbuilderappendfloatsignature = "(f)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
public static final char[] stringbuilderappendintsignature = "(i)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
public static final char[] stringbuilderappendlongsignature = "(j)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
public static final char[] stringbuilderappendobjectsignature = "(ljava/lang/object;)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
public static final char[] stringbuilderappendstringsignature = "(ljava/lang/string;)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
public static final char[] stringconstructorsignature = "(ljava/lang/string;)v".tochararray(); //$non-nls-1$
public static final char[] this = "this".tochararray(); //$non-nls-1$
public static final char[] tostring = "tostring".tochararray(); //$non-nls-1$
public static final char[] tostringsignature = getmessagesignature;
public static final char[] type = "type".tochararray(); //$non-nls-1$
public static final char[] valueof = "valueof".tochararray(); //$non-nls-1$
public static final char[] valueofbooleansignature = "(z)ljava/lang/string;".tochararray(); //$non-nls-1$
public static final char[] valueofcharsignature = "(c)ljava/lang/string;".tochararray(); //$non-nls-1$
public static final char[] valueofdoublesignature = "(d)ljava/lang/string;".tochararray(); //$non-nls-1$
public static final char[] valueoffloatsignature = "(f)ljava/lang/string;".tochararray(); //$non-nls-1$
public static final char[] valueofintsignature = "(i)ljava/lang/string;".tochararray(); //$non-nls-1$
public static final char[] valueoflongsignature = "(j)ljava/lang/string;".tochararray(); //$non-nls-1$
public static final char[] valueofobjectsignature = "(ljava/lang/object;)ljava/lang/string;".tochararray(); //$non-nls-1$
public static final char[] valueofstringclasssignature = "(ljava/lang/class;ljava/lang/string;)ljava/lang/enum;".tochararray(); //$non-nls-1$
public static final char[] java_lang_annotation_documented = "ljava/lang/annotation/documented;".tochararray(); //$non-nls-1$
public static final char[] java_lang_annotation_elementtype = "ljava/lang/annotation/elementtype;".tochararray(); //$non-nls-1$
public static final char[] java_lang_annotation_retention = "ljava/lang/annotation/retention;".tochararray(); //$non-nls-1$
public static final char[] java_lang_annotation_retentionpolicy = "ljava/lang/annotation/retentionpolicy;".tochararray(); //$non-nls-1$
public static final char[] java_lang_annotation_target = "ljava/lang/annotation/target;".tochararray(); //$non-nls-1$
public static final char[] java_lang_deprecated = "ljava/lang/deprecated;".tochararray(); //$non-nls-1$
public static final char[] java_lang_annotation_inherited = "ljava/lang/annotation/inherited;".tochararray(); //$non-nls-1$
/**
* constantpool constructor comment.
*/
public constantpool(classfile classfile) {
this.utf8cache = new chararraycache(utf8_initial_size);
this.stringcache = new chararraycache(string_initial_size);
this.methodsandfieldscache = new hashtableofobject(methods_and_fields_initial_size);
this.classcache = new chararraycache(class_initial_size);
this.nameandtypecacheforfieldsandmethods = new hashtableofobject(nameandtype_initial_size);
this.offsets = new int[5];
initialize(classfile);
}
public void initialize(classfile givenclassfile) {
this.poolcontent = givenclassfile.header;
this.currentoffset = givenclassfile.headeroffset;
// currentoffset is initialized to 0 by default
this.currentindex = 1;
this.classfile = givenclassfile;
}
/**
* return the content of the receiver
*/
public byte[] dumpbytes() {
system.arraycopy(this.poolcontent, 0, (this.poolcontent = new byte[this.currentoffset]), 0, this.currentoffset);
return this.poolcontent;
}
public int literalindex(byte[] utf8encoding, char[] stringchararray) {
int index;
if ((index = this.utf8cache.putifabsent(stringchararray, this.currentindex)) < 0) {
// the entry doesn't exit yet
if ((index = -index)> 0xffff) {
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
this.currentindex++;
// write the tag first
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(utf8tag);
int utf8encodinglength = utf8encoding.length;
if (this.currentoffset + 2 + utf8encodinglength >= this.poolcontent.length) {
// we need to resize the poolcontent array because we won't have
// enough space to write the length
resizepoolcontents(2 + utf8encodinglength);
}
this.poolcontent[this.currentoffset++] = (byte) (utf8encodinglength >> 8);
this.poolcontent[this.currentoffset++] = (byte) utf8encodinglength;
// add in once the whole byte array
system.arraycopy(utf8encoding, 0, this.poolcontent, this.currentoffset, utf8encodinglength);
this.currentoffset += utf8encodinglength;
}
return index;
}
public int literalindex(typebinding binding) {
typebinding typebinding = binding.leafcomponenttype();
if ((typebinding.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(this.classfile, typebinding);
}
return literalindex(binding.signature());
}
/**
* this method returns the index into the constantpool corresponding to the type descriptor.
*
* @@param utf8constant char[]
* @@return <code>int</code>
*/
public int literalindex(char[] utf8constant) {
int index;
if ((index = this.utf8cache.putifabsent(utf8constant, this.currentindex)) < 0) {
if ((index = -index)> 0xffff) {
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
// the entry doesn't exit yet
// write the tag first
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(utf8tag);
// then the size of the stringname array
int savedcurrentoffset = this.currentoffset;
if (this.currentoffset + 2 >= this.poolcontent.length) {
// we need to resize the poolcontent array because we won't have
// enough space to write the length
resizepoolcontents(2);
}
this.currentoffset += 2;
length = 0;
for (int i = 0; i < utf8constant.length; i++) {
char current = utf8constant[i];
if ((current >= 0x0001) && (current <= 0x007f)) {
// we only need one byte: ascii table
writeu1(current);
length++;
} else {
if (current > 0x07ff) {
// we need 3 bytes
length += 3;
writeu1(0xe0 | ((current >> 12) & 0x0f)); // 0xe0 = 1110 0000
writeu1(0x80 | ((current >> 6) & 0x3f)); // 0x80 = 1000 0000
writeu1(0x80 | (current & 0x3f)); // 0x80 = 1000 0000
} else {
// we can be 0 or between 0x0080 and 0x07ff
// in that case we only need 2 bytes
length += 2;
writeu1(0xc0 | ((current >> 6) & 0x1f)); // 0xc0 = 1100 0000
writeu1(0x80 | (current & 0x3f)); // 0x80 = 1000 0000
}
}
}
if (length >= 65535) {
this.currentoffset = savedcurrentoffset - 1;
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceforconstant(this.classfile.referencebinding.scope.referencetype());
}
if (index > 0xffff){
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
this.currentindex++;
// now we know the length that we have to write in the constant pool
// we use savedcurrentoffset to do that
this.poolcontent[savedcurrentoffset] = (byte) (length >> 8);
this.poolcontent[savedcurrentoffset + 1] = (byte) length;
}
return index;
}
public int literalindex(char[] stringchararray, byte[] utf8encoding) {
int index;
if ((index = this.stringcache.putifabsent(stringchararray, this.currentindex)) < 0) {
// the entry doesn't exit yet
this.currentindex++;
if ((index = -index) > 0xffff){
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
// write the tag first
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(stringtag);
// then the string index
int stringindexoffset = this.currentoffset;
if (this.currentoffset + 2 >= this.poolcontent.length) {
resizepoolcontents(2);
}
this.currentoffset+=2;

final int stringindex = literalindex(utf8encoding, stringchararray);
this.poolcontent[stringindexoffset++] = (byte) (stringindex >> 8);
this.poolcontent[stringindexoffset] = (byte) stringindex;
}
return index;
}
/**
* this method returns the index into the constantpool corresponding to the double
* value. if the double is not already present into the pool, it is added. the
* double cache is updated and it returns the right index.
*
* @@param key <code>double</code>
* @@return <code>int</code>
*/
public int literalindex(double key) {
//retrieve the index from the cache
// the double constant takes two indexes into the constant pool, but we only store
// the first index into the long table
int index;
// lazy initialization for base type caches
// if it is null, initialize it, otherwise use it
if (this.doublecache == null) {
this.doublecache = new doublecache(double_initial_size);
}
if ((index = this.doublecache.putifabsent(key, this.currentindex)) < 0) {
if ((index = -index)> 0xffff){
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
this.currentindex += 2; // a double needs an extra place into the constant pool
// write the double into the constant pool
// first add the tag
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(doubletag);
// then add the 8 bytes representing the double
long temp = java.lang.double.doubletolongbits(key);
length = this.poolcontent.length;
if (this.currentoffset + 8 >= length) {
resizepoolcontents(8);
}
this.poolcontent[this.currentoffset++] = (byte) (temp >>> 56);
this.poolcontent[this.currentoffset++] = (byte) (temp >>> 48);
this.poolcontent[this.currentoffset++] = (byte) (temp >>> 40);
this.poolcontent[this.currentoffset++] = (byte) (temp >>> 32);
this.poolcontent[this.currentoffset++] = (byte) (temp >>> 24);
this.poolcontent[this.currentoffset++] = (byte) (temp >>> 16);
this.poolcontent[this.currentoffset++] = (byte) (temp >>> 8);
this.poolcontent[this.currentoffset++] = (byte) temp;
}
return index;
}
/**
* this method returns the index into the constantpool corresponding to the float
* value. if the float is not already present into the pool, it is added. the
* int cache is updated and it returns the right index.
*
* @@param key <code>float</code>
* @@return <code>int</code>
*/
public int literalindex(float key) {
//retrieve the index from the cache
int index;
// lazy initialization for base type caches
// if it is null, initialize it, otherwise use it
if (this.floatcache == null) {
this.floatcache = new floatcache(float_initial_size);
}
if ((index = this.floatcache.putifabsent(key, this.currentindex)) < 0) {
if ((index = -index) > 0xffff){
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
this.currentindex++;
// write the float constant entry into the constant pool
// first add the tag
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(floattag);
// then add the 4 bytes representing the float
int temp = java.lang.float.floattointbits(key);
if (this.currentoffset + 4 >= this.poolcontent.length) {
resizepoolcontents(4);
}
this.poolcontent[this.currentoffset++] = (byte) (temp >>> 24);
this.poolcontent[this.currentoffset++] = (byte) (temp >>> 16);
this.poolcontent[this.currentoffset++] = (byte) (temp >>> 8);
this.poolcontent[this.currentoffset++] = (byte) temp;
}
return index;
}
/**
* this method returns the index into the constantpool corresponding to the int
* value. if the int is not already present into the pool, it is added. the
* int cache is updated and it returns the right index.
*
* @@param key <code>int</code>
* @@return <code>int</code>
*/
public int literalindex(int key) {
//retrieve the index from the cache
int index;
// lazy initialization for base type caches
// if it is null, initialize it, otherwise use it
if (this.intcache == null) {
this.intcache = new integercache(int_initial_size);
}
if ((index = this.intcache.putifabsent(key, this.currentindex)) < 0) {
this.currentindex++;
if ((index = -index) > 0xffff){
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
// write the integer constant entry into the constant pool
// first add the tag
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(integertag);
// then add the 4 bytes representing the int
if (this.currentoffset + 4 >= this.poolcontent.length) {
resizepoolcontents(4);
}
this.poolcontent[this.currentoffset++] = (byte) (key >>> 24);
this.poolcontent[this.currentoffset++] = (byte) (key >>> 16);
this.poolcontent[this.currentoffset++] = (byte) (key >>> 8);
this.poolcontent[this.currentoffset++] = (byte) key;
}
return index;
}
/**
* this method returns the index into the constantpool corresponding to the long
* value. if the long is not already present into the pool, it is added. the
* long cache is updated and it returns the right index.
*
* @@param key <code>long</code>
* @@return <code>int</code>
*/
public int literalindex(long key) {
// retrieve the index from the cache
// the long constant takes two indexes into the constant pool, but we only store
// the first index into the long table
int index;
// lazy initialization for base type caches
// if it is null, initialize it, otherwise use it
if (this.longcache == null) {
this.longcache = new longcache(long_initial_size);
}
if ((index = this.longcache.putifabsent(key, this.currentindex)) < 0) {
if ((index = -index) > 0xffff){
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
this.currentindex+= 2; // long value need an extra place into thwe constant pool
// write the long into the constant pool
// first add the tag
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(longtag);
// then add the 8 bytes representing the long
if (this.currentoffset + 8 >= this.poolcontent.length) {
resizepoolcontents(8);
}
this.poolcontent[this.currentoffset++] = (byte) (key >>> 56);
this.poolcontent[this.currentoffset++] = (byte) (key >>> 48);
this.poolcontent[this.currentoffset++] = (byte) (key >>> 40);
this.poolcontent[this.currentoffset++] = (byte) (key >>> 32);
this.poolcontent[this.currentoffset++] = (byte) (key >>> 24);
this.poolcontent[this.currentoffset++] = (byte) (key >>> 16);
this.poolcontent[this.currentoffset++] = (byte) (key >>> 8);
this.poolcontent[this.currentoffset++] = (byte) key;
}
return index;
}
/**
* this method returns the index into the constantpool corresponding to the type descriptor.
*
* @@param stringconstant java.lang.string
* @@return <code>int</code>
*/
public int literalindex(string stringconstant) {
int index;
char[] stringchararray = stringconstant.tochararray();
if ((index = this.stringcache.putifabsent(stringchararray, this.currentindex)) < 0) {
// the entry doesn't exit yet
this.currentindex++;
if ((index  = -index)> 0xffff){
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
// write the tag first
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(stringtag);
// then the string index
int stringindexoffset = this.currentoffset;
if (this.currentoffset + 2 >= this.poolcontent.length) {
resizepoolcontents(2);
}
this.currentoffset+=2;
final int stringindex = literalindex(stringchararray);
this.poolcontent[stringindexoffset++] = (byte) (stringindex >> 8);
this.poolcontent[stringindexoffset] = (byte) stringindex;
}
return index;
}
public int literalindexfortype(final char[] constantpoolname) {
int index;
if ((index = this.classcache.putifabsent(constantpoolname, this.currentindex)) < 0) {
// the entry doesn't exit yet
this.currentindex++;
if ((index = -index) > 0xffff){
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(classtag);

// then the name index
int nameindexoffset = this.currentoffset;
if (this.currentoffset + 2 >= this.poolcontent.length) {
resizepoolcontents(2);
}
this.currentoffset+=2;
final int nameindex = literalindex(constantpoolname);
this.poolcontent[nameindexoffset++] = (byte) (nameindex >> 8);
this.poolcontent[nameindexoffset] = (byte) nameindex;
}
return index;
}
/*
* this method returns the index into the constantpool corresponding to the type descriptor
* corresponding to a type constant pool name
* binding must not be an array type.
*/
public int literalindexfortype(final typebinding binding) {
typebinding typebinding = binding.leafcomponenttype();
if ((typebinding.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(this.classfile, typebinding);
}
return this.literalindexfortype(binding.constantpoolname());
}
public int literalindexformethod(char[] declaringclass, char[] selector, char[] signature, boolean isinterface) {
int index;
if ((index = putincacheifabsent(declaringclass, selector, signature, this.currentindex)) < 0) {
// it doesn't exist yet
this.currentindex++;
if ((index = -index) > 0xffff){
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
// write the interface method ref constant into the constant pool
// first add the tag
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(isinterface ? interfacemethodreftag : methodreftag);

int classindexoffset = this.currentoffset;
if (this.currentoffset + 4 >= this.poolcontent.length) {
resizepoolcontents(4);
}
this.currentoffset+=4;

final int classindex = literalindexfortype(declaringclass);
final int nameandtypeindex = literalindexfornameandtype(selector, signature);

this.poolcontent[classindexoffset++] = (byte) (classindex >> 8);
this.poolcontent[classindexoffset++] = (byte) classindex;
this.poolcontent[classindexoffset++] = (byte) (nameandtypeindex >> 8);
this.poolcontent[classindexoffset] = (byte) nameandtypeindex;
}
return index;
}
public int literalindexformethod(typebinding declaringclass, char[] selector, char[] signature, boolean isinterface) {
if ((declaringclass.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(this.classfile, declaringclass);
}
return this.literalindexformethod(declaringclass.constantpoolname(), selector, signature, isinterface);
}
public int literalindexfornameandtype(char[] name, char[] signature) {
int index;
if ((index = putinnameandtypecacheifabsent(name, signature, this.currentindex)) < 0) {
// the entry doesn't exit yet
this.currentindex++;
if ((index = -index) > 0xffff){
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(nameandtypetag);
int nameindexoffset = this.currentoffset;
if (this.currentoffset + 4 >= this.poolcontent.length) {
resizepoolcontents(4);
}
this.currentoffset+=4;

final int nameindex = literalindex(name);
final int typeindex = literalindex(signature);
this.poolcontent[nameindexoffset++] = (byte) (nameindex >> 8);
this.poolcontent[nameindexoffset++] = (byte) nameindex;
this.poolcontent[nameindexoffset++] = (byte) (typeindex >> 8);
this.poolcontent[nameindexoffset] = (byte) typeindex;
}
return index;
}
public int literalindexforfield(char[] declaringclass, char[] name, char[] signature) {
int index;
if ((index = putincacheifabsent(declaringclass, name, signature, this.currentindex)) < 0) {
this.currentindex++;
// doesn't exist yet
if ((index = -index) > 0xffff){
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
// write the interface method ref constant into the constant pool
// first add the tag
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(fieldreftag);
int classindexoffset = this.currentoffset;
if (this.currentoffset + 4 >= this.poolcontent.length) {
resizepoolcontents(4);
}
this.currentoffset+=4;

final int classindex = literalindexfortype(declaringclass);
final int nameandtypeindex = literalindexfornameandtype(name, signature);

this.poolcontent[classindexoffset++] = (byte) (classindex >> 8);
this.poolcontent[classindexoffset++] = (byte) classindex;
this.poolcontent[classindexoffset++] = (byte) (nameandtypeindex >> 8);
this.poolcontent[classindexoffset] = (byte) nameandtypeindex;
}
return index;
}
/**
* this method returns the index into the constantpool corresponding to the type descriptor.
*
* @@param stringchararray char[]
* @@return <code>int</code>
*/
public int literalindexforldc(char[] stringchararray) {
int savedcurrentindex = this.currentindex;
int savedcurrentoffset = this.currentoffset;
int index;
if ((index = this.stringcache.putifabsent(stringchararray, this.currentindex)) < 0) {
if ((index = -index)> 0xffff) {
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
// the entry doesn't exit yet
this.currentindex++;
// write the tag first
int length = this.offsets.length;
if (length <= index) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[index * 2]), 0, length);
}
this.offsets[index] = this.currentoffset;
writeu1(stringtag);

// then the string index
int stringindexoffset = this.currentoffset;
if (this.currentoffset + 2 >= this.poolcontent.length) {
resizepoolcontents(2);
}
this.currentoffset+=2;

int stringindex;
if ((stringindex = this.utf8cache.putifabsent(stringchararray, this.currentindex)) < 0) {
if ((stringindex = -stringindex)> 0xffff) {
this.classfile.referencebinding.scope.problemreporter().nomoreavailablespaceinconstantpool(this.classfile.referencebinding.scope.referencetype());
}
// the entry doesn't exit yet
this.currentindex++;
// write the tag first
length = this.offsets.length;
if (length <= stringindex) {
// resize
system.arraycopy(this.offsets, 0, (this.offsets = new int[stringindex * 2]), 0, length);
}
this.offsets[stringindex] = this.currentoffset;
writeu1(utf8tag);
// then the size of the stringname array
int lengthoffset = this.currentoffset;
if (this.currentoffset + 2 >= this.poolcontent.length) {
// we need to resize the poolcontent array because we won't have
// enough space to write the length
resizepoolcontents(2);
}
this.currentoffset += 2;
length = 0;
for (int i = 0; i < stringchararray.length; i++) {
char current = stringchararray[i];
if ((current >= 0x0001) && (current <= 0x007f)) {
// we only need one byte: ascii table
length++;
if (this.currentoffset + 1 >= this.poolcontent.length) {
// we need to resize the poolcontent array because we won't have
// enough space to write the length
resizepoolcontents(1);
}
this.poolcontent[this.currentoffset++] = (byte)(current);
} else
if (current > 0x07ff) {
// we need 3 bytes
length += 3;
if (this.currentoffset + 3 >= this.poolcontent.length) {
// we need to resize the poolcontent array because we won't have
// enough space to write the length
resizepoolcontents(3);
}
this.poolcontent[this.currentoffset++] = (byte) (0xe0 | ((current >> 12) & 0x0f)); // 0xe0 = 1110 0000
this.poolcontent[this.currentoffset++] = (byte) (0x80 | ((current >> 6) & 0x3f)); // 0x80 = 1000 0000
this.poolcontent[this.currentoffset++] = (byte) (0x80 | (current & 0x3f)); // 0x80 = 1000 0000
} else {
if (this.currentoffset + 2 >= this.poolcontent.length) {
// we need to resize the poolcontent array because we won't have
// enough space to write the length
resizepoolcontents(2);
}
// we can be 0 or between 0x0080 and 0x07ff
// in that case we only need 2 bytes
length += 2;
this.poolcontent[this.currentoffset++] = (byte) (0xc0 | ((current >> 6) & 0x1f)); // 0xc0 = 1100 0000
this.poolcontent[this.currentoffset++] = (byte) (0x80 | (current & 0x3f)); // 0x80 = 1000 0000
}
}
if (length >= 65535) {
this.currentoffset = savedcurrentoffset;
this.currentindex = savedcurrentindex;
this.stringcache.remove(stringchararray);
this.utf8cache.remove(stringchararray);
return 0;
}
this.poolcontent[lengthoffset++] = (byte) (length >> 8);
this.poolcontent[lengthoffset] = (byte) length;
}
this.poolcontent[stringindexoffset++] = (byte) (stringindex >> 8);
this.poolcontent[stringindexoffset] = (byte) stringindex;
}
return index;
}
/**
* @@param key1 the given name
* @@param key2 the given signature
* @@param value the given index
* @@return the new index
*/
private int putinnameandtypecacheifabsent(final char[] key1, final char[] key2, int value) {
int index ;
object key1value = this.nameandtypecacheforfieldsandmethods.get(key1);
if (key1value == null) {
cachedindexentry cachedindexentry = new cachedindexentry(key2, value);
index = -value;
this.nameandtypecacheforfieldsandmethods.put(key1, cachedindexentry);
} else if (key1value instanceof cachedindexentry) {
// adding a second entry
cachedindexentry entry = (cachedindexentry) key1value;
if (charoperation.equals(key2, entry.signature)) {
index = entry.index;
} else {
chararraycache chararraycache = new chararraycache();
chararraycache.putifabsent(entry.signature, entry.index);
index = chararraycache.putifabsent(key2, value);
this.nameandtypecacheforfieldsandmethods.put(key1, chararraycache);
}
} else {
chararraycache chararraycache = (chararraycache) key1value;
index = chararraycache.putifabsent(key2, value);
}
return index;
}
/**
* @@param key1 the given declaring class name
* @@param key2 the given field name or method selector
* @@param key3 the given signature
* @@param value the new index
* @@return the given index
*/
private int putincacheifabsent(final char[] key1, final char[] key2, final char[] key3, int value) {
int index;
hashtableofobject key1value = (hashtableofobject) this.methodsandfieldscache.get(key1);
if (key1value == null) {
key1value = new hashtableofobject();
this.methodsandfieldscache.put(key1, key1value);
cachedindexentry cachedindexentry = new cachedindexentry(key3, value);
index = -value;
key1value.put(key2, cachedindexentry);
} else {
object key2value = key1value.get(key2);
if (key2value == null) {
cachedindexentry cachedindexentry = new cachedindexentry(key3, value);
index = -value;
key1value.put(key2, cachedindexentry);
} else if (key2value instanceof cachedindexentry) {
// adding a second entry
cachedindexentry entry = (cachedindexentry) key2value;
if (charoperation.equals(key3, entry.signature)) {
index = entry.index;
} else {
chararraycache chararraycache = new chararraycache();
chararraycache.putifabsent(entry.signature, entry.index);
index = chararraycache.putifabsent(key3, value);
key1value.put(key2, chararraycache);
}
} else {
chararraycache chararraycache = (chararraycache) key2value;
index = chararraycache.putifabsent(key3, value);
}
}
return index;
}
/**
* this method is used to clean the receiver in case of a clinit header is generated, but the
* clinit has no code.
* this implementation assumes that the clinit is the first method to be generated.
* @@see org.eclipse.jdt.internal.compiler.ast.typedeclaration#addclinit()
*/
public void resetforclinit(int constantpoolindex, int constantpooloffset) {
this.currentindex = constantpoolindex;
this.currentoffset = constantpooloffset;
if (this.utf8cache.get(attributenamesconstants.codename) >= constantpoolindex) {
this.utf8cache.remove(attributenamesconstants.codename);
}
if (this.utf8cache.get(constantpool.clinitsignature) >= constantpoolindex) {
this.utf8cache.remove(constantpool.clinitsignature);
}
if (this.utf8cache.get(constantpool.clinit) >= constantpoolindex) {
this.utf8cache.remove(constantpool.clinit);
}
}

/**
* resize the pool contents
*/
private final void resizepoolcontents(int minimalsize) {
int length = this.poolcontent.length;
int toadd = length;
if (toadd < minimalsize)
toadd = minimalsize;
system.arraycopy(this.poolcontent, 0, this.poolcontent = new byte[length + toadd], 0, length);
}
/**
* write a unsigned byte into the byte array
*
* @@param value <code>int</code> the value to write into the byte array
*/
protected final void writeu1(int value) {
if (this.currentoffset + 1 >= this.poolcontent.length) {
resizepoolcontents(1);
}
this.poolcontent[this.currentoffset++] = (byte) value;
}
/**
* write a unsigned byte into the byte array
*
* @@param value <code>int</code> the value to write into the byte array
*/
protected final void writeu2(int value) {
if (this.currentoffset + 2 >= this.poolcontent.length) {
resizepoolcontents(2);
}
this.poolcontent[this.currentoffset++] = (byte) (value >>> 8);
this.poolcontent[this.currentoffset++] = (byte) value;
}
public void reset() {
if (this.doublecache != null) this.doublecache.clear();
if (this.floatcache != null) this.floatcache.clear();
if (this.intcache != null) this.intcache.clear();
if (this.longcache != null) this.longcache.clear();
this.utf8cache.clear();
this.stringcache.clear();
this.methodsandfieldscache.clear();
this.classcache.clear();
this.nameandtypecacheforfieldsandmethods.clear();
this.currentindex = 1;
this.currentoffset = 0;
}
public void resetforattributename(char[] attributename, int constantpoolindex, int constantpooloffset) {
this.currentindex = constantpoolindex;
this.currentoffset = constantpooloffset;
if (this.utf8cache.get(attributename) >= constantpoolindex) {
this.utf8cache.remove(attributename);
}
}
}
