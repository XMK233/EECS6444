/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class annotationfieldreference extends fieldreference {

public int tagsourcestart, tagsourceend;

public annotationfieldreference(char[] source, long pos) {
super(source, pos);
this.bits |= insideannotation;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#issuperaccess()
*/
public boolean issuperaccess() {
return false;
}

public stringbuffer printexpression(int indent, stringbuffer output) {

if (receiver != null) {
receiver.printexpression(0, output);
}
output.append('#').append(token);
return output;
}

/* (non-javadoc)
* redefine to remove unnecessary tests while resolving in annotation
* @@see org.eclipse.jdt.internal.compiler.ast.expression#resolvetype(org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public typebinding resolvetype(blockscope scope) {

constant = notaconstant;

if (this.receiver == null) {
sourcetypebinding sourcetypebinding = scope.enclosingsourcetype();
this.receivertype = sourcetypebinding;
this.receiver = new annotationqualifiedtypereference(sourcetypebinding.compoundname, new long[sourcetypebinding.compoundname.length], 0, 0);
} else {
this.receivertype = receiver.resolvetype(scope);
}
if (this.receivertype == null) {
return null;
}

this.binding = scope.getfield(this.receivertype, this.token, this);
if (!this.binding.isvalidbinding()) {
constant = notaconstant;
scope.problemreporter().invalidfield(this, this.receivertype);
return null;
}

if (isfieldusedeprecated(binding, scope, (this.bits & isstrictlyassignedmask) != 0)) {
scope.problemreporter().deprecatedfield(this.binding, this);
}
return this.resolvedtype = binding.type;
}

/* (non-javadoc)
* redefine to remove unnecessary tests while resolving in annotation
* @@see org.eclipse.jdt.internal.compiler.ast.expression#resolvetype(org.eclipse.jdt.internal.compiler.lookup.classscope)
*/
public typebinding resolvetype(classscope scope) {

constant = notaconstant;

if (this.receiver == null) {
sourcetypebinding sourcetypebinding = scope.enclosingsourcetype();
this.receivertype = sourcetypebinding;
this.receiver = new annotationqualifiedtypereference(sourcetypebinding.compoundname, new long[sourcetypebinding.compoundname.length], 0, 0);
} else {
this.receivertype = receiver.resolvetype(scope);
}
if (this.receivertype == null) {
return null;
}

this.binding = scope.getfield(this.receivertype, this.token, this);
if (!this.binding.isvalidbinding()) {
constant = notaconstant;
scope.problemreporter().invalidfield(this, this.receivertype);
return null;
}

if (isfieldusedeprecated(binding, scope, (this.bits & isstrictlyassignedmask) != 0)) {
scope.problemreporter().deprecatedfield(this.binding, this);
}
return this.resolvedtype = binding.type;
}

/* (non-javadoc)
* redefine to capture annotation specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(iabstractsyntaxtreevisitor visitor, blockscope scope) {

if (visitor.visit(this, scope)) {
if (receiver != null) {
receiver.traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}@


1.5
log
@45592 + todo while resolving type on classscope
