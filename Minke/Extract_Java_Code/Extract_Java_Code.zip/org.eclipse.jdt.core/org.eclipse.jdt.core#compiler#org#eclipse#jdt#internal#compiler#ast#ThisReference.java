/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class thisreference extends reference {

public static thisreference implicitthis(){

thisreference implicitthis = new thisreference(0, 0);
implicitthis.bits |= isimplicitthis;
return implicitthis;
}

public thisreference(int sourcestart, int sourceend) {

this.sourcestart = sourcestart;
this.sourceend = sourceend;
}

/*
* @@see reference#analyseassignment(...)
*/
public flowinfo analyseassignment(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo, assignment assignment, boolean iscompound) {

return flowinfo; // this cannot be assigned
}

public boolean checkaccess(methodscope methodscope) {

// this/super cannot be used in constructor call
if (methodscope.isconstructorcall) {
methodscope.problemreporter().fieldsorthisbeforeconstructorinvocation(this);
return false;
}

// static may not refer to this/super
if (methodscope.isstatic) {
methodscope.problemreporter().errorthissuperinstatic(this);
return false;
}
return true;
}

/*
* @@see reference#generateassignment(...)
*/
public void generateassignment(blockscope currentscope, codestream codestream, assignment assignment, boolean valuerequired) {

// this cannot be assigned
}

public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {

int pc = codestream.position;
if (valuerequired)
codestream.aload_0();
if ((this.bits & isimplicitthis) == 0) codestream.recordpositionsfrom(pc, this.sourcestart);
}

/*
* @@see reference#generatecompoundassignment(...)
*/
public void generatecompoundassignment(blockscope currentscope, codestream codestream, expression expression, int operator, int assignmentimplicitconversion,  boolean valuerequired) {

// this cannot be assigned
}

/*
* @@see org.eclipse.jdt.internal.compiler.ast.reference#generatepostincrement()
*/
public void generatepostincrement(blockscope currentscope, codestream codestream, compoundassignment postincrement, boolean valuerequired) {

// this cannot be assigned
}

public boolean isimplicitthis() {

return (this.bits & isimplicitthis) != 0;
}

public boolean isthis() {

return true ;
}

public int nullstatus(flowinfo flowinfo) {
return flowinfo.non_null;
}

public stringbuffer printexpression(int indent, stringbuffer output){

if (isimplicitthis()) return output;
return output.append("this"); //$non-nls-1$
}

public typebinding resolvetype(blockscope scope) {

this.constant = constant.notaconstant;
if (!isimplicitthis() &&!checkaccess(scope.methodscope())) {
return null;
}
return this.resolvedtype = scope.enclosingreceivertype();
}

public void traverse(astvisitor visitor, blockscope blockscope) {

visitor.visit(this, blockscope);
visitor.endvisit(this, blockscope);
}
public void traverse(astvisitor visitor, classscope blockscope) {

visitor.visit(this, blockscope);
visitor.endvisit(this, blockscope);
}
}
