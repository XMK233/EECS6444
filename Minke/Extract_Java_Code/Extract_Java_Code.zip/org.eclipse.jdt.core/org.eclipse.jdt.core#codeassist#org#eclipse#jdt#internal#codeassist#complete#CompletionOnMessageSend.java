/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce a message send containing the cursor.
* e.g.
*
*	class x {
*    void foo() {
*      this.bar(1, 2, [cursor]
*    }
*  }
*
*	---> class x {
*         void foo() {
*           <completeonmessagesend:this.bar(1, 2)>
*         }
*       }
*
* the source range is always of length 0.
* the arguments of the message send are all the arguments defined
* before the cursor.
*/

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class completiononmessagesend extends messagesend {

public typebinding resolvetype(blockscope scope) {
if (this.arguments != null) {
int argslength = this.arguments.length;
for (int a = argslength; --a >= 0;)
this.arguments[a].resolvetype(scope);
}

if (this.receiver.isimplicitthis())
throw new completionnodefound(this, null, scope);

this.actualreceivertype = this.receiver.resolvetype(scope);
if (this.actualreceivertype == null || this.actualreceivertype.isbasetype())
throw new completionnodefound();

if (this.actualreceivertype.isarraytype())
this.actualreceivertype = scope.getjavalangobject();
throw new completionnodefound(this, this.actualreceivertype, scope);
}

public stringbuffer printexpression(int indent, stringbuffer output) {

output.append("<completeonmessagesend:"); //$non-nls-1$
if (!this.receiver.isimplicitthis()) this.receiver.printexpression(0, output).append('.');
if (this.typearguments != null) {
output.append('<');
int max = this.typearguments.length - 1;
for (int j = 0; j < max; j++) {
this.typearguments[j].print(0, output);
output.append(", ");//$non-nls-1$
}
this.typearguments[max].print(0, output);
output.append('>');
}
output.append(this.selector).append('(');
if (this.arguments != null) {
for (int i = 0; i < this.arguments.length; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.arguments[i].printexpression(0, output);
}
}
return output.append(")>"); //$non-nls-1$
}
}
