/*******************************************************************************
* copyright (c) 2005, 2009 bea systems, inc.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*    tyeung@@bea.com - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

/**
* this represents the class file information about a member value pair of an annotation.
*/
public interface ibinaryelementvaluepair {

/** @@return the name of the member */
char[] getname();

/**
* return {@@link classsignature} for a class {@@link java.lang.class}.
* return {@@link org.eclipse.jdt.internal.compiler.impl.constant} for compile-time constant of primitive type, as well as string literals.
* return {@@link enumconstantsignature} if value is an enum constant.
* return {@@link ibinaryannotation} for annotation type.
* return {@@link object}[] for array type.
*
* @@return the value of this member value pair
*/
object getvalue();
}
