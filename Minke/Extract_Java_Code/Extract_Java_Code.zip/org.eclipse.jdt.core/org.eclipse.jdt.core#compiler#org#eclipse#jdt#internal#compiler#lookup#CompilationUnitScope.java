/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     erling ellingsen -  patch for bug 125570
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.env.accessrestriction;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;
import org.eclipse.jdt.internal.compiler.util.*;

public class compilationunitscope extends scope {

public lookupenvironment environment;
public compilationunitdeclaration referencecontext;
public char[][] currentpackagename;
public packagebinding fpackage;
public importbinding[] imports;
public hashtableofobject typeorpackagecache; // used in scope.gettypeorpackage()

public sourcetypebinding[] topleveltypes;

private compoundnamevector qualifiedreferences;
private simplenamevector simplenamereferences;
private simplenamevector rootreferences;
private objectvector referencedtypes;
private objectvector referencedsupertypes;

hashtableoftype constantpoolnameusage;
private int captureid = 1;

public compilationunitscope(compilationunitdeclaration unit, lookupenvironment environment) {
super(compilation_unit_scope, null);
this.environment = environment;
this.referencecontext = unit;
unit.scope = this;
this.currentpackagename = unit.currentpackage == null ? charoperation.no_char_char : unit.currentpackage.tokens;

if (compileroptions().producereferenceinfo) {
this.qualifiedreferences = new compoundnamevector();
this.simplenamereferences = new simplenamevector();
this.rootreferences = new simplenamevector();
this.referencedtypes = new objectvector();
this.referencedsupertypes = new objectvector();
} else {
this.qualifiedreferences = null; // used to test if dependencies should be recorded
this.simplenamereferences = null;
this.rootreferences = null;
this.referencedtypes = null;
this.referencedsupertypes = null;
}
}
void buildfieldsandmethods() {
for (int i = 0, length = this.topleveltypes.length; i < length; i++)
this.topleveltypes[i].scope.buildfieldsandmethods();
}
void buildtypebindings(accessrestriction accessrestriction) {
this.topleveltypes = new sourcetypebinding[0]; // want it initialized if the package cannot be resolved
boolean firstissynthetic = false;
if (this.referencecontext.compilationresult.compilationunit != null) {
char[][] expectedpackagename = this.referencecontext.compilationresult.compilationunit.getpackagename();
if (expectedpackagename != null
&& !charoperation.equals(this.currentpackagename, expectedpackagename)) {

// only report if the unit isn't structurally empty
if (this.referencecontext.currentpackage != null
|| this.referencecontext.types != null
|| this.referencecontext.imports != null) {
problemreporter().packageisnotexpectedpackage(this.referencecontext);
}
this.currentpackagename = expectedpackagename.length == 0 ? charoperation.no_char_char : expectedpackagename;
}
}
if (this.currentpackagename == charoperation.no_char_char) {
if ((this.fpackage = this.environment.defaultpackage) == null) {
problemreporter().mustspecifypackage(this.referencecontext);
return;
}
} else {
if ((this.fpackage = this.environment.createpackage(this.currentpackagename)) == null) {
if (this.referencecontext.currentpackage != null)
problemreporter().packagecollideswithtype(this.referencecontext); // only report when the unit has a package statement
return;
} else if (this.referencecontext.ispackageinfo()) {
// resolve package annotations now if this is "package-info.java".
if (this.referencecontext.types == null || this.referencecontext.types.length == 0) {
this.referencecontext.types = new typedeclaration[1];
this.referencecontext.createpackageinfotype();
firstissynthetic = true;
}
// ensure the package annotations are copied over before resolution
if (this.referencecontext.currentpackage != null)
this.referencecontext.types[0].annotations = this.referencecontext.currentpackage.annotations;
}
recordqualifiedreference(this.currentpackagename); // always dependent on your own package
}

// skip typedeclarations which know of previously reported errors
typedeclaration[] types = this.referencecontext.types;
int typelength = (types == null) ? 0 : types.length;
this.topleveltypes = new sourcetypebinding[typelength];
int count = 0;
nexttype: for (int i = 0; i < typelength; i++) {
typedeclaration typedecl = types[i];
if (this.environment.isprocessingannotations && this.environment.ismissingtype(typedecl.name))
throw new sourcetypecollisionexception(); // resolved a type ref before apt generated the type
referencebinding typebinding = this.fpackage.gettype0(typedecl.name);
recordsimplereference(typedecl.name); // needed to detect collision cases
if (typebinding != null && typebinding.isvalidbinding() && !(typebinding instanceof unresolvedreferencebinding)) {
// if its an unresolved binding - its fixed up whenever its needed, see unresolvedreferencebinding.resolve()
if (this.environment.isprocessingannotations)
throw new sourcetypecollisionexception(); // resolved a type ref before apt generated the type
// if a type exists, check that its a valid type
// it can be a notfound problem type if its a secondary type referenced before its primary type found in additional units
// and it can be an unresolved type which is now being defined
problemreporter().duplicatetypes(this.referencecontext, typedecl);
continue nexttype;
}
if (this.fpackage != this.environment.defaultpackage && this.fpackage.getpackage(typedecl.name) != null) {
// if a package exists, it must be a valid package - cannot be a notfound problem package
// this is now a warning since a package does not really 'exist' until it contains a type, see jls v2, 7.4.3
problemreporter().typecollideswithpackage(this.referencecontext, typedecl);
}

if ((typedecl.modifiers & classfileconstants.accpublic) != 0) {
char[] maintypename;
if ((maintypename = this.referencecontext.getmaintypename()) != null // maintypename == null means that implementor of icompilationunit decided to return null
&& !charoperation.equals(maintypename, typedecl.name)) {
problemreporter().publicclassmustmatchfilename(this.referencecontext, typedecl);
// tolerate faulty main type name (91091), allow to proceed into type construction
}
}

classscope child = new classscope(this, typedecl);
sourcetypebinding type = child.buildtype(null, this.fpackage, accessrestriction);
if (firstissynthetic && i == 0)
type.modifiers |= classfileconstants.accsynthetic;
if (type != null)
this.topleveltypes[count++] = type;
}

// shrink topleveltypes... only happens if an error was reported
if (count != this.topleveltypes.length)
system.arraycopy(this.topleveltypes, 0, this.topleveltypes = new sourcetypebinding[count], 0, count);
}
void checkandsetimports() {
if (this.referencecontext.imports == null) {
this.imports = getdefaultimports();
return;
}

// allocate the import array, add java.lang.* by default
int numberofstatements = this.referencecontext.imports.length;
int numberofimports = numberofstatements + 1;
for (int i = 0; i < numberofstatements; i++) {
importreference importreference = this.referencecontext.imports[i];
if (((importreference.bits & astnode.ondemand) != 0) && charoperation.equals(typeconstants.java_lang, importreference.tokens) && !importreference.isstatic()) {
numberofimports--;
break;
}
}
importbinding[] resolvedimports = new importbinding[numberofimports];
resolvedimports[0] = getdefaultimports()[0];
int index = 1;

nextimport : for (int i = 0; i < numberofstatements; i++) {
importreference importreference = this.referencecontext.imports[i];
char[][] compoundname = importreference.tokens;

// skip duplicates or imports of the current package
for (int j = 0; j < index; j++) {
importbinding resolved = resolvedimports[j];
if (resolved.ondemand == ((importreference.bits & astnode.ondemand) != 0) && resolved.isstatic() == importreference.isstatic())
if (charoperation.equals(compoundname, resolvedimports[j].compoundname))
continue nextimport;
}

if ((importreference.bits & astnode.ondemand) != 0) {
if (charoperation.equals(compoundname, this.currentpackagename))
continue nextimport;

binding importbinding = findimport(compoundname, compoundname.length);
if (!importbinding.isvalidbinding() || (importreference.isstatic() && importbinding instanceof packagebinding))
continue nextimport;	// we report all problems in faultinimports()
resolvedimports[index++] = new importbinding(compoundname, true, importbinding, importreference);
} else {
// resolve single imports only when the last name matches
resolvedimports[index++] = new importbinding(compoundname, false, null, importreference);
}
}

// shrink resolvedimports... only happens if an error was reported
if (resolvedimports.length > index)
system.arraycopy(resolvedimports, 0, resolvedimports = new importbinding[index], 0, index);
this.imports = resolvedimports;
}

/**
* perform deferred check specific to parameterized types: bound checks, supertype collisions
*/
void checkparameterizedtypes() {
if (compileroptions().sourcelevel < classfileconstants.jdk1_5) return;

for (int i = 0, length = this.topleveltypes.length; i < length; i++) {
classscope scope = this.topleveltypes[i].scope;
scope.checkparameterizedtypebounds();
scope.checkparameterizedsupertypecollisions();
}
}
/*
* internal use-only
* innerclasses get their name computed as they are generated, since some may not
* be actually outputed if sitting inside unreachable code.
*/
public char[] computeconstantpoolname(localtypebinding localtype) {
if (localtype.constantpoolname() != null) {
return localtype.constantpoolname();
}
// delegates to the outermost enclosing classfile, since it is the only one with a global vision of its innertypes.

if (this.constantpoolnameusage == null)
this.constantpoolnameusage = new hashtableoftype();

referencebinding outermostenclosingtype = localtype.scope.outermostclassscope().enclosingsourcetype();

// ensure there is not already such a local type name defined by the user
int index = 0;
char[] candidatename;
boolean iscompliant15 = compileroptions().compliancelevel >= classfileconstants.jdk1_5;
while(true) {
if (localtype.ismembertype()){
if (index == 0){
candidatename = charoperation.concat(
localtype.enclosingtype().constantpoolname(),
localtype.sourcename,
'$');
} else {
// in case of collision, then member name gets extra $1 inserted
// e.g. class x { { class l{} new x(){ class l{} } } }
candidatename = charoperation.concat(
localtype.enclosingtype().constantpoolname(),
'$',
string.valueof(index).tochararray(),
'$',
localtype.sourcename);
}
} else if (localtype.isanonymoustype()){
if (iscompliant15) {
// from 1.5 on, use immediately enclosing type name
candidatename = charoperation.concat(
localtype.enclosingtype.constantpoolname(),
string.valueof(index+1).tochararray(),
'$');
} else {
candidatename = charoperation.concat(
outermostenclosingtype.constantpoolname(),
string.valueof(index+1).tochararray(),
'$');
}
} else {
// local type
if (iscompliant15) {
candidatename = charoperation.concat(
charoperation.concat(
localtype.enclosingtype().constantpoolname(),
string.valueof(index+1).tochararray(),
'$'),
localtype.sourcename);
} else {
candidatename = charoperation.concat(
outermostenclosingtype.constantpoolname(),
'$',
string.valueof(index+1).tochararray(),
'$',
localtype.sourcename);
}
}
if (this.constantpoolnameusage.get(candidatename) != null) {
index ++;
} else {
this.constantpoolnameusage.put(candidatename, localtype);
break;
}
}
return candidatename;
}

void connecttypehierarchy() {
for (int i = 0, length = this.topleveltypes.length; i < length; i++)
this.topleveltypes[i].scope.connecttypehierarchy();
}
void faultinimports() {
if (this.typeorpackagecache != null)
return; // can be called when a field constant is resolved before static imports
if (this.referencecontext.imports == null) {
this.typeorpackagecache = new hashtableofobject(1);
return;
}

// collect the top level type names if a single type import exists
int numberofstatements = this.referencecontext.imports.length;
hashtableoftype typesbysimplenames = null;
for (int i = 0; i < numberofstatements; i++) {
if ((this.referencecontext.imports[i].bits & astnode.ondemand) == 0) {
typesbysimplenames = new hashtableoftype(this.topleveltypes.length + numberofstatements);
for (int j = 0, length = this.topleveltypes.length; j < length; j++)
typesbysimplenames.put(this.topleveltypes[j].sourcename, this.topleveltypes[j]);
break;
}
}

// allocate the import array, add java.lang.* by default
int numberofimports = numberofstatements + 1;
for (int i = 0; i < numberofstatements; i++) {
importreference importreference = this.referencecontext.imports[i];
if (((importreference.bits & astnode.ondemand) != 0) && charoperation.equals(typeconstants.java_lang, importreference.tokens) && !importreference.isstatic()) {
numberofimports--;
break;
}
}
importbinding[] resolvedimports = new importbinding[numberofimports];
resolvedimports[0] = getdefaultimports()[0];
int index = 1;

// keep static imports with normal imports until there is a reason to split them up
// on demand imports continue to be packages & types. need to check on demand type imports for fields/methods
// single imports change from being just types to types or fields
nextimport : for (int i = 0; i < numberofstatements; i++) {
importreference importreference = this.referencecontext.imports[i];
char[][] compoundname = importreference.tokens;

// skip duplicates or imports of the current package
for (int j = 0; j < index; j++) {
importbinding resolved = resolvedimports[j];
if (resolved.ondemand == ((importreference.bits & astnode.ondemand) != 0) && resolved.isstatic() == importreference.isstatic()) {
if (charoperation.equals(compoundname, resolved.compoundname)) {
problemreporter().unusedimport(importreference); // since skipped, must be reported now
continue nextimport;
}
}
}
if ((importreference.bits & astnode.ondemand) != 0) {
if (charoperation.equals(compoundname, this.currentpackagename)) {
problemreporter().unusedimport(importreference); // since skipped, must be reported now
continue nextimport;
}

binding importbinding = findimport(compoundname, compoundname.length);
if (!importbinding.isvalidbinding()) {
problemreporter().importproblem(importreference, importbinding);
continue nextimport;
}
if (importreference.isstatic() && importbinding instanceof packagebinding) {
problemreporter().cannotimportpackage(importreference);
continue nextimport;
}
resolvedimports[index++] = new importbinding(compoundname, true, importbinding, importreference);
} else {
binding importbinding = findsingleimport(compoundname, binding.type | binding.field | binding.method, importreference.isstatic());
if (!importbinding.isvalidbinding()) {
if (importbinding.problemid() == problemreasons.ambiguous) {
// keep it unless a duplicate can be found below
} else {
problemreporter().importproblem(importreference, importbinding);
continue nextimport;
}
}
if (importbinding instanceof packagebinding) {
problemreporter().cannotimportpackage(importreference);
continue nextimport;
}
referencebinding conflictingtype = null;
if (importbinding instanceof methodbinding) {
conflictingtype = (referencebinding) gettype(compoundname, compoundname.length);
if (!conflictingtype.isvalidbinding() || (importreference.isstatic() && !conflictingtype.isstatic()))
conflictingtype = null;
}
// collisions between an imported static field & a type should be checked according to spec... but currently not by javac
if (importbinding instanceof referencebinding || conflictingtype != null) {
referencebinding referencebinding = conflictingtype == null ? (referencebinding) importbinding : conflictingtype;
referencebinding typetocheck = referencebinding.problemid() == problemreasons.ambiguous
? ((problemreferencebinding) referencebinding).closestmatch
: referencebinding;
if (importreference.istypeusedeprecated(typetocheck, this))
problemreporter().deprecatedtype(typetocheck, importreference);

referencebinding existingtype = typesbysimplenames.get(compoundname[compoundname.length - 1]);
if (existingtype != null) {
// duplicate test above should have caught this case, but make sure
if (existingtype == referencebinding) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=302865
// check all resolved imports to see if this import qualifies as a duplicate
for (int j = 0; j < index; j++) {
importbinding resolved = resolvedimports[j];
if (resolved instanceof importconflictbinding) {
importconflictbinding importconflictbinding = (importconflictbinding) resolved;
if (importconflictbinding.conflictingtypebinding == referencebinding) {
if (!importreference.isstatic()) {
// resolved is implicitly static
problemreporter().duplicateimport(importreference);
resolvedimports[index++] = new importbinding(compoundname, false, importbinding, importreference);
}
}
} else if (resolved.resolvedimport == referencebinding) {
if (importreference.isstatic() != resolved.isstatic()) {
problemreporter().duplicateimport(importreference);
resolvedimports[index++] = new importbinding(compoundname, false, importbinding, importreference);
}
}
}
continue nextimport;
}
// either the type collides with a top level type or another imported type
for (int j = 0, length = this.topleveltypes.length; j < length; j++) {
if (charoperation.equals(this.topleveltypes[j].sourcename, existingtype.sourcename)) {
problemreporter().conflictingimport(importreference);
continue nextimport;
}
}
problemreporter().duplicateimport(importreference);
continue nextimport;
}
typesbysimplenames.put(compoundname[compoundname.length - 1], referencebinding);
} else if (importbinding instanceof fieldbinding) {
for (int j = 0; j < index; j++) {
importbinding resolved = resolvedimports[j];
// find other static fields with the same name
if (resolved.isstatic() && resolved.resolvedimport instanceof fieldbinding && importbinding != resolved.resolvedimport) {
if (charoperation.equals(compoundname[compoundname.length - 1], resolved.compoundname[resolved.compoundname.length - 1])) {
problemreporter().duplicateimport(importreference);
continue nextimport;
}
}
}
}
resolvedimports[index++] = conflictingtype == null
? new importbinding(compoundname, false, importbinding, importreference)
: new importconflictbinding(compoundname, importbinding, conflictingtype, importreference);
}
}

// shrink resolvedimports... only happens if an error was reported
if (resolvedimports.length > index)
system.arraycopy(resolvedimports, 0, resolvedimports = new importbinding[index], 0, index);
this.imports = resolvedimports;

int length = this.imports.length;
this.typeorpackagecache = new hashtableofobject(length);
for (int i = 0; i < length; i++) {
importbinding binding = this.imports[i];
if (!binding.ondemand && binding.resolvedimport instanceof referencebinding || binding instanceof importconflictbinding)
this.typeorpackagecache.put(binding.compoundname[binding.compoundname.length - 1], binding);
}
}
public void faultintypes() {
faultinimports();

for (int i = 0, length = this.topleveltypes.length; i < length; i++)
this.topleveltypes[i].faultintypesforfieldsandmethods();
}
// this api is for code assist purpose
public binding findimport(char[][] compoundname, boolean findstaticimports, boolean ondemand) {
if(ondemand) {
return findimport(compoundname, compoundname.length);
} else {
return findsingleimport(compoundname, binding.type | binding.field | binding.method, findstaticimports);
}
}
private binding findimport(char[][] compoundname, int length) {
recordqualifiedreference(compoundname);

binding binding = this.environment.gettoplevelpackage(compoundname[0]);
int i = 1;
foundnothingortype: if (binding != null) {
packagebinding packagebinding = (packagebinding) binding;
while (i < length) {
binding = packagebinding.gettypeorpackage(compoundname[i++]);
if (binding == null || !binding.isvalidbinding()) {
binding = null;
break foundnothingortype;
}
if (!(binding instanceof packagebinding))
break foundnothingortype;

packagebinding = (packagebinding) binding;
}
return packagebinding;
}

referencebinding type;
if (binding == null) {
if (this.environment.defaultpackage == null || compileroptions().compliancelevel >= classfileconstants.jdk1_4)
return new problemreferencebinding(charoperation.subarray(compoundname, 0, i), null, problemreasons.notfound);
type = findtype(compoundname[0], this.environment.defaultpackage, this.environment.defaultpackage);
if (type == null || !type.isvalidbinding())
return new problemreferencebinding(charoperation.subarray(compoundname, 0, i), null, problemreasons.notfound);
i = 1; // reset to look for member types inside the default package type
} else {
type = (referencebinding) binding;
}

while (i < length) {
type = (referencebinding)this.environment.converttorawtype(type, false /*do not force conversion of enclosing types*/); // type imports are necessarily raw for all except last
if (!type.canbeseenby(this.fpackage))
return new problemreferencebinding(charoperation.subarray(compoundname, 0, i), type, problemreasons.notvisible);

char[] name = compoundname[i++];
// does not look for inherited member types on purpose, only immediate members
type = type.getmembertype(name);
if (type == null)
return new problemreferencebinding(charoperation.subarray(compoundname, 0, i), null, problemreasons.notfound);
}
if (!type.canbeseenby(this.fpackage))
return new problemreferencebinding(compoundname, type, problemreasons.notvisible);
return type;
}
private binding findsingleimport(char[][] compoundname, int mask, boolean findstaticimports) {
if (compoundname.length == 1) {
// findtype records the reference
// the name cannot be a package
if (this.environment.defaultpackage == null || compileroptions().compliancelevel >= classfileconstants.jdk1_4)
return new problemreferencebinding(compoundname, null, problemreasons.notfound);
referencebinding typebinding = findtype(compoundname[0], this.environment.defaultpackage, this.fpackage);
if (typebinding == null)
return new problemreferencebinding(compoundname, null, problemreasons.notfound);
return typebinding;
}

if (findstaticimports)
return findsinglestaticimport(compoundname, mask);
return findimport(compoundname, compoundname.length);
}
private binding findsinglestaticimport(char[][] compoundname, int mask) {
binding binding = findimport(compoundname, compoundname.length - 1);
if (!binding.isvalidbinding()) return binding;

char[] name = compoundname[compoundname.length - 1];
if (binding instanceof packagebinding) {
binding temp = ((packagebinding) binding).gettypeorpackage(name);
if (temp != null && temp instanceof referencebinding) // must resolve to a member type or field, not a top level type
return new problemreferencebinding(compoundname, (referencebinding) temp, problemreasons.invalidtypeforstaticimport);
return binding; // cannot be a package, error is caught in sender
}

// look to see if its a static field first
referencebinding type = (referencebinding) binding;
fieldbinding field = (mask & binding.field) != 0 ? findfield(type, name, null, true) : null;
if (field != null) {
if (field.problemid() == problemreasons.ambiguous && ((problemfieldbinding) field).closestmatch.isstatic())
return field; // keep the ambiguous field instead of a possible method match
if (field.isvalidbinding() && field.isstatic() && field.canbeseenby(type, null, this))
return field;
}

// look to see if there is a static method with the same selector
methodbinding method = (mask & binding.method) != 0 ? findstaticmethod(type, name) : null;
if (method != null) return method;

type = findmembertype(name, type);
if (type == null || !type.isstatic()) {
if (field != null && !field.isvalidbinding() && field.problemid() != problemreasons.notfound)
return field;
return new problemreferencebinding(compoundname, type, problemreasons.notfound);
}
if (type.isvalidbinding() && !type.canbeseenby(this.fpackage))
return new problemreferencebinding(compoundname, type, problemreasons.notvisible);
if (type.problemid() == problemreasons.notvisible) // ensure compoundname is correct
return new problemreferencebinding(compoundname, ((problemreferencebinding) type).closestmatch, problemreasons.notvisible);
return type;
}
// helper method for findsinglestaticimport()
private methodbinding findstaticmethod(referencebinding currenttype, char[] selector) {
if (!currenttype.canbeseenby(this))
return null;

do {
currenttype.initializeforstaticimports();
methodbinding[] methods = currenttype.getmethods(selector);
if (methods != binding.no_methods) {
for (int i = methods.length; --i >= 0;) {
methodbinding method = methods[i];
if (method.isstatic() && method.canbeseenby(this.fpackage))
return method;
}
}
} while ((currenttype = currenttype.superclass()) != null);
return null;
}
importbinding[] getdefaultimports() {
// initialize the default imports if necessary... share the default java.lang.* import
if (this.environment.defaultimports != null) return this.environment.defaultimports;

binding importbinding = this.environment.gettoplevelpackage(typeconstants.java);
if (importbinding != null)
importbinding = ((packagebinding) importbinding).gettypeorpackage(typeconstants.java_lang[1]);

if (importbinding == null || !importbinding.isvalidbinding()) {
// create a proxy for the missing binarytype
problemreporter().isclasspathcorrect(
typeconstants.java_lang_object,
this.referencecontext,
this.environment.missingclassfilelocation);
binarytypebinding missingobject = this.environment.createmissingtype(null, typeconstants.java_lang_object);
importbinding = missingobject.fpackage;
}

return this.environment.defaultimports = new importbinding[] {new importbinding(typeconstants.java_lang, true, importbinding, null)};
}
// not public api
public final binding getimport(char[][] compoundname, boolean ondemand, boolean isstaticimport) {
if (ondemand)
return findimport(compoundname, compoundname.length);
return findsingleimport(compoundname, binding.type | binding.field | binding.method, isstaticimport);
}

public int nextcaptureid() {
return this.captureid++;
}

/* answer the problem reporter to use for raising new problems.
*
* note that as a side-effect, this updates the current reference context
* (unit, type or method) in case the problem handler decides it is necessary
* to abort.
*/
public problemreporter problemreporter() {
problemreporter problemreporter = this.referencecontext.problemreporter;
problemreporter.referencecontext = this.referencecontext;
return problemreporter;
}

/*
what do we hold onto:

1. when we resolve 'a.b.c', say we keep only 'a.b.c'
& when we fail to resolve 'c' in 'a.b', lets keep 'a.b.c'
then when we come across a new/changed/removed item named 'a.b.c',
we would find all references to 'a.b.c'
-> this approach fails because every type is resolved in every ondemand import to
detect collision cases... so the references could be 10 times bigger than necessary.

2. when we resolve 'a.b.c', lets keep 'a.b' & 'c'
& when we fail to resolve 'c' in 'a.b', lets keep 'a.b' & 'c'
then when we come across a new/changed/removed item named 'a.b.c',
we would find all references to 'a.b' & 'c'
-> this approach does not have a space problem but fails to handle collision cases.
what happens if a type is added named 'a.b'? we would search for 'a' & 'b' but
would not find a match.

3. when we resolve 'a.b.c', lets keep 'a', 'a.b' & 'a', 'b', 'c'
& when we fail to resolve 'c' in 'a.b', lets keep 'a', 'a.b' & 'a', 'b', 'c'
then when we come across a new/changed/removed item named 'a.b.c',
we would find all references to 'a.b' & 'c'
or 'a.b' -> 'a' & 'b'
or 'a' -> '' & 'a'
-> as long as each single char[] is interned, we should not have a space problem
and can handle collision cases.

4. when we resolve 'a.b.c', lets keep 'a.b' & 'a', 'b', 'c'
& when we fail to resolve 'c' in 'a.b', lets keep 'a.b' & 'a', 'b', 'c'
then when we come across a new/changed/removed item named 'a.b.c',
we would find all references to 'a.b' & 'c'
or 'a.b' -> 'a' & 'b' in the simple name collection
or 'a' -> 'a' in the simple name collection
-> as long as each single char[] is interned, we should not have a space problem
and can handle collision cases.
*/
void recordqualifiedreference(char[][] qualifiedname) {
if (this.qualifiedreferences == null) return; // not recording dependencies

int length = qualifiedname.length;
if (length > 1) {
recordrootreference(qualifiedname[0]);
while (!this.qualifiedreferences.contains(qualifiedname)) {
this.qualifiedreferences.add(qualifiedname);
if (length == 2) {
recordsimplereference(qualifiedname[0]);
recordsimplereference(qualifiedname[1]);
return;
}
length--;
recordsimplereference(qualifiedname[length]);
system.arraycopy(qualifiedname, 0, qualifiedname = new char[length][], 0, length);
}
} else if (length == 1) {
recordrootreference(qualifiedname[0]);
recordsimplereference(qualifiedname[0]);
}
}
void recordreference(char[][] qualifiedenclosingname, char[] simplename) {
recordqualifiedreference(qualifiedenclosingname);
if (qualifiedenclosingname.length == 0)
recordrootreference(simplename);
recordsimplereference(simplename);
}
void recordreference(referencebinding type, char[] simplename) {
referencebinding actualtype = typetorecord(type);
if (actualtype != null)
recordreference(actualtype.compoundname, simplename);
}
void recordrootreference(char[] simplename) {
if (this.rootreferences == null) return; // not recording dependencies

if (!this.rootreferences.contains(simplename))
this.rootreferences.add(simplename);
}
void recordsimplereference(char[] simplename) {
if (this.simplenamereferences == null) return; // not recording dependencies

if (!this.simplenamereferences.contains(simplename))
this.simplenamereferences.add(simplename);
}
void recordsupertypereference(typebinding type) {
if (this.referencedsupertypes == null) return; // not recording dependencies

referencebinding actualtype = typetorecord(type);
if (actualtype != null && !this.referencedsupertypes.containsidentical(actualtype))
this.referencedsupertypes.add(actualtype);
}
public void recordtypeconversion(typebinding supertype, typebinding subtype) {
recordsupertypereference(subtype); // must record the hierarchy of the subtype that is converted to the supertype
}
void recordtypereference(typebinding type) {
if (this.referencedtypes == null) return; // not recording dependencies

referencebinding actualtype = typetorecord(type);
if (actualtype != null && !this.referencedtypes.containsidentical(actualtype))
this.referencedtypes.add(actualtype);
}
void recordtypereferences(typebinding[] types) {
if (this.referencedtypes == null) return; // not recording dependencies
if (types == null || types.length == 0) return;

for (int i = 0, max = types.length; i < max; i++) {
// no need to record supertypes of method arguments & thrown exceptions, just the compoundname
// if a field/method is retrieved from such a type then a separate call does the job
referencebinding actualtype = typetorecord(types[i]);
if (actualtype != null && !this.referencedtypes.containsidentical(actualtype))
this.referencedtypes.add(actualtype);
}
}
binding resolvesingleimport(importbinding importbinding, int mask) {
if (importbinding.resolvedimport == null) {
importbinding.resolvedimport = findsingleimport(importbinding.compoundname, mask, importbinding.isstatic());
if (!importbinding.resolvedimport.isvalidbinding() || importbinding.resolvedimport instanceof packagebinding) {
if (importbinding.resolvedimport.problemid() == problemreasons.ambiguous)
return importbinding.resolvedimport;
if (this.imports != null) {
importbinding[] newimports = new importbinding[this.imports.length - 1];
for (int i = 0, n = 0, max = this.imports.length; i < max; i++)
if (this.imports[i] != importbinding)
newimports[n++] = this.imports[i];
this.imports = newimports;
}
return null;
}
}
return importbinding.resolvedimport;
}
public void storedependencyinfo() {
// add the type hierarchy of each referenced supertype
// cannot do early since the hierarchy may not be fully resolved
for (int i = 0; i < this.referencedsupertypes.size; i++) { // grows as more types are added
referencebinding type = (referencebinding) this.referencedsupertypes.elementat(i);
if (!this.referencedtypes.containsidentical(type))
this.referencedtypes.add(type);

if (!type.islocaltype()) {
referencebinding enclosing = type.enclosingtype();
if (enclosing != null)
recordsupertypereference(enclosing);
}
referencebinding superclass = type.superclass();
if (superclass != null)
recordsupertypereference(superclass);
referencebinding[] interfaces = type.superinterfaces();
if (interfaces != null)
for (int j = 0, length = interfaces.length; j < length; j++)
recordsupertypereference(interfaces[j]);
}

for (int i = 0, l = this.referencedtypes.size; i < l; i++) {
referencebinding type = (referencebinding) this.referencedtypes.elementat(i);
if (!type.islocaltype())
recordqualifiedreference(type.ismembertype()
? charoperation.spliton('.', type.readablename())
: type.compoundname);
}

int size = this.qualifiedreferences.size;
char[][][] qualifiedrefs = new char[size][][];
for (int i = 0; i < size; i++)
qualifiedrefs[i] = this.qualifiedreferences.elementat(i);
this.referencecontext.compilationresult.qualifiedreferences = qualifiedrefs;

size = this.simplenamereferences.size;
char[][] simplerefs = new char[size][];
for (int i = 0; i < size; i++)
simplerefs[i] = this.simplenamereferences.elementat(i);
this.referencecontext.compilationresult.simplenamereferences = simplerefs;

size = this.rootreferences.size;
char[][] rootrefs = new char[size][];
for (int i = 0; i < size; i++)
rootrefs[i] = this.rootreferences.elementat(i);
this.referencecontext.compilationresult.rootreferences = rootrefs;
}
public string tostring() {
return "--- compilationunit scope : " + new string(this.referencecontext.getfilename()); //$non-nls-1$
}
private referencebinding typetorecord(typebinding type) {
if (type.isarraytype())
type = ((arraybinding) type).leafcomponenttype;

switch (type.kind()) {
case binding.base_type :
case binding.type_parameter :
case binding.wildcard_type :
case binding.intersection_type :
return null;
case binding.parameterized_type :
case binding.raw_type :
type = type.erasure();
}
referencebinding reftype = (referencebinding) type;
if (reftype.islocaltype()) return null;
return reftype;
}
public void verifymethods(methodverifier verifier) {
for (int i = 0, length = this.topleveltypes.length; i < length; i++)
this.topleveltypes[i].verifymethods(verifier);
}
}
