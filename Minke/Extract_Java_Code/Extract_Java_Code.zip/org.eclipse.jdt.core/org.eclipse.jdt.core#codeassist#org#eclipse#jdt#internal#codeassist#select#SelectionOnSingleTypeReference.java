/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

/*
* selection node build by the parser in any case it was intending to
* reduce a type reference containing the selection identifier as a single
* name reference.
* e.g.
*
*	class x extends [start]object[end]
*
*	---> class x extends <selectontype:object>
*
*/
import org.eclipse.jdt.internal.compiler.ast.singletypereference;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.packagebinding;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.problemreferencebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class selectiononsingletypereference extends singletypereference {
public selectiononsingletypereference(char[] source, long pos) {
super(source, pos);
}
public void abouttoresolve(scope scope) {
gettypebinding(scope.parent); // step up from the classscope
}
protected typebinding gettypebinding(scope scope) {
// it can be a package, type or member type
binding binding = scope.gettypeorpackage(new char[][] {this.token});
if (!binding.isvalidbinding()) {
if (binding instanceof typebinding) {
scope.problemreporter().invalidtype(this, (typebinding) binding);
} else if (binding instanceof packagebinding) {
problemreferencebinding problembinding = new problemreferencebinding(((packagebinding)binding).compoundname, null, binding.problemid());
scope.problemreporter().invalidtype(this, problembinding);
}
throw new selectionnodefound();
}
throw new selectionnodefound(binding);
}
public stringbuffer printexpression(int indent, stringbuffer output) {

return output.append("<selectontype:").append(this.token).append('>');//$non-nls-1$
}
public typebinding resolvetypeenclosing(blockscope scope, referencebinding enclosingtype) {
super.resolvetypeenclosing(scope, enclosingtype);

// tolerate some error cases
if (this.resolvedtype == null ||
!(this.resolvedtype.isvalidbinding() ||
this.resolvedtype.problemid() == problemreasons.notvisible))
throw new selectionnodefound();
else
throw new selectionnodefound(this.resolvedtype);
}
}
