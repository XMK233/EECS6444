/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

abstract public class classfilestruct {
byte[] reference;
int[] constantpooloffsets;
int structoffset;
public classfilestruct(byte[] classfilebytes, int[] offsets, int offset) {
this.reference = classfilebytes;
this.constantpooloffsets = offsets;
this.structoffset = offset;
}
public double doubleat(int relativeoffset) {
return (double.longbitstodouble(i8at(relativeoffset)));
}
public float floatat(int relativeoffset) {
return (float.intbitstofloat(i4at(relativeoffset)));
}
public int i4at(int relativeoffset) {
int position = relativeoffset + this.structoffset;
return ((this.reference[position++] & 0xff) << 24) | ((this.reference[position++] & 0xff) << 16) | ((this.reference[position++] & 0xff) << 8) + (this.reference[position] & 0xff);
}
public long i8at(int relativeoffset) {
int position = relativeoffset + this.structoffset;
return (((long) (this.reference[position++] & 0xff)) << 56)
| (((long) (this.reference[position++] & 0xff)) << 48)
| (((long) (this.reference[position++] & 0xff)) << 40)
| (((long) (this.reference[position++] & 0xff)) << 32)
| (((long) (this.reference[position++] & 0xff)) << 24)
| (((long) (this.reference[position++] & 0xff)) << 16)
| (((long) (this.reference[position++] & 0xff)) << 8)
| (this.reference[position++] & 0xff);
}
protected void reset() {
this.reference = null;
this.constantpooloffsets = null;
}
public int u1at(int relativeoffset) {
return (this.reference[relativeoffset + this.structoffset] & 0xff);
}
public int u2at(int relativeoffset) {
int position = relativeoffset + this.structoffset;
return ((this.reference[position++] & 0xff) << 8) | (this.reference[position] & 0xff);
}
public long u4at(int relativeoffset) {
int position = relativeoffset + this.structoffset;
return (((this.reference[position++] & 0xffl) << 24) | ((this.reference[position++] & 0xff) << 16) | ((this.reference[position++] & 0xff) << 8) | (this.reference[position] & 0xff));
}
public char[] utf8at(int relativeoffset, int bytesavailable) {
int length = bytesavailable;
char outputbuf[] = new char[bytesavailable];
int outputpos = 0;
int readoffset = this.structoffset + relativeoffset;

while (length != 0) {
int x = this.reference[readoffset++] & 0xff;
length--;
if ((0x80 & x) != 0) {
if ((x & 0x20) != 0) {
length-=2;
x = ((x & 0xf) << 12) | ((this.reference[readoffset++] & 0x3f) << 6) | (this.reference[readoffset++] & 0x3f);
} else {
length--;
x = ((x & 0x1f) << 6) | (this.reference[readoffset++] & 0x3f);
}
}
outputbuf[outputpos++] = (char) x;
}

if (outputpos != bytesavailable) {
system.arraycopy(outputbuf, 0, (outputbuf = new char[outputpos]), 0, outputpos);
}
return outputbuf;
}
}
