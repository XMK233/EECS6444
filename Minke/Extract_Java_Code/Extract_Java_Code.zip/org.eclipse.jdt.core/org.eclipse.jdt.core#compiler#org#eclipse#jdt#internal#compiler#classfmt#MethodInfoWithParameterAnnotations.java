/*******************************************************************************
* copyright (c) 2005, 2007 bea systems, inc.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*    tyeung@@bea.com - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

import org.eclipse.jdt.internal.compiler.env.ibinaryannotation;

class methodinfowithparameterannotations extends methodinfowithannotations {
private annotationinfo[][] parameterannotations;

methodinfowithparameterannotations(methodinfo methodinfo, annotationinfo[] annotations, annotationinfo[][] parameterannotations) {
super(methodinfo, annotations);
this.parameterannotations = parameterannotations;
}

public ibinaryannotation[] getparameterannotations(int index) {
return this.parameterannotations[index];
}
protected void initialize() {
for (int i = 0, l = this.parameterannotations == null ? 0 : this.parameterannotations.length; i < l; i++) {
annotationinfo[] infos = this.parameterannotations[i];
for (int j = 0, k = infos == null ? 0 : infos.length; j < k; j++)
infos[j].initialize();
}
super.initialize();
}
protected void reset() {
for (int i = 0, l = this.parameterannotations == null ? 0 : this.parameterannotations.length; i < l; i++) {
annotationinfo[] infos = this.parameterannotations[i];
for (int j = 0, k = infos == null ? 0 : infos.length; j < k; j++)
infos[j].reset();
}
super.reset();
}
protected void tostringcontent(stringbuffer buffer) {
super.tostringcontent(buffer);
for (int i = 0, l = this.parameterannotations == null ? 0 : this.parameterannotations.length; i < l; i++) {
buffer.append("param" + (i - 1)); //$non-nls-1$
buffer.append('\n');
annotationinfo[] infos = this.parameterannotations[i];
for (int j = 0, k = infos == null ? 0 : infos.length; j < k; j++) {
buffer.append(infos[j]);
buffer.append('\n');
}
}
}
}
