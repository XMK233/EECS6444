/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.impl;

public class intconstant extends constant {

int value;

private static final intconstant min_value = new intconstant(integer.min_value);
private static final intconstant minus_four = new intconstant(-4);
private static final intconstant minus_three = new intconstant(-3);
private static final intconstant minus_two = new intconstant(-2);
private static final intconstant minus_one = new intconstant(-1);
private static final intconstant zero = new intconstant(0);
private static final intconstant one = new intconstant(1);
private static final intconstant two = new intconstant(2);
private static final intconstant three = new intconstant(3);
private static final intconstant four = new intconstant(4);
private static final intconstant five = new intconstant(5);
private static final intconstant six = new intconstant(6);
private static final intconstant seven = new intconstant(7);
private static final intconstant eight= new intconstant(8);
private static final intconstant nine = new intconstant(9);
private static final intconstant ten = new intconstant(10);

public static constant fromvalue(int value) {
switch (value) {
case integer.min_value : return intconstant.min_value;
case -4 : return intconstant.minus_four;
case -3 : return intconstant.minus_three;
case -2 : return intconstant.minus_two;
case -1 : return intconstant.minus_one;
case 0 : return intconstant.zero;
case 1 : return intconstant.one;
case 2 : return intconstant.two;
case 3 : return intconstant.three;
case 4 : return intconstant.four;
case 5 : return intconstant.five;
case 6 : return intconstant.six;
case 7 : return intconstant.seven;
case 8 : return intconstant.eight;
case 9 : return intconstant.nine;
case 10 : return intconstant.ten;
}
return new intconstant(value);
}

private intconstant(int value) {
this.value = value;
}

public byte bytevalue() {
return (byte) this.value;
}

public char charvalue() {
return (char) this.value;
}

public double doublevalue() {
return this.value; // implicit cast to return type
}

public float floatvalue() {
return this.value; // implicit cast to return type
}

public int intvalue() {
return this.value;
}

public long longvalue() {
return this.value; // implicit cast to return type
}

public short shortvalue() {
return (short) this.value;
}

public string stringvalue() {
//spec 15.17.11
return string.valueof(this.value);
}

public string tostring() {
return "(int)" + this.value; //$non-nls-1$
}

public int typeid() {
return t_int;
}
}
