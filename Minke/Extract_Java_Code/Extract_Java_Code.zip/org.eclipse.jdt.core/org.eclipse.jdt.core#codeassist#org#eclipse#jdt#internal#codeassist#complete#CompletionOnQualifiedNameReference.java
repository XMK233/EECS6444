/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce a qualified name reference containing the completion identifier.
* e.g.
*
*	class x {
*    y y;
*    void foo() {
*      y.fred.ba[cursor]
*    }
*  }
*
*	---> class x {
*         y y;
*         void foo() {
*           <completeonname:y.fred.ba>
*         }
*       }
*
* the source range of the completion node denotes the source range
* which should be replaced by the completion.
*/

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class completiononqualifiednamereference extends qualifiednamereference {
public char[] completionidentifier;
public boolean isinsideannotationattribute;
public completiononqualifiednamereference(char[][] previousidentifiers, char[] completionidentifier, long[] positions, boolean isinsideannotationattribute) {
super(previousidentifiers, positions, (int) (positions[0] >>> 32), (int) positions[positions.length - 1]);
this.completionidentifier = completionidentifier;
this.isinsideannotationattribute = isinsideannotationattribute;
}
public stringbuffer printexpression(int indent, stringbuffer output) {

output.append("<completeonname:"); //$non-nls-1$
for (int i = 0; i < this.tokens.length; i++) {
output.append(this.tokens[i]);
output.append('.');
}
output.append(this.completionidentifier).append('>');
return output;
}
public typebinding resolvetype(blockscope scope) {
// it can be a package, type, member type, local variable or field
this.binding = scope.getbinding(this.tokens, this);
if (!this.binding.isvalidbinding()) {
if (this.binding instanceof problemfieldbinding) {
scope.problemreporter().invalidfield(this, (fieldbinding) this.binding);
} else if (this.binding instanceof problemreferencebinding || this.binding instanceof missingtypebinding) {
scope.problemreporter().invalidtype(this, (typebinding) this.binding);
} else {
scope.problemreporter().unresolvablereference(this, this.binding);
}

if (this.binding.problemid() == problemreasons.notfound) {
throw new completionnodefound(this, this.binding, scope);
}

throw new completionnodefound();
}

throw new completionnodefound(this, this.binding, scope);
}
}
