/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser.diagnose;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.invalidinputexception;
import org.eclipse.jdt.internal.compiler.parser.scanner;
import org.eclipse.jdt.internal.compiler.parser.terminaltokens;
import org.eclipse.jdt.internal.compiler.util.util;

public class lexstream implements terminaltokens {
public static final int is_after_jump = 1;
public static final int lbrace_missing = 2;

public static class token{
int kind;
char[] name;
int start;
int end;
int line;
int flags;

public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append(this.name).append('[').append(this.kind).append(']');
buffer.append('{').append(this.start).append(',').append(this.end).append('}').append(this.line);
return buffer.tostring();
}

}

private int tokencacheindex;
private int tokencacheeofindex;
private token[] tokencache;

private int currentindex = -1;

private scanner scanner;
private int[] intervalstarttoskip;
private int[] intervalendtoskip;
private int[] intervalflagstoskip;

private int previousinterval = -1;
private int currentinterval = -1;

public lexstream(int size, scanner scanner, int[] intervalstarttoskip, int[] intervalendtoskip, int[] intervalflagstoskip, int firsttoken, int init, int eof) {
this.tokencache = new token[size];
this.tokencacheindex = 0;
this.tokencacheeofindex = integer.max_value;
this.tokencache[0] = new token();
this.tokencache[0].kind = firsttoken;
this.tokencache[0].name = charoperation.no_char;
this.tokencache[0].start = init;
this.tokencache[0].end = init;
this.tokencache[0].line = 0;

this.intervalstarttoskip = intervalstarttoskip;
this.intervalendtoskip = intervalendtoskip;
this.intervalflagstoskip = intervalflagstoskip;

scanner.resetto(init, eof);
this.scanner = scanner;
}

private void readtokenfromscanner(){
int length = this.tokencache.length;
boolean tokennotfound = true;

while(tokennotfound) {
try {
int tokenkind =  this.scanner.getnexttoken();
if(tokenkind != tokennameeof) {
int start = this.scanner.getcurrenttokenstartposition();
int end = this.scanner.getcurrenttokenendposition();

int nextinterval = this.currentinterval + 1;
if(this.intervalstarttoskip.length == 0 ||
nextinterval >= this.intervalstarttoskip.length ||
start < this.intervalstarttoskip[nextinterval]) {
token token = new token();
token.kind = tokenkind;
token.name = this.scanner.getcurrenttokensource();
token.start = start;
token.end = end;
token.line = util.getlinenumber(end, this.scanner.lineends, 0, this.scanner.lineptr);

if(this.currentinterval != this.previousinterval && (this.intervalflagstoskip[this.currentinterval] & rangeutil.ignore) == 0){
token.flags = is_after_jump;
if((this.intervalflagstoskip[this.currentinterval] & rangeutil.lbrace_missing) != 0){
token.flags |= lbrace_missing;
}
}
this.previousinterval = this.currentinterval;

this.tokencache[++this.tokencacheindex % length] = token;

tokennotfound = false;
} else {
this.scanner.resetto(this.intervalendtoskip[++this.currentinterval] + 1, this.scanner.eofposition - 1);
}
} else {
int start = this.scanner.getcurrenttokenstartposition();
int end = this.scanner.getcurrenttokenendposition();
token token = new token();
token.kind = tokenkind;
token.name = charoperation.no_char;
token.start = start;
token.end = end;
token.line = util.getlinenumber(end, this.scanner.lineends, 0, this.scanner.lineptr);

this.tokencache[++this.tokencacheindex % length] = token;

this.tokencacheeofindex = this.tokencacheindex;
tokennotfound = false;
}
} catch (invalidinputexception e) {
// return next token
}
}
}

public token token(int index) {
if(index < 0) {
token eoftoken = new token();
eoftoken.kind = tokennameeof;
eoftoken.name = charoperation.no_char;
return eoftoken;
}
if(this.tokencacheeofindex >= 0 && index > this.tokencacheeofindex) {
return token(this.tokencacheeofindex);
}
int length = this.tokencache.length;
if(index > this.tokencacheindex) {
int tokenstoread = index - this.tokencacheindex;
while(tokenstoread-- != 0) {
readtokenfromscanner();
}
} else if(this.tokencacheindex - length >= index) {
return null;
}

return this.tokencache[index % length];
}



public int gettoken() {
return this.currentindex = next(this.currentindex);
}

public int previous(int tokenindex) {
return tokenindex > 0 ? tokenindex - 1 : 0;
}

public int next(int tokenindex) {
return tokenindex < this.tokencacheeofindex ? tokenindex + 1 : this.tokencacheeofindex;
}

public boolean aftereol(int i) {
return i < 1 ? true : line(i - 1) < line(i);
}

public void reset() {
this.currentindex = -1;
}

public void reset(int i) {
this.currentindex = previous(i);
}

public int badtoken() {
return 0;
}

public int kind(int tokenindex) {
return token(tokenindex).kind;
}

public char[] name(int tokenindex) {
return token(tokenindex).name;
}

public int line(int tokenindex) {
return token(tokenindex).line;
}

public int start(int tokenindex) {
return token(tokenindex).start;
}

public int end(int tokenindex) {
return token(tokenindex).end;
}

public int flags(int tokenindex) {
return token(tokenindex).flags;
}

public boolean isinsidestream(int index) {
if(this.tokencacheeofindex >= 0 && index > this.tokencacheeofindex) {
return false;
} else if(index > this.tokencacheindex) {
return true;
} else if(this.tokencacheindex - this.tokencache.length >= index) {
return false;
} else {
return true;
}
}

/* (non-javadoc)
* @@see java.lang.object#tostring()
*/
public string tostring() {
stringbuffer res = new stringbuffer();

string source = new string(this.scanner.source);
if(this.currentindex < 0) {
int previousend = -1;
for (int i = 0; i < this.intervalstarttoskip.length; i++) {
int intervalstart = this.intervalstarttoskip[i];
int intervalend = this.intervalendtoskip[i];

res.append(source.substring(previousend + 1, intervalstart));
res.append('<');
res.append('@@');
res.append(source.substring(intervalstart, intervalend + 1));
res.append('@@');
res.append('>');

previousend = intervalend;
}
res.append(source.substring(previousend + 1));
} else {
token token = token(this.currentindex);
int curtokkind = token.kind;
int curtokstart = token.start;
int curtokend = token.end;

int previousend = -1;
for (int i = 0; i < this.intervalstarttoskip.length; i++) {
int intervalstart = this.intervalstarttoskip[i];
int intervalend = this.intervalendtoskip[i];

if(curtokstart >= previousend && curtokend <= intervalstart) {
res.append(source.substring(previousend + 1, curtokstart));
res.append('<');
res.append('#');
res.append(source.substring(curtokstart, curtokend + 1));
res.append('#');
res.append('>');
res.append(source.substring(curtokend+1, intervalstart));
} else {
res.append(source.substring(previousend + 1, intervalstart));
}
res.append('<');
res.append('@@');
res.append(source.substring(intervalstart, intervalend + 1));
res.append('@@');
res.append('>');

previousend = intervalend;
}
if(curtokstart >= previousend) {
res.append(source.substring(previousend + 1, curtokstart));
res.append('<');
res.append('#');
if(curtokkind == tokennameeof) {
res.append("eof#>"); //$non-nls-1$
} else {
res.append(source.substring(curtokstart, curtokend + 1));
res.append('#');
res.append('>');
res.append(source.substring(curtokend+1));
}
} else {
res.append(source.substring(previousend + 1));
}
}

return res.tostring();
}
}
