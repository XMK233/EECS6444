/*******************************************************************************
* copyright (c) 2004, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

import org.eclipse.jdt.internal.compiler.ast.expression;
import org.eclipse.jdt.internal.compiler.ast.membervaluepair;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;


public class selectiononnameofmembervaluepair extends membervaluepair {

public selectiononnameofmembervaluepair(char[] token, int sourcestart, int sourceend, expression value) {
super(token, sourcestart, sourceend, value);
}

public stringbuffer print(int indent, stringbuffer output) {
output.append("<selectonname:"); //$non-nls-1$
output.append(this.name);
output.append(">"); //$non-nls-1$
return output;
}

public void resolvetypeexpecting(blockscope scope, typebinding requiredtype) {
super.resolvetypeexpecting(scope, requiredtype);

if(this.binding != null) {
throw new selectionnodefound(this.binding);
}
throw new selectionnodefound();
}
}
