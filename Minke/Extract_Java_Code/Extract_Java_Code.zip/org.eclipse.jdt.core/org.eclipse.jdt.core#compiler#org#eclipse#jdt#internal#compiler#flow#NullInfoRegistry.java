/*******************************************************************************
* copyright (c) 2006, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;

/**
* a degenerate form of unconditionalflowinfo explicitly meant to capture
* the effects of null related operations within try blocks. given the fact
* that a try block might exit at any time, a null related operation that
* occurs within such a block mitigates whatever we know about the previous
* null status of involved variables. nullinforegistry handles that
* by negating upstream definite information that clashes with what a given
* statement contends about the same variable. it also implements
* {@@link #mitigatenullinfoof(flowinfo) mitigatenullinfo} so as to elaborate the
* flow info presented in input of finally blocks.
*/
public class nullinforegistry extends unconditionalflowinfo {
// significant states at this level:
// def. non null, def. null, def. unknown, prot. non null

// premature implement coverage and low level tests

/**
* make a new null info registry, using an upstream flow info. all definite
* assignments of the upstream are carried forward, since a try block may
* exit before its first statement.
* @@param upstream - unconditionalflowinfo: the flow info before we enter the
* 		try block; only definite assignments are considered; this parameter is
*  	not modified by this constructor
*/
public nullinforegistry(unconditionalflowinfo upstream) {
this.maxfieldcount = upstream.maxfieldcount;
if ((upstream.tagbits & null_flag_mask) != 0) {
long u1, u2, u3, u4, nu2, nu3, nu4;
this.nullbit2 = (u1 = upstream.nullbit1)
& (u2 = upstream.nullbit2)
& (nu3 = ~(u3 = upstream.nullbit3))
& (nu4 = ~(u4 = upstream.nullbit4));
this.nullbit3 =	u1 & (nu2 = ~u2) & u3 & nu4;
this.nullbit4 =	u1 & nu2 &nu3 & u4;
if ((this.nullbit2 | this.nullbit3 | this.nullbit4) != 0) {
this.tagbits |= null_flag_mask;
}
if (upstream.extra != null) {
this.extra = new long[extralength][];
int length = upstream.extra[2].length;
for (int i = 2; i < extralength; i++) {
this.extra[i] = new long[length];
}
for (int i = 0; i < length; i++) {
this.extra[2 + 1][i] = (u1 = upstream.extra[1 + 1][i])
& (u2 = upstream.extra[2 + 1][i])
& (nu3 = ~(u3 = upstream.extra[3 + 1][i]))
& (nu4 = ~(u4 = upstream.extra[4 + 1][i]));
this.extra[3 + 1][i] =	u1 & (nu2 = ~u2) & u3 & nu4;
this.extra[4 + 1][i] =	u1 & nu2 &nu3 & u4;
if ((this.extra[2 + 1][i] | this.extra[3 + 1][i] | this.extra[4 + 1][i]) != 0) {
this.tagbits |= null_flag_mask;
}
}
}
}
}

/**
* add the information held by another nullinforegistry instance to this,
* then return this.
* @@param other - nullinforegistry: the information to add to this
* @@return this, modified to carry the information held by other
*/
public nullinforegistry add(nullinforegistry other) {
if ((other.tagbits & null_flag_mask) == 0) {
return this;
}
this.tagbits |= null_flag_mask;
this.nullbit1 |= other.nullbit1;
this.nullbit2 |= other.nullbit2;
this.nullbit3 |= other.nullbit3;
this.nullbit4 |= other.nullbit4;
if (other.extra != null) {
if (this.extra == null) {
this.extra = new long[extralength][];
for (int i = 2, length = other.extra[2].length; i < extralength; i++) {
system.arraycopy(other.extra[i], 0,
(this.extra[i] = new long[length]), 0, length);
}
} else {
int length = this.extra[2].length, otherlength = other.extra[2].length;
if (otherlength > length) {
for (int i = 2; i < extralength; i++) {
system.arraycopy(this.extra[i], 0,
(this.extra[i] = new long[otherlength]), 0, length);
system.arraycopy(other.extra[i], length,
this.extra[i], length, otherlength - length);
}
} else if (otherlength < length) {
length = otherlength;
}
for (int i = 2; i < extralength; i++) {
for (int j = 0; j < length; j++) {
this.extra[i][j] |= other.extra[i][j];
}
}
}
}
return this;
}

public void markascomparedequaltononnull(localvariablebinding local) {
// protected from non-object locals in calling methods
if (this != dead_end) {
this.tagbits |= null_flag_mask;
int position;
// position is zero-based
if ((position = local.id + this.maxfieldcount) < bitcachesize) { // use bits
// set protected non null
this.nullbit1 |= (1l << position);
if (coverage_test_flag) {
if (coveragetestid == 290) {
this.nullbit1 = 0;
}
}
}
else {
// use extra vector
int vectorindex = (position / bitcachesize) - 1;
if (this.extra == null) {
int length = vectorindex + 1;
this.extra = new long[extralength][];
for (int j = 2; j < extralength; j++) {
this.extra[j] = new long[length];
}
}
else {
int oldlength; // might need to grow the arrays
if (vectorindex >= (oldlength = this.extra[2].length)) {
for (int j = 2; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
(this.extra[j] = new long[vectorindex + 1]), 0,
oldlength);
}
}
}
this.extra[2][vectorindex] |= (1l << (position % bitcachesize));
if (coverage_test_flag) {
if (coveragetestid == 300) {
this.extra[5][vectorindex] = ~0;
}
}
}
}
}

public void markasdefinitelynonnull(localvariablebinding local) {
// protected from non-object locals in calling methods
if (this != dead_end) {
this.tagbits |= null_flag_mask;
int position;
// position is zero-based
if ((position = local.id + this.maxfieldcount) < bitcachesize) { // use bits
// set assigned non null
this.nullbit3 |= (1l << position);
if (coverage_test_flag) {
if (coveragetestid == 290) {
this.nullbit1 = 0;
}
}
}
else {
// use extra vector
int vectorindex = (position / bitcachesize) - 1;
if (this.extra == null) {
int length = vectorindex + 1;
this.extra = new long[extralength][];
for (int j = 2; j < extralength; j++) {
this.extra[j] = new long[length];
}
}
else {
int oldlength; // might need to grow the arrays
if (vectorindex >= (oldlength = this.extra[2].length)) {
for (int j = 2; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
(this.extra[j] = new long[vectorindex + 1]), 0,
oldlength);
}
}
}
this.extra[4][vectorindex] |= (1l << (position % bitcachesize));
if (coverage_test_flag) {
if (coveragetestid == 300) {
this.extra[5][vectorindex] = ~0;
}
}
}
}
}
// premature consider ignoring extra 0 to 2 included - means a1 should not be used either
// premature project protected non null onto something else
public void markasdefinitelynull(localvariablebinding local) {
// protected from non-object locals in calling methods
if (this != dead_end) {
this.tagbits |= null_flag_mask;
int position;
// position is zero-based
if ((position = local.id + this.maxfieldcount) < bitcachesize) { // use bits
// set assigned null
this.nullbit2 |= (1l << position);
if (coverage_test_flag) {
if (coveragetestid == 290) {
this.nullbit1 = 0;
}
}
}
else {
// use extra vector
int vectorindex = (position / bitcachesize) - 1;
if (this.extra == null) {
int length = vectorindex + 1;
this.extra = new long[extralength][];
for (int j = 2; j < extralength; j++) {
this.extra[j] = new long[length];
}
}
else {
int oldlength; // might need to grow the arrays
if (vectorindex >= (oldlength = this.extra[2].length)) {
for (int j = 2; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
(this.extra[j] = new long[vectorindex + 1]), 0,
oldlength);
}
}
}
this.extra[3][vectorindex] |= (1l << (position % bitcachesize));
if (coverage_test_flag) {
if (coveragetestid == 300) {
this.extra[5][vectorindex] = ~0;
}
}
}
}
}

public void markasdefinitelyunknown(localvariablebinding local) {
// protected from non-object locals in calling methods
if (this != dead_end) {
this.tagbits |= null_flag_mask;
int position;
// position is zero-based
if ((position = local.id + this.maxfieldcount) < bitcachesize) { // use bits
// set assigned unknown
this.nullbit4 |= (1l << position);
if (coverage_test_flag) {
if (coveragetestid == 290) {
this.nullbit1 = 0;
}
}
}
else {
// use extra vector
int vectorindex = (position / bitcachesize) - 1;
if (this.extra == null) {
int length = vectorindex + 1;
this.extra = new long[extralength][];
for (int j = 2; j < extralength; j++) {
this.extra[j] = new long[length];
}
}
else {
int oldlength; // might need to grow the arrays
if (vectorindex >= (oldlength = this.extra[2].length)) {
for (int j = 2; j < extralength; j++) {
system.arraycopy(this.extra[j], 0,
(this.extra[j] = new long[vectorindex + 1]), 0,
oldlength);
}
}
}
this.extra[5][vectorindex] |= (1l << (position % bitcachesize));
if (coverage_test_flag) {
if (coveragetestid == 300) {
this.extra[5][vectorindex] = ~0;
}
}
}
}
}

/**
* mitigate the definite and protected info of flowinfo, depending on what
* this null info registry knows about potential assignments and messages
* sends involving locals. may return flowinfo unchanged, or a modified,
* fresh copy of flowinfo.
* @@param flowinfo - flowinfo: the flow information that this null info
* 		registry may mitigate
* @@return a copy of flowinfo carrying mitigated information, or else
* 		flowinfo unchanged
*/
public unconditionalflowinfo mitigatenullinfoof(flowinfo flowinfo) {
if ((this.tagbits & null_flag_mask) == 0) {
return flowinfo.unconditionalinits();
}
long m, m1, nm1, m2, nm2, m3, a2, a3, a4, s1, s2, ns2, s3, ns3, s4, ns4;
boolean newcopy = false;
unconditionalflowinfo source = flowinfo.unconditionalinits();
// clear incompatible protections
m1 = (s1 = source.nullbit1) & (s3 = source.nullbit3)
& (s4 = source.nullbit4)
// prot. non null
& ((a2 = this.nullbit2) | (a4 = this.nullbit4));
// null or unknown
m2 = s1 & (s2 = this.nullbit2) & (s3 ^ s4)
// prot. null
& ((a3 = this.nullbit3) | a4);
// non null or unknown
// clear incompatible assignments
// premature check effect of protected non null (no npe on call)
// todo (maxime) code extensive implementation tests
m3 = s1	& (s2 & (ns3 = ~s3) & (ns4 = ~s4) & (a3 | a4)
| (ns2 = ~s2) & s3 & ns4 & (a2 | a4)
| ns2 & ns3 & s4 & (a2 | a3));
if ((m = (m1 | m2 | m3)) != 0) {
newcopy = true;
source = source.unconditionalcopy();
source.nullbit1 &= ~m;
source.nullbit2 &= (nm1 = ~m1) & ((nm2 = ~m2) | a4);
source.nullbit3 &= (nm1 | a2) & nm2;
source.nullbit4 &= nm1 & nm2;
}
if (this.extra != null && source.extra != null) {
int length = this.extra[2].length, sourcelength = source.extra[0].length;
if (sourcelength < length) {
length = sourcelength;
}
for (int i = 0; i < length; i++) {
m1 = (s1 = source.extra[1 + 1][i]) & (s3 = source.extra[3 + 1][i])
& (s4 = source.extra[4 + 1][i])
& ((a2 = this.extra[2 + 1][i]) | (a4 = this.extra[4 + 1][i]));
m2 = s1 & (s2 = this.extra[2 + 1][i]) & (s3 ^ s4)
& ((a3 = this.extra[3 + 1][i]) | a4);
m3 = s1	& (s2 & (ns3 = ~s3) & (ns4 = ~s4) & (a3 | a4)
| (ns2 = ~s2) & s3 & ns4 & (a2 | a4)
| ns2 & ns3 & s4 & (a2 | a3));
if ((m = (m1 | m2 | m3)) != 0) {
if (! newcopy) {
newcopy = true;
source = source.unconditionalcopy();
}
source.extra[1 + 1][i] &= ~m;
source.extra[2 + 1][i] &= (nm1 = ~m1) & ((nm2 = ~m2) | a4);
source.extra[3 + 1][i] &= (nm1 | a2) & nm2;
source.extra[4 + 1][i] &= nm1 & nm2;
}
}
}
return source;
}

public string tostring(){
if (this.extra == null) {
return "nullinforegistry<" + this.nullbit1 //$non-nls-1$
+ this.nullbit2 + this.nullbit3 + this.nullbit4
+ ">"; //$non-nls-1$
}
else {
string nulls = "nullinforegistry<[" + this.nullbit1 //$non-nls-1$
+ this.nullbit2 + this.nullbit3 + this.nullbit4;
int i, ceil;
for (i = 0, ceil = this.extra[0].length > 3 ?
3 :
this.extra[0].length;
i < ceil; i++) {
nulls += "," + this.extra[2][i] //$non-nls-1$
+ this.extra[3][i] + this.extra[4][i] + this.extra[5][i];
}
if (ceil < this.extra[0].length) {
nulls += ",..."; //$non-nls-1$
}
return nulls + "]>"; //$non-nls-1$
}
}
}

