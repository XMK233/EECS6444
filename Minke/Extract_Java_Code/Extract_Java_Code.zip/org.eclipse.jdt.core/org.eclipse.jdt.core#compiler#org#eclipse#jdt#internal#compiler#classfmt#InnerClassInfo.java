/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

import org.eclipse.jdt.internal.compiler.env.ibinarynestedtype;

/**
* describes one entry in the classes table of the innerclasses attribute.
* see the inner class specification (the class file attribute "innerclasses").
*/

public class innerclassinfo extends classfilestruct implements ibinarynestedtype {
int innerclassnameindex = -1;
int outerclassnameindex = -1;
int innernameindex = -1;
private char[] innerclassname;
private char[] outerclassname;
private char[] innername;
private int accessflags = -1;
private boolean readinnerclassname = false;
private boolean readouterclassname = false;
private boolean readinnername = false;

public innerclassinfo(byte classfilebytes[], int offsets[], int offset) {
super(classfilebytes, offsets, offset);
this.innerclassnameindex = u2at(0);
this.outerclassnameindex = u2at(2);
this.innernameindex = u2at(4);
}
/**
* answer the resolved name of the enclosing type in the
* class file format as specified in section 4.2 of the java 2 vm spec.
*
* for example, java.lang.string is java/lang/string.
* @@return char[]
*/
public char[] getenclosingtypename() {
if (!this.readouterclassname) {
// read outer class name
this.readouterclassname = true;
if (this.outerclassnameindex != 0) {
int utf8offset =
this.constantpooloffsets[u2at(
this.constantpooloffsets[this.outerclassnameindex] - this.structoffset + 1)]
- this.structoffset;
this.outerclassname = utf8at(utf8offset + 3, u2at(utf8offset + 1));
}

}
return this.outerclassname;
}
/**
* answer an int whose bits are set according the access constants
* defined by the vm spec.
* @@return int
*/
public int getmodifiers() {
if (this.accessflags == -1) {
// read access flag
this.accessflags = u2at(6);
}
return this.accessflags;
}
/**
* answer the resolved name of the member type in the
* class file format as specified in section 4.2 of the java 2 vm spec.
*
* for example, p1.p2.a.m is p1/p2/a$m.
* @@return char[]
*/
public char[] getname() {
if (!this.readinnerclassname) {
// read the inner class name
this.readinnerclassname = true;
if (this.innerclassnameindex != 0) {
int  classoffset = this.constantpooloffsets[this.innerclassnameindex] - this.structoffset;
int utf8offset = this.constantpooloffsets[u2at(classoffset + 1)] - this.structoffset;
this.innerclassname = utf8at(utf8offset + 3, u2at(utf8offset + 1));
}
}
return this.innerclassname;
}
/**
* answer the source name of the member type.
*
* for example, p1.p2.a.m is m.
* @@return char[]
*/
public char[] getsourcename() {
if (!this.readinnername) {
this.readinnername = true;
if (this.innernameindex != 0) {
int utf8offset = this.constantpooloffsets[this.innernameindex] - this.structoffset;
this.innername = utf8at(utf8offset + 3, u2at(utf8offset + 1));
}
}
return this.innername;
}
/**
* answer the string representation of the receiver
* @@return java.lang.string
*/
public string tostring() {
stringbuffer buffer = new stringbuffer();
if (getname() != null) {
buffer.append(getname());
}
buffer.append("\n"); //$non-nls-1$
if (getenclosingtypename() != null) {
buffer.append(getenclosingtypename());
}
buffer.append("\n"); //$non-nls-1$
if (getsourcename() != null) {
buffer.append(getsourcename());
}
return buffer.tostring();
}
/**
* this method is used to fully initialize the contents of the receiver. all methodinfos, fields infos
* will be therefore fully initialized and we can get rid of the bytes.
*/
void initialize() {
getmodifiers();
getname();
getsourcename();
getenclosingtypename();
reset();
}
}
