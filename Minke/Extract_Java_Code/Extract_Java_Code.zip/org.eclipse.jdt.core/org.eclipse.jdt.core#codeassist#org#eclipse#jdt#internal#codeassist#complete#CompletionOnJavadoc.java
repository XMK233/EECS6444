/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

public interface completiononjavadoc {

// bit pattern for javadoc completion flags
int javadoc = 0x0001;
int exception = 0x0002;
int text = 0x0004;
int base_types = 0x0008;
int only_inline_tag = 0x0010;
int replace_tag = 0x0020;
int formal_reference = 0x0040;
int all_possible_tags = 0x0080;

/**
* get completion node flags.
*
* @@return int flags of the javadoc completion node.
*/
public int getcompletionflags();

/**
* @@param flags the completionflags to add.
*/
public void addcompletionflags(int flags);

}
