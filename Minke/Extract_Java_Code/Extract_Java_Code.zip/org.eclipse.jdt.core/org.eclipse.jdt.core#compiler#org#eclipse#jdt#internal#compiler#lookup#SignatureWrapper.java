/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;

public class signaturewrapper {
public char[] signature;
public int start;
public int end;
public int bracket;

public signaturewrapper(char[] signature) {
this.signature = signature;
this.start = 0;
this.end = this.bracket = -1;
}
public boolean atend() {
return this.start < 0 || this.start >= this.signature.length;
}
public int computeend() {
int index = this.start;
while (this.signature[index] == '[')
index++;
switch (this.signature[index]) {
case 'l' :
case 't' :
this.end = charoperation.indexof(';', this.signature, this.start);
if (this.bracket <= this.start) // already know it if its > start
this.bracket = charoperation.indexof('<', this.signature, this.start);

if (this.bracket > this.start && this.bracket < this.end)
this.end = this.bracket;
else if (this.end == -1)
this.end = this.signature.length + 1;
break;
default :
this.end = this.start;
}

this.start = this.end + 1; // skip ';'
return this.end;
}
public char[] nextword() {
this.end = charoperation.indexof(';', this.signature, this.start);
if (this.bracket <= this.start) // already know it if its > start
this.bracket = charoperation.indexof('<', this.signature, this.start);
int dot = charoperation.indexof('.', this.signature, this.start);

if (this.bracket > this.start && this.bracket < this.end)
this.end = this.bracket;
if (dot > this.start && dot < this.end)
this.end = dot;

return charoperation.subarray(this.signature, this.start, this.start = this.end); // skip word
}
public string tostring() {
return new string(this.signature) + " @@ " + this.start; //$non-nls-1$
}
}
