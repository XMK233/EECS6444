/*******************************************************************************
* copyright (c) 2004, 2006 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

/**
* @@deprecated use {@@link org.eclipse.jdt.core.completionrequestor} instead
*/
//todo remove this class once no more clients
public interface iextendedcompletionrequestor extends org.eclipse.jdt.core.icompletionrequestor {
void acceptpotentialmethoddeclaration(
char[] declaringtypepackagename,
char[] declaringtypename,
char[] selector,
int completionstart,
int completionend,
int relevance);
}
