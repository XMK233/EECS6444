/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.ast.typereference;

public class selectiononfieldtype extends fielddeclaration {
public selectiononfieldtype(typereference type) {
super();
this.sourcestart = type.sourcestart;
this.sourceend = type.sourceend;
this.type = type;
this.name = charoperation.no_char;
}
public stringbuffer printstatement(int tab, stringbuffer output) {
return this.type.print(tab, output).append(';');
}
}
