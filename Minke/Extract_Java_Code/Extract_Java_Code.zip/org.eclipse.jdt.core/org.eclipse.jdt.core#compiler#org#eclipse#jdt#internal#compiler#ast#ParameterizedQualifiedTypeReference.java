/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

/**
* syntactic representation of a reference to a generic type.
* note that it might also have a dimension.
*/
public class parameterizedqualifiedtypereference extends arrayqualifiedtypereference {

public typereference[][] typearguments;

/**
* @@param tokens
* @@param dim
* @@param positions
*/
public parameterizedqualifiedtypereference(char[][] tokens, typereference[][] typearguments, int dim, long[] positions) {

super(tokens, dim, positions);
this.typearguments = typearguments;
}
public void checkbounds(scope scope) {
if (this.resolvedtype == null) return;

checkbounds(
(referencebinding) this.resolvedtype.leafcomponenttype(),
scope,
this.typearguments.length - 1);
}
public void checkbounds(referencebinding type, scope scope, int index) {
// recurse on enclosing type if any, and assuming explictly  part of the reference (index>0)
if (index > 0 &&  type.enclosingtype() != null) {
checkbounds(type.enclosingtype(), scope, index - 1);
}
if (type.isparameterizedtypewithactualarguments()) {
parameterizedtypebinding parameterizedtype = (parameterizedtypebinding) type;
referencebinding currenttype = parameterizedtype.generictype();
typevariablebinding[] typevariables = currenttype.typevariables();
if (typevariables != null) { // argtypes may be null in error cases
parameterizedtype.boundcheck(scope, this.typearguments[index]);
}
}
}
public typereference copydims(int dim){
return new parameterizedqualifiedtypereference(this.tokens, this.typearguments, dim, this.sourcepositions);
}

/**
* @@return char[][]
*/
public char [][] getparameterizedtypename(){
int length = this.tokens.length;
char[][] qparamname = new char[length][];
for (int i = 0; i < length; i++) {
typereference[] arguments = this.typearguments[i];
if (arguments == null) {
qparamname[i] = this.tokens[i];
} else {
stringbuffer buffer = new stringbuffer(5);
buffer.append(this.tokens[i]);
buffer.append('<');
for (int j = 0, arglength =arguments.length; j < arglength; j++) {
if (j > 0) buffer.append(',');
buffer.append(charoperation.concatwith(arguments[j].getparameterizedtypename(), '.'));
}
buffer.append('>');
int namelength = buffer.length();
qparamname[i] = new char[namelength];
buffer.getchars(0, namelength, qparamname[i], 0);
}
}
int dim = this.dimensions;
if (dim > 0) {
char[] dimchars = new char[dim*2];
for (int i = 0; i < dim; i++) {
int index = i*2;
dimchars[index] = '[';
dimchars[index+1] = ']';
}
qparamname[length-1] = charoperation.concat(qparamname[length-1], dimchars);
}
return qparamname;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.arrayqualifiedtypereference#gettypebinding(org.eclipse.jdt.internal.compiler.lookup.scope)
*/
protected typebinding gettypebinding(scope scope) {
return null; // not supported here - combined with resolvetype(...)
}

/*
* no need to check for reference to raw type per construction
*/
private typebinding internalresolvetype(scope scope, boolean checkbounds) {
// handle the error here
this.constant = constant.notaconstant;
if ((this.bits & astnode.didresolve) != 0) { // is a shared type reference which was already resolved
if (this.resolvedtype != null) { // is a shared type reference which was already resolved
if (this.resolvedtype.isvalidbinding()) {
return this.resolvedtype;
} else {
switch (this.resolvedtype.problemid()) {
case problemreasons.notfound :
case problemreasons.notvisible :
case problemreasons.inheritednamehidesenclosingname :
typebinding type = this.resolvedtype.closestmatch();
return type;
default :
return null;
}
}
}
}
this.bits |= astnode.didresolve;
boolean isclassscope = scope.kind == scope.class_scope;
binding binding = scope.getpackage(this.tokens);
if (binding != null && !binding.isvalidbinding()) {
this.resolvedtype = (referencebinding) binding;
reportinvalidtype(scope);
// be resilient, still attempt resolving arguments
for (int i = 0, max = this.tokens.length; i < max; i++) {
typereference[] args = this.typearguments[i];
if (args != null) {
int arglength = args.length;
for (int j = 0; j < arglength; j++) {
typereference typeargument = args[j];
if (isclassscope) {
typeargument.resolvetype((classscope) scope);
} else {
typeargument.resolvetype((blockscope) scope, checkbounds);
}
}
}
}
return null;
}

packagebinding packagebinding = binding == null ? null : (packagebinding) binding;
boolean typeisconsistent = true;
referencebinding qualifyingtype = null;
for (int i = packagebinding == null ? 0 : packagebinding.compoundname.length, max = this.tokens.length; i < max; i++) {
findnexttypebinding(i, scope, packagebinding);
if (!(this.resolvedtype.isvalidbinding())) {
reportinvalidtype(scope);
// be resilient, still attempt resolving arguments
for (int j = i; j < max; j++) {
typereference[] args = this.typearguments[j];
if (args != null) {
int arglength = args.length;
for (int k = 0; k < arglength; k++) {
typereference typeargument = args[k];
if (isclassscope) {
typeargument.resolvetype((classscope) scope);
} else {
typeargument.resolvetype((blockscope) scope);
}
}
}
}
return null;
}
referencebinding currenttype = (referencebinding) this.resolvedtype;
if (qualifyingtype == null) {
qualifyingtype = currenttype.enclosingtype(); // if member type
if (qualifyingtype != null) {
qualifyingtype = currenttype.isstatic()
? (referencebinding) scope.environment().converttorawtype(qualifyingtype, false /*do not force conversion of enclosing types*/)
: scope.environment().converttoparameterizedtype(qualifyingtype);
}
} else {
if (typeisconsistent && currenttype.isstatic()
&& (qualifyingtype.isparameterizedtypewithactualarguments() || qualifyingtype.isgenerictype())) {
scope.problemreporter().staticmemberofparameterizedtype(this, scope.environment().createparameterizedtype((referencebinding)currenttype.erasure(), null, qualifyingtype), i);
typeisconsistent = false;
}
referencebinding enclosingtype = currenttype.enclosingtype();
if (enclosingtype != null && enclosingtype.erasure() != qualifyingtype.erasure()) { // qualifier != declaring/enclosing
qualifyingtype = enclosingtype; // inherited member type, leave it associated with its enclosing rather than subtype
}
}

// check generic and arity
typereference[] args = this.typearguments[i];
if (args != null) {
typereference keep = null;
if (isclassscope) {
keep = ((classscope) scope).supertypereference;
((classscope) scope).supertypereference = null;
}
int arglength = args.length;
typebinding[] argtypes = new typebinding[arglength];
boolean arghaserror = false;
referencebinding currentoriginal = (referencebinding)currenttype.original();
for (int j = 0; j < arglength; j++) {
typereference arg = args[j];
typebinding argtype = isclassscope
? arg.resolvetypeargument((classscope) scope, currentoriginal, j)
: arg.resolvetypeargument((blockscope) scope, currentoriginal, j);
if (argtype == null) {
arghaserror = true;
} else {
argtypes[j] = argtype;
}
}
if (arghaserror) {
return null;
}
if (isclassscope) {
((classscope) scope).supertypereference = keep;
if (((classscope) scope).detecthierarchycycle(currentoriginal, this))
return null;
}

typevariablebinding[] typevariables = currentoriginal.typevariables();
if (typevariables == binding.no_type_variables) { // check generic
if (scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5) { // below 1.5, already reported as syntax error
scope.problemreporter().nongenerictypecannotbeparameterized(i, this, currenttype, argtypes);
return null;
}
this.resolvedtype =  (qualifyingtype != null && qualifyingtype.isparameterizedtype())
? scope.environment().createparameterizedtype(currentoriginal, null, qualifyingtype)
: currenttype;
if (this.dimensions > 0) {
if (this.dimensions > 255)
scope.problemreporter().toomanydimensions(this);
this.resolvedtype = scope.createarraytype(this.resolvedtype, this.dimensions);
}
return this.resolvedtype;
} else if (arglength != typevariables.length) { // check arity
scope.problemreporter().incorrectarityforparameterizedtype(this, currenttype, argtypes, i);
return null;
}
// check parameterizing non-static member type of raw type
if (typeisconsistent && !currenttype.isstatic()) {
referencebinding actualenclosing = currenttype.enclosingtype();
if (actualenclosing != null && actualenclosing.israwtype()) {
scope.problemreporter().rawmembertypecannotbeparameterized(
this, scope.environment().createrawtype(currentoriginal, actualenclosing), argtypes);
typeisconsistent = false;
}
}
parameterizedtypebinding parameterizedtype = scope.environment().createparameterizedtype(currentoriginal, argtypes, qualifyingtype);
// check argument type compatibility
if (checkbounds) // otherwise will do it in scope.connecttypevariables() or generic method resolution
parameterizedtype.boundcheck(scope, args);
else
scope.deferboundcheck(this);
qualifyingtype = parameterizedtype;
} else {
referencebinding currentoriginal = (referencebinding)currenttype.original();
if (isclassscope)
if (((classscope) scope).detecthierarchycycle(currentoriginal, this))
return null;
if (currentoriginal.isgenerictype()) {
if (typeisconsistent && qualifyingtype != null && qualifyingtype.isparameterizedtype()) {
scope.problemreporter().parameterizedmembertypemissingarguments(this, scope.environment().createparameterizedtype(currentoriginal, null, qualifyingtype), i);
typeisconsistent = false;
}
qualifyingtype = scope.environment().createrawtype(currentoriginal, qualifyingtype); // raw type
} else {
qualifyingtype = (qualifyingtype != null && qualifyingtype.isparameterizedtype())
? scope.environment().createparameterizedtype(currentoriginal, null, qualifyingtype)
: currenttype;
}
}
if (istypeusedeprecated(qualifyingtype, scope))
reportdeprecatedtype(qualifyingtype, scope, i);
this.resolvedtype = qualifyingtype;
}
// array type ?
if (this.dimensions > 0) {
if (this.dimensions > 255)
scope.problemreporter().toomanydimensions(this);
this.resolvedtype = scope.createarraytype(this.resolvedtype, this.dimensions);
}
return this.resolvedtype;
}

public stringbuffer printexpression(int indent, stringbuffer output) {
int length = this.tokens.length;
for (int i = 0; i < length - 1; i++) {
output.append(this.tokens[i]);
typereference[] typeargument = this.typearguments[i];
if (typeargument != null) {
output.append('<');
int max = typeargument.length - 1;
for (int j = 0; j < max; j++) {
typeargument[j].print(0, output);
output.append(", ");//$non-nls-1$
}
typeargument[max].print(0, output);
output.append('>');
}
output.append('.');
}
output.append(this.tokens[length - 1]);
typereference[] typeargument = this.typearguments[length - 1];
if (typeargument != null) {
output.append('<');
int max = typeargument.length - 1;
for (int j = 0; j < max; j++) {
typeargument[j].print(0, output);
output.append(", ");//$non-nls-1$
}
typeargument[max].print(0, output);
output.append('>');
}
if ((this.bits & isvarargs) != 0) {
for (int i= 0 ; i < this.dimensions - 1; i++) {
output.append("[]"); //$non-nls-1$
}
output.append("..."); //$non-nls-1$
} else {
for (int i= 0 ; i < this.dimensions; i++) {
output.append("[]"); //$non-nls-1$
}
}
return output;
}

public typebinding resolvetype(blockscope scope, boolean checkbounds) {
return internalresolvetype(scope, checkbounds);
}
public typebinding resolvetype(classscope scope) {
return internalresolvetype(scope, false);
}
public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
for (int i = 0, max = this.typearguments.length; i < max; i++) {
if (this.typearguments[i] != null) {
for (int j = 0, max2 = this.typearguments[i].length; j < max2; j++) {
this.typearguments[i][j].traverse(visitor, scope);
}
}
}
}
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {
if (visitor.visit(this, scope)) {
for (int i = 0, max = this.typearguments.length; i < max; i++) {
if (this.typearguments[i] != null) {
for (int j = 0, max2 = this.typearguments[i].length; j < max2; j++) {
this.typearguments[i][j].traverse(visitor, scope);
}
}
}
}
visitor.endvisit(this, scope);
}

}
