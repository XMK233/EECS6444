/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.javadoctagconstants;

/**
* node representing a structured javadoc comment
*/
public class javadoc extends astnode {

public javadocsinglenamereference[] paramreferences; // @@param
public javadocsingletypereference[] paramtypeparameters; // @@param
public typereference[] exceptionreferences; // @@throws, @@exception
public javadocreturnstatement returnstatement; // @@return
public expression[] seereferences; // @@see
public long[] inheritedpositions = null;
// bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=51600
// store param references for tag with invalid syntax
public javadocsinglenamereference[] invalidparameters; // @@param
// bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=153399
// store value tag positions
public long valuepositions = -1;

public javadoc(int sourcestart, int sourceend) {
this.sourcestart = sourcestart;
this.sourceend = sourceend;
}
/**
* returns whether a type can be seen at a given visibility level or not.
*
* @@param visibility level of visiblity allowed to see references
* @@param modifiers modifiers of java element to be seen
* @@return true if the type can be seen, false otherwise
*/
boolean canbeseen(int visibility, int modifiers) {
if (modifiers < 0) return true;
switch (modifiers & extracompilermodifiers.accvisibilitymask) {
case classfileconstants.accpublic :
return true;
case classfileconstants.accprotected:
return (visibility != classfileconstants.accpublic);
case classfileconstants.accdefault:
return (visibility == classfileconstants.accdefault || visibility == classfileconstants.accprivate);
case classfileconstants.accprivate:
return (visibility == classfileconstants.accprivate);
}
return true;
}

/*
* search node with a given staring position in javadoc objects arrays.
*/
public astnode getnodestartingat(int start) {
int length = 0;
// parameters array
if (this.paramreferences != null) {
length = this.paramreferences.length;
for (int i=0; i<length; i++) {
javadocsinglenamereference param = this.paramreferences[i];
if (param.sourcestart==start) {
return param;
}
}
}
// array of invalid syntax tags parameters
if (this.invalidparameters != null) {
length = this.invalidparameters.length;
for (int i=0; i<length; i++) {
javadocsinglenamereference param = this.invalidparameters[i];
if (param.sourcestart==start) {
return param;
}
}
}
// type parameters array
if (this.paramtypeparameters != null) {
length = this.paramtypeparameters.length;
for (int i=0; i<length; i++) {
javadocsingletypereference param = this.paramtypeparameters[i];
if (param.sourcestart==start) {
return param;
}
}
}
// thrown exception array
if (this.exceptionreferences != null) {
length = this.exceptionreferences.length;
for (int i=0; i<length; i++) {
typereference typeref = this.exceptionreferences[i];
if (typeref.sourcestart==start) {
return typeref;
}
}
}
// references array
if (this.seereferences != null) {
length = this.seereferences.length;
for (int i=0; i<length; i++) {
org.eclipse.jdt.internal.compiler.ast.expression expression = this.seereferences[i];
if (expression.sourcestart==start) {
return expression;
} else if (expression instanceof javadocallocationexpression) {
javadocallocationexpression allocationexpr = (javadocallocationexpression) this.seereferences[i];
// if binding is valid then look at arguments
if (allocationexpr.binding != null && allocationexpr.binding.isvalidbinding()) {
if (allocationexpr.arguments != null) {
for (int j=0, l=allocationexpr.arguments.length; j<l; j++) {
if (allocationexpr.arguments[j].sourcestart == start) {
return allocationexpr.arguments[j];
}
}
}
}
} else if (expression instanceof javadocmessagesend) {
javadocmessagesend messagesend = (javadocmessagesend) this.seereferences[i];
// if binding is valid then look at arguments
if (messagesend.binding != null && messagesend.binding.isvalidbinding()) {
if (messagesend.arguments != null) {
for (int j=0, l=messagesend.arguments.length; j<l; j++) {
if (messagesend.arguments[j].sourcestart == start) {
return messagesend.arguments[j];
}
}
}
}
}
}
}
return null;
}

/*
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#print(int, java.lang.stringbuffer)
*/
public stringbuffer print(int indent, stringbuffer output) {
printindent(indent, output).append("/**\n"); //$non-nls-1$
if (this.paramreferences != null) {
for (int i = 0, length = this.paramreferences.length; i < length; i++) {
printindent(indent + 1, output).append(" * @@param "); //$non-nls-1$
this.paramreferences[i].print(indent, output).append('\n');
}
}
if (this.paramtypeparameters != null) {
for (int i = 0, length = this.paramtypeparameters.length; i < length; i++) {
printindent(indent + 1, output).append(" * @@param <"); //$non-nls-1$
this.paramtypeparameters[i].print(indent, output).append(">\n"); //$non-nls-1$
}
}
if (this.returnstatement != null) {
printindent(indent + 1, output).append(" * @@"); //$non-nls-1$
this.returnstatement.print(indent, output).append('\n');
}
if (this.exceptionreferences != null) {
for (int i = 0, length = this.exceptionreferences.length; i < length; i++) {
printindent(indent + 1, output).append(" * @@throws "); //$non-nls-1$
this.exceptionreferences[i].print(indent, output).append('\n');
}
}
if (this.seereferences != null) {
for (int i = 0, length = this.seereferences.length; i < length; i++) {
printindent(indent + 1, output).append(" * @@see "); //$non-nls-1$
this.seereferences[i].print(indent, output).append('\n');
}
}
printindent(indent, output).append(" */\n"); //$non-nls-1$
return output;
}

/*
* resolve type javadoc
*/
public void resolve(classscope scope) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=247037, @@inheritdoc tag cannot
// be used in the documentation comment for a class or interface.
if (this.inheritedpositions != null) {
int length = this.inheritedpositions.length;
for (int i = 0; i < length; ++i) {
int start = (int) (this.inheritedpositions[i] >>> 32);
int end = (int) this.inheritedpositions[i];
scope.problemreporter().javadocunexpectedtag(start, end);
}
}
// @@param tags
int paramtagssize = this.paramreferences == null ? 0 : this.paramreferences.length;
for (int i = 0; i < paramtagssize; i++) {
javadocsinglenamereference param = this.paramreferences[i];
scope.problemreporter().javadocunexpectedtag(param.tagsourcestart, param.tagsourceend);
}
resolvetypeparametertags(scope, true);

// @@return tags
if (this.returnstatement != null) {
scope.problemreporter().javadocunexpectedtag(this.returnstatement.sourcestart, this.returnstatement.sourceend);
}

// @@throws/@@exception tags
int throwstagslength = this.exceptionreferences == null ? 0 : this.exceptionreferences.length;
for (int i = 0; i < throwstagslength; i++) {
typereference typeref = this.exceptionreferences[i];
int start, end;
if (typeref instanceof javadocsingletypereference) {
javadocsingletypereference singleref = (javadocsingletypereference) typeref;
start = singleref.tagsourcestart;
end = singleref.tagsourceend;
} else if (typeref instanceof javadocqualifiedtypereference) {
javadocqualifiedtypereference qualifiedref = (javadocqualifiedtypereference) typeref;
start = qualifiedref.tagsourcestart;
end = qualifiedref.tagsourceend;
} else {
start = typeref.sourcestart;
end = typeref.sourceend;
}
scope.problemreporter().javadocunexpectedtag(start, end);
}

// @@see tags
int seetagslength = this.seereferences == null ? 0 : this.seereferences.length;
for (int i = 0; i < seetagslength; i++) {
resolvereference(this.seereferences[i], scope);
}

// @@value tag
boolean source15 = scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
if (!source15 && this.valuepositions != -1) {
scope.problemreporter().javadocunexpectedtag((int)(this.valuepositions>>>32), (int) this.valuepositions);
}
}

/*
* resolve compilation unit javadoc
*/
public void resolve(compilationunitscope unitscope) {
// do nothing - this is to mimic the sdk's javadoc tool behavior, which neither
// sanity checks nor generates documentation using comments at the cu scope
// (unless the unit happens to be package-info.java - in which case we don't come here.)
}

/*
* resolve method javadoc
*/
public void resolve(methodscope methscope) {

// get method declaration
abstractmethoddeclaration methdecl = methscope.referencemethod();
boolean overriding = methdecl == null /* field declaration */ || methdecl.binding == null /* compiler error */
? false :
!methdecl.binding.isstatic() && ((methdecl.binding.modifiers & (extracompilermodifiers.accimplementing | extracompilermodifiers.accoverriding)) != 0);

// @@see tags
int seetagslength = this.seereferences == null ? 0 : this.seereferences.length;
boolean superref = false;
for (int i = 0; i < seetagslength; i++) {

// resolve reference
resolvereference(this.seereferences[i], methscope);

// see whether we can have a super reference
if (methdecl != null && !superref) {
if (!methdecl.isconstructor()) {
if (overriding && this.seereferences[i] instanceof javadocmessagesend) {
javadocmessagesend messagesend = (javadocmessagesend) this.seereferences[i];
// if binding is valid then look if we have a reference to an overriden method/constructor
if (messagesend.binding != null && messagesend.binding.isvalidbinding() && messagesend.actualreceivertype instanceof referencebinding) {
referencebinding methodreceivertype = (referencebinding) messagesend.actualreceivertype;
typebinding supertype = methdecl.binding.declaringclass.findsupertypeoriginatingfrom(methodreceivertype);
if (supertype != null && supertype.original() != methdecl.binding.declaringclass && charoperation.equals(messagesend.selector, methdecl.selector)) {
if (methscope.environment().methodverifier().doesmethodoverride(methdecl.binding, messagesend.binding.original())) {
superref = true;
}
}
}
}
} else if (this.seereferences[i] instanceof javadocallocationexpression) {
javadocallocationexpression allocationexpr = (javadocallocationexpression) this.seereferences[i];
// if binding is valid then look if we have a reference to an overriden method/constructor
if (allocationexpr.binding != null && allocationexpr.binding.isvalidbinding()) {
referencebinding alloctype = (referencebinding) allocationexpr.resolvedtype.original();
referencebinding supertype = (referencebinding) methdecl.binding.declaringclass.findsupertypeoriginatingfrom(alloctype);
if (supertype != null && supertype.original() != methdecl.binding.declaringclass) {
methodbinding superconstructor = methscope.getconstructor(supertype, methdecl.binding.parameters, allocationexpr);
if (superconstructor.isvalidbinding() && superconstructor.original() == allocationexpr.binding.original()) {
if (superconstructor.areparametersequal(methdecl.binding)) {
superref = true;
}
}
}
}
}
}
}

// look at @@override annotations
if (!superref && methdecl != null && methdecl.annotations != null) {
int length = methdecl.annotations.length;
for (int i=0; i<length && !superref; i++) {
superref = (methdecl.binding.tagbits & tagbits.annotationoverride) != 0;
}
}

// store if a reference exists to an overriden method/constructor or the method is in a local type,
boolean reportmissing = methdecl == null || !((overriding && this.inheritedpositions != null) || superref || (methdecl.binding.declaringclass != null && methdecl.binding.declaringclass.islocaltype()));
if (!overriding && this.inheritedpositions != null) {
int length = this.inheritedpositions.length;
for (int i = 0; i < length; ++i) {
int start = (int) (this.inheritedpositions[i] >>> 32);
int end = (int) this.inheritedpositions[i];
methscope.problemreporter().javadocunexpectedtag(start, end);
}
}

// @@param tags
compileroptions compileroptions = methscope.compileroptions();
resolveparamtags(methscope, reportmissing, compileroptions.reportunusedparameterincludedoccommentreference /* considerparamrefasusage*/);
resolvetypeparametertags(methscope, reportmissing);

// @@return tags
if (this.returnstatement == null) {
if (reportmissing && methdecl != null) {
if (methdecl.ismethod()) {
methoddeclaration meth = (methoddeclaration) methdecl;
if (meth.binding.returntype != typebinding.void) {
// method with return should have @@return tag
methscope.problemreporter().javadocmissingreturntag(meth.returntype.sourcestart, meth.returntype.sourceend, methdecl.binding.modifiers);
}
}
}
} else {
this.returnstatement.resolve(methscope);
}

// @@throws/@@exception tags
resolvethrowstags(methscope, reportmissing);

// @@value tag
boolean source15 = compileroptions.sourcelevel >= classfileconstants.jdk1_5;
if (!source15 && methdecl != null && this.valuepositions != -1) {
methscope.problemreporter().javadocunexpectedtag((int)(this.valuepositions>>>32), (int) this.valuepositions);
}

// resolve param tags with invalid syntax
int length = this.invalidparameters == null ? 0 : this.invalidparameters.length;
for (int i = 0; i < length; i++) {
this.invalidparameters[i].resolve(methscope, false, false);
}
}

private void resolvereference(expression reference, scope scope) {

// perform resolve
int problemcount = scope.referencecontext().compilationresult().problemcount;
switch (scope.kind) {
case scope.method_scope:
reference.resolvetype((methodscope)scope);
break;
case scope.class_scope:
reference.resolvetype((classscope)scope);
break;
}
boolean hasproblems = scope.referencecontext().compilationresult().problemcount > problemcount;

// verify field references
boolean source15 = scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
int scopemodifiers = -1;
if (reference instanceof javadocfieldreference) {
javadocfieldreference fieldref = (javadocfieldreference) reference;

// verify if this is a method reference
// see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=51911
if (fieldref.methodbinding != null) {
// cannot refer to method for @@value tag
if (fieldref.tagvalue == javadoctagconstants.tag_value_value) {
if (scopemodifiers == -1) scopemodifiers = scope.getdeclarationmodifiers();
scope.problemreporter().javadocinvalidvaluereference(fieldref.sourcestart, fieldref.sourceend, scopemodifiers);
}
else if (fieldref.actualreceivertype != null) {
if (scope.enclosingsourcetype().iscompatiblewith(fieldref.actualreceivertype)) {
fieldref.bits |= astnode.superaccess;
}
fieldref.methodbinding = scope.findmethod((referencebinding)fieldref.actualreceivertype, fieldref.token, new typebinding[0], fieldref);
}
}

// verify whether field ref should be static or not (for @@value tags)
else if (source15 && fieldref.binding != null && fieldref.binding.isvalidbinding()) {
if (fieldref.tagvalue == javadoctagconstants.tag_value_value && !fieldref.binding.isstatic()) {
if (scopemodifiers == -1) scopemodifiers = scope.getdeclarationmodifiers();
scope.problemreporter().javadocinvalidvaluereference(fieldref.sourcestart, fieldref.sourceend, scopemodifiers);
}
}

// verify type references
if (!hasproblems && fieldref.binding != null && fieldref.binding.isvalidbinding() && fieldref.actualreceivertype instanceof referencebinding) {
referencebinding resolvedtype = (referencebinding) fieldref.actualreceivertype;
verifytypereference(fieldref, fieldref.receiver, scope, source15, resolvedtype, fieldref.binding.modifiers);
}

// that's it for field references
return;
}

// verify type references
if (!hasproblems && (reference instanceof javadocsingletypereference || reference instanceof javadocqualifiedtypereference) && reference.resolvedtype instanceof referencebinding) {
referencebinding resolvedtype = (referencebinding) reference.resolvedtype;
verifytypereference(reference, reference, scope, source15, resolvedtype, resolvedtype.modifiers);
}

// verify that message reference are not used for @@value tags
if (reference instanceof javadocmessagesend) {
javadocmessagesend msgsend = (javadocmessagesend) reference;

// tag value
if (source15 && msgsend.tagvalue == javadoctagconstants.tag_value_value) { // cannot refer to method for @@value tag
if (scopemodifiers == -1) scopemodifiers = scope.getdeclarationmodifiers();
scope.problemreporter().javadocinvalidvaluereference(msgsend.sourcestart, msgsend.sourceend, scopemodifiers);
}

// verify type references
if (!hasproblems && msgsend.binding != null && msgsend.binding.isvalidbinding() && msgsend.actualreceivertype instanceof referencebinding) {
referencebinding resolvedtype = (referencebinding) msgsend.actualreceivertype;
verifytypereference(msgsend, msgsend.receiver, scope, source15, resolvedtype, msgsend.binding.modifiers);
}
}

// verify that constructor reference are not used for @@value tags
else if (reference instanceof javadocallocationexpression) {
javadocallocationexpression alloc = (javadocallocationexpression) reference;

// tag value
if (source15 && alloc.tagvalue == javadoctagconstants.tag_value_value) { // cannot refer to method for @@value tag
if (scopemodifiers == -1) scopemodifiers = scope.getdeclarationmodifiers();
scope.problemreporter().javadocinvalidvaluereference(alloc.sourcestart, alloc.sourceend, scopemodifiers);
}

// verify type references
if (!hasproblems && alloc.binding != null && alloc.binding.isvalidbinding() && alloc.resolvedtype instanceof referencebinding) {
referencebinding resolvedtype = (referencebinding) alloc.resolvedtype;
verifytypereference(alloc, alloc.type, scope, source15, resolvedtype, alloc.binding.modifiers);
}
}

// verify that there's no type variable reference
// (javadoc does not accept them and this is not a referenced bug or requested enhancement)
if (reference.resolvedtype != null && reference.resolvedtype.istypevariable()) {
scope.problemreporter().javadocinvalidreference(reference.sourcestart, reference.sourceend);
}
}

/*
* resolve @@param tags while method scope
*/
private void resolveparamtags(methodscope scope, boolean reportmissing, boolean considerparamrefasusage) {
abstractmethoddeclaration methoddecl = scope.referencemethod();
int paramtagssize = this.paramreferences == null ? 0 : this.paramreferences.length;

// if no referenced method (field initializer for example) then report a problem for each param tag
if (methoddecl == null) {
for (int i = 0; i < paramtagssize; i++) {
javadocsinglenamereference param = this.paramreferences[i];
scope.problemreporter().javadocunexpectedtag(param.tagsourcestart, param.tagsourceend);
}
return;
}

// if no param tags then report a problem for each method argument
int argumentssize = methoddecl.arguments == null ? 0 : methoddecl.arguments.length;
if (paramtagssize == 0) {
if (reportmissing) {
for (int i = 0; i < argumentssize; i++) {
argument arg = methoddecl.arguments[i];
scope.problemreporter().javadocmissingparamtag(arg.name, arg.sourcestart, arg.sourceend, methoddecl.binding.modifiers);
}
}
} else {
localvariablebinding[] bindings = new localvariablebinding[paramtagssize];
int maxbindings = 0;

// scan all @@param tags
for (int i = 0; i < paramtagssize; i++) {
javadocsinglenamereference param = this.paramreferences[i];
param.resolve(scope, true, considerparamrefasusage);
if (param.binding != null && param.binding.isvalidbinding()) {
// verify duplicated tags
boolean found = false;
for (int j = 0; j < maxbindings && !found; j++) {
if (bindings[j] == param.binding) {
scope.problemreporter().javadocduplicatedparamtag(param.token, param.sourcestart, param.sourceend, methoddecl.binding.modifiers);
found = true;
}
}
if (!found) {
bindings[maxbindings++] = (localvariablebinding) param.binding;
}
}
}

// look for undocumented arguments
if (reportmissing) {
for (int i = 0; i < argumentssize; i++) {
argument arg = methoddecl.arguments[i];
boolean found = false;
for (int j = 0; j < maxbindings && !found; j++) {
localvariablebinding binding = bindings[j];
if (arg.binding == binding) {
found = true;
}
}
if (!found) {
scope.problemreporter().javadocmissingparamtag(arg.name, arg.sourcestart, arg.sourceend, methoddecl.binding.modifiers);
}
}
}
}
}

/*
* resolve @@param tags for type parameters
*/
private void resolvetypeparametertags(scope scope, boolean reportmissing) {
int paramtypeparamlength = this.paramtypeparameters == null ? 0 : this.paramtypeparameters.length;

// get declaration infos
typeparameter[] parameters = null;
typevariablebinding[] typevariables = null;
int modifiers = -1;
switch (scope.kind) {
case scope.method_scope:
abstractmethoddeclaration methoddeclaration = ((methodscope)scope).referencemethod();
// if no referenced method (field initializer for example) then report a problem for each param tag
if (methoddeclaration == null) {
for (int i = 0; i < paramtypeparamlength; i++) {
javadocsingletypereference param = this.paramtypeparameters[i];
scope.problemreporter().javadocunexpectedtag(param.tagsourcestart, param.tagsourceend);
}
return;
}
parameters = methoddeclaration.typeparameters();
typevariables = methoddeclaration.binding.typevariables;
modifiers = methoddeclaration.binding.modifiers;
break;
case scope.class_scope:
typedeclaration typedeclaration = ((classscope) scope).referencecontext;
parameters = typedeclaration.typeparameters;
typevariables = typedeclaration.binding.typevariables;
modifiers = typedeclaration.binding.modifiers;
break;
}

// if no type variables then report a problem for each param type parameter tag
if (typevariables == null || typevariables.length == 0) {
for (int i = 0; i < paramtypeparamlength; i++) {
javadocsingletypereference param = this.paramtypeparameters[i];
scope.problemreporter().javadocunexpectedtag(param.tagsourcestart, param.tagsourceend);
}
return;
}

// if no param tags then report a problem for each declaration type parameter
if (parameters != null) {
int typeparameterslength = parameters.length;
if (paramtypeparamlength == 0) {
if (reportmissing) {
for (int i = 0, l=typeparameterslength; i<l; i++) {
scope.problemreporter().javadocmissingparamtag(parameters[i].name, parameters[i].sourcestart, parameters[i].sourceend, modifiers);
}
}

// otherwise verify that all param tags match type parameters
} else if (typevariables.length == typeparameterslength) {
typevariablebinding[] bindings = new typevariablebinding[paramtypeparamlength];

// scan all @@param tags
for (int i = 0; i < paramtypeparamlength; i++) {
javadocsingletypereference param = this.paramtypeparameters[i];
typebinding parambindind = param.internalresolvetype(scope);
if (parambindind != null && parambindind.isvalidbinding()) {
if (parambindind.istypevariable()) {
// verify duplicated tags
boolean duplicate = false;
for (int j = 0; j < i && !duplicate; j++) {
if (bindings[j] == param.resolvedtype) {
scope.problemreporter().javadocduplicatedparamtag(param.token, param.sourcestart, param.sourceend, modifiers);
duplicate = true;
}
}
if (!duplicate) {
bindings[i] = (typevariablebinding) param.resolvedtype;
}
} else {
scope.problemreporter().javadocundeclaredparamtagname(param.token, param.sourcestart, param.sourceend, modifiers);
}
}
}

// look for undocumented type parameters
for (int i = 0; i < typeparameterslength; i++) {
typeparameter parameter = parameters[i];
boolean found = false;
for (int j = 0; j < paramtypeparamlength && !found; j++) {
if (parameter.binding == bindings[j]) {
found = true;
bindings[j] = null;
}
}
if (!found && reportmissing) {
scope.problemreporter().javadocmissingparamtag(parameter.name, parameter.sourcestart, parameter.sourceend, modifiers);
}
}

// report invalid param
for (int i=0; i<paramtypeparamlength; i++) {
if (bindings[i] != null) {
javadocsingletypereference param = this.paramtypeparameters[i];
scope.problemreporter().javadocundeclaredparamtagname(param.token, param.sourcestart, param.sourceend, modifiers);
}
}
}
}
}

/*
* resolve @@throws/@@exception tags while method scope
*/
private void resolvethrowstags(methodscope methscope, boolean reportmissing) {
abstractmethoddeclaration md = methscope.referencemethod();
int throwstagslength = this.exceptionreferences == null ? 0 : this.exceptionreferences.length;

// if no referenced method (field initializer for example) then report a problem for each throws tag
if (md == null) {
for (int i = 0; i < throwstagslength; i++) {
typereference typeref = this.exceptionreferences[i];
int start = typeref.sourcestart;
int end = typeref.sourceend;
if (typeref instanceof javadocqualifiedtypereference) {
start = ((javadocqualifiedtypereference) typeref).tagsourcestart;
end = ((javadocqualifiedtypereference) typeref).tagsourceend;
} else if (typeref instanceof javadocsingletypereference) {
start = ((javadocsingletypereference) typeref).tagsourcestart;
end = ((javadocsingletypereference) typeref).tagsourceend;
}
methscope.problemreporter().javadocunexpectedtag(start, end);
}
return;
}

// if no throws tags then report a problem for each method thrown exception
int boundexceptionlength = (md.binding == null) ? 0 : md.binding.thrownexceptions.length;
int thrownexceptionlength = md.thrownexceptions == null ? 0 : md.thrownexceptions.length;
if (throwstagslength == 0) {
if (reportmissing) {
for (int i = 0; i < boundexceptionlength; i++) {
referencebinding exceptionbinding = md.binding.thrownexceptions[i];
if (exceptionbinding != null && exceptionbinding.isvalidbinding()) { // flag only valid class name
int j=i;
while (j<thrownexceptionlength && exceptionbinding != md.thrownexceptions[j].resolvedtype) j++;
if (j<thrownexceptionlength) {
methscope.problemreporter().javadocmissingthrowstag(md.thrownexceptions[j], md.binding.modifiers);
}
}
}
}
} else {
int maxref = 0;
typereference[] typereferences = new typereference[throwstagslength];

// scan all @@throws tags
for (int i = 0; i < throwstagslength; i++) {
typereference typeref = this.exceptionreferences[i];
typeref.resolve(methscope);
typebinding typebinding = typeref.resolvedtype;

if (typebinding != null && typebinding.isvalidbinding() && typebinding.isclass()) {
// accept only valid class binding
typereferences[maxref++] = typeref;
}
}

// look for undocumented thrown exception
for (int i = 0; i < boundexceptionlength; i++) {
referencebinding exceptionbinding = md.binding.thrownexceptions[i];
if (exceptionbinding != null) exceptionbinding = (referencebinding) exceptionbinding.erasure();
boolean found = false;
for (int j = 0; j < maxref && !found; j++) {
if (typereferences[j] != null) {
typebinding typebinding = typereferences[j].resolvedtype;
if (exceptionbinding == typebinding) {
found = true;
typereferences[j] = null;
}
}
}
if (!found && reportmissing) {
if (exceptionbinding != null && exceptionbinding.isvalidbinding()) { // flag only valid class name
int k=i;
while (k<thrownexceptionlength && exceptionbinding != md.thrownexceptions[k].resolvedtype) k++;
if (k<thrownexceptionlength) {
methscope.problemreporter().javadocmissingthrowstag(md.thrownexceptions[k], md.binding.modifiers);
}
}
}
}

// verify additional @@throws tags
for (int i = 0; i < maxref; i++) {
typereference typeref = typereferences[i];
if (typeref != null) {
boolean compatible = false;
// thrown exceptions subclasses are accepted
for (int j = 0; j<thrownexceptionlength && !compatible; j++) {
typebinding exceptionbinding = md.thrownexceptions[j].resolvedtype;
if (exceptionbinding != null) {
compatible = typeref.resolvedtype.iscompatiblewith(exceptionbinding);
}
}

//  if not compatible only complain on unchecked exception
if (!compatible && !typeref.resolvedtype.isuncheckedexception(false)) {
methscope.problemreporter().javadocinvalidthrowsclassname(typeref, md.binding.modifiers);
}
}
}
}
}

private void verifytypereference(expression reference, expression typereference, scope scope, boolean source15, referencebinding resolvedtype, int modifiers) {
if (resolvedtype.isvalidbinding()) {
int scopemodifiers = -1;

// reference must have enough visibility to be used
if (!canbeseen(scope.problemreporter().options.reportinvalidjavadoctagsvisibility, modifiers)) {
scope.problemreporter().javadochiddenreference(typereference.sourcestart, reference.sourceend, scope, modifiers);
return;
}

// type reference must have enough visibility to be used
if (reference != typereference) {
if (!canbeseen(scope.problemreporter().options.reportinvalidjavadoctagsvisibility, resolvedtype.modifiers)) {
scope.problemreporter().javadochiddenreference(typereference.sourcestart, typereference.sourceend, scope, resolvedtype.modifiers);
return;
}
}

// member types
if (resolvedtype.ismembertype()) {
referencebinding topleveltype = resolvedtype;
// rebuild and store (in reverse order) compound name to handle embedded inner class
int packagelength = topleveltype.fpackage.compoundname.length;
int depth = resolvedtype.depth();
int idx = depth + packagelength;
char[][] computedcompoundname = new char[idx+1][];
computedcompoundname[idx] = topleveltype.sourcename;
while (topleveltype.enclosingtype() != null) {
topleveltype = topleveltype.enclosingtype();
computedcompoundname[--idx] = topleveltype.sourcename;
}

// add package information
for (int i = packagelength; --i >= 0;) {
computedcompoundname[--idx] = topleveltype.fpackage.compoundname[i];
}

classscope toplevelscope = scope.classscope();
// when scope is not on compilation unit type, then inner class may not be visible...
if (toplevelscope.parent.kind != scope.compilation_unit_scope ||
!charoperation.equals(topleveltype.sourcename, toplevelscope.referencecontext.name)) {
toplevelscope = toplevelscope.outermostclassscope();
if (typereference instanceof javadocsingletypereference) {
// inner class single reference can only be done in same unit
if ((!source15 && depth == 1) || topleveltype != toplevelscope.referencecontext.binding) {
// search for corresponding import
boolean hasvalidimport = false;
if (source15) {
compilationunitscope unitscope = toplevelscope.compilationunitscope();
importbinding[] imports = unitscope.imports;
int length = imports == null ? 0 : imports.length;
mainloop: for (int i=0; i<length; i++) {
char[][] compoundname = imports[i].compoundname;
int compoundnamelength = compoundname.length;
if ((imports[i].ondemand && compoundnamelength == computedcompoundname.length-1)
|| (compoundnamelength == computedcompoundname.length)) {
for (int j = compoundnamelength; --j >= 0;) {
if (charoperation.equals(imports[i].compoundname[j], computedcompoundname[j])) {
if (j == 0) {
hasvalidimport = true;
importreference importreference = imports[i].reference;
if (importreference != null) {
importreference.bits |= astnode.used;
}
break mainloop;
}
} else {
break;
}
}
}
}
if (!hasvalidimport) {
if (scopemodifiers == -1) scopemodifiers = scope.getdeclarationmodifiers();
scope.problemreporter().javadocinvalidmembertypequalification(typereference.sourcestart, typereference.sourceend, scopemodifiers);
}
} else {
if (scopemodifiers == -1) scopemodifiers = scope.getdeclarationmodifiers();
scope.problemreporter().javadocinvalidmembertypequalification(typereference.sourcestart, typereference.sourceend, scopemodifiers);
return;
}
}
}
}
}
/*
* https://bugs.eclipse.org/bugs/show_bug.cgi?id=286918
*
* we are concerned only about the single type references (i.e. without any package) if they are not in default package,
* then report an error. references with qualified yet incorrect names would have already been taken care of.
*/
if (scope.referencecompilationunit().ispackageinfo() && typereference instanceof javadocsingletypereference) {
if (resolvedtype.fpackage.compoundname.length > 0) {
scope.problemreporter().javadocinvalidreference(typereference.sourcestart, typereference.sourceend);
return; // not really needed - just in case more code added in future
}
}
}
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.paramreferences != null) {
for (int i = 0, length = this.paramreferences.length; i < length; i++) {
this.paramreferences[i].traverse(visitor, scope);
}
}
if (this.paramtypeparameters != null) {
for (int i = 0, length = this.paramtypeparameters.length; i < length; i++) {
this.paramtypeparameters[i].traverse(visitor, scope);
}
}
if (this.returnstatement != null) {
this.returnstatement.traverse(visitor, scope);
}
if (this.exceptionreferences != null) {
for (int i = 0, length = this.exceptionreferences.length; i < length; i++) {
this.exceptionreferences[i].traverse(visitor, scope);
}
}
if (this.seereferences != null) {
for (int i = 0, length = this.seereferences.length; i < length; i++) {
this.seereferences[i].traverse(visitor, scope);
}
}
}
visitor.endvisit(this, scope);
}
public void traverse(astvisitor visitor, classscope scope) {
if (visitor.visit(this, scope)) {
if (this.paramreferences != null) {
for (int i = 0, length = this.paramreferences.length; i < length; i++) {
this.paramreferences[i].traverse(visitor, scope);
}
}
if (this.paramtypeparameters != null) {
for (int i = 0, length = this.paramtypeparameters.length; i < length; i++) {
this.paramtypeparameters[i].traverse(visitor, scope);
}
}
if (this.returnstatement != null) {
this.returnstatement.traverse(visitor, scope);
}
if (this.exceptionreferences != null) {
for (int i = 0, length = this.exceptionreferences.length; i < length; i++) {
this.exceptionreferences[i].traverse(visitor, scope);
}
}
if (this.seereferences != null) {
for (int i = 0, length = this.seereferences.length; i < length; i++) {
this.seereferences[i].traverse(visitor, scope);
}
}
}
visitor.endvisit(this, scope);
}
}
