/*******************************************************************************
* copyright (c) 2006, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

import java.util.arraylist;
import java.util.arrays;
import java.util.hashmap;
import java.util.hashset;
import java.util.iterator;
import java.util.set;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.classfile;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;

public class stackmapframecodestream extends codestream {
public static class exceptionmarker implements comparable {
public char[] constantpoolname;
public int pc;

public exceptionmarker(int pc, char[] constantpoolname) {
this.pc = pc;
this.constantpoolname = constantpoolname;
}
public int compareto(object o) {
if (o instanceof exceptionmarker) {
return this.pc - ((exceptionmarker) o).pc;
}
return 0;
}
public boolean equals(object obj) {
if (obj instanceof exceptionmarker) {
exceptionmarker marker = (exceptionmarker) obj;
return this.pc == marker.pc && charoperation.equals(this.constantpoolname, marker.constantpoolname);
}
return false;
}
public int hashcode() {
return this.pc + this.constantpoolname.hashcode();
}
public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append('(').append(this.pc).append(',').append(this.constantpoolname).append(')');
return string.valueof(buffer);
}
}

public static class stackdepthmarker {
public int pc;
public int delta;
public typebinding typebinding;

public stackdepthmarker(int pc, int delta, typebinding typebinding) {
this.pc = pc;
this.typebinding = typebinding;
this.delta = delta;
}

public stackdepthmarker(int pc, int delta) {
this.pc = pc;
this.delta = delta;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append('(').append(this.pc).append(',').append(this.delta);
if (this.typebinding != null) {
buffer
.append(',')
.append(this.typebinding.qualifiedpackagename())
.append(this.typebinding.qualifiedsourcename());
}
buffer.append(')');
return string.valueof(buffer);
}
}

public static class stackmarker {
public int pc;
public int destinationpc;
public verificationtypeinfo[] infos;

public stackmarker(int pc, int destinationpc) {
this.pc = pc;
this.destinationpc = destinationpc;
}

public void setinfos(verificationtypeinfo[] infos) {
this.infos = infos;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer
.append("[copy stack items from ") //$non-nls-1$
.append(this.pc)
.append(" to ") //$non-nls-1$
.append(this.destinationpc);
if (this.infos!= null) {
for (int i = 0, max = this.infos.length; i < max; i++) {
if (i > 0) buffer.append(',');
buffer.append(this.infos[i]);
}
}
buffer.append(']');
return string.valueof(buffer);
}
}

static class frameposition {
int counter;
}

public int[] stateindexes;
public int stateindexescounter;
private hashmap framepositions;
public set exceptionmarkers;
public arraylist stackdepthmarkers;
public arraylist stackmarkers;

public stackmapframecodestream(classfile givenclassfile) {
super(givenclassfile);
this.generateattributes |= classfileconstants.attr_stack_map;
}
public void adddefinitelyassignedvariables(scope scope, int initstateindex) {
// required to fix 1pr0xvs: lfre:winnt - compiler: variable table for method appears incorrect
loop: for (int i = 0; i < this.visiblelocalscount; i++) {
localvariablebinding localbinding = this.visiblelocals[i];
if (localbinding != null) {
// check if the local is definitely assigned
boolean isdefinitelyassigned = isdefinitelyassigned(scope, initstateindex, localbinding);
if (!isdefinitelyassigned) {
if (this.stateindexes != null) {
for (int j = 0, max = this.stateindexescounter; j < max; j++) {
if (isdefinitelyassigned(scope, this.stateindexes[j], localbinding)) {
if ((localbinding.initializationcount == 0) || (localbinding.initializationpcs[((localbinding.initializationcount - 1) << 1) + 1] != -1)) {
/* there are two cases:
* 1) there is no initialization interval opened ==> add an opened interval
* 2) there is already some initialization intervals but the last one is closed ==> add an opened interval
* an opened interval means that the value at localbinding.initializationpcs[localbinding.initializationcount - 1][1]
* is equals to -1.
* initializationpcs is a collection of pairs of int:
* 	first value is the startpc and second value is the endpc. -1 one for the last value means that the interval
* 	is not closed yet.
*/
localbinding.recordinitializationstartpc(this.position);
}
continue loop;
}
}
}
} else {
if ((localbinding.initializationcount == 0) || (localbinding.initializationpcs[((localbinding.initializationcount - 1) << 1) + 1] != -1)) {
/* there are two cases:
* 1) there is no initialization interval opened ==> add an opened interval
* 2) there is already some initialization intervals but the last one is closed ==> add an opened interval
* an opened interval means that the value at localbinding.initializationpcs[localbinding.initializationcount - 1][1]
* is equals to -1.
* initializationpcs is a collection of pairs of int:
* 	first value is the startpc and second value is the endpc. -1 one for the last value means that the interval
* 	is not closed yet.
*/
localbinding.recordinitializationstartpc(this.position);
}
}
}
}
}
public void addexceptionmarker(int pc, typebinding typebinding) {
if (this.exceptionmarkers == null) {
this.exceptionmarkers = new hashset();
}
if (typebinding == null) {
this.exceptionmarkers.add(new exceptionmarker(pc, constantpool.javalangthrowableconstantpoolname));
} else {
switch(typebinding.id) {
case typeids.t_null :
this.exceptionmarkers.add(new exceptionmarker(pc, constantpool.javalangclassnotfoundexceptionconstantpoolname));
break;
case typeids.t_long :
this.exceptionmarkers.add(new exceptionmarker(pc, constantpool.javalangnosuchfielderrorconstantpoolname));
break;
default:
this.exceptionmarkers.add(new exceptionmarker(pc, typebinding.constantpoolname()));
}
}
}
public void addframeposition(int pc) {
integer newentry = new integer(pc);
frameposition value;
if ((value = (frameposition) this.framepositions.get(newentry)) != null) {
value.counter++;
} else {
this.framepositions.put(newentry, new frameposition());
}
}
public void optimizebranch(int oldposition, branchlabel lbl) {
super.optimizebranch(oldposition, lbl);
removeframeposition(oldposition);
}
public void removeframeposition(int pc) {
integer entry = new integer(pc);
frameposition value;
if ((value = (frameposition) this.framepositions.get(entry)) != null) {
value.counter--;
if (value.counter <= 0) {
this.framepositions.remove(entry);
}
}
}
public void addvariable(localvariablebinding localbinding) {
if (localbinding.initializationpcs == null) {
record(localbinding);
}
localbinding.recordinitializationstartpc(this.position);
}
private void addstackmarker(int pc, int destinationpc) {
if (this.stackmarkers == null) {
this.stackmarkers = new arraylist();
this.stackmarkers.add(new stackmarker(pc, destinationpc));
} else {
int size = this.stackmarkers.size();
if (size == 0 || ((stackmarker) this.stackmarkers.get(size - 1)).pc != this.position) {
this.stackmarkers.add(new stackmarker(pc, destinationpc));
}
}
}
private void addstackdepthmarker(int pc, int delta, typebinding typebinding) {
if (this.stackdepthmarkers == null) {
this.stackdepthmarkers = new arraylist();
this.stackdepthmarkers.add(new stackdepthmarker(pc, delta, typebinding));
} else {
int size = this.stackdepthmarkers.size();
if (size == 0 || ((stackdepthmarker) this.stackdepthmarkers.get(size - 1)).pc != this.position) {
this.stackdepthmarkers.add(new stackdepthmarker(pc, delta, typebinding));
}
}
}
public void decrstacksize(int offset) {
super.decrstacksize(offset);
addstackdepthmarker(this.position, -1, null);
}
public void recordexpressiontype(typebinding typebinding) {
addstackdepthmarker(this.position, 0, typebinding);
}
/**
* macro for building a class descriptor object
*/
public void generateclassliteralaccessfortype(typebinding accessedtype, fieldbinding syntheticfieldbinding) {
if (accessedtype.isbasetype() && accessedtype != typebinding.null) {
gettype(accessedtype.id);
return;
}

if (this.targetlevel >= classfileconstants.jdk1_5) {
// generation using the new ldc_w bytecode
this.ldc(accessedtype);
} else {
// use in cldc mode
branchlabel endlabel = new branchlabel(this);
if (syntheticfieldbinding != null) { // non interface case
fieldaccess(opcodes.opc_getstatic, syntheticfieldbinding, null /* default declaringclass */);
dup();
ifnonnull(endlabel);
pop();
}

/* macro for building a class descriptor object... using or not a field cache to store it into...
this sequence is responsible for building the actual class descriptor.

if the fieldcache is set, then it is supposed to be the body of a synthetic access method
factoring the actual descriptor creation out of the invocation site (saving space).
if the fieldcache is nil, then we are dumping the bytecode on the invocation site, since
we have no way to get a hand on the field cache to do better. */


// wrap the code in an exception handler to convert a classnotfoundexception into a noclassdeferror

exceptionlabel classnotfoundexceptionhandler = new exceptionlabel(this, typebinding.null /*represents classnotfoundexception*/);
classnotfoundexceptionhandler.placestart();
this.ldc(accessedtype == typebinding.null ? "java.lang.object" : string.valueof(accessedtype.constantpoolname()).replace('/', '.')); //$non-nls-1$
invokeclassforname();

/* see https://bugs.eclipse.org/bugs/show_bug.cgi?id=37565
if (accessedtype == basetypes.nullbinding) {
this.ldc("java.lang.object"); //$non-nls-1$
} else if (accessedtype.isarraytype()) {
this.ldc(string.valueof(accessedtype.constantpoolname()).replace('/', '.'));
} else {
// we make it an array type (to avoid class initialization)
this.ldc("[l" + string.valueof(accessedtype.constantpoolname()).replace('/', '.') + ";"); //$non-nls-1$//$non-nls-2$
}
this.invokeclassforname();
if (!accessedtype.isarraytype()) { // extract the component type, which doesn't initialize the class
this.invokejavalangclassgetcomponenttype();
}
*/
/* we need to protect the runtime code from binary inconsistencies
in case the accessedtype is missing, the classnotfoundexception has to be converted
into a noclassdeferror(old ex message), we thus need to build an exception handler for this one. */
classnotfoundexceptionhandler.placeend();

if (syntheticfieldbinding != null) { // non interface case
dup();
fieldaccess(opcodes.opc_putstatic, syntheticfieldbinding, null /* default declaringclass */);
}
int frompc = this.position;
goto_(endlabel);
int savedstackdepth = this.stackdepth;
// generate the body of the exception handler
/* classnotfoundexception on stack -- the class literal could be doing more things
on the stack, which means that the stack may not be empty at this point in the
above code gen. so we save its state and restart it from 1. */

pushexceptiononstack(typebinding.null);/*represents classnotfoundexception*/
classnotfoundexceptionhandler.place();

// transform the current exception, and repush and throw a
// noclassdeffounderror(classnotfound.getmessage())

newnoclassdeffounderror();
dup_x1();
swap();

// retrieve the message from the old exception
invokethrowablegetmessage();

// send the constructor taking a message string as an argument
invokenoclassdeffounderrorstringconstructor();
athrow();
endlabel.place();
addstackmarker(frompc, this.position);
this.stackdepth = savedstackdepth;
}
}
public exceptionmarker[] getexceptionmarkers() {
set exceptionmarkerset = this.exceptionmarkers;
if (this.exceptionmarkers == null) return null;
int size = exceptionmarkerset.size();
exceptionmarker[] markers = new exceptionmarker[size];
int n = 0;
for (iterator iterator = exceptionmarkerset.iterator(); iterator.hasnext(); ) {
markers[n++] = (exceptionmarker) iterator.next();
}
arrays.sort(markers);
//  system.out.print('[');
//  for (int n = 0; n < size; n++) {
//  	if (n != 0) system.out.print(',');
//  	system.out.print(positions[n]);
//  }
//  system.out.println(']');
return markers;
}
public int[] getframepositions() {
set set = this.framepositions.keyset();
int size = set.size();
int[] positions = new int[size];
int n = 0;
for (iterator iterator = set.iterator(); iterator.hasnext(); ) {
positions[n++] = ((integer) iterator.next()).intvalue();
}
arrays.sort(positions);
//  system.out.print('[');
//  for (int n = 0; n < size; n++) {
//  	if (n != 0) system.out.print(',');
//  	system.out.print(positions[n]);
//  }
//  system.out.println(']');
return positions;
}
public stackdepthmarker[] getstackdepthmarkers() {
if (this.stackdepthmarkers == null) return null;
int length = this.stackdepthmarkers.size();
if (length == 0) return null;
stackdepthmarker[] result = new stackdepthmarker[length];
this.stackdepthmarkers.toarray(result);
return result;
}
public stackmarker[] getstackmarkers() {
if (this.stackmarkers == null) return null;
int length = this.stackmarkers.size();
if (length == 0) return null;
stackmarker[] result = new stackmarker[length];
this.stackmarkers.toarray(result);
return result;
}
public boolean hasframepositions() {
return this.framepositions.size() != 0;
}
public void init(classfile targetclassfile) {
super.init(targetclassfile);
this.stateindexescounter = 0;
if (this.framepositions != null) {
this.framepositions.clear();
}
if (this.exceptionmarkers != null) {
this.exceptionmarkers.clear();
}
if (this.stackdepthmarkers != null) {
this.stackdepthmarkers.clear();
}
if (this.stackmarkers != null) {
this.stackmarkers.clear();
}
}

public void initializemaxlocals(methodbinding methodbinding) {
super.initializemaxlocals(methodbinding);
if (this.framepositions == null) {
this.framepositions = new hashmap();
} else {
this.framepositions.clear();
}
}
public void popstateindex() {
this.stateindexescounter--;
}
public void pushstateindex(int naturalexitmergeinitstateindex) {
if (this.stateindexes == null) {
this.stateindexes = new int[3];
}
int length = this.stateindexes.length;
if (length == this.stateindexescounter) {
// resize
system.arraycopy(this.stateindexes, 0, (this.stateindexes = new int[length * 2]), 0, length);
}
this.stateindexes[this.stateindexescounter++] = naturalexitmergeinitstateindex;
}
public void removenotdefinitelyassignedvariables(scope scope, int initstateindex) {
int index = this.visiblelocalscount;
loop : for (int i = 0; i < index; i++) {
localvariablebinding localbinding = this.visiblelocals[i];
if (localbinding != null && localbinding.initializationcount > 0) {
boolean isdefinitelyassigned = isdefinitelyassigned(scope, initstateindex, localbinding);
if (!isdefinitelyassigned) {
if (this.stateindexes != null) {
for (int j = 0, max = this.stateindexescounter; j < max; j++) {
if (isdefinitelyassigned(scope, this.stateindexes[j], localbinding)) {
continue loop;
}
}
}
localbinding.recordinitializationendpc(this.position);
}
}
}
}
public void reset(classfile givenclassfile) {
super.reset(givenclassfile);
this.stateindexescounter = 0;
if (this.framepositions != null) {
this.framepositions.clear();
}
if (this.exceptionmarkers != null) {
this.exceptionmarkers.clear();
}
if (this.stackdepthmarkers != null) {
this.stackdepthmarkers.clear();
}
if (this.stackmarkers != null) {
this.stackmarkers.clear();
}
}
protected void writeposition(branchlabel label) {
super.writeposition(label);
addframeposition(label.position);
}
protected void writeposition(branchlabel label, int forwardreference) {
super.writeposition(label, forwardreference);
addframeposition(label.position);
}
protected void writesignedword(int pos, int value) {
super.writesignedword(pos, value);
addframeposition(this.position);
}
protected void writewideposition(branchlabel label) {
super.writewideposition(label);
addframeposition(label.position);
}
public void areturn() {
super.areturn();
addframeposition(this.position);
}
public void ireturn() {
super.ireturn();
addframeposition(this.position);
}
public void lreturn() {
super.lreturn();
addframeposition(this.position);
}
public void freturn() {
super.freturn();
addframeposition(this.position);
}
public void dreturn() {
super.dreturn();
addframeposition(this.position);
}
public void return_() {
super.return_();
addframeposition(this.position);
}
public void athrow() {
super.athrow();
addframeposition(this.position);
}
public void pushonstack(typebinding binding) {
super.pushonstack(binding);
addstackdepthmarker(this.position, 1, binding);
}
public void pushexceptiononstack(typebinding binding) {
super.pushexceptiononstack(binding);
addexceptionmarker(this.position, binding);
}
public void goto_(branchlabel label) {
super.goto_(label);
addframeposition(this.position);
}
public void goto_w(branchlabel label) {
super.goto_w(label);
addframeposition(this.position);
}
public void resetinwidemode() {
this.resetsecretlocals();
super.resetinwidemode();
}
public void resetsecretlocals() {
for (int i = 0, max = this.locals.length; i < max; i++) {
localvariablebinding localvariablebinding = this.locals[i];
if (localvariablebinding != null && localvariablebinding.issecret()) {
// all other locals are reinitialized inside the computation of their resolved positions
localvariablebinding.resetinitializations();
}
}
}
}
