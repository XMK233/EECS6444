/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.impl.stringconstant;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class stringliteral extends literal {

char[] source;
int linenumber;

public stringliteral(char[] token, int start, int end, int linenumber) {

this(start,end);
this.source = token;
this.linenumber = linenumber - 1; // line number is 1 based
}

public stringliteral(int s, int e) {

super(s,e);
}

public void computeconstant() {

this.constant = stringconstant.fromvalue(string.valueof(this.source));
}

public extendedstringliteral extendwith(charliteral lit){

//add the lit source to mine, just as if it was mine
return new extendedstringliteral(this,lit);
}

public extendedstringliteral extendwith(stringliteral lit){

//add the lit source to mine, just as if it was mine
return new extendedstringliteral(this,lit);
}

/**
*  add the lit source to mine, just as if it was mine
*/
public stringliteralconcatenation extendswith(stringliteral lit) {
return new stringliteralconcatenation(this, lit);
}
/**
* code generation for string literal
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {

int pc = codestream.position;
if (valuerequired)
codestream.ldc(this.constant.stringvalue());
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public typebinding literaltype(blockscope scope) {

return scope.getjavalangstring();
}

public stringbuffer printexpression(int indent, stringbuffer output) {

// handle some special char.....
output.append('\"');
for (int i = 0; i < this.source.length; i++) {
switch (this.source[i]) {
case '\b' :
output.append("\\b"); //$non-nls-1$
break;
case '\t' :
output.append("\\t"); //$non-nls-1$
break;
case '\n' :
output.append("\\n"); //$non-nls-1$
break;
case '\f' :
output.append("\\f"); //$non-nls-1$
break;
case '\r' :
output.append("\\r"); //$non-nls-1$
break;
case '\"' :
output.append("\\\""); //$non-nls-1$
break;
case '\'' :
output.append("\\'"); //$non-nls-1$
break;
case '\\' : //take care not to display the escape as a potential real char
output.append("\\\\"); //$non-nls-1$
break;
default :
output.append(this.source[i]);
}
}
output.append('\"');
return output;
}

public char[] source() {

return this.source;
}

public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
