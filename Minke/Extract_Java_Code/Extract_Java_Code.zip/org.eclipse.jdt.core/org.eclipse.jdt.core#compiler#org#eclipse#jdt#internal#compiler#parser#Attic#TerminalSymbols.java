package org.eclipse.jdt.internal.compiler.parser;

import org.eclipse.jdt.core.compiler.iterminalsymbols;
/*
* (c) copyright ibm corp. 2000, 2001.
* all rights reserved.
*/
/*maps each terminal symbol in the java-grammar into a unique integer.
this integer is used to represent the terminal when computing a parsing action. */

/**
* @@deprecated - use org.eclipse.jdt.core.compiler.iterminalsymbols instead
*/
public interface terminalsymbols extends iterminalsymbols {}
