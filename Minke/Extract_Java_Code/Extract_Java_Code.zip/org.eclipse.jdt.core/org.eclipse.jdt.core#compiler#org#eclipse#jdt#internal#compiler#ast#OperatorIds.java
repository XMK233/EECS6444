/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

public interface operatorids {
public static final int and_and = 0;
public static final int or_or = 1;
public static final int and = 2;
public static final int or = 3;
public static final int less = 4;
public static final int less_equal = 5;
public static final int greater = 6;
public static final int greater_equal = 7;
public static final int xor = 8;
public static final int divide = 9;
public static final int left_shift = 10;
public static final int not = 11;
public static final int twiddle = 12;
public static final int minus = 13;
public static final int plus = 14;
public static final int multiply = 15;
public static final int remainder = 16;
public static final int right_shift = 17;
public static final int equal_equal = 18;
public static final int unsigned_right_shift= 19;
public static final int numberoftables = 20;

public static final int questioncolon = 23;

public static final int not_equal = 29;
public static final int equal = 30;
public static final int instanceof = 31;
public static final int plus_plus = 32;
public static final int minus_minus = 33;
}
