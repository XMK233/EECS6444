/*******************************************************************************
* copyright (c) 2000, 2006 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

public interface isourcemethod extends igenericmethod {

/**
* answer the source end position of the method's declaration.
*/

int getdeclarationsourceend();
/**
* answer the source start position of the method's declaration.
*/

int getdeclarationsourcestart();
/**
* answer the unresolved names of the exception types
* or null if the array is empty.
*
* a name is a simple name or a qualified, dot separated name.
* for example, hashtable or java.util.hashtable.
*/

char[][] getexceptiontypenames();
/**
* answer the source end position of the method's selector.
*/

int getnamesourceend();
/**
* answer the source start position of the method's selector.
*/

int getnamesourcestart();
/**
* answer the unresolved name of the return type
* or null if receiver is a constructor or clinit.
*
* the name is a simple name or a qualified, dot separated name.
* for example, hashtable or java.util.hashtable.
*/

char[] getreturntypename();
/**
* answer the names of the receiver's type parameters
* or null if the array is empty.
*/
char[][] gettypeparameternames();
/**
* answer the array of bound names of the receiver's type parameters
* or null if the array is empty.
*/
char[][][] gettypeparameterbounds();
}
