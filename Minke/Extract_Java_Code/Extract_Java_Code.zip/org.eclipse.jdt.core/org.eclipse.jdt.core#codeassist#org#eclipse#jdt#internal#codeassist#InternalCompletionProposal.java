/*******************************************************************************
* copyright (c) 2004, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import org.eclipse.core.runtime.iprogressmonitor;
import org.eclipse.jdt.core.completionflags;
import org.eclipse.jdt.core.completionproposal;
import org.eclipse.jdt.core.completionrequestor;
import org.eclipse.jdt.core.flags;
import org.eclipse.jdt.core.iaccessrule;
import org.eclipse.jdt.core.icodeassist;
import org.eclipse.jdt.core.icompilationunit;
import org.eclipse.jdt.core.ijavaelement;
import org.eclipse.jdt.core.imethod;
import org.eclipse.jdt.core.ipackagefragmentroot;
import org.eclipse.jdt.core.itype;
import org.eclipse.jdt.core.javamodelexception;
import org.eclipse.jdt.core.signature;
import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.env.ibinarymethod;
import org.eclipse.jdt.internal.compiler.env.ibinarytype;
import org.eclipse.jdt.internal.core.binarytype;
import org.eclipse.jdt.internal.core.javaelement;
import org.eclipse.jdt.internal.core.javamodelmanager;
import org.eclipse.jdt.internal.core.namelookup;
import org.eclipse.jdt.internal.core.sourcemapper;

/**
* internal completion proposal
* @@since 3.1
*/
public class internalcompletionproposal extends completionproposal {
private static object no_attached_source = new object();

protected completionengine completionengine;
protected namelookup namelookup;

protected char[] declarationpackagename;
protected char[] declarationtypename;
protected char[] packagename;
protected char[] typename;
protected char[][] parameterpackagenames;
protected char[][] parametertypenames;

protected char[] originalsignature;

private boolean hasnoparameternamesfromindex = false;
private boolean updatecompletion = false;

protected int accessibility = iaccessrule.k_accessible;

protected boolean isconstructor = false;

/**
* kind of completion request.
*/
private int completionkind;

/**
* offset in original buffer where icodeassist.codecomplete() was
* requested.
*/
private int completionlocation;

/**
* start position (inclusive) of source range in original buffer
* containing the relevant token
* defaults to empty subrange at [0,0).
*/
private int tokenstart = 0;

/**
* end position (exclusive) of source range in original buffer
* containing the relevant token;
* defaults to empty subrange at [0,0).
*/
private int tokenend = 0;

/**
* completion string; defaults to empty string.
*/
private char[] completion = charoperation.no_char;

/**
* start position (inclusive) of source range in original buffer
* to be replaced by completion string;
* defaults to empty subrange at [0,0).
*/
private int replacestart = 0;

/**
* end position (exclusive) of source range in original buffer
* to be replaced by completion string;
* defaults to empty subrange at [0,0).
*/
private int replaceend = 0;

/**
* relevance rating; positive; higher means better;
* defaults to minimum rating.
*/
private int relevance = 1;

/**
* signature of the relevant package or type declaration
* in the context, or <code>null</code> if none.
* defaults to null.
*/
private char[] declarationsignature = null;

/**
* unique key of the relevant package or type declaration
* in the context, or <code>null</code> if none.
* defaults to null.
*/
private char[] declarationkey = null;

/**
* simple name of the method, field,
* member, or variable relevant in the context, or
* <code>null</code> if none.
* defaults to null.
*/
private char[] name = null;

/**
* signature of the method, field type, member type,
* relevant in the context, or <code>null</code> if none.
* defaults to null.
*/
private char[] signature = null;

/**
* unique of the method, field type, member type,
* relevant in the context, or <code>null</code> if none.
* defaults to null.
*/
private char[] key = null;

/**
* array of required completion proposals, or <code>null</code> if none.
* the proposal can not be applied if the required proposals aren't applied.
* defaults to <code>null</code>.
*/
private completionproposal[] requiredproposals;

/**
* modifier flags relevant in the context, or
* <code>flags.accdefault</code> if none.
* defaults to <code>flags.accdefault</code>.
*/
private int flags = flags.accdefault;

/**
* completion flags relevant in the context, or
* <code>completionflags.default</code> if none.
* defaults to <code>completionflags.default</code>.
*/
private int additionalflags = completionflags.default;

/**
* parameter names (for method completions), or
* <code>null</code> if none. lazily computed.
* defaults to <code>null</code>.
*/
private char[][] parameternames = null;

/**
* indicates whether parameter names have been computed.
*/
private boolean parameternamescomputed = false;

protected char[][] findconstructorparameternames(char[] declaringtypepackagename, char[] declaringtypename, char[] selector, char[][] paramtypenames){
if(paramtypenames == null || declaringtypename == null) return null;

char[][] parameters = null;
int length = paramtypenames.length;

char[] tname = charoperation.concat(declaringtypepackagename,declaringtypename,'.');
object cachedtype = this.completionengine.typecache.get(tname);

itype type = null;
if(cachedtype != null) {
if(cachedtype != no_attached_source && cachedtype instanceof binarytype) {
type = (binarytype)cachedtype;
}
} else {
// todo (david) shouldn't it be namelookup.accept_all ?
namelookup.answer answer = this.namelookup.findtype(new string(tname),
false,
namelookup.accept_classes & namelookup.accept_interfaces,
true/* consider secondary types */,
false/* do not wait for indexes */,
false/*don't check restrictions*/,
null);
type = answer == null ? null : answer.type;
if(type instanceof binarytype){
this.completionengine.typecache.put(tname, type);
} else {
type = null;
}
}

if(type != null) {
string[] args = new string[length];
for(int i = 0;	i< length ; i++){
args[i] = new string(paramtypenames[i]);
}
imethod method = type.getmethod(new string(selector),args);

if (this.hasnoparameternamesfromindex) {
ipackagefragmentroot packagefragmentroot = (ipackagefragmentroot)type.getancestor(ijavaelement.package_fragment_root);
if (packagefragmentroot.isarchive() ||
this.completionengine.openedbinarytypes < getopenedbinarytypesthreshold()) {
sourcemapper mapper = ((javaelement)method).getsourcemapper();
if (mapper != null) {
try {
char[][] paramnames = mapper.getmethodparameternames(method);

// map source and try to find parameter names
if(paramnames == null) {
if (!packagefragmentroot.isarchive()) this.completionengine.openedbinarytypes++;
ibinarytype info = (ibinarytype) ((binarytype) type).getelementinfo();
char[] source = mapper.findsource(type, info);
if (source != null){
mapper.mapsource(type, source, info);
}
paramnames = mapper.getmethodparameternames(method);
}

if(paramnames != null) {
parameters = paramnames;
}
} catch(javamodelexception e){
//parameters == null;
}
}
}
} else {
try{
ibinarymethod info = (ibinarymethod) ((javaelement)method).getelementinfo();
char[][] argumentnames = info.getargumentnames();
if (argumentnames != null && argumentnames.length == length) {
parameters = argumentnames;
}
} catch(javamodelexception e){
//parameters == null;
}

try{
parameters = new char[length][];
string[] params = method.getparameternames();
for(int i = 0;	i< length ; i++){
parameters[i] = params[i].tochararray();
}
} catch(javamodelexception e){
parameters = null;
}
}
}

// default parameters name
if(parameters == null) {
parameters = completionengine.createdefaultparameternames(length);
}

return parameters;
}

protected char[][] findmethodparameternames(char[] declaringtypepackagename, char[] declaringtypename, char[] selector, char[][] paramtypenames){
if(paramtypenames == null || declaringtypename == null) return null;

char[][] parameters = null;
int length = paramtypenames.length;

char[] tname = charoperation.concat(declaringtypepackagename,declaringtypename,'.');
object cachedtype = this.completionengine.typecache.get(tname);

itype type = null;
if(cachedtype != null) {
if(cachedtype != no_attached_source && cachedtype instanceof binarytype) {
type = (binarytype)cachedtype;
}
} else {
// todo (david) shouldn't it be namelookup.accept_all ?
namelookup.answer answer = this.namelookup.findtype(new string(tname),
false,
namelookup.accept_classes & namelookup.accept_interfaces,
true/* consider secondary types */,
false/* do not wait for indexes */,
false/*don't check restrictions*/,
null);
type = answer == null ? null : answer.type;
if(type instanceof binarytype){
this.completionengine.typecache.put(tname, type);
} else {
type = null;
}
}

if(type != null) {
string[] args = new string[length];
for(int i = 0;	i< length ; i++){
args[i] = new string(paramtypenames[i]);
}
imethod method = type.getmethod(new string(selector),args);
try{
parameters = new char[length][];
string[] params = method.getparameternames();
for(int i = 0;	i< length ; i++){
parameters[i] = params[i].tochararray();
}
} catch(javamodelexception e){
parameters = null;
}
}

// default parameters name
if(parameters == null) {
parameters = completionengine.createdefaultparameternames(length);
}

return parameters;
}

protected char[] getdeclarationpackagename() {
return this.declarationpackagename;
}

protected char[] getdeclarationtypename() {
return this.declarationtypename;
}

private int getopenedbinarytypesthreshold() {
return javamodelmanager.getjavamodelmanager().getopenablecachesize() / 10;
}

protected char[] getpackagename() {
return this.packagename;
}

protected char[] gettypename() {
return this.typename;
}

protected char[][] getparameterpackagenames() {
return this.parameterpackagenames;
}


protected char[][] getparametertypenames() {
return this.parametertypenames;
}

protected void setdeclarationpackagename(char[] declarationpackagename) {
this.declarationpackagename = declarationpackagename;
}

protected void setdeclarationtypename(char[] declarationtypename) {
this.declarationtypename = declarationtypename;
}

protected void setpackagename(char[] packagename) {
this.packagename = packagename;
}

protected void settypename(char[] typename) {
this.typename = typename;
}

protected void setparameterpackagenames(char[][] parameterpackagenames) {
this.parameterpackagenames = parameterpackagenames;
}

protected void setparametertypenames(char[][] parametertypenames) {
this.parametertypenames = parametertypenames;
}

protected void setaccessibility(int kind) {
this.accessibility = kind;
}

protected void setiscontructor(boolean isconstructor) {
this.isconstructor = isconstructor;
}
public void setoriginalsignature(char[] originalsignature) {
this.originalsignature = originalsignature;
}
/**
* creates a basic completion proposal. all instance
* field have plausible default values unless otherwise noted.
* <p>
* note that the constructors for this class are internal to the
* java model implementation. clients cannot directly create
* completionproposal objects.
* </p>
*
* @@param kind one of the kind constants declared on this class
* @@param completionlocation original offset of code completion request
*/
public internalcompletionproposal(int kind, int completionlocation) {
if ((kind < first_kind)
|| (kind > last_kind)) {
throw new illegalargumentexception();
}
if (this.completion == null || completionlocation < 0) {
// work around for bug 132558 (https://bugs.eclipse.org/bugs/show_bug.cgi?id=132558).
// completionlocation can be -1 if the completion occur at the start of a file or
// the start of a code snippet but this api isn't design to support negative position.
if(this.completion == null || completionlocation != -1) {
throw new illegalargumentexception();
}
completionlocation = 0;
}
this.completionkind = kind;
this.completionlocation = completionlocation;
}

/**
* returns the completion flags relevant in the context, or
* <code>completionflags.default</code> if none.
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
* <li><code>field_import</code> - completion flags
* of the attribute that is referenced. completion flags for
* this proposal kind can only include <code>completionflags.staticimport</code></li>
* <li><code>method_import</code> - completion flags
* of the attribute that is referenced. completion flags for
* this proposal kind can only include <code>completionflags.staticimport</code></li>
* <li><code>type_import</code> - completion flags
* of the attribute that is referenced. completion flags for
* this proposal kind can only include <code>completionflags.staticimport</code></li>
* </ul>
* for other kinds of completion proposals, this method returns
* <code>completionflags.default</code>.
* </p>
*
* @@return the completion flags, or
* <code>completionflags.default</code> if none
* @@see completionflags
*
* @@since 3.3
*/
public int getadditionalflags() {
return this.additionalflags;
}

/**
* sets the completion flags relevant in the context.
* <p>
* if not set, defaults to none.
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param additionalflags the completion flags, or
* <code>completionflags.default</code> if none
*
* @@since 3.3
*/
public void setadditionalflags(int additionalflags) {
this.additionalflags = additionalflags;
}

/**
* returns the kind of completion being proposed.
* <p>
* the set of different kinds of completion proposals is
* expected to change over time. it is strongly recommended
* that clients do <b>not</b> assume that the kind is one of the
* ones they know about, and code defensively for the
* possibility of unexpected future growth.
* </p>
*
* @@return the kind; one of the kind constants
* declared on this class, or possibly a kind unknown
* to the caller
*/
public int getkind() {
return this.completionkind;
}

/**
* returns the character index in the source file buffer
* where source completion was requested (the
* <code>offset</code> parameter to
* <code>icodeassist.codecomplete</code> minus one).
*
* @@return character index in source file buffer
* @@see icodeassist#codecomplete(int,completionrequestor)
*/
// todo (david) https://bugs.eclipse.org/bugs/show_bug.cgi?id=132558
public int getcompletionlocation() {
return this.completionlocation;
}

/**
* returns the character index of the start of the
* subrange in the source file buffer containing the
* relevant token being completed. this
* token is either the identifier or java language keyword
* under, or immediately preceding, the original request
* offset. if the original request offset is not within
* or immediately after an identifier or keyword, then the
* position returned is original request offset and the
* token range is empty.
*
* @@return character index of token start position (inclusive)
*/
public int gettokenstart() {
return this.tokenstart;
}

/**
* returns the character index of the end (exclusive) of the subrange
* in the source file buffer containing the
* relevant token. when there is no relevant token, the
* range is empty
* (<code>getendtoken() == getstarttoken()</code>).
*
* @@return character index of token end position (exclusive)
*/
public int gettokenend() {
return this.tokenend;
}

/**
* sets the character indices of the subrange in the
* source file buffer containing the relevant token being
* completed. this token is either the identifier or
* java language keyword under, or immediately preceding,
* the original request offset. if the original request
* offset is not within or immediately after an identifier
* or keyword, then the source range begins at original
* request offset and is empty.
* <p>
* if not set, defaults to empty subrange at [0,0).
* </p>
*
* @@param startindex character index of token start position (inclusive)
* @@param endindex character index of token end position (exclusive)
*/
public void settokenrange(int startindex, int endindex) {
if (startindex < 0 || endindex < startindex) {
throw new illegalargumentexception();
}
this.tokenstart = startindex;
this.tokenend = endindex;
}

/**
* returns the proposed sequence of characters to insert into the
* source file buffer, replacing the characters at the specified
* source range. the string can be arbitrary; for example, it might
* include not only the name of a method but a set of parentheses.
* <p>
* the client must not modify the array returned.
* </p>
*
* @@return the completion string
*/
public char[] getcompletion() {
if(this.completionkind == method_declaration) {
findparameternames(null);
if(this.updatecompletion) {
this.updatecompletion = false;

if(this.parameternames != null) {
int length = this.parameternames.length;
stringbuffer completionbuffer = new stringbuffer(this.completion.length);

int start = 0;
int end = charoperation.indexof('%', this.completion);

completionbuffer.append(this.completion, start, end - start);

for(int i = 0 ; i < length ; i++){
completionbuffer.append(this.parameternames[i]);
start = end + 1;
end = charoperation.indexof('%', this.completion, start);
if(end > -1){
completionbuffer.append(this.completion, start, end - start);
} else {
completionbuffer.append(this.completion, start, this.completion.length - start);
}
}
int namelength = completionbuffer.length();
this.completion = new char[namelength];
completionbuffer.getchars(0, namelength, this.completion, 0);
}
}
}
return this.completion;
}

/**
* sets the proposed sequence of characters to insert into the
* source file buffer, replacing the characters at the specified
* source range. the string can be arbitrary; for example, it might
* include not only the name of a method but a set of parentheses.
* <p>
* if not set, defaults to an empty character array.
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param completion the completion string
*/
public void setcompletion(char[] completion) {
this.completion = completion;
}

/**
* returns the character index of the start of the
* subrange in the source file buffer to be replaced
* by the completion string. if the subrange is empty
* (<code>getreplaceend() == getreplacestart()</code>),
* the completion string is to be inserted at this
* index.
* <p>
* note that while the token subrange is precisely
* specified, the replacement range is loosely
* constrained and may not bear any direct relation
* to the original request offset. for example,
* it would be possible for a type completion to
* propose inserting an import declaration at the
* top of the compilation unit; or the completion
* might include trailing parentheses and
* punctuation for a method completion.
* </p>
*
* @@return replacement start position (inclusive)
*/
public int getreplacestart() {
return this.replacestart;
}

/**
* returns the character index of the end of the
* subrange in the source file buffer to be replaced
* by the completion string. if the subrange is empty
* (<code>getreplaceend() == getreplacestart()</code>),
* the completion string is to be inserted at this
* index.
*
* @@return replacement end position (exclusive)
*/
public int getreplaceend() {
return this.replaceend;
}

/**
* sets the character indices of the subrange in the
* source file buffer to be replaced by the completion
* string. if the subrange is empty
* (<code>startindex == endindex</code>),
* the completion string is to be inserted at this
* index.
* <p>
* if not set, defaults to empty subrange at [0,0).
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param startindex character index of replacement start position (inclusive)
* @@param endindex character index of replacement end position (exclusive)
*/
public void setreplacerange(int startindex, int endindex) {
if (startindex < 0 || endindex < startindex) {
throw new illegalargumentexception();
}
this.replacestart = startindex;
this.replaceend = endindex;
}

/**
* returns the relative relevance rating of this proposal.
*
* @@return relevance rating of this proposal; ratings are positive; higher means better
*/
public int getrelevance() {
return this.relevance;
}

/**
* sets the relative relevance rating of this proposal.
* <p>
* if not set, defaults to the lowest possible rating (1).
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param rating relevance rating of this proposal; ratings are positive; higher means better
*/
public void setrelevance(int rating) {
if (rating <= 0) {
throw new illegalargumentexception();
}
this.relevance = rating;
}

/**
* returns the type signature or package name of the relevant
* declaration in the context, or <code>null</code> if none.
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
*  <li><code>annotation_attribut_ref</code> - type signature
* of the annotation that declares the attribute that is referenced</li>
* <li><code>anonymous_class_declaration</code> - type signature
* of the type that is being subclassed or implemented</li>
* 	<li><code>field_import</code> - type signature
* of the type that declares the field that is imported</li>
*  <li><code>field_ref</code> - type signature
* of the type that declares the field that is referenced</li>
*  <li><code>field_ref_with_casted_receiver</code> - type signature
* of the type that declares the field that is referenced</li>
* 	<li><code>method_import</code> - type signature
* of the type that declares the method that is imported</li>
*  <li><code>method_ref</code> - type signature
* of the type that declares the method that is referenced</li>
*  <li><code>method_ref_with_casted_receiver</code> - type signature
* of the type that declares the method that is referenced</li>
* 	<li><code>method_declaration</code> - type signature
* of the type that declares the method that is being
* implemented or overridden</li>
* 	<li><code>package_ref</code> - dot-based package
* name of the package that is referenced</li>
* 	<li><code>type_import</code> - dot-based package
* name of the package containing the type that is imported</li>
*  <li><code>type_ref</code> - dot-based package
* name of the package containing the type that is referenced</li>
*  <li><code>potential_method_declaration</code> - type signature
* of the type that declares the method that is being created</li>
* </ul>
* for kinds of completion proposals, this method returns
* <code>null</code>. clients must not modify the array
* returned.
* </p>
*
* @@return a type signature or a package name (depending
* on the kind of completion), or <code>null</code> if none
* @@see signature
*/
public char[] getdeclarationsignature() {
return this.declarationsignature;
}

/**
* returns the key of the relevant
* declaration in the context, or <code>null</code> if none.
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
* <li><code>anonymous_class_declaration</code> - key
* of the type that is being subclassed or implemented</li>
* 	<li><code>method_declaration</code> - key
* of the type that declares the method that is being
* implemented or overridden</li>
* </ul>
* for kinds of completion proposals, this method returns
* <code>null</code>. clients must not modify the array
* returned.
* </p>
*
* @@return a key, or <code>null</code> if none
* @@see org.eclipse.jdt.core.dom.astparser#createasts(icompilationunit[], string[], org.eclipse.jdt.core.dom.astrequestor, iprogressmonitor)
* @@since 3.1
*/
public char[] getdeclarationkey() {
return this.declarationkey;
}

/**
* sets the type or package signature of the relevant
* declaration in the context, or <code>null</code> if none.
* <p>
* if not set, defaults to none.
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param signature the type or package signature, or
* <code>null</code> if none
*/
public void setdeclarationsignature(char[] signature) {
this.declarationsignature = signature;
}

/**
* sets the type or package key of the relevant
* declaration in the context, or <code>null</code> if none.
* <p>
* if not set, defaults to none.
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param key the type or package key, or
* <code>null</code> if none
* @@since 3.1
*/
public void setdeclarationkey(char[] key) {
this.declarationkey = key;
}

/**
* returns the simple name of the method, field,
* member, or variable relevant in the context, or
* <code>null</code> if none.
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
*  <li><code>annotation_attribut_ref</code> - the name of the attribute</li>
* 	<li><code>field_import</code> - the name of the field</li>
*  <li><code>field_ref</code> - the name of the field</li>
*  <li><code>field_ref_with_casted_receiver</code> - the name of the field</li>
* 	<li><code>keyword</code> - the keyword</li>
* 	<li><code>label_ref</code> - the name of the label</li>
* 	<li><code>local_variable_ref</code> - the name of the local variable</li>
* 	<li><code>method_import</code> - the name of the method</li>
*  <li><code>method_ref</code> - the name of the method (the type simple name for constructor)</li>
*  <li><code>method_ref_with_casted_receiver</code> - the name of the method</li>
* 	<li><code>method_declaration</code> - the name of the method (the type simple name for constructor)</li>
* 	<li><code>variable_declaration</code> - the name of the variable</li>
*  <li><code>potential_method_declaration</code> - the name of the method</li>
* </ul>
* for kinds of completion proposals, this method returns
* <code>null</code>. clients must not modify the array
* returned.
* </p>
*
* @@return the keyword, field, method, local variable, or member
* name, or <code>null</code> if none
*/
public char[] getname() {
return this.name;
}


/**
* sets the simple name of the method (type simple name for constructor), field,
* member, or variable relevant in the context, or
* <code>null</code> if none.
* <p>
* if not set, defaults to none.
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param name the keyword, field, method, local variable,
* or member name, or <code>null</code> if none
*/
public void setname(char[] name) {
this.name = name;
}

/**
* returns the signature of the method or type
* relevant in the context, or <code>null</code> if none.
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
* <li><code>annotation_attribut_ref</code> - the type signature
* of the referenced attribute's type</li>
* <li><code>anonymous_class_declaration</code> - method signature
* of the constructor that is being invoked</li>
* 	<li><code>field_import</code> - the type signature
* of the referenced field's type</li>
*  <li><code>field_ref</code> - the type signature
* of the referenced field's type</li>
*  <li><code>field_ref_with_casted_receiver</code> - the type signature
* of the referenced field's type</li>
* 	<li><code>local_variable_ref</code> - the type signature
* of the referenced local variable's type</li>
* 	<li><code>method_import</code> - method signature
* of the method that is imported</li>
*  <li><code>method_ref</code> - method signature
* of the method that is referenced</li>
*  <li><code>method_ref_with_casted_receiver</code> - method signature
* of the method that is referenced</li>
* 	<li><code>method_declaration</code> - method signature
* of the method that is being implemented or overridden</li>
* 	<li><code>type_import</code> - type signature
* of the type that is imported</li>
* 	<li><code>type_ref</code> - type signature
* of the type that is referenced</li>
* 	<li><code>variable_declaration</code> - the type signature
* of the type of the variable being declared</li>
*  <li><code>potential_method_declaration</code> - method signature
* of the method that is being created</li>
* </ul>
* for kinds of completion proposals, this method returns
* <code>null</code>. clients must not modify the array
* returned.
* </p>
*
* @@return the signature, or <code>null</code> if none
* @@see signature
*/
public char[] getsignature() {
return this.signature;
}

/**
* returns the key relevant in the context,
* or <code>null</code> if none.
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
* <li><code>anonymous_class_declaration</code> - method key
* of the constructor that is being invoked, or <code>null</code> if
* the declaring type is an interface</li>
* 	<li><code>method_declaration</code> - method key
* of the method that is being implemented or overridden</li>
* </ul>
* for kinds of completion proposals, this method returns
* <code>null</code>. clients must not modify the array
* returned.
* </p>
*
* @@return the key, or <code>null</code> if none
* @@see org.eclipse.jdt.core.dom.astparser#createasts(icompilationunit[], string[], org.eclipse.jdt.core.dom.astrequestor, iprogressmonitor)
* @@since 3.1
*/
public char[] getkey() {
return this.key;
}

//	/**
//	 * returns the package name of the relevant
//	 * declaration in the context, or <code>null</code> if none.
//	 * <p>
//	 * this field is available for the following kinds of
//	 * completion proposals:
//	 * <ul>
//	 * <li><code>anonymous_class_declaration</code> - the dot-based package name
//	 * of the type that is being subclassed or implemented</li>
//	 * 	<li><code>field_ref</code> - the dot-based package name
//	 * of the type that declares the field that is referenced</li>
//	 * 	<li><code>method_ref</code> - the dot-based package name
//	 * of the type that declares the method that is referenced</li>
//	 * 	<li><code>method_declaration</code> - the dot-based package name
//	 * of the type that declares the method that is being
//	 * implemented or overridden</li>
//	 * </ul>
//	 * for kinds of completion proposals, this method returns
//	 * <code>null</code>. clients must not modify the array
//	 * returned.
//	 * </p>
//	 *
//	 * @@return the dot-based package name, or
//	 * <code>null</code> if none
//	 * @@see #getdeclarationsignature()
//	 * @@see #getsignature()
//	 *
//	 * @@since 3.1
//	 */
//	public char[] getdeclarationpackagename() {
//		return this.declarationpackagename;
//	}
//
//	/**
//	 * returns the type name of the relevant
//	 * declaration in the context without the package fragment,
//	 * or <code>null</code> if none.
//	 * <p>
//	 * this field is available for the following kinds of
//	 * completion proposals:
//	 * <ul>
//	 * <li><code>anonymous_class_declaration</code> - the dot-based type name
//	 * of the type that is being subclassed or implemented</li>
//	 * 	<li><code>field_ref</code> - the dot-based type name
//	 * of the type that declares the field that is referenced
//	 * or an anonymous type instantiation ("new x(){}") if it is an anonymous type</li>
//	 * 	<li><code>method_ref</code> - the dot-based type name
//	 * of the type that declares the method that is referenced
//	 * or an anonymous type instantiation ("new x(){}") if it is an anonymous type</li>
//	 * 	<li><code>method_declaration</code> - the dot-based type name
//	 * of the type that declares the method that is being
//	 * implemented or overridden</li>
//	 * </ul>
//	 * for kinds of completion proposals, this method returns
//	 * <code>null</code>. clients must not modify the array
//	 * returned.
//	 * </p>
//	 *
//	 * @@return the dot-based package name, or
//	 * <code>null</code> if none
//	 * @@see #getdeclarationsignature()
//	 * @@see #getsignature()
//	 *
//	 * @@since 3.1
//	 */
//	public char[] getdeclarationtypename() {
//		return this.declarationtypename;
//	}
//
//	/**
//	 * returns the package name of the method or type
//	 * relevant in the context, or <code>null</code> if none.
//	 * <p>
//	 * this field is available for the following kinds of
//	 * completion proposals:
//	 * <ul>
//	 * 	<li><code>field_ref</code> - the dot-based package name
//	 * of the referenced field's type</li>
//	 * 	<li><code>local_variable_ref</code> - the dot-based package name
//	 * of the referenced local variable's type</li>
//	 * 	<li><code>method_ref</code> -  the dot-based package name
//	 * of the return type of the method that is referenced</li>
//	 * 	<li><code>method_declaration</code> - the dot-based package name
//	 * of the return type of the method that is being implemented
//	 * or overridden</li>
//	 * 	<li><code>package_ref</code> - the dot-based package name
//	 * of the package that is referenced</li>
//	 * 	<li><code>type_ref</code> - the dot-based package name
//	 * of the type that is referenced</li>
//	 * 	<li><code>variable_declaration</code> - the dot-based package name
//	 * of the type of the variable being declared</li>
//	 * </ul>
//	 * for kinds of completion proposals, this method returns
//	 * <code>null</code>. clients must not modify the array
//	 * returned.
//	 * </p>
//	 *
//	 * @@return the package name, or <code>null</code> if none
//	 *
//	 * @@see #getdeclarationsignature()
//	 * @@see #getsignature()
//	 *
//	 * @@since 3.1
//	 */
//	public char[] getpackagename() {
//		return this.packagename;
//	}
//
//	/**
//	 * returns the type name without the package fragment of the method or type
//	 * relevant in the context, or <code>null</code> if none.
//	 * <p>
//	 * this field is available for the following kinds of
//	 * completion proposals:
//	 * <ul>
//	 * 	<li><code>field_ref</code> - the dot-based type name
//	 * of the referenced field's type</li>
//	 * 	<li><code>local_variable_ref</code> - the dot-based type name
//	 * of the referenced local variable's type</li>
//	 * 	<li><code>method_ref</code> -  the dot-based type name
//	 * of the return type of the method that is referenced</li>
//	 * 	<li><code>method_declaration</code> - the dot-based type name
//	 * of the return type of the method that is being implemented
//	 * or overridden</li>
//	 * 	<li><code>type_ref</code> - the dot-based type name
//	 * of the type that is referenced</li>
//	 * 	<li><code>variable_declaration</code> - the dot-based package name
//	 * of the type of the variable being declared</li>
//	 * </ul>
//	 * for kinds of completion proposals, this method returns
//	 * <code>null</code>. clients must not modify the array
//	 * returned.
//	 * </p>
//	 *
//	 * @@return the package name, or <code>null</code> if none
//	 *
//	 * @@see #getdeclarationsignature()
//	 * @@see #getsignature()
//	 *
//	 * @@since 3.1
//	 */
//	public char[] gettypename() {
//		return this.typename;
//	}
//
//	/**
//	 * returns the parameter package names of the method
//	 * relevant in the context, or <code>null</code> if none.
//	 * <p>
//	 * this field is available for the following kinds of
//	 * completion proposals:
//	 * <ul>
//	 * 	<li><code>anonymous_class_declaration</code> - parameter package names
//	 * of the constructor that is being invoked</li>
//	 * 	<li><code>method_ref</code> - parameter package names
//	 * of the method that is referenced</li>
//	 * 	<li><code>method_declaration</code> - parameter package names
//	 * of the method that is being implemented or overridden</li>
//	 * </ul>
//	 * for kinds of completion proposals, this method returns
//	 * <code>null</code>. clients must not modify the array
//	 * returned.
//	 * </p>
//	 *
//	 * @@return the package name, or <code>null</code> if none
//	 *
//	 * @@see #getdeclarationsignature()
//	 * @@see #getsignature()
//	 *
//	 * @@since 3.1
//	 */
//	public char[][] getparameterpackagenames() {
//		return this.parameterpackagenames;
//	}
//
//	/**
//	 * returns the parameter type names without the package fragment of
//	 * the method relevant in the context, or <code>null</code> if none.
//	 * <p>
//	 * this field is available for the following kinds of
//	 * completion proposals:
//	 * <ul>
//	 * 	<li><code>anonymous_class_declaration</code> - parameter type names
//	 * of the constructor that is being invoked</li>
//	 * 	<li><code>method_ref</code> - parameter type names
//	 * of the method that is referenced</li>
//	 * 	<li><code>method_declaration</code> - parameter type names
//	 * of the method that is being implemented or overridden</li>
//	 * </ul>
//	 * for kinds of completion proposals, this method returns
//	 * <code>null</code>. clients must not modify the array
//	 * returned.
//	 * </p>
//	 *
//	 * @@return the package name, or <code>null</code> if none
//	 *
//	 * @@see #getdeclarationsignature()
//	 * @@see #getsignature()
//	 *
//	 * @@since 3.1
//	 */
//	public char[][] getparametertypenames() {
//		return this.parametertypenames;
//	}

/**
* sets the signature of the method, field type, member type,
* relevant in the context, or <code>null</code> if none.
* <p>
* if not set, defaults to none.
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param signature the signature, or <code>null</code> if none
*/
public void setsignature(char[] signature) {
this.signature = signature;
}

/**
* sets the key of the method, field type, member type,
* relevant in the context, or <code>null</code> if none.
* <p>
* if not set, defaults to none.
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param key the key, or <code>null</code> if none
* @@since 3.1
*/
public void setkey(char[] key) {
this.key = key;
}

/**
* returns the modifier flags relevant in the context, or
* <code>flags.accdefault</code> if none.
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
* <li><code>annotation_attribut_ref</code> - modifier flags
* of the attribute that is referenced;
* <li><code>anonymous_class_declaration</code> - modifier flags
* of the constructor that is referenced</li>
* 	<li><code>field_import</code> - modifier flags
* of the field that is imported.</li>
*  <li><code>field_ref</code> - modifier flags
* of the field that is referenced;
* <code>flags.accenum</code> can be used to recognize
* references to enum constants
* </li>
*  <li><code>field_ref_with_casted_receiver</code> - modifier flags
* of the field that is referenced.
* </li>
* 	<li><code>keyword</code> - modifier flag
* corresponding to the modifier keyword</li>
* 	<li><code>local_variable_ref</code> - modifier flags
* of the local variable that is referenced</li>
*  <li><code>method_import</code> - modifier flags
* of the method that is imported;
*  </li>
* 	<li><code>method_ref</code> - modifier flags
* of the method that is referenced;
* <code>flags.accannotation</code> can be used to recognize
* references to annotation type members
* </li>
* <li><code>method_ref_with_casted_receiver</code> - modifier flags
* of the method that is referenced.
* </li>
* <li><code>method_declaration</code> - modifier flags
* for the method that is being implemented or overridden</li>
* <li><code>type_import</code> - modifier flags
* of the type that is imported; <code>flags.accinterface</code>
* can be used to recognize references to interfaces,
* <code>flags.accenum</code> enum types,
* and <code>flags.accannotation</code> annotation types</li>
* <li><code>type_ref</code> - modifier flags
* of the type that is referenced; <code>flags.accinterface</code>
* can be used to recognize references to interfaces,
* <code>flags.accenum</code> enum types,
* and <code>flags.accannotation</code> annotation types
* </li>
* 	<li><code>variable_declaration</code> - modifier flags
* for the variable being declared</li>
* 	<li><code>potential_method_declaration</code> - modifier flags
* for the method that is being created</li>
* </ul>
* for other kinds of completion proposals, this method returns
* <code>flags.accdefault</code>.
* </p>
*
* @@return the modifier flags, or
* <code>flags.accdefault</code> if none
* @@see flags
*/
public int getflags() {
return this.flags;
}

/**
* sets the modifier flags relevant in the context.
* <p>
* if not set, defaults to none.
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param flags the modifier flags, or
* <code>flags.accdefault</code> if none
*/
public void setflags(int flags) {
this.flags = flags;
}

public void sethasnoparameternamesfromindex(boolean hasnoparameternamesfromindex) {
this.hasnoparameternamesfromindex = hasnoparameternamesfromindex;
}

/**
* returns the required completion proposals.
* the proposal can be apply only if these required completion proposals are also applied.
* if the required proposal aren't applied the completion could create completion problems.
*
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
* 	<li><code>field_ref</code> - the allowed required proposals for this kind are:
*   <ul>
*    <li><code>type_ref</code></li>
*    <li><code>type_import</code></li>
*    <li><code>field_import</code></li>
*   </ul>
* </li>
* 	<li><code>method_ref</code> - the allowed required proposals for this kind are:
*   <ul>
*    <li><code>type_ref</code></li>
*    <li><code>type_import</code></li>
*    <li><code>method_import</code></li>
*   </ul>
*  </li>
* </li>
* 	<li><code>type_ref</code> - the allowed required proposals for this kind are:
*   <ul>
*    <li><code>type_ref</code></li>
*   </ul>
*  </li>
* </ul>
* </p>
* <p>
* other kinds of required proposals will be returned in the future, therefore clients of this
* api must allow with {@@link completionrequestor#setallowsrequiredproposals(int, int, boolean)}
* only kinds which are in this list to avoid unexpected results in the future.
* </p>
* <p>
* a required proposal of a given kind is proposed even if {@@link completionrequestor#isignored(int)}
* return <code>true</code> for that kind.
* </p>
* <p>
* a required completion proposal cannot have required completion proposals.
* </p>
*
* @@return the required completion proposals, or <code>null</code> if none.
*
* @@see completionrequestor#setallowsrequiredproposals(int, int,boolean)
*
* @@since 3.3
*/
public completionproposal[] getrequiredproposals() {
return this.requiredproposals;
}


/**
* sets the list of required completion proposals, or <code>null</code> if none.
* <p>
* if not set, defaults to none.
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param proposals the list of required completion proposals, or
* <code>null</code> if none
* @@since 3.3
*/
public void setrequiredproposals(completionproposal[] proposals) {
this.requiredproposals = proposals;
}

/**
* finds the method parameter names.
* this information is relevant to method reference (and
* method declaration proposals). returns <code>null</code>
* if not available or not relevant.
* <p>
* the client must not modify the array returned.
* </p>
* <p>
* <b>note that this is an expensive thing to compute, which may require
* parsing java source files, etc. use sparingly.</b>
* </p>
*
* @@param monitor the progress monitor, or <code>null</code> if none
* @@return the parameter names, or <code>null</code> if none
* or not available or not relevant
*/
public char[][] findparameternames(iprogressmonitor monitor) {
if (!this.parameternamescomputed) {
this.parameternamescomputed = true;

switch(this.completionkind) {
case anonymous_class_declaration:
try {
this.parameternames = findmethodparameternames(
this.declarationpackagename,
this.declarationtypename,
charoperation.lastsegment(this.declarationtypename, '.'),
signature.getparametertypes(this.originalsignature == null ? this.signature : this.originalsignature));
} catch(illegalargumentexception e) {
// protection for invalid signature
if(this.parametertypenames != null) {
this.parameternames =  completionengine.createdefaultparameternames(this.parametertypenames.length);
} else {
this.parameternames = null;
}
}
break;
case anonymous_class_constructor_invocation:
try {
this.parameternames = findconstructorparameternames(
this.declarationpackagename,
this.declarationtypename,
charoperation.lastsegment(this.declarationtypename, '.'),
signature.getparametertypes(this.originalsignature == null ? this.signature : this.originalsignature));
} catch(illegalargumentexception e) {
// protection for invalid signature
if(this.parametertypenames != null) {
this.parameternames =  completionengine.createdefaultparameternames(this.parametertypenames.length);
} else {
this.parameternames = null;
}
}
break;
case method_ref:
case method_ref_with_casted_receiver:
try {
this.parameternames = findmethodparameternames(
this.declarationpackagename,
this.declarationtypename,
this.name,
signature.getparametertypes(this.originalsignature == null ? this.signature : this.originalsignature));
} catch(illegalargumentexception e) {
// protection for invalid signature
if(this.parametertypenames != null) {
this.parameternames =  completionengine.createdefaultparameternames(this.parametertypenames.length);
} else {
this.parameternames = null;
}
}
break;
case constructor_invocation:
try {
this.parameternames = findconstructorparameternames(
this.declarationpackagename,
this.declarationtypename,
this.name,
signature.getparametertypes(this.originalsignature == null ? this.signature : this.originalsignature));
} catch(illegalargumentexception e) {
// protection for invalid signature
if(this.parametertypenames != null) {
this.parameternames =  completionengine.createdefaultparameternames(this.parametertypenames.length);
} else {
this.parameternames = null;
}
}
break;
case method_declaration:
try {
this.parameternames = findmethodparameternames(
this.declarationpackagename,
this.declarationtypename,
this.name,
signature.getparametertypes(this.originalsignature == null ? this.signature : this.originalsignature));
} catch(illegalargumentexception e) {
// protection for invalid signature
if(this.parametertypenames != null) {
this.parameternames =  completionengine.createdefaultparameternames(this.parametertypenames.length);
} else {
this.parameternames = null;
}
}
if(this.parameternames != null) {
this.updatecompletion = true;
}
break;
}
}
return this.parameternames;
}

/**
* sets the method parameter names.
* this information is relevant to method reference (and
* method declaration proposals).
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param parameternames the parameter names, or <code>null</code> if none
*/
public void setparameternames(char[][] parameternames) {
this.parameternames = parameternames;
this.parameternamescomputed = true;
}

/**
* returns the accessibility of the proposal.
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
* 	<li><code>type_ref</code> - accessibility of the type</li>
* </ul>
* for these kinds of completion proposals, this method returns
* {@@link iaccessrule#k_accessible} or {@@link iaccessrule#k_discouraged}
* or {@@link iaccessrule#k_non_accessible}.
* by default this method return {@@link iaccessrule#k_accessible}.
* </p>
*
* @@see iaccessrule
*
* @@return the accessibility of the proposal
*
* @@since 3.1
*/
public int getaccessibility() {
return this.accessibility;
}

/**
* returns whether this proposal is a constructor.
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
* <li><code>method_ref</code> - return <code>true</code>
* if the referenced method is a constructor</li>
* 	<li><code>method_declaration</code> - return <code>true</code>
* if the declared method is a constructor</li>
* </ul>
* for kinds of completion proposals, this method returns
* <code>false</code>.
* </p>
*
* @@return <code>true</code> if the proposal is a constructor.
* @@since 3.1
*/
public boolean isconstructor() {
return this.isconstructor;
}

private int receiverstart;
private int receiverend;
private char[] receiversignature;

/**
* returns the type signature or package name of the relevant
* receiver in the context, or <code>null</code> if none.
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
*  <li><code>field_ref_with_casted_receiver</code> - type signature
* of the type that cast the receiver of the field that is referenced</li>
*  <li><code>method_ref_with_casted_receiver</code> - type signature
* of the type that cast the receiver of the method that is referenced</li>
* </ul>
* for kinds of completion proposals, this method returns
* <code>null</code>. clients must not modify the array
* returned.
* </p>
*
* @@return a type signature or a package name (depending
* on the kind of completion), or <code>null</code> if none
* @@see signature
*
* @@since 3.4
*/
public char[] getreceiversignature() {
return this.receiversignature;
}

/**
* returns the character index of the start of the
* subrange in the source file buffer containing the
* relevant receiver of the member being completed. this
* receiver is an expression.
*
* <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
*  <li><code>field_ref_with_casted_receiver</code></li>
*  <li><code>method_ref_with_casted_receiver</code></li>
* </ul>
* for kinds of completion proposals, this method returns <code>0</code>.
* </p>
*
* @@return character index of receiver start position (inclusive)
*
* @@since 3.4
*/
public int getreceiverstart() {
return this.receiverstart;
}

/**
* returns the character index of the end (exclusive) of the subrange
* in the source file buffer containing the
* relevant receiver of the member being completed.
*
* * <p>
* this field is available for the following kinds of
* completion proposals:
* <ul>
*  <li><code>field_ref_with_casted_receiver</code></li>
*  <li><code>method_ref_with_casted_receiver</code></li>
* </ul>
* for kinds of completion proposals, this method returns <code>0</code>.
* </p>
*
* @@return character index of receiver end position (exclusive)
*
* @@since 3.4
*/
public int getreceiverend() {
return this.receiverend;
}

/**
* sets the type or package signature of the relevant
* receiver in the context, or <code>null</code> if none.
* <p>
* if not set, defaults to none.
* </p>
* <p>
* the completion engine creates instances of this class and sets
* its properties; this method is not intended to be used by other clients.
* </p>
*
* @@param signature the type or package signature, or
* <code>null</code> if none
*
* @@since 3.4
*/
public void setreceiversignature(char[] signature) {
this.receiversignature = signature;
}

/**
* sets the character indices of the subrange in the
* source file buffer containing the relevant receiver
* of the member being completed.
*
* <p>
* if not set, defaults to empty subrange at [0,0).
* </p>
*
* @@param startindex character index of receiver start position (inclusive)
* @@param endindex character index of receiver end position (exclusive)
*
* @@since 3.4
*/
public void setreceiverrange(int startindex, int endindex) {
this.receiverstart = startindex;
this.receiverend = endindex;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append('[');
switch(this.completionkind) {
case completionproposal.anonymous_class_declaration :
buffer.append("anonymous_class_declaration"); //$non-nls-1$
break;
case completionproposal.field_ref :
buffer.append("field_ref"); //$non-nls-1$
break;
case completionproposal.keyword :
buffer.append("keyword"); //$non-nls-1$
break;
case completionproposal.label_ref :
buffer.append("label_ref"); //$non-nls-1$
break;
case completionproposal.local_variable_ref :
buffer.append("local_variable_ref"); //$non-nls-1$
break;
case completionproposal.method_declaration :
buffer.append("method_declaration"); //$non-nls-1$
if(this.isconstructor) {
buffer.append("<constructor>"); //$non-nls-1$
}
break;
case completionproposal.method_ref :
buffer.append("method_ref"); //$non-nls-1$
if(this.isconstructor) {
buffer.append("<constructor>"); //$non-nls-1$
}
break;
case completionproposal.package_ref :
buffer.append("package_ref"); //$non-nls-1$
break;
case completionproposal.type_ref :
buffer.append("type_ref"); //$non-nls-1$
break;
case completionproposal.variable_declaration :
buffer.append("variable_declaration"); //$non-nls-1$
break;
case completionproposal.potential_method_declaration :
buffer.append("potential_method_declaration"); //$non-nls-1$
break;
case completionproposal.method_name_reference :
buffer.append("method_import"); //$non-nls-1$
break;
case completionproposal.annotation_attribute_ref :
buffer.append("annotation_attribute_ref"); //$non-nls-1$
break;
case completionproposal.javadoc_block_tag :
buffer.append("javadoc_block_tag"); //$non-nls-1$
break;
case completionproposal.javadoc_inline_tag :
buffer.append("javadoc_inline_tag"); //$non-nls-1$
break;
case completionproposal.javadoc_field_ref:
buffer.append("javadoc_field_ref"); //$non-nls-1$
break;
case completionproposal.javadoc_method_ref :
buffer.append("javadoc_method_ref"); //$non-nls-1$
break;
case completionproposal.javadoc_type_ref :
buffer.append("javadoc_type_ref"); //$non-nls-1$
break;
case completionproposal.javadoc_param_ref :
buffer.append("javadoc_param_ref"); //$non-nls-1$
break;
case completionproposal.javadoc_value_ref :
buffer.append("javadoc_value_ref"); //$non-nls-1$
break;
case completionproposal.field_import :
buffer.append("field_import"); //$non-nls-1$
break;
case completionproposal.method_import :
buffer.append("method_import"); //$non-nls-1$
break;
case completionproposal.type_import :
buffer.append("type_import"); //$non-nls-1$
break;
case completionproposal.method_ref_with_casted_receiver :
buffer.append("method_ref_with_casted_receiver"); //$non-nls-1$
break;
case completionproposal.field_ref_with_casted_receiver :
buffer.append("field_ref_with_casted_receiver"); //$non-nls-1$
break;
case completionproposal.constructor_invocation :
buffer.append("constructor_invocation"); //$non-nls-1$
break;
case completionproposal.anonymous_class_constructor_invocation :
buffer.append("anonymous_class_constructor_invocation"); //$non-nls-1$
break;
default :
buffer.append("proposal"); //$non-nls-1$
break;

}
buffer.append("]{completion:"); //$non-nls-1$
if (this.completion != null) buffer.append(this.completion);
buffer.append(", declsign:"); //$non-nls-1$
if (this.declarationsignature != null) buffer.append(this.declarationsignature);
buffer.append(", sign:"); //$non-nls-1$
if (this.signature != null) buffer.append(this.signature);
buffer.append(", declkey:"); //$non-nls-1$
if (this.declarationkey != null) buffer.append(this.declarationkey);
buffer.append(", key:"); //$non-nls-1$
if (this.key != null) buffer.append(this.key);
buffer.append(", name:"); //$non-nls-1$
if (this.name != null) buffer.append(this.name);
buffer.append(", replace:["); //$non-nls-1$
buffer.append(this.replacestart);
buffer.append(',');
buffer.append(this.replaceend);
buffer.append("], token:["); //$non-nls-1$
buffer.append(this.tokenstart);
buffer.append(',');
buffer.append(this.tokenend);
buffer.append("], relevance:"); //$non-nls-1$
buffer.append(this.relevance);
buffer.append('}');
return buffer.tostring();
}
}
