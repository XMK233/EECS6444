/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser;

/**
* converter from source element type to parsed compilation unit.
*
* limitation:
* | the source element field does not carry any information for its constant part, thus
* | the converted parse tree will not include any field initializations.
* | therefore, any binary produced by compiling against converted source elements will
* | not take advantage of remote field constant inlining.
* | given the intended purpose of the conversion is to resolve references, this is not
* | a problem.
*
*/

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.argument;
import org.eclipse.jdt.internal.compiler.ast.arrayqualifiedtypereference;
import org.eclipse.jdt.internal.compiler.ast.arraytypereference;
import org.eclipse.jdt.internal.compiler.ast.compilationunitdeclaration;
import org.eclipse.jdt.internal.compiler.ast.constructordeclaration;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.ast.importreference;
import org.eclipse.jdt.internal.compiler.ast.methoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.qualifiedtypereference;
import org.eclipse.jdt.internal.compiler.ast.singletypereference;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.env.isourcefield;
import org.eclipse.jdt.internal.compiler.env.isourceimport;
import org.eclipse.jdt.internal.compiler.env.isourcemethod;
import org.eclipse.jdt.internal.compiler.env.isourcetype;

import org.eclipse.jdt.internal.compiler.lookup.compilermodifiers;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;

public class sourcetypeconverter implements compilermodifiers {

public static final int field = 0x01;
public static final int constructor = 0x02;
public static final int method = 0x04;
public static final int member_type = 0x08;
public static final int field_initialization = 0x10;
public static final int field_and_method = field | constructor | method;
public static final int none = 0;

private int flags;
private compilationunitdeclaration unit;
private parser parser;
private problemreporter problemreporter;

private sourcetypeconverter(int flags, problemreporter problemreporter) {
this.flags = flags;
this.problemreporter = problemreporter;
}

/*
* convert a set of source element types into a parsed compilation unit declaration
* the argument types are then all grouped in the same unit. the argument types must
* at least contain one type.
* can optionally ignore fields & methods or member types or field initialization
*/
public static compilationunitdeclaration buildcompilationunit(
isourcetype[] sourcetypes,
int flags,
problemreporter problemreporter,
compilationresult compilationresult) {

return
new sourcetypeconverter(flags, problemreporter).convert(sourcetypes, compilationresult);
}

/*
* convert a set of source element types into a parsed compilation unit declaration
* the argument types are then all grouped in the same unit. the argument types must
* at least contain one type.
*/
private compilationunitdeclaration convert(isourcetype[] sourcetypes, compilationresult compilationresult) {
isourcetype sourcetype = sourcetypes[0];
if (sourcetype.getname() == null)
return null; // do a basic test that the sourcetype is valid

this.unit = new compilationunitdeclaration(this.problemreporter, compilationresult, 0);
// not filled at this point

/* only positions available */
int start = sourcetype.getnamesourcestart();
int end = sourcetype.getnamesourceend();

/* convert package and imports */
if (sourcetype.getpackagename() != null
&& sourcetype.getpackagename().length > 0)
// if its null then it is defined in the default package
this.unit.currentpackage =
createimportreference(sourcetype.getpackagename(), start, end, false, accdefault);
isourceimport[]  sourceimports = sourcetype.getimports();
int importcount = sourceimports == null ? 0 : sourceimports.length;
this.unit.imports = new importreference[importcount];
for (int i = 0; i < importcount; i++) {
isourceimport sourceimport = sourceimports[i];
this.unit.imports[i] = createimportreference(
sourceimport.getname(),
sourceimport.getdeclarationsourcestart(),
sourceimport.getdeclarationsourceend(),
sourceimport.ondemand(),
sourceimport.getmodifiers());
}
/* convert type(s) */
int typecount = sourcetypes.length;
this.unit.types = new typedeclaration[typecount];
for (int i = 0; i < typecount; i++) {
this.unit.types[i] =
convert(sourcetypes[i], compilationresult);
}
return this.unit;
}

/*
* convert a field source element into a parsed field declaration
*/
private fielddeclaration convert(isourcefield sourcefield, typedeclaration type) {

fielddeclaration field = new fielddeclaration();

int start = sourcefield.getnamesourcestart();
int end = sourcefield.getnamesourceend();

field.name = sourcefield.getname();
field.sourcestart = start;
field.sourceend = end;
field.type = createtypereference(sourcefield.gettypename(), start, end);
field.declarationsourcestart = sourcefield.getdeclarationsourcestart();
field.declarationsourceend = sourcefield.getdeclarationsourceend();
field.modifiers = sourcefield.getmodifiers();

if ((this.flags & field_initialization) != 0) {
/* conversion of field constant */
char[] initializationsource = sourcefield.getinitializationsource();
if (initializationsource != null) {
if (this.parser == null) {
this.parser = new parser(this.problemreporter, true);
}
this.parser.parse(field, type, this.unit, initializationsource);
}
}

return field;
}

/*
* convert a method source element into a parsed method/constructor declaration
*/
private abstractmethoddeclaration convert(isourcemethod sourcemethod, compilationresult compilationresult) {

abstractmethoddeclaration method;

/* only source positions available */
int start = sourcemethod.getnamesourcestart();
int end = sourcemethod.getnamesourceend();

if (sourcemethod.isconstructor()) {
constructordeclaration decl = new constructordeclaration(compilationresult);
decl.isdefaultconstructor = false;
method = decl;
} else {
methoddeclaration decl = new methoddeclaration(compilationresult);
/* convert return type */
decl.returntype =
createtypereference(sourcemethod.getreturntypename(), start, end);
method = decl;
}
method.selector = sourcemethod.getselector();
method.modifiers = sourcemethod.getmodifiers();
method.sourcestart = start;
method.sourceend = end;
method.declarationsourcestart = sourcemethod.getdeclarationsourcestart();
method.declarationsourceend = sourcemethod.getdeclarationsourceend();

/* convert arguments */
char[][] argumenttypenames = sourcemethod.getargumenttypenames();
char[][] argumentnames = sourcemethod.getargumentnames();
int argumentcount = argumenttypenames == null ? 0 : argumenttypenames.length;
long position = (long) start << 32 + end;
method.arguments = new argument[argumentcount];
for (int i = 0; i < argumentcount; i++) {
method.arguments[i] =
new argument(
argumentnames[i],
position,
createtypereference(argumenttypenames[i], start, end),
accdefault);
// do not care whether was final or not
}

/* convert thrown exceptions */
char[][] exceptiontypenames = sourcemethod.getexceptiontypenames();
int exceptioncount = exceptiontypenames == null ? 0 : exceptiontypenames.length;
method.thrownexceptions = new typereference[exceptioncount];
for (int i = 0; i < exceptioncount; i++) {
method.thrownexceptions[i] =
createtypereference(exceptiontypenames[i], start, end);
}
return method;
}

/*
* convert a source element type into a parsed type declaration
*/
private typedeclaration convert(isourcetype sourcetype, compilationresult compilationresult) {
/* create type declaration - can be member type */
typedeclaration type = type = new typedeclaration(compilationresult);
if (sourcetype.getenclosingtype() != null) {
type.bits |= astnode.ismembertypemask;
}
type.name = sourcetype.getname();
int start, end; // only positions available
type.sourcestart = start = sourcetype.getnamesourcestart();
type.sourceend = end = sourcetype.getnamesourceend();
type.modifiers = sourcetype.getmodifiers();
type.declarationsourcestart = sourcetype.getdeclarationsourcestart();
type.declarationsourceend = sourcetype.getdeclarationsourceend();
type.bodyend = type.declarationsourceend;

/* set superclass and superinterfaces */
if (sourcetype.getsuperclassname() != null)
type.superclass =
createtypereference(sourcetype.getsuperclassname(), start, end);
char[][] interfacenames = sourcetype.getinterfacenames();
int interfacecount = interfacenames == null ? 0 : interfacenames.length;
type.superinterfaces = new typereference[interfacecount];
for (int i = 0; i < interfacecount; i++) {
type.superinterfaces[i] = createtypereference(interfacenames[i], start, end);
}
/* convert member types */
if ((this.flags & member_type) != 0) {
isourcetype[] sourcemembertypes = sourcetype.getmembertypes();
int sourcemembertypecount =
sourcemembertypes == null ? 0 : sourcemembertypes.length;
type.membertypes = new typedeclaration[sourcemembertypecount];
for (int i = 0; i < sourcemembertypecount; i++) {
type.membertypes[i] = convert(sourcemembertypes[i], compilationresult);
}
}

/* convert fields */
if ((this.flags & field) != 0) {
isourcefield[] sourcefields = sourcetype.getfields();
int sourcefieldcount = sourcefields == null ? 0 : sourcefields.length;
type.fields = new fielddeclaration[sourcefieldcount];
for (int i = 0; i < sourcefieldcount; i++) {
type.fields[i] = convert(sourcefields[i], type);
}
}

/* convert methods - need to add default constructor if necessary */
boolean needconstructor = (this.flags & constructor) != 0;
boolean needmethod = (this.flags & method) != 0;
if (needconstructor || needmethod) {

isourcemethod[] sourcemethods = sourcetype.getmethods();
int sourcemethodcount = sourcemethods == null ? 0 : sourcemethods.length;

/* source type has a constructor ?           */
/* by default, we assume that one is needed. */
int extraconstructor = 0;
int methodcount = 0;
boolean isinterface = type.isinterface();
if (!isinterface) {
extraconstructor = needconstructor ? 1 : 0;
for (int i = 0; i < sourcemethodcount; i++) {
if (sourcemethods[i].isconstructor()) {
if (needconstructor) {
extraconstructor = 0; // does not need the extra constructor since one constructor already exists.
methodcount++;
}
} else if (needmethod) {
methodcount++;
}
}
} else {
methodcount = needmethod ? sourcemethodcount : 0;
}
type.methods = new abstractmethoddeclaration[methodcount + extraconstructor];
if (extraconstructor != 0) { // add default constructor in first position
type.methods[0] = type.createsinternalconstructor(false, false);
}
int index = 0;
for (int i = 0; i < sourcemethodcount; i++) {
isourcemethod sourcemethod = sourcemethods[i];
boolean isconstructor = sourcemethod.isconstructor();
if ((isconstructor && needconstructor) || (!isconstructor && needmethod)) {
abstractmethoddeclaration method =convert(sourcemethod, compilationresult);
if (isinterface || method.isabstract()) { // fix-up flag
method.modifiers |= accsemicolonbody;
}
type.methods[extraconstructor + index++] = method;
}
}
}

return type;
}

/*
* build an import reference from an import name, e.g. java.lang.*
*/
private importreference createimportreference(
char[] importname,
int start,
int end,
boolean ondemand,
int modifiers) {

char[][] qimportname = charoperation.spliton('.', importname);
long[] positions = new long[qimportname.length];
long position = (long) start << 32 + end;
for (int i = 0; i < qimportname.length; i++) {
positions[i] = position; // dummy positions
}
return new importreference(
qimportname,
positions,
ondemand,
modifiers);
}

/*
* build a type reference from a readable name, e.g. java.lang.object[][]
*/
private typereference createtypereference(
char[] typesignature,
int start,
int end) {

/* count identifiers and dimensions */
int max = typesignature.length;
int dimstart = max;
int dim = 0;
int identcount = 1;
for (int i = 0; i < max; i++) {
switch (typesignature[i]) {
case '[' :
if (dim == 0)
dimstart = i;
dim++;
break;
case '.' :
identcount++;
break;
}
}
/* rebuild identifiers and dimensions */
if (identcount == 1) { // simple type reference
if (dim == 0) {
return new singletypereference(typesignature, (((long) start )<< 32) + end);
} else {
char[] identifier = new char[dimstart];
system.arraycopy(typesignature, 0, identifier, 0, dimstart);
return new arraytypereference(identifier, dim, (((long) start) << 32) + end);
}
} else { // qualified type reference
long[] positions = new long[identcount];
long pos = (((long) start) << 32) + end;
for (int i = 0; i < identcount; i++) {
positions[i] = pos;
}
char[][] identifiers =
charoperation.spliton('.', typesignature, 0, dimstart);
if (dim == 0) {
return new qualifiedtypereference(identifiers, positions);
} else {
return new arrayqualifiedtypereference(identifiers, dim, positions);
}
}
}
}
