/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     nick teryaev - fix for bug (https://bugs.eclipse.org/bugs/show_bug.cgi?id=40752)
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.codegen.opcodes;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.impl.referencecontext;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.extracompilermodifiers;
import org.eclipse.jdt.internal.compiler.lookup.invocationsite;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.missingtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.problemmethodbinding;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.problemreferencebinding;
import org.eclipse.jdt.internal.compiler.lookup.rawtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;

public class messagesend extends expression implements invocationsite {

public expression receiver;
public char[] selector;
public expression[] arguments;
public methodbinding binding;							// exact binding resulting from lookup
public methodbinding syntheticaccessor;						// synthetic accessor for inner-emulation
public typebinding expectedtype;					// for generic method invocation (return type inference)

public long namesourceposition ; //(start<<32)+end

public typebinding actualreceivertype;
public typebinding valuecast; // extra reference type cast to perform on method returned value
public typereference[] typearguments;
public typebinding[] generictypearguments;

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
boolean nonstatic = !this.binding.isstatic();
flowinfo = this.receiver.analysecode(currentscope, flowcontext, flowinfo, nonstatic).unconditionalinits();
if (nonstatic) {
this.receiver.checknpe(currentscope, flowcontext, flowinfo);
}

if (this.arguments != null) {
int length = this.arguments.length;
for (int i = 0; i < length; i++) {
flowinfo = this.arguments[i].analysecode(currentscope, flowcontext, flowinfo).unconditionalinits();
}
}
referencebinding[] thrownexceptions;
if ((thrownexceptions = this.binding.thrownexceptions) != binding.no_exceptions) {
if ((this.bits & astnode.unchecked) != 0 && this.generictypearguments == null) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=277643, align with javac on jls 15.12.2.6
thrownexceptions = currentscope.environment().converttorawtypes(this.binding.thrownexceptions, true, true);
}
// must verify that exceptions potentially thrown by this expression are caught in the method
flowcontext.checkexceptionhandlers(thrownexceptions, this, flowinfo.copy(), currentscope);
// todo (maxime) the copy above is needed because of a side effect into
//               checkexceptionhandlers; consider protecting there instead of here;
//               nullreferencetest#test0510
}
managesyntheticaccessifnecessary(currentscope, flowinfo);
return flowinfo;
}
/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#computeconversion(org.eclipse.jdt.internal.compiler.lookup.scope, org.eclipse.jdt.internal.compiler.lookup.typebinding, org.eclipse.jdt.internal.compiler.lookup.typebinding)
*/
public void computeconversion(scope scope, typebinding runtimetimetype, typebinding compiletimetype) {
if (runtimetimetype == null || compiletimetype == null)
return;
// set the generic cast after the fact, once the type expectation is fully known (no need for strict cast)
if (this.binding != null && this.binding.isvalidbinding()) {
methodbinding originalbinding = this.binding.original();
typebinding originaltype = originalbinding.returntype;
// extra cast needed if method return type is type variable
if (originaltype.leafcomponenttype().istypevariable()) {
typebinding targettype = (!compiletimetype.isbasetype() && runtimetimetype.isbasetype())
? compiletimetype  // unboxing: checkcast before conversion
: runtimetimetype;
this.valuecast = originaltype.genericcast(targettype);
} 	else if (this.binding == scope.environment().arrayclone
&& runtimetimetype.id != typeids.t_javalangobject
&& scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
// from 1.5 source level on, array#clone() resolves to array type, but codegen to #clone()object - thus require extra inserted cast
this.valuecast = runtimetimetype;
}
if (this.valuecast instanceof referencebinding) {
referencebinding referencecast = (referencebinding) this.valuecast;
if (!referencecast.canbeseenby(scope)) {
scope.problemreporter().invalidtype(this,
new problemreferencebinding(
charoperation.spliton('.', referencecast.shortreadablename()),
referencecast,
problemreasons.notvisible));
}
}
}
super.computeconversion(scope, runtimetimetype, compiletimetype);
}

/**
* messagesend code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
// generate receiver/enclosing instance access
methodbinding codegenbinding = this.binding.original();
boolean isstatic = codegenbinding.isstatic();
if (isstatic) {
this.receiver.generatecode(currentscope, codestream, false);
} else if ((this.bits & astnode.depthmask) != 0 && this.receiver.isimplicitthis()) { // outer access ?
// outer method can be reached through emulation if implicit access
referencebinding targettype = currentscope.enclosingsourcetype().enclosingtypeat((this.bits & astnode.depthmask) >> astnode.depthshift);
object[] path = currentscope.getemulationpath(targettype, true /*only exact match*/, false/*consider enclosing arg*/);
codestream.generateouteraccess(path, this, targettype, currentscope);
} else {
this.receiver.generatecode(currentscope, codestream, true);
if ((this.bits & needreceivergenericcast) != 0) {
codestream.checkcast(this.actualreceivertype);
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
// generate arguments
generatearguments(this.binding, this.arguments, currentscope, codestream);
pc = codestream.position;
// actual message invocation
if (this.syntheticaccessor == null){
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenbinding, this.actualreceivertype, this.receiver.isimplicitthis());
if (isstatic){
codestream.invoke(opcodes.opc_invokestatic, codegenbinding, constantpooldeclaringclass);
} else if((this.receiver.issuper()) || codegenbinding.isprivate()){
codestream.invoke(opcodes.opc_invokespecial, codegenbinding, constantpooldeclaringclass);
} else if (constantpooldeclaringclass.isinterface()) { // interface or annotation type
codestream.invoke(opcodes.opc_invokeinterface, codegenbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokevirtual, codegenbinding, constantpooldeclaringclass);
}
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessor, null /* default declaringclass */);
}
// required cast must occur even if no value is required
if (this.valuecast != null) codestream.checkcast(this.valuecast);
if (valuerequired){
// implicit conversion if necessary
codestream.generateimplicitconversion(this.implicitconversion);
} else {
boolean isunboxing = (this.implicitconversion & typeids.unboxing) != 0;
// conversion only generated if unboxing
if (isunboxing) codestream.generateimplicitconversion(this.implicitconversion);
switch (isunboxing ? postconversiontype(currentscope).id : codegenbinding.returntype.id) {
case t_long :
case t_double :
codestream.pop2();
break;
case t_void :
break;
default :
codestream.pop();
}
}
codestream.recordpositionsfrom(pc, (int)(this.namesourceposition >>> 32)); // highlight selector
}
/**
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#generictypearguments()
*/
public typebinding[] generictypearguments() {
return this.generictypearguments;
}

public boolean issuperaccess() {
return this.receiver.issuper();
}
public boolean istypeaccess() {
return this.receiver != null && this.receiver.istypereference();
}
public void managesyntheticaccessifnecessary(blockscope currentscope, flowinfo flowinfo){

if ((flowinfo.tagbits & flowinfo.unreachable) != 0)	return;

// if method from parameterized type got found, use the original method at codegen time
methodbinding codegenbinding = this.binding.original();
if (this.binding.isprivate()){

// depth is set for both implicit and explicit access (see methodbinding#canbeseenby)
if (currentscope.enclosingsourcetype() != codegenbinding.declaringclass){
this.syntheticaccessor = ((sourcetypebinding)codegenbinding.declaringclass).addsyntheticmethod(codegenbinding, false /* not super access there */);
currentscope.problemreporter().needtoemulatemethodaccess(codegenbinding, this);
return;
}

} else if (this.receiver instanceof qualifiedsuperreference){ // qualified super

// qualified super need emulation always
sourcetypebinding destinationtype = (sourcetypebinding)(((qualifiedsuperreference)this.receiver).currentcompatibletype);
this.syntheticaccessor = destinationtype.addsyntheticmethod(codegenbinding, issuperaccess());
currentscope.problemreporter().needtoemulatemethodaccess(codegenbinding, this);
return;

} else if (this.binding.isprotected()){

sourcetypebinding enclosingsourcetype;
if (((this.bits & astnode.depthmask) != 0)
&& codegenbinding.declaringclass.getpackage()
!= (enclosingsourcetype = currentscope.enclosingsourcetype()).getpackage()){

sourcetypebinding currentcompatibletype = (sourcetypebinding)enclosingsourcetype.enclosingtypeat((this.bits & astnode.depthmask) >> astnode.depthshift);
this.syntheticaccessor = currentcompatibletype.addsyntheticmethod(codegenbinding, issuperaccess());
currentscope.problemreporter().needtoemulatemethodaccess(codegenbinding, this);
return;
}
}
}
public int nullstatus(flowinfo flowinfo) {
return flowinfo.unknown;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#postconversiontype(scope)
*/
public typebinding postconversiontype(scope scope) {
typebinding convertedtype = this.resolvedtype;
if (this.valuecast != null)
convertedtype = this.valuecast;
int runtimetype = (this.implicitconversion & typeids.implicit_conversion_mask) >> 4;
switch (runtimetype) {
case t_boolean :
convertedtype = typebinding.boolean;
break;
case t_byte :
convertedtype = typebinding.byte;
break;
case t_short :
convertedtype = typebinding.short;
break;
case t_char :
convertedtype = typebinding.char;
break;
case t_int :
convertedtype = typebinding.int;
break;
case t_float :
convertedtype = typebinding.float;
break;
case t_long :
convertedtype = typebinding.long;
break;
case t_double :
convertedtype = typebinding.double;
break;
default :
}
if ((this.implicitconversion & typeids.boxing) != 0) {
convertedtype = scope.environment().computeboxingtype(convertedtype);
}
return convertedtype;
}

public stringbuffer printexpression(int indent, stringbuffer output){

if (!this.receiver.isimplicitthis()) this.receiver.printexpression(0, output).append('.');
if (this.typearguments != null) {
output.append('<');
int max = this.typearguments.length - 1;
for (int j = 0; j < max; j++) {
this.typearguments[j].print(0, output);
output.append(", ");//$non-nls-1$
}
this.typearguments[max].print(0, output);
output.append('>');
}
output.append(this.selector).append('(') ;
if (this.arguments != null) {
for (int i = 0; i < this.arguments.length ; i ++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.arguments[i].printexpression(0, output);
}
}
return output.append(')');
}

public typebinding resolvetype(blockscope scope) {
// answer the signature return type
// base type promotion

this.constant = constant.notaconstant;
boolean receivercast = false, argscontaincast = false;
if (this.receiver instanceof castexpression) {
this.receiver.bits |= astnode.disableunnecessarycastcheck; // will check later on
receivercast = true;
}
this.actualreceivertype = this.receiver.resolvetype(scope);
boolean receiveristype = this.receiver instanceof namereference && (((namereference) this.receiver).bits & binding.type) != 0;
if (receivercast && this.actualreceivertype != null) {
// due to change of declaring class with receiver type, only identity cast should be notified
if (((castexpression)this.receiver).expression.resolvedtype == this.actualreceivertype) {
scope.problemreporter().unnecessarycast((castexpression)this.receiver);
}
}
// resolve type arguments (for generic constructor call)
if (this.typearguments != null) {
int length = this.typearguments.length;
boolean arghaserror = scope.compileroptions().sourcelevel < classfileconstants.jdk1_5; // typechecks all arguments
this.generictypearguments = new typebinding[length];
for (int i = 0; i < length; i++) {
typereference typereference = this.typearguments[i];
if ((this.generictypearguments[i] = typereference.resolvetype(scope, true /* check bounds*/)) == null) {
arghaserror = true;
}
if (arghaserror && typereference instanceof wildcard) {
scope.problemreporter().illegalusageofwildcard(typereference);
}
}
if (arghaserror) {
if (this.arguments != null) { // still attempt to resolve arguments
for (int i = 0, max = this.arguments.length; i < max; i++) {
this.arguments[i].resolvetype(scope);
}
}
return null;
}
}
// will check for null after args are resolved
typebinding[] argumenttypes = binding.no_parameters;
if (this.arguments != null) {
boolean arghaserror = false; // typechecks all arguments
int length = this.arguments.length;
argumenttypes = new typebinding[length];
for (int i = 0; i < length; i++){
expression argument = this.arguments[i];
if (argument instanceof castexpression) {
argument.bits |= astnode.disableunnecessarycastcheck; // will check later on
argscontaincast = true;
}
if ((argumenttypes[i] = argument.resolvetype(scope)) == null){
arghaserror = true;
}
}
if (arghaserror) {
if (this.actualreceivertype instanceof referencebinding) {
//  record a best guess, for clients who need hint about possible method match
typebinding[] pseudoargs = new typebinding[length];
for (int i = length; --i >= 0;)
pseudoargs[i] = argumenttypes[i] == null ? typebinding.null : argumenttypes[i]; // replace args with errors with null type
this.binding =
this.receiver.isimplicitthis()
? scope.getimplicitmethod(this.selector, pseudoargs, this)
: scope.findmethod((referencebinding) this.actualreceivertype, this.selector, pseudoargs, this);
if (this.binding != null && !this.binding.isvalidbinding()) {
methodbinding closestmatch = ((problemmethodbinding)this.binding).closestmatch;
// record the closest match, for clients who may still need hint about possible method match
if (closestmatch != null) {
if (closestmatch.original().typevariables != binding.no_type_variables) { // generic method
// shouldn't return generic method outside its context, rather convert it to raw method (175409)
closestmatch = scope.environment().createparameterizedgenericmethod(closestmatch.original(), (rawtypebinding)null);
}
this.binding = closestmatch;
methodbinding closestmatchoriginal = closestmatch.original();
if (closestmatchoriginal.isorenclosedbyprivatetype() && !scope.isdefinedinmethod(closestmatchoriginal)) {
// ignore cases where method is used from within inside itself (e.g. direct recursions)
closestmatchoriginal.modifiers |= extracompilermodifiers.acclocallyused;
}
}
}
}
return null;
}
}
if (this.actualreceivertype == null) {
return null;
}
// base type cannot receive any message
if (this.actualreceivertype.isbasetype()) {
scope.problemreporter().errornomethodfor(this, this.actualreceivertype, argumenttypes);
return null;
}
this.binding = this.receiver.isimplicitthis()
? scope.getimplicitmethod(this.selector, argumenttypes, this)
: scope.getmethod(this.actualreceivertype, this.selector, argumenttypes, this);
if (!this.binding.isvalidbinding()) {
if (this.binding.declaringclass == null) {
if (this.actualreceivertype instanceof referencebinding) {
this.binding.declaringclass = (referencebinding) this.actualreceivertype;
} else {
scope.problemreporter().errornomethodfor(this, this.actualreceivertype, argumenttypes);
return null;
}
}
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=245007 avoid secondary errors in case of
// missing super type for anonymous classes ...
referencebinding declaringclass = this.binding.declaringclass;
boolean avoidsecondary = declaringclass != null &&
declaringclass.isanonymoustype() &&
declaringclass.superclass() instanceof missingtypebinding;
if (!avoidsecondary)
scope.problemreporter().invalidmethod(this, this.binding);
methodbinding closestmatch = ((problemmethodbinding)this.binding).closestmatch;
switch (this.binding.problemid()) {
case problemreasons.ambiguous :
break; // no resilience on ambiguous
case problemreasons.notvisible :
case problemreasons.nonstaticreferenceinconstructorinvocation :
case problemreasons.nonstaticreferenceinstaticcontext :
case problemreasons.receivertypenotvisible :
case problemreasons.parameterboundmismatch :
// only steal returntype in cases listed above
if (closestmatch != null) this.resolvedtype = closestmatch.returntype;
break;
}
// record the closest match, for clients who may still need hint about possible method match
if (closestmatch != null) {
this.binding = closestmatch;
methodbinding closestmatchoriginal = closestmatch.original();
if (closestmatchoriginal.isorenclosedbyprivatetype() && !scope.isdefinedinmethod(closestmatchoriginal)) {
// ignore cases where method is used from within inside itself (e.g. direct recursions)
closestmatchoriginal.modifiers |= extracompilermodifiers.acclocallyused;
}
}
return (this.resolvedtype != null && (this.resolvedtype.tagbits & tagbits.hasmissingtype) == 0)
? this.resolvedtype
: null;
}
if ((this.binding.tagbits & tagbits.hasmissingtype) != 0) {
scope.problemreporter().missingtypeinmethod(this, this.binding);
}
final compileroptions compileroptions = scope.compileroptions();
if (!this.binding.isstatic()) {
// the "receiver" must not be a type
if (receiveristype) {
scope.problemreporter().mustuseastaticmethod(this, this.binding);
if (this.actualreceivertype.israwtype()
&& (this.receiver.bits & astnode.ignorerawtypecheck) == 0
&& compileroptions.getseverity(compileroptions.rawtypereference) != problemseverities.ignore) {
scope.problemreporter().rawtypereference(this.receiver, this.actualreceivertype);
}
} else {
// handle indirect inheritance thru variable secondary bound
// receiver may receive generic cast, as part of implicit conversion
typebinding oldreceivertype = this.actualreceivertype;
this.actualreceivertype = this.actualreceivertype.geterasurecompatibletype(this.binding.declaringclass);
this.receiver.computeconversion(scope, this.actualreceivertype, this.actualreceivertype);
if (this.actualreceivertype != oldreceivertype && this.receiver.postconversiontype(scope) != this.actualreceivertype) { // record need for explicit cast at codegen since receiver could not handle it
this.bits |= needreceivergenericcast;
}
}
} else {
// static message invoked through receiver? legal but unoptimal (optional warning).
if (!(this.receiver.isimplicitthis() || this.receiver.issuper() || receiveristype)) {
scope.problemreporter().nonstaticaccesstostaticmethod(this, this.binding);
}
if (!this.receiver.isimplicitthis() && this.binding.declaringclass != this.actualreceivertype) {
scope.problemreporter().indirectaccesstostaticmethod(this, this.binding);
}
}
if (checkinvocationarguments(scope, this.receiver, this.actualreceivertype, this.binding, this.arguments, argumenttypes, argscontaincast, this)) {
this.bits |= astnode.unchecked;
}

//-------message send that are known to fail at compile time-----------
if (this.binding.isabstract()) {
if (this.receiver.issuper()) {
scope.problemreporter().cannotdireclyinvokeabstractmethod(this, this.binding);
}
// abstract private methods cannot occur nor abstract static............
}
if (ismethodusedeprecated(this.binding, scope, true))
scope.problemreporter().deprecatedmethod(this.binding, this);

// from 1.5 source level on, array#clone() returns the array type (but binding still shows object)
if (this.binding == scope.environment().arrayclone && compileroptions.sourcelevel >= classfileconstants.jdk1_5) {
this.resolvedtype = this.actualreceivertype;
} else {
typebinding returntype;
if ((this.bits & astnode.unchecked) != 0 && this.generictypearguments == null) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=277643, align with javac on jls 15.12.2.6
returntype = this.binding.returntype;
if (returntype != null) {
returntype = scope.environment().converttorawtype(returntype.erasure(), true);
}
} else {
returntype = this.binding.returntype;
if (returntype != null) {
returntype = returntype.capture(scope, this.sourceend);
}
}
this.resolvedtype = returntype;
}
if (this.receiver.issuper() && compileroptions.getseverity(compileroptions.overridingmethodwithoutsuperinvocation) != problemseverities.ignore) {
final referencecontext referencecontext = scope.methodscope().referencecontext;
if (referencecontext instanceof abstractmethoddeclaration) {
final abstractmethoddeclaration abstractmethoddeclaration = (abstractmethoddeclaration) referencecontext;
methodbinding enclosingmethodbinding = abstractmethoddeclaration.binding;
if (enclosingmethodbinding.isoverriding()
&& charoperation.equals(this.binding.selector, enclosingmethodbinding.selector)
&& this.binding.areparametersequal(enclosingmethodbinding)) {
abstractmethoddeclaration.bits |= astnode.overridingmethodwithsupercall;
}
}
}
if (this.typearguments != null && this.binding.original().typevariables == binding.no_type_variables) {
scope.problemreporter().unnecessarytypeargumentsformethodinvocation(this.binding, this.generictypearguments, this.typearguments);
}
return (this.resolvedtype.tagbits & tagbits.hasmissingtype) == 0
? this.resolvedtype
: null;
}

public void setactualreceivertype(referencebinding receivertype) {
if (receivertype == null) return; // error scenario only
this.actualreceivertype = receivertype;
}
public void setdepth(int depth) {
this.bits &= ~astnode.depthmask; // flush previous depth if any
if (depth > 0) {
this.bits |= (depth & 0xff) << astnode.depthshift; // encoded on 8 bits
}
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#setexpectedtype(org.eclipse.jdt.internal.compiler.lookup.typebinding)
*/
public void setexpectedtype(typebinding expectedtype) {
this.expectedtype = expectedtype;
}
public void setfieldindex(int depth) {
// ignore for here
}

public void traverse(astvisitor visitor, blockscope blockscope) {
if (visitor.visit(this, blockscope)) {
this.receiver.traverse(visitor, blockscope);
if (this.typearguments != null) {
for (int i = 0, typeargumentslength = this.typearguments.length; i < typeargumentslength; i++) {
this.typearguments[i].traverse(visitor, blockscope);
}
}
if (this.arguments != null) {
int argumentslength = this.arguments.length;
for (int i = 0; i < argumentslength; i++)
this.arguments[i].traverse(visitor, blockscope);
}
}
visitor.endvisit(this, blockscope);
}
}
