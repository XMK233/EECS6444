/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

/**
* syntactic representation of a reference to a generic type.
* note that it might also have a dimension.
*/
public class parameterizedsingletypereference extends arraytypereference {

public typereference[] typearguments;

public parameterizedsingletypereference(char[] name, typereference[] typearguments, int dim, long pos){
super(name, dim, pos);
this.originalsourceend = this.sourceend;
this.typearguments = typearguments;
}
public void checkbounds(scope scope) {
if (this.resolvedtype == null) return;

if (this.resolvedtype.leafcomponenttype() instanceof parameterizedtypebinding) {
parameterizedtypebinding parameterizedtype = (parameterizedtypebinding) this.resolvedtype.leafcomponenttype();
referencebinding currenttype = parameterizedtype.generictype();
typevariablebinding[] typevariables = currenttype.typevariables();
typebinding[] argtypes = parameterizedtype.arguments;
if (argtypes != null && typevariables != null) { // may be null in error cases
parameterizedtype.boundcheck(scope, this.typearguments);
}
}
}
/**
* @@see org.eclipse.jdt.internal.compiler.ast.typereference#copydims(int)
*/
public typereference copydims(int dim) {
return new parameterizedsingletypereference(this.token, this.typearguments, dim, (((long)this.sourcestart)<<32)+this.sourceend);
}

/**
* @@return char[][]
*/
public char [][] getparameterizedtypename(){
stringbuffer buffer = new stringbuffer(5);
buffer.append(this.token).append('<');
for (int i = 0, length = this.typearguments.length; i < length; i++) {
if (i > 0) buffer.append(',');
buffer.append(charoperation.concatwith(this.typearguments[i].getparameterizedtypename(), '.'));
}
buffer.append('>');
int namelength = buffer.length();
char[] name = new char[namelength];
buffer.getchars(0, namelength, name, 0);
int dim = this.dimensions;
if (dim > 0) {
char[] dimchars = new char[dim*2];
for (int i = 0; i < dim; i++) {
int index = i*2;
dimchars[index] = '[';
dimchars[index+1] = ']';
}
name = charoperation.concat(name, dimchars);
}
return new char[][]{ name };
}
/**
* @@see org.eclipse.jdt.internal.compiler.ast.arrayqualifiedtypereference#gettypebinding(org.eclipse.jdt.internal.compiler.lookup.scope)
*/
protected typebinding gettypebinding(scope scope) {
return null; // not supported here - combined with resolvetype(...)
}

/*
* no need to check for reference to raw type per construction
*/
private typebinding internalresolvetype(scope scope, referencebinding enclosingtype, boolean checkbounds) {
// handle the error here
this.constant = constant.notaconstant;
if ((this.bits & astnode.didresolve) != 0) { // is a shared type reference which was already resolved
if (this.resolvedtype != null) { // is a shared type reference which was already resolved
if (this.resolvedtype.isvalidbinding()) {
return this.resolvedtype;
} else {
switch (this.resolvedtype.problemid()) {
case problemreasons.notfound :
case problemreasons.notvisible :
case problemreasons.inheritednamehidesenclosingname :
typebinding type = this.resolvedtype.closestmatch();
return type;
default :
return null;
}
}
}
}
boolean hasgenericerror = false;
referencebinding currenttype;
this.bits |= astnode.didresolve;
if (enclosingtype == null) {
this.resolvedtype = scope.gettype(this.token);
if (this.resolvedtype.isvalidbinding()) {
currenttype = (referencebinding) this.resolvedtype;
} else {
hasgenericerror = true;
reportinvalidtype(scope);
switch (this.resolvedtype.problemid()) {
case problemreasons.notfound :
case problemreasons.notvisible :
case problemreasons.inheritednamehidesenclosingname :
typebinding type = this.resolvedtype.closestmatch();
if (type instanceof referencebinding) {
currenttype = (referencebinding) type;
break;
}
//$fall-through$ - unable to complete type binding, but still resolve type arguments
default :
boolean isclassscope = scope.kind == scope.class_scope;
int arglength = this.typearguments.length;
for (int i = 0; i < arglength; i++) {
typereference typeargument = this.typearguments[i];
if (isclassscope) {
typeargument.resolvetype((classscope) scope);
} else {
typeargument.resolvetype((blockscope) scope, checkbounds);
}
}
return null;
}
// be resilient, still attempt resolving arguments
}
enclosingtype = currenttype.enclosingtype(); // if member type
if (enclosingtype != null) {
enclosingtype = currenttype.isstatic()
? (referencebinding) scope.environment().converttorawtype(enclosingtype, false /*do not force conversion of enclosing types*/)
: scope.environment().converttoparameterizedtype(enclosingtype);
currenttype = scope.environment().createparameterizedtype((referencebinding) currenttype.erasure(), null /* no arg */, enclosingtype);
}
} else { // resolving member type (relatively to enclosingtype)
this.resolvedtype = currenttype = scope.getmembertype(this.token, enclosingtype);
if (!this.resolvedtype.isvalidbinding()) {
hasgenericerror = true;
scope.problemreporter().invalidenclosingtype(this, currenttype, enclosingtype);
return null;
}
if (istypeusedeprecated(currenttype, scope))
scope.problemreporter().deprecatedtype(currenttype, this);
referencebinding currentenclosing = currenttype.enclosingtype();
if (currentenclosing != null && currentenclosing.erasure() != enclosingtype.erasure()) {
enclosingtype = currentenclosing; // inherited member type, leave it associated with its enclosing rather than subtype
}
}

// check generic and arity
boolean isclassscope = scope.kind == scope.class_scope;
typereference keep = null;
if (isclassscope) {
keep = ((classscope) scope).supertypereference;
((classscope) scope).supertypereference = null;
}
int arglength = this.typearguments.length;
typebinding[] argtypes = new typebinding[arglength];
boolean arghaserror = false;
referencebinding currentoriginal = (referencebinding)currenttype.original();
for (int i = 0; i < arglength; i++) {
typereference typeargument = this.typearguments[i];
typebinding argtype = isclassscope
? typeargument.resolvetypeargument((classscope) scope, currentoriginal, i)
: typeargument.resolvetypeargument((blockscope) scope, currentoriginal, i);
if (argtype == null) {
arghaserror = true;
} else {
argtypes[i] = argtype;
}
}
if (arghaserror) {
return null;
}
if (isclassscope) {
((classscope) scope).supertypereference = keep;
if (((classscope) scope).detecthierarchycycle(currentoriginal, this))
return null;
}

typevariablebinding[] typevariables = currentoriginal.typevariables();
if (typevariables == binding.no_type_variables) { // non generic invoked with arguments
boolean iscompliant15 = scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
if ((currentoriginal.tagbits & tagbits.hasmissingtype) == 0) {
if (iscompliant15) { // below 1.5, already reported as syntax error
this.resolvedtype = currenttype;
scope.problemreporter().nongenerictypecannotbeparameterized(0, this, currenttype, argtypes);
return null;
}
}
// resilience do not rebuild a parameterized type unless compliance is allowing it
if (!iscompliant15) {
// array type ?
typebinding type = currenttype;
if (this.dimensions > 0) {
if (this.dimensions > 255)
scope.problemreporter().toomanydimensions(this);
type = scope.createarraytype(type, this.dimensions);
}
if (hasgenericerror)
return type;
return this.resolvedtype = type;
}
// if missing generic type, and compliance >= 1.5, then will rebuild a parameterized binding
} else if (arglength != typevariables.length) { // check arity
scope.problemreporter().incorrectarityforparameterizedtype(this, currenttype, argtypes);
return null;
} else if (!currenttype.isstatic()) {
referencebinding actualenclosing = currenttype.enclosingtype();
if (actualenclosing != null && actualenclosing.israwtype()){
scope.problemreporter().rawmembertypecannotbeparameterized(
this, scope.environment().createrawtype(currentoriginal, actualenclosing), argtypes);
return null;
}
}

parameterizedtypebinding parameterizedtype = scope.environment().createparameterizedtype(currentoriginal, argtypes, enclosingtype);
// check argument type compatibility
if (checkbounds) // otherwise will do it in scope.connecttypevariables() or generic method resolution
parameterizedtype.boundcheck(scope, this.typearguments);
else
scope.deferboundcheck(this);
if (istypeusedeprecated(parameterizedtype, scope))
reportdeprecatedtype(parameterizedtype, scope);

typebinding type = parameterizedtype;
// array type ?
if (this.dimensions > 0) {
if (this.dimensions > 255)
scope.problemreporter().toomanydimensions(this);
type = scope.createarraytype(type, this.dimensions);
}
if (hasgenericerror) {
return type;
}
return this.resolvedtype = type;
}

public stringbuffer printexpression(int indent, stringbuffer output){
output.append(this.token);
output.append("<"); //$non-nls-1$
int max = this.typearguments.length - 1;
for (int i= 0; i < max; i++) {
this.typearguments[i].print(0, output);
output.append(", ");//$non-nls-1$
}
this.typearguments[max].print(0, output);
output.append(">"); //$non-nls-1$
if ((this.bits & isvarargs) != 0) {
for (int i= 0 ; i < this.dimensions - 1; i++) {
output.append("[]"); //$non-nls-1$
}
output.append("..."); //$non-nls-1$
} else {
for (int i= 0 ; i < this.dimensions; i++) {
output.append("[]"); //$non-nls-1$
}
}
return output;
}

public typebinding resolvetype(blockscope scope, boolean checkbounds) {
return internalresolvetype(scope, null, checkbounds);
}

public typebinding resolvetype(classscope scope) {
return internalresolvetype(scope, null, false /*no bounds check in classscope*/);
}

public typebinding resolvetypeenclosing(blockscope scope, referencebinding enclosingtype) {
return internalresolvetype(scope, enclosingtype, true/*check bounds*/);
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
for (int i = 0, max = this.typearguments.length; i < max; i++) {
this.typearguments[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {
if (visitor.visit(this, scope)) {
for (int i = 0, max = this.typearguments.length; i < max; i++) {
this.typearguments[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
