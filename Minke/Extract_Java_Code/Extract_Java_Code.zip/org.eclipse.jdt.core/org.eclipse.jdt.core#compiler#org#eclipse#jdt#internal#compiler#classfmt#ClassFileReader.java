/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

import java.io.file;
import java.io.ioexception;
import java.io.inputstream;
import java.util.arrays;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.codegen.attributenamesconstants;
import org.eclipse.jdt.internal.compiler.env.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.util.util;

public class classfilereader extends classfilestruct implements ibinarytype {

private int accessflags;
private char[] classfilename;
private char[] classname;
private int classnameindex;
private int constantpoolcount;
private annotationinfo[] annotations;
private fieldinfo[] fields;
private int fieldscount;

// initialized in case the .class file is a nested type
private innerclassinfo innerinfo;
private int innerinfoindex;
private innerclassinfo[] innerinfos;
private char[][] interfacenames;
private int interfacescount;
private methodinfo[] methods;
private int methodscount;
private char[] signature;
private char[] sourcename;
private char[] sourcefilename;
private char[] superclassname;
private long tagbits;
private long version;
private char[] enclosingtypename;
private char[][][] missingtypenames;
private int enclosingnameandtypeindex;
private char[] enclosingmethod;

private static string printtypemodifiers(int modifiers) {
java.io.bytearrayoutputstream out = new java.io.bytearrayoutputstream();
java.io.printwriter print = new java.io.printwriter(out);

if ((modifiers & classfileconstants.accpublic) != 0) print.print("public "); //$non-nls-1$
if ((modifiers & classfileconstants.accprivate) != 0) print.print("private "); //$non-nls-1$
if ((modifiers & classfileconstants.accfinal) != 0) print.print("final "); //$non-nls-1$
if ((modifiers & classfileconstants.accsuper) != 0) print.print("super "); //$non-nls-1$
if ((modifiers & classfileconstants.accinterface) != 0) print.print("interface "); //$non-nls-1$
if ((modifiers & classfileconstants.accabstract) != 0) print.print("abstract "); //$non-nls-1$
print.flush();
return out.tostring();
}

public static classfilereader read(file file) throws classformatexception, ioexception {
return read(file, false);
}

public static classfilereader read(file file, boolean fullyinitialize) throws classformatexception, ioexception {
byte classfilebytes[] = util.getfilebytecontent(file);
classfilereader classfilereader = new classfilereader(classfilebytes, file.getabsolutepath().tochararray());
if (fullyinitialize) {
classfilereader.initialize();
}
return classfilereader;
}

public static classfilereader read(inputstream stream, string filename) throws classformatexception, ioexception {
return read(stream, filename, false);
}

public static classfilereader read(inputstream stream, string filename, boolean fullyinitialize) throws classformatexception, ioexception {
byte classfilebytes[] = util.getinputstreamasbytearray(stream, -1);
classfilereader classfilereader = new classfilereader(classfilebytes, filename.tochararray());
if (fullyinitialize) {
classfilereader.initialize();
}
return classfilereader;
}

public static classfilereader read(
java.util.zip.zipfile zip,
string filename)
throws classformatexception, java.io.ioexception {
return read(zip, filename, false);
}

public static classfilereader read(
java.util.zip.zipfile zip,
string filename,
boolean fullyinitialize)
throws classformatexception, java.io.ioexception {
java.util.zip.zipentry ze = zip.getentry(filename);
if (ze == null)
return null;
byte classfilebytes[] = util.getzipentrybytecontent(ze, zip);
classfilereader classfilereader = new classfilereader(classfilebytes, filename.tochararray());
if (fullyinitialize) {
classfilereader.initialize();
}
return classfilereader;
}

public static classfilereader read(string filename) throws classformatexception, java.io.ioexception {
return read(filename, false);
}

public static classfilereader read(string filename, boolean fullyinitialize) throws classformatexception, java.io.ioexception {
return read(new file(filename), fullyinitialize);
}

/**
* @@param classfilebytes actual bytes of a .class file
* @@param filename	actual name of the file that contains the bytes, can be null
*
* @@exception classformatexception
*/
public classfilereader(byte classfilebytes[], char[] filename) throws classformatexception {
this(classfilebytes, filename, false);
}

/**
* @@param classfilebytes byte[]
* 		actual bytes of a .class file
*
* @@param filename char[]
* 		actual name of the file that contains the bytes, can be null
*
* @@param fullyinitialize boolean
* 		flag to fully initialize the new object
* @@exception classformatexception
*/
public classfilereader(byte[] classfilebytes, char[] filename, boolean fullyinitialize) throws classformatexception {
// this method looks ugly but is actually quite simple, the constantpool is constructed
// in 3 passes.  all non-primitive constant pool members that usually refer to other members
// by index are tweaked to have their value in inst vars, this minor cost at read-time makes
// all subsequent uses of the constant pool element faster.
super(classfilebytes, null, 0);
this.classfilename = filename;
int readoffset = 10;
try {
this.version = ((long)u2at(6) << 16) + u2at(4); // major<<16 + minor
this.constantpoolcount = u2at(8);
// pass #1 - fill in all primitive constants
this.constantpooloffsets = new int[this.constantpoolcount];
for (int i = 1; i < this.constantpoolcount; i++) {
int tag = u1at(readoffset);
switch (tag) {
case classfileconstants.utf8tag :
this.constantpooloffsets[i] = readoffset;
readoffset += u2at(readoffset + 1);
readoffset += classfileconstants.constantutf8fixedsize;
break;
case classfileconstants.integertag :
this.constantpooloffsets[i] = readoffset;
readoffset += classfileconstants.constantintegerfixedsize;
break;
case classfileconstants.floattag :
this.constantpooloffsets[i] = readoffset;
readoffset += classfileconstants.constantfloatfixedsize;
break;
case classfileconstants.longtag :
this.constantpooloffsets[i] = readoffset;
readoffset += classfileconstants.constantlongfixedsize;
i++;
break;
case classfileconstants.doubletag :
this.constantpooloffsets[i] = readoffset;
readoffset += classfileconstants.constantdoublefixedsize;
i++;
break;
case classfileconstants.classtag :
this.constantpooloffsets[i] = readoffset;
readoffset += classfileconstants.constantclassfixedsize;
break;
case classfileconstants.stringtag :
this.constantpooloffsets[i] = readoffset;
readoffset += classfileconstants.constantstringfixedsize;
break;
case classfileconstants.fieldreftag :
this.constantpooloffsets[i] = readoffset;
readoffset += classfileconstants.constantfieldreffixedsize;
break;
case classfileconstants.methodreftag :
this.constantpooloffsets[i] = readoffset;
readoffset += classfileconstants.constantmethodreffixedsize;
break;
case classfileconstants.interfacemethodreftag :
this.constantpooloffsets[i] = readoffset;
readoffset += classfileconstants.constantinterfacemethodreffixedsize;
break;
case classfileconstants.nameandtypetag :
this.constantpooloffsets[i] = readoffset;
readoffset += classfileconstants.constantnameandtypefixedsize;
}
}
// read and validate access flags
this.accessflags = u2at(readoffset);
readoffset += 2;

// read the classname, use exception handlers to catch bad format
this.classnameindex = u2at(readoffset);
this.classname = getconstantclassnameat(this.classnameindex);
readoffset += 2;

// read the superclass name, can be null for java.lang.object
int superclassnameindex = u2at(readoffset);
readoffset += 2;
// if superclassnameindex is equals to 0 there is no need to set a value for the
// field this.superclassname. null is fine.
if (superclassnameindex != 0) {
this.superclassname = getconstantclassnameat(superclassnameindex);
}

// read the interfaces, use exception handlers to catch bad format
this.interfacescount = u2at(readoffset);
readoffset += 2;
if (this.interfacescount != 0) {
this.interfacenames = new char[this.interfacescount][];
for (int i = 0; i < this.interfacescount; i++) {
this.interfacenames[i] = getconstantclassnameat(u2at(readoffset));
readoffset += 2;
}
}
// read the fields, use exception handlers to catch bad format
this.fieldscount = u2at(readoffset);
readoffset += 2;
if (this.fieldscount != 0) {
fieldinfo field;
this.fields = new fieldinfo[this.fieldscount];
for (int i = 0; i < this.fieldscount; i++) {
field = fieldinfo.createfield(this.reference, this.constantpooloffsets, readoffset);
this.fields[i] = field;
readoffset += field.sizeinbytes();
}
}
// read the methods
this.methodscount = u2at(readoffset);
readoffset += 2;
if (this.methodscount != 0) {
this.methods = new methodinfo[this.methodscount];
boolean isannotationtype = (this.accessflags & classfileconstants.accannotation) != 0;
for (int i = 0; i < this.methodscount; i++) {
this.methods[i] = isannotationtype
? annotationmethodinfo.createannotationmethod(this.reference, this.constantpooloffsets, readoffset)
: methodinfo.createmethod(this.reference, this.constantpooloffsets, readoffset);
readoffset += this.methods[i].sizeinbytes();
}
}

// read the attributes
int attributescount = u2at(readoffset);
readoffset += 2;

for (int i = 0; i < attributescount; i++) {
int utf8offset = this.constantpooloffsets[u2at(readoffset)];
char[] attributename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
if (attributename.length == 0) {
readoffset += (6 + u4at(readoffset + 2));
continue;
}
switch(attributename[0] ) {
case 'e' :
if (charoperation.equals(attributename, attributenamesconstants.enclosingmethodname)) {
utf8offset =
this.constantpooloffsets[u2at(this.constantpooloffsets[u2at(readoffset + 6)] + 1)];
this.enclosingtypename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
this.enclosingnameandtypeindex = u2at(readoffset + 8);
}
break;
case 'd' :
if (charoperation.equals(attributename, attributenamesconstants.deprecatedname)) {
this.accessflags |= classfileconstants.accdeprecated;
}
break;
case 'i' :
if (charoperation.equals(attributename, attributenamesconstants.innerclassname)) {
int inneroffset = readoffset + 6;
int number_of_classes = u2at(inneroffset);
if (number_of_classes != 0) {
inneroffset+= 2;
this.innerinfos = new innerclassinfo[number_of_classes];
for (int j = 0; j < number_of_classes; j++) {
this.innerinfos[j] =
new innerclassinfo(this.reference, this.constantpooloffsets, inneroffset);
if (this.classnameindex == this.innerinfos[j].innerclassnameindex) {
this.innerinfo = this.innerinfos[j];
this.innerinfoindex = j;
}
inneroffset += 8;
}
if (this.innerinfo != null) {
char[] enclosingtype = this.innerinfo.getenclosingtypename();
if (enclosingtype != null) {
this.enclosingtypename = enclosingtype;
}
}
}
} else if (charoperation.equals(attributename, attributenamesconstants.inconsistenthierarchy)) {
this.tagbits |= tagbits.hierarchyhasproblems;
}
break;
case 's' :
if (attributename.length > 2) {
switch(attributename[1]) {
case 'o' :
if (charoperation.equals(attributename, attributenamesconstants.sourcename)) {
utf8offset = this.constantpooloffsets[u2at(readoffset + 6)];
this.sourcefilename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
}
break;
case 'y' :
if (charoperation.equals(attributename, attributenamesconstants.syntheticname)) {
this.accessflags |= classfileconstants.accsynthetic;
}
break;
case 'i' :
if (charoperation.equals(attributename, attributenamesconstants.signaturename)) {
utf8offset = this.constantpooloffsets[u2at(readoffset + 6)];
this.signature = utf8at(utf8offset + 3, u2at(utf8offset + 1));
}
}
}
break;
case 'r' :
if (charoperation.equals(attributename, attributenamesconstants.runtimevisibleannotationsname)) {
decodeannotations(readoffset, true);
} else if (charoperation.equals(attributename, attributenamesconstants.runtimeinvisibleannotationsname)) {
decodeannotations(readoffset, false);
}
break;
case 'm' :
if (charoperation.equals(attributename, attributenamesconstants.missingtypesname)) {
// decode the missing types
int missingtypeoffset = readoffset + 6;
int numberofmissingtypes = u2at(missingtypeoffset);
if (numberofmissingtypes != 0) {
this.missingtypenames = new char[numberofmissingtypes][][];
missingtypeoffset += 2;
for (int j = 0; j < numberofmissingtypes; j++) {
utf8offset = this.constantpooloffsets[u2at(this.constantpooloffsets[u2at(missingtypeoffset)] + 1)];
char[] missingtypeconstantpoolname = utf8at(utf8offset + 3, u2at(utf8offset + 1));
this.missingtypenames[j] = charoperation.spliton('/', missingtypeconstantpoolname);
missingtypeoffset += 2;
}
}
}
}
readoffset += (6 + u4at(readoffset + 2));
}
if (fullyinitialize) {
initialize();
}
} catch(classformatexception e) {
throw e;
} catch (exception e) {
throw new classformatexception(
classformatexception.errtruncatedinput,
readoffset);
}
}

/**
* answer the receiver's access flags.  the value of the access_flags
*	item is a mask of modifiers used with class and interface declarations.
*  @@return int
*/
public int accessflags() {
return this.accessflags;
}

private void decodeannotations(int offset, boolean runtimevisible) {
int numberofannotations = u2at(offset + 6);
if (numberofannotations > 0) {
int readoffset = offset + 8;
annotationinfo[] newinfos = null;
int newinfocount = 0;
for (int i = 0; i < numberofannotations; i++) {
// with the last parameter being 'false', the data structure will not be flushed out
annotationinfo newinfo = new annotationinfo(this.reference, this.constantpooloffsets, readoffset, runtimevisible, false);
readoffset += newinfo.readoffset;
long standardtagbits = newinfo.standardannotationtagbits;
if (standardtagbits != 0) {
this.tagbits |= standardtagbits;
} else {
if (newinfos == null)
newinfos = new annotationinfo[numberofannotations - i];
newinfos[newinfocount++] = newinfo;
}
}
if (newinfos == null)
return; // nothing to record in this.annotations

if (this.annotations == null) {
if (newinfocount != newinfos.length)
system.arraycopy(newinfos, 0, newinfos = new annotationinfo[newinfocount], 0, newinfocount);
this.annotations = newinfos;
} else {
int length = this.annotations.length;
annotationinfo[] temp = new annotationinfo[length + newinfocount];
system.arraycopy(this.annotations, 0, temp, 0, length);
system.arraycopy(newinfos, 0, temp, length, newinfocount);
this.annotations = temp;
}
}
}

/**
* @@return the annotations or null if there is none.
*/
public ibinaryannotation[] getannotations() {
return this.annotations;
}

/**
* answer the char array that corresponds to the class name of the constant class.
* constantpoolindex is the index in the constant pool that is a constant class entry.
*
* @@param constantpoolindex int
* @@return char[]
*/
private char[] getconstantclassnameat(int constantpoolindex) {
int utf8offset = this.constantpooloffsets[u2at(this.constantpooloffsets[constantpoolindex] + 1)];
return utf8at(utf8offset + 3, u2at(utf8offset + 1));
}

/**
* answer the int array that corresponds to all the offsets of each entry in the constant pool
*
* @@return int[]
*/
public int[] getconstantpooloffsets() {
return this.constantpooloffsets;
}

public char[] getenclosingmethod() {
if (this.enclosingnameandtypeindex <= 0) {
return null;
}
if (this.enclosingmethod == null) {
// read the name
stringbuffer buffer = new stringbuffer();

int nameandtypeoffset = this.constantpooloffsets[this.enclosingnameandtypeindex];
int utf8offset = this.constantpooloffsets[u2at(nameandtypeoffset + 1)];
buffer.append(utf8at(utf8offset + 3, u2at(utf8offset + 1)));

utf8offset = this.constantpooloffsets[u2at(nameandtypeoffset + 3)];
buffer.append(utf8at(utf8offset + 3, u2at(utf8offset + 1)));

this.enclosingmethod = string.valueof(buffer).tochararray();
}
return this.enclosingmethod;
}

/*
* answer the resolved compoundname of the enclosing type
* or null if the receiver is a top level type.
*/
public char[] getenclosingtypename() {
return this.enclosingtypename;
}

/**
* answer the receiver's this.fields or null if the array is empty.
* @@return org.eclipse.jdt.internal.compiler.api.ibinaryfield[]
*/
public ibinaryfield[] getfields() {
return this.fields;
}

/**
* @@see org.eclipse.jdt.internal.compiler.env.idependent#getfilename()
*/
public char[] getfilename() {
return this.classfilename;
}

public char[] getgenericsignature() {
return this.signature;
}

/**
* answer the source name if the receiver is a inner type. return null if it is an anonymous class or if the receiver is a top-level class.
* e.g.
* public class a {
*	public class b {
*	}
*	public void foo() {
*		class c {}
*	}
*	public runnable bar() {
*		return new runnable() {
*			public void run() {}
*		};
*	}
* }
* it returns {'b'} for the member a$b
* it returns null for a
* it returns {'c'} for the local class a$1$c
* it returns null for the anonymous a$1
* @@return char[]
*/
public char[] getinnersourcename() {
if (this.innerinfo != null)
return this.innerinfo.getsourcename();
return null;
}

/**
* answer the resolved names of the receiver's interfaces in the
* class file format as specified in section 4.2 of the java 2 vm spec
* or null if the array is empty.
*
* for example, java.lang.string is java/lang/string.
* @@return char[][]
*/
public char[][] getinterfacenames() {
return this.interfacenames;
}

/**
* answer the receiver's nested types or null if the array is empty.
*
* this nested type info is extracted from the inner class attributes. ask the
* name environment to find a member type using its compound name
*
* @@return org.eclipse.jdt.internal.compiler.api.ibinarynestedtype[]
*/
public ibinarynestedtype[] getmembertypes() {
// we might have some member types of the current type
if (this.innerinfos == null) return null;

int length = this.innerinfos.length;
int startingindex = this.innerinfo != null ? this.innerinfoindex + 1 : 0;
if (length != startingindex) {
ibinarynestedtype[] membertypes =
new ibinarynestedtype[length - this.innerinfoindex];
int membertypeindex = 0;
for (int i = startingindex; i < length; i++) {
innerclassinfo currentinnerinfo = this.innerinfos[i];
int outerclassnameidx = currentinnerinfo.outerclassnameindex;
int innernameindex = currentinnerinfo.innernameindex;
/*
* checking that outerclassnameidx is different from 0 should be enough to determine if an inner class
* attribute entry is a member class, but due to the bug:
* http://dev.eclipse.org/bugs/show_bug.cgi?id=14592
* we needed to add an extra check. so we check that innernameindex is different from 0 as well.
*
* https://bugs.eclipse.org/bugs/show_bug.cgi?id=49879
* from javamail 1.2, the class javax.mail.folder contains an anonymous class in the
* terminatequeue() method for which the inner attribute is boggus.
* outerclassnameidx is not 0, innernameindex is not 0, but the sourcename length is 0.
* so i added this extra check to filter out this anonymous class from the
* member types.
*/
if (outerclassnameidx != 0
&& innernameindex != 0
&& outerclassnameidx == this.classnameindex
&& currentinnerinfo.getsourcename().length != 0) {
membertypes[membertypeindex++] = currentinnerinfo;
}
}
if (membertypeindex == 0) return null;
if (membertypeindex != membertypes.length) {
// we need to resize the membertypes array. some local or anonymous classes
// are present in the current class.
system.arraycopy(
membertypes,
0,
(membertypes = new ibinarynestedtype[membertypeindex]),
0,
membertypeindex);
}
return membertypes;
}
return null;
}

/**
* answer the receiver's this.methods or null if the array is empty.
* @@return org.eclipse.jdt.internal.compiler.api.env.ibinarymethod[]
*/
public ibinarymethod[] getmethods() {
return this.methods;
}

/*
public static void main(string[] args) throws classformatexception, ioexception {
if (args == null || args.length != 1) {
system.err.println("classfilereader <filename>"); //$non-nls-1$
system.exit(1);
}
file file = new file(args[0]);
classfilereader reader = read(file, true);
if (reader.annotations != null) {
system.err.println();
for (int i = 0; i < reader.annotations.length; i++)
system.err.println(reader.annotations[i]);
}
system.err.print("class "); //$non-nls-1$
system.err.print(reader.getname());
char[] superclass = reader.getsuperclassname();
if (superclass != null) {
system.err.print(" extends "); //$non-nls-1$
system.err.print(superclass);
}
system.err.println();
char[][] interfaces = reader.getinterfacenames();
if (interfaces != null && interfaces.length > 0) {
system.err.print(" implements "); //$non-nls-1$
for (int i = 0; i < interfaces.length; i++) {
if (i != 0) system.err.print(", "); //$non-nls-1$
system.err.println(interfaces[i]);
}
}
system.err.println();
system.err.println('{');
if (reader.fields != null) {
for (int i = 0; i < reader.fields.length; i++) {
system.err.println(reader.fields[i]);
system.err.println();
}
}
if (reader.methods != null) {
for (int i = 0; i < reader.methods.length; i++) {
system.err.println(reader.methods[i]);
system.err.println();
}
}
system.err.println();
system.err.println('}');
}
*/
public char[][][] getmissingtypenames() {
return this.missingtypenames;
}

/**
* answer an int whose bits are set according the access constants
* defined by the vm spec.
* set the accdeprecated and accsynthetic bits if necessary
* @@return int
*/
public int getmodifiers() {
int modifiers;
if (this.innerinfo != null) {
modifiers = this.innerinfo.getmodifiers()
| (this.accessflags & classfileconstants.accdeprecated)
| (this.accessflags & classfileconstants.accsynthetic);
} else {
modifiers = this.accessflags;
}
return modifiers;
}

/**
* answer the resolved name of the type in the
* class file format as specified in section 4.2 of the java 2 vm spec.
*
* for example, java.lang.string is java/lang/string.
* @@return char[]
*/
public char[] getname() {
return this.classname;
}

public char[] getsourcename() {
if (this.sourcename != null)
return this.sourcename;

char[] name = getinnersourcename(); // member or local scenario
if (name == null) {
name = getname(); // extract from full name
int start;
if (isanonymous()) {
start = charoperation.indexof('$', name, charoperation.lastindexof('/', name) + 1) + 1;
} else {
start = charoperation.lastindexof('/', name) + 1;
}
if (start > 0) {
char[] newname = new char[name.length - start];
system.arraycopy(name, start, newname, 0, newname.length);
name = newname;
}
}
return this.sourcename = name;
}

/**
* answer the resolved name of the receiver's superclass in the
* class file format as specified in section 4.2 of the java 2 vm spec
* or null if it does not have one.
*
* for example, java.lang.string is java/lang/string.
* @@return char[]
*/
public char[] getsuperclassname() {
return this.superclassname;
}

public long gettagbits() {
return this.tagbits;
}

/**
* answer the major/minor version defined in this class file according to the vm spec.
* as a long: (major<<16)+minor
* @@return the major/minor version found
*/
public long getversion() {
return this.version;
}

private boolean hasnonsyntheticfieldchanges(fieldinfo[] currentfieldinfos, fieldinfo[] otherfieldinfos) {
int length1 = currentfieldinfos == null ? 0 : currentfieldinfos.length;
int length2 = otherfieldinfos == null ? 0 : otherfieldinfos.length;
int index1 = 0;
int index2 = 0;

end : while (index1 < length1 && index2 < length2) {
while (currentfieldinfos[index1].issynthetic()) {
if (++index1 >= length1) break end;
}
while (otherfieldinfos[index2].issynthetic()) {
if (++index2 >= length2) break end;
}
if (hasstructuralfieldchanges(currentfieldinfos[index1++], otherfieldinfos[index2++]))
return true;
}

while (index1 < length1) {
if (!currentfieldinfos[index1++].issynthetic()) return true;
}
while (index2 < length2) {
if (!otherfieldinfos[index2++].issynthetic()) return true;
}
return false;
}

private boolean hasnonsyntheticmethodchanges(methodinfo[] currentmethodinfos, methodinfo[] othermethodinfos) {
int length1 = currentmethodinfos == null ? 0 : currentmethodinfos.length;
int length2 = othermethodinfos == null ? 0 : othermethodinfos.length;
int index1 = 0;
int index2 = 0;

methodinfo m;
end : while (index1 < length1 && index2 < length2) {
while ((m = currentmethodinfos[index1]).issynthetic() || m.isclinit()) {
if (++index1 >= length1) break end;
}
while ((m = othermethodinfos[index2]).issynthetic() || m.isclinit()) {
if (++index2 >= length2) break end;
}
if (hasstructuralmethodchanges(currentmethodinfos[index1++], othermethodinfos[index2++]))
return true;
}

while (index1 < length1) {
if (!((m = currentmethodinfos[index1++]).issynthetic() || m.isclinit())) return true;
}
while (index2 < length2) {
if (!((m = othermethodinfos[index2++]).issynthetic() || m.isclinit())) return true;
}
return false;
}

/**
* check if the receiver has structural changes compare to the byte array in argument.
* structural changes are:
* - modifiers changes for the class, the this.fields or the this.methods
* - signature changes for this.fields or this.methods.
* - changes in the number of this.fields or this.methods
* - changes for field constants
* - changes for thrown exceptions
* - change for the super class or any super interfaces.
* - changes for member types name or modifiers
* if any of these changes occurs, the method returns true. false otherwise.
* the synthetic fields are included and the members are not required to be sorted.
* @@param newbytes the bytes of the .class file we want to compare the receiver to
* @@return boolean returns true is there is a structural change between the two .class files, false otherwise
*/
public boolean hasstructuralchanges(byte[] newbytes) {
return hasstructuralchanges(newbytes, true, true);
}

/**
* check if the receiver has structural changes compare to the byte array in argument.
* structural changes are:
* - modifiers changes for the class, the this.fields or the this.methods
* - signature changes for this.fields or this.methods.
* - changes in the number of this.fields or this.methods
* - changes for field constants
* - changes for thrown exceptions
* - change for the super class or any super interfaces.
* - changes for member types name or modifiers
* if any of these changes occurs, the method returns true. false otherwise.
* @@param newbytes the bytes of the .class file we want to compare the receiver to
* @@param orderrequired a boolean indicating whether the members should be sorted or not
* @@param excludessynthetic a boolean indicating whether the synthetic members should be used in the comparison
* @@return boolean returns true is there is a structural change between the two .class files, false otherwise
*/
public boolean hasstructuralchanges(byte[] newbytes, boolean orderrequired, boolean excludessynthetic) {
try {
classfilereader newclassfile =
new classfilereader(newbytes, this.classfilename);
// type level comparison
// modifiers
if (getmodifiers() != newclassfile.getmodifiers())
return true;

// only consider a portion of the tagbits which indicate a structural change for dependents
// e.g. @@override change has no influence outside
long onlystructuraltagbits = tagbits.annotationtargetmask // different @@target status ?
| tagbits.annotationdeprecated // different @@deprecated status ?
| tagbits.annotationretentionmask // different @@retention status ?
| tagbits.hierarchyhasproblems; // different hierarchy status ?

// meta-annotations
if ((gettagbits() & onlystructuraltagbits) != (newclassfile.gettagbits() & onlystructuraltagbits))
return true;
// annotations
if (hasstructuralannotationchanges(getannotations(), newclassfile.getannotations()))
return true;

// generic signature
if (!charoperation.equals(getgenericsignature(), newclassfile.getgenericsignature()))
return true;
// superclass
if (!charoperation.equals(getsuperclassname(), newclassfile.getsuperclassname()))
return true;
// interfaces
char[][] newinterfacesnames = newclassfile.getinterfacenames();
if (this.interfacenames != newinterfacesnames) { // typeconstants.nosuperinterfaces
int newinterfaceslength = newinterfacesnames == null ? 0 : newinterfacesnames.length;
if (newinterfaceslength != this.interfacescount)
return true;
for (int i = 0, max = this.interfacescount; i < max; i++)
if (!charoperation.equals(this.interfacenames[i], newinterfacesnames[i]))
return true;
}

// member types
ibinarynestedtype[] currentmembertypes = getmembertypes();
ibinarynestedtype[] othermembertypes = newclassfile.getmembertypes();
if (currentmembertypes != othermembertypes) { // typeconstants.nomembertypes
int currentmembertypelength = currentmembertypes == null ? 0 : currentmembertypes.length;
int othermembertypelength = othermembertypes == null ? 0 : othermembertypes.length;
if (currentmembertypelength != othermembertypelength)
return true;
for (int i = 0; i < currentmembertypelength; i++)
if (!charoperation.equals(currentmembertypes[i].getname(), othermembertypes[i].getname())
|| currentmembertypes[i].getmodifiers() != othermembertypes[i].getmodifiers())
return true;
}

// fields
fieldinfo[] otherfieldinfos = (fieldinfo[]) newclassfile.getfields();
int otherfieldinfoslength = otherfieldinfos == null ? 0 : otherfieldinfos.length;
boolean comparefields = true;
if (this.fieldscount == otherfieldinfoslength) {
int i = 0;
for (; i < this.fieldscount; i++)
if (hasstructuralfieldchanges(this.fields[i], otherfieldinfos[i])) break;
if ((comparefields = i != this.fieldscount) && !orderrequired && !excludessynthetic)
return true;
}
if (comparefields) {
if (this.fieldscount != otherfieldinfoslength && !excludessynthetic)
return true;
if (orderrequired) {
if (this.fieldscount != 0)
arrays.sort(this.fields);
if (otherfieldinfoslength != 0)
arrays.sort(otherfieldinfos);
}
if (excludessynthetic) {
if (hasnonsyntheticfieldchanges(this.fields, otherfieldinfos))
return true;
} else {
for (int i = 0; i < this.fieldscount; i++)
if (hasstructuralfieldchanges(this.fields[i], otherfieldinfos[i]))
return true;
}
}

// methods
methodinfo[] othermethodinfos = (methodinfo[]) newclassfile.getmethods();
int othermethodinfoslength = othermethodinfos == null ? 0 : othermethodinfos.length;
boolean comparemethods = true;
if (this.methodscount == othermethodinfoslength) {
int i = 0;
for (; i < this.methodscount; i++)
if (hasstructuralmethodchanges(this.methods[i], othermethodinfos[i])) break;
if ((comparemethods = i != this.methodscount) && !orderrequired && !excludessynthetic)
return true;
}
if (comparemethods) {
if (this.methodscount != othermethodinfoslength && !excludessynthetic)
return true;
if (orderrequired) {
if (this.methodscount != 0)
arrays.sort(this.methods);
if (othermethodinfoslength != 0)
arrays.sort(othermethodinfos);
}
if (excludessynthetic) {
if (hasnonsyntheticmethodchanges(this.methods, othermethodinfos))
return true;
} else {
for (int i = 0; i < this.methodscount; i++)
if (hasstructuralmethodchanges(this.methods[i], othermethodinfos[i]))
return true;
}
}

// missing types
char[][][] missingtypes = getmissingtypenames();
char[][][] newmissingtypes = newclassfile.getmissingtypenames();
if (missingtypes != null) {
if (newmissingtypes == null) {
return true;
}
int length = missingtypes.length;
if (length != newmissingtypes.length) {
return true;
}
for (int i = 0; i < length; i++) {
if (!charoperation.equals(missingtypes[i], newmissingtypes[i])) {
return true;
}
}
} else if (newmissingtypes != null) {
return true;
}
return false;
} catch (classformatexception e) {
return true;
}
}

private boolean hasstructuralannotationchanges(ibinaryannotation[] currentannotations, ibinaryannotation[] otherannotations) {
if (currentannotations == otherannotations)
return false;

int currentannotationslength = currentannotations == null ? 0 : currentannotations.length;
int otherannotationslength = otherannotations == null ? 0 : otherannotations.length;
if (currentannotationslength != otherannotationslength)
return true;
for (int i = 0; i < currentannotationslength; i++) {
if (!charoperation.equals(currentannotations[i].gettypename(), otherannotations[i].gettypename()))
return true;
ibinaryelementvaluepair[] currentpairs = currentannotations[i].getelementvaluepairs();
ibinaryelementvaluepair[] otherpairs = otherannotations[i].getelementvaluepairs();
int currentpairslength = currentpairs == null ? 0 : currentpairs.length;
int otherpairslength = otherpairs == null ? 0 : otherpairs.length;
if (currentpairslength != otherpairslength)
return true;
for (int j = 0; j < currentpairslength; j++) {
if (!charoperation.equals(currentpairs[j].getname(), otherpairs[j].getname()))
return true;
if (!currentpairs[j].getvalue().equals(otherpairs[j].getvalue()))
return true;
}
}
return false;
}

private boolean hasstructuralfieldchanges(fieldinfo currentfieldinfo, fieldinfo otherfieldinfo) {
// generic signature
if (!charoperation.equals(currentfieldinfo.getgenericsignature(), otherfieldinfo.getgenericsignature()))
return true;
if (currentfieldinfo.getmodifiers() != otherfieldinfo.getmodifiers())
return true;
if ((currentfieldinfo.gettagbits() & tagbits.annotationdeprecated) != (otherfieldinfo.gettagbits() & tagbits.annotationdeprecated))
return true;
if (hasstructuralannotationchanges(currentfieldinfo.getannotations(), otherfieldinfo.getannotations()))
return true;
if (!charoperation.equals(currentfieldinfo.getname(), otherfieldinfo.getname()))
return true;
if (!charoperation.equals(currentfieldinfo.gettypename(), otherfieldinfo.gettypename()))
return true;
if (currentfieldinfo.hasconstant() != otherfieldinfo.hasconstant())
return true;
if (currentfieldinfo.hasconstant()) {
constant currentconstant = currentfieldinfo.getconstant();
constant otherconstant = otherfieldinfo.getconstant();
if (currentconstant.typeid() != otherconstant.typeid())
return true;
if (!currentconstant.getclass().equals(otherconstant.getclass()))
return true;
switch (currentconstant.typeid()) {
case typeids.t_int :
return currentconstant.intvalue() != otherconstant.intvalue();
case typeids.t_byte :
return currentconstant.bytevalue() != otherconstant.bytevalue();
case typeids.t_short :
return currentconstant.shortvalue() != otherconstant.shortvalue();
case typeids.t_char :
return currentconstant.charvalue() != otherconstant.charvalue();
case typeids.t_long :
return currentconstant.longvalue() != otherconstant.longvalue();
case typeids.t_float :
return currentconstant.floatvalue() != otherconstant.floatvalue();
case typeids.t_double :
return currentconstant.doublevalue() != otherconstant.doublevalue();
case typeids.t_boolean :
return currentconstant.booleanvalue() != otherconstant.booleanvalue();
case typeids.t_javalangstring :
return !currentconstant.stringvalue().equals(otherconstant.stringvalue());
}
}
return false;
}

private boolean hasstructuralmethodchanges(methodinfo currentmethodinfo, methodinfo othermethodinfo) {
// generic signature
if (!charoperation.equals(currentmethodinfo.getgenericsignature(), othermethodinfo.getgenericsignature()))
return true;
if (currentmethodinfo.getmodifiers() != othermethodinfo.getmodifiers())
return true;
if ((currentmethodinfo.gettagbits() & tagbits.annotationdeprecated) != (othermethodinfo.gettagbits() & tagbits.annotationdeprecated))
return true;
if (hasstructuralannotationchanges(currentmethodinfo.getannotations(), othermethodinfo.getannotations()))
return true;
if (!charoperation.equals(currentmethodinfo.getselector(), othermethodinfo.getselector()))
return true;
if (!charoperation.equals(currentmethodinfo.getmethoddescriptor(), othermethodinfo.getmethoddescriptor()))
return true;
if (!charoperation.equals(currentmethodinfo.getgenericsignature(), othermethodinfo.getgenericsignature()))
return true;

char[][] currentthrownexceptions = currentmethodinfo.getexceptiontypenames();
char[][] otherthrownexceptions = othermethodinfo.getexceptiontypenames();
if (currentthrownexceptions != otherthrownexceptions) { // typeconstants.noexceptions
int currentthrownexceptionslength = currentthrownexceptions == null ? 0 : currentthrownexceptions.length;
int otherthrownexceptionslength = otherthrownexceptions == null ? 0 : otherthrownexceptions.length;
if (currentthrownexceptionslength != otherthrownexceptionslength)
return true;
for (int k = 0; k < currentthrownexceptionslength; k++)
if (!charoperation.equals(currentthrownexceptions[k], otherthrownexceptions[k]))
return true;
}
return false;
}

/**
* this method is used to fully initialize the contents of the receiver. all methodinfos, fields infos
* will be therefore fully initialized and we can get rid of the bytes.
*/
private void initialize() throws classformatexception {
try {
for (int i = 0, max = this.fieldscount; i < max; i++) {
this.fields[i].initialize();
}
for (int i = 0, max = this.methodscount; i < max; i++) {
this.methods[i].initialize();
}
if (this.innerinfos != null) {
for (int i = 0, max = this.innerinfos.length; i < max; i++) {
this.innerinfos[i].initialize();
}
}
if (this.annotations != null) {
for (int i = 0, max = this.annotations.length; i < max; i++) {
this.annotations[i].initialize();
}
}
this.getenclosingmethod();
reset();
} catch(runtimeexception e) {
classformatexception exception = new classformatexception(e, this.classfilename);
throw exception;
}
}

/**
* answer true if the receiver is an anonymous type, false otherwise
*
* @@return <code>boolean</code>
*/
public boolean isanonymous() {
if (this.innerinfo == null) return false;
char[] innersourcename = this.innerinfo.getsourcename();
return (innersourcename == null || innersourcename.length == 0);
}

/**
* answer whether the receiver contains the resolved binary form
* or the unresolved source form of the type.
* @@return boolean
*/
public boolean isbinarytype() {
return true;
}

/**
* answer true if the receiver is a local type, false otherwise
*
* @@return <code>boolean</code>
*/
public boolean islocal() {
if (this.innerinfo == null) return false;
if (this.innerinfo.getenclosingtypename() != null) return false;
char[] innersourcename = this.innerinfo.getsourcename();
return (innersourcename != null && innersourcename.length > 0);
}

/**
* answer true if the receiver is a member type, false otherwise
*
* @@return <code>boolean</code>
*/
public boolean ismember() {
if (this.innerinfo == null) return false;
if (this.innerinfo.getenclosingtypename() == null) return false;
char[] innersourcename = this.innerinfo.getsourcename();
return (innersourcename != null && innersourcename.length > 0);	 // protection against ill-formed attributes (67600)
}

/**
* answer true if the receiver is a nested type, false otherwise
*
* @@return <code>boolean</code>
*/
public boolean isnestedtype() {
return this.innerinfo != null;
}

/**
* answer the source file name attribute. return null if there is no source file attribute for the receiver.
*
* @@return char[]
*/
public char[] sourcefilename() {
return this.sourcefilename;
}

public string tostring() {
java.io.bytearrayoutputstream out = new java.io.bytearrayoutputstream();
java.io.printwriter print = new java.io.printwriter(out);
print.println(getclass().getname() + "{"); //$non-nls-1$
print.println(" this.classname: " + new string(getname())); //$non-nls-1$
print.println(" this.superclassname: " + (getsuperclassname() == null ? "null" : new string(getsuperclassname()))); //$non-nls-2$ //$non-nls-1$
print.println(" access_flags: " + printtypemodifiers(accessflags()) + "(" + accessflags() + ")"); //$non-nls-1$ //$non-nls-3$ //$non-nls-2$
print.flush();
return out.tostring();
}
}
