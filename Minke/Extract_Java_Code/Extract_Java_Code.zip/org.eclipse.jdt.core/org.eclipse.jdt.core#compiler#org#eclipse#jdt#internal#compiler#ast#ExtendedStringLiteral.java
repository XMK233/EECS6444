/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;

public class extendedstringliteral extends stringliteral {

/**
*  build a string+char literal
*/
public extendedstringliteral(stringliteral str, charliteral character) {

super(str.source, str.sourcestart, str.sourceend, str.linenumber);
extendwith(character);
}

/**
* build a two-strings literal
* */
public extendedstringliteral(stringliteral str1, stringliteral str2) {

super(str1.source, str1.sourcestart, str1.sourceend, str1.linenumber);
extendwith(str2);
}

/**
* add the lit source to mine, just as if it was mine
*/
public extendedstringliteral extendwith(charliteral lit) {

//update the source
int length = this.source.length;
system.arraycopy(this.source, 0, (this.source = new char[length + 1]), 0, length);
this.source[length] = lit.value;
//position at the end of all literals
this.sourceend = lit.sourceend;
return this;
}

/**
*  add the lit source to mine, just as if it was mine
*/
public extendedstringliteral extendwith(stringliteral lit) {

//uddate the source
int length = this.source.length;
system.arraycopy(
this.source,
0,
this.source = new char[length + lit.source.length],
0,
length);
system.arraycopy(lit.source, 0, this.source, length, lit.source.length);
//position at the end of all literals
this.sourceend = lit.sourceend;
return this;
}

public stringbuffer printexpression(int indent, stringbuffer output) {

return output.append("extendedstringliteral{").append(this.source).append('}'); //$non-nls-1$
}

public void traverse(astvisitor visitor, blockscope scope) {

visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
