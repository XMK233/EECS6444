/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class localdeclaration extends abstractvariabledeclaration {

public localvariablebinding binding;

public localdeclaration(
char[] name,
int sourcestart,
int sourceend) {

this.name = name;
this.sourcestart = sourcestart;
this.sourceend = sourceend;
this.declarationend = sourceend;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
// record variable initialization if any
if ((flowinfo.tagbits & flowinfo.unreachable) == 0) {
this.bits |= astnode.islocaldeclarationreachable; // only set if actually reached
}
if (this.initialization == null) {
return flowinfo;
}
int nullstatus = this.initialization.nullstatus(flowinfo);
flowinfo =
this.initialization
.analysecode(currentscope, flowcontext, flowinfo)
.unconditionalinits();
if (!flowinfo.isdefinitelyassigned(this.binding)){// for local variable debug attributes
this.bits |= firstassignmenttolocal;
} else {
this.bits &= ~firstassignmenttolocal;  // int i = (i = 0);
}
flowinfo.markasdefinitelyassigned(this.binding);
if ((this.binding.type.tagbits & tagbits.isbasetype) == 0) {
switch(nullstatus) {
case flowinfo.null :
flowinfo.markasdefinitelynull(this.binding);
break;
case flowinfo.non_null :
flowinfo.markasdefinitelynonnull(this.binding);
break;
default:
flowinfo.markasdefinitelyunknown(this.binding);
}
// no need to inform enclosing try block since its locals won't get
// known by the finally block
}
return flowinfo;
}

public void checkmodifiers() {

//only potential valid modifier is <<final>>
if (((this.modifiers & extracompilermodifiers.accjustflag) & ~classfileconstants.accfinal) != 0)
//accmodifierproblem -> other (non-visibility problem)
//accalternatemodifierproblem -> duplicate modifier
//accmodifierproblem | accalternatemodifierproblem -> visibility problem"

this.modifiers = (this.modifiers & ~extracompilermodifiers.accalternatemodifierproblem) | extracompilermodifiers.accmodifierproblem;
}

/**
* code generation for a local declaration:
*	i.e.&nbsp;normal assignment to a local variable + unused variable handling
*/
public void generatecode(blockscope currentscope, codestream codestream) {

// even if not reachable, variable must be added to visible if allocated (28298)
if (this.binding.resolvedposition != -1) {
codestream.addvisiblelocalvariable(this.binding);
}
if ((this.bits & isreachable) == 0) {
return;
}
int pc = codestream.position;

// something to initialize?
generateinit: {
if (this.initialization == null)
break generateinit;
// forget initializing unused or final locals set to constant value (final ones are inlined)
if (this.binding.resolvedposition < 0) {
if (this.initialization.constant != constant.notaconstant)
break generateinit;
// if binding unused generate then discard the value
this.initialization.generatecode(currentscope, codestream, false);
break generateinit;
}
this.initialization.generatecode(currentscope, codestream, true);
// 26903, need extra cast to store null in array local var
if (this.binding.type.isarraytype()
&& (this.initialization.resolvedtype == typebinding.null	// arrayloc = null
|| ((this.initialization instanceof castexpression)	// arrayloc = (type[])null
&& (((castexpression)this.initialization).innermostcastedexpression().resolvedtype == typebinding.null)))){
codestream.checkcast(this.binding.type);
}
codestream.store(this.binding, false);
if ((this.bits & astnode.firstassignmenttolocal) != 0) {
/* variable may have been initialized during the code initializing it
e.g. int i = (i = 1);
*/
this.binding.recordinitializationstartpc(codestream.position);
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.abstractvariabledeclaration#getkind()
*/
public int getkind() {
return local_variable;
}

public void resolve(blockscope scope) {

// create a binding and add it to the scope
typebinding variabletype = this.type.resolvetype(scope, true /* check bounds*/);

checkmodifiers();
if (variabletype != null) {
if (variabletype == typebinding.void) {
scope.problemreporter().variabletypecannotbevoid(this);
return;
}
if (variabletype.isarraytype() && ((arraybinding) variabletype).leafcomponenttype == typebinding.void) {
scope.problemreporter().variabletypecannotbevoidarray(this);
return;
}
}

binding existingvariable = scope.getbinding(this.name, binding.variable, this, false /*do not resolve hidden field*/);
if (existingvariable != null && existingvariable.isvalidbinding()){
if (existingvariable instanceof localvariablebinding && this.hiddenvariabledepth == 0) {
scope.problemreporter().redefinelocal(this);
} else {
scope.problemreporter().localvariablehiding(this, existingvariable, false);
}
}

if ((this.modifiers & classfileconstants.accfinal)!= 0 && this.initialization == null) {
this.modifiers |= extracompilermodifiers.accblankfinal;
}
this.binding = new localvariablebinding(this, variabletype, this.modifiers, false);
scope.addlocalvariable(this.binding);
this.binding.setconstant(constant.notaconstant);
// allow to recursivelly target the binding....
// the correct constant is harmed if correctly computed at the end of this method

if (variabletype == null) {
if (this.initialization != null)
this.initialization.resolvetype(scope); // want to report all possible errors
return;
}

// store the constant for final locals
if (this.initialization != null) {
if (this.initialization instanceof arrayinitializer) {
typebinding initializationtype = this.initialization.resolvetypeexpecting(scope, variabletype);
if (initializationtype != null) {
((arrayinitializer) this.initialization).binding = (arraybinding) initializationtype;
this.initialization.computeconversion(scope, variabletype, initializationtype);
}
} else {
this.initialization.setexpectedtype(variabletype);
typebinding initializationtype = this.initialization.resolvetype(scope);
if (initializationtype != null) {
if (variabletype != initializationtype) // must call before computeconversion() and typemismatcherror()
scope.compilationunitscope().recordtypeconversion(variabletype, initializationtype);
if (this.initialization.isconstantvalueoftypeassignabletotype(initializationtype, variabletype)
|| initializationtype.iscompatiblewith(variabletype)) {
this.initialization.computeconversion(scope, variabletype, initializationtype);
if (initializationtype.needsuncheckedconversion(variabletype)) {
scope.problemreporter().unsafetypeconversion(this.initialization, initializationtype, variabletype);
}
if (this.initialization instanceof castexpression
&& (this.initialization.bits & astnode.unnecessarycast) == 0) {
castexpression.checkneedforassignedcast(scope, variabletype, (castexpression) this.initialization);
}
} else if (isboxingcompatible(initializationtype, variabletype, this.initialization, scope)) {
this.initialization.computeconversion(scope, variabletype, initializationtype);
if (this.initialization instanceof castexpression
&& (this.initialization.bits & astnode.unnecessarycast) == 0) {
castexpression.checkneedforassignedcast(scope, variabletype, (castexpression) this.initialization);
}
} else {
if ((variabletype.tagbits & tagbits.hasmissingtype) == 0) {
// if problem already got signaled on type, do not report secondary problem
scope.problemreporter().typemismatcherror(initializationtype, variabletype, this.initialization, null);
}
}
}
}
// check for assignment with no effect
if (this.binding == expression.getdirectbinding(this.initialization)) {
scope.problemreporter().assignmenthasnoeffect(this, this.name);
}
// change the constant in the binding when it is final
// (the optimization of the constant propagation will be done later on)
// cast from constant actual type to variable type
this.binding.setconstant(
this.binding.isfinal()
? this.initialization.constant.castto((variabletype.id << 4) + this.initialization.constant.typeid())
: constant.notaconstant);
}
// only resolve annotation at the end, for constant to be positioned before (96991)
resolveannotations(scope, this.annotations, this.binding);
}

public void traverse(astvisitor visitor, blockscope scope) {

if (visitor.visit(this, scope)) {
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, scope);
}
this.type.traverse(visitor, scope);
if (this.initialization != null)
this.initialization.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
