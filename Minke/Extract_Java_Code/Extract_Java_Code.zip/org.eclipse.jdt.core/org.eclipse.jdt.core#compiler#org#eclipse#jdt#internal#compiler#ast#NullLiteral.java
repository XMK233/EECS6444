/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class nullliteral extends magicliteral {

static final char[] source = {'n' , 'u' , 'l' , 'l'};

public nullliteral(int s , int e) {

super(s,e);
}

public void computeconstant() {

this.constant = constant.notaconstant;
}

/**
* code generation for the null literal
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
if (valuerequired) {
codestream.aconst_null();
codestream.generateimplicitconversion(this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}
public typebinding literaltype(blockscope scope) {
return typebinding.null;
}

public int nullstatus(flowinfo flowinfo) {
return flowinfo.null;
}

public object reusablejsrtarget() {
return typebinding.null;
}

public char[] source() {
return source;
}

public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
