/*******************************************************************************
* copyright (c) 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser;

import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.annotation;
import org.eclipse.jdt.internal.compiler.ast.expression;
import org.eclipse.jdt.internal.compiler.ast.markerannotation;
import org.eclipse.jdt.internal.compiler.ast.membervaluepair;
import org.eclipse.jdt.internal.compiler.ast.normalannotation;
import org.eclipse.jdt.internal.compiler.ast.singlememberannotation;
import org.eclipse.jdt.internal.compiler.ast.singlenamereference;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.ast.typereference;

public class recoveredannotation extends recoveredelement {
public static final int marker = 0;
public static final int normal = 1;
public static final int single_member = 2;

private int kind;
private int identifierptr;
private int identifierlengthptr;
private int sourcestart;
public boolean haspendingmembervaluename;
public int membervalupairequalend = -1;
public annotation annotation;

public recoveredannotation(int identifierptr, int identifierlengthptr, int sourcestart, recoveredelement parent, int bracketbalance) {
super(parent, bracketbalance);
this.kind = marker;
this.identifierptr = identifierptr;
this.identifierlengthptr = identifierlengthptr;
this.sourcestart = sourcestart;
}

public recoveredelement add(typedeclaration typedeclaration, int bracketbalancevalue) {
if (this.annotation == null && (typedeclaration.bits & astnode.isanonymoustype) != 0){
// ignore anonymous type in annotations when annotation isn't fully recovered
return this;
}
return super.add(typedeclaration, bracketbalancevalue);
}

public recoveredelement addannotationname(int identptr, int identlengthptr, int annotationstart, int bracketbalancevalue) {

recoveredannotation element = new recoveredannotation(identptr, identlengthptr, annotationstart, this, bracketbalancevalue);

return element;
}

public recoveredelement addannotation(annotation annot, int index) {
this.annotation = annot;

if (this.parent != null) return this.parent;
return this;
}

public void updatefromparserstate() {
parser parser = parser();

if (this.annotation == null && this.identifierptr <= parser.identifierptr) {
annotation annot = null;

boolean needupdaterparenpos = false;

membervaluepair pendingmembervaluename = null;
if (this.haspendingmembervaluename && this.identifierptr < parser.identifierptr) {
char[] membervaluename = parser.identifierstack[this.identifierptr + 1];

long pos = parser.identifierpositionstack[this.identifierptr + 1];
int start = (int) (pos >>> 32);
int end = (int)pos;
int valueend = this.membervalupairequalend > -1 ? this.membervalupairequalend : end;

singlenamereference fakeexpression = new singlenamereference(recoveryscanner.fake_identifier, (((long) valueend + 1) << 32) + (valueend));
pendingmembervaluename = new membervaluepair(membervaluename, start, end, fakeexpression);
}
parser.identifierptr = this.identifierptr;
parser.identifierlengthptr = this.identifierlengthptr;
typereference typereference = parser.getannotationtype();

switch (this.kind) {
case normal:
if (parser.astptr > -1 && parser.aststack[parser.astptr] instanceof membervaluepair) {
membervaluepair[] membervaluepairs = null;

int arglength = parser.astlengthstack[parser.astlengthptr];
int argstart = parser.astptr - arglength + 1;

if (arglength > 0) {
int annotationend;
if (pendingmembervaluename != null) {
membervaluepairs = new membervaluepair[arglength + 1];

system.arraycopy(parser.aststack, argstart, membervaluepairs, 0, arglength);
parser.astlengthptr--;
parser.astptr -= arglength;

membervaluepairs[arglength] = pendingmembervaluename;

annotationend = pendingmembervaluename.sourceend;
} else {
membervaluepairs = new membervaluepair[arglength];

system.arraycopy(parser.aststack, argstart, membervaluepairs, 0, arglength);
parser.astlengthptr--;
parser.astptr -= arglength;

membervaluepair lastmembervaluepair = membervaluepairs[membervaluepairs.length - 1];

annotationend =
lastmembervaluepair.value != null
? lastmembervaluepair.value instanceof annotation
? ((annotation)lastmembervaluepair.value).declarationsourceend
: lastmembervaluepair.value.sourceend
: lastmembervaluepair.sourceend;
}

normalannotation normalannotation = new normalannotation(typereference, this.sourcestart);
normalannotation.membervaluepairs = membervaluepairs;
normalannotation.declarationsourceend = annotationend;
normalannotation.bits |= astnode.isrecovered;

annot = normalannotation;

needupdaterparenpos = true;
}
}


break;
case single_member:
if (parser.expressionptr > -1) {
expression membervalue = parser.expressionstack[parser.expressionptr--];

singlememberannotation singlememberannotation = new singlememberannotation(typereference, this.sourcestart);
singlememberannotation.membervalue = membervalue;
singlememberannotation.declarationsourceend = membervalue.sourceend;
singlememberannotation.bits |= astnode.isrecovered;

annot = singlememberannotation;

needupdaterparenpos = true;
}
break;
}

if (!needupdaterparenpos) {
if (pendingmembervaluename != null) {
normalannotation normalannotation = new normalannotation(typereference, this.sourcestart);
normalannotation.membervaluepairs = new membervaluepair[]{pendingmembervaluename};
normalannotation.declarationsourceend = pendingmembervaluename.value.sourceend;
normalannotation.bits |= astnode.isrecovered;

annot = normalannotation;
} else {
markerannotation markerannotation = new markerannotation(typereference, this.sourcestart);
markerannotation.declarationsourceend = markerannotation.sourceend;
markerannotation.bits |= astnode.isrecovered;

annot = markerannotation;
}
}

parser.currentelement = addannotation(annot, this.identifierptr);
parser.annotationrecoverycheckpoint(annot.sourcestart, annot.declarationsourceend);
if (this.parent != null) {

this.parent.updatefromparserstate();
}
}
}

public astnode parsetree() {
return this.annotation;
}

public void resetpendingmodifiers() {
if (this.parent != null) this.parent.resetpendingmodifiers();
}

public void setkind(int kind) {
this.kind = kind;
}

public int sourceend() {
if (this.annotation == null) {
parser parser = parser();
if (this.identifierptr < parser.identifierpositionstack.length) {
return (int) parser.identifierpositionstack[this.identifierptr];
} else {
return this.sourcestart;
}
}
return this.annotation.declarationsourceend;
}

public string tostring(int tab) {
if (this.annotation != null) {
return tabstring(tab) + "recovered annotation:\n" + this.annotation.print(tab + 1, new stringbuffer(10)); //$non-nls-1$
} else {
return tabstring(tab) + "recovered annotation: identiferptr=" + this.identifierptr + " identiferlengthptr=" + this.identifierlengthptr + "\n"; //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
}
}

public annotation updatedannotationreference() {
return this.annotation;
}

public recoveredelement updateonclosingbrace(int bracestart, int braceend){
if (this.bracketbalance > 0){ // was an member value array initializer
this.bracketbalance--;
return this;
}
if (this.parent != null){
return this.parent.updateonclosingbrace(bracestart, braceend);
}
return this;
}

public void updateparsetree() {
updatedannotationreference();
}
}
