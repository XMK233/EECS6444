/*******************************************************************************
* copyright (c) 2004, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import org.eclipse.jdt.core.completionproposal;
import org.eclipse.jdt.core.completionrequestor;
import org.eclipse.jdt.core.flags;
import org.eclipse.jdt.core.signature;
import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.iproblem;

/**
* this completionrequetor wrap the old requestor icompletionrequestor
* @@since 3.1
* @@deprecated
*/
public class completionrequestorwrapper extends completionrequestor {
private static boolean decode_signature = false;

private org.eclipse.jdt.core.icompletionrequestor requestor;
public completionrequestorwrapper(org.eclipse.jdt.core.icompletionrequestor requestor) {
this.requestor = requestor;
}

public void accept(completionproposal proposal) {
internalcompletionproposal internalcompletionproposal = (internalcompletionproposal) proposal;
switch(internalcompletionproposal.getkind()) {
case completionproposal.keyword:
this.requestor.acceptkeyword(
internalcompletionproposal.getname(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance());
break;
case completionproposal.package_ref:
if(decode_signature) {
this.requestor.acceptpackage(
internalcompletionproposal.getdeclarationsignature(),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance());
} else {
this.requestor.acceptpackage(
internalcompletionproposal.getpackagename(),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance());
}
break;
case completionproposal.type_ref:
if((internalcompletionproposal.getflags() & flags.accenum) != 0) {
// does not exist for old requestor
} else if((internalcompletionproposal.getflags() & flags.accinterface) != 0) {
if(decode_signature) {
this.requestor.acceptinterface(
internalcompletionproposal.getdeclarationsignature(),
signature.getsignaturesimplename(internalcompletionproposal.getsignature()),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags() & ~flags.accinterface,
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance());
} else {
this.requestor.acceptinterface(
internalcompletionproposal.getpackagename() == null ? charoperation.no_char : internalcompletionproposal.getpackagename(),
internalcompletionproposal.gettypename(),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags() & ~flags.accinterface,
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance());
}
} else {
if(decode_signature) {
this.requestor.acceptclass(
internalcompletionproposal.getdeclarationsignature(),
signature.getsignaturesimplename(internalcompletionproposal.getsignature()),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance());
} else {
this.requestor.acceptclass(
internalcompletionproposal.getpackagename() == null ? charoperation.no_char : internalcompletionproposal.getpackagename(),
internalcompletionproposal.gettypename(),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance());
}
}
break;
case completionproposal.field_ref:
if(decode_signature) {
this.requestor.acceptfield(
signature.getsignaturequalifier(internalcompletionproposal.getdeclarationsignature()),
signature.getsignaturesimplename(internalcompletionproposal.getdeclarationsignature()),
internalcompletionproposal.getname(),
signature.getsignaturequalifier(internalcompletionproposal.getsignature()),
signature.getsignaturesimplename(internalcompletionproposal.getsignature()),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
} else {
this.requestor.acceptfield(
internalcompletionproposal.getdeclarationpackagename() == null ? charoperation.no_char : internalcompletionproposal.getdeclarationpackagename(),
internalcompletionproposal.getdeclarationtypename() == null ? charoperation.no_char : internalcompletionproposal.getdeclarationtypename(),
internalcompletionproposal.getname(),
internalcompletionproposal.getpackagename() == null ? charoperation.no_char : internalcompletionproposal.getpackagename(),
internalcompletionproposal.gettypename() == null ? charoperation.no_char : internalcompletionproposal.gettypename(),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
}
break;
case completionproposal.method_ref:
if(decode_signature) {
this.requestor.acceptmethod(
signature.getsignaturequalifier(internalcompletionproposal.getdeclarationsignature()),
signature.getsignaturesimplename(internalcompletionproposal.getdeclarationsignature()),
internalcompletionproposal.getname(),
getparameterpackages(internalcompletionproposal.getsignature()),
getparametertypes(internalcompletionproposal.getsignature()),
internalcompletionproposal.findparameternames(null) == null ? charoperation.no_char_char : internalcompletionproposal.findparameternames(null),
signature.getsignaturequalifier(signature.getreturntype(internalcompletionproposal.getsignature())),
signature.getsignaturesimplename(signature.getreturntype(internalcompletionproposal.getsignature())),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
} else {
this.requestor.acceptmethod(
internalcompletionproposal.getdeclarationpackagename() == null ? charoperation.no_char : internalcompletionproposal.getdeclarationpackagename(),
internalcompletionproposal.getdeclarationtypename() == null ? charoperation.no_char : internalcompletionproposal.getdeclarationtypename(),
internalcompletionproposal.getname(),
internalcompletionproposal.getparameterpackagenames() == null ? charoperation.no_char_char : internalcompletionproposal.getparameterpackagenames(),
internalcompletionproposal.getparametertypenames() == null ? charoperation.no_char_char : internalcompletionproposal.getparametertypenames(),
internalcompletionproposal.findparameternames(null) == null ? charoperation.no_char_char : internalcompletionproposal.findparameternames(null),
internalcompletionproposal.getpackagename() == null ? charoperation.no_char : internalcompletionproposal.getpackagename(),
internalcompletionproposal.gettypename() == null ? charoperation.no_char : internalcompletionproposal.gettypename(),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
}
break;
case completionproposal.method_declaration:
if(decode_signature) {
this.requestor.acceptmethoddeclaration(
signature.getsignaturequalifier(internalcompletionproposal.getdeclarationsignature()),
signature.getsignaturesimplename(internalcompletionproposal.getdeclarationsignature()),
internalcompletionproposal.getname(),
getparameterpackages(internalcompletionproposal.getsignature()),
getparametertypes(internalcompletionproposal.getsignature()),
internalcompletionproposal.findparameternames(null) == null ? charoperation.no_char_char : internalcompletionproposal.findparameternames(null),
signature.getsignaturequalifier(signature.getreturntype(internalcompletionproposal.getsignature())),
signature.getsignaturesimplename(signature.getreturntype(internalcompletionproposal.getsignature())),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
} else {
this.requestor.acceptmethoddeclaration(
internalcompletionproposal.getdeclarationpackagename(),
internalcompletionproposal.getdeclarationtypename(),
internalcompletionproposal.getname(),
internalcompletionproposal.getparameterpackagenames() == null ? charoperation.no_char_char : internalcompletionproposal.getparameterpackagenames(),
internalcompletionproposal.getparametertypenames() == null ? charoperation.no_char_char : internalcompletionproposal.getparametertypenames(),
internalcompletionproposal.findparameternames(null) == null ? charoperation.no_char_char : internalcompletionproposal.findparameternames(null),
internalcompletionproposal.getpackagename(),
internalcompletionproposal.gettypename(),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
}
break;
case completionproposal.anonymous_class_declaration:
if(decode_signature) {
this.requestor.acceptanonymoustype(
signature.getsignaturequalifier(internalcompletionproposal.getdeclarationsignature()),
signature.getsignaturesimplename(internalcompletionproposal.getdeclarationsignature()),
getparameterpackages(internalcompletionproposal.getsignature()),
getparametertypes(internalcompletionproposal.getsignature()),
internalcompletionproposal.findparameternames(null) == null ? charoperation.no_char_char : internalcompletionproposal.findparameternames(null),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
} else {
this.requestor.acceptanonymoustype(
internalcompletionproposal.getdeclarationpackagename(),
internalcompletionproposal.getdeclarationtypename(),
internalcompletionproposal.getparameterpackagenames() == null ? charoperation.no_char_char : internalcompletionproposal.getparameterpackagenames(),
internalcompletionproposal.getparametertypenames() == null ? charoperation.no_char_char : internalcompletionproposal.getparametertypenames(),
internalcompletionproposal.findparameternames(null) == null ? charoperation.no_char_char : internalcompletionproposal.findparameternames(null),
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
}
break;
case completionproposal.label_ref :
this.requestor.acceptlabel(
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
break;
case completionproposal.local_variable_ref:
if(decode_signature) {
this.requestor.acceptlocalvariable(
internalcompletionproposal.getcompletion(),
signature.getsignaturequalifier(internalcompletionproposal.getsignature()),
signature.getsignaturesimplename(internalcompletionproposal.getsignature()),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
} else {
this.requestor.acceptlocalvariable(
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getpackagename() == null ? charoperation.no_char : internalcompletionproposal.getpackagename(),
internalcompletionproposal.gettypename(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
}
break;
case completionproposal.variable_declaration:
if(decode_signature) {
this.requestor.acceptlocalvariable(
internalcompletionproposal.getcompletion(),
signature.getsignaturequalifier(internalcompletionproposal.getsignature()),
signature.getsignaturesimplename(internalcompletionproposal.getsignature()),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
} else {
this.requestor.acceptlocalvariable(
internalcompletionproposal.getcompletion(),
internalcompletionproposal.getpackagename(),
internalcompletionproposal.gettypename(),
internalcompletionproposal.getflags(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
}
break;
case completionproposal.potential_method_declaration:
if(this.requestor instanceof iextendedcompletionrequestor) {
iextendedcompletionrequestor r = (iextendedcompletionrequestor) this.requestor;
if(decode_signature) {
r.acceptpotentialmethoddeclaration(
signature.getsignaturequalifier(internalcompletionproposal.getdeclarationsignature()),
signature.getsignaturesimplename(internalcompletionproposal.getdeclarationsignature()),
internalcompletionproposal.getname(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
} else {
r.acceptpotentialmethoddeclaration(
internalcompletionproposal.getdeclarationpackagename(),
internalcompletionproposal.getdeclarationtypename(),
internalcompletionproposal.getname(),
internalcompletionproposal.getreplacestart(),
internalcompletionproposal.getreplaceend(),
internalcompletionproposal.getrelevance()
);
}
}
break;

}
}

public void completionfailure(iproblem problem) {
this.requestor.accepterror(problem);
}

private char[][] getparameterpackages(char[] methodsignature) {
char[][] parameterqualifiedtypes = signature.getparametertypes(methodsignature);
int length = parameterqualifiedtypes == null ? 0 : parameterqualifiedtypes.length;
char[][] parameterpackages = new char[length][];
for(int i = 0; i < length; i++) {
parameterpackages[i] = signature.getsignaturequalifier(parameterqualifiedtypes[i]);
}

return parameterpackages;
}

private char[][] getparametertypes(char[] methodsignature) {
char[][] parameterqualifiedtypes = signature.getparametertypes(methodsignature);
int length = parameterqualifiedtypes == null ? 0 : parameterqualifiedtypes.length;
char[][] parameterpackages = new char[length][];
for(int i = 0; i < length; i++) {
parameterpackages[i] = signature.getsignaturesimplename(parameterqualifiedtypes[i]);
}

return parameterpackages;
}
}
