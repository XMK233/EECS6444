/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     matt mccutchen - partial fix for https://bugs.eclipse.org/bugs/show_bug.cgi?id=122995
*     karen moore - fix for https://bugs.eclipse.org/bugs/show_bug.cgi?id=207411
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.env.accessrestriction;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.astvisitor;

public abstract class astnode implements typeconstants, typeids {

public int sourcestart, sourceend;

// storage for internal flags (32 bits)				bit usage
public final static int bit1 = 0x1;					// return type (operator) | name reference kind (name ref) | add assertion (type decl) | useful empty statement (empty statement)
public final static int bit2 = 0x2;					// return type (operator) | name reference kind (name ref) | has local type (type, method, field decl)
public final static int bit3 = 0x4;					// return type (operator) | name reference kind (name ref) | implicit this (this ref)
public final static int bit4 = 0x8;					// return type (operator) | first assignment to local (name ref,local decl) | undocumented empty block (block, type and method decl)
public final static int bit5 = 0x10;					// value for return (expression) | has all method bodies (unit) | supertype ref (type ref) | resolved (field decl)
public final static int bit6 = 0x20;					// depth (name ref, msg) | ignore need cast check (cast expression) | error in signature (method declaration/ initializer) | is recovered (annotation reference)
public final static int bit7 = 0x40;					// depth (name ref, msg) | operator (operator) | need runtime checkcast (cast expression) | label used (labelstatement) | needfreereturn (abstractmethoddeclaration)
public final static int bit8 = 0x80;					// depth (name ref, msg) | operator (operator) | unsafe cast (cast expression) | is default constructor (constructor declaration) | iselsestatementunreachable (if statement)
public final static int bit9 = 0x100;				// depth (name ref, msg) | operator (operator) | is local type (type decl) | isthenstatementunreachable (if statement)
public final static int bit10= 0x200;				// depth (name ref, msg) | operator (operator) | is anonymous type (type decl)
public final static int bit11 = 0x400;				// depth (name ref, msg) | operator (operator) | is member type (type decl)
public final static int bit12 = 0x800;				// depth (name ref, msg) | operator (operator) | has abstract methods (type decl)
public final static int bit13 = 0x1000;			// depth (name ref, msg) | is secondary type (type decl)
public final static int bit14 = 0x2000;			// strictly assigned (reference lhs) | discard enclosing instance (explicit constr call) | hasbeengenerated (type decl)
public final static int bit15 = 0x4000;			// is unnecessary cast (expression) | is varargs (type ref) | issubroutineescaping (try statement) | superaccess (javadoc allocation expression/javadoc message send/javadoc return statement)
public final static int bit16 = 0x8000;			// in javadoc comment (name ref, type ref, msg)
public final static int bit17 = 0x10000;			// compound assigned (reference lhs) | unchecked (msg, alloc, explicit constr call)
public final static int bit18 = 0x20000;			// non null (expression) | ondemand (import reference)
public final static int bit19 = 0x40000;			// didresolve (parameterized qualified type ref/parameterized single type ref)  | empty (javadoc return statement) | needreceivergenericcast (msg/fieldref)
public final static int bit20 = 0x80000;			// contains syntax errors (method declaration, type declaration, field declarations, initializer)
public final static int bit21 = 0x100000;
public final static int bit22 = 0x200000;			// parenthesis count (expression) | used (import reference)
public final static int bit23 = 0x400000;			// parenthesis count (expression)
public final static int bit24 = 0x800000;			// parenthesis count (expression)
public final static int bit25 = 0x1000000;		// parenthesis count (expression)
public final static int bit26 = 0x2000000;		// parenthesis count (expression)
public final static int bit27 = 0x4000000;		// parenthesis count (expression)
public final static int bit28 = 0x8000000;		// parenthesis count (expression)
public final static int bit29 = 0x10000000;		// parenthesis count (expression)
public final static int bit30 = 0x20000000;		// elseif (if statement) | try block exit (try statement) | fall-through (case statement) | ignore no effect assign (expression ref) | needscope (for statement) | isanysubroutineescaping (return statement) | blockexit (synchronized statement)
public final static int bit31 = 0x40000000;		// local declaration reachable (local decl) | ignore raw type check (type ref) | discard entire assignment (assignment) | issynchronized (return statement) | thenexit (if statement)
public final static int bit32 = 0x80000000;		// reachable (statement)

public final static long bit32l = 0x80000000l;
public final static long bit33l = 0x100000000l;
public final static long bit34l = 0x200000000l;
public final static long bit35l = 0x400000000l;
public final static long bit36l = 0x800000000l;
public final static long bit37l = 0x1000000000l;
public final static long bit38l = 0x2000000000l;
public final static long bit39l = 0x4000000000l;
public final static long bit40l = 0x8000000000l;
public final static long bit41l = 0x10000000000l;
public final static long bit42l = 0x20000000000l;
public final static long bit43l = 0x40000000000l;
public final static long bit44l = 0x80000000000l;
public final static long bit45l = 0x100000000000l;
public final static long bit46l = 0x200000000000l;
public final static long bit47l = 0x400000000000l;
public final static long bit48l = 0x800000000000l;
public final static long bit49l = 0x1000000000000l;
public final static long bit50l = 0x2000000000000l;
public final static long bit51l = 0x4000000000000l;
public final static long bit52l = 0x8000000000000l;
public final static long bit53l = 0x10000000000000l;
public final static long bit54l = 0x20000000000000l;
public final static long bit55l = 0x40000000000000l;
public final static long bit56l = 0x80000000000000l;
public final static long bit57l = 0x100000000000000l;
public final static long bit58l = 0x200000000000000l;
public final static long bit59l = 0x400000000000000l;
public final static long bit60l = 0x800000000000000l;
public final static long bit61l = 0x1000000000000000l;
public final static long bit62l = 0x2000000000000000l;
public final static long bit63l = 0x4000000000000000l;
public final static long bit64l = 0x8000000000000000l;

public int bits = isreachable; 				// reachable by default

// for operators
public static final int returntypeidmask = bit1|bit2|bit3|bit4;
public static final int operatorshift = 6;	// bit7 -> bit12
public static final int operatormask = bit7|bit8|bit9|bit10|bit11|bit12; // 6 bits for operator id

// for binary expressions
public static final int isreturnedvalue = bit5;

// for cast expressions
public static final int unnecessarycast = bit15;
public static final int disableunnecessarycastcheck = bit6;
public static final int generatecheckcast = bit7;
public static final int unsafecast = bit8;

// for name references
public static final int restrictiveflagmask = bit1|bit2|bit3;

// for name refs or local decls
public static final int firstassignmenttolocal = bit4;

// for msg or field references
public static final int needreceivergenericcast = bit19;

// for this reference
public static final int isimplicitthis = bit3;

// for single name references
public static final int depthshift = 5;	// bit6 -> bit13
public static final int depthmask = bit6|bit7|bit8|bit9|bit10|bit11|bit12|bit13; // 8 bits for actual depth value (max. 255)

// for statements
public static final int isreachable = bit32;
public static final int labelused = bit7;
public static final int documentedfallthrough = bit30;

// local decls
public static final int islocaldeclarationreachable = bit31;

// try statements
public static final int issubroutineescaping = bit15;
public static final int istryblockexiting = bit30;

// for type declaration
public static final int containsassertion = bit1;
public static final int islocaltype = bit9;
public static final int isanonymoustype = bit10; // used to test for anonymous
public static final int ismembertype = bit11; // local member do not know it is local at parse time (need to look at binding)
public static final int hasabstractmethods = bit12; // used to promote abstract enums
public static final int issecondarytype = bit13; // used to test for secondary
public static final int hasbeengenerated = bit14;

// for type, method and field declarations
public static final int haslocaltype = bit2; // cannot conflict with addassertionmask
public static final int hasbeenresolved = bit5; // field decl only (to handle forward references)

// for expression
public static final int parenthesizedshift = 21; // bit22 -> bit29
public static final int parenthesizedmask = bit22|bit23|bit24|bit25|bit26|bit27|bit28|bit29; // 8 bits for parenthesis count value (max. 255)
public static final int ignorenoeffectassigncheck = bit30;

// for references on lhs of assignment
public static final int isstrictlyassigned = bit14; // set only for true assignments, as opposed to compound ones
public static final int iscompoundassigned = bit17; // set only for compound assignments, as opposed to other ones

// for explicit constructor call
public static final int discardenclosinginstance = bit14; // used for codegen

// for all method/constructor invocations (msg, alloc, expl. constr call)
public static final int unchecked = bit17;

// for empty statement
public static final int isusefulemptystatement = bit1;

// for block and method declaration
public static final int undocumentedemptyblock = bit4;
public static final int overridingmethodwithsupercall = bit5;

// for initializer and method declaration
public static final int errorinsignature = bit6;

// for abstract method declaration
public static final int needfreereturn = bit7; // abstract method declaration

// for constructor declaration
public static final int isdefaultconstructor = bit8;

// for compilation unit
public static final int hasallmethodbodies = bit5;
public static final int isimplicitunit = bit1;

// for references in javadoc comments
public static final int insidejavadoc = bit16;

// for javadoc allocation expression/javadoc message send/javadoc return statement
public static final int superaccess = bit15;

// for javadoc return statement
public static final int empty = bit19;

// for if statement
public static final int iselseifstatement = bit30;
public static final int thenexit = bit31;
public static final int iselsestatementunreachable = bit8;
public static final int isthenstatementunreachable = bit9;

// for type reference
public static final int issupertype = bit5;
public static final int isvarargs = bit15;
public static final int ignorerawtypecheck = bit31;

// for array initializer
public static final int isannotationdefaultvalue = bit1;

// for null reference analysis
public static final int isnonnull = bit18;

// for for statement
public static final int neededscope = bit30;

// for import reference
public static final int ondemand = bit18;
public static final int used = bit2;

// for parameterized qualified/single type ref
public static final int didresolve = bit19;

// for return statement
public static final int isanysubroutineescaping = bit30;
public static final int issynchronized = bit31;

// for synchronized statement
public static final int blockexit = bit30;

// for annotation reference
public static final int isrecovered = bit6;

// for type declaration, initializer and method declaration
public static final int hassyntaxerrors = bit20;

// constants used when checking invocation arguments
public static final int invocation_argument_ok = 0;
public static final int invocation_argument_unchecked = 1;
public static final int invocation_argument_wildcard = 2;

public astnode() {

super();
}
private static int checkinvocationargument(blockscope scope, expression argument, typebinding parametertype, typebinding argumenttype, typebinding originalparametertype) {
argument.computeconversion(scope, parametertype, argumenttype);

if (argumenttype != typebinding.null && parametertype.kind() == binding.wildcard_type) { // intersection types are tolerated
wildcardbinding wildcard = (wildcardbinding) parametertype;
if (wildcard.boundkind != wildcard.super) {
return invocation_argument_wildcard;
}
}
typebinding checkedparametertype = parametertype; // originalparametertype == null ? parametertype : originalparametertype;
if (argumenttype != checkedparametertype && argumenttype.needsuncheckedconversion(checkedparametertype)) {
scope.problemreporter().unsafetypeconversion(argument, argumenttype, checkedparametertype);
return invocation_argument_unchecked;
}
return invocation_argument_ok;
}
public static boolean checkinvocationarguments(blockscope scope, expression receiver, typebinding receivertype, methodbinding method, expression[] arguments, typebinding[] argumenttypes, boolean argscontaincast, invocationsite invocationsite) {
typebinding[] params = method.parameters;
int paramlength = params.length;
boolean israwmemberinvocation = !method.isstatic()
&& !receivertype.isunboundwildcard()
&& method.declaringclass.israwtype()
&& method.hassubstitutedparameters();

boolean uncheckedboundcheck = (method.tagbits & tagbits.hasuncheckedtypeargumentforboundcheck) != 0;
methodbinding raworiginalgenericmethod = null;
if (!israwmemberinvocation) {
if (method instanceof parameterizedgenericmethodbinding) {
parameterizedgenericmethodbinding parammethod = (parameterizedgenericmethodbinding) method;
if (parammethod.israw && method.hassubstitutedparameters()) {
raworiginalgenericmethod = method.original();
}
}
}
int invocationstatus = invocation_argument_ok;
if (arguments == null) {
if (method.isvarargs()) {
typebinding parametertype = ((arraybinding) params[paramlength-1]).elementstype(); // no element was supplied for vararg parameter
if (!parametertype.isreifiable()) {
scope.problemreporter().unsafegenericarrayforvarargs(parametertype, (astnode)invocationsite);
}
}
} else {
if (method.isvarargs()) {
// 4 possibilities exist for a call to the vararg method foo(int i, long ... value) : foo(1), foo(1, 2), foo(1, 2, 3, 4) & foo(1, new long[] {1, 2})
int lastindex = paramlength - 1;
for (int i = 0; i < lastindex; i++) {
typebinding originalrawparam = raworiginalgenericmethod == null ? null : raworiginalgenericmethod.parameters[i];
invocationstatus |= checkinvocationargument(scope, arguments[i], params[i] , argumenttypes[i], originalrawparam);
}
int arglength = arguments.length;
if (lastindex < arglength) { // vararg argument was provided
typebinding parametertype = params[lastindex];
typebinding originalrawparam = null;

if (paramlength != arglength || parametertype.dimensions() != argumenttypes[lastindex].dimensions()) {
parametertype = ((arraybinding) parametertype).elementstype(); // single element was provided for vararg parameter
if (!parametertype.isreifiable()) {
scope.problemreporter().unsafegenericarrayforvarargs(parametertype, (astnode)invocationsite);
}
originalrawparam = raworiginalgenericmethod == null ? null : ((arraybinding)raworiginalgenericmethod.parameters[lastindex]).elementstype();
}
for (int i = lastindex; i < arglength; i++) {
invocationstatus |= checkinvocationargument(scope, arguments[i], parametertype, argumenttypes[i], originalrawparam);
}
}
if (paramlength == arglength) { // 70056
int varargsindex = paramlength - 1;
arraybinding varargstype = (arraybinding) params[varargsindex];
typebinding lastargtype = argumenttypes[varargsindex];
int dimensions;
if (lastargtype == typebinding.null) {
if (!(varargstype.leafcomponenttype().isbasetype() && varargstype.dimensions() == 1))
scope.problemreporter().varargsargumentneedcast(method, lastargtype, invocationsite);
} else if (varargstype.dimensions <= (dimensions = lastargtype.dimensions())) {
if (lastargtype.leafcomponenttype().isbasetype()) {
dimensions--;
}
if (varargstype.dimensions < dimensions) {
scope.problemreporter().varargsargumentneedcast(method, lastargtype, invocationsite);
} else if (varargstype.dimensions == dimensions
&& lastargtype != varargstype
&& lastargtype.leafcomponenttype().erasure() != varargstype.leafcomponenttype.erasure()
&& lastargtype.iscompatiblewith(varargstype.elementstype())
&& lastargtype.iscompatiblewith(varargstype)) {
scope.problemreporter().varargsargumentneedcast(method, lastargtype, invocationsite);
}
}
}
} else {
for (int i = 0; i < paramlength; i++) {
typebinding originalrawparam = raworiginalgenericmethod == null ? null : raworiginalgenericmethod.parameters[i];
invocationstatus |= checkinvocationargument(scope, arguments[i], params[i], argumenttypes[i], originalrawparam);
}
}
if (argscontaincast) {
castexpression.checkneedforargumentcasts(scope, receiver, receivertype, method, arguments, argumenttypes, invocationsite);
}
}
if ((invocationstatus & invocation_argument_wildcard) != 0) {
scope.problemreporter().wildcardinvocation((astnode)invocationsite, receivertype, method, argumenttypes);
} else if (!method.isstatic() && !receivertype.isunboundwildcard() && method.declaringclass.israwtype() && method.hassubstitutedparameters()) {
scope.problemreporter().unsaferawinvocation((astnode)invocationsite, method);
} else if (raworiginalgenericmethod != null
|| uncheckedboundcheck
|| ((invocationstatus & invocation_argument_unchecked) != 0
&& method instanceof parameterizedgenericmethodbinding
/*&& method.returntype != scope.environment().converttorawtype(method.returntype.erasure(), true)*/)) {
scope.problemreporter().unsaferawgenericmethodinvocation((astnode)invocationsite, method, argumenttypes);
return true;
}
return false;
}
public astnode concretestatement() {
return this;
}

public final boolean isfieldusedeprecated(fieldbinding field, scope scope, boolean isstrictlyassigned) {
// ignore references insing javadoc comments
if ((this.bits & astnode.insidejavadoc) == 0 && !isstrictlyassigned && field.isorenclosedbyprivatetype() && !scope.isdefinedinfield(field)) {
// ignore cases where field is used from inside itself
field.original().modifiers |= extracompilermodifiers.acclocallyused;
}

if ((field.modifiers & extracompilermodifiers.accrestrictedaccess) != 0) {
accessrestriction restriction =
scope.environment().getaccessrestriction(field.declaringclass.erasure());
if (restriction != null) {
scope.problemreporter().forbiddenreference(field, this,
restriction.classpathentrytype, restriction.classpathentryname,
restriction.getproblemid());
}
}

if (!field.isviewedasdeprecated()) return false;

// inside same unit - no report
if (scope.isdefinedinsameunit(field.declaringclass)) return false;

// if context is deprecated, may avoid reporting
if (!scope.compileroptions().reportdeprecationinsidedeprecatedcode && scope.isinsidedeprecatedcode()) return false;
return true;
}

public boolean isimplicitthis() {

return false;
}

/* answer true if the method use is considered deprecated.
* an access in the same compilation unit is allowed.
*/
public final boolean ismethodusedeprecated(methodbinding method, scope scope,
boolean isexplicituse) {
// ignore references insing javadoc comments
if ((this.bits & astnode.insidejavadoc) == 0 && method.isorenclosedbyprivatetype() && !scope.isdefinedinmethod(method)) {
// ignore cases where method is used from inside itself (e.g. direct recursions)
method.original().modifiers |= extracompilermodifiers.acclocallyused;
}

// todo (maxime) consider separating concerns between deprecation and access restriction.
// 				 caveat: this was not the case when access restriction funtion was added.
if (isexplicituse && (method.modifiers & extracompilermodifiers.accrestrictedaccess) != 0) {
// note: explicit constructors calls warnings are kept despite the 'new c1()' case (two
//       warnings, one on type, the other on constructor), because of the 'super()' case.
accessrestriction restriction =
scope.environment().getaccessrestriction(method.declaringclass.erasure());
if (restriction != null) {
scope.problemreporter().forbiddenreference(method, this,
restriction.classpathentrytype, restriction.classpathentryname,
restriction.getproblemid());
}
}

if (!method.isviewedasdeprecated()) return false;

// inside same unit - no report
if (scope.isdefinedinsameunit(method.declaringclass)) return false;

// non explicit use and non explicitly deprecated - no report
if (!isexplicituse &&
(method.modifiers & classfileconstants.accdeprecated) == 0) {
return false;
}

// if context is deprecated, may avoid reporting
if (!scope.compileroptions().reportdeprecationinsidedeprecatedcode && scope.isinsidedeprecatedcode()) return false;
return true;
}

public boolean issuper() {

return false;
}

public boolean isthis() {

return false;
}

/* answer true if the type use is considered deprecated.
* an access in the same compilation unit is allowed.
*/
public final boolean istypeusedeprecated(typebinding type, scope scope) {

if (type.isarraytype()) {
type = ((arraybinding) type).leafcomponenttype;
}
if (type.isbasetype())
return false;

referencebinding reftype = (referencebinding) type;
// ignore references insing javadoc comments
if ((this.bits & astnode.insidejavadoc) == 0 && reftype.isorenclosedbyprivatetype() && !scope.isdefinedintype(reftype)) {
// ignore cases where type is used from inside itself
((referencebinding)reftype.erasure()).modifiers |= extracompilermodifiers.acclocallyused;
}

if (reftype.hasrestrictedaccess()) {
accessrestriction restriction = scope.environment().getaccessrestriction(type.erasure());
if (restriction != null) {
scope.problemreporter().forbiddenreference(type, this, restriction.classpathentrytype,
restriction.classpathentryname, restriction.getproblemid());
}
}

// force annotations resolution before deciding whether the type may be deprecated
reftype.initializedeprecatedannotationtagbits();

if (!reftype.isviewedasdeprecated()) return false;

// inside same unit - no report
if (scope.isdefinedinsameunit(reftype)) return false;

// if context is deprecated, may avoid reporting
if (!scope.compileroptions().reportdeprecationinsidedeprecatedcode && scope.isinsidedeprecatedcode()) return false;
return true;
}

public abstract stringbuffer print(int indent, stringbuffer output);

public static stringbuffer printannotations(annotation[] annotations, stringbuffer output) {
int length = annotations.length;
for (int i = 0; i < length; i++) {
annotations[i].print(0, output);
output.append(" "); //$non-nls-1$
}
return output;
}

public static stringbuffer printindent(int indent, stringbuffer output) {

for (int i = indent; i > 0; i--) output.append("  "); //$non-nls-1$
return output;
}

public static stringbuffer printmodifiers(int modifiers, stringbuffer output) {

if ((modifiers & classfileconstants.accpublic) != 0)
output.append("public "); //$non-nls-1$
if ((modifiers & classfileconstants.accprivate) != 0)
output.append("private "); //$non-nls-1$
if ((modifiers & classfileconstants.accprotected) != 0)
output.append("protected "); //$non-nls-1$
if ((modifiers & classfileconstants.accstatic) != 0)
output.append("static "); //$non-nls-1$
if ((modifiers & classfileconstants.accfinal) != 0)
output.append("final "); //$non-nls-1$
if ((modifiers & classfileconstants.accsynchronized) != 0)
output.append("synchronized "); //$non-nls-1$
if ((modifiers & classfileconstants.accvolatile) != 0)
output.append("volatile "); //$non-nls-1$
if ((modifiers & classfileconstants.acctransient) != 0)
output.append("transient "); //$non-nls-1$
if ((modifiers & classfileconstants.accnative) != 0)
output.append("native "); //$non-nls-1$
if ((modifiers & classfileconstants.accabstract) != 0)
output.append("abstract "); //$non-nls-1$
return output;
}

/**
* resolve annotations, and check duplicates, answers combined tagbits
* for recognized standard annotations
*/
public static void resolveannotations(blockscope scope, annotation[] sourceannotations, binding recipient) {
annotationbinding[] annotations = null;
int length = sourceannotations == null ? 0 : sourceannotations.length;
if (recipient != null) {
switch (recipient.kind()) {
case binding.package :
packagebinding packagebinding = (packagebinding) recipient;
if ((packagebinding.tagbits & tagbits.annotationresolved) != 0) return;
packagebinding.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
break;
case binding.type :
case binding.generic_type :
referencebinding type = (referencebinding) recipient;
if ((type.tagbits & tagbits.annotationresolved) != 0) return;
type.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
if (length > 0) {
annotations = new annotationbinding[length];
type.setannotations(annotations);
}
break;
case binding.method :
methodbinding method = (methodbinding) recipient;
if ((method.tagbits & tagbits.annotationresolved) != 0) return;
method.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
if (length > 0) {
annotations = new annotationbinding[length];
method.setannotations(annotations);
}
break;
case binding.field :
fieldbinding field = (fieldbinding) recipient;
if ((field.tagbits & tagbits.annotationresolved) != 0) return;
field.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
if (length > 0) {
annotations = new annotationbinding[length];
field.setannotations(annotations);
}
break;
case binding.local :
localvariablebinding local = (localvariablebinding) recipient;
if ((local.tagbits & tagbits.annotationresolved) != 0) return;
local.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
if (length > 0) {
annotations = new annotationbinding[length];
local.setannotations(annotations);
}
break;
default :
return;
}
}
if (sourceannotations == null)
return;
for (int i = 0; i < length; i++) {
annotation annotation = sourceannotations[i];
final binding annotationrecipient = annotation.recipient;
if (annotationrecipient != null && recipient != null) {
// only local and field can share annnotations
switch (recipient.kind()) {
case binding.field :
fieldbinding field = (fieldbinding) recipient;
field.tagbits = ((fieldbinding) annotationrecipient).tagbits;
if (annotations != null) {
// need to fill the instances array
for (int j = 0; j < length; j++) {
annotation annot = sourceannotations[j];
annotations[j] = annot.getcompilerannotation();
}
}
break;
case binding.local :
localvariablebinding local = (localvariablebinding) recipient;
long otherlocaltagbits = ((localvariablebinding) annotationrecipient).tagbits;
local.tagbits = otherlocaltagbits;
if ((otherlocaltagbits & tagbits.annotationsuppresswarnings) == 0) {
// none of the annotations is a suppresswarnings annotation
// need to fill the instances array
if (annotations != null) {
for (int j = 0; j < length; j++) {
annotation annot = sourceannotations[j];
annotations[j] = annot.getcompilerannotation();
}
}
} else if (annotations != null) {
// one of the annotations at least is a suppresswarnings annotation
localdeclaration localdeclaration = local.declaration;
int declarationsourceend = localdeclaration.declarationsourceend;
int declarationsourcestart = localdeclaration.declarationsourcestart;
for (int j = 0; j < length; j++) {
annotation annot = sourceannotations[j];
/*
* annotations are shared between two locals, but we still need to record
* the suppress annotation range for the second local
*/
annotationbinding annotationbinding = annot.getcompilerannotation();
annotations[j] = annotationbinding;
if (annotationbinding != null) {
final referencebinding annotationtype = annotationbinding.getannotationtype();
if (annotationtype != null && annotationtype.id == typeids.t_javalangsuppresswarnings) {
annot.recordsuppresswarnings(scope, declarationsourcestart, declarationsourceend, scope.compileroptions().suppresswarnings);
}
}
}
}
break;
}
return;
} else {
annotation.recipient = recipient;
annotation.resolvetype(scope);
// null if receiver is a package binding
if (annotations != null) {
annotations[i] = annotation.getcompilerannotation();
}
}
}
// check duplicate annotations
if (annotations != null) {
annotationbinding[] distinctannotations = annotations; // only copy after 1st duplicate is detected
for (int i = 0; i < length; i++) {
annotationbinding annotation = distinctannotations[i];
if (annotation == null) continue;
typebinding annotationtype = annotation.getannotationtype();
boolean foundduplicate = false;
for (int j = i+1; j < length; j++) {
annotationbinding otherannotation = distinctannotations[j];
if (otherannotation == null) continue;
if (otherannotation.getannotationtype() == annotationtype) {
foundduplicate = true;
if (distinctannotations == annotations) {
system.arraycopy(distinctannotations, 0, distinctannotations = new annotationbinding[length], 0, length);
}
distinctannotations[j] = null; // report it only once
scope.problemreporter().duplicateannotation(sourceannotations[j]);
}
}
if (foundduplicate) {
scope.problemreporter().duplicateannotation(sourceannotations[i]);
}
}
}
}

/**
* figures if @@deprecated annotation is specified, do not resolve entire annotations.
*/
public static void resolvedeprecatedannotations(blockscope scope, annotation[] annotations, binding recipient) {
if (recipient != null) {
int kind = recipient.kind();
if (annotations != null) {
int length;
if ((length = annotations.length) >= 0) {
switch (kind) {
case binding.package :
packagebinding packagebinding = (packagebinding) recipient;
if ((packagebinding.tagbits & tagbits.deprecatedannotationresolved) != 0) return;
break;
case binding.type :
case binding.generic_type :
referencebinding type = (referencebinding) recipient;
if ((type.tagbits & tagbits.deprecatedannotationresolved) != 0) return;
break;
case binding.method :
methodbinding method = (methodbinding) recipient;
if ((method.tagbits & tagbits.deprecatedannotationresolved) != 0) return;
break;
case binding.field :
fieldbinding field = (fieldbinding) recipient;
if ((field.tagbits & tagbits.deprecatedannotationresolved) != 0) return;
break;
case binding.local :
localvariablebinding local = (localvariablebinding) recipient;
if ((local.tagbits & tagbits.deprecatedannotationresolved) != 0) return;
break;
default :
return;
}
for (int i = 0; i < length; i++) {
typereference annotationtyperef = annotations[i].type;
// only resolve type name if 'deprecated' last token
if (!charoperation.equals(typeconstants.java_lang_deprecated[2], annotationtyperef.getlasttoken())) return;
typebinding annotationtype = annotations[i].type.resolvetype(scope);
if(annotationtype != null && annotationtype.isvalidbinding() && annotationtype.id == typeids.t_javalangdeprecated) {
switch (kind) {
case binding.package :
packagebinding packagebinding = (packagebinding) recipient;
packagebinding.tagbits |= (tagbits.annotationdeprecated | tagbits.deprecatedannotationresolved);
return;
case binding.type :
case binding.generic_type :
case binding.type_parameter :
referencebinding type = (referencebinding) recipient;
type.tagbits |= (tagbits.annotationdeprecated | tagbits.deprecatedannotationresolved);
return;
case binding.method :
methodbinding method = (methodbinding) recipient;
method.tagbits |= (tagbits.annotationdeprecated | tagbits.deprecatedannotationresolved);
return;
case binding.field :
fieldbinding field = (fieldbinding) recipient;
field.tagbits |= (tagbits.annotationdeprecated | tagbits.deprecatedannotationresolved);
return;
case binding.local :
localvariablebinding local = (localvariablebinding) recipient;
local.tagbits |= (tagbits.annotationdeprecated | tagbits.deprecatedannotationresolved);
return;
default:
return;
}
}
}
}
}
switch (kind) {
case binding.package :
packagebinding packagebinding = (packagebinding) recipient;
packagebinding.tagbits |= tagbits.deprecatedannotationresolved;
return;
case binding.type :
case binding.generic_type :
case binding.type_parameter :
referencebinding type = (referencebinding) recipient;
type.tagbits |= tagbits.deprecatedannotationresolved;
return;
case binding.method :
methodbinding method = (methodbinding) recipient;
method.tagbits |= tagbits.deprecatedannotationresolved;
return;
case binding.field :
fieldbinding field = (fieldbinding) recipient;
field.tagbits |= tagbits.deprecatedannotationresolved;
return;
case binding.local :
localvariablebinding local = (localvariablebinding) recipient;
local.tagbits |= tagbits.deprecatedannotationresolved;
return;
default:
return;
}
}
}

public int sourcestart() {
return this.sourcestart;
}
public int sourceend() {
return this.sourceend;
}
public string tostring() {

return print(0, new stringbuffer(30)).tostring();
}

public void traverse(astvisitor visitor, blockscope scope) {
// do nothing by default
}
}
