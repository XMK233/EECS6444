/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;

public class syntheticaccessmethodbinding extends methodbinding {

public fieldbinding targetreadfield;		// read access to a field
public fieldbinding targetwritefield;		// write access to a field
public methodbinding targetmethod;	// method or constructor

public int accesstype;

public final static int fieldreadaccess = 1; 		// field read
public final static int fieldwriteaccess = 2; 		// field write
public final static int methodaccess = 3; 		// normal method
public final static int constructoraccess = 4; 	// constructor
public final static int supermethodaccess = 5; // super method
public final static int bridgemethodaccess = 6; // bridge method

final static char[] accessmethodprefix = { 'a', 'c', 'c', 'e', 's', 's', '$' };

public int sourcestart = 0; // start position of the matching declaration
public int index; // used for sorting access methods in the class file

public syntheticaccessmethodbinding(fieldbinding targetfield, boolean isreadaccess, referencebinding declaringclass) {

this.modifiers = accdefault | accstatic | accsynthetic;
sourcetypebinding declaringsourcetype = (sourcetypebinding) declaringclass;
syntheticaccessmethodbinding[] knownaccessmethods = declaringsourcetype.syntheticaccessmethods();
int methodid = knownaccessmethods == null ? 0 : knownaccessmethods.length;
this.index = methodid;
this.selector = charoperation.concat(accessmethodprefix, string.valueof(methodid).tochararray());
if (isreadaccess) {
this.returntype = targetfield.type;
if (targetfield.isstatic()) {
this.parameters = noparameters;
} else {
this.parameters = new typebinding[1];
this.parameters[0] = declaringsourcetype;
}
this.targetreadfield = targetfield;
this.accesstype = fieldreadaccess;
} else {
this.returntype = voidbinding;
if (targetfield.isstatic()) {
this.parameters = new typebinding[1];
this.parameters[0] = targetfield.type;
} else {
this.parameters = new typebinding[2];
this.parameters[0] = declaringsourcetype;
this.parameters[1] = targetfield.type;
}
this.targetwritefield = targetfield;
this.accesstype = fieldwriteaccess;
}
this.thrownexceptions = noexceptions;
this.declaringclass = declaringsourcetype;

// check for method collision
boolean needrename;
do {
check : {
needrename = false;
// check for collision with known methods
methodbinding[] methods = declaringsourcetype.methods;
for (int i = 0, length = methods.length; i < length; i++) {
if (charoperation.equals(this.selector, methods[i].selector) && this.areparametersequal(methods[i])) {
needrename = true;
break check;
}
}
// check for collision with synthetic accessors
if (knownaccessmethods != null) {
for (int i = 0, length = knownaccessmethods.length; i < length; i++) {
if (knownaccessmethods[i] == null) continue;
if (charoperation.equals(this.selector, knownaccessmethods[i].selector) && this.areparametersequal(methods[i])) {
needrename = true;
break check;
}
}
}
}
if (needrename) { // retry with a selector postfixed by a growing methodid
this.setselector(charoperation.concat(accessmethodprefix, string.valueof(++methodid).tochararray()));
}
} while (needrename);

// retrieve sourcestart position for the target field for line number attributes
fielddeclaration[] fielddecls = declaringsourcetype.scope.referencecontext.fields;
if (fielddecls != null) {
for (int i = 0, max = fielddecls.length; i < max; i++) {
if (fielddecls[i].binding == targetfield) {
this.sourcestart = fielddecls[i].sourcestart;
return;
}
}
}

/* did not find the target field declaration - it is a synthetic one
public class a {
public class b {
public class c {
void foo() {
system.out.println("a.this = " + a.this);
}
}
}
public static void main(string args[]) {
new a().new b().new c().foo();
}
}
*/
// we now at this point - per construction - it is for sure an enclosing instance, we are going to
// show the target field type declaration location.
this.sourcestart = declaringsourcetype.scope.referencecontext.sourcestart; // use the target declaring class name position instead
}

public syntheticaccessmethodbinding(methodbinding targetmethod, boolean issuperaccess, referencebinding receivertype) {

if (targetmethod.isconstructor()) {
this.initializeconstructoraccessor(targetmethod);
} else {
this.initializemethodaccessor(targetmethod, issuperaccess, receivertype);
}
}

/*
* construct a bridge method
*/
public syntheticaccessmethodbinding(methodbinding overridenmethodtobridge, methodbinding localtargetmethod) {
this.declaringclass = localtargetmethod.declaringclass;
this.selector = overridenmethodtobridge.selector;
this.modifiers = overridenmethodtobridge.modifiers | accbridge | accsynthetic;
this.modifiers &= ~(accabstract | accnative);
this.returntype = overridenmethodtobridge.returntype;
this.parameters = overridenmethodtobridge.parameters;
this.thrownexceptions = overridenmethodtobridge.thrownexceptions;
this.targetmethod = localtargetmethod;
this.accesstype = bridgemethodaccess;
syntheticaccessmethodbinding[] knownaccessmethods = ((sourcetypebinding)this.declaringclass).syntheticaccessmethods();
int methodid = knownaccessmethods == null ? 0 : knownaccessmethods.length;
this.index = methodid;
}

/**
* an constructor accessor is a constructor with an extra argument (declaringclass), in case of
* collision with an existing constructor, then add again an extra argument (declaringclass again).
*/
public void initializeconstructoraccessor(methodbinding accessedconstructor) {

this.targetmethod = accessedconstructor;
this.modifiers = accdefault | accsynthetic;
sourcetypebinding sourcetype = (sourcetypebinding) accessedconstructor.declaringclass;
syntheticaccessmethodbinding[] knownaccessmethods =
sourcetype.syntheticaccessmethods();
this.index = knownaccessmethods == null ? 0 : knownaccessmethods.length;

this.selector = accessedconstructor.selector;
this.returntype = accessedconstructor.returntype;
this.accesstype = constructoraccess;
this.parameters = new typebinding[accessedconstructor.parameters.length + 1];
system.arraycopy(
accessedconstructor.parameters,
0,
this.parameters,
0,
accessedconstructor.parameters.length);
parameters[accessedconstructor.parameters.length] =
accessedconstructor.declaringclass;
this.thrownexceptions = accessedconstructor.thrownexceptions;
this.declaringclass = sourcetype;

// check for method collision
boolean needrename;
do {
check : {
needrename = false;
// check for collision with known methods
methodbinding[] methods = sourcetype.methods;
for (int i = 0, length = methods.length; i < length; i++) {
if (charoperation.equals(this.selector, methods[i].selector)
&& this.areparametersequal(methods[i])) {
needrename = true;
break check;
}
}
// check for collision with synthetic accessors
if (knownaccessmethods != null) {
for (int i = 0, length = knownaccessmethods.length; i < length; i++) {
if (knownaccessmethods[i] == null)
continue;
if (charoperation.equals(this.selector, knownaccessmethods[i].selector)
&& this.areparametersequal(knownaccessmethods[i])) {
needrename = true;
break check;
}
}
}
}
if (needrename) { // retry with a new extra argument
int length = this.parameters.length;
system.arraycopy(
this.parameters,
0,
this.parameters = new typebinding[length + 1],
0,
length);
this.parameters[length] = this.declaringclass;
}
} while (needrename);

// retrieve sourcestart position for the target method for line number attributes
abstractmethoddeclaration[] methoddecls =
sourcetype.scope.referencecontext.methods;
if (methoddecls != null) {
for (int i = 0, length = methoddecls.length; i < length; i++) {
if (methoddecls[i].binding == accessedconstructor) {
this.sourcestart = methoddecls[i].sourcestart;
return;
}
}
}
}

/**
* an method accessor is a method with an access$n selector, where n is incremented in case of collisions.
*/
public void initializemethodaccessor(methodbinding accessedmethod, boolean issuperaccess, referencebinding receivertype) {

this.targetmethod = accessedmethod;
this.modifiers = accdefault | accstatic | accsynthetic;
sourcetypebinding declaringsourcetype = (sourcetypebinding) receivertype;
syntheticaccessmethodbinding[] knownaccessmethods = declaringsourcetype.syntheticaccessmethods();
int methodid = knownaccessmethods == null ? 0 : knownaccessmethods.length;
this.index = methodid;

this.selector = charoperation.concat(accessmethodprefix, string.valueof(methodid).tochararray());
this.returntype = accessedmethod.returntype;
this.accesstype = issuperaccess ? supermethodaccess : methodaccess;

if (accessedmethod.isstatic()) {
this.parameters = accessedmethod.parameters;
} else {
this.parameters = new typebinding[accessedmethod.parameters.length + 1];
this.parameters[0] = declaringsourcetype;
system.arraycopy(accessedmethod.parameters, 0, this.parameters, 1, accessedmethod.parameters.length);
}
this.thrownexceptions = accessedmethod.thrownexceptions;
this.declaringclass = declaringsourcetype;

// check for method collision
boolean needrename;
do {
check : {
needrename = false;
// check for collision with known methods
methodbinding[] methods = declaringsourcetype.methods;
for (int i = 0, length = methods.length; i < length; i++) {
if (charoperation.equals(this.selector, methods[i].selector) && this.areparametersequal(methods[i])) {
needrename = true;
break check;
}
}
// check for collision with synthetic accessors
if (knownaccessmethods != null) {
for (int i = 0, length = knownaccessmethods.length; i < length; i++) {
if (knownaccessmethods[i] == null) continue;
if (charoperation.equals(this.selector, knownaccessmethods[i].selector) && this.areparametersequal(knownaccessmethods[i])) {
needrename = true;
break check;
}
}
}
}
if (needrename) { // retry with a selector & a growing methodid
this.setselector(charoperation.concat(accessmethodprefix, string.valueof(++methodid).tochararray()));
}
} while (needrename);

// retrieve sourcestart position for the target method for line number attributes
abstractmethoddeclaration[] methoddecls = declaringsourcetype.scope.referencecontext.methods;
if (methoddecls != null) {
for (int i = 0, length = methoddecls.length; i < length; i++) {
if (methoddecls[i].binding == accessedmethod) {
this.sourcestart = methoddecls[i].sourcestart;
return;
}
}
}
}

protected boolean isconstructorrelated() {
return accesstype == constructoraccess;
}
}
