/*******************************************************************************
* copyright (c) 2006, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.codeassist.complete.completionparser;
import org.eclipse.jdt.internal.codeassist.complete.completionscanner;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.argument;
import org.eclipse.jdt.internal.compiler.ast.block;
import org.eclipse.jdt.internal.compiler.ast.constructordeclaration;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.ast.initializer;
import org.eclipse.jdt.internal.compiler.ast.localdeclaration;
import org.eclipse.jdt.internal.compiler.ast.methoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.statement;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.util.simplesetofchararray;
import org.eclipse.jdt.internal.compiler.util.util;

public class unresolvedreferencenamefinder extends astvisitor {
private static final int max_line_count = 100;
private static final int fake_blocks_count = 20;

public static interface unresolvedreferencenamerequestor {
public void acceptname(char[] name);
}

private unresolvedreferencenamerequestor requestor;

private completionengine completionengine;
private completionparser parser;
private completionscanner completionscanner;

private int parentsptr;
private astnode[] parents;

private int potentialvariablenamesptr;
private char[][] potentialvariablenames;
private int[] potentialvariablenamestarts;

private simplesetofchararray acceptednames = new simplesetofchararray();

public unresolvedreferencenamefinder(completionengine completionengine) {
this.completionengine = completionengine;
this.parser = completionengine.parser;
this.completionscanner = (completionscanner) this.parser.scanner;
}

private void acceptname(char[] name) {
// the null check is added to fix bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=166570
if (name == null) return;

if (!charoperation.prefixequals(this.completionengine.completiontoken, name, false /* ignore case */)
&& !(this.completionengine.options.camelcasematch && charoperation.camelcasematch(this.completionengine.completiontoken, name))) return;

if (this.acceptednames.includes(name)) return;

this.acceptednames.add(name);

// accept result
this.requestor.acceptname(name);
}

public void find(
char[] startwith,
initializer initializer,
classscope scope,
int from,
char[][] discouragednames,
unresolvedreferencenamerequestor namerequestor) {
methoddeclaration fakemethod =
this.findafter(startwith, scope, from, initializer.bodyend, max_line_count, false, discouragednames, namerequestor);
if (fakemethod != null) fakemethod.traverse(this, scope);
}

public void find(
char[] startwith,
abstractmethoddeclaration methoddeclaration,
int from,
char[][] discouragednames,
unresolvedreferencenamerequestor namerequestor) {
methoddeclaration fakemethod =
this.findafter(startwith, methoddeclaration.scope, from, methoddeclaration.bodyend, max_line_count, false, discouragednames, namerequestor);
if (fakemethod != null) fakemethod.traverse(this, methoddeclaration.scope.classscope());
}

public void findafter(
char[] startwith,
scope scope,
classscope classscope,
int from,
int to,
char[][] discouragednames,
unresolvedreferencenamerequestor namerequestor) {
methoddeclaration fakemethod =
this.findafter(startwith, scope, from, to, max_line_count / 2, true, discouragednames, namerequestor);
if (fakemethod != null) fakemethod.traverse(this, classscope);
}

private methoddeclaration findafter(
char[] startwith,
scope s,
int from,
int to,
int maxlinecount,
boolean outsideenclosingblock,
char[][] discouragednames,
unresolvedreferencenamerequestor namerequestor) {
this.requestor = namerequestor;

// reinitialize completion scanner to be usable as a normal scanner
this.completionscanner.cursorlocation = 0;

if (!outsideenclosingblock) {
// compute location of the end of the current block
this.completionscanner.resetto(from + 1, to);
this.completionscanner.jumpoverblock();

to = this.completionscanner.startposition - 1;
}

int maxend =
this.completionscanner.getlineend(
util.getlinenumber(from, this.completionscanner.lineends, 0, this.completionscanner.lineptr) + maxlinecount);

int end;
if (maxend < 0) {
end = to;
} else {
end = maxend < to ? maxend : to;
}

this.parser.startrecordingidentifiers(from, end);

methoddeclaration fakemethod = this.parser.parsesomestatements(
from,
end,
outsideenclosingblock ? fake_blocks_count : 0,
s.compilationunitscope().referencecontext);

this.parser.stoprecordingidentifiers();

if(!initpotentialnamestables(discouragednames)) return null;

this.parentsptr = -1;
this.parents = new astnode[10];

return fakemethod;
}

public void findbefore(
char[] startwith,
scope scope,
classscope classscope,
int from,
int recordto,
int parseto,
char[][] discouragednames,
unresolvedreferencenamerequestor namerequestor) {
methoddeclaration fakemethod =
this.findbefore(startwith, scope, from, recordto, parseto, max_line_count / 2, discouragednames, namerequestor);
if (fakemethod != null) fakemethod.traverse(this, classscope);
}

private methoddeclaration findbefore(
char[] startwith,
scope s,
int from,
int recordto,
int parseto,
int maxlinecount,
char[][] discouragednames,
unresolvedreferencenamerequestor namerequestor) {
this.requestor = namerequestor;

// reinitialize completion scanner to be usable as a normal scanner
this.completionscanner.cursorlocation = 0;

int minstart =
this.completionscanner.getlinestart(
util.getlinenumber(recordto, this.completionscanner.lineends, 0, this.completionscanner.lineptr) - maxlinecount);

int start;
int fakeblockscount;
if (minstart <= from) {
start = from;
fakeblockscount = 0;
} else {
start = minstart;
fakeblockscount = fake_blocks_count;
}

this.parser.startrecordingidentifiers(start, recordto);

methoddeclaration fakemethod = this.parser.parsesomestatements(
start,
parseto,
fakeblockscount,
s.compilationunitscope().referencecontext);

this.parser.stoprecordingidentifiers();

if(!initpotentialnamestables(discouragednames)) return null;

this.parentsptr = -1;
this.parents = new astnode[10];

return fakemethod;
}

private boolean initpotentialnamestables(char[][] discouragednames) {
char[][] pvns = this.parser.potentialvariablenames;
int[] pvnss = this.parser.potentialvariablenamestarts;
int pvnsptr = this.parser.potentialvariablenamesptr;

if (pvnsptr < 0) return false; // there is no potential names

// remove null and discouragednames
int discouragednamescount = discouragednames == null ? 0 : discouragednames.length;
int j = -1;
next : for (int i = 0; i <= pvnsptr; i++) {
char[] temp = pvns[i];

if (temp == null) continue next;

for (int k = 0; k < discouragednamescount; k++) {
if (charoperation.equals(temp, discouragednames[k], false)) {
continue next;
}
}

pvns[i] = null;
pvns[++j] = temp;
pvnss[j] = pvnss[i];
}
pvnsptr = j;

if (pvnsptr < 0) return false; // there is no potential names

this.potentialvariablenames = pvns;
this.potentialvariablenamestarts = pvnss;
this.potentialvariablenamesptr = pvnsptr;

return true;
}

private void popparent() {
this.parentsptr--;
}
private void pushparent(astnode parent) {
int length = this.parents.length;
if (this.parentsptr >= length - 1) {
system.arraycopy(this.parents, 0, this.parents = new astnode[length * 2], 0, length);
}
this.parents[++this.parentsptr] = parent;
}

private astnode getenclosingdeclaration() {
int i = this.parentsptr;
while (i > -1) {
astnode parent = this.parents[i];
if (parent instanceof abstractmethoddeclaration) {
return parent;
} else if (parent instanceof initializer) {
return parent;
} else if (parent instanceof fielddeclaration) {
return parent;
} else if (parent instanceof typedeclaration) {
return parent;
}
i--;
}
return null;
}

public boolean visit(block block, blockscope blockscope) {
astnode enclosingdeclaration = getenclosingdeclaration();
removelocals(block.statements, enclosingdeclaration.sourcestart, block.sourceend);
pushparent(block);
return true;
}

public boolean visit(constructordeclaration constructordeclaration, classscope classscope) {
if (((constructordeclaration.bits & astnode.isdefaultconstructor) == 0) && !constructordeclaration.isclinit()) {
removelocals(
constructordeclaration.arguments,
constructordeclaration.declarationsourcestart,
constructordeclaration.declarationsourceend);
removelocals(
constructordeclaration.statements,
constructordeclaration.declarationsourcestart,
constructordeclaration.declarationsourceend);
}
pushparent(constructordeclaration);
return true;
}

public boolean visit(fielddeclaration fielddeclaration, methodscope methodscope) {
pushparent(fielddeclaration);
return true;
}

public boolean visit(initializer initializer, methodscope methodscope) {
pushparent(initializer);
return true;
}

public boolean visit(methoddeclaration methoddeclaration, classscope classscope) {
removelocals(
methoddeclaration.arguments,
methoddeclaration.declarationsourcestart,
methoddeclaration.declarationsourceend);
removelocals(
methoddeclaration.statements,
methoddeclaration.declarationsourcestart,
methoddeclaration.declarationsourceend);
pushparent(methoddeclaration);
return true;
}

public boolean visit(typedeclaration localtypedeclaration, blockscope blockscope) {
removefields(localtypedeclaration);
pushparent(localtypedeclaration);
return true;
}

public boolean visit(typedeclaration membertypedeclaration, classscope classscope) {
removefields(membertypedeclaration);
pushparent(membertypedeclaration);
return true;
}

public void endvisit(block block, blockscope blockscope) {
popparent();
}

public void endvisit(argument argument, blockscope blockscope) {
endvisitremoved(argument.declarationsourcestart, argument.sourceend);
}

public void endvisit(argument argument, classscope classscope) {
endvisitremoved(argument.declarationsourcestart, argument.sourceend);
}

public void endvisit(constructordeclaration constructordeclaration, classscope classscope) {
if (((constructordeclaration.bits & astnode.isdefaultconstructor) == 0) && !constructordeclaration.isclinit()) {
endvisitpreserved(constructordeclaration.bodystart, constructordeclaration.bodyend);
}
popparent();
}

public void endvisit(fielddeclaration fielddeclaration, methodscope methodscope) {
endvisitremoved(fielddeclaration.declarationsourcestart, fielddeclaration.sourceend);
endvisitpreserved(fielddeclaration.sourceend, fielddeclaration.declarationend);
popparent();
}

public void endvisit(initializer initializer, methodscope methodscope) {
endvisitpreserved(initializer.bodystart, initializer.bodyend);
popparent();
}

public void endvisit(localdeclaration localdeclaration, blockscope blockscope) {
endvisitremoved(localdeclaration.declarationsourcestart, localdeclaration.sourceend);
}

public void endvisit(methoddeclaration methoddeclaration, classscope classscope) {
endvisitpreserved(
methoddeclaration.bodystart,
methoddeclaration.bodyend);
popparent();
}

public void endvisit(typedeclaration typedeclaration, blockscope blockscope) {
endvisitremoved(typedeclaration.sourcestart, typedeclaration.declarationsourceend);
popparent();
}

public void endvisit(typedeclaration typedeclaration, classscope classscope) {
endvisitremoved(typedeclaration.sourcestart, typedeclaration.declarationsourceend);
popparent();
}

private int indexoffisrtnameafter(int position) {
int left = 0;
int right = this.potentialvariablenamesptr;

next : while (true) {
if (right < left) return -1;

int mid = left + (right - left) / 2;
int midposition = this.potentialvariablenamestarts[mid];
if (midposition < 0) {
int nextmid = indexofnextname(mid);
if (nextmid < 0 || right < nextmid) { // no next index or next index is after 'right'
right = mid - 1;
continue next;
}
mid = nextmid;
midposition = this.potentialvariablenamestarts[nextmid];

if (mid == right) { // mid and right are at the same index, we must move 'left'
int leftposition = this.potentialvariablenamestarts[left];
if (leftposition < 0 || leftposition < position) { // 'left' is empty or 'left' is before the position
int nextleft = indexofnextname(left);
if (nextleft < 0) return - 1;

left = nextleft;
continue next;
}

return left;
}
}

if (left != right) {
if (midposition < position) {
left = mid + 1;
} else {
right = mid;
}
} else {
if (midposition < position) {
return -1;
}
return mid;
}
}
}

private int indexofnextname(int index) {
int nextindex = index + 1;
while (nextindex <= this.potentialvariablenamesptr &&
this.potentialvariablenames[nextindex] == null) {
int jumpindex = -this.potentialvariablenamestarts[nextindex];
if (jumpindex > 0) {
nextindex = jumpindex;
} else {
nextindex++;
}
}

if (this.potentialvariablenamesptr < nextindex) {
if  (index < this.potentialvariablenamesptr) {
this.potentialvariablenamesptr = index;
}
return -1;
}
if (index + 1 < nextindex) {
this.potentialvariablenamestarts[index + 1] = -nextindex;
}
return nextindex;
}

private void removenameat(int index) {
this.potentialvariablenames[index] = null;
int nextindex = indexofnextname(index);
if (nextindex != -1) {
this.potentialvariablenamestarts[index] = -nextindex;
} else {
this.potentialvariablenamesptr = index - 1;
}
}

private void endvisitpreserved(int start, int end) {
int i = indexoffisrtnameafter(start);
done : while (i != -1) {
int namestart = this.potentialvariablenamestarts[i];
if (start < namestart && namestart < end) {
acceptname(this.potentialvariablenames[i]);
removenameat(i);
}

if (end < namestart) break done;
i = indexofnextname(i);
}
}

private void endvisitremoved(int start, int end) {
int i = indexoffisrtnameafter(start);
done : while (i != -1) {
int namestart = this.potentialvariablenamestarts[i];
if (start < namestart && namestart < end) {
removenameat(i);
}

if (end < namestart) break done;
i = indexofnextname(i);
}
}

private void removelocals(statement[] statements, int start, int end) {
if (statements != null) {
for (int i = 0; i < statements.length; i++) {
if (statements[i] instanceof localdeclaration) {
localdeclaration localdeclaration = (localdeclaration) statements[i];
int j = indexoffisrtnameafter(start);
done : while (j != -1) {
int namestart = this.potentialvariablenamestarts[j];
if (start <= namestart && namestart <= end) {
if (charoperation.equals(this.potentialvariablenames[j], localdeclaration.name, false)) {
removenameat(j);
}
}

if (end < namestart) break done;
j = indexofnextname(j);
}
}
}

}
}

private void removefields(typedeclaration typedeclaration) {
int start = typedeclaration.declarationsourcestart;
int end = typedeclaration.declarationsourceend;

fielddeclaration[] fielddeclarations = typedeclaration.fields;
if (fielddeclarations != null) {
for (int i = 0; i < fielddeclarations.length; i++) {
int j = indexoffisrtnameafter(start);
done : while (j != -1) {
int namestart = this.potentialvariablenamestarts[j];
if (start <= namestart && namestart <= end) {
if (charoperation.equals(this.potentialvariablenames[j], fielddeclarations[i].name, false)) {
removenameat(j);
}
}

if (end < namestart) break done;
j = indexofnextname(j);
}
}
}
}
}
