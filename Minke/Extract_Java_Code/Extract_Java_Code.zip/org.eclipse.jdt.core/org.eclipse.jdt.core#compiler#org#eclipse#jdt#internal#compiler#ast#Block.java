/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class block extends statement {

public statement[] statements;
public int explicitdeclarations;
// the number of explicit declaration , used to create scope
public blockscope scope;

public block(int explicitdeclarations) {
this.explicitdeclarations = explicitdeclarations;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
// empty block
if (this.statements == null)	return flowinfo;
int complaintlevel = (flowinfo.reachmode() & flowinfo.unreachable) != 0 ? statement.complained_fake_reachable : statement.not_complained;
for (int i = 0, max = this.statements.length; i < max; i++) {
statement stat = this.statements[i];
if ((complaintlevel = stat.complainifunreachable(flowinfo, this.scope, complaintlevel)) < statement.complained_unreachable) {
flowinfo = stat.analysecode(this.scope, flowcontext, flowinfo);
}
}
return flowinfo;
}
/**
* code generation for a block
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & isreachable) == 0) {
return;
}
int pc = codestream.position;
if (this.statements != null) {
for (int i = 0, max = this.statements.length; i < max; i++) {
this.statements[i].generatecode(this.scope, codestream);
}
} // for local variable debug attributes
if (this.scope != currentscope) { // was really associated with its own scope
codestream.exituserscope(this.scope);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public boolean isemptyblock() {
return this.statements == null;
}

public stringbuffer printbody(int indent, stringbuffer output) {
if (this.statements == null) return output;
for (int i = 0; i < this.statements.length; i++) {
this.statements[i].printstatement(indent + 1, output);
output.append('\n');
}
return output;
}

public stringbuffer printstatement(int indent, stringbuffer output) {
printindent(indent, output);
output.append("{\n"); //$non-nls-1$
printbody(indent, output);
return printindent(indent, output).append('}');
}

public void resolve(blockscope upperscope) {
if ((this.bits & undocumentedemptyblock) != 0) {
upperscope.problemreporter().undocumentedemptyblock(this.sourcestart, this.sourceend);
}
if (this.statements != null) {
this.scope =
this.explicitdeclarations == 0
? upperscope
: new blockscope(upperscope, this.explicitdeclarations);
for (int i = 0, length = this.statements.length; i < length; i++) {
this.statements[i].resolve(this.scope);
}
}
}

public void resolveusing(blockscope givenscope) {
if ((this.bits & undocumentedemptyblock) != 0) {
givenscope.problemreporter().undocumentedemptyblock(this.sourcestart, this.sourceend);
}
// this optimized resolve(...) is sent only on none empty blocks
this.scope = givenscope;
if (this.statements != null) {
for (int i = 0, length = this.statements.length; i < length; i++) {
this.statements[i].resolve(this.scope);
}
}
}

public void traverse(astvisitor visitor, blockscope blockscope) {
if (visitor.visit(this, blockscope)) {
if (this.statements != null) {
for (int i = 0, length = this.statements.length; i < length; i++)
this.statements[i].traverse(visitor, this.scope);
}
}
visitor.endvisit(this, blockscope);
}

/**
* dispatch the call on its last statement.
*/
public void branchchainto(branchlabel label) {
if (this.statements != null) {
this.statements[this.statements.length - 1].branchchainto(label);
}
}
}
