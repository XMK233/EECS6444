/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

import org.eclipse.jdt.internal.compiler.impl.constant;

public interface ibinaryfield extends igenericfield {
/**
* answer the runtime visible and invisible annotations for this field or null if none.
*/
ibinaryannotation[] getannotations();

/**
*
* @@return org.eclipse.jdt.internal.compiler.constant
*/
constant getconstant();

/**
* answer the receiver's signature which describes the parameter &
* return types as specified in section 4.4.4 of the java 2 vm spec.
*/
char[] getgenericsignature();

/**
* answer the name of the field.
*/
char[] getname();

/**
* answer the tagbits set according to the bits for annotations.
*/
long gettagbits();

/**
* answer the resolved name of the receiver's type in the
* class file format as specified in section 4.3.2 of the java 2 vm spec.
*
* for example:
*   - java.lang.string is ljava/lang/string;
*   - an int is i
*   - a 2 dimensional array of strings is [[ljava/lang/string;
*   - an array of floats is [f
*/
char[] gettypename();
}
