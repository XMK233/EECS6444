/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

import org.eclipse.jdt.internal.compiler.ast.astnode;

/**
* this interface defines constants for use by the builder / compiler
* interface.
*/
public interface iconstants {
int accdefault = 0;
/*
* modifiers
*/
int accpublic       = 0x0001;
int accprivate      = 0x0002;
int accprotected    = 0x0004;
int accstatic       = 0x0008;
int accfinal        = 0x0010;
int accsynchronized = 0x0020;
int accvolatile     = 0x0040;
int accbridge       = 0x0040;
int acctransient    = 0x0080;
int accvarargs      = 0x0080;
int accnative       = 0x0100;
int accinterface    = 0x0200;
int accabstract     = 0x0400;
int accstrictfp     = 0x0800;
int accsynthetic    = 0x1000;
int accannotation   = 0x2000;
int accenum         = 0x4000;

/**
* other vm flags.
*/
int accsuper = 0x0020;
/**
* extra flags for types and members attributes.
*/
int accannotationdefault = astnode.bit18; // indicate presence of an attribute  "defaultvalue" (annotation method)
int accdeprecated = astnode.bit21; // indicate presence of an attribute "deprecated"


}
