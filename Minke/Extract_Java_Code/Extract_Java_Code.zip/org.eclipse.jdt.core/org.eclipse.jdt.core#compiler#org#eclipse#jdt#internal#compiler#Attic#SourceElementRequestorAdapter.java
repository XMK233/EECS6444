/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

import org.eclipse.jdt.core.compiler.iproblem;

public class sourceelementrequestoradapter implements isourceelementrequestor {

/*
* @@see isourceelementrequestor#acceptconstructorreference(char[], int, int)
*/
public void acceptconstructorreference(
char[] typename,
int argcount,
int sourceposition) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#acceptfieldreference(char[], int)
*/
public void acceptfieldreference(char[] fieldname, int sourceposition) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#acceptimport(int, int, char[], boolean, int)
*/
public void acceptimport(
int declarationstart,
int declarationend,
char[] name,
boolean ondemand,
int modifiers) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#acceptlineseparatorpositions(int[])
*/
public void acceptlineseparatorpositions(int[] positions) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#acceptmethodreference(char[], int, int)
*/
public void acceptmethodreference(
char[] methodname,
int argcount,
int sourceposition) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#acceptpackage(int, int, char[])
*/
public void acceptpackage(
int declarationstart,
int declarationend,
char[] name) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#acceptproblem(iproblem)
*/
public void acceptproblem(iproblem problem) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#accepttypereference(char[][], int, int)
*/
public void accepttypereference(
char[][] typename,
int sourcestart,
int sourceend) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#accepttypereference(char[], int)
*/
public void accepttypereference(char[] typename, int sourceposition) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#acceptunknownreference(char[][], int, int)
*/
public void acceptunknownreference(
char[][] name,
int sourcestart,
int sourceend) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#acceptunknownreference(char[], int)
*/
public void acceptunknownreference(char[] name, int sourceposition) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#enterclass(int, int, char[], int, int, char[], char[][])
*/
public void enterclass(
int declarationstart,
int modifiers,
char[] name,
int namesourcestart,
int namesourceend,
char[] superclass,
char[][] superinterfaces) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#entercompilationunit()
*/
public void entercompilationunit() {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#enterconstructor(int, int, char[], int, int, char[][], char[][], char[][])
*/
public void enterconstructor(
int declarationstart,
int modifiers,
char[] name,
int namesourcestart,
int namesourceend,
char[][] parametertypes,
char[][] parameternames,
char[][] exceptiontypes) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#enterfield(int, int, char[], char[], int, int)
*/
public void enterfield(
int declarationstart,
int modifiers,
char[] type,
char[] name,
int namesourcestart,
int namesourceend) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#enterinitializer(int, int)
*/
public void enterinitializer(int declarationstart, int modifiers) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#enterinterface(int, int, char[], int, int, char[][])
*/
public void enterinterface(
int declarationstart,
int modifiers,
char[] name,
int namesourcestart,
int namesourceend,
char[][] superinterfaces) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#entermethod(int, int, char[], char[], int, int, char[][], char[][], char[][])
*/
public void entermethod(
int declarationstart,
int modifiers,
char[] returntype,
char[] name,
int namesourcestart,
int namesourceend,
char[][] parametertypes,
char[][] parameternames,
char[][] exceptiontypes) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#exitclass(int)
*/
public void exitclass(int declarationend) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#exitcompilationunit(int)
*/
public void exitcompilationunit(int declarationend) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#exitconstructor(int)
*/
public void exitconstructor(int declarationend) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#exitfield(int)
*/
public void exitfield(int initializationstart, int declarationend, int declarationsourceend) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#exitinitializer(int)
*/
public void exitinitializer(int declarationend) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#exitinterface(int)
*/
public void exitinterface(int declarationend) {
// default implementation: do nothing
}

/*
* @@see isourceelementrequestor#exitmethod(int)
*/
public void exitmethod(int declarationend) {
// default implementation: do nothing
}

}

