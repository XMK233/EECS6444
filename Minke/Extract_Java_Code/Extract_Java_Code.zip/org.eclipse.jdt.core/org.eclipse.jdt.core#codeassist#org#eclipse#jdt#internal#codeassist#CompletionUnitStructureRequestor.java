/*******************************************************************************
* copyright (c) 2008, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import java.util.map;

import org.eclipse.jdt.core.iannotation;
import org.eclipse.jdt.core.icompilationunit;
import org.eclipse.jdt.core.imembervaluepair;
import org.eclipse.jdt.internal.codeassist.complete.completiononmarkerannotationname;
import org.eclipse.jdt.internal.codeassist.complete.completiononmembervaluename;
import org.eclipse.jdt.internal.codeassist.complete.completiononparameterizedqualifiedtypereference;
import org.eclipse.jdt.internal.codeassist.complete.completiononqualifiednamereference;
import org.eclipse.jdt.internal.codeassist.complete.completiononqualifiedtypereference;
import org.eclipse.jdt.internal.codeassist.complete.completiononsinglenamereference;
import org.eclipse.jdt.internal.codeassist.complete.completiononsingletypereference;
import org.eclipse.jdt.internal.codeassist.impl.assistannotation;
import org.eclipse.jdt.internal.codeassist.impl.assistimportcontainer;
import org.eclipse.jdt.internal.codeassist.impl.assistimportdeclaration;
import org.eclipse.jdt.internal.codeassist.impl.assistinitializer;
import org.eclipse.jdt.internal.codeassist.impl.assistpackagedeclaration;
import org.eclipse.jdt.internal.codeassist.impl.assistsourcefield;
import org.eclipse.jdt.internal.codeassist.impl.assistsourcemethod;
import org.eclipse.jdt.internal.codeassist.impl.assistsourcetype;
import org.eclipse.jdt.internal.codeassist.impl.assisttypeparameter;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.expression;
import org.eclipse.jdt.internal.compiler.ast.membervaluepair;
import org.eclipse.jdt.internal.compiler.ast.parameterizedqualifiedtypereference;
import org.eclipse.jdt.internal.compiler.ast.parameterizedsingletypereference;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.parser.parser;
import org.eclipse.jdt.internal.core.annotatableinfo;
import org.eclipse.jdt.internal.core.annotation;
import org.eclipse.jdt.internal.core.compilationunit;
import org.eclipse.jdt.internal.core.compilationunitelementinfo;
import org.eclipse.jdt.internal.core.compilationunitstructurerequestor;
import org.eclipse.jdt.internal.core.importcontainer;
import org.eclipse.jdt.internal.core.importdeclaration;
import org.eclipse.jdt.internal.core.initializer;
import org.eclipse.jdt.internal.core.javaelement;
import org.eclipse.jdt.internal.core.javamodelmanager;
import org.eclipse.jdt.internal.core.packagedeclaration;
import org.eclipse.jdt.internal.core.sourcefield;
import org.eclipse.jdt.internal.core.sourcemethod;
import org.eclipse.jdt.internal.core.sourcetype;
import org.eclipse.jdt.internal.core.typeparameter;

public class completionunitstructurerequestor extends compilationunitstructurerequestor {
private astnode assistnode;

private map bindingcache;
private map elementcache;
private map elementwithproblemcache;

public completionunitstructurerequestor(
icompilationunit unit,
compilationunitelementinfo unitinfo,
parser parser,
astnode assistnode,
map bindingcache,
map elementcache,
map elementwithproblemcache,
map newelements) {
super(unit, unitinfo, newelements);
this.parser = parser;
this.assistnode = assistnode;
this.bindingcache = bindingcache;
this.elementcache = elementcache;
this.elementwithproblemcache = elementwithproblemcache;
}

protected annotation createannotation(javaelement parent, string name) {
return new assistannotation(parent, name, this.newelements);
}

protected sourcefield createfield(javaelement parent, fieldinfo fieldinfo) {
string fieldname = javamodelmanager.getjavamodelmanager().intern(new string(fieldinfo.name));
assistsourcefield field = new assistsourcefield(parent, fieldname, this.bindingcache, this.newelements);
if (fieldinfo.node.binding != null) {
this.bindingcache.put(field, fieldinfo.node.binding);
this.elementcache.put(fieldinfo.node.binding, field);
} else {
this.elementwithproblemcache.put(fieldinfo.node, field);
}
return field;
}

protected importcontainer createimportcontainer(icompilationunit parent) {
return new assistimportcontainer((compilationunit)parent, this.newelements);
}

protected importdeclaration createimportdeclaration(importcontainer parent, string name, boolean ondemand) {
return new assistimportdeclaration(parent, name, ondemand, this.newelements);
}

protected initializer createinitializer(javaelement parent) {
return new assistinitializer(parent, 1, this.bindingcache, this.newelements);
}

protected sourcemethod createmethodhandle(javaelement parent, methodinfo methodinfo) {
string selector = javamodelmanager.getjavamodelmanager().intern(new string(methodinfo.name));
string[] parametertypesigs = converttypenamestosigs(methodinfo.parametertypes);
assistsourcemethod method = new assistsourcemethod(parent, selector, parametertypesigs, this.bindingcache, this.newelements);
if (methodinfo.node.binding != null) {
this.bindingcache.put(method, methodinfo.node.binding);
this.elementcache.put(methodinfo.node.binding, method);
} else {
this.elementwithproblemcache.put(methodinfo.node, method);
}
return method;
}

protected packagedeclaration createpackagedeclaration(javaelement parent, string name) {
return new assistpackagedeclaration((compilationunit) parent, name, this.newelements);
}

protected sourcetype createtypehandle(javaelement parent, typeinfo typeinfo) {
string namestring= new string(typeinfo.name);
assistsourcetype type = new assistsourcetype(parent, namestring, this.bindingcache, this.newelements);
if (typeinfo.node.binding != null) {
this.bindingcache.put(type, typeinfo.node.binding);
this.elementcache.put(typeinfo.node.binding, type);
} else {
this.elementwithproblemcache.put(typeinfo.node, type);
}
return type;
}

protected typeparameter createtypeparameter(javaelement parent, string name) {
return new assisttypeparameter(parent, name, this.newelements);
}

protected iannotation acceptannotation(
org.eclipse.jdt.internal.compiler.ast.annotation annotation,
annotatableinfo parentinfo,
javaelement parenthandle) {
if (annotation instanceof completiononmarkerannotationname) {
if (hasemptyname(annotation.type, this.assistnode)) {
super.acceptannotation(annotation, null, parenthandle);
return null;
}
}
return super.acceptannotation(annotation, parentinfo, parenthandle);
}

protected object getmembervalue(
org.eclipse.jdt.internal.core.membervaluepair membervaluepair,
expression expression) {
if (expression instanceof completiononsinglenamereference) {
completiononsinglenamereference reference = (completiononsinglenamereference) expression;
if (reference.token.length == 0) return null;
} else if (expression instanceof completiononqualifiednamereference) {
completiononqualifiednamereference reference = (completiononqualifiednamereference) expression;
if (reference.tokens[reference.tokens.length - 1].length == 0) return null;
}
return super.getmembervalue(membervaluepair, expression);
}
protected imembervaluepair[] getmembervaluepairs(membervaluepair[] membervaluepairs) {
int memberslength = membervaluepairs.length;
int memberscount = 0;
imembervaluepair[] members = new imembervaluepair[memberslength];
next : for (int j = 0; j < memberslength; j++) {
if (membervaluepairs[j] instanceof completiononmembervaluename) continue next;

members[memberscount++] = getmembervaluepair(membervaluepairs[j]);
}

if (memberscount > memberslength) {
system.arraycopy(members, 0, members, 0, memberscount);
}
return members;
}

protected static boolean hasemptyname(typereference reference, astnode assistnode) {
if (reference == null) return false;

if (reference.sourcestart <= assistnode.sourcestart && assistnode.sourceend <= reference.sourceend) return false;

if (reference instanceof completiononsingletypereference ||
reference instanceof completiononqualifiedtypereference ||
reference instanceof completiononparameterizedqualifiedtypereference) {
char[][] typename = reference.gettypename();
if (typename[typename.length - 1].length == 0) return true;
}
if (reference instanceof parameterizedsingletypereference) {
parameterizedsingletypereference parameterizedreference = (parameterizedsingletypereference) reference;
typereference[] typearguments = parameterizedreference.typearguments;
if (typearguments != null) {
for (int i = 0; i < typearguments.length; i++) {
if (hasemptyname(typearguments[i], assistnode)) return true;
}
}
} else if (reference instanceof parameterizedqualifiedtypereference) {
parameterizedqualifiedtypereference parameterizedreference = (parameterizedqualifiedtypereference) reference;
typereference[][] typearguments = parameterizedreference.typearguments;
if (typearguments != null) {
for (int i = 0; i < typearguments.length; i++) {
if (typearguments[i] != null) {
for (int j = 0; j < typearguments[i].length; j++) {
if (hasemptyname(typearguments[i][j], assistnode)) return true;
}
}
}
}
}
return false;
}
}
