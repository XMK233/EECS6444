/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.batch;

import java.io.file;
import java.util.arraylist;

public class filefinder {

public static string[] find(file f, string pattern) {
arraylist files = new arraylist();
find0(f, pattern, files);
string[] result = new string[files.size()];
files.toarray(result);
return result;
}
private static void find0(file f, string pattern, arraylist collector) {
if (f.isdirectory()) {
string[] files = f.list();
if (files == null) return;
for (int i = 0, max = files.length; i < max; i++) {
file current = new file(f, files[i]);
if (current.isdirectory()) {
find0(current, pattern, collector);
} else {
if (current.getname().touppercase().endswith(pattern)) {
collector.add(current.getabsolutepath());
}
}
}
}
}
}
