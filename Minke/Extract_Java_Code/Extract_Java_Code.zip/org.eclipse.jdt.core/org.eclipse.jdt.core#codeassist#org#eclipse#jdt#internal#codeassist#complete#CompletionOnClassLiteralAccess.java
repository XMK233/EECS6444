/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce an access to the literal 'class' containing the cursor.
* e.g.
*
*	class x {
*    void foo() {
*      string[].[cursor]
*    }
*  }
*
*	---> class x {
*         void foo() {
*           <completeonclassliteralaccess:string[].>
*         }
*       }
*
* the source range of the completion node denotes the source range
* which should be replaced by the completion.
*/

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class completiononclassliteralaccess extends classliteralaccess {

public char[] completionidentifier;
public int classstart;

public completiononclassliteralaccess(long pos, typereference t) {

super((int)pos, t);
this.classstart = (int) (pos >>> 32);
}

public stringbuffer printexpression(int indent, stringbuffer output) {

output.append("<completeonclassliteralaccess:"); //$non-nls-1$
return this.type.print(0, output).append('.').append(this.completionidentifier).append('>');
}

public typebinding resolvetype(blockscope scope) {

if (super.resolvetype(scope) == null)
throw new completionnodefound();
else
throw new completionnodefound(this, this.targettype, scope);
}
}
