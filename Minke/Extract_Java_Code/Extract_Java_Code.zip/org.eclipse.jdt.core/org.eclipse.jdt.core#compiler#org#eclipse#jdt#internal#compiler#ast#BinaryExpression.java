/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class binaryexpression extends operatorexpression {

/* tracking helpers
* the following are used to elaborate realistic statistics about binary
* expressions. this must be neutralized in the released code.
* search the keyword be_instrumentation to reenable.
* an external device must install a suitable probe so as to monitor the
* emission of events and publish the results.
public interface probe {
public void ping(int depth);
}
public int depthtracker;
public static probe probe;
*/

public expression left, right;
public constant optimizedbooleanconstant;

public binaryexpression(expression left, expression right, int operator) {
this.left = left;
this.right = right;
this.bits |= operator << astnode.operatorshift; // encode operator
this.sourcestart = left.sourcestart;
this.sourceend = right.sourceend;
// be_instrumentation: neutralized in the released code
//	if (left instanceof binaryexpression &&
//			((left.bits & operatormask) ^ (this.bits & operatormask)) == 0) {
//		this.depthtracker = ((binaryexpression)left).depthtracker + 1;
//	} else {
//		this.depthtracker = 1;
//	}
}
public binaryexpression(binaryexpression expression) {
this.left = expression.left;
this.right = expression.right;
this.bits = expression.bits;
this.sourcestart = expression.sourcestart;
this.sourceend = expression.sourceend;
}
public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
// keep implementation in sync with combinedbinaryexpression#analysecode
if (this.resolvedtype.id == typeids.t_javalangstring) {
return this.right.analysecode(
currentscope, flowcontext,
this.left.analysecode(currentscope, flowcontext, flowinfo).unconditionalinits())
.unconditionalinits();
} else {
this.left.checknpe(currentscope, flowcontext, flowinfo);
flowinfo = this.left.analysecode(currentscope, flowcontext, flowinfo).unconditionalinits();
this.right.checknpe(currentscope, flowcontext, flowinfo);
return this.right.analysecode(currentscope, flowcontext, flowinfo).unconditionalinits();
}
}

public void computeconstant(blockscope scope, int leftid, int rightid) {
//compute the constant when valid
if ((this.left.constant != constant.notaconstant)
&& (this.right.constant != constant.notaconstant)) {
try {
this.constant =
constant.computeconstantoperation(
this.left.constant,
leftid,
(this.bits & astnode.operatormask) >> astnode.operatorshift,
this.right.constant,
rightid);
} catch (arithmeticexception e) {
this.constant = constant.notaconstant;
// 1.2 no longer throws an exception at compile-time
//scope.problemreporter().compiletimeconstantthrowsarithmeticexception(this);
}
} else {
this.constant = constant.notaconstant;
//add some work for the boolean operators & |
this.optimizedbooleanconstant(
leftid,
(this.bits & astnode.operatormask) >> astnode.operatorshift,
rightid);
}
}

public constant optimizedbooleanconstant() {
return this.optimizedbooleanconstant == null ? this.constant : this.optimizedbooleanconstant;
}

/**
* code generation for a binary operation
*/
// given the current focus of combinedbinaryexpression on strings concatenation,
// we do not provide a general, non-recursive implementation of generatecode,
// but rely upon generateoptimizedstringconcatenationcreation instead
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
if (this.constant != constant.notaconstant) {
if (valuerequired)
codestream.generateconstant(this.constant, this.implicitconversion);
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
switch ((this.bits & astnode.operatormask) >> astnode.operatorshift) {
case plus :
switch (this.bits & astnode.returntypeidmask) {
case t_javalangstring :
// be_instrumentation: neutralized in the released code
//					if (probe != null) {
//						probe.ping(this.depthtracker);
//					}
codestream.generatestringconcatenationappend(currentscope, this.left, this.right);
if (!valuerequired)
codestream.pop();
break;
case t_int :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.iadd();
break;
case t_long :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.ladd();
break;
case t_double :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.dadd();
break;
case t_float :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.fadd();
break;
}
break;
case minus :
switch (this.bits & astnode.returntypeidmask) {
case t_int :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.isub();
break;
case t_long :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.lsub();
break;
case t_double :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.dsub();
break;
case t_float :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.fsub();
break;
}
break;
case multiply :
switch (this.bits & astnode.returntypeidmask) {
case t_int :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.imul();
break;
case t_long :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.lmul();
break;
case t_double :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.dmul();
break;
case t_float :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.fmul();
break;
}
break;
case divide :
switch (this.bits & astnode.returntypeidmask) {
case t_int :
this.left.generatecode(currentscope, codestream, true);
this.right.generatecode(currentscope, codestream, true);
codestream.idiv();
if (!valuerequired)
codestream.pop();
break;
case t_long :
this.left.generatecode(currentscope, codestream, true);
this.right.generatecode(currentscope, codestream, true);
codestream.ldiv();
if (!valuerequired)
codestream.pop2();
break;
case t_double :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.ddiv();
break;
case t_float :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.fdiv();
break;
}
break;
case remainder :
switch (this.bits & astnode.returntypeidmask) {
case t_int :
this.left.generatecode(currentscope, codestream, true);
this.right.generatecode(currentscope, codestream, true);
codestream.irem();
if (!valuerequired)
codestream.pop();
break;
case t_long :
this.left.generatecode(currentscope, codestream, true);
this.right.generatecode(currentscope, codestream, true);
codestream.lrem();
if (!valuerequired)
codestream.pop2();
break;
case t_double :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.drem();
break;
case t_float :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.frem();
break;
}
break;
case and :
switch (this.bits & astnode.returntypeidmask) {
case t_int :
// 0 & x
if ((this.left.constant != constant.notaconstant)
&& (this.left.constant.typeid() == typeids.t_int)
&& (this.left.constant.intvalue() == 0)) {
this.right.generatecode(currentscope, codestream, false);
if (valuerequired)
codestream.iconst_0();
} else {
// x & 0
if ((this.right.constant != constant.notaconstant)
&& (this.right.constant.typeid() == typeids.t_int)
&& (this.right.constant.intvalue() == 0)) {
this.left.generatecode(currentscope, codestream, false);
if (valuerequired)
codestream.iconst_0();
} else {
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.iand();
}
}
break;
case t_long :
// 0 & x
if ((this.left.constant != constant.notaconstant)
&& (this.left.constant.typeid() == typeids.t_long)
&& (this.left.constant.longvalue() == 0l)) {
this.right.generatecode(currentscope, codestream, false);
if (valuerequired)
codestream.lconst_0();
} else {
// x & 0
if ((this.right.constant != constant.notaconstant)
&& (this.right.constant.typeid() == typeids.t_long)
&& (this.right.constant.longvalue() == 0l)) {
this.left.generatecode(currentscope, codestream, false);
if (valuerequired)
codestream.lconst_0();
} else {
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.land();
}
}
break;
case t_boolean : // logical and
generatelogicaland(currentscope, codestream, valuerequired);
break;
}
break;
case or :
switch (this.bits & astnode.returntypeidmask) {
case t_int :
// 0 | x
if ((this.left.constant != constant.notaconstant)
&& (this.left.constant.typeid() == typeids.t_int)
&& (this.left.constant.intvalue() == 0)) {
this.right.generatecode(currentscope, codestream, valuerequired);
} else {
// x | 0
if ((this.right.constant != constant.notaconstant)
&& (this.right.constant.typeid() == typeids.t_int)
&& (this.right.constant.intvalue() == 0)) {
this.left.generatecode(currentscope, codestream, valuerequired);
} else {
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.ior();
}
}
break;
case t_long :
// 0 | x
if ((this.left.constant != constant.notaconstant)
&& (this.left.constant.typeid() == typeids.t_long)
&& (this.left.constant.longvalue() == 0l)) {
this.right.generatecode(currentscope, codestream, valuerequired);
} else {
// x | 0
if ((this.right.constant != constant.notaconstant)
&& (this.right.constant.typeid() == typeids.t_long)
&& (this.right.constant.longvalue() == 0l)) {
this.left.generatecode(currentscope, codestream, valuerequired);
} else {
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.lor();
}
}
break;
case t_boolean : // logical or
generatelogicalor(currentscope, codestream, valuerequired);
break;
}
break;
case xor :
switch (this.bits & astnode.returntypeidmask) {
case t_int :
// 0 ^ x
if ((this.left.constant != constant.notaconstant)
&& (this.left.constant.typeid() == typeids.t_int)
&& (this.left.constant.intvalue() == 0)) {
this.right.generatecode(currentscope, codestream, valuerequired);
} else {
// x ^ 0
if ((this.right.constant != constant.notaconstant)
&& (this.right.constant.typeid() == typeids.t_int)
&& (this.right.constant.intvalue() == 0)) {
this.left.generatecode(currentscope, codestream, valuerequired);
} else {
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.ixor();
}
}
break;
case t_long :
// 0 ^ x
if ((this.left.constant != constant.notaconstant)
&& (this.left.constant.typeid() == typeids.t_long)
&& (this.left.constant.longvalue() == 0l)) {
this.right.generatecode(currentscope, codestream, valuerequired);
} else {
// x ^ 0
if ((this.right.constant != constant.notaconstant)
&& (this.right.constant.typeid() == typeids.t_long)
&& (this.right.constant.longvalue() == 0l)) {
this.left.generatecode(currentscope, codestream, valuerequired);
} else {
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.lxor();
}
}
break;
case t_boolean :
generatelogicalxor(currentscope, 	codestream, valuerequired);
break;
}
break;
case left_shift :
switch (this.bits & astnode.returntypeidmask) {
case t_int :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.ishl();
break;
case t_long :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.lshl();
}
break;
case right_shift :
switch (this.bits & astnode.returntypeidmask) {
case t_int :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.ishr();
break;
case t_long :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.lshr();
}
break;
case unsigned_right_shift :
switch (this.bits & astnode.returntypeidmask) {
case t_int :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.iushr();
break;
case t_long :
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired)
codestream.lushr();
}
break;
case greater :
branchlabel falselabel, endlabel;
generateoptimizedgreaterthan(
currentscope,
codestream,
null,
(falselabel = new branchlabel(codestream)),
valuerequired);
if (valuerequired) {
codestream.iconst_1();
if ((this.bits & astnode.isreturnedvalue) != 0) {
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
falselabel.place();
codestream.iconst_0();
} else {
codestream.goto_(endlabel = new branchlabel(codestream));
codestream.decrstacksize(1);
falselabel.place();
codestream.iconst_0();
endlabel.place();
}
}
break;
case greater_equal :
generateoptimizedgreaterthanorequal(
currentscope,
codestream,
null,
(falselabel = new branchlabel(codestream)),
valuerequired);
if (valuerequired) {
codestream.iconst_1();
if ((this.bits & astnode.isreturnedvalue) != 0) {
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
falselabel.place();
codestream.iconst_0();
} else {
codestream.goto_(endlabel = new branchlabel(codestream));
codestream.decrstacksize(1);
falselabel.place();
codestream.iconst_0();
endlabel.place();
}
}
break;
case less :
generateoptimizedlessthan(
currentscope,
codestream,
null,
(falselabel = new branchlabel(codestream)),
valuerequired);
if (valuerequired) {
codestream.iconst_1();
if ((this.bits & astnode.isreturnedvalue) != 0) {
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
falselabel.place();
codestream.iconst_0();
} else {
codestream.goto_(endlabel = new branchlabel(codestream));
codestream.decrstacksize(1);
falselabel.place();
codestream.iconst_0();
endlabel.place();
}
}
break;
case less_equal :
generateoptimizedlessthanorequal(
currentscope,
codestream,
null,
(falselabel = new branchlabel(codestream)),
valuerequired);
if (valuerequired) {
codestream.iconst_1();
if ((this.bits & astnode.isreturnedvalue) != 0) {
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
falselabel.place();
codestream.iconst_0();
} else {
codestream.goto_(endlabel = new branchlabel(codestream));
codestream.decrstacksize(1);
falselabel.place();
codestream.iconst_0();
endlabel.place();
}
}
}
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* boolean operator code generation
*	optimized operations are: <, <=, >, >=, &, |, ^
*/
public void generateoptimizedboolean(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {
if ((this.constant != constant.notaconstant) && (this.constant.typeid() == typeids.t_boolean)) {
super.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
return;
}
switch ((this.bits & astnode.operatormask) >> astnode.operatorshift) {
case less :
generateoptimizedlessthan(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
return;
case less_equal :
generateoptimizedlessthanorequal(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
return;
case greater :
generateoptimizedgreaterthan(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
return;
case greater_equal :
generateoptimizedgreaterthanorequal(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
return;
case and :
generateoptimizedlogicaland(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
return;
case or :
generateoptimizedlogicalor(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
return;
case xor :
generateoptimizedlogicalxor(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
return;
}
super.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
}

/**
* boolean generation for >
*/
public void generateoptimizedgreaterthan(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {
int promotedtypeid = (this.left.implicitconversion & typeids.implicit_conversion_mask) >> 4;
// both sides got promoted in the same way
if (promotedtypeid == typeids.t_int) {
// 0 > x
if ((this.left.constant != constant.notaconstant) && (this.left.constant.intvalue() == 0)) {
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicitly falling through the false case
codestream.iflt(truelabel);
}
} else {
if (truelabel == null) {
// implicitly falling through the true case
codestream.ifge(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
// x > 0
if ((this.right.constant != constant.notaconstant) && (this.right.constant.intvalue() == 0)) {
this.left.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicitly falling through the false case
codestream.ifgt(truelabel);
}
} else {
if (truelabel == null) {
// implicitly falling through the true case
codestream.ifle(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
}
// default comparison
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
switch (promotedtypeid) {
case t_int :
codestream.if_icmpgt(truelabel);
break;
case t_float :
codestream.fcmpl();
codestream.ifgt(truelabel);
break;
case t_long :
codestream.lcmp();
codestream.ifgt(truelabel);
break;
case t_double :
codestream.dcmpl();
codestream.ifgt(truelabel);
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
} else {
if (truelabel == null) {
// implicit falling through the true case
switch (promotedtypeid) {
case t_int :
codestream.if_icmple(falselabel);
break;
case t_float :
codestream.fcmpl();
codestream.ifle(falselabel);
break;
case t_long :
codestream.lcmp();
codestream.ifle(falselabel);
break;
case t_double :
codestream.dcmpl();
codestream.ifle(falselabel);
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
} else {
// no implicit fall through true/false --> should never occur
}
}
}
}

/**
* boolean generation for >=
*/
public void generateoptimizedgreaterthanorequal(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {
int promotedtypeid = (this.left.implicitconversion & typeids.implicit_conversion_mask) >> 4;
// both sides got promoted in the same way
if (promotedtypeid == typeids.t_int) {
// 0 >= x
if ((this.left.constant != constant.notaconstant) && (this.left.constant.intvalue() == 0)) {
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicitly falling through the false case
codestream.ifle(truelabel);
}
} else {
if (truelabel == null) {
// implicitly falling through the true case
codestream.ifgt(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
// x >= 0
if ((this.right.constant != constant.notaconstant) && (this.right.constant.intvalue() == 0)) {
this.left.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicitly falling through the false case
codestream.ifge(truelabel);
}
} else {
if (truelabel == null) {
// implicitly falling through the true case
codestream.iflt(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
}
// default comparison
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
switch (promotedtypeid) {
case t_int :
codestream.if_icmpge(truelabel);
break;
case t_float :
codestream.fcmpl();
codestream.ifge(truelabel);
break;
case t_long :
codestream.lcmp();
codestream.ifge(truelabel);
break;
case t_double :
codestream.dcmpl();
codestream.ifge(truelabel);
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
} else {
if (truelabel == null) {
// implicit falling through the true case
switch (promotedtypeid) {
case t_int :
codestream.if_icmplt(falselabel);
break;
case t_float :
codestream.fcmpl();
codestream.iflt(falselabel);
break;
case t_long :
codestream.lcmp();
codestream.iflt(falselabel);
break;
case t_double :
codestream.dcmpl();
codestream.iflt(falselabel);
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
} else {
// no implicit fall through true/false --> should never occur
}
}
}
}

/**
* boolean generation for <
*/
public void generateoptimizedlessthan(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {
int promotedtypeid = (this.left.implicitconversion & typeids.implicit_conversion_mask) >> 4;
// both sides got promoted in the same way
if (promotedtypeid == typeids.t_int) {
// 0 < x
if ((this.left.constant != constant.notaconstant) && (this.left.constant.intvalue() == 0)) {
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicitly falling through the false case
codestream.ifgt(truelabel);
}
} else {
if (truelabel == null) {
// implicitly falling through the true case
codestream.ifle(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
// x < 0
if ((this.right.constant != constant.notaconstant) && (this.right.constant.intvalue() == 0)) {
this.left.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicitly falling through the false case
codestream.iflt(truelabel);
}
} else {
if (truelabel == null) {
// implicitly falling through the true case
codestream.ifge(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
}
// default comparison
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
switch (promotedtypeid) {
case t_int :
codestream.if_icmplt(truelabel);
break;
case t_float :
codestream.fcmpg();
codestream.iflt(truelabel);
break;
case t_long :
codestream.lcmp();
codestream.iflt(truelabel);
break;
case t_double :
codestream.dcmpg();
codestream.iflt(truelabel);
}
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
} else {
if (truelabel == null) {
// implicit falling through the true case
switch (promotedtypeid) {
case t_int :
codestream.if_icmpge(falselabel);
break;
case t_float :
codestream.fcmpg();
codestream.ifge(falselabel);
break;
case t_long :
codestream.lcmp();
codestream.ifge(falselabel);
break;
case t_double :
codestream.dcmpg();
codestream.ifge(falselabel);
}
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
} else {
// no implicit fall through true/false --> should never occur
}
}
}
}

/**
* boolean generation for <=
*/
public void generateoptimizedlessthanorequal(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {
int promotedtypeid = (this.left.implicitconversion & typeids.implicit_conversion_mask) >> 4;
// both sides got promoted in the same way
if (promotedtypeid == typeids.t_int) {
// 0 <= x
if ((this.left.constant != constant.notaconstant) && (this.left.constant.intvalue() == 0)) {
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicitly falling through the false case
codestream.ifge(truelabel);
}
} else {
if (truelabel == null) {
// implicitly falling through the true case
codestream.iflt(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
// x <= 0
if ((this.right.constant != constant.notaconstant) && (this.right.constant.intvalue() == 0)) {
this.left.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicitly falling through the false case
codestream.ifle(truelabel);
}
} else {
if (truelabel == null) {
// implicitly falling through the true case
codestream.ifgt(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
}
// default comparison
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
switch (promotedtypeid) {
case t_int :
codestream.if_icmple(truelabel);
break;
case t_float :
codestream.fcmpg();
codestream.ifle(truelabel);
break;
case t_long :
codestream.lcmp();
codestream.ifle(truelabel);
break;
case t_double :
codestream.dcmpg();
codestream.ifle(truelabel);
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
}
} else {
if (truelabel == null) {
// implicit falling through the true case
switch (promotedtypeid) {
case t_int :
codestream.if_icmpgt(falselabel);
break;
case t_float :
codestream.fcmpg();
codestream.ifgt(falselabel);
break;
case t_long :
codestream.lcmp();
codestream.ifgt(falselabel);
break;
case t_double :
codestream.dcmpg();
codestream.ifgt(falselabel);
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
return;
} else {
// no implicit fall through true/false --> should never occur
}
}
}
}

/**
* boolean generation for &
*/
public void generatelogicaland(blockscope currentscope, codestream codestream, boolean valuerequired) {
constant condconst;
if ((this.left.implicitconversion & typeids.compile_type_mask) == typeids.t_boolean) {
if ((condconst = this.left.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// <something equivalent to true> & x
this.left.generatecode(currentscope, codestream, false);
this.right.generatecode(currentscope, codestream, valuerequired);
} else {
// <something equivalent to false> & x
this.left.generatecode(currentscope, codestream, false);
this.right.generatecode(currentscope, codestream, false);
if (valuerequired) {
codestream.iconst_0();
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}
return;
}
if ((condconst = this.right.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// x & <something equivalent to true>
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, false);
} else {
// x & <something equivalent to false>
this.left.generatecode(currentscope, codestream, false);
this.right.generatecode(currentscope, codestream, false);
if (valuerequired) {
codestream.iconst_0();
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}
return;
}
}
// default case
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
codestream.iand();
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}

/**
* boolean generation for |
*/
public void generatelogicalor(blockscope currentscope, codestream codestream, boolean valuerequired) {
constant condconst;
if ((this.left.implicitconversion & typeids.compile_type_mask) == typeids.t_boolean) {
if ((condconst = this.left.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// <something equivalent to true> | x
this.left.generatecode(currentscope, codestream, false);
this.right.generatecode(currentscope, codestream, false);
if (valuerequired) {
codestream.iconst_1();
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
} else {
// <something equivalent to false> | x
this.left.generatecode(currentscope, codestream, false);
this.right.generatecode(currentscope, codestream, valuerequired);
}
return;
}
if ((condconst = this.right.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// x | <something equivalent to true>
this.left.generatecode(currentscope, codestream, false);
this.right.generatecode(currentscope, codestream, false);
if (valuerequired) {
codestream.iconst_1();
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
} else {
// x | <something equivalent to false>
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, false);
}
return;
}
}
// default case
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
codestream.ior();
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}

/**
* boolean generation for ^
*/
public void generatelogicalxor(blockscope currentscope,	codestream codestream, boolean valuerequired) {
constant condconst;
if ((this.left.implicitconversion & typeids.compile_type_mask) == typeids.t_boolean) {
if ((condconst = this.left.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// <something equivalent to true> ^ x
this.left.generatecode(currentscope, codestream, false);
if (valuerequired) {
codestream.iconst_1();
}
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
codestream.ixor(); // negate
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}
} else {
// <something equivalent to false> ^ x
this.left.generatecode(currentscope, codestream, false);
this.right.generatecode(currentscope, codestream, valuerequired);
}
return;
}
if ((condconst = this.right.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// x ^ <something equivalent to true>
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, false);
if (valuerequired) {
codestream.iconst_1();
codestream.ixor(); // negate
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}
} else {
// x ^ <something equivalent to false>
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, false);
}
return;
}
}
// default case
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
codestream.ixor();
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}

/**
* boolean generation for &
*/
public void generateoptimizedlogicaland(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {
constant condconst;
if ((this.left.implicitconversion & typeids.compile_type_mask) == typeids.t_boolean) {
if ((condconst = this.left.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// <something equivalent to true> & x
this.left.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
this.right.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
} else {
// <something equivalent to false> & x
this.left.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
this.right.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
if (valuerequired) {
if (falselabel != null) {
// implicit falling through the true case
codestream.goto_(falselabel);
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}
return;
}
if ((condconst = this.right.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// x & <something equivalent to true>
this.left.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
this.right.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
} else {
// x & <something equivalent to false>
branchlabel internaltruelabel = new branchlabel(codestream);
this.left.generateoptimizedboolean(
currentscope,
codestream,
internaltruelabel,
falselabel,
false);
internaltruelabel.place();
this.right.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
if (valuerequired) {
if (falselabel != null) {
// implicit falling through the true case
codestream.goto_(falselabel);
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}
return;
}
}
// default case
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
codestream.iand();
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
codestream.ifne(truelabel);
}
} else {
// implicit falling through the true case
if (truelabel == null) {
codestream.ifeq(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}

/**
* boolean generation for |
*/
public void generateoptimizedlogicalor(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {
constant condconst;
if ((this.left.implicitconversion & typeids.compile_type_mask) == typeids.t_boolean) {
if ((condconst = this.left.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// <something equivalent to true> | x
this.left.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
branchlabel internalfalselabel = new branchlabel(codestream);
this.right.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
internalfalselabel,
false);
internalfalselabel.place();
if (valuerequired) {
if (truelabel != null) {
codestream.goto_(truelabel);
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
} else {
// <something equivalent to false> | x
this.left.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
this.right.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
}
return;
}
if ((condconst = this.right.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// x | <something equivalent to true>
branchlabel internalfalselabel = new branchlabel(codestream);
this.left.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
internalfalselabel,
false);
internalfalselabel.place();
this.right.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
if (valuerequired) {
if (truelabel != null) {
codestream.goto_(truelabel);
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
} else {
// x | <something equivalent to false>
this.left.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
this.right.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
}
return;
}
}
// default case
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
codestream.ior();
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
codestream.ifne(truelabel);
}
} else {
// implicit falling through the true case
if (truelabel == null) {
codestream.ifeq(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}

/**
* boolean generation for ^
*/
public void generateoptimizedlogicalxor(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {
constant condconst;
if ((this.left.implicitconversion & typeids.compile_type_mask) == typeids.t_boolean) {
if ((condconst = this.left.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// <something equivalent to true> ^ x
this.left.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
this.right.generateoptimizedboolean(
currentscope,
codestream,
falselabel, // negating
truelabel,
valuerequired);
} else {
// <something equivalent to false> ^ x
this.left.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
this.right.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
}
return;
}
if ((condconst = this.right.optimizedbooleanconstant()) != constant.notaconstant) {
if (condconst.booleanvalue() == true) {
// x ^ <something equivalent to true>
this.left.generateoptimizedboolean(
currentscope,
codestream,
falselabel, // negating
truelabel,
valuerequired);
this.right.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
} else {
// x ^ <something equivalent to false>
this.left.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
this.right.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
false);
}
return;
}
}
// default case
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
codestream.ixor();
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
codestream.ifne(truelabel);
}
} else {
// implicit falling through the true case
if (truelabel == null) {
codestream.ifeq(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}

public void generateoptimizedstringconcatenation(blockscope blockscope, codestream codestream, int typeid) {
// keep implementation in sync with combinedbinaryexpression
// #generateoptimizedstringconcatenation
/* in the case trying to make a string concatenation, there is no need to create a new
* string buffer, thus use a lower-level api for code generation involving only the
* appending of arguments to the existing stringbuffer
*/

if ((((this.bits & astnode.operatormask) >> astnode.operatorshift) == operatorids.plus)
&& ((this.bits & astnode.returntypeidmask) == typeids.t_javalangstring)) {
if (this.constant != constant.notaconstant) {
codestream.generateconstant(this.constant, this.implicitconversion);
codestream.invokestringconcatenationappendfortype(this.implicitconversion & typeids.compile_type_mask);
} else {
int pc = codestream.position;
this.left.generateoptimizedstringconcatenation(
blockscope,
codestream,
this.left.implicitconversion & typeids.compile_type_mask);
codestream.recordpositionsfrom(pc, this.left.sourcestart);
pc = codestream.position;
this.right.generateoptimizedstringconcatenation(
blockscope,
codestream,
this.right.implicitconversion & typeids.compile_type_mask);
codestream.recordpositionsfrom(pc, this.right.sourcestart);
}
} else {
super.generateoptimizedstringconcatenation(blockscope, codestream, typeid);
}
}

public void generateoptimizedstringconcatenationcreation(blockscope blockscope, codestream codestream, int typeid) {
// keep implementation in sync with combinedbinaryexpression
// #generateoptimizedstringconcatenationcreation
/* in the case trying to make a string concatenation, there is no need to create a new
* string buffer, thus use a lower-level api for code generation involving only the
* appending of arguments to the existing stringbuffer
*/
if ((((this.bits & astnode.operatormask) >> astnode.operatorshift) == operatorids.plus)
&& ((this.bits & astnode.returntypeidmask) == typeids.t_javalangstring)) {
if (this.constant != constant.notaconstant) {
codestream.newstringcontatenation(); // new: java.lang.stringbuffer
codestream.dup();
codestream.ldc(this.constant.stringvalue());
codestream.invokestringconcatenationstringconstructor();
// invokespecial: java.lang.stringbuffer.<init>(ljava.lang.string;)v
} else {
int pc = codestream.position;
this.left.generateoptimizedstringconcatenationcreation(
blockscope,
codestream,
this.left.implicitconversion & typeids.compile_type_mask);
codestream.recordpositionsfrom(pc, this.left.sourcestart);
pc = codestream.position;
this.right.generateoptimizedstringconcatenation(
blockscope,
codestream,
this.right.implicitconversion & typeids.compile_type_mask);
codestream.recordpositionsfrom(pc, this.right.sourcestart);
}
} else {
super.generateoptimizedstringconcatenationcreation(blockscope, codestream, typeid);
}
}

public boolean iscompactableoperation() {
return true;
}

/**
* separates into a reusable method the subpart of {@@link
* #resolvetype(blockscope)} that needs to be executed while climbing up the
* chain of expressions of this' leftmost branch. for use by {@@link
* combinedbinaryexpression#resolvetype(blockscope)}.
* @@param scope the scope within which the resolution occurs
*/
void nonrecursiveresolvetypeupwards(blockscope scope) {
// keep implementation in sync with binaryexpression#resolvetype
boolean leftiscast, rightiscast;
typebinding lefttype = this.left.resolvedtype;

if ((rightiscast = this.right instanceof castexpression) == true) {
this.right.bits |= astnode.disableunnecessarycastcheck; // will check later on
}
typebinding righttype = this.right.resolvetype(scope);

// use the id of the type to navigate into the table
if (lefttype == null || righttype == null) {
this.constant = constant.notaconstant;
return;
}

int lefttypeid = lefttype.id;
int righttypeid = righttype.id;

// autoboxing support
boolean use15specifics = scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
if (use15specifics) {
if (!lefttype.isbasetype() && righttypeid != typeids.t_javalangstring && righttypeid != typeids.t_null) {
lefttypeid = scope.environment().computeboxingtype(lefttype).id;
}
if (!righttype.isbasetype() && lefttypeid != typeids.t_javalangstring && lefttypeid != typeids.t_null) {
righttypeid = scope.environment().computeboxingtype(righttype).id;
}
}
if (lefttypeid > 15
|| righttypeid > 15) { // must convert string + object || object + string
if (lefttypeid == typeids.t_javalangstring) {
righttypeid = typeids.t_javalangobject;
} else if (righttypeid == typeids.t_javalangstring) {
lefttypeid = typeids.t_javalangobject;
} else {
this.constant = constant.notaconstant;
scope.problemreporter().invalidoperator(this, lefttype, righttype);
return;
}
}
if (((this.bits & astnode.operatormask) >> astnode.operatorshift) == operatorids.plus) {
if (lefttypeid == typeids.t_javalangstring) {
this.left.computeconversion(scope, lefttype, lefttype);
if (righttype.isarraytype() && ((arraybinding) righttype).elementstype() == typebinding.char) {
scope.problemreporter().signalnoimplicitstringconversionforchararrayexpression(this.right);
}
}
if (righttypeid == typeids.t_javalangstring) {
this.right.computeconversion(scope, righttype, righttype);
if (lefttype.isarraytype() && ((arraybinding) lefttype).elementstype() == typebinding.char) {
scope.problemreporter().signalnoimplicitstringconversionforchararrayexpression(this.left);
}
}
}

// the code is an int
// (cast)  left   op (cast)  right --> result
//  0000   0000       0000   0000      0000
//  <<16   <<12       <<8    <<4       <<0

// don't test for result = 0. if it is zero, some more work is done.
// on the one hand when it is not zero (correct code) we avoid doing the test
int operator = (this.bits & astnode.operatormask) >> astnode.operatorshift;
int operatorsignature = operatorexpression.operatorsignatures[operator][(lefttypeid << 4) + righttypeid];

this.left.computeconversion(scope, 	typebinding.wellknowntype(scope, (operatorsignature >>> 16) & 0x0000f), lefttype);
this.right.computeconversion(scope, typebinding.wellknowntype(scope, (operatorsignature >>> 8) & 0x0000f), righttype);
this.bits |= operatorsignature & 0xf;
switch (operatorsignature & 0xf) { // record the current returntypeid
// only switch on possible result type.....
case t_boolean :
this.resolvedtype = typebinding.boolean;
break;
case t_byte :
this.resolvedtype = typebinding.byte;
break;
case t_char :
this.resolvedtype = typebinding.char;
break;
case t_double :
this.resolvedtype = typebinding.double;
break;
case t_float :
this.resolvedtype = typebinding.float;
break;
case t_int :
this.resolvedtype = typebinding.int;
break;
case t_long :
this.resolvedtype = typebinding.long;
break;
case t_javalangstring :
this.resolvedtype = scope.getjavalangstring();
break;
default : //error........
this.constant = constant.notaconstant;
scope.problemreporter().invalidoperator(this, lefttype, righttype);
return;
}

// check need for operand cast
if ((leftiscast = (this.left instanceof castexpression)) == true ||
rightiscast) {
castexpression.checkneedforargumentcasts(scope, operator, operatorsignature, this.left, lefttypeid, leftiscast, this.right, righttypeid, rightiscast);
}
// compute the constant when valid
computeconstant(scope, lefttypeid, righttypeid);
}

public void optimizedbooleanconstant(int leftid, int operator, int rightid) {
switch (operator) {
case and :
if ((leftid != typeids.t_boolean) || (rightid != typeids.t_boolean))
return;
//$fall-through$
case and_and :
constant cst;
if ((cst = this.left.optimizedbooleanconstant()) != constant.notaconstant) {
if (cst.booleanvalue() == false) { // left is equivalent to false
this.optimizedbooleanconstant = cst; // constant(false)
return;
} else { //left is equivalent to true
if ((cst = this.right.optimizedbooleanconstant()) != constant.notaconstant) {
this.optimizedbooleanconstant = cst;
// the conditional result is equivalent to the right conditional value
}
return;
}
}
if ((cst = this.right.optimizedbooleanconstant()) != constant.notaconstant) {
if (cst.booleanvalue() == false) { // right is equivalent to false
this.optimizedbooleanconstant = cst; // constant(false)
}
}
return;
case or :
if ((leftid != typeids.t_boolean) || (rightid != typeids.t_boolean))
return;
//$fall-through$
case or_or :
if ((cst = this.left.optimizedbooleanconstant()) != constant.notaconstant) {
if (cst.booleanvalue() == true) { // left is equivalent to true
this.optimizedbooleanconstant = cst; // constant(true)
return;
} else { //left is equivalent to false
if ((cst = this.right.optimizedbooleanconstant()) != constant.notaconstant) {
this.optimizedbooleanconstant = cst;
}
return;
}
}
if ((cst = this.right.optimizedbooleanconstant()) != constant.notaconstant) {
if (cst.booleanvalue() == true) { // right is equivalent to true
this.optimizedbooleanconstant = cst; // constant(true)
}
}
}
}

public stringbuffer printexpressionnoparenthesis(int indent, stringbuffer output) {
// keep implementation in sync with
// combinedbinaryexpression#printexpressionnoparenthesis
this.left.printexpression(indent, output).append(' ').append(operatortostring()).append(' ');
return this.right.printexpression(0, output);
}

public typebinding resolvetype(blockscope scope) {
// keep implementation in sync with combinedbinaryexpression#resolvetype
// and nonrecursiveresolvetypeupwards
boolean leftiscast, rightiscast;
if ((leftiscast = this.left instanceof castexpression) == true) this.left.bits |= astnode.disableunnecessarycastcheck; // will check later on
typebinding lefttype = this.left.resolvetype(scope);

if ((rightiscast = this.right instanceof castexpression) == true) this.right.bits |= astnode.disableunnecessarycastcheck; // will check later on
typebinding righttype = this.right.resolvetype(scope);

// use the id of the type to navigate into the table
if (lefttype == null || righttype == null) {
this.constant = constant.notaconstant;
return null;
}

int lefttypeid = lefttype.id;
int righttypeid = righttype.id;

// autoboxing support
boolean use15specifics = scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
if (use15specifics) {
if (!lefttype.isbasetype() && righttypeid != typeids.t_javalangstring && righttypeid != typeids.t_null) {
lefttypeid = scope.environment().computeboxingtype(lefttype).id;
}
if (!righttype.isbasetype() && lefttypeid != typeids.t_javalangstring && lefttypeid != typeids.t_null) {
righttypeid = scope.environment().computeboxingtype(righttype).id;
}
}
if (lefttypeid > 15
|| righttypeid > 15) { // must convert string + object || object + string
if (lefttypeid == typeids.t_javalangstring) {
righttypeid = typeids.t_javalangobject;
} else if (righttypeid == typeids.t_javalangstring) {
lefttypeid = typeids.t_javalangobject;
} else {
this.constant = constant.notaconstant;
scope.problemreporter().invalidoperator(this, lefttype, righttype);
return null;
}
}
if (((this.bits & astnode.operatormask) >> astnode.operatorshift) == operatorids.plus) {
if (lefttypeid == typeids.t_javalangstring) {
this.left.computeconversion(scope, lefttype, lefttype);
if (righttype.isarraytype() && ((arraybinding) righttype).elementstype() == typebinding.char) {
scope.problemreporter().signalnoimplicitstringconversionforchararrayexpression(this.right);
}
}
if (righttypeid == typeids.t_javalangstring) {
this.right.computeconversion(scope, righttype, righttype);
if (lefttype.isarraytype() && ((arraybinding) lefttype).elementstype() == typebinding.char) {
scope.problemreporter().signalnoimplicitstringconversionforchararrayexpression(this.left);
}
}
}

// the code is an int
// (cast)  left   op (cast)  right --> result
//  0000   0000       0000   0000      0000
//  <<16   <<12       <<8    <<4       <<0

// don't test for result = 0. if it is zero, some more work is done.
// on the one hand when it is not zero (correct code) we avoid doing the test
int operator = (this.bits & astnode.operatormask) >> astnode.operatorshift;
int operatorsignature = operatorexpression.operatorsignatures[operator][(lefttypeid << 4) + righttypeid];

this.left.computeconversion(scope, typebinding.wellknowntype(scope, (operatorsignature >>> 16) & 0x0000f), lefttype);
this.right.computeconversion(scope, typebinding.wellknowntype(scope, (operatorsignature >>> 8) & 0x0000f), righttype);
this.bits |= operatorsignature & 0xf;
switch (operatorsignature & 0xf) { // record the current returntypeid
// only switch on possible result type.....
case t_boolean :
this.resolvedtype = typebinding.boolean;
break;
case t_byte :
this.resolvedtype = typebinding.byte;
break;
case t_char :
this.resolvedtype = typebinding.char;
break;
case t_double :
this.resolvedtype = typebinding.double;
break;
case t_float :
this.resolvedtype = typebinding.float;
break;
case t_int :
this.resolvedtype = typebinding.int;
break;
case t_long :
this.resolvedtype = typebinding.long;
break;
case t_javalangstring :
this.resolvedtype = scope.getjavalangstring();
break;
default : //error........
this.constant = constant.notaconstant;
scope.problemreporter().invalidoperator(this, lefttype, righttype);
return null;
}

// check need for operand cast
if (leftiscast || rightiscast) {
castexpression.checkneedforargumentcasts(scope, operator, operatorsignature, this.left, lefttypeid, leftiscast, this.right, righttypeid, rightiscast);
}
// compute the constant when valid
computeconstant(scope, lefttypeid, righttypeid);
return this.resolvedtype;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
this.left.traverse(visitor, scope);
this.right.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
