/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.typeparameter;
import org.eclipse.jdt.internal.compiler.util.hashtableofobject;
import org.eclipse.jdt.internal.compiler.util.simpleset;

class methodverifier15 extends methodverifier {

methodverifier15(lookupenvironment environment) {
super(environment);
}
boolean aremethodscompatible(methodbinding one, methodbinding two) {
// use the original methods to test compatibility, but do not check visibility, etc
one = one.original();
two = one.findoriginalinheritedmethod(two);

if (two == null)
return false; // method's declaringclass does not inherit from inheritedmethod's

return isparametersubsignature(one, two);
}
boolean areparametersequal(methodbinding one, methodbinding two) {
typebinding[] oneargs = one.parameters;
typebinding[] twoargs = two.parameters;
if (oneargs == twoargs) return true;

int length = oneargs.length;
if (length != twoargs.length) return false;

if (one.declaringclass.isinterface()) {
for (int i = 0; i < length; i++)
if (!aretypesequal(oneargs[i], twoargs[i]))
return false;
} else {
// methods with raw parameters are considered equal to inherited methods
// with parameterized parameters for backwards compatibility, need a more complex check
int i;
foundraw: for (i = 0; i < length; i++) {
if (!aretypesequal(oneargs[i], twoargs[i])) {
if (oneargs[i].leafcomponenttype().israwtype()) {
if (oneargs[i].dimensions() == twoargs[i].dimensions() && oneargs[i].leafcomponenttype().isequivalentto(twoargs[i].leafcomponenttype())) {
// raw mode does not apply if the method defines its own type variables
if (one.typevariables != binding.no_type_variables)
return false;
// one parameter type is raw, hence all parameters types must be raw or non generic
// otherwise we have a mismatch check backwards
for (int j = 0; j < i; j++)
if (oneargs[j].leafcomponenttype().isparameterizedtypewithactualarguments())
return false;
// switch to all raw mode
break foundraw;
}
}
return false;
}
}
// all raw mode for remaining parameters (if any)
for (i++; i < length; i++) {
if (!aretypesequal(oneargs[i], twoargs[i])) {
if (oneargs[i].leafcomponenttype().israwtype())
if (oneargs[i].dimensions() == twoargs[i].dimensions() && oneargs[i].leafcomponenttype().isequivalentto(twoargs[i].leafcomponenttype()))
continue;
return false;
} else if (oneargs[i].leafcomponenttype().isparameterizedtypewithactualarguments()) {
return false; // no remaining parameter can be a parameterized type (if one has been converted then all raw types must be converted)
}
}
}
return true;
}
boolean arereturntypescompatible(methodbinding one, methodbinding two) {
if (one.returntype == two.returntype) return true;
return arereturntypescompatible0(one, two);
}
boolean aretypesequal(typebinding one, typebinding two) {
if (one == two) return true;

// need to consider x<?> and x<? extends object> as the same 'type'
if (one.isparameterizedtype() && two.isparameterizedtype())
return one.isequivalentto(two) && two.isequivalentto(one);

// can skip this since we resolved each method before comparing it, see computesubstitutemethod()
//	if (one instanceof unresolvedreferencebinding)
//		return ((unresolvedreferencebinding) one).resolvedtype == two;
//	if (two instanceof unresolvedreferencebinding)
//		return ((unresolvedreferencebinding) two).resolvedtype == one;
return false; // all other type bindings are identical
}
// given `overridingmethod' which overrides `inheritedmethod' answer whether some subclass method that
// differs in erasure from overridingmethod could override `inheritedmethod'
protected boolean canoverridingmethoddifferinerasure(methodbinding overridingmethod, methodbinding inheritedmethod) {
if (overridingmethod.areparametererasuresequal(inheritedmethod))
return false;  // no further change in signature is possible due to parameterization.
if (overridingmethod.declaringclass.israwtype())
return false;  // no parameterization is happening anyways.
return true;
}
boolean canskipinheritedmethods() {
if (this.type.superclass() != null)
if (this.type.superclass().isabstract() || this.type.superclass().isparameterizedtype())
return false;
return this.type.superinterfaces() == binding.no_superinterfaces;
}
boolean canskipinheritedmethods(methodbinding one, methodbinding two) {
return two == null // already know one is not null
|| (one.declaringclass == two.declaringclass && !one.declaringclass.isparameterizedtype());
}
void checkconcreteinheritedmethod(methodbinding concretemethod, methodbinding[] abstractmethods) {
super.checkconcreteinheritedmethod(concretemethod, abstractmethods);

for (int i = 0, l = abstractmethods.length; i < l; i++) {
methodbinding abstractmethod = abstractmethods[i];
if (concretemethod.isvarargs() != abstractmethod.isvarargs())
problemreporter().varargsconflict(concretemethod, abstractmethod, this.type);

// so the parameters are equal and the return type is compatible b/w the currentmethod & the substituted inheritedmethod
methodbinding originalinherited = abstractmethod.original();
if (originalinherited.returntype != concretemethod.returntype)
if (!isacceptablereturntypeoverride(concretemethod, abstractmethod))
problemreporter().unsafereturntypeoverride(concretemethod, originalinherited, this.type);

// check whether bridge method is already defined above for interface methods
// skip generation of bridge method for current class & method if an equivalent
// bridge will be/would have been generated in the context of the super class since
// the bridge itself will be inherited. see https://bugs.eclipse.org/bugs/show_bug.cgi?id=298362
if (originalinherited.declaringclass.isinterface()) {
if ((concretemethod.declaringclass == this.type.superclass && this.type.superclass.isparameterizedtype() && !aremethodscompatible(concretemethod, originalinherited))
|| this.type.superclass.erasure().findsupertypeoriginatingfrom(originalinherited.declaringclass) == null)
this.type.addsyntheticbridgemethod(originalinherited, concretemethod.original());
}
}
}
void checkforbridgemethod(methodbinding currentmethod, methodbinding inheritedmethod, methodbinding[] allinheritedmethods) {
if (currentmethod.isvarargs() != inheritedmethod.isvarargs())
problemreporter(currentmethod).varargsconflict(currentmethod, inheritedmethod, this.type);

// so the parameters are equal and the return type is compatible b/w the currentmethod & the substituted inheritedmethod
methodbinding originalinherited = inheritedmethod.original();
if (originalinherited.returntype != currentmethod.returntype)
if (!isacceptablereturntypeoverride(currentmethod, inheritedmethod))
problemreporter(currentmethod).unsafereturntypeoverride(currentmethod, originalinherited, this.type);

methodbinding bridge = this.type.addsyntheticbridgemethod(originalinherited, currentmethod.original());
if (bridge != null) {
for (int i = 0, l = allinheritedmethods == null ? 0 : allinheritedmethods.length; i < l; i++) {
if (allinheritedmethods[i] != null && detectinheritednameclash(originalinherited, allinheritedmethods[i].original()))
return;
}
// see if the new bridge clashes with any of the user methods of the class. for this check
// we should check for "method descriptor clash" and not just "method signature clash". really
// what we are checking is whether there is a contention for the method dispatch table slot.
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=293615.
methodbinding[] current = (methodbinding[]) this.currentmethods.get(bridge.selector);
for (int i = current.length - 1; i >= 0; --i) {
final methodbinding thismethod = current[i];
if (thismethod.areparametererasuresequal(bridge) && thismethod.returntype.erasure() == bridge.returntype.erasure()) {
// use inherited method for problem reporting.
problemreporter(thismethod).methodnameclash(thismethod, inheritedmethod.declaringclass.israwtype() ? inheritedmethod : inheritedmethod.original());
return;
}
}
}
}
void checkfornameclash(methodbinding currentmethod, methodbinding inheritedmethod) {
// sent from checkmethods() to compare a current method and an inherited method that are not 'equal'

// error cases:
//		abstract class aa<e extends comparable> { abstract void test(e element); }
//		class a extends aa<integer> { public void test(integer i) {} }
//		public class b extends a { public void test(comparable i) {} }
//		interface i<e extends comparable> { void test(e element); }
//		class a implements i<integer> { public void test(integer i) {} }
//		public class b extends a { public void test(comparable i) {} }

//		abstract class y implements equalitycomparable<integer>, equivalent<string> {
//			public boolean equalto(integer other) { return true; }
//		}
//		interface equivalent<t> { boolean equalto(t other); }
//		interface equalitycomparable<t> { boolean equalto(t other); }

//		class y implements equalitycomparable, equivalent<string>{
//			public boolean equalto(string other) { return true; }
//			public boolean equalto(object other) { return true; }
//		}
//		interface equivalent<t> { boolean equalto(t other); }
//		interface equalitycomparable { boolean equalto(object other); }

//		class a<t extends number> { void m(t t) {} }
//		class b<s extends integer> extends a<s> { void m(s t) {}}
//		class d extends b<integer> { void m(number t) {}    void m(integer t) {} }

//		inheritedmethods does not include i.test since a has a valid implementation
//		interface i<e extends comparable<e>> { void test(e element); }
//		class a implements i<integer> { public void test(integer i) {} }
//		class b extends a { public void test(comparable i) {} }

if (currentmethod.declaringclass.isinterface() || inheritedmethod.isstatic()) return;

if (!detectnameclash(currentmethod, inheritedmethod, false)) { // check up the hierarchy for skipped inherited methods
typebinding[] currentparams = currentmethod.parameters;
typebinding[] inheritedparams = inheritedmethod.parameters;
int length = currentparams.length;
if (length != inheritedparams.length) return; // no match

for (int i = 0; i < length; i++)
if (currentparams[i] != inheritedparams[i])
if (currentparams[i].isbasetype() != inheritedparams[i].isbasetype() || !inheritedparams[i].iscompatiblewith(currentparams[i]))
return; // no chance that another inherited method's bridge method can collide

referencebinding[] interfacestovisit = null;
int nextposition = 0;
referencebinding supertype = inheritedmethod.declaringclass;
referencebinding[] itsinterfaces = supertype.superinterfaces();
if (itsinterfaces != binding.no_superinterfaces) {
nextposition = itsinterfaces.length;
interfacestovisit = itsinterfaces;
}
supertype = supertype.superclass(); // now start with its superclass
while (supertype != null && supertype.isvalidbinding()) {
methodbinding[] methods = supertype.getmethods(currentmethod.selector);
for (int m = 0, n = methods.length; m < n; m++) {
methodbinding substitute = computesubstitutemethod(methods[m], currentmethod);
if (substitute != null && !issubstituteparametersubsignature(currentmethod, substitute) && detectnameclash(currentmethod, substitute, true))
return;
}
if ((itsinterfaces = supertype.superinterfaces()) != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
supertype = supertype.superclass();
}

for (int i = 0; i < nextposition; i++) {
supertype = interfacestovisit[i];
if (supertype.isvalidbinding()) {
methodbinding[] methods = supertype.getmethods(currentmethod.selector);
for (int m = 0, n = methods.length; m < n; m++){
methodbinding substitute = computesubstitutemethod(methods[m], currentmethod);
if (substitute != null && !issubstituteparametersubsignature(currentmethod, substitute) && detectnameclash(currentmethod, substitute, true))
return;
}
if ((itsinterfaces = supertype.superinterfaces()) != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
}
}
void checkinheritedmethods(methodbinding inheritedmethod, methodbinding otherinheritedmethod) {
// sent from checkmethods() to compare 2 inherited methods that are not 'equal'
if (inheritedmethod.declaringclass.erasure() == otherinheritedmethod.declaringclass.erasure()) {
boolean areduplicates = inheritedmethod.hassubstitutedparameters() && otherinheritedmethod.hassubstitutedparameters()
? inheritedmethod.areparametersequal(otherinheritedmethod)
: inheritedmethod.areparametererasuresequal(otherinheritedmethod);
if (areduplicates) {
problemreporter().duplicateinheritedmethods(this.type, inheritedmethod, otherinheritedmethod);
return;
}
}

// the 2 inherited methods clash because of a parameterized type overrides a raw type
//		interface i { void foo(a a); }
//		class y { void foo(a<string> a) {} }
//		abstract class x extends y implements i { }
//		class a<t> {}
// in this case the 2 inherited methods clash because of type variables
//		interface i { <t, s> void foo(t t); }
//		class y { <t> void foo(t t) {} }
//		abstract class x extends y implements i {}

if (inheritedmethod.declaringclass.isinterface() || inheritedmethod.isstatic()) return;

detectinheritednameclash(inheritedmethod.original(), otherinheritedmethod.original());
}
void checkinheritedmethods(methodbinding[] methods, int length) {
int count = length;
int[] skip = new int[count];
nextmethod : for (int i = 0, l = length - 1; i < l; i++) {
if (skip[i] == -1) continue nextmethod;
methodbinding method = methods[i];
methodbinding[] duplicates = null;
for (int j = i + 1; j <= l; j++) {
methodbinding method2 = methods[j];
if (method.declaringclass == method2.declaringclass && aremethodscompatible(method, method2)) {
skip[j] = -1;
if (duplicates == null)
duplicates = new methodbinding[length];
duplicates[j] = method2;
}
}
if (duplicates != null) {
// found an inherited parameterizedtype that defines duplicate methods
// if all methods are abstract or more than 1 concrete method exists, then consider them to be duplicates
// if a single concrete method 'implements' the abstract methods, then do not report a duplicate error
int concretecount = method.isabstract() ? 0 : 1;
methodbinding methodtokeep = method; // if a concrete method exists, keep it, otherwise keep the first method
for (int m = 0, s = duplicates.length; m < s; m++) {
if (duplicates[m] != null) {
if (!duplicates[m].isabstract()) {
methodtokeep = duplicates[m];
concretecount++;
}
}
}
if (concretecount != 1) {
for (int m = 0, s = duplicates.length; m < s; m++) {
if (duplicates[m] != null) {
problemreporter().duplicateinheritedmethods(this.type, method, duplicates[m]);
count--;
if (methodtokeep == duplicates[m])
methods[i] = null;
else
methods[m] = null;
}
}
}
}
}
if (count < length) {
if (count == 1) return; // no need to continue since only 1 inherited method is left
methodbinding[] newmethods = new methodbinding[count];
for (int i = length; --i >= 0;)
if (methods[i] != null)
newmethods[--count] = methods[i];
methods = newmethods;
length = newmethods.length;
}

super.checkinheritedmethods(methods, length);
}
boolean checkinheritedreturntypes(methodbinding method, methodbinding othermethod) {
if (arereturntypescompatible(method, othermethod)) return true;

if (!this.type.isinterface())
if (method.declaringclass.isclass() || !this.type.implementsinterface(method.declaringclass, false))
if (othermethod.declaringclass.isclass() || !this.type.implementsinterface(othermethod.declaringclass, false))
return true; // do not complain since the superclass already got blamed

// check to see if this is just a warning, if so report it & skip to next method
if (isunsafereturntypeoverride(method, othermethod)) {
if (!method.declaringclass.implementsinterface(othermethod.declaringclass, false))
problemreporter(method).unsafereturntypeoverride(method, othermethod, this.type);
return true;
}

return false;
}
void checkmethods() {
boolean mustimplementabstractmethods = mustimplementabstractmethods();
boolean skipinheritedmethods = mustimplementabstractmethods && canskipinheritedmethods(); // have a single concrete superclass so only check overridden methods
boolean isorenclosedbyprivatetype = this.type.isorenclosedbyprivatetype();
char[][] methodselectors = this.inheritedmethods.keytable;
nextselector : for (int s = methodselectors.length; --s >= 0;) {
if (methodselectors[s] == null) continue nextselector;

methodbinding[] current = (methodbinding[]) this.currentmethods.get(methodselectors[s]);
methodbinding[] inherited = (methodbinding[]) this.inheritedmethods.valuetable[s];

// https://bugs.eclipse.org/bugs/show_bug.cgi?id=296660, if current type is exposed,
// inherited methods of super classes are too. current != null case handled below.
if (current == null && !isorenclosedbyprivatetype) {
int length = inherited.length;
for (int i = 0; i < length; i++){
inherited[i].original().modifiers |= extracompilermodifiers.acclocallyused;
}
}
if (current == null && this.type.ispublic()) {
int length = inherited.length;
for (int i = 0; i < length; i++) {
methodbinding inheritedmethod = inherited[i];
if (inheritedmethod.ispublic() && !inheritedmethod.declaringclass.ispublic())
this.type.addsyntheticbridgemethod(inheritedmethod);
}
}

if (current == null && skipinheritedmethods)
continue nextselector;

if (inherited.length == 1 && current == null) { // handle the common case
if (mustimplementabstractmethods && inherited[0].isabstract())
checkabstractmethod(inherited[0]);
continue nextselector;
}

int index = -1;
int inheritedlength = inherited.length;
methodbinding[] matchinginherited = new methodbinding[inherited.length];
methodbinding[] foundmatch = new methodbinding[inherited.length]; // null is no match, otherwise value is matching currentmethod
if (current != null) {
for (int i = 0, length1 = current.length; i < length1; i++) {
methodbinding currentmethod = current[i];
methodbinding[] nonmatchinginherited = null;
for (int j = 0; j < inheritedlength; j++) {
methodbinding inheritedmethod = computesubstitutemethod(inherited[j], currentmethod);
if (inheritedmethod != null) {
if (foundmatch[j] == null && issubstituteparametersubsignature(currentmethod, inheritedmethod)) {
matchinginherited[++index] = inheritedmethod;
foundmatch[j] = currentmethod;
} else {
// best place to check each currentmethod against each non-matching inheritedmethod
checkfornameclash(currentmethod, inheritedmethod);
if (inheritedlength > 1) {
if (nonmatchinginherited == null)
nonmatchinginherited = new methodbinding[inheritedlength];
nonmatchinginherited[j] = inheritedmethod;
}
}
}
}
if (index >= 0) {
// see addtional comments in https://bugs.eclipse.org/bugs/show_bug.cgi?id=122881
// if (index > 0 && currentmethod.declaringclass.isinterface()) // only check when inherited methods are from interfaces
//	checkinheritedreturntypes(matchinginherited, index + 1);
checkagainstinheritedmethods(currentmethod, matchinginherited, index + 1, nonmatchinginherited); // pass in the length of matching
while (index >= 0) matchinginherited[index--] = null; // clear the contents of the matching methods
}
}
}

// skip tracks which inherited methods have matched other inherited methods
// either because they match the same currentmethod or match each other
boolean[] skip = new boolean[inheritedlength];
for (int i = 0; i < inheritedlength; i++) {
methodbinding matchmethod = foundmatch[i];
if (matchmethod == null && current != null && this.type.ispublic()) { // current == null case handled already.
methodbinding inheritedmethod = inherited[i];
if (inheritedmethod.ispublic() && !inheritedmethod.declaringclass.ispublic()) {
this.type.addsyntheticbridgemethod(inheritedmethod);
}
}
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=296660, if current type is exposed,
// inherited methods of super classes are too. current == null case handled already.
if (!isorenclosedbyprivatetype && matchmethod == null && current != null) {
inherited[i].original().modifiers |= extracompilermodifiers.acclocallyused;
}
if (skip[i]) continue;
methodbinding inheritedmethod = inherited[i];
if (matchmethod == null)
matchinginherited[++index] = inheritedmethod;
for (int j = i + 1; j < inheritedlength; j++) {
methodbinding otherinheritedmethod = inherited[j];
if (matchmethod == foundmatch[j] && matchmethod != null)
continue; // both inherited methods matched the same currentmethod
if (canskipinheritedmethods(inheritedmethod, otherinheritedmethod))
continue;
// skip the otherinheritedmethod if it is completely replaced by inheritedmethod
// this elimination used to happen rather eagerly in computeinheritedmethods step
// itself earlier. (https://bugs.eclipse.org/bugs/show_bug.cgi?id=302358)
if (inheritedmethod.declaringclass != otherinheritedmethod.declaringclass) {
if (otherinheritedmethod.declaringclass.isinterface()) {
if (isinterfacemethodimplemented(otherinheritedmethod, inheritedmethod, otherinheritedmethod.declaringclass)) {
skip[j] = true;
continue;
}
} else if (aremethodscompatible(inheritedmethod, otherinheritedmethod)) {
skip[j] = true;
continue;
}
}
otherinheritedmethod = computesubstitutemethod(otherinheritedmethod, inheritedmethod);
if (otherinheritedmethod != null) {
if (inheritedmethod.declaringclass != otherinheritedmethod.declaringclass
&& issubstituteparametersubsignature(inheritedmethod, otherinheritedmethod)) {
if (index == -1)
matchinginherited[++index] = inheritedmethod;
if (foundmatch[j] == null)
matchinginherited[++index] = otherinheritedmethod;
skip[j] = true;
} else if (matchmethod == null && foundmatch[j] == null) {
checkinheritedmethods(inheritedmethod, otherinheritedmethod);
}
}
}
if (index == -1) continue;

if (index > 0)
checkinheritedmethods(matchinginherited, index + 1); // pass in the length of matching
else if (mustimplementabstractmethods && matchinginherited[0].isabstract() && matchmethod == null)
checkabstractmethod(matchinginherited[0]);
while (index >= 0) matchinginherited[index--] = null; // clear the previous contents of the matching methods
}
}
}
void checktypevariablemethods(typeparameter typeparameter) {
char[][] methodselectors = this.inheritedmethods.keytable;
nextselector : for (int s = methodselectors.length; --s >= 0;) {
if (methodselectors[s] == null) continue nextselector;
methodbinding[] inherited = (methodbinding[]) this.inheritedmethods.valuetable[s];
if (inherited.length == 1) continue nextselector;

int index = -1;
methodbinding[] matchinginherited = new methodbinding[inherited.length];
for (int i = 0, length = inherited.length; i < length; i++) {
while (index >= 0) matchinginherited[index--] = null; // clear the previous contents of the matching methods
methodbinding inheritedmethod = inherited[i];
if (inheritedmethod != null) {
matchinginherited[++index] = inheritedmethod;
for (int j = i + 1; j < length; j++) {
methodbinding otherinheritedmethod = inherited[j];
if (canskipinheritedmethods(inheritedmethod, otherinheritedmethod))
continue;
otherinheritedmethod = computesubstitutemethod(otherinheritedmethod, inheritedmethod);
if (otherinheritedmethod != null && issubstituteparametersubsignature(inheritedmethod, otherinheritedmethod)) {
matchinginherited[++index] = otherinheritedmethod;
inherited[j] = null; // do not want to find it again
}
}
}
if (index > 0) {
methodbinding first = matchinginherited[0];
int count = index + 1;
while (--count > 0) {
methodbinding match = matchinginherited[count];
if (arereturntypescompatible(first, match)) continue;
// unrelated interfaces - check to see if return types are compatible
if (first.declaringclass.isinterface() && match.declaringclass.isinterface() && arereturntypescompatible(match, first))
continue;
break;
}
if (count > 0) {  // all inherited methods do not have the same vmsignature
problemreporter().inheritedmethodshaveincompatiblereturntypes(typeparameter, matchinginherited, index + 1);
continue nextselector;
}
}
}
}
}
methodbinding computesubstitutemethod(methodbinding inheritedmethod, methodbinding currentmethod) {
if (inheritedmethod == null) return null;
if (currentmethod.parameters.length != inheritedmethod.parameters.length) return null; // no match

// due to hierarchy & compatibility checks, we need to ensure these 2 methods are resolved
if (currentmethod.declaringclass instanceof binarytypebinding)
((binarytypebinding) currentmethod.declaringclass).resolvetypesfor(currentmethod);
if (inheritedmethod.declaringclass instanceof binarytypebinding)
((binarytypebinding) inheritedmethod.declaringclass).resolvetypesfor(inheritedmethod);

typevariablebinding[] inheritedtypevariables = inheritedmethod.typevariables;
int inheritedlength = inheritedtypevariables.length;
if (inheritedlength == 0) return inheritedmethod; // no substitution needed
typevariablebinding[] typevariables = currentmethod.typevariables;
int length = typevariables.length;
if (length == 0)
return inheritedmethod.asrawmethod(this.environment);
if (length != inheritedlength)
return inheritedmethod; // no match jls 8.4.2

// interface i { <t> void foo(t t); }
// class x implements i { public <t extends i> void foo(t t) {} }
// for the above case, we do not want to answer the substitute method since its not a match
typebinding[] arguments = new typebinding[length];
system.arraycopy(typevariables, 0, arguments, 0, length);
parameterizedgenericmethodbinding substitute =
this.environment.createparameterizedgenericmethod(inheritedmethod, arguments);
for (int i = 0; i < inheritedlength; i++) {
typevariablebinding inheritedtypevariable = inheritedtypevariables[i];
typebinding argument = arguments[i];
if (argument instanceof typevariablebinding) {
typevariablebinding typevariable = (typevariablebinding) argument;
if (typevariable.firstbound == inheritedtypevariable.firstbound) {
if (typevariable.firstbound == null)
continue; // both are null
} else if (typevariable.firstbound != null && inheritedtypevariable.firstbound != null) {
if (typevariable.firstbound.isclass() != inheritedtypevariable.firstbound.isclass())
return inheritedmethod; // not a match
}
if (scope.substitute(substitute, inheritedtypevariable.superclass) != typevariable.superclass)
return inheritedmethod; // not a match
int interfacelength = inheritedtypevariable.superinterfaces.length;
referencebinding[] interfaces = typevariable.superinterfaces;
if (interfacelength != interfaces.length)
return inheritedmethod; // not a match
// todo (kent) another place where we expect the superinterfaces to be in the exact same order
next : for (int j = 0; j < interfacelength; j++) {
typebinding supertype = scope.substitute(substitute, inheritedtypevariable.superinterfaces[j]);
for (int k = 0; k < interfacelength; k++)
if (supertype == interfaces[k])
continue next;
return inheritedmethod; // not a match
}
} else if (inheritedtypevariable.boundcheck(substitute, argument) != typeconstants.ok) {
return inheritedmethod;
}
}
return substitute;
}
boolean detectinheritednameclash(methodbinding inherited, methodbinding otherinherited) {
if (!inherited.areparametererasuresequal(otherinherited))
return false;
// skip it if otherinherited is defined by a subtype of inherited's declaringclass or vice versa.
// avoid being order sensitive and check with the roles reversed also.
if (inherited.declaringclass.erasure() != otherinherited.declaringclass.erasure()) {
if (inherited.declaringclass.findsupertypeoriginatingfrom(otherinherited.declaringclass) != null)
return false;
if (otherinherited.declaringclass.findsupertypeoriginatingfrom(inherited.declaringclass) != null)
return false;
}

problemreporter().inheritedmethodshavenameclash(this.type, inherited, otherinherited);
return true;
}
boolean detectnameclash(methodbinding current, methodbinding inherited, boolean treatassynthetic) {
methodbinding methodtocheck = inherited;
if (!treatassynthetic) {
// for a user method, see if current class overrides the inherited method. if it does,
// then any grievance we may have ought to be against the current class's method and
// not against any super implementations. https://bugs.eclipse.org/bugs/show_bug.cgi?id=293615
methodbinding[] currentnamesakes = (methodbinding[]) this.currentmethods.get(inherited.selector);
if (currentnamesakes.length > 1) { // we know it ought to at least one and that current is not the override
for (int i = 0, length = currentnamesakes.length; i < length; i++) {
methodbinding currentmethod = currentnamesakes[i];
if (currentmethod != current && doesmethodoverride(currentmethod, inherited)) {
methodtocheck = currentmethod;
break;
}
}
}
}
methodbinding original = methodtocheck.original(); // can be the same as inherited
if (!current.areparametererasuresequal(original))
return false;
original = inherited.original();  // for error reporting use, inherited.original()
problemreporter(current).methodnameclash(current, inherited.declaringclass.israwtype() ? inherited : original);
return true;
}
public boolean doesmethodoverride(methodbinding method, methodbinding inheritedmethod) {
return couldmethodoverride(method, inheritedmethod) && aremethodscompatible(method, inheritedmethod);
}
boolean dotypevariablesclash(methodbinding one, methodbinding substitutetwo) {
// one has type variables and substitutetwo did not pass bounds check in computesubstitutemethod()
return one.typevariables != binding.no_type_variables && !(substitutetwo instanceof parameterizedgenericmethodbinding);
}
simpleset findsuperinterfacecollisions(referencebinding superclass, referencebinding[] superinterfaces) {
referencebinding[] interfacestovisit = null;
int nextposition = 0;
referencebinding[] itsinterfaces = superinterfaces;
if (itsinterfaces != binding.no_superinterfaces) {
nextposition = itsinterfaces.length;
interfacestovisit = itsinterfaces;
}

boolean isinconsistent = this.type.ishierarchyinconsistent();
referencebinding supertype = superclass;
while (supertype != null && supertype.isvalidbinding()) {
isinconsistent |= supertype.ishierarchyinconsistent();
if ((itsinterfaces = supertype.superinterfaces()) != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
supertype = supertype.superclass();
}

for (int i = 0; i < nextposition; i++) {
supertype = interfacestovisit[i];
if (supertype.isvalidbinding()) {
isinconsistent |= supertype.ishierarchyinconsistent();
if ((itsinterfaces = supertype.superinterfaces()) != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}

if (!isinconsistent) return null; // hierarchy is consistent so no collisions are possible
simpleset copy = null;
for (int i = 0; i < nextposition; i++) {
referencebinding current = interfacestovisit[i];
if (current.isvalidbinding()) {
typebinding erasure = current.erasure();
for (int j = i + 1; j < nextposition; j++) {
referencebinding next = interfacestovisit[j];
if (next.isvalidbinding() && next.erasure() == erasure) {
if (copy == null)
copy = new simpleset(nextposition);
copy.add(interfacestovisit[i]);
copy.add(interfacestovisit[j]);
}
}
}
}
return copy;
}
boolean hasgenericparameter(methodbinding method) {
if (method.genericsignature() == null) return false;

// may be only the return type that is generic, need to check parameters
typebinding[] params = method.parameters;
for (int i = 0, l = params.length; i < l; i++) {
typebinding param = params[i].leafcomponenttype();
if (param instanceof referencebinding) {
int modifiers = ((referencebinding) param).modifiers;
if ((modifiers & extracompilermodifiers.accgenericsignature) != 0)
return true;
}
}
return false;
}
boolean isacceptablereturntypeoverride(methodbinding currentmethod, methodbinding inheritedmethod) {
// called when currentmethod's return type is compatible with inheritedmethod's return type

if (inheritedmethod.declaringclass.israwtype())
return true; // since the inheritedmethod comes from a raw type, the return type is always acceptable

methodbinding originalinherited = inheritedmethod.original();
typebinding originalinheritedreturntype = originalinherited.returntype.leafcomponenttype();
if (originalinheritedreturntype.isparameterizedtypewithactualarguments())
return !currentmethod.returntype.leafcomponenttype().israwtype(); // raw types issue a warning if inherited is parameterized

typebinding currentreturntype = currentmethod.returntype.leafcomponenttype();
switch (currentreturntype.kind()) {
case binding.type_parameter :
if (currentreturntype == inheritedmethod.returntype.leafcomponenttype())
return true;
//$fall-through$
default :
if (originalinheritedreturntype.istypevariable())
if (((typevariablebinding) originalinheritedreturntype).declaringelement == originalinherited)
return false;
return true;
}
}
// caveat: returns false if a method is implemented that needs a bridge method
boolean isinterfacemethodimplemented(methodbinding inheritedmethod, methodbinding existingmethod, referencebinding supertype) {
if (inheritedmethod.original() != inheritedmethod && existingmethod.declaringclass.isinterface())
return false; // must hold onto parameterizedmethod to see if a bridge method is necessary

inheritedmethod = computesubstitutemethod(inheritedmethod, existingmethod);
return inheritedmethod != null
&& inheritedmethod.returntype == existingmethod.returntype // keep around to produce bridge methods
&& doesmethodoverride(existingmethod, inheritedmethod);
}
public boolean ismethodsubsignature(methodbinding method, methodbinding inheritedmethod) {
if (!org.eclipse.jdt.core.compiler.charoperation.equals(method.selector, inheritedmethod.selector))
return false;

// need to switch back to the original if the method is from a parameterizedtype
if (method.declaringclass.isparameterizedtype())
method = method.original();

methodbinding inheritedoriginal = method.findoriginalinheritedmethod(inheritedmethod);
return isparametersubsignature(method, inheritedoriginal == null ? inheritedmethod : inheritedoriginal);
}
boolean isparametersubsignature(methodbinding method, methodbinding inheritedmethod) {
methodbinding substitute = computesubstitutemethod(inheritedmethod, method);
return substitute != null && issubstituteparametersubsignature(method, substitute);
}
// if method "overrides" substitutemethod then we can skip over substitutemethod while resolving a message send
// if it does not then a name clash error is likely
boolean issubstituteparametersubsignature(methodbinding method, methodbinding substitutemethod) {
if (!areparametersequal(method, substitutemethod)) {
// method can still override substitutemethod in cases like :
// <u extends number> void c(u u) {}
// @@override void c(number n) {}
// but method cannot have a "generic-enabled" parameter type
if (substitutemethod.hassubstitutedparameters() && method.areparametererasuresequal(substitutemethod))
return method.typevariables == binding.no_type_variables && !hasgenericparameter(method);

// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=279836
if (method.declaringclass.israwtype() && substitutemethod.declaringclass.israwtype())
if (method.hassubstitutedparameters() && substitutemethod.hassubstitutedparameters())
return aremethodscompatible(method, substitutemethod);

return false;
}

if (substitutemethod instanceof parameterizedgenericmethodbinding) {
if (method.typevariables != binding.no_type_variables)
return !((parameterizedgenericmethodbinding) substitutemethod).israw;
// since substitutemethod has substituted type variables, method cannot have a generic signature and no variables -> its a name clash if it does
return !hasgenericparameter(method);
}

// if method has its own variables, then substitutemethod failed bounds check in computesubstitutemethod()
return method.typevariables == binding.no_type_variables;
}
boolean isunsafereturntypeoverride(methodbinding currentmethod, methodbinding inheritedmethod) {
// called when currentmethod's return type is not compatible with inheritedmethod's return type

// jls 3 8.4.5: more are accepted, with an unchecked conversion
if (currentmethod.returntype == inheritedmethod.returntype.erasure()) {
typebinding[] currentparams = currentmethod.parameters;
typebinding[] inheritedparams = inheritedmethod.parameters;
for (int i = 0, l = currentparams.length; i < l; i++)
if (!aretypesequal(currentparams[i], inheritedparams[i]))
return true;
}
if (currentmethod.typevariables == binding.no_type_variables
&& inheritedmethod.original().typevariables != binding.no_type_variables
&& currentmethod.returntype.erasure().findsupertypeoriginatingfrom(inheritedmethod.returntype.erasure()) != null) {
return true;
}
return false;
}
boolean reportincompatiblereturntypeerror(methodbinding currentmethod, methodbinding inheritedmethod) {
if (isunsafereturntypeoverride(currentmethod, inheritedmethod)) {
problemreporter(currentmethod).unsafereturntypeoverride(currentmethod, inheritedmethod, this.type);
return false;
}
return super.reportincompatiblereturntypeerror(currentmethod, inheritedmethod);
}
void verify() {
if (this.type.isannotationtype())
this.type.detectannotationcycle();

super.verify();

for (int i = this.type.typevariables.length; --i >= 0;) {
typevariablebinding var = this.type.typevariables[i];
// must verify bounds if the variable has more than 1
if (var.superinterfaces == binding.no_superinterfaces) continue;
if (var.superinterfaces.length == 1 && var.superclass.id == typeids.t_javalangobject) continue;

this.currentmethods = new hashtableofobject(0);
referencebinding superclass = var.superclass();
if (superclass.kind() == binding.type_parameter)
superclass = (referencebinding) superclass.erasure();
referencebinding[] itsinterfaces = var.superinterfaces();
referencebinding[] superinterfaces = new referencebinding[itsinterfaces.length];
for (int j = itsinterfaces.length; --j >= 0;) {
superinterfaces[j] = itsinterfaces[j].kind() == binding.type_parameter
? (referencebinding) itsinterfaces[j].erasure()
: itsinterfaces[j];
}
computeinheritedmethods(superclass, superinterfaces);
checktypevariablemethods(this.type.scope.referencecontext.typeparameters[i]);
}
}
}
