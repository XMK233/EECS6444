/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;

public abstract class astnode implements basetypes, compilermodifiers, typeconstants, typeids {

public int sourcestart, sourceend;

//some global provision for the hierarchy
public final static constant notaconstant = constant.notaconstant;

// storage for internal flags (32 bits)						bit usage
public final static int bit1 = 0x1; 						// return type (operator) | name reference kind (name ref) | add assertion (type decl) | useful empty statement (empty statement)
public final static int bit2 = 0x2; 						// return type (operator) | name reference kind (name ref) | has local type (type, method, field decl)
public final static int bit3 = 0x4; 						// return type (operator) | name reference kind (name ref) | implicit this (this ref)
public final static int bit4 = 0x8; 						// return type (operator) | first assignment to local (local decl) | undocumented empty block (block, type and method decl)
public final static int bit5 = 0x10; 					// value for return (expression) | has all method bodies (unit)
public final static int bit6 = 0x20; 					// depth (name ref, msg) | only value required (binary expression) | ignore need cast check (cast expression)
public final static int bit7 = 0x40; 					// depth (name ref, msg) | operator (operator) | need runtime checkcast (cast expression)
public final static int bit8 = 0x80; 					// depth (name ref, msg) | operator (operator)
public final static int bit9 = 0x100; 				// depth (name ref, msg) | operator (operator)
public final static int bit10= 0x200; 				// depth (name ref, msg) | operator (operator)
public final static int bit11 = 0x400; 				// depth (name ref, msg) | operator (operator)
public final static int bit12 = 0x800; 				// depth (name ref, msg) | operator (operator)
public final static int bit13 = 0x1000; 			// depth (name ref, msg)
public final static int bit14 = 0x2000; 			// assigned (reference lhs)
public final static int bit15 = 0x4000; 			// is unnecessary cast (expression)
public final static int bit16 = 0x8000; 			// in javadoc comment (name ref, type ref, msg)
public final static int bit17 = 0x10000;
public final static int bit18 = 0x20000;
public final static int bit19 = 0x40000;
public final static int bit20 = 0x80000;
public final static int bit21 = 0x100000;
public final static int bit22 = 0x200000; 			// parenthesis count (expression)
public final static int bit23 = 0x400000; 			// parenthesis count (expression)
public final static int bit24 = 0x800000; 			// parenthesis count (expression)
public final static int bit25 = 0x1000000; 		// parenthesis count (expression)
public final static int bit26 = 0x2000000; 		// parenthesis count (expression)
public final static int bit27 = 0x4000000; 		// parenthesis count (expression)
public final static int bit28 = 0x8000000; 		// parenthesis count (expression)
public final static int bit29 = 0x10000000; 		// parenthesis count (expression)
public final static int bit30 = 0x20000000; 		// assignment with no effect (assignment)
public final static int bit31 = 0x40000000; 		// local declaration reachable (local decl)
public final static int bit32 = 0x80000000; 		// reachable (statement)

public int bits = isreachablemask; 				// reachable by default

// for operators
public static final int returntypeidmask = bit1|bit2|bit3|bit4;
public static final int operatorshift = 6;	// bit7 -> bit12
public static final int operatormask = bit7|bit8|bit9|bit10|bit11|bit12; // 6 bits for operator id

// for binary expressions
public static final int valueforreturnmask = bit5;
public static final int onlyvaluerequiredmask = bit6;

// for cast expressions
public static final int unnecessarycastmask = bit15;
public static final int needruntimecheckcastmask = bit7;
public static final int ignoreneedforcastcheckmask = bit6;

// for name references
public static final int restrictiveflagmask = bit1|bit2|bit3;
public static final int firstassignmenttolocalmask = bit4;

// for this reference
public static final int isimplicitthismask = bit3;

// for single name references
public static final int depthshift = 5;	// bit6 -> bit13
public static final int depthmask = bit6|bit7|bit8|bit9|bit10|bit11|bit12|bit13; // 8 bits for actual depth value (max. 255)

// for statements
public static final int isreachablemask = bit32;
public static final int islocaldeclarationreachablemask = bit31;

// for type declaration
public static final int addassertionmask = bit1;

// for type, method and field declarations
public static final int haslocaltypemask = bit2; // cannot conflict with addassertionmask

// for expression
public static final int parenthesizedshift = 21; // bit22 -> bit29
public static final int parenthesizedmask = bit22|bit23|bit24|bit25|bit26|bit27|bit28|bit29; // 8 bits for parenthesis count value (max. 255)

// for assignment
public static final int isassignmentwithnoeffectmask = bit30;

// for references on lhs of assignment (set only for true assignments, as opposed to compound ones)
public static final int isstrictlyassignedmask = bit14;

// for empty statement
public static final int isusefulemptystatementmask = bit1;

// for block and method declaration
public static final int undocumentedemptyblockmask = bit4;

// for compilation unit
public static final int hasallmethodbodies = bit5;

// for references in javadoc comments
public static final int insidejavadoc = bit16;

public astnode() {

super();
}

public astnode concretestatement() {
return this;
}

/* answer true if the field use is considered deprecated.
* an access in the same compilation unit is allowed.
*/
public final boolean isfieldusedeprecated(fieldbinding field, scope scope, boolean isstrictlyassigned) {

if (!isstrictlyassigned && field.isprivate() && !scope.isdefinedinfield(field)) {
// ignore cases where field is used from within inside itself
field.modifiers |= accprivateused;
}

if (!field.isviewedasdeprecated()) return false;

// inside same unit - no report
if (scope.isdefinedinsameunit(field.declaringclass)) return false;

// if context is deprecated, may avoid reporting
if (!scope.environment().options.reportdeprecationinsidedeprecatedcode && scope.isinsidedeprecatedcode()) return false;
return true;
}

public boolean isimplicitthis() {

return false;
}

/* answer true if the method use is considered deprecated.
* an access in the same compilation unit is allowed.
*/
public final boolean ismethodusedeprecated(methodbinding method, scope scope) {

if (method.isprivate() && !scope.isdefinedinmethod(method)) {
// ignore cases where method is used from within inside itself (e.g. direct recursions)
method.modifiers |= accprivateused;
}

if (!method.isviewedasdeprecated()) return false;

// inside same unit - no report
if (scope.isdefinedinsameunit(method.declaringclass)) return false;

// if context is deprecated, may avoid reporting
if (!scope.environment().options.reportdeprecationinsidedeprecatedcode && scope.isinsidedeprecatedcode()) return false;
return true;
}

public boolean issuper() {

return false;
}

public boolean isthis() {

return false;
}

/* answer true if the type use is considered deprecated.
* an access in the same compilation unit is allowed.
*/
public final boolean istypeusedeprecated(typebinding type, scope scope) {

if (type.isarraytype())
type = ((arraybinding) type).leafcomponenttype;
if (type.isbasetype())
return false;

referencebinding reftype = (referencebinding) type;

if (reftype.isprivate() && !scope.isdefinedintype(reftype)) {
// ignore cases where type is used from within inside itself
reftype.modifiers |= accprivateused;
}

if (!reftype.isviewedasdeprecated()) return false;

// inside same unit - no report
if (scope.isdefinedinsameunit(reftype)) return false;

// if context is deprecated, may avoid reporting
if (!scope.environment().options.reportdeprecationinsidedeprecatedcode && scope.isinsidedeprecatedcode()) return false;
return true;
}

public abstract stringbuffer print(int indent, stringbuffer output);

public static stringbuffer printindent(int indent, stringbuffer output) {

for (int i = indent; i > 0; i--) output.append("  "); //$non-nls-1$
return output;
}

public static stringbuffer printmodifiers(int modifiers, stringbuffer output) {

if ((modifiers & accpublic) != 0)
output.append("public "); //$non-nls-1$
if ((modifiers & accprivate) != 0)
output.append("private "); //$non-nls-1$
if ((modifiers & accprotected) != 0)
output.append("protected "); //$non-nls-1$
if ((modifiers & accstatic) != 0)
output.append("static "); //$non-nls-1$
if ((modifiers & accfinal) != 0)
output.append("final "); //$non-nls-1$
if ((modifiers & accsynchronized) != 0)
output.append("synchronized "); //$non-nls-1$
if ((modifiers & accvolatile) != 0)
output.append("volatile "); //$non-nls-1$
if ((modifiers & acctransient) != 0)
output.append("transient "); //$non-nls-1$
if ((modifiers & accnative) != 0)
output.append("native "); //$non-nls-1$
if ((modifiers & accabstract) != 0)
output.append("abstract "); //$non-nls-1$
return output;
}

public string tostring() {

return print(0, new stringbuffer(30)).tostring();
}

public void traverse(iabstractsyntaxtreevisitor visitor, blockscope scope) {
// do nothing by default
}
}
