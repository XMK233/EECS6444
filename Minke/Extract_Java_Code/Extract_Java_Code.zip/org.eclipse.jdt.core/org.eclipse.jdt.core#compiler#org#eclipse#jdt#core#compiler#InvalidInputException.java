/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/

package org.eclipse.jdt.core.compiler;

/**
* exception thrown by a scanner when encountering lexical errors.
*
* @@noinstantiate this class is not intended to be instantiated by clients.
* @@noextend this class is not intended to be subclassed by clients.
*/
public class invalidinputexception extends exception {

private static final long serialversionuid = 2909732853499731592l; // backward compatible

/**
* creates a new exception with no detail message.
*/
public invalidinputexception() {
super();
}

/**
* creates a new exception with the given detail message.
* @@param message the detail message
*/
public invalidinputexception(string message) {
super(message);
}
}
