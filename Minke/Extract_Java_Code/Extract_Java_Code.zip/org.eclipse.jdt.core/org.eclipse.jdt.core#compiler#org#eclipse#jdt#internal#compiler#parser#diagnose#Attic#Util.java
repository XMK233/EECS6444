/*******************************************************************************
* copyright (c) 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser.diagnose;

import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.ast.initializer;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.lookup.compilermodifiers;

public class util {
private static final int initial_size = 10;

// flags
public static final int no_flag = 0;
public static final int lbrace_missing = 1;
public static final int ignore = 2;

static class rangeresult {
int pos;
int[] intervalstarts;
int[] intervalends;
int[] intervalflags;

rangeresult() {
this.pos = 0;
this.intervalstarts = new int[initial_size];
this.intervalends = new int[initial_size];
this.intervalflags = new int[initial_size];
}

void addinterval(int start, int end){
addinterval(start, end, no_flag);
}

void addinterval(int start, int end, int flags){
if(pos >= intervalstarts.length) {
system.arraycopy(intervalstarts, 0, intervalstarts = new int[pos * 2], 0, pos);
system.arraycopy(intervalends, 0, intervalends = new int[pos * 2], 0, pos);
system.arraycopy(intervalflags, 0, intervalflags = new int[pos * 2], 0, pos);
}
intervalstarts[pos] = start;
intervalends[pos] = end;
intervalflags[pos] = flags;
pos++;
}

int[][] getranges() {
int[] resultstarts = new int[pos];
int[] resultends = new int[pos];
int[] resultflags = new int[pos];

system.arraycopy(intervalstarts, 0, resultstarts, 0, pos);
system.arraycopy(intervalends, 0, resultends, 0, pos);
system.arraycopy(intervalflags, 0, resultflags, 0, pos);

if (resultstarts.length > 1) {
quicksort(resultstarts, resultends, resultflags, 0, resultstarts.length - 1);
}
return new int[][]{resultstarts, resultends, resultflags};
}

private void quicksort(int[] list, int[] list2, int[] list3, int left, int right) {
int original_left= left;
int original_right= right;
int mid= list[(left + right) / 2];
do {
while (compare(list[left], mid) < 0) {
left++;
}
while (compare(mid, list[right]) < 0) {
right--;
}
if (left <= right) {
int tmp= list[left];
list[left]= list[right];
list[right]= tmp;

tmp = list2[left];
list2[left]= list2[right];
list2[right]= tmp;

tmp = list3[left];
list3[left]= list3[right];
list3[right]= tmp;

left++;
right--;
}
} while (left <= right);

if (original_left < right) {
quicksort(list, list2, list3, original_left, right);
}
if (left < original_right) {
quicksort(list, list2, list3, left, original_right);
}
}

private int compare(int i1, int i2) {
return i1 - i2;
}
}



public static boolean containserrorinsignature(abstractmethoddeclaration method){
return method.sourceend + 1 == method.bodystart	|| method.bodyend == method.declarationsourceend;
}

public static int[][] computedietrange(typedeclaration[] types) {
if(types == null || types.length == 0) {
return new int[3][0];
} else {
rangeresult result = new rangeresult();
computedietrange0(types, result);
return result.getranges();
}
}

private static void computedietrange0(typedeclaration[] types, rangeresult result) {
for (int j = 0; j < types.length; j++) {
//members
typedeclaration[] membertypedeclarations = types[j].membertypes;
if(membertypedeclarations != null && membertypedeclarations.length > 0) {
computedietrange0(types[j].membertypes, result);
}
//methods
abstractmethoddeclaration[] methods = types[j].methods;
if (methods != null) {
int length = methods.length;
for (int i = 0; i < length; i++) {
abstractmethoddeclaration method = methods[i];
if(containsignoredbody(method)) {
if(containserrorinsignature(method)) {
method.errorinsignature = true;
result.addinterval(method.declarationsourcestart, method.declarationsourceend, ignore);
} else {
int flags = method.sourceend + 1 == method.bodystart ? lbrace_missing : no_flag;
result.addinterval(method.bodystart, method.bodyend, flags);
}
}
}
}

//initializers
fielddeclaration[] fields = types[j].fields;
if (fields != null) {
int length = fields.length;
for (int i = 0; i < length; i++) {
if (fields[i] instanceof initializer) {
initializer initializer = (initializer)fields[i];
if(initializer.declarationsourceend == initializer.bodyend){
initializer.errorinsignature = true;
result.addinterval(initializer.declarationsourcestart, initializer.declarationsourceend, ignore);
} else {
result.addinterval(initializer.bodystart, initializer.bodyend);
}
}
}
}
}
}

public static boolean isininterval(int start, int end, int[] intervalstart, int[] intervalend) {
int length = intervalstart.length;
for (int i = 0; i < length; i++) {
if(intervalstart[i] <= start && intervalend[i] >= end) {
return true;
} else if(intervalstart[i] > end) {
return false;
}
}
return false;
}

public static int getpreviousinterval(int start, int end, int[] intervalstart, int[] intervalend) {
int length = intervalstart.length;
for (int i = 0; i < length; i++) {
if(intervalstart[i] > end) {
return i - 1;
}
}
return length - 1;
}

public static boolean containsignoredbody(abstractmethoddeclaration method){
return !method.isdefaultconstructor()
&& !method.isclinit()
&& (method.modifiers & compilermodifiers.accsemicolonbody) == 0;
}
}
