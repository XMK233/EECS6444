/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.*;
import org.eclipse.jdt.internal.compiler.*;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.flow.initializationflowcontext;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.problem.*;
import org.eclipse.jdt.internal.compiler.parser.*;
import org.eclipse.jdt.internal.compiler.util.util;

public abstract class abstractmethoddeclaration
extends astnode
implements problemseverities, referencecontext {

public methodscope scope;
//it is not relevent for constructor but it helps to have the name of the constructor here
//which is always the name of the class.....parsing do extra work to fill it up while it do not have to....
public char[] selector;
public int declarationsourcestart;
public int declarationsourceend;
public int modifiers;
public int modifierssourcestart;
public annotation[] annotations;
public argument[] arguments;
public typereference[] thrownexceptions;
public statement[] statements;
public int explicitdeclarations;
public methodbinding binding;
public boolean ignorefurtherinvestigation = false;

public javadoc javadoc;

public int bodystart;
public int bodyend = -1;
public compilationresult compilationresult;

abstractmethoddeclaration(compilationresult compilationresult){
this.compilationresult = compilationresult;
}

/*
*	we cause the compilation task to abort to a given extent.
*/
public void abort(int abortlevel, categorizedproblem problem) {

switch (abortlevel) {
case abortcompilation :
throw new abortcompilation(this.compilationresult, problem);
case abortcompilationunit :
throw new abortcompilationunit(this.compilationresult, problem);
case aborttype :
throw new aborttype(this.compilationresult, problem);
default :
throw new abortmethod(this.compilationresult, problem);
}
}

public abstract void analysecode(classscope classscope, initializationflowcontext initializationcontext, flowinfo info);

/**
* bind and add argument's binding into the scope of the method
*/
public void bindarguments() {

if (this.arguments != null) {
// by default arguments in abstract/native methods are considered to be used (no complaint is expected)
if (this.binding == null) {
for (int i = 0, length = this.arguments.length; i < length; i++) {
this.arguments[i].bind(this.scope, null, true);
}
return;
}
boolean used = this.binding.isabstract() || this.binding.isnative();
annotationbinding[][] paramannotations = null;
for (int i = 0, length = this.arguments.length; i < length; i++) {
argument argument = this.arguments[i];
argument.bind(this.scope, this.binding.parameters[i], used);
if (argument.annotations != null) {
if (paramannotations == null) {
paramannotations = new annotationbinding[length][];
for (int j=0; j<i; j++) {
paramannotations[j] = binding.no_annotations;
}
}
paramannotations[i] = argument.binding.getannotations();
} else if (paramannotations != null) {
paramannotations[i] = binding.no_annotations;
}
}
if (paramannotations != null)
this.binding.setparameterannotations(paramannotations);
}
}

/**
* record the thrown exception type bindings in the corresponding type references.
*/
public void bindthrownexceptions() {

if (this.thrownexceptions != null
&& this.binding != null
&& this.binding.thrownexceptions != null) {
int thrownexceptionlength = this.thrownexceptions.length;
int length = this.binding.thrownexceptions.length;
if (length == thrownexceptionlength) {
for (int i = 0; i < length; i++) {
this.thrownexceptions[i].resolvedtype = this.binding.thrownexceptions[i];
}
} else {
int bindingindex = 0;
for (int i = 0; i < thrownexceptionlength && bindingindex < length; i++) {
typereference thrownexception = this.thrownexceptions[i];
referencebinding thrownexceptionbinding = this.binding.thrownexceptions[bindingindex];
char[][] bindingcompoundname = thrownexceptionbinding.compoundname;
if (bindingcompoundname == null) continue; // skip problem case
if (thrownexception instanceof singletypereference) {
// single type reference
int lengthname = bindingcompoundname.length;
char[] thrownexceptiontypename = thrownexception.gettypename()[0];
if (charoperation.equals(thrownexceptiontypename, bindingcompoundname[lengthname - 1])) {
thrownexception.resolvedtype = thrownexceptionbinding;
bindingindex++;
}
} else {
// qualified type reference
if (charoperation.equals(thrownexception.gettypename(), bindingcompoundname)) {
thrownexception.resolvedtype = thrownexceptionbinding;
bindingindex++;
}
}
}
}
}
}

public compilationresult compilationresult() {

return this.compilationresult;
}

/**
* bytecode generation for a method
* @@param classscope
* @@param classfile
*/
public void generatecode(classscope classscope, classfile classfile) {

int problemresetpc = 0;
classfile.codestream.widemode = false; // reset widemode to false
if (this.ignorefurtherinvestigation) {
// method is known to have errors, dump a problem method
if (this.binding == null)
return; // handle methods with invalid signature or duplicates
int problemslength;
categorizedproblem[] problems =
this.scope.referencecompilationunit().compilationresult.getproblems();
categorizedproblem[] problemscopy = new categorizedproblem[problemslength = problems.length];
system.arraycopy(problems, 0, problemscopy, 0, problemslength);
classfile.addproblemmethod(this, this.binding, problemscopy);
return;
}
// regular code generation
try {
problemresetpc = classfile.contentsoffset;
this.generatecode(classfile);
} catch (abortmethod e) {
// a fatal error was detected during code generation, need to restart code gen if possible
if (e.compilationresult == codestream.restart_in_wide_mode) {
// a branch target required a goto_w, restart code gen in wide mode.
try {
classfile.contentsoffset = problemresetpc;
classfile.methodcount--;
classfile.codestream.resetinwidemode(); // request wide mode
this.generatecode(classfile); // restart method generation
} catch (abortmethod e2) {
int problemslength;
categorizedproblem[] problems =
this.scope.referencecompilationunit().compilationresult.getallproblems();
categorizedproblem[] problemscopy = new categorizedproblem[problemslength = problems.length];
system.arraycopy(problems, 0, problemscopy, 0, problemslength);
classfile.addproblemmethod(this, this.binding, problemscopy, problemresetpc);
}
} else {
// produce a problem method accounting for this fatal error
int problemslength;
categorizedproblem[] problems =
this.scope.referencecompilationunit().compilationresult.getallproblems();
categorizedproblem[] problemscopy = new categorizedproblem[problemslength = problems.length];
system.arraycopy(problems, 0, problemscopy, 0, problemslength);
classfile.addproblemmethod(this, this.binding, problemscopy, problemresetpc);
}
}
}

public void generatecode(classfile classfile) {

classfile.generatemethodinfoheader(this.binding);
int methodattributeoffset = classfile.contentsoffset;
int attributenumber = classfile.generatemethodinfoattribute(this.binding);
if ((!this.binding.isnative()) && (!this.binding.isabstract())) {
int codeattributeoffset = classfile.contentsoffset;
classfile.generatecodeattributeheader();
codestream codestream = classfile.codestream;
codestream.reset(this, classfile);
// initialize local positions
this.scope.computelocalvariablepositions(this.binding.isstatic() ? 0 : 1, codestream);

// arguments initialization for local variable debug attributes
if (this.arguments != null) {
for (int i = 0, max = this.arguments.length; i < max; i++) {
localvariablebinding argbinding;
codestream.addvisiblelocalvariable(argbinding = this.arguments[i].binding);
argbinding.recordinitializationstartpc(0);
}
}
if (this.statements != null) {
for (int i = 0, max = this.statements.length; i < max; i++)
this.statements[i].generatecode(this.scope, codestream);
}
// if a problem got reported during code gen, then trigger problem method creation
if (this.ignorefurtherinvestigation) {
throw new abortmethod(this.scope.referencecompilationunit().compilationresult, null);
}
if ((this.bits & astnode.needfreereturn) != 0) {
codestream.return_();
}
// local variable attributes
codestream.exituserscope(this.scope);
codestream.recordpositionsfrom(0, this.declarationsourceend);
try {
classfile.completecodeattribute(codeattributeoffset);
} catch(negativearraysizeexception e) {
throw new abortmethod(this.scope.referencecompilationunit().compilationresult, null);
}
attributenumber++;
} else {
checkargumentssize();
}
classfile.completemethodinfo(methodattributeoffset, attributenumber);
}

private void checkargumentssize() {
typebinding[] parameters = this.binding.parameters;
int size = 1; // an abstact method or a native method cannot be static
for (int i = 0, max = parameters.length; i < max; i++) {
switch(parameters[i].id) {
case typeids.t_long :
case typeids.t_double :
size += 2;
break;
default :
size++;
break;
}
if (size > 0xff) {
this.scope.problemreporter().nomoreavailablespaceforargument(this.scope.locals[i], this.scope.locals[i].declaration);
}
}
}

public boolean haserrors() {
return this.ignorefurtherinvestigation;
}

public boolean isabstract() {

if (this.binding != null)
return this.binding.isabstract();
return (this.modifiers & classfileconstants.accabstract) != 0;
}

public boolean isannotationmethod() {

return false;
}

public boolean isclinit() {

return false;
}

public boolean isconstructor() {

return false;
}

public boolean isdefaultconstructor() {

return false;
}

public boolean isinitializationmethod() {

return false;
}

public boolean ismethod() {

return false;
}

public boolean isnative() {

if (this.binding != null)
return this.binding.isnative();
return (this.modifiers & classfileconstants.accnative) != 0;
}

public boolean isstatic() {

if (this.binding != null)
return this.binding.isstatic();
return (this.modifiers & classfileconstants.accstatic) != 0;
}

/**
* fill up the method body with statement
* @@param parser
* @@param unit
*/
public abstract void parsestatements(parser parser, compilationunitdeclaration unit);

public stringbuffer print(int tab, stringbuffer output) {

if (this.javadoc != null) {
this.javadoc.print(tab, output);
}
printindent(tab, output);
printmodifiers(this.modifiers, output);
if (this.annotations != null) printannotations(this.annotations, output);

typeparameter[] typeparams = typeparameters();
if (typeparams != null) {
output.append('<');
int max = typeparams.length - 1;
for (int j = 0; j < max; j++) {
typeparams[j].print(0, output);
output.append(", ");//$non-nls-1$
}
typeparams[max].print(0, output);
output.append('>');
}

printreturntype(0, output).append(this.selector).append('(');
if (this.arguments != null) {
for (int i = 0; i < this.arguments.length; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.arguments[i].print(0, output);
}
}
output.append(')');
if (this.thrownexceptions != null) {
output.append(" throws "); //$non-nls-1$
for (int i = 0; i < this.thrownexceptions.length; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.thrownexceptions[i].print(0, output);
}
}
printbody(tab + 1, output);
return output;
}

public stringbuffer printbody(int indent, stringbuffer output) {

if (isabstract() || (this.modifiers & extracompilermodifiers.accsemicolonbody) != 0)
return output.append(';');

output.append(" {"); //$non-nls-1$
if (this.statements != null) {
for (int i = 0; i < this.statements.length; i++) {
output.append('\n');
this.statements[i].printstatement(indent, output);
}
}
output.append('\n');
printindent(indent == 0 ? 0 : indent - 1, output).append('}');
return output;
}

public stringbuffer printreturntype(int indent, stringbuffer output) {

return output;
}

public void resolve(classscope upperscope) {

if (this.binding == null) {
this.ignorefurtherinvestigation = true;
}

try {
bindarguments();
bindthrownexceptions();
resolvejavadoc();
resolveannotations(this.scope, this.annotations, this.binding);
resolvestatements();
// check @@deprecated annotation presence
if (this.binding != null
&& (this.binding.getannotationtagbits() & tagbits.annotationdeprecated) == 0
&& (this.binding.modifiers & classfileconstants.accdeprecated) != 0
&& this.scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
this.scope.problemreporter().missingdeprecatedannotationformethod(this);
}
} catch (abortmethod e) {
// ========= abort on fatal error =============
this.ignorefurtherinvestigation = true;
}
}

public void resolvejavadoc() {

if (this.binding == null) return;
if (this.javadoc != null) {
this.javadoc.resolve(this.scope);
return;
}
if (this.binding.declaringclass != null && !this.binding.declaringclass.islocaltype()) {
// set javadoc visibility
int javadocvisibility = this.binding.modifiers & extracompilermodifiers.accvisibilitymask;
classscope classscope = this.scope.classscope();
problemreporter reporter = this.scope.problemreporter();
int severity = reporter.computeseverity(iproblem.javadocmissing);
if (severity != problemseverities.ignore) {
if (classscope != null) {
javadocvisibility = util.computeoutermostvisibility(classscope.referencetype(), javadocvisibility);
}
int javadocmodifiers = (this.binding.modifiers & ~extracompilermodifiers.accvisibilitymask) | javadocvisibility;
reporter.javadocmissing(this.sourcestart, this.sourceend, severity, javadocmodifiers);
}
}
}

public void resolvestatements() {

if (this.statements != null) {
for (int i = 0, length = this.statements.length; i < length; i++) {
this.statements[i].resolve(this.scope);
}
} else if ((this.bits & undocumentedemptyblock) != 0) {
this.scope.problemreporter().undocumentedemptyblock(this.bodystart-1, this.bodyend+1);
}
}

public void tagashavingerrors() {
this.ignorefurtherinvestigation = true;
}

public void traverse(
astvisitor visitor,
classscope classscope) {
// default implementation: subclass will define it
}

public typeparameter[] typeparameters() {
return null;
}
}
