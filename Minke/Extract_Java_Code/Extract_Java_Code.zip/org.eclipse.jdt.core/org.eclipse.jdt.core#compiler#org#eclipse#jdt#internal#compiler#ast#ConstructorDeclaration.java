/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import java.util.arraylist;

import org.eclipse.jdt.core.compiler.*;
import org.eclipse.jdt.internal.compiler.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.*;
import org.eclipse.jdt.internal.compiler.problem.*;
import org.eclipse.jdt.internal.compiler.util.util;

public class constructordeclaration extends abstractmethoddeclaration {

public explicitconstructorcall constructorcall;

public typeparameter[] typeparameters;

public constructordeclaration(compilationresult compilationresult){
super(compilationresult);
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration#analysecode(org.eclipse.jdt.internal.compiler.lookup.classscope, org.eclipse.jdt.internal.compiler.flow.initializationflowcontext, org.eclipse.jdt.internal.compiler.flow.flowinfo)
* @@deprecated use instead {@@link #analysecode(classscope, initializationflowcontext, flowinfo, int)}
*/
public void analysecode(classscope classscope, initializationflowcontext initializerflowcontext, flowinfo flowinfo) {
analysecode(classscope, initializerflowcontext, flowinfo, flowinfo.reachable);
}

/**
* the flowinfo corresponds to non-static field initialization infos. it may be unreachable (155423), but still the explicit constructor call must be
* analysed as reachable, since it will be generated in the end.
*/
public void analysecode(classscope classscope, initializationflowcontext initializerflowcontext, flowinfo flowinfo, int initialreachmode) {
if (this.ignorefurtherinvestigation)
return;

int nonstaticfieldinforeachmode = flowinfo.reachmode();
flowinfo.setreachmode(initialreachmode);

checkunused: {
methodbinding constructorbinding;
if ((constructorbinding = this.binding) == null) break checkunused;
if ((this.bits & astnode.isdefaultconstructor) != 0) break checkunused;
if (constructorbinding.isused()) break checkunused;
if (constructorbinding.isprivate()) {
if ((this.binding.declaringclass.tagbits & tagbits.hasnonprivateconstructor) == 0)
break checkunused; // tolerate as known pattern to block instantiation
} else if (!constructorbinding.isorenclosedbyprivatetype()) {
break checkunused;
}
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=270446, when the ast built is an abridged version
// we don't have all tree nodes we would otherwise expect. (see astparser.setfocalposition)
if (this.constructorcall == null)
break checkunused;
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=264991, don't complain about this
// constructor being unused if the base class doesn't have a no-arg constructor.
// see that a seemingly unused constructor that chains to another constructor with a
// this(...) can be flagged as being unused without hesitation.
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=265142
if (this.constructorcall.accessmode != explicitconstructorcall.this) {
referencebinding superclass = constructorbinding.declaringclass.superclass();
if (superclass == null)
break checkunused;
// see if there is a no-arg super constructor
methodbinding methodbinding = superclass.getexactconstructor(binding.no_parameters);
if (methodbinding == null)
break checkunused;
if (!methodbinding.canbeseenby(superreference.implicitsuperconstructorcall(), this.scope))
break checkunused;
// otherwise default super constructor exists, so go ahead and complain unused.
}
// complain unused
this.scope.problemreporter().unusedprivateconstructor(this);
}

// check constructor recursion, once all constructor got resolved
if (isrecursive(null /*lazy initialized visited list*/)) {
this.scope.problemreporter().recursiveconstructorinvocation(this.constructorcall);
}

try {
exceptionhandlingflowcontext constructorcontext =
new exceptionhandlingflowcontext(
initializerflowcontext.parent,
this,
this.binding.thrownexceptions,
initializerflowcontext,
this.scope,
flowinfo.dead_end);
initializerflowcontext.checkinitializerexceptions(
this.scope,
constructorcontext,
flowinfo);

// anonymous constructor can gain extra thrown exceptions from unhandled ones
if (this.binding.declaringclass.isanonymoustype()) {
arraylist computedexceptions = constructorcontext.extendedexceptions;
if (computedexceptions != null){
int size;
if ((size = computedexceptions.size()) > 0){
referencebinding[] actuallythrownexceptions;
computedexceptions.toarray(actuallythrownexceptions = new referencebinding[size]);
this.binding.thrownexceptions = actuallythrownexceptions;
}
}
}

// tag parameters as being set
if (this.arguments != null) {
for (int i = 0, count = this.arguments.length; i < count; i++) {
flowinfo.markasdefinitelyassigned(this.arguments[i].binding);
}
}

// propagate to constructor call
if (this.constructorcall != null) {
// if calling 'this(...)', then flag all non-static fields as definitely
// set since they are supposed to be set inside other local constructor
if (this.constructorcall.accessmode == explicitconstructorcall.this) {
fieldbinding[] fields = this.binding.declaringclass.fields();
for (int i = 0, count = fields.length; i < count; i++) {
fieldbinding field;
if (!(field = fields[i]).isstatic()) {
flowinfo.markasdefinitelyassigned(field);
}
}
}
flowinfo = this.constructorcall.analysecode(this.scope, constructorcontext, flowinfo);
}

// reuse the reachmode from non static field info
flowinfo.setreachmode(nonstaticfieldinforeachmode);

// propagate to statements
if (this.statements != null) {
int complaintlevel = (nonstaticfieldinforeachmode & flowinfo.unreachable) == 0 ? statement.not_complained : statement.complained_fake_reachable;
for (int i = 0, count = this.statements.length; i < count; i++) {
statement stat = this.statements[i];
if ((complaintlevel = stat.complainifunreachable(flowinfo, this.scope, complaintlevel)) < statement.complained_unreachable) {
flowinfo = stat.analysecode(this.scope, constructorcontext, flowinfo);
}
}
}
// check for missing returning path
if ((flowinfo.tagbits & flowinfo.unreachable) == 0) {
this.bits |= astnode.needfreereturn;
}

// reuse the initial reach mode for diagnosing missing blank finals
// no, we should use the updated reach mode for diagnosing uninitialized blank finals.
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=235781
// flowinfo.setreachmode(initialreachmode);

// check missing blank final field initializations
if ((this.constructorcall != null)
&& (this.constructorcall.accessmode != explicitconstructorcall.this)) {
flowinfo = flowinfo.mergedwith(constructorcontext.initsonreturn);
fieldbinding[] fields = this.binding.declaringclass.fields();
for (int i = 0, count = fields.length; i < count; i++) {
fieldbinding field;
if ((!(field = fields[i]).isstatic())
&& field.isfinal()
&& (!flowinfo.isdefinitelyassigned(fields[i]))) {
this.scope.problemreporter().uninitializedblankfinalfield(
field,
((this.bits & astnode.isdefaultconstructor) != 0) ? (astnode) this.scope.referencetype() : this);
}
}
}
// check unreachable catch blocks
constructorcontext.complainifunusedexceptionhandlers(this);
// check unused parameters
this.scope.checkunusedparameters(this.binding);
} catch (abortmethod e) {
this.ignorefurtherinvestigation = true;
}
}

/**
* bytecode generation for a constructor
*
* @@param classscope org.eclipse.jdt.internal.compiler.lookup.classscope
* @@param classfile org.eclipse.jdt.internal.compiler.codegen.classfile
*/
public void generatecode(classscope classscope, classfile classfile) {
int problemresetpc = 0;
if (this.ignorefurtherinvestigation) {
if (this.binding == null)
return; // handle methods with invalid signature or duplicates
int problemslength;
categorizedproblem[] problems =
this.scope.referencecompilationunit().compilationresult.getproblems();
categorizedproblem[] problemscopy = new categorizedproblem[problemslength = problems.length];
system.arraycopy(problems, 0, problemscopy, 0, problemslength);
classfile.addproblemconstructor(this, this.binding, problemscopy);
return;
}
try {
problemresetpc = classfile.contentsoffset;
internalgeneratecode(classscope, classfile);
} catch (abortmethod e) {
if (e.compilationresult == codestream.restart_in_wide_mode) {
// a branch target required a goto_w, restart code gen in wide mode.
try {
classfile.contentsoffset = problemresetpc;
classfile.methodcount--;
classfile.codestream.resetinwidemode(); // request wide mode
internalgeneratecode(classscope, classfile); // restart method generation
} catch (abortmethod e2) {
int problemslength;
categorizedproblem[] problems =
this.scope.referencecompilationunit().compilationresult.getallproblems();
categorizedproblem[] problemscopy = new categorizedproblem[problemslength = problems.length];
system.arraycopy(problems, 0, problemscopy, 0, problemslength);
classfile.addproblemconstructor(this, this.binding, problemscopy, problemresetpc);
}
} else {
int problemslength;
categorizedproblem[] problems =
this.scope.referencecompilationunit().compilationresult.getallproblems();
categorizedproblem[] problemscopy = new categorizedproblem[problemslength = problems.length];
system.arraycopy(problems, 0, problemscopy, 0, problemslength);
classfile.addproblemconstructor(this, this.binding, problemscopy, problemresetpc);
}
}
}

public void generatesyntheticfieldinitializationsifnecessary(methodscope methodscope, codestream codestream, referencebinding declaringclass) {
if (!declaringclass.isnestedtype()) return;

nestedtypebinding nestedtype = (nestedtypebinding) declaringclass;

syntheticargumentbinding[] syntheticargs = nestedtype.syntheticenclosinginstances();
for (int i = 0, max = syntheticargs == null ? 0 : syntheticargs.length; i < max; i++) {
syntheticargumentbinding syntheticarg;
if ((syntheticarg = syntheticargs[i]).matchingfield != null) {
codestream.aload_0();
codestream.load(syntheticarg);
codestream.fieldaccess(opcodes.opc_putfield, syntheticarg.matchingfield, null /* default declaringclass */);
}
}
syntheticargs = nestedtype.syntheticouterlocalvariables();
for (int i = 0, max = syntheticargs == null ? 0 : syntheticargs.length; i < max; i++) {
syntheticargumentbinding syntheticarg;
if ((syntheticarg = syntheticargs[i]).matchingfield != null) {
codestream.aload_0();
codestream.load(syntheticarg);
codestream.fieldaccess(opcodes.opc_putfield, syntheticarg.matchingfield, null /* default declaringclass */);
}
}
}

private void internalgeneratecode(classscope classscope, classfile classfile) {
classfile.generatemethodinfoheader(this.binding);
int methodattributeoffset = classfile.contentsoffset;
int attributenumber = classfile.generatemethodinfoattribute(this.binding);
if ((!this.binding.isnative()) && (!this.binding.isabstract())) {

typedeclaration declaringtype = classscope.referencecontext;
int codeattributeoffset = classfile.contentsoffset;
classfile.generatecodeattributeheader();
codestream codestream = classfile.codestream;
codestream.reset(this, classfile);

// initialize local positions - including initializer scope.
referencebinding declaringclass = this.binding.declaringclass;

int enumoffset = declaringclass.isenum() ? 2 : 0; // string name, int ordinal
int argslotsize = 1 + enumoffset; // this==aload0

if (declaringclass.isnestedtype()){
this.scope.extrasyntheticarguments = declaringclass.syntheticouterlocalvariables();
this.scope.computelocalvariablepositions(// consider synthetic arguments if any
declaringclass.getenclosinginstancesslotsize() + 1 + enumoffset,
codestream);
argslotsize += declaringclass.getenclosinginstancesslotsize();
argslotsize += declaringclass.getouterlocalvariablesslotsize();
} else {
this.scope.computelocalvariablepositions(1 + enumoffset,  codestream);
}

if (this.arguments != null) {
for (int i = 0, max = this.arguments.length; i < max; i++) {
// arguments initialization for local variable debug attributes
localvariablebinding argbinding;
codestream.addvisiblelocalvariable(argbinding = this.arguments[i].binding);
argbinding.recordinitializationstartpc(0);
switch(argbinding.type.id) {
case typeids.t_long :
case typeids.t_double :
argslotsize += 2;
break;
default :
argslotsize++;
break;
}
}
}

methodscope initializerscope = declaringtype.initializerscope;
initializerscope.computelocalvariablepositions(argslotsize, codestream); // offset by the argument size (since not linked to method scope)

boolean needfieldinitializations = this.constructorcall == null || this.constructorcall.accessmode != explicitconstructorcall.this;

// post 1.4 target level, synthetic initializations occur prior to explicit constructor call
boolean preinitsyntheticfields = this.scope.compileroptions().targetjdk >= classfileconstants.jdk1_4;

if (needfieldinitializations && preinitsyntheticfields){
generatesyntheticfieldinitializationsifnecessary(this.scope, codestream, declaringclass);
}
// generate constructor call
if (this.constructorcall != null) {
this.constructorcall.generatecode(this.scope, codestream);
}
// generate field initialization - only if not invoking another constructor call of the same class
if (needfieldinitializations) {
if (!preinitsyntheticfields){
generatesyntheticfieldinitializationsifnecessary(this.scope, codestream, declaringclass);
}
// generate user field initialization
if (declaringtype.fields != null) {
for (int i = 0, max = declaringtype.fields.length; i < max; i++) {
fielddeclaration fielddecl;
if (!(fielddecl = declaringtype.fields[i]).isstatic()) {
fielddecl.generatecode(initializerscope, codestream);
}
}
}
}
// generate statements
if (this.statements != null) {
for (int i = 0, max = this.statements.length; i < max; i++) {
this.statements[i].generatecode(this.scope, codestream);
}
}
// if a problem got reported during code gen, then trigger problem method creation
if (this.ignorefurtherinvestigation) {
throw new abortmethod(this.scope.referencecompilationunit().compilationresult, null);
}
if ((this.bits & astnode.needfreereturn) != 0) {
codestream.return_();
}
// local variable attributes
codestream.exituserscope(this.scope);
codestream.recordpositionsfrom(0, this.bodyend);
try {
classfile.completecodeattribute(codeattributeoffset);
} catch(negativearraysizeexception e) {
throw new abortmethod(this.scope.referencecompilationunit().compilationresult, null);
}
attributenumber++;
if ((codestream instanceof stackmapframecodestream)
&& needfieldinitializations
&& declaringtype.fields != null) {
((stackmapframecodestream) codestream).resetsecretlocals();
}
}
classfile.completemethodinfo(methodattributeoffset, attributenumber);
}

public boolean isconstructor() {
return true;
}

public boolean isdefaultconstructor() {
return (this.bits & astnode.isdefaultconstructor) != 0;
}

public boolean isinitializationmethod() {
return true;
}

/*
* returns true if the constructor is directly involved in a cycle.
* given most constructors aren't, we only allocate the visited list
* lazily.
*/
public boolean isrecursive(arraylist visited) {
if (this.binding == null
|| this.constructorcall == null
|| this.constructorcall.binding == null
|| this.constructorcall.issuperaccess()
|| !this.constructorcall.binding.isvalidbinding()) {
return false;
}

constructordeclaration targetconstructor =
((constructordeclaration)this.scope.referencetype().declarationof(this.constructorcall.binding.original()));
if (this == targetconstructor) return true; // direct case

if (visited == null) { // lazy allocation
visited = new arraylist(1);
} else {
int index = visited.indexof(this);
if (index >= 0) return index == 0; // only blame if directly part of the cycle
}
visited.add(this);

return targetconstructor.isrecursive(visited);
}

public void parsestatements(parser parser, compilationunitdeclaration unit) {
//fill up the constructor body with its statements
if (((this.bits & astnode.isdefaultconstructor) != 0) && this.constructorcall == null){
this.constructorcall = superreference.implicitsuperconstructorcall();
this.constructorcall.sourcestart = this.sourcestart;
this.constructorcall.sourceend = this.sourceend;
return;
}
parser.parse(this, unit, false);

}

public stringbuffer printbody(int indent, stringbuffer output) {
output.append(" {"); //$non-nls-1$
if (this.constructorcall != null) {
output.append('\n');
this.constructorcall.printstatement(indent, output);
}
if (this.statements != null) {
for (int i = 0; i < this.statements.length; i++) {
output.append('\n');
this.statements[i].printstatement(indent, output);
}
}
output.append('\n');
printindent(indent == 0 ? 0 : indent - 1, output).append('}');
return output;
}

public void resolvejavadoc() {
if (this.binding == null || this.javadoc != null) {
super.resolvejavadoc();
} else if ((this.bits & astnode.isdefaultconstructor) == 0) {
if (this.binding.declaringclass != null && !this.binding.declaringclass.islocaltype()) {
// set javadoc visibility
int javadocvisibility = this.binding.modifiers & extracompilermodifiers.accvisibilitymask;
classscope classscope = this.scope.classscope();
problemreporter reporter = this.scope.problemreporter();
int severity = reporter.computeseverity(iproblem.javadocmissing);
if (severity != problemseverities.ignore) {
if (classscope != null) {
javadocvisibility = util.computeoutermostvisibility(classscope.referencetype(), javadocvisibility);
}
int javadocmodifiers = (this.binding.modifiers & ~extracompilermodifiers.accvisibilitymask) | javadocvisibility;
reporter.javadocmissing(this.sourcestart, this.sourceend, severity, javadocmodifiers);
}
}
}
}

/*
* type checking for constructor, just another method, except for special check
* for recursive constructor invocations.
*/
public void resolvestatements() {
sourcetypebinding sourcetype = this.scope.enclosingsourcetype();
if (!charoperation.equals(sourcetype.sourcename, this.selector)){
this.scope.problemreporter().missingreturntype(this);
}
if (this.typeparameters != null) {
for (int i = 0, length = this.typeparameters.length; i < length; i++) {
this.typeparameters[i].resolve(this.scope);
}
}
if (this.binding != null && !this.binding.isprivate()) {
sourcetype.tagbits |= tagbits.hasnonprivateconstructor;
}
// if null ==> an error has occurs at parsing time ....
if (this.constructorcall != null) {
if (sourcetype.id == typeids.t_javalangobject
&& this.constructorcall.accessmode != explicitconstructorcall.this) {
// cannot use super() in java.lang.object
if (this.constructorcall.accessmode == explicitconstructorcall.super) {
this.scope.problemreporter().cannotusesuperinjavalangobject(this.constructorcall);
}
this.constructorcall = null;
} else {
this.constructorcall.resolve(this.scope);
}
}
if ((this.modifiers & extracompilermodifiers.accsemicolonbody) != 0) {
this.scope.problemreporter().methodneedbody(this);
}
super.resolvestatements();
}

public void traverse(astvisitor visitor, classscope classscope) {
if (visitor.visit(this, classscope)) {
if (this.javadoc != null) {
this.javadoc.traverse(visitor, this.scope);
}
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, this.scope);
}
if (this.typeparameters != null) {
int typeparameterslength = this.typeparameters.length;
for (int i = 0; i < typeparameterslength; i++) {
this.typeparameters[i].traverse(visitor, this.scope);
}
}
if (this.arguments != null) {
int argumentlength = this.arguments.length;
for (int i = 0; i < argumentlength; i++)
this.arguments[i].traverse(visitor, this.scope);
}
if (this.thrownexceptions != null) {
int thrownexceptionslength = this.thrownexceptions.length;
for (int i = 0; i < thrownexceptionslength; i++)
this.thrownexceptions[i].traverse(visitor, this.scope);
}
if (this.constructorcall != null)
this.constructorcall.traverse(visitor, this.scope);
if (this.statements != null) {
int statementslength = this.statements.length;
for (int i = 0; i < statementslength; i++)
this.statements[i].traverse(visitor, this.scope);
}
}
visitor.endvisit(this, classscope);
}
public typeparameter[] typeparameters() {
return this.typeparameters;
}
}
