/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.util.arraylist;
import java.util.hashmap;
import java.util.map;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.classfilepool;
import org.eclipse.jdt.internal.compiler.ast.compilationunitdeclaration;
import org.eclipse.jdt.internal.compiler.ast.wildcard;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.env.*;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.ityperequestor;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;
import org.eclipse.jdt.internal.compiler.util.hashtableofpackage;
import org.eclipse.jdt.internal.compiler.util.simplelookuptable;

public class lookupenvironment implements problemreasons, typeconstants {

/**
* map from typebinding -> accessrestriction rule
*/
private map accessrestrictions;
importbinding[] defaultimports;
public packagebinding defaultpackage;
hashtableofpackage knownpackages;
private int lastcompletedunitindex = -1;
private int lastunitindex = -1;

public inameenvironment nameenvironment;
public compileroptions globaloptions;

public problemreporter problemreporter;
public classfilepool classfilepool;
// indicate in which step on the compilation we are.
// step 1 : build the reference binding
// step 2 : conect the hierarchy (connect bindings)
// step 3 : build fields and method bindings.
private int stepcompleted;
public ityperequestor typerequestor;

private arraybinding[][] uniquearraybindings;
private simplelookuptable uniqueparameterizedtypebindings;
private simplelookuptable uniquerawtypebindings;
private simplelookuptable uniquewildcardbindings;
private simplelookuptable uniqueparameterizedgenericmethodbindings;
private simplelookuptable uniquegetclassmethodbinding; // https://bugs.eclipse.org/bugs/show_bug.cgi?id=300734

public compilationunitdeclaration unitbeingcompleted = null; // only set while completing units
public object missingclassfilelocation = null; // only set when resolving certain references, to help locating problems
private compilationunitdeclaration[] units = new compilationunitdeclaration[4];
private methodverifier verifier;

public methodbinding arrayclone;

private arraylist missingtypes;
public boolean isprocessingannotations = false;

final static int build_fields_and_methods = 4;
final static int build_type_hierarchy = 1;
final static int check_and_set_imports = 2;
final static int connect_type_hierarchy = 3;

static final problempackagebinding thenotfoundpackage = new problempackagebinding(charoperation.no_char, notfound);
static final problemreferencebinding thenotfoundtype = new problemreferencebinding(charoperation.no_char_char, null, notfound);

public lookupenvironment(ityperequestor typerequestor, compileroptions globaloptions, problemreporter problemreporter, inameenvironment nameenvironment) {
this.typerequestor = typerequestor;
this.globaloptions = globaloptions;
this.problemreporter = problemreporter;
this.defaultpackage = new packagebinding(this); // assume the default package always exists
this.defaultimports = null;
this.nameenvironment = nameenvironment;
this.knownpackages = new hashtableofpackage();
this.uniquearraybindings = new arraybinding[5][];
this.uniquearraybindings[0] = new arraybinding[50]; // start off the most common 1 dimension array @@ 50
this.uniqueparameterizedtypebindings = new simplelookuptable(3);
this.uniquerawtypebindings = new simplelookuptable(3);
this.uniquewildcardbindings = new simplelookuptable(3);
this.uniqueparameterizedgenericmethodbindings = new simplelookuptable(3);
this.missingtypes = null;
this.accessrestrictions = new hashmap(3);
this.classfilepool = classfilepool.newinstance();
}

/**
* ask the name environment for a type which corresponds to the compoundname.
* answer null if the name cannot be found.
*/

public referencebinding askfortype(char[][] compoundname) {
nameenvironmentanswer answer = this.nameenvironment.findtype(compoundname);
if (answer == null) return null;

if (answer.isbinarytype()) {
// the type was found as a .class file
this.typerequestor.accept(answer.getbinarytype(), computepackagefrom(compoundname, false /* valid pkg */), answer.getaccessrestriction());
} else if (answer.iscompilationunit()) {
// the type was found as a .java file, try to build it then search the cache
this.typerequestor.accept(answer.getcompilationunit(), answer.getaccessrestriction());
} else if (answer.issourcetype()) {
// the type was found as a source model
this.typerequestor.accept(answer.getsourcetypes(), computepackagefrom(compoundname, false /* valid pkg */), answer.getaccessrestriction());
}
return getcachedtype(compoundname);
}
/* ask the oracle for a type named name in the packagebinding.
* answer null if the name cannot be found.
*/

referencebinding askfortype(packagebinding packagebinding, char[] name) {
if (packagebinding == null) {
if (this.defaultpackage == null)
return null;
packagebinding = this.defaultpackage;
}
nameenvironmentanswer answer = this.nameenvironment.findtype(name, packagebinding.compoundname);
if (answer == null)
return null;

if (answer.isbinarytype()) {
// the type was found as a .class file
this.typerequestor.accept(answer.getbinarytype(), packagebinding, answer.getaccessrestriction());
} else if (answer.iscompilationunit()) {
// the type was found as a .java file, try to build it then search the cache
this.typerequestor.accept(answer.getcompilationunit(), answer.getaccessrestriction());
} else if (answer.issourcetype()) {
// the type was found as a source model
this.typerequestor.accept(answer.getsourcetypes(), packagebinding, answer.getaccessrestriction());
}
return packagebinding.gettype0(name);
}

/* create the initial type bindings for the compilation unit.
*
* see completetypebindings() for a description of the remaining steps
*
* note: this method can be called multiple times as additional source files are needed
*/
public void buildtypebindings(compilationunitdeclaration unit, accessrestriction accessrestriction) {
compilationunitscope scope = new compilationunitscope(unit, this);
scope.buildtypebindings(accessrestriction);
int unitslength = this.units.length;
if (++this.lastunitindex >= unitslength)
system.arraycopy(this.units, 0, this.units = new compilationunitdeclaration[2 * unitslength], 0, unitslength);
this.units[this.lastunitindex] = unit;
}

/* cache the binary type since we know it is needed during this compile.
*
* answer the created binarytypebinding or null if the type is already in the cache.
*/
public binarytypebinding cachebinarytype(ibinarytype binarytype, accessrestriction accessrestriction) {
return cachebinarytype(binarytype, true, accessrestriction);
}

/* cache the binary type since we know it is needed during this compile.
*
* answer the created binarytypebinding or null if the type is already in the cache.
*/
public binarytypebinding cachebinarytype(ibinarytype binarytype, boolean needfieldsandmethods, accessrestriction accessrestriction) {
char[][] compoundname = charoperation.spliton('/', binarytype.getname());
referencebinding existingtype = getcachedtype(compoundname);

if (existingtype == null || existingtype instanceof unresolvedreferencebinding)
// only add the binary type if its not already in the cache
return createbinarytypefrom(binarytype, computepackagefrom(compoundname, false /* valid pkg */), needfieldsandmethods, accessrestriction);
return null; // the type already exists & can be retrieved from the cache
}

public void completetypebindings() {
this.stepcompleted = build_type_hierarchy;

for (int i = this.lastcompletedunitindex + 1; i <= this.lastunitindex; i++) {
(this.unitbeingcompleted = this.units[i]).scope.checkandsetimports();
}
this.stepcompleted = check_and_set_imports;

for (int i = this.lastcompletedunitindex + 1; i <= this.lastunitindex; i++) {
(this.unitbeingcompleted = this.units[i]).scope.connecttypehierarchy();
}
this.stepcompleted = connect_type_hierarchy;

for (int i = this.lastcompletedunitindex + 1; i <= this.lastunitindex; i++) {
compilationunitscope unitscope = (this.unitbeingcompleted = this.units[i]).scope;
unitscope.checkparameterizedtypes();
unitscope.buildfieldsandmethods();
this.units[i] = null; // release unnecessary reference to the parsed unit
}
this.stepcompleted = build_fields_and_methods;
this.lastcompletedunitindex = this.lastunitindex;
this.unitbeingcompleted = null;
}

/*
* 1. connect the type hierarchy for the type bindings created for parsedunits.
* 2. create the field bindings
* 3. create the method bindings
*/

/* we know each known compilationunit is free of errors at this point...
*
* each step will create additional bindings unless a problem is detected, in which
* case either the faulty import/superinterface/field/method will be skipped or a
* suitable replacement will be substituted (such as object for a missing superclass)
*/
public void completetypebindings(compilationunitdeclaration parsedunit) {
if (this.stepcompleted == build_fields_and_methods) {
// this can only happen because the original set of units are completely built and
// are now being processed, so we want to treat all the additional units as a group
// until they too are completely processed.
completetypebindings();
} else {
if (parsedunit.scope == null) return; // parsing errors were too severe

if (this.stepcompleted >= check_and_set_imports)
(this.unitbeingcompleted = parsedunit).scope.checkandsetimports();

if (this.stepcompleted >= connect_type_hierarchy)
(this.unitbeingcompleted = parsedunit).scope.connecttypehierarchy();

this.unitbeingcompleted = null;
}
}

/*
* used by other compiler tools which do not start by calling completetypebindings().
*
* 1. connect the type hierarchy for the type bindings created for parsedunits.
* 2. create the field bindings
* 3. create the method bindings
*/

/*
* each step will create additional bindings unless a problem is detected, in which
* case either the faulty import/superinterface/field/method will be skipped or a
* suitable replacement will be substituted (such as object for a missing superclass)
*/
public void completetypebindings(compilationunitdeclaration parsedunit, boolean buildfieldsandmethods) {
if (parsedunit.scope == null) return; // parsing errors were too severe

(this.unitbeingcompleted = parsedunit).scope.checkandsetimports();
parsedunit.scope.connecttypehierarchy();
parsedunit.scope.checkparameterizedtypes();
if (buildfieldsandmethods)
parsedunit.scope.buildfieldsandmethods();
this.unitbeingcompleted = null;
}

/*
* used by other compiler tools which do not start by calling completetypebindings()
* and have more than 1 unit to complete.
*
* 1. connect the type hierarchy for the type bindings created for parsedunits.
* 2. create the field bindings
* 3. create the method bindings
*/
public void completetypebindings(compilationunitdeclaration[] parsedunits, boolean[] buildfieldsandmethods, int unitcount) {
for (int i = 0; i < unitcount; i++) {
compilationunitdeclaration parsedunit = parsedunits[i];
if (parsedunit.scope != null)
(this.unitbeingcompleted = parsedunit).scope.checkandsetimports();
}

for (int i = 0; i < unitcount; i++) {
compilationunitdeclaration parsedunit = parsedunits[i];
if (parsedunit.scope != null)
(this.unitbeingcompleted = parsedunit).scope.connecttypehierarchy();
}

for (int i = 0; i < unitcount; i++) {
compilationunitdeclaration parsedunit = parsedunits[i];
if (parsedunit.scope != null) {
(this.unitbeingcompleted = parsedunit).scope.checkparameterizedtypes();
if (buildfieldsandmethods[i])
parsedunit.scope.buildfieldsandmethods();
}
}

this.unitbeingcompleted = null;
}
public methodbinding computearrayclone(methodbinding objectclone) {
if (this.arrayclone == null) {
this.arrayclone = new methodbinding(
(objectclone.modifiers & ~classfileconstants.accprotected) | classfileconstants.accpublic,
typeconstants.clone,
objectclone.returntype,
binding.no_parameters,
binding.no_exceptions, // no exception for array specific method
(referencebinding)objectclone.returntype);
}
return this.arrayclone;

}
public typebinding computeboxingtype(typebinding type) {
typebinding boxedtype;
switch (type.id) {
case typeids.t_javalangboolean :
return typebinding.boolean;
case typeids.t_javalangbyte :
return typebinding.byte;
case typeids.t_javalangcharacter :
return typebinding.char;
case typeids.t_javalangshort :
return typebinding.short;
case typeids.t_javalangdouble :
return typebinding.double;
case typeids.t_javalangfloat :
return typebinding.float;
case typeids.t_javalanginteger :
return typebinding.int;
case typeids.t_javalanglong :
return typebinding.long;

case typeids.t_int :
boxedtype = gettype(java_lang_integer);
if (boxedtype != null) return boxedtype;
return new problemreferencebinding(java_lang_integer, null, notfound);
case typeids.t_byte :
boxedtype = gettype(java_lang_byte);
if (boxedtype != null) return boxedtype;
return new problemreferencebinding(java_lang_byte, null, notfound);
case typeids.t_short :
boxedtype = gettype(java_lang_short);
if (boxedtype != null) return boxedtype;
return new problemreferencebinding(java_lang_short, null, notfound);
case typeids.t_char :
boxedtype = gettype(java_lang_character);
if (boxedtype != null) return boxedtype;
return new problemreferencebinding(java_lang_character, null, notfound);
case typeids.t_long :
boxedtype = gettype(java_lang_long);
if (boxedtype != null) return boxedtype;
return new problemreferencebinding(java_lang_long, null, notfound);
case typeids.t_float :
boxedtype = gettype(java_lang_float);
if (boxedtype != null) return boxedtype;
return new problemreferencebinding(java_lang_float, null, notfound);
case typeids.t_double :
boxedtype = gettype(java_lang_double);
if (boxedtype != null) return boxedtype;
return new problemreferencebinding(java_lang_double, null, notfound);
case typeids.t_boolean :
boxedtype = gettype(java_lang_boolean);
if (boxedtype != null) return boxedtype;
return new problemreferencebinding(java_lang_boolean, null, notfound);
//		case typeids.t_int :
//			return getresolvedtype(java_lang_integer, null);
//		case typeids.t_byte :
//			return getresolvedtype(java_lang_byte, null);
//		case typeids.t_short :
//			return getresolvedtype(java_lang_short, null);
//		case typeids.t_char :
//			return getresolvedtype(java_lang_character, null);
//		case typeids.t_long :
//			return getresolvedtype(java_lang_long, null);
//		case typeids.t_float :
//			return getresolvedtype(java_lang_float, null);
//		case typeids.t_double :
//			return getresolvedtype(java_lang_double, null);
//		case typeids.t_boolean :
//			return getresolvedtype(java_lang_boolean, null);
}
// allow indirect unboxing conversion for wildcards and type parameters
switch (type.kind()) {
case binding.wildcard_type :
case binding.intersection_type :
case binding.type_parameter :
switch (type.erasure().id) {
case typeids.t_javalangboolean :
return typebinding.boolean;
case typeids.t_javalangbyte :
return typebinding.byte;
case typeids.t_javalangcharacter :
return typebinding.char;
case typeids.t_javalangshort :
return typebinding.short;
case typeids.t_javalangdouble :
return typebinding.double;
case typeids.t_javalangfloat :
return typebinding.float;
case typeids.t_javalanginteger :
return typebinding.int;
case typeids.t_javalanglong :
return typebinding.long;
}
}
return type;
}

private packagebinding computepackagefrom(char[][] constantpoolname, boolean ismissing) {
if (constantpoolname.length == 1)
return this.defaultpackage;

packagebinding packagebinding = getpackage0(constantpoolname[0]);
if (packagebinding == null || packagebinding == thenotfoundpackage) {
packagebinding = new packagebinding(constantpoolname[0], this);
if (ismissing) packagebinding.tagbits |= tagbits.hasmissingtype;
this.knownpackages.put(constantpoolname[0], packagebinding);
}

for (int i = 1, length = constantpoolname.length - 1; i < length; i++) {
packagebinding parent = packagebinding;
if ((packagebinding = parent.getpackage0(constantpoolname[i])) == null || packagebinding == thenotfoundpackage) {
packagebinding = new packagebinding(charoperation.subarray(constantpoolname, 0, i + 1), parent, this);
if (ismissing) {
packagebinding.tagbits |= tagbits.hasmissingtype;
}
parent.addpackage(packagebinding);
}
}
return packagebinding;
}

/**
* convert a given source type into a parameterized form if generic.
* generic x<e> --> param x<e>
*/
public referencebinding converttoparameterizedtype(referencebinding originaltype) {
if (originaltype != null) {
boolean isgeneric = originaltype.isgenerictype();
referencebinding originalenclosingtype = originaltype.enclosingtype();
referencebinding convertedenclosingtype = originalenclosingtype;
boolean needtoconvert = isgeneric;
if (originalenclosingtype != null) {
convertedenclosingtype = originaltype.isstatic()
? (referencebinding) converttorawtype(originalenclosingtype, false /*do not force conversion of enclosing types*/)
: converttoparameterizedtype(originalenclosingtype);
needtoconvert |= originalenclosingtype != convertedenclosingtype;
}
if (needtoconvert) {
return createparameterizedtype(originaltype, isgeneric ? originaltype.typevariables() : null, convertedenclosingtype);
}
}
return originaltype;
}

/**
* returns the given binding's raw type binding.
* @@param type the typebinding to raw convert
* @@param forcerawenclosingtype forces recursive raw conversion of enclosing types (used in javadoc references only)
* @@return typebinding the raw converted typebinding
*/
public typebinding converttorawtype(typebinding type, boolean forcerawenclosingtype) {
int dimension;
typebinding originaltype;
switch(type.kind()) {
case binding.base_type :
case binding.type_parameter:
case binding.wildcard_type:
case binding.intersection_type:
case binding.raw_type:
return type;
case binding.array_type:
dimension = type.dimensions();
originaltype = type.leafcomponenttype();
break;
default:
if (type.id == typeids.t_javalangobject)
return type; // object is not generic
dimension = 0;
originaltype = type;
}
boolean needtoconvert;
switch (originaltype.kind()) {
case binding.base_type :
return type;
case binding.generic_type :
needtoconvert = true;
break;
case binding.parameterized_type :
parameterizedtypebinding paramtype = (parameterizedtypebinding) originaltype;
needtoconvert = paramtype.generictype().isgenerictype(); // only recursive call to enclosing type can find parameterizedtype with arguments
break;
default :
needtoconvert = false;
break;
}
referencebinding originalenclosing = originaltype.enclosingtype();
typebinding convertedtype;
if (originalenclosing == null) {
convertedtype = needtoconvert ? createrawtype((referencebinding)originaltype.erasure(), null) : originaltype;
} else {
referencebinding convertedenclosing;
if (originalenclosing.kind() == binding.raw_type) {
needtoconvert |= !((referencebinding)originaltype).isstatic();
convertedenclosing = originalenclosing;
} else if (forcerawenclosingtype && !needtoconvert/*stop recursion when conversion occurs*/) {
convertedenclosing = (referencebinding) converttorawtype(originalenclosing, forcerawenclosingtype);
needtoconvert = originalenclosing != convertedenclosing; // only convert generic or parameterized types
} else if (needtoconvert || ((referencebinding)originaltype).isstatic()) {
convertedenclosing = (referencebinding) converttorawtype(originalenclosing, false);
} else {
convertedenclosing = converttoparameterizedtype(originalenclosing);
}
if (needtoconvert) {
convertedtype = createrawtype((referencebinding) originaltype.erasure(), convertedenclosing);
} else if (originalenclosing != convertedenclosing) {
convertedtype = createparameterizedtype((referencebinding) originaltype.erasure(), null, convertedenclosing);
} else {
convertedtype = originaltype;
}
}
if (originaltype != convertedtype) {
return dimension > 0 ? (typebinding)createarraytype(convertedtype, dimension) : convertedtype;
}
return type;
}

/**
* convert an array of types in raw forms.
* only allocate an array if anything is different.
*/
public referencebinding[] converttorawtypes(referencebinding[] originaltypes, boolean forceerasure, boolean forcerawenclosingtype) {
if (originaltypes == null) return null;
referencebinding[] convertedtypes = originaltypes;
for (int i = 0, length = originaltypes.length; i < length; i++) {
referencebinding originaltype = originaltypes[i];
referencebinding convertedtype = (referencebinding) converttorawtype(forceerasure ? originaltype.erasure() : originaltype, forcerawenclosingtype);
if (convertedtype != originaltype) {
if (convertedtypes == originaltypes) {
system.arraycopy(originaltypes, 0, convertedtypes = new referencebinding[length], 0, i);
}
convertedtypes[i] = convertedtype;
} else if (convertedtypes != originaltypes) {
convertedtypes[i] = originaltype;
}
}
return convertedtypes;
}

// variation for unresolved types in binaries (consider generic type as raw)
public typebinding convertunresolvedbinarytorawtype(typebinding type) {
int dimension;
typebinding originaltype;
switch(type.kind()) {
case binding.base_type :
case binding.type_parameter:
case binding.wildcard_type:
case binding.intersection_type:
case binding.raw_type:
return type;
case binding.array_type:
dimension = type.dimensions();
originaltype = type.leafcomponenttype();
break;
default:
if (type.id == typeids.t_javalangobject)
return type; // object is not generic
dimension = 0;
originaltype = type;
}
boolean needtoconvert;
switch (originaltype.kind()) {
case binding.base_type :
return type;
case binding.generic_type :
needtoconvert = true;
break;
case binding.parameterized_type :
parameterizedtypebinding paramtype = (parameterizedtypebinding) originaltype;
needtoconvert = paramtype.generictype().isgenerictype(); // only recursive call to enclosing type can find parameterizedtype with arguments
break;
default :
needtoconvert = false;
break;
}
referencebinding originalenclosing = originaltype.enclosingtype();
typebinding convertedtype;
if (originalenclosing == null) {
convertedtype = needtoconvert ? createrawtype((referencebinding)originaltype.erasure(), null) : originaltype;
} else {
referencebinding convertedenclosing = (referencebinding) convertunresolvedbinarytorawtype(originalenclosing);
if (convertedenclosing != originalenclosing) {
needtoconvert |= !((referencebinding)originaltype).isstatic();
}
if (needtoconvert) {
convertedtype = createrawtype((referencebinding) originaltype.erasure(), convertedenclosing);
} else if (originalenclosing != convertedenclosing) {
convertedtype = createparameterizedtype((referencebinding) originaltype.erasure(), null, convertedenclosing);
} else {
convertedtype = originaltype;
}
}
if (originaltype != convertedtype) {
return dimension > 0 ? (typebinding)createarraytype(convertedtype, dimension) : convertedtype;
}
return type;
}
/*
*  used to guarantee annotation identity.
*/
public annotationbinding createannotation(referencebinding annotationtype, elementvaluepair[] pairs) {
if (pairs.length != 0) {
annotationbinding.setmethodbindings(annotationtype, pairs);
}
return new annotationbinding(annotationtype, pairs);
}

/*
*  used to guarantee array type identity.
*/
public arraybinding createarraytype(typebinding leafcomponenttype, int dimensioncount) {
if (leafcomponenttype instanceof localtypebinding) // cache local type arrays with the local type itself
return ((localtypebinding) leafcomponenttype).createarraytype(dimensioncount, this);

// find the array binding cache for this dimension
int dimindex = dimensioncount - 1;
int length = this.uniquearraybindings.length;
arraybinding[] arraybindings;
if (dimindex < length) {
if ((arraybindings = this.uniquearraybindings[dimindex]) == null)
this.uniquearraybindings[dimindex] = arraybindings = new arraybinding[10];
} else {
system.arraycopy(
this.uniquearraybindings, 0,
this.uniquearraybindings = new arraybinding[dimensioncount][], 0,
length);
this.uniquearraybindings[dimindex] = arraybindings = new arraybinding[10];
}

// find the cached array binding for this leaf component type (if any)
int index = -1;
length = arraybindings.length;
while (++index < length) {
arraybinding currentbinding = arraybindings[index];
if (currentbinding == null) // no matching array, but space left
return arraybindings[index] = new arraybinding(leafcomponenttype, dimensioncount, this);
if (currentbinding.leafcomponenttype == leafcomponenttype)
return currentbinding;
}

// no matching array, no space left
system.arraycopy(
arraybindings, 0,
(arraybindings = new arraybinding[length * 2]), 0,
length);
this.uniquearraybindings[dimindex] = arraybindings;
return arraybindings[length] = new arraybinding(leafcomponenttype, dimensioncount, this);
}
public binarytypebinding createbinarytypefrom(ibinarytype binarytype, packagebinding packagebinding, accessrestriction accessrestriction) {
return createbinarytypefrom(binarytype, packagebinding, true, accessrestriction);
}

public binarytypebinding createbinarytypefrom(ibinarytype binarytype, packagebinding packagebinding, boolean needfieldsandmethods, accessrestriction accessrestriction) {
binarytypebinding binarybinding = new binarytypebinding(packagebinding, binarytype, this);

// resolve any array bindings which reference the unresolvedtype
referencebinding cachedtype = packagebinding.gettype0(binarybinding.compoundname[binarybinding.compoundname.length - 1]);
if (cachedtype != null) { // update reference to unresolved binding after having read classfile (knows whether generic for raw conversion)
if (cachedtype instanceof unresolvedreferencebinding) {
((unresolvedreferencebinding) cachedtype).setresolvedtype(binarybinding, this);
} else {
if (cachedtype.isbinarybinding()) // sanity check... at this point the cache should only contain unresolved types
return (binarytypebinding) cachedtype;
// it is possible with a large number of source files (exceeding abstractimagebuilder.max_at_once) that a member type can be in the cache as an unresolvedtype,
// but because its enclosingtype is resolved while its created (call to binarytypebinding constructor), its replaced with a source type
return null;
}
}
packagebinding.addtype(binarybinding);
setaccessrestriction(binarybinding, accessrestriction);
binarybinding.cachepartsfrom(binarytype, needfieldsandmethods);
return binarybinding;
}

/*
* used to create types denoting missing types.
* if package is given, then reuse the package; if not then infer a package from compound name.
* if the package is existing, then install the missing type in type cache
*/
public missingtypebinding createmissingtype(packagebinding packagebinding, char[][] compoundname) {
// create a proxy for the missing binarytype
if (packagebinding == null) {
packagebinding = computepackagefrom(compoundname, true /* missing */);
if (packagebinding == thenotfoundpackage) packagebinding = this.defaultpackage;
}
missingtypebinding missingtype = new missingtypebinding(packagebinding, compoundname, this);
if (missingtype.id != typeids.t_javalangobject) {
// make object be its superclass - it could in turn be missing as well
referencebinding objecttype = gettype(typeconstants.java_lang_object);
if (objecttype == null) {
objecttype = createmissingtype(null, typeconstants.java_lang_object);	// create a proxy for the missing object type
}
missingtype.setmissingsuperclass(objecttype);
}
packagebinding.addtype(missingtype);
if (this.missingtypes == null)
this.missingtypes = new arraylist(3);
this.missingtypes.add(missingtype);
return missingtype;
}

/*
* 1. connect the type hierarchy for the type bindings created for parsedunits.
* 2. create the field bindings
* 3. create the method bindings
*/
public packagebinding createpackage(char[][] compoundname) {
packagebinding packagebinding = getpackage0(compoundname[0]);
if (packagebinding == null || packagebinding == thenotfoundpackage) {
packagebinding = new packagebinding(compoundname[0], this);
this.knownpackages.put(compoundname[0], packagebinding);
}

for (int i = 1, length = compoundname.length; i < length; i++) {
// check to see if it collides with a known type...
// this case can only happen if the package does not exist as a directory in the file system
// otherwise when the source type was defined, the correct error would have been reported
// unless its an unresolved type which is referenced from an inconsistent class file
// note: empty packages are not packages according to changes in jls v2, 7.4.3
// so not all types cause collision errors when they're created even though the package did exist
referencebinding type = packagebinding.gettype0(compoundname[i]);
if (type != null && type != thenotfoundtype && !(type instanceof unresolvedreferencebinding))
return null;

packagebinding parent = packagebinding;
if ((packagebinding = parent.getpackage0(compoundname[i])) == null || packagebinding == thenotfoundpackage) {
// if the package is unknown, check to see if a type exists which would collide with the new package
// catches the case of a package statement of: package java.lang.object;
// since the package can be added after a set of source files have already been compiled,
// we need to check whenever a package is created
if (this.nameenvironment.findtype(compoundname[i], parent.compoundname) != null)
return null;

packagebinding = new packagebinding(charoperation.subarray(compoundname, 0, i + 1), parent, this);
parent.addpackage(packagebinding);
}
}
return packagebinding;
}

public parameterizedgenericmethodbinding createparameterizedgenericmethod(methodbinding genericmethod, rawtypebinding rawtype) {
// cached info is array of already created parameterized types for this type
parameterizedgenericmethodbinding[] cachedinfo = (parameterizedgenericmethodbinding[])this.uniqueparameterizedgenericmethodbindings.get(genericmethod);
boolean needtogrow = false;
int index = 0;
if (cachedinfo != null){
nextcachedmethod :
// iterate existing parameterized for reusing one with same type arguments if any
for (int max = cachedinfo.length; index < max; index++){
parameterizedgenericmethodbinding cachedmethod = cachedinfo[index];
if (cachedmethod == null) break nextcachedmethod;
if (!cachedmethod.israw) continue nextcachedmethod;
if (cachedmethod.declaringclass != (rawtype == null ? genericmethod.declaringclass : rawtype)) continue nextcachedmethod;
return cachedmethod;
}
needtogrow = true;
} else {
cachedinfo = new parameterizedgenericmethodbinding[5];
this.uniqueparameterizedgenericmethodbindings.put(genericmethod, cachedinfo);
}
// grow cache ?
int length = cachedinfo.length;
if (needtogrow && index == length){
system.arraycopy(cachedinfo, 0, cachedinfo = new parameterizedgenericmethodbinding[length*2], 0, length);
this.uniqueparameterizedgenericmethodbindings.put(genericmethod, cachedinfo);
}
// add new binding
parameterizedgenericmethodbinding parameterizedgenericmethod = new parameterizedgenericmethodbinding(genericmethod, rawtype, this);
cachedinfo[index] = parameterizedgenericmethod;
return parameterizedgenericmethod;
}

public parameterizedgenericmethodbinding createparameterizedgenericmethod(methodbinding genericmethod, typebinding[] typearguments) {
// cached info is array of already created parameterized types for this type
parameterizedgenericmethodbinding[] cachedinfo = (parameterizedgenericmethodbinding[])this.uniqueparameterizedgenericmethodbindings.get(genericmethod);
int arglength = typearguments == null ? 0: typearguments.length;
boolean needtogrow = false;
int index = 0;
if (cachedinfo != null){
nextcachedmethod :
// iterate existing parameterized for reusing one with same type arguments if any
for (int max = cachedinfo.length; index < max; index++){
parameterizedgenericmethodbinding cachedmethod = cachedinfo[index];
if (cachedmethod == null) break nextcachedmethod;
if (cachedmethod.israw) continue nextcachedmethod;
typebinding[] cachedarguments = cachedmethod.typearguments;
int cachedarglength = cachedarguments == null ? 0 : cachedarguments.length;
if (arglength != cachedarglength) continue nextcachedmethod;
for (int j = 0; j < cachedarglength; j++){
if (typearguments[j] != cachedarguments[j]) continue nextcachedmethod;
}
// all arguments match, reuse current
return cachedmethod;
}
needtogrow = true;
} else {
cachedinfo = new parameterizedgenericmethodbinding[5];
this.uniqueparameterizedgenericmethodbindings.put(genericmethod, cachedinfo);
}
// grow cache ?
int length = cachedinfo.length;
if (needtogrow && index == length){
system.arraycopy(cachedinfo, 0, cachedinfo = new parameterizedgenericmethodbinding[length*2], 0, length);
this.uniqueparameterizedgenericmethodbindings.put(genericmethod, cachedinfo);
}
// add new binding
parameterizedgenericmethodbinding parameterizedgenericmethod = new parameterizedgenericmethodbinding(genericmethod, typearguments, this);
cachedinfo[index] = parameterizedgenericmethod;
return parameterizedgenericmethod;
}

public parameterizedmethodbinding creategetclassmethod(typebinding receivertype, methodbinding originalmethod, scope scope) {
// see if we have already cached this method for the given receiver type.
parameterizedmethodbinding retval = null;
if (this.uniquegetclassmethodbinding == null) {
this.uniquegetclassmethodbinding = new simplelookuptable(3);
} else {
retval = (parameterizedmethodbinding)this.uniquegetclassmethodbinding.get(receivertype);
}
if (retval == null) {
retval = parameterizedmethodbinding.instantiategetclass(receivertype, originalmethod, scope);
this.uniquegetclassmethodbinding.put(receivertype, retval);
}
return retval;
}

public parameterizedtypebinding createparameterizedtype(referencebinding generictype, typebinding[] typearguments, referencebinding enclosingtype) {
// cached info is array of already created parameterized types for this type
parameterizedtypebinding[] cachedinfo = (parameterizedtypebinding[])this.uniqueparameterizedtypebindings.get(generictype);
int arglength = typearguments == null ? 0: typearguments.length;
boolean needtogrow = false;
int index = 0;
if (cachedinfo != null){
nextcachedtype :
// iterate existing parameterized for reusing one with same type arguments if any
for (int max = cachedinfo.length; index < max; index++){
parameterizedtypebinding cachedtype = cachedinfo[index];
if (cachedtype == null) break nextcachedtype;
if (cachedtype.actualtype() != generictype) continue nextcachedtype; // remain of unresolved type
if (cachedtype.enclosingtype() != enclosingtype) continue nextcachedtype;
typebinding[] cachedarguments = cachedtype.arguments;
int cachedarglength = cachedarguments == null ? 0 : cachedarguments.length;
if (arglength != cachedarglength) continue nextcachedtype; // would be an error situation (from unresolved binaries)
for (int j = 0; j < cachedarglength; j++){
if (typearguments[j] != cachedarguments[j]) continue nextcachedtype;
}
// all arguments match, reuse current
return cachedtype;
}
needtogrow = true;
} else {
cachedinfo = new parameterizedtypebinding[5];
this.uniqueparameterizedtypebindings.put(generictype, cachedinfo);
}
// grow cache ?
int length = cachedinfo.length;
if (needtogrow && index == length){
system.arraycopy(cachedinfo, 0, cachedinfo = new parameterizedtypebinding[length*2], 0, length);
this.uniqueparameterizedtypebindings.put(generictype, cachedinfo);
}
// add new binding
parameterizedtypebinding parameterizedtype = new parameterizedtypebinding(generictype,typearguments, enclosingtype, this);
cachedinfo[index] = parameterizedtype;
return parameterizedtype;
}

public rawtypebinding createrawtype(referencebinding generictype, referencebinding enclosingtype) {
// cached info is array of already created raw types for this type
rawtypebinding[] cachedinfo = (rawtypebinding[])this.uniquerawtypebindings.get(generictype);
boolean needtogrow = false;
int index = 0;
if (cachedinfo != null){
nextcachedtype :
// iterate existing parameterized for reusing one with same type arguments if any
for (int max = cachedinfo.length; index < max; index++){
rawtypebinding cachedtype = cachedinfo[index];
if (cachedtype == null) break nextcachedtype;
if (cachedtype.actualtype() != generictype) continue nextcachedtype; // remain of unresolved type
if (cachedtype.enclosingtype() != enclosingtype) continue nextcachedtype;
// all enclosing type match, reuse current
return cachedtype;
}
needtogrow = true;
} else {
cachedinfo = new rawtypebinding[1];
this.uniquerawtypebindings.put(generictype, cachedinfo);
}
// grow cache ?
int length = cachedinfo.length;
if (needtogrow && index == length){
system.arraycopy(cachedinfo, 0, cachedinfo = new rawtypebinding[length*2], 0, length);
this.uniquerawtypebindings.put(generictype, cachedinfo);
}
// add new binding
rawtypebinding rawtype = new rawtypebinding(generictype, enclosingtype, this);
cachedinfo[index] = rawtype;
return rawtype;

}

public wildcardbinding createwildcard(referencebinding generictype, int rank, typebinding bound, typebinding[] otherbounds, int boundkind) {
// cached info is array of already created wildcard  types for this type
if (generictype == null) // pseudo wildcard denoting composite bounds for lub computation
generictype = referencebinding.lub_generic;
wildcardbinding[] cachedinfo = (wildcardbinding[])this.uniquewildcardbindings.get(generictype);
boolean needtogrow = false;
int index = 0;
if (cachedinfo != null){
nextcachedtype :
// iterate existing wildcards for reusing one with same information if any
for (int max = cachedinfo.length; index < max; index++){
wildcardbinding cachedtype = cachedinfo[index];
if (cachedtype == null) break nextcachedtype;
if (cachedtype.generictype != generictype) continue nextcachedtype; // remain of unresolved type
if (cachedtype.rank != rank) continue nextcachedtype;
if (cachedtype.boundkind != boundkind) continue nextcachedtype;
if (cachedtype.bound != bound) continue nextcachedtype;
if (cachedtype.otherbounds != otherbounds) {
int cachedlength = cachedtype.otherbounds == null ? 0 : cachedtype.otherbounds.length;
int length = otherbounds == null ? 0 : otherbounds.length;
if (cachedlength != length) continue nextcachedtype;
for (int j = 0; j < length; j++) {
if (cachedtype.otherbounds[j] != otherbounds[j]) continue nextcachedtype;
}
}
// all match, reuse current
return cachedtype;
}
needtogrow = true;
} else {
cachedinfo = new wildcardbinding[10];
this.uniquewildcardbindings.put(generictype, cachedinfo);
}
// grow cache ?
int length = cachedinfo.length;
if (needtogrow && index == length){
system.arraycopy(cachedinfo, 0, cachedinfo = new wildcardbinding[length*2], 0, length);
this.uniquewildcardbindings.put(generictype, cachedinfo);
}
// add new binding
wildcardbinding wildcard = new wildcardbinding(generictype, rank, bound, otherbounds, boundkind, this);
cachedinfo[index] = wildcard;
return wildcard;
}

/**
* returns the access restriction associated to a given type, or null if none
*/
public accessrestriction getaccessrestriction(typebinding type) {
return (accessrestriction) this.accessrestrictions.get(type);
}

/**
*  answer the type for the compoundname if it exists in the cache.
* answer thenotfoundtype if it could not be resolved the first time
* it was looked up, otherwise answer null.
*
* note: do not use for nested types... the answer is not the same for a.b.c or a.b.c.d.e
* assuming c is a type in both cases. in the a.b.c.d.e case, null is the answer.
*/
public referencebinding getcachedtype(char[][] compoundname) {
if (compoundname.length == 1) {
if (this.defaultpackage == null)
return null;
return this.defaultpackage.gettype0(compoundname[0]);
}
packagebinding packagebinding = getpackage0(compoundname[0]);
if (packagebinding == null || packagebinding == thenotfoundpackage)
return null;

for (int i = 1, packagelength = compoundname.length - 1; i < packagelength; i++)
if ((packagebinding = packagebinding.getpackage0(compoundname[i])) == null || packagebinding == thenotfoundpackage)
return null;
return packagebinding.gettype0(compoundname[compoundname.length - 1]);
}

/* answer the top level package named name if it exists in the cache.
* answer thenotfoundpackage if it could not be resolved the first time
* it was looked up, otherwise answer null.
*
* note: senders must convert thenotfoundpackage into a real problem
* package if its to returned.
*/
packagebinding getpackage0(char[] name) {
return this.knownpackages.get(name);
}

/* answer the type corresponding to the compoundname.
* ask the name environment for the type if its not in the cache.
* fail with a classpath error if the type cannot be found.
*/
public referencebinding getresolvedtype(char[][] compoundname, scope scope) {
referencebinding type = gettype(compoundname);
if (type != null) return type;

// create a proxy for the missing binarytype
// report the missing class file first
this.problemreporter.isclasspathcorrect(
compoundname,
scope == null ? this.unitbeingcompleted : scope.referencecompilationunit(),
this.missingclassfilelocation);
return createmissingtype(null, compoundname);
}

/* answer the top level package named name.
* ask the oracle for the package if its not in the cache.
* answer null if the package cannot be found.
*/
packagebinding gettoplevelpackage(char[] name) {
packagebinding packagebinding = getpackage0(name);
if (packagebinding != null) {
if (packagebinding == thenotfoundpackage)
return null;
return packagebinding;
}

if (this.nameenvironment.ispackage(null, name)) {
this.knownpackages.put(name, packagebinding = new packagebinding(name, this));
return packagebinding;
}

this.knownpackages.put(name, thenotfoundpackage); // saves asking the oracle next time
return null;
}

/* answer the type corresponding to the compoundname.
* ask the name environment for the type if its not in the cache.
* answer null if the type cannot be found.
*/
public referencebinding gettype(char[][] compoundname) {
referencebinding referencebinding;

if (compoundname.length == 1) {
if (this.defaultpackage == null)
return null;

if ((referencebinding = this.defaultpackage.gettype0(compoundname[0])) == null) {
packagebinding packagebinding = getpackage0(compoundname[0]);
if (packagebinding != null && packagebinding != thenotfoundpackage)
return null; // collides with a known package... should not call this method in such a case
referencebinding = askfortype(this.defaultpackage, compoundname[0]);
}
} else {
packagebinding packagebinding = getpackage0(compoundname[0]);
if (packagebinding == thenotfoundpackage)
return null;

if (packagebinding != null) {
for (int i = 1, packagelength = compoundname.length - 1; i < packagelength; i++) {
if ((packagebinding = packagebinding.getpackage0(compoundname[i])) == null)
break;
if (packagebinding == thenotfoundpackage)
return null;
}
}

if (packagebinding == null)
referencebinding = askfortype(compoundname);
else if ((referencebinding = packagebinding.gettype0(compoundname[compoundname.length - 1])) == null)
referencebinding = askfortype(packagebinding, compoundname[compoundname.length - 1]);
}

if (referencebinding == null || referencebinding == thenotfoundtype)
return null;
referencebinding = (referencebinding) binarytypebinding.resolvetype(referencebinding, this, false /* no raw conversion for now */);

// compoundname refers to a nested type incorrectly (for example, package1.a$b)
if (referencebinding.isnestedtype())
return new problemreferencebinding(compoundname, referencebinding, internalnameprovided);
return referencebinding;
}

private typebinding[] gettypeargumentsfromsignature(signaturewrapper wrapper, typevariablebinding[] staticvariables, referencebinding enclosingtype, referencebinding generictype, char[][][] missingtypenames) {
java.util.arraylist args = new java.util.arraylist(2);
int rank = 0;
do {
args.add(gettypefromvarianttypesignature(wrapper, staticvariables, enclosingtype, generictype, rank++, missingtypenames));
} while (wrapper.signature[wrapper.start] != '>');
wrapper.start++; // skip '>'
typebinding[] typearguments = new typebinding[args.size()];
args.toarray(typearguments);
return typearguments;
}

/* answer the type corresponding to the compound name.
* does not ask the oracle for the type if its not found in the cache... instead an
* unresolved type is returned which must be resolved before used.
*
* note: does not answer base types nor array types!
*/
private referencebinding gettypefromcompoundname(char[][] compoundname, boolean isparameterized, boolean wasmissingtype) {
referencebinding binding = getcachedtype(compoundname);
if (binding == null) {
packagebinding packagebinding = computepackagefrom(compoundname, false /* valid pkg */);
binding = new unresolvedreferencebinding(compoundname, packagebinding);
if (wasmissingtype) {
binding.tagbits |= tagbits.hasmissingtype; // record it was bound to a missing type
}
packagebinding.addtype(binding);
} else if (binding == thenotfoundtype) {
// report the missing class file first
this.problemreporter.isclasspathcorrect(compoundname, this.unitbeingcompleted, this.missingclassfilelocation);
// create a proxy for the missing binarytype
binding = createmissingtype(null, compoundname);
} else if (!isparameterized) {
// check raw type, only for resolved types
binding = (referencebinding) convertunresolvedbinarytorawtype(binding);
}
return binding;
}

/* answer the type corresponding to the name from the binary file.
* does not ask the oracle for the type if its not found in the cache... instead an
* unresolved type is returned which must be resolved before used.
*
* note: does not answer base types nor array types!
*/
referencebinding gettypefromconstantpoolname(char[] signature, int start, int end, boolean isparameterized, char[][][] missingtypenames) {
if (end == -1)
end = signature.length;
char[][] compoundname = charoperation.spliton('/', signature, start, end);
boolean wasmissingtype = false;
if (missingtypenames != null) {
for (int i = 0, max = missingtypenames.length; i < max; i++) {
if (charoperation.equals(compoundname, missingtypenames[i])) {
wasmissingtype = true;
break;
}
}
}
return gettypefromcompoundname(compoundname, isparameterized, wasmissingtype);
}

/* answer the type corresponding to the signature from the binary file.
* does not ask the oracle for the type if its not found in the cache... instead an
* unresolved type is returned which must be resolved before used.
*
* note: does answer base types & array types.
*/
typebinding gettypefromsignature(char[] signature, int start, int end, boolean isparameterized, typebinding enclosingtype, char[][][] missingtypenames) {
int dimension = 0;
while (signature[start] == '[') {
start++;
dimension++;
}
if (end == -1)
end = signature.length - 1;

// just switch on signature[start] - the l case is the else
typebinding binding = null;
if (start == end) {
switch (signature[start]) {
case 'i' :
binding = typebinding.int;
break;
case 'z' :
binding = typebinding.boolean;
break;
case 'v' :
binding = typebinding.void;
break;
case 'c' :
binding = typebinding.char;
break;
case 'd' :
binding = typebinding.double;
break;
case 'b' :
binding = typebinding.byte;
break;
case 'f' :
binding = typebinding.float;
break;
case 'j' :
binding = typebinding.long;
break;
case 's' :
binding = typebinding.short;
break;
default :
this.problemreporter.corruptedsignature(enclosingtype, signature, start);
// will never reach here, since error will cause abort
}
} else {
binding = gettypefromconstantpoolname(signature, start + 1, end, isparameterized, missingtypenames); // skip leading 'l' or 't'
}

if (dimension == 0)
return binding;
return createarraytype(binding, dimension);
}

public typebinding gettypefromtypesignature(signaturewrapper wrapper, typevariablebinding[] staticvariables, referencebinding enclosingtype, char[][][] missingtypenames) {
// typevariablesignature = 't' identifier ';'
// arraytypesignature = '[' typesignature
// classtypesignature = 'l' identifier typeargs(optional) ';'
//   or classtypesignature '.' 'l' identifier typeargs(optional) ';'
// typeargs = '<' varianttypesignature varianttypesignatures '>'
int dimension = 0;
while (wrapper.signature[wrapper.start] == '[') {
wrapper.start++;
dimension++;
}
if (wrapper.signature[wrapper.start] == 't') {
int varstart = wrapper.start + 1;
int varend = wrapper.computeend();
for (int i = staticvariables.length; --i >= 0;)
if (charoperation.equals(staticvariables[i].sourcename, wrapper.signature, varstart, varend))
return dimension == 0 ? (typebinding) staticvariables[i] : createarraytype(staticvariables[i], dimension);
referencebinding initialtype = enclosingtype;
do {
typevariablebinding[] enclosingtypevariables;
if (enclosingtype instanceof binarytypebinding) { // compiler normal case, no eager resolution of binary variables
enclosingtypevariables = ((binarytypebinding)enclosingtype).typevariables; // do not trigger resolution of variables
} else { // codepath only use by codeassist for decoding signatures
enclosingtypevariables = enclosingtype.typevariables();
}
for (int i = enclosingtypevariables.length; --i >= 0;)
if (charoperation.equals(enclosingtypevariables[i].sourcename, wrapper.signature, varstart, varend))
return dimension == 0 ? (typebinding) enclosingtypevariables[i] : createarraytype(enclosingtypevariables[i], dimension);
} while ((enclosingtype = enclosingtype.enclosingtype()) != null);
this.problemreporter.undefinedtypevariablesignature(charoperation.subarray(wrapper.signature, varstart, varend), initialtype);
return null; // cannot reach this, since previous problem will abort compilation
}
boolean isparameterized;
typebinding type = gettypefromsignature(wrapper.signature, wrapper.start, wrapper.computeend(), isparameterized = (wrapper.end == wrapper.bracket), enclosingtype, missingtypenames);
if (!isparameterized)
return dimension == 0 ? type : createarraytype(type, dimension);

// type must be a referencebinding at this point, cannot be a basetypebinding or arraytypebinding
referencebinding actualtype = (referencebinding) type;
if (actualtype instanceof unresolvedreferencebinding)
if (charoperation.indexof('$', actualtype.compoundname[actualtype.compoundname.length - 1]) > 0)
actualtype = (referencebinding) binarytypebinding.resolvetype(actualtype, this, false /* no raw conversion */); // must resolve member types before asking for enclosingtype
referencebinding actualenclosing = actualtype.enclosingtype();
if (actualenclosing != null) { // convert needed if read some static member type
actualenclosing = (referencebinding) converttorawtype(actualenclosing, false /*do not force conversion of enclosing types*/);
}
typebinding[] typearguments = gettypeargumentsfromsignature(wrapper, staticvariables, enclosingtype, actualtype, missingtypenames);
parameterizedtypebinding parameterizedtype = createparameterizedtype(actualtype, typearguments, actualenclosing);

while (wrapper.signature[wrapper.start] == '.') {
wrapper.start++; // skip '.'
int memberstart = wrapper.start;
char[] membername = wrapper.nextword();
binarytypebinding.resolvetype(parameterizedtype, this, false);
referencebinding membertype = parameterizedtype.generictype().getmembertype(membername);
// need to protect against the member type being null when the signature is invalid
if (membertype == null)
this.problemreporter.corruptedsignature(parameterizedtype, wrapper.signature, memberstart); // aborts
if (wrapper.signature[wrapper.start] == '<') {
wrapper.start++; // skip '<'
typearguments = gettypeargumentsfromsignature(wrapper, staticvariables, enclosingtype, membertype, missingtypenames);
} else {
typearguments = null;
}
parameterizedtype = createparameterizedtype(membertype, typearguments, parameterizedtype);
}
wrapper.start++; // skip ';'
return dimension == 0 ? (typebinding) parameterizedtype : createarraytype(parameterizedtype, dimension);
}

typebinding gettypefromvarianttypesignature(
signaturewrapper wrapper,
typevariablebinding[] staticvariables,
referencebinding enclosingtype,
referencebinding generictype,
int rank,
char[][][] missingtypenames) {
// varianttypesignature = '-' typesignature
//   or '+' typesignature
//   or typesignature
//   or '*'
switch (wrapper.signature[wrapper.start]) {
case '-' :
// ? super atype
wrapper.start++;
typebinding bound = gettypefromtypesignature(wrapper, staticvariables, enclosingtype, missingtypenames);
return createwildcard(generictype, rank, bound, null /*no extra bound*/, wildcard.super);
case '+' :
// ? extends atype
wrapper.start++;
bound = gettypefromtypesignature(wrapper, staticvariables, enclosingtype, missingtypenames);
return createwildcard(generictype, rank, bound, null /*no extra bound*/, wildcard.extends);
case '*' :
// ?
wrapper.start++;
return createwildcard(generictype, rank, null, null /*no extra bound*/, wildcard.unbound);
default :
return gettypefromtypesignature(wrapper, staticvariables, enclosingtype, missingtypenames);
}
}

boolean ismissingtype(char[] typename) {
for (int i = this.missingtypes == null ? 0 : this.missingtypes.size(); --i >= 0;) {
missingtypebinding missingtype = (missingtypebinding) this.missingtypes.get(i);
if (charoperation.equals(missingtype.sourcename, typename))
return true;
}
return false;
}

/* ask the oracle if a package exists named name in the package named compoundname.
*/
boolean ispackage(char[][] compoundname, char[] name) {
if (compoundname == null || compoundname.length == 0)
return this.nameenvironment.ispackage(null, name);
return this.nameenvironment.ispackage(compoundname, name);
}
// the method verifier is lazily initialized to guarantee the receiver, the compiler & the oracle are ready.
public methodverifier methodverifier() {
if (this.verifier == null)
this.verifier = newmethodverifier();
return this.verifier;
}

public methodverifier newmethodverifier() {
return this.globaloptions.sourcelevel < classfileconstants.jdk1_5
? new methodverifier(this)
: new methodverifier15(this); // covariance only if sourcelevel is >= 1.5
}

public void releaseclassfiles(org.eclipse.jdt.internal.compiler.classfile[] classfiles) {
for (int i = 0, filecount = classfiles.length; i < filecount; i++)
this.classfilepool.release(classfiles[i]);
}

public void reset() {
this.defaultpackage = new packagebinding(this); // assume the default package always exists
this.defaultimports = null;
this.knownpackages = new hashtableofpackage();
this.accessrestrictions = new hashmap(3);

this.verifier = null;
for (int i = this.uniquearraybindings.length; --i >= 0;) {
arraybinding[] arraybindings = this.uniquearraybindings[i];
if (arraybindings != null)
for (int j = arraybindings.length; --j >= 0;)
arraybindings[j] = null;
}
// note: remember to fix #updatecaches(...) when adding unique binding caches
this.uniqueparameterizedtypebindings = new simplelookuptable(3);
this.uniquerawtypebindings = new simplelookuptable(3);
this.uniquewildcardbindings = new simplelookuptable(3);
this.uniqueparameterizedgenericmethodbindings = new simplelookuptable(3);
this.uniquegetclassmethodbinding = null;
this.missingtypes = null;

for (int i = this.units.length; --i >= 0;)
this.units[i] = null;
this.lastunitindex = -1;
this.lastcompletedunitindex = -1;
this.unitbeingcompleted = null; // in case abortexception occurred

this.classfilepool.reset();
// name environment has a longer life cycle, and must be reset in
// the code which created it.
}

/**
* associate a given type with some access restriction
* (did not store the restriction directly into binding, since sparse information)
*/
public void setaccessrestriction(referencebinding type, accessrestriction accessrestriction) {
if (accessrestriction == null) return;
type.modifiers |= extracompilermodifiers.accrestrictedaccess;
this.accessrestrictions.put(type, accessrestriction);
}

void updatecaches(unresolvedreferencebinding unresolvedtype, referencebinding resolvedtype) {
// walk all the unique collections & replace the unresolvedtype with the resolvedtype
// must prevent 2 entries so == still works (1 containing the unresolvedtype and the other containing the resolvedtype)
if (this.uniqueparameterizedtypebindings.get(unresolvedtype) != null) { // update the key
object[] keys = this.uniqueparameterizedtypebindings.keytable;
for (int i = 0, l = keys.length; i < l; i++) {
if (keys[i] == unresolvedtype) {
keys[i] = resolvedtype; // hashcode is based on compoundname so this works - cannot be raw since type of parameterized type
break;
}
}
}
if (this.uniquerawtypebindings.get(unresolvedtype) != null) { // update the key
object[] keys = this.uniquerawtypebindings.keytable;
for (int i = 0, l = keys.length; i < l; i++) {
if (keys[i] == unresolvedtype) {
keys[i] = resolvedtype; // hashcode is based on compoundname so this works
break;
}
}
}
if (this.uniquewildcardbindings.get(unresolvedtype) != null) { // update the key
object[] keys = this.uniquewildcardbindings.keytable;
for (int i = 0, l = keys.length; i < l; i++) {
if (keys[i] == unresolvedtype) {
keys[i] = resolvedtype; // hashcode is based on compoundname so this works
break;
}
}
}
}
}
