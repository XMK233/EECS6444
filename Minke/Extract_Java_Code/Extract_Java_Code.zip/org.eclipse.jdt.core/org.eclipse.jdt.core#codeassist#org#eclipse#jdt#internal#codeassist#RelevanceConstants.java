/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

public interface relevanceconstants {


/*
* important: the following rules must be strictly adhered to while declaring new relevance constants or modifying the existing:
* 1. one or more relevance constants are used in combination to form a relevance.
* 2. a particular relevance constant can be added only once to form a relevance.
* 3. a resultant relevance (after combining all the applicable relevance constants) must be a positive number.
* 4. the value of r_default is maintained at a positive value such that the sum of all the negative relevance constants
*    and r_default must not be negative.
*/
int r_default = 5;
int r_interesting = 5;
int r_case = 10;
int r_camel_case = 5;
int r_exact_name = 4;
int r_void = -5;
int r_expected_type = 20;
int r_exact_expected_type = 30;
int r_interface = 20;
int r_class = 20;
int r_enum = 20;
int r_annotation = 20;
int r_exception = 20;
int r_enum_constant = 5;
int r_abstract_method = 20;
int r_non_static = 11;
int r_unqualified = 3;
int r_qualified = 2;
int r_name_first_prefix = 6;
int r_name_prefix = 5;
int r_name_first_suffix = 4;
int r_name_suffix = 3;
int r_name_less_new_characters = 15;
int r_method_overide = 3;
int r_non_restricted = 3;
int r_true_or_false = 1;
int r_inline_tag = 31;
int r_value_tag = 31;
int r_non_inherited = 2;
int r_no_problems = 1;
int r_resolved = 1;
int r_target = 5;
}
