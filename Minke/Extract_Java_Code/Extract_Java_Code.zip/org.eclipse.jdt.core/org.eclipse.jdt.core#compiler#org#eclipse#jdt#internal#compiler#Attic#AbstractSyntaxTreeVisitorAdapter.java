/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

import org.eclipse.jdt.core.compiler.*;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

/**
* an adapter class for interating through the parse tree.
*/

public class abstractsyntaxtreevisitoradapter implements iabstractsyntaxtreevisitor {

public void acceptproblem(iproblem problem) {
// do nothing by default
}
public void endvisit(
allocationexpression allocationexpression,
blockscope scope) {
// do nothing by default
}
public void endvisit(and_and_expression and_and_expression, blockscope scope) {
// do nothing by default
}
public void endvisit(
anonymouslocaltypedeclaration anonymoustypedeclaration,
blockscope scope) {
// do nothing by default
}
public void endvisit(javadocarrayqualifiedtypereference typeref, blockscope scope) {
// do nothing by default
}
public void endvisit(javadocarraysingletypereference typeref, blockscope scope) {
// do nothing by default
}
public void endvisit(javadocargumentexpression expression, blockscope scope) {
// do nothing by default
}
public void endvisit(javadocfieldreference fieldref, blockscope scope) {
// do nothing by default
}
public void endvisit(javadocmessagesend messagesend, blockscope scope) {
// do nothing by default
}
public void endvisit(javadocqualifiedtypereference typeref, blockscope scope) {
// do nothing by default
}
public void endvisit(javadocreturnstatement statement, blockscope scope) {
// do nothing by default
}
public void endvisit(javadocsinglenamereference argument, blockscope scope) {
// do nothing by default
}
public void endvisit(javadocsingletypereference typeref, blockscope scope) {
// do nothing by default
}
public void endvisit(argument argument, blockscope scope) {
// do nothing by default
}
public void endvisit(
arrayallocationexpression arrayallocationexpression,
blockscope scope) {
// do nothing by default
}
public void endvisit(arrayinitializer arrayinitializer, blockscope scope) {
// do nothing by default
}
public void endvisit(
arrayqualifiedtypereference arrayqualifiedtypereference,
blockscope scope) {
// do nothing by default
}
public void endvisit(
arrayqualifiedtypereference arrayqualifiedtypereference,
classscope scope) {
// do nothing by default
}
public void endvisit(arrayreference arrayreference, blockscope scope) {
// do nothing by default
}
public void endvisit(arraytypereference arraytypereference, blockscope scope) {
// do nothing by default
}
public void endvisit(arraytypereference arraytypereference, classscope scope) {
// do nothing by default
}
public void endvisit(assignment assignment, blockscope scope) {
// do nothing by default
}
public void endvisit(assertstatement assertstatement, blockscope scope) {
// do nothing by default
}
public void endvisit(binaryexpression binaryexpression, blockscope scope) {
// do nothing by default
}
public void endvisit(block block, blockscope scope) {
// do nothing by default
}
public void endvisit(breakstatement breakstatement, blockscope scope) {
// do nothing by default
}
public void endvisit(casestatement casestatement, blockscope scope) {
// do nothing by default
}
public void endvisit(castexpression castexpression, blockscope scope) {
// do nothing by default
}
public void endvisit(charliteral charliteral, blockscope scope) {
// do nothing by default
}
public void endvisit(classliteralaccess classliteral, blockscope scope) {
// do nothing by default
}
public void endvisit(clinit clinit, classscope scope) {
// do nothing by default
}
public void endvisit(
compilationunitdeclaration compilationunitdeclaration,
compilationunitscope scope) {
// do nothing by default
}
public void endvisit(compoundassignment compoundassignment, blockscope scope) {
// do nothing by default
}
public void endvisit(
conditionalexpression conditionalexpression,
blockscope scope) {
// do nothing by default
}
public void endvisit(
constructordeclaration constructordeclaration,
classscope scope) {
// do nothing by default
}
public void endvisit(continuestatement continuestatement, blockscope scope) {
// do nothing by default
}
public void endvisit(dostatement dostatement, blockscope scope) {
// do nothing by default
}
public void endvisit(doubleliteral doubleliteral, blockscope scope) {
// do nothing by default
}
public void endvisit(equalexpression equalexpression, blockscope scope) {
// do nothing by default
}
public void endvisit(
explicitconstructorcall explicitconstructor,
blockscope scope) {
// do nothing by default
}
public void endvisit(
extendedstringliteral extendedstringliteral,
blockscope scope) {
// do nothing by default
}
public void endvisit(falseliteral falseliteral, blockscope scope) {
// do nothing by default
}
public void endvisit(fielddeclaration fielddeclaration, methodscope scope) {
// do nothing by default
}
public void endvisit(fieldreference fieldreference, blockscope scope) {
// do nothing by default
}
public void endvisit(floatliteral floatliteral, blockscope scope) {
// do nothing by default
}
public void endvisit(emptystatement emptystatement, blockscope scope) {
// do nothing by default
}
public void endvisit(forstatement forstatement, blockscope scope) {
// do nothing by default
}
public void endvisit(ifstatement ifstatement, blockscope scope) {
// do nothing by default
}
public void endvisit(importreference importref, compilationunitscope scope) {
// do nothing by default
}
public void endvisit(initializer initializer, methodscope scope) {
// do nothing by default
}
public void endvisit(
instanceofexpression instanceofexpression,
blockscope scope) {
// do nothing by default
}
public void endvisit(intliteral intliteral, blockscope scope) {
// do nothing by default
}
public void endvisit(iteratorforstatement forstatement, blockscope scope) {
// do nothing by default
}
public void endvisit(labeledstatement labeledstatement, blockscope scope) {
// do nothing by default
}
public void endvisit(localdeclaration localdeclaration, blockscope scope) {
// do nothing by default
}
public void endvisit(longliteral longliteral, blockscope scope) {
// do nothing by default
}
public void endvisit(
membertypedeclaration membertypedeclaration,
classscope scope) {
// do nothing by default
}
public void endvisit(messagesend messagesend, blockscope scope) {
// do nothing by default
}
public void endvisit(methoddeclaration methoddeclaration, classscope scope) {
// do nothing by default
}
public void endvisit(nullliteral nullliteral, blockscope scope) {
// do nothing by default
}
public void endvisit(or_or_expression or_or_expression, blockscope scope) {
// do nothing by default
}
public void endvisit(postfixexpression postfixexpression, blockscope scope) {
// do nothing by default
}
public void endvisit(prefixexpression prefixexpression, blockscope scope) {
// do nothing by default
}
public void endvisit(
qualifiedallocationexpression qualifiedallocationexpression,
blockscope scope) {
// do nothing by default
}
public void endvisit(
qualifiednamereference qualifiednamereference,
blockscope scope) {
// do nothing by default
}
public void endvisit(
qualifiedsuperreference qualifiedsuperreference,
blockscope scope) {
// do nothing by default
}
public void endvisit(
qualifiedthisreference qualifiedthisreference,
blockscope scope) {
// do nothing by default
}
public void endvisit(
qualifiedtypereference qualifiedtypereference,
blockscope scope) {
// do nothing by default
}
public void endvisit(
qualifiedtypereference qualifiedtypereference,
classscope scope) {
// do nothing by default
}
public void endvisit(returnstatement returnstatement, blockscope scope) {
// do nothing by default
}
public void endvisit(
singlenamereference singlenamereference,
blockscope scope) {
// do nothing by default
}
public void endvisit(
singletypereference singletypereference,
blockscope scope) {
// do nothing by default
}
public void endvisit(
singletypereference singletypereference,
classscope scope) {
// do nothing by default
}
public void endvisit(stringliteral stringliteral, blockscope scope) {
// do nothing by default
}
public void endvisit(superreference superreference, blockscope scope) {
// do nothing by default
}
public void endvisit(switchstatement switchstatement, blockscope scope) {
// do nothing by default
}
public void endvisit(
synchronizedstatement synchronizedstatement,
blockscope scope) {
// do nothing by default
}
public void endvisit(thisreference thisreference, blockscope scope) {
// do nothing by default
}
public void endvisit(throwstatement throwstatement, blockscope scope) {
// do nothing by default
}
public void endvisit(trueliteral trueliteral, blockscope scope) {
// do nothing by default
}
public void endvisit(trystatement trystatement, blockscope scope) {
// do nothing by default
}
public void endvisit(
typedeclaration typedeclaration,
compilationunitscope scope) {
// do nothing by default
}
public void endvisit(unaryexpression unaryexpression, blockscope scope) {
// do nothing by default
}
public void endvisit(whilestatement whilestatement, blockscope scope) {
// do nothing by default
}
public boolean visit(
allocationexpression allocationexpression,
blockscope scope) {
return true; // do nothing by default, keep traversing
// do nothing by default
}
public boolean visit(and_and_expression and_and_expression, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
anonymouslocaltypedeclaration anonymoustypedeclaration,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(javadocarrayqualifiedtypereference typeref, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(javadocarraysingletypereference typeref, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(javadocargumentexpression expression, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(javadocfieldreference fieldref, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(javadocmessagesend messagesend, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(javadocqualifiedtypereference typeref, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(javadocreturnstatement statement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(javadocsinglenamereference argument, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(javadocsingletypereference typeref, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(argument argument, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
arrayallocationexpression arrayallocationexpression,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(arrayinitializer arrayinitializer, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
arrayqualifiedtypereference arrayqualifiedtypereference,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
arrayqualifiedtypereference arrayqualifiedtypereference,
classscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(arrayreference arrayreference, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(arraytypereference arraytypereference, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(arraytypereference arraytypereference, classscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(assignment assignment, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(assertstatement assertstatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(binaryexpression binaryexpression, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(block block, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(breakstatement breakstatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(casestatement casestatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(castexpression castexpression, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(charliteral charliteral, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(classliteralaccess classliteral, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(clinit clinit, classscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
compilationunitdeclaration compilationunitdeclaration,
compilationunitscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(compoundassignment compoundassignment, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
conditionalexpression conditionalexpression,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
constructordeclaration constructordeclaration,
classscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(continuestatement continuestatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(dostatement dostatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(doubleliteral doubleliteral, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(equalexpression equalexpression, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(emptystatement emptystatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
explicitconstructorcall explicitconstructor,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
extendedstringliteral extendedstringliteral,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(falseliteral falseliteral, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(fielddeclaration fielddeclaration, methodscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(fieldreference fieldreference, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(floatliteral floatliteral, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(forstatement forstatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(ifstatement ifstatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(importreference importref, compilationunitscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(initializer initializer, methodscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
instanceofexpression instanceofexpression,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(intliteral intliteral, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(iteratorforstatement forstatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(labeledstatement labeledstatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(localdeclaration localdeclaration, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(longliteral longliteral, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
membertypedeclaration membertypedeclaration,
classscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(messagesend messagesend, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(methoddeclaration methoddeclaration, classscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(nullliteral nullliteral, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(or_or_expression or_or_expression, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(postfixexpression postfixexpression, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(prefixexpression prefixexpression, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
qualifiedallocationexpression qualifiedallocationexpression,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
qualifiednamereference qualifiednamereference,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
qualifiedsuperreference qualifiedsuperreference,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
qualifiedthisreference qualifiedthisreference,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
qualifiedtypereference qualifiedtypereference,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
qualifiedtypereference qualifiedtypereference,
classscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(returnstatement returnstatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
singlenamereference singlenamereference,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
singletypereference singletypereference,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
singletypereference singletypereference,
classscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(stringliteral stringliteral, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(superreference superreference, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(switchstatement switchstatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
synchronizedstatement synchronizedstatement,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(thisreference thisreference, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(throwstatement throwstatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(trueliteral trueliteral, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(trystatement trystatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
typedeclaration typedeclaration,
compilationunitscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(unaryexpression unaryexpression, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(whilestatement whilestatement, blockscope scope) {
return true; // do nothing by default, keep traversing
}
public boolean visit(
localtypedeclaration localtypedeclaration,
blockscope scope) {
return true; // do nothing by default, keep traversing
}
public void endvisit(
localtypedeclaration localtypedeclaration,
blockscope scope) {
// do nothing by default
}
}
