/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

/*
* selection node build by the parser in any case it was intending to
* reduce a message send containing the cursor.
* e.g.
*
*	class x {
*    void foo() {
*      this.[start]bar[end](1, 2)
*    }
*  }
*
*	---> class x {
*         void foo() {
*           <selectonmessagesend:this.bar(1, 2)>
*         }
*       }
*
*/

import org.eclipse.jdt.internal.compiler.ast.messagesend;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class selectiononmessagesend extends messagesend {

/*
* cannot answer default abstract match, iterate in superinterfaces of declaring class
* for a better match (default abstract match came from scope lookups).
*/
private methodbinding findnondefaultabstractmethod(methodbinding methodbinding) {

referencebinding[] itsinterfaces = methodbinding.declaringclass.superinterfaces();
if (itsinterfaces != binding.no_superinterfaces) {
referencebinding[] interfacestovisit = itsinterfaces;
int nextposition = interfacestovisit.length;

for (int i = 0; i < nextposition; i++) {
referencebinding currenttype = interfacestovisit[i];
methodbinding[] methods = currenttype.getmethods(methodbinding.selector);
if(methods != null) {
for (int k = 0; k < methods.length; k++) {
if(methodbinding.areparametersequal(methods[k]))
return methods[k];
}
}

if ((itsinterfaces = currenttype.superinterfaces()) != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
return methodbinding;
}

public stringbuffer printexpression(int indent, stringbuffer output) {

output.append("<selectonmessagesend:"); //$non-nls-1$
if (!this.receiver.isimplicitthis()) this.receiver.printexpression(0, output).append('.');
output.append(this.selector).append('(');
if (this.arguments != null) {
for (int i = 0; i < this.arguments.length; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.arguments[i].printexpression(0, output);
}
}
return output.append(")>"); //$non-nls-1$
}

public typebinding resolvetype(blockscope scope) {

super.resolvetype(scope);

// tolerate some error cases
if(this.binding == null ||
!(this.binding.isvalidbinding() ||
this.binding.problemid() == problemreasons.notvisible
|| this.binding.problemid() == problemreasons.inheritednamehidesenclosingname
|| this.binding.problemid() == problemreasons.nonstaticreferenceinconstructorinvocation
|| this.binding.problemid() == problemreasons.nonstaticreferenceinstaticcontext)) {
throw new selectionnodefound();
} else {
if(this.binding.isdefaultabstract()) {
throw new selectionnodefound(findnondefaultabstractmethod(this.binding)); // 23594
} else {
throw new selectionnodefound(this.binding);
}
}
}
}
