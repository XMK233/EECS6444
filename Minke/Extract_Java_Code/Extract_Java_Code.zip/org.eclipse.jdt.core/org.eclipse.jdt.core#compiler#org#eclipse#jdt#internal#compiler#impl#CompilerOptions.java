/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     benjamin muskalla - contribution for bug 239066
*     stephan herrmann  - contribution for bug 236385
*     stephan herrmann  - contribution for bug 295551
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.impl;

import java.io.bytearrayinputstream;
import java.io.inputstreamreader;
import java.io.unsupportedencodingexception;
import java.util.hashmap;
import java.util.map;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.compiler;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.lookup.extracompilermodifiers;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;
import org.eclipse.jdt.internal.compiler.util.util;

public class compileroptions {

/**
* option ids
*/
public static final string option_localvariableattribute = "org.eclipse.jdt.core.compiler.debug.localvariable"; //$non-nls-1$
public static final string option_linenumberattribute = "org.eclipse.jdt.core.compiler.debug.linenumber"; //$non-nls-1$
public static final string option_sourcefileattribute = "org.eclipse.jdt.core.compiler.debug.sourcefile"; //$non-nls-1$
public static final string option_preserveunusedlocal = "org.eclipse.jdt.core.compiler.codegen.unusedlocal"; //$non-nls-1$
public static final string option_doccommentsupport= "org.eclipse.jdt.core.compiler.doc.comment.support"; //$non-nls-1$
public static final string option_reportmethodwithconstructorname = "org.eclipse.jdt.core.compiler.problem.methodwithconstructorname"; //$non-nls-1$
public static final string option_reportoverridingpackagedefaultmethod = "org.eclipse.jdt.core.compiler.problem.overridingpackagedefaultmethod"; //$non-nls-1$
public static final string option_reportdeprecation = "org.eclipse.jdt.core.compiler.problem.deprecation"; //$non-nls-1$
public static final string option_reportdeprecationindeprecatedcode = "org.eclipse.jdt.core.compiler.problem.deprecationindeprecatedcode"; //$non-nls-1$
public static final string option_reportdeprecationwhenoverridingdeprecatedmethod = "org.eclipse.jdt.core.compiler.problem.deprecationwhenoverridingdeprecatedmethod"; //$non-nls-1$
public static final string option_reporthiddencatchblock = "org.eclipse.jdt.core.compiler.problem.hiddencatchblock"; //$non-nls-1$
public static final string option_reportunusedlocal = "org.eclipse.jdt.core.compiler.problem.unusedlocal"; //$non-nls-1$
public static final string option_reportunusedparameter = "org.eclipse.jdt.core.compiler.problem.unusedparameter"; //$non-nls-1$
public static final string option_reportunusedparameterwhenimplementingabstract = "org.eclipse.jdt.core.compiler.problem.unusedparameterwhenimplementingabstract"; //$non-nls-1$
public static final string option_reportunusedparameterwhenoverridingconcrete = "org.eclipse.jdt.core.compiler.problem.unusedparameterwhenoverridingconcrete"; //$non-nls-1$
public static final string option_reportunusedparameterincludedoccommentreference = "org.eclipse.jdt.core.compiler.problem.unusedparameterincludedoccommentreference"; //$non-nls-1$
public static final string option_reportunusedimport = "org.eclipse.jdt.core.compiler.problem.unusedimport"; //$non-nls-1$
public static final string option_reportsyntheticaccessemulation = "org.eclipse.jdt.core.compiler.problem.syntheticaccessemulation"; //$non-nls-1$
public static final string option_reportnoeffectassignment = "org.eclipse.jdt.core.compiler.problem.noeffectassignment"; //$non-nls-1$
public static final string option_reportlocalvariablehiding = "org.eclipse.jdt.core.compiler.problem.localvariablehiding"; //$non-nls-1$
public static final string option_reportspecialparameterhidingfield = "org.eclipse.jdt.core.compiler.problem.specialparameterhidingfield"; //$non-nls-1$
public static final string option_reportfieldhiding = "org.eclipse.jdt.core.compiler.problem.fieldhiding"; //$non-nls-1$
public static final string option_reporttypeparameterhiding = "org.eclipse.jdt.core.compiler.problem.typeparameterhiding"; //$non-nls-1$
public static final string option_reportpossibleaccidentalbooleanassignment = "org.eclipse.jdt.core.compiler.problem.possibleaccidentalbooleanassignment"; //$non-nls-1$
public static final string option_reportnonexternalizedstringliteral = "org.eclipse.jdt.core.compiler.problem.nonexternalizedstringliteral"; //$non-nls-1$
public static final string option_reportincompatiblenoninheritedinterfacemethod = "org.eclipse.jdt.core.compiler.problem.incompatiblenoninheritedinterfacemethod"; //$non-nls-1$
public static final string option_reportunusedprivatemember = "org.eclipse.jdt.core.compiler.problem.unusedprivatemember"; //$non-nls-1$
public static final string option_reportnoimplicitstringconversion = "org.eclipse.jdt.core.compiler.problem.noimplicitstringconversion"; //$non-nls-1$
public static final string option_reportassertidentifier = "org.eclipse.jdt.core.compiler.problem.assertidentifier"; //$non-nls-1$
public static final string option_reportenumidentifier = "org.eclipse.jdt.core.compiler.problem.enumidentifier"; //$non-nls-1$
public static final string option_reportnonstaticaccesstostatic = "org.eclipse.jdt.core.compiler.problem.staticaccessreceiver"; //$non-nls-1$
public static final string option_reportindirectstaticaccess = "org.eclipse.jdt.core.compiler.problem.indirectstaticaccess"; //$non-nls-1$
public static final string option_reportemptystatement = "org.eclipse.jdt.core.compiler.problem.emptystatement"; //$non-nls-1$
public static final string option_reportunnecessarytypecheck = "org.eclipse.jdt.core.compiler.problem.unnecessarytypecheck"; //$non-nls-1$
public static final string option_reportunnecessaryelse = "org.eclipse.jdt.core.compiler.problem.unnecessaryelse"; //$non-nls-1$
public static final string option_reportundocumentedemptyblock = "org.eclipse.jdt.core.compiler.problem.undocumentedemptyblock"; //$non-nls-1$
public static final string option_reportinvalidjavadoc = "org.eclipse.jdt.core.compiler.problem.invalidjavadoc"; //$non-nls-1$
public static final string option_reportinvalidjavadoctags = "org.eclipse.jdt.core.compiler.problem.invalidjavadoctags"; //$non-nls-1$
public static final string option_reportinvalidjavadoctagsdeprecatedref = "org.eclipse.jdt.core.compiler.problem.invalidjavadoctagsdeprecatedref"; //$non-nls-1$
public static final string option_reportinvalidjavadoctagsnotvisibleref = "org.eclipse.jdt.core.compiler.problem.invalidjavadoctagsnotvisibleref"; //$non-nls-1$
public static final string option_reportinvalidjavadoctagsvisibility = "org.eclipse.jdt.core.compiler.problem.invalidjavadoctagsvisibility"; //$non-nls-1$
public static final string option_reportmissingjavadoctags = "org.eclipse.jdt.core.compiler.problem.missingjavadoctags"; //$non-nls-1$
public static final string option_reportmissingjavadoctagsvisibility = "org.eclipse.jdt.core.compiler.problem.missingjavadoctagsvisibility"; //$non-nls-1$
public static final string option_reportmissingjavadoctagsoverriding = "org.eclipse.jdt.core.compiler.problem.missingjavadoctagsoverriding"; //$non-nls-1$
public static final string option_reportmissingjavadoccomments = "org.eclipse.jdt.core.compiler.problem.missingjavadoccomments"; //$non-nls-1$
public static final string option_reportmissingjavadoctagdescription = "org.eclipse.jdt.core.compiler.problem.missingjavadoctagdescription"; //$non-nls-1$
public static final string option_reportmissingjavadoccommentsvisibility = "org.eclipse.jdt.core.compiler.problem.missingjavadoccommentsvisibility"; //$non-nls-1$
public static final string option_reportmissingjavadoccommentsoverriding = "org.eclipse.jdt.core.compiler.problem.missingjavadoccommentsoverriding"; //$non-nls-1$
public static final string option_reportfinallyblocknotcompletingnormally = "org.eclipse.jdt.core.compiler.problem.finallyblocknotcompletingnormally"; //$non-nls-1$
public static final string option_reportunuseddeclaredthrownexception = "org.eclipse.jdt.core.compiler.problem.unuseddeclaredthrownexception"; //$non-nls-1$
public static final string option_reportunuseddeclaredthrownexceptionwhenoverriding = "org.eclipse.jdt.core.compiler.problem.unuseddeclaredthrownexceptionwhenoverriding"; //$non-nls-1$
public static final string option_reportunuseddeclaredthrownexceptionincludedoccommentreference = "org.eclipse.jdt.core.compiler.problem.unuseddeclaredthrownexceptionincludedoccommentreference"; //$non-nls-1$
public static final string option_reportunuseddeclaredthrownexceptionexemptexceptionandthrowable = "org.eclipse.jdt.core.compiler.problem.unuseddeclaredthrownexceptionexemptexceptionandthrowable"; //$non-nls-1$
public static final string option_reportunqualifiedfieldaccess = "org.eclipse.jdt.core.compiler.problem.unqualifiedfieldaccess"; //$non-nls-1$
public static final string option_reportuncheckedtypeoperation = "org.eclipse.jdt.core.compiler.problem.uncheckedtypeoperation"; //$non-nls-1$
public static final string option_reportrawtypereference =  "org.eclipse.jdt.core.compiler.problem.rawtypereference"; //$non-nls-1$
public static final string option_reportfinalparameterbound = "org.eclipse.jdt.core.compiler.problem.finalparameterbound"; //$non-nls-1$
public static final string option_reportmissingserialversion = "org.eclipse.jdt.core.compiler.problem.missingserialversion"; //$non-nls-1$
public static final string option_reportvarargsargumentneedcast = "org.eclipse.jdt.core.compiler.problem.varargsargumentneedcast"; //$non-nls-1$
public static final string option_reportunusedtypeargumentsformethodinvocation = "org.eclipse.jdt.core.compiler.problem.unusedtypeargumentsformethodinvocation"; //$non-nls-1$
public static final string option_source = "org.eclipse.jdt.core.compiler.source"; //$non-nls-1$
public static final string option_targetplatform = "org.eclipse.jdt.core.compiler.codegen.targetplatform"; //$non-nls-1$
public static final string option_compliance = "org.eclipse.jdt.core.compiler.compliance"; //$non-nls-1$
public static final string option_encoding = "org.eclipse.jdt.core.encoding"; //$non-nls-1$
public static final string option_maxproblemperunit = "org.eclipse.jdt.core.compiler.maxproblemperunit"; //$non-nls-1$
public static final string option_tasktags = "org.eclipse.jdt.core.compiler.tasktags"; //$non-nls-1$
public static final string option_taskpriorities = "org.eclipse.jdt.core.compiler.taskpriorities"; //$non-nls-1$
public static final string option_taskcasesensitive = "org.eclipse.jdt.core.compiler.taskcasesensitive"; //$non-nls-1$
public static final string option_inlinejsr = "org.eclipse.jdt.core.compiler.codegen.inlinejsrbytecode"; //$non-nls-1$
public static final string option_reportnullreference = "org.eclipse.jdt.core.compiler.problem.nullreference"; //$non-nls-1$
public static final string option_reportpotentialnullreference = "org.eclipse.jdt.core.compiler.problem.potentialnullreference"; //$non-nls-1$
public static final string option_reportredundantnullcheck = "org.eclipse.jdt.core.compiler.problem.redundantnullcheck"; //$non-nls-1$
public static final string option_reportautoboxing = "org.eclipse.jdt.core.compiler.problem.autoboxing"; //$non-nls-1$
public static final string option_reportannotationsuperinterface = "org.eclipse.jdt.core.compiler.problem.annotationsuperinterface"; //$non-nls-1$
public static final string option_reportmissingoverrideannotation = "org.eclipse.jdt.core.compiler.problem.missingoverrideannotation"; //$non-nls-1$
public static final string option_reportmissingoverrideannotationforinterfacemethodimplementation = "org.eclipse.jdt.core.compiler.problem.missingoverrideannotationforinterfacemethodimplementation"; //$non-nls-1$
public static final string option_reportmissingdeprecatedannotation = "org.eclipse.jdt.core.compiler.problem.missingdeprecatedannotation"; //$non-nls-1$
public static final string option_reportincompleteenumswitch = "org.eclipse.jdt.core.compiler.problem.incompleteenumswitch"; //$non-nls-1$
public static final string option_reportforbiddenreference =  "org.eclipse.jdt.core.compiler.problem.forbiddenreference"; //$non-nls-1$
public static final string option_reportdiscouragedreference =  "org.eclipse.jdt.core.compiler.problem.discouragedreference"; //$non-nls-1$
public static final string option_suppresswarnings =  "org.eclipse.jdt.core.compiler.problem.suppresswarnings"; //$non-nls-1$
public static final string option_suppressoptionalerrors = "org.eclipse.jdt.core.compiler.problem.suppressoptionalerrors"; //$non-nls-1$
public static final string option_reportunhandledwarningtoken =  "org.eclipse.jdt.core.compiler.problem.unhandledwarningtoken"; //$non-nls-1$
public static final string option_reportunusedwarningtoken =  "org.eclipse.jdt.core.compiler.problem.unusedwarningtoken"; //$non-nls-1$
public static final string option_reportunusedlabel =  "org.eclipse.jdt.core.compiler.problem.unusedlabel"; //$non-nls-1$
public static final string option_fataloptionalerror =  "org.eclipse.jdt.core.compiler.problem.fataloptionalerror"; //$non-nls-1$
public static final string option_reportparameterassignment =  "org.eclipse.jdt.core.compiler.problem.parameterassignment"; //$non-nls-1$
public static final string option_reportfallthroughcase =  "org.eclipse.jdt.core.compiler.problem.fallthroughcase"; //$non-nls-1$
public static final string option_reportoverridingmethodwithoutsuperinvocation =  "org.eclipse.jdt.core.compiler.problem.overridingmethodwithoutsuperinvocation"; //$non-nls-1$
public static final string option_generateclassfiles = "org.eclipse.jdt.core.compiler.generateclassfiles"; //$non-nls-1$
public static final string option_process_annotations = "org.eclipse.jdt.core.compiler.processannotations"; //$non-nls-1$
public static final string option_reportredundantsuperinterface =  "org.eclipse.jdt.core.compiler.problem.redundantsuperinterface"; //$non-nls-1$
public static final string option_reportcomparingidentical =  "org.eclipse.jdt.core.compiler.problem.comparingidentical"; //$non-nls-1$
public static final string option_reportmissingsynchronizedoninheritedmethod =  "org.eclipse.jdt.core.compiler.problem.missingsynchronizedoninheritedmethod"; //$non-nls-1$
public static final string option_reportmissinghashcodemethod =  "org.eclipse.jdt.core.compiler.problem.missinghashcodemethod"; //$non-nls-1$
public static final string option_reportdeadcode =  "org.eclipse.jdt.core.compiler.problem.deadcode"; //$non-nls-1$
public static final string option_reportdeadcodeintrivialifstatement =  "org.eclipse.jdt.core.compiler.problem.deadcodeintrivialifstatement"; //$non-nls-1$
public static final string option_reporttasks = "org.eclipse.jdt.core.compiler.problem.tasks"; //$non-nls-1$
public static final string option_reportunusedobjectallocation = "org.eclipse.jdt.core.compiler.problem.unusedobjectallocation";  //$non-nls-1$

// backward compatibility
public static final string option_reportinvalidannotation = "org.eclipse.jdt.core.compiler.problem.invalidannotation"; //$non-nls-1$
public static final string option_reportmissingannotation = "org.eclipse.jdt.core.compiler.problem.missingannotation"; //$non-nls-1$
public static final string option_reportmissingjavadoc = "org.eclipse.jdt.core.compiler.problem.missingjavadoc"; //$non-nls-1$

/**
* possible values for configurable options
*/
public static final string generate = "generate";//$non-nls-1$
public static final string do_not_generate = "do not generate"; //$non-nls-1$
public static final string preserve = "preserve"; //$non-nls-1$
public static final string optimize_out = "optimize out"; //$non-nls-1$
public static final string version_1_1 = "1.1"; //$non-nls-1$
public static final string version_1_2 = "1.2"; //$non-nls-1$
public static final string version_1_3 = "1.3"; //$non-nls-1$
public static final string version_1_4 = "1.4"; //$non-nls-1$
public static final string version_jsr14 = "jsr14"; //$non-nls-1$
public static final string version_cldc1_1 = "cldc1.1"; //$non-nls-1$
public static final string version_1_5 = "1.5"; //$non-nls-1$
public static final string version_1_6 = "1.6"; //$non-nls-1$
public static final string version_1_7 = "1.7"; //$non-nls-1$
public static final string error = "error"; //$non-nls-1$
public static final string warning = "warning"; //$non-nls-1$
public static final string ignore = "ignore"; //$non-nls-1$
public static final string enabled = "enabled"; //$non-nls-1$
public static final string disabled = "disabled"; //$non-nls-1$
public static final string public = "public";	//$non-nls-1$
public static final string protected = "protected";	//$non-nls-1$
public static final string default = "default";	//$non-nls-1$
public static final string private = "private";	//$non-nls-1$
public static final string return_tag = "return_tag";	//$non-nls-1$
public static final string no_tag = "no_tag";	//$non-nls-1$
public static final string all_standard_tags = "all_standard_tags";	//$non-nls-1$

/**
* bit mask for configurable problems (error/warning threshold)
* note: bitmask assumes 3 highest bits to denote irritant group (to allow storing 8 groups of 29 bits each
*/
// group 0
public static final int methodwithconstructorname = irritantset.group0 | astnode.bit1;
public static final int overriddenpackagedefaultmethod = irritantset.group0 | astnode.bit2;
public static final int usingdeprecatedapi = irritantset.group0 | astnode.bit3;
public static final int maskedcatchblock = irritantset.group0 | astnode.bit4;
public static final int unusedlocalvariable = irritantset.group0 | astnode.bit5;
public static final int unusedargument = irritantset.group0 | astnode.bit6;
public static final int noimplicitstringconversion = irritantset.group0 | astnode.bit7;
public static final int accessemulation = irritantset.group0 | astnode.bit8;
public static final int nonexternalizedstring = irritantset.group0 | astnode.bit9;
public static final int assertusedasanidentifier = irritantset.group0 | astnode.bit10;
public static final int unusedimport = irritantset.group0 | astnode.bit11;
public static final int nonstaticaccesstostatic = irritantset.group0 | astnode.bit12;
public static final int task = irritantset.group0 | astnode.bit13;
public static final int noeffectassignment = irritantset.group0 | astnode.bit14;
public static final int incompatiblenoninheritedinterfacemethod = irritantset.group0 | astnode.bit15;
public static final int unusedprivatemember = irritantset.group0 | astnode.bit16;
public static final int localvariablehiding = irritantset.group0 | astnode.bit17;
public static final int fieldhiding = irritantset.group0 | astnode.bit18;
public static final int accidentalbooleanassign = irritantset.group0 | astnode.bit19;
public static final int emptystatement = irritantset.group0 | astnode.bit20;
public static final int missingjavadoccomments  = irritantset.group0 | astnode.bit21;
public static final int missingjavadoctags = irritantset.group0 | astnode.bit22;
public static final int unqualifiedfieldaccess = irritantset.group0 | astnode.bit23;
public static final int unuseddeclaredthrownexception = irritantset.group0 | astnode.bit24;
public static final int finallyblocknotcompleting = irritantset.group0 | astnode.bit25;
public static final int invalidjavadoc = irritantset.group0 | astnode.bit26;
public static final int unnecessarytypecheck = irritantset.group0 | astnode.bit27;
public static final int undocumentedemptyblock = irritantset.group0 | astnode.bit28;
public static final int indirectstaticaccess = irritantset.group0 | astnode.bit29;

// group 1
public static final int unnecessaryelse  = irritantset.group1 | astnode.bit1;
public static final int uncheckedtypeoperation = irritantset.group1 | astnode.bit2;
public static final int finalparameterbound = irritantset.group1 | astnode.bit3;
public static final int missingserialversion = irritantset.group1 | astnode.bit4;
public static final int enumusedasanidentifier = irritantset.group1 | astnode.bit5;
public static final int forbiddenreference = irritantset.group1 | astnode.bit6;
public static final int varargsargumentneedcast = irritantset.group1 | astnode.bit7;
public static final int nullreference = irritantset.group1 | astnode.bit8;
public static final int autoboxing = irritantset.group1 | astnode.bit9;
public static final int annotationsuperinterface = irritantset.group1 | astnode.bit10;
public static final int typehiding = irritantset.group1 | astnode.bit11;
public static final int missingoverrideannotation = irritantset.group1 | astnode.bit12;
public static final int incompleteenumswitch = irritantset.group1 | astnode.bit13;
public static final int missingdeprecatedannotation = irritantset.group1 | astnode.bit14;
public static final int discouragedreference = irritantset.group1 | astnode.bit15;
public static final int unhandledwarningtoken = irritantset.group1 | astnode.bit16;
public static final int rawtypereference = irritantset.group1 | astnode.bit17;
public static final int unusedlabel = irritantset.group1 | astnode.bit18;
public static final int parameterassignment = irritantset.group1 | astnode.bit19;
public static final int fallthroughcase = irritantset.group1 | astnode.bit20;
public static final int overridingmethodwithoutsuperinvocation = irritantset.group1 | astnode.bit21;
public static final int potentialnullreference = irritantset.group1 | astnode.bit22;
public static final int redundantnullcheck = irritantset.group1 | astnode.bit23;
public static final int missingjavadoctagdescription = irritantset.group1 | astnode.bit24;
public static final int unusedtypearguments = irritantset.group1 | astnode.bit25;
public static final int unusedwarningtoken = irritantset.group1 | astnode.bit26;
public static final int redundantsuperinterface = irritantset.group1 | astnode.bit27;
public static final int comparingidentical = irritantset.group1 | astnode.bit28;
public static final int missingsynchronizedmodifierininheritedmethod= irritantset.group1 | astnode.bit29;

// group 2
public static final int shouldimplementhashcode = irritantset.group2 | astnode.bit1;
public static final int deadcode = irritantset.group2 | astnode.bit2;
public static final int tasks = irritantset.group2 | astnode.bit3;
public static final int unusedobjectallocation = irritantset.group2 | astnode.bit4;

// severity level for handlers
/**
* defaults defined at {@@link irritantset#compiler_default_errors}
* @@see #resetdefaults()
*/
protected irritantset errorthreshold;
/**
* defaults defined at {@@link irritantset#compiler_default_warnings}
* @@see #resetdefaults()
*/
protected irritantset warningthreshold;

/**
* default settings are to be defined in {@@lnk compileroptions#resetdefaults()}
*/

/** classfile debug information, may contain source file name, line numbers, local variable tables, etc... */
public int producedebugattributes;
/** compliance level for the compiler, refers to a jdk version, e.g. {link {@@link classfileconstants#jdk1_4} */
public long compliancelevel;
/** java source level, refers to a jdk version, e.g. {link {@@link classfileconstants#jdk1_4} */
public long sourcelevel;
/** vm target level, refers to a jdk version, e.g. {link {@@link classfileconstants#jdk1_4} */
public long targetjdk;
/** source encoding format */
public string defaultencoding;
/** compiler trace verbosity */
public boolean verbose;
/** indicates whether reference info is desired */
public boolean producereferenceinfo;
/** indicates if unused/optimizable local variables need to be preserved (debugging purpose) */
public boolean preservealllocalvariables;
/** indicates whether literal expressions are inlined at parse-time or not */
public boolean parseliteralexpressionsasconstants;
/** max problems per compilation unit */
public int maxproblemsperunit;
/** tags used to recognize tasks in comments */
public char[][] tasktags;
/** respective priorities of recognized task tags */
public char[][] taskpriorities;
/** indicate whether tag detection is case sensitive or not */
public boolean istaskcasesensitive;
/** specify whether deprecation inside deprecated code is to be reported */
public boolean reportdeprecationinsidedeprecatedcode;
/** specify whether override of deprecated method is to be reported */
public boolean reportdeprecationwhenoverridingdeprecatedmethod;
/** specify if should report unused parameter when implementing abstract method */
public boolean reportunusedparameterwhenimplementingabstract;
/** specify if should report unused parameter when overriding concrete method */
public boolean reportunusedparameterwhenoverridingconcrete;
/** specify if should report documented unused parameter (in javadoc) */
public boolean reportunusedparameterincludedoccommentreference;
/** specify if should reported unused declared thrown exception when overriding method */
public boolean reportunuseddeclaredthrownexceptionwhenoverriding;
/** specify if should reported unused declared thrown exception when documented in javadoc */
public boolean reportunuseddeclaredthrownexceptionincludedoccommentreference;
/** specify if should reported unused declared thrown exception when exception or throwable */
public boolean reportunuseddeclaredthrownexceptionexemptexceptionandthrowable;
/** specify whether should report constructor/setter method parameter hiding */
public boolean reportspecialparameterhidingfield;
/** specify whether trivial deadcode pattern is to be reported (e.g. if (debug) ...) */
public boolean reportdeadcodeintrivialifstatement;
/** master flag controlling whether doc comment should be processed */
public boolean doccommentsupport;
/** specify if invalid javadoc shall be reported */
public boolean reportinvalidjavadoctags;
/** only report invalid javadoc above a given level of visibility of associated construct */
public int reportinvalidjavadoctagsvisibility;
/** specify if deprecated javadoc ref is allowed */
public boolean reportinvalidjavadoctagsdeprecatedref;
/** specify if non visible javadoc ref is allowed */
public boolean reportinvalidjavadoctagsnotvisibleref;
/** specify when to report missing javadoc tag description */
public string reportmissingjavadoctagdescription;
/** only report missing javadoc tags above a given level of visibility of associated construct */
public int reportmissingjavadoctagsvisibility;
/** specify if need to flag missing javadoc tags for overriding method */
public boolean reportmissingjavadoctagsoverriding;
/** only report missing javadoc comment above a given level of visibility of associated construct */
public int reportmissingjavadoccommentsvisibility;
/** specify if need to flag missing javadoc comment for overriding method */
public boolean reportmissingjavadoccommentsoverriding;
/** indicate whether the jsr bytecode should be inlined to avoid its presence in classfile */
public boolean inlinejsrbytecode;
/** indicate if @@suppresswarning annotations are activated */
public boolean suppresswarnings;
/** indicate if @@suppresswarning annotations should also suppress optional errors */
public boolean suppressoptionalerrors;
/** specify if should treat optional error as fatal or just like warning */
public boolean treatoptionalerrorasfatal;
/** specify if parser should perform structural recovery in methods */
public boolean performmethodsfullrecovery;
/** specify if parser perform statements recovery */
public boolean performstatementsrecovery;
/** control whether annotation processing is enabled */
public boolean processannotations;
/** store annotations */
public boolean storeannotations;
/** specify if need to report missing override annotation for a method implementing an interface method (java 1.6 and above)*/
public boolean reportmissingoverrideannotationforinterfacemethodimplementation;
/** indicate if annotation processing generates classfiles */
public boolean generateclassfiles;
/** indicate if method bodies should be ignored */
public boolean ignoremethodbodies;

// keep in sync with warningtokentoirritant and warningtokenfromirritant
public final static string[] warningtokens = {
"all", //$non-nls-1$
"boxing", //$non-nls-1$
"cast", //$non-nls-1$
"dep-ann", //$non-nls-1$
"deprecation", //$non-nls-1$
"fallthrough", //$non-nls-1$
"finally", //$non-nls-1$
"hiding", //$non-nls-1$
"incomplete-switch", //$non-nls-1$
"nls", //$non-nls-1$
"null", //$non-nls-1$
"restriction", //$non-nls-1$
"rawtypes", //$non-nls-1$
"serial", //$non-nls-1$
"static-access", //$non-nls-1$
"super", //$non-nls-1$
"synthetic-access", //$non-nls-1$
"unchecked", //$non-nls-1$
"unqualified-field-access", //$non-nls-1$
"unused", //$non-nls-1$
};

/**
* initializing the compiler options with defaults
*/
public compileroptions(){
this(null); // use default options
}

/**
* initializing the compiler options with external settings
* @@param settings
*/
public compileroptions(map settings){
resetdefaults();
if (settings != null) {
set(settings);
}
}

/**
* @@deprecated used to preserve 3.1 and 3.2m4 compatibility of some compiler constructors
*/
public compileroptions(map settings, boolean parseliteralexpressionsasconstants){
this(settings);
this.parseliteralexpressionsasconstants = parseliteralexpressionsasconstants;
}

/**
* return the most specific option key controlling this irritant. note that in some case, some irritant is controlled by
* other master options (e.g. javadoc, deprecation, etc.).
* this information is intended for grouping purpose (several problems governed by a rule)
*/
public static string optionkeyfromirritant(int irritant) {
// keep in sync with warningtokens and warningtokentoirritant
switch (irritant) {
case methodwithconstructorname :
return option_reportmethodwithconstructorname;
case overriddenpackagedefaultmethod  :
return option_reportoverridingpackagedefaultmethod;
case usingdeprecatedapi :
case (invalidjavadoc | usingdeprecatedapi) :
return option_reportdeprecation;
case maskedcatchblock  :
return option_reporthiddencatchblock;
case unusedlocalvariable :
return option_reportunusedlocal;
case unusedargument :
return option_reportunusedparameter;
case noimplicitstringconversion :
return option_reportnoimplicitstringconversion;
case accessemulation :
return option_reportsyntheticaccessemulation;
case nonexternalizedstring :
return option_reportnonexternalizedstringliteral;
case assertusedasanidentifier :
return option_reportassertidentifier;
case unusedimport :
return option_reportunusedimport;
case nonstaticaccesstostatic :
return option_reportnonstaticaccesstostatic;
case task :
return option_tasktags;
case noeffectassignment :
return option_reportnoeffectassignment;
case incompatiblenoninheritedinterfacemethod :
return option_reportincompatiblenoninheritedinterfacemethod;
case unusedprivatemember :
return option_reportunusedprivatemember;
case localvariablehiding :
return option_reportlocalvariablehiding;
case fieldhiding :
return option_reportfieldhiding;
case accidentalbooleanassign :
return option_reportpossibleaccidentalbooleanassignment;
case emptystatement :
return option_reportemptystatement;
case missingjavadoccomments  :
return option_reportmissingjavadoccomments;
case missingjavadoctags :
return option_reportmissingjavadoctags;
case unqualifiedfieldaccess :
return option_reportunqualifiedfieldaccess;
case unuseddeclaredthrownexception :
return option_reportunuseddeclaredthrownexceptionwhenoverriding;
case finallyblocknotcompleting :
return option_reportfinallyblocknotcompletingnormally;
case invalidjavadoc :
return option_reportinvalidjavadoc;
case unnecessarytypecheck :
return option_reportunnecessarytypecheck;
case undocumentedemptyblock :
return option_reportundocumentedemptyblock;
case indirectstaticaccess :
return option_reportindirectstaticaccess;
case unnecessaryelse  :
return option_reportunnecessaryelse;
case uncheckedtypeoperation :
return option_reportuncheckedtypeoperation;
case finalparameterbound :
return option_reportfinalparameterbound;
case missingserialversion :
return option_reportmissingserialversion ;
case enumusedasanidentifier :
return option_reportenumidentifier;
case forbiddenreference :
return option_reportforbiddenreference;
case varargsargumentneedcast :
return option_reportvarargsargumentneedcast;
case nullreference :
return option_reportnullreference;
case potentialnullreference :
return option_reportpotentialnullreference;
case redundantnullcheck :
return option_reportredundantnullcheck;
case autoboxing :
return option_reportautoboxing;
case annotationsuperinterface :
return option_reportannotationsuperinterface;
case typehiding :
return option_reporttypeparameterhiding;
case missingoverrideannotation :
return option_reportmissingoverrideannotation;
case incompleteenumswitch :
return option_reportincompleteenumswitch;
case missingdeprecatedannotation :
return option_reportmissingdeprecatedannotation;
case discouragedreference :
return option_reportdiscouragedreference;
case unhandledwarningtoken :
return option_reportunhandledwarningtoken;
case rawtypereference :
return option_reportrawtypereference;
case unusedlabel :
return option_reportunusedlabel;
case parameterassignment :
return option_reportparameterassignment;
case fallthroughcase :
return option_reportfallthroughcase;
case overridingmethodwithoutsuperinvocation :
return option_reportoverridingmethodwithoutsuperinvocation;
case missingjavadoctagdescription :
return option_reportmissingjavadoctagdescription;
case unusedtypearguments :
return option_reportunusedtypeargumentsformethodinvocation;
case unusedwarningtoken :
return option_reportunusedwarningtoken;
case redundantsuperinterface :
return option_reportredundantsuperinterface;
case comparingidentical :
return option_reportcomparingidentical;
case missingsynchronizedmodifierininheritedmethod :
return option_reportmissingsynchronizedoninheritedmethod;
case shouldimplementhashcode :
return option_reportmissinghashcodemethod;
case deadcode :
return option_reportdeadcode;
case unusedobjectallocation:
return option_reportunusedobjectallocation;
}
return null;
}

public static string versionfromjdklevel(long jdklevel) {
switch ((int)(jdklevel>>16)) {
case classfileconstants.major_version_1_1 :
if (jdklevel == classfileconstants.jdk1_1)
return version_1_1;
break;
case classfileconstants.major_version_1_2 :
if (jdklevel == classfileconstants.jdk1_2)
return version_1_2;
break;
case classfileconstants.major_version_1_3 :
if (jdklevel == classfileconstants.jdk1_3)
return version_1_3;
break;
case classfileconstants.major_version_1_4 :
if (jdklevel == classfileconstants.jdk1_4)
return version_1_4;
break;
case classfileconstants.major_version_1_5 :
if (jdklevel == classfileconstants.jdk1_5)
return version_1_5;
break;
case classfileconstants.major_version_1_6 :
if (jdklevel == classfileconstants.jdk1_6)
return version_1_6;
break;
case classfileconstants.major_version_1_7 :
if (jdklevel == classfileconstants.jdk1_7)
return version_1_7;
break;
}
return util.empty_string; // unknown version
}

public static long versiontojdklevel(object versionid) {
if (versionid instanceof string) {
string version = (string) versionid;
// verification is optimized for all versions with same length and same "1." prefix
if (version.length() == 3 && version.charat(0) == '1' && version.charat(1) == '.') {
switch (version.charat(2)) {
case '1':
return classfileconstants.jdk1_1;
case '2':
return classfileconstants.jdk1_2;
case '3':
return classfileconstants.jdk1_3;
case '4':
return classfileconstants.jdk1_4;
case '5':
return classfileconstants.jdk1_5;
case '6':
return classfileconstants.jdk1_6;
case '7':
return classfileconstants.jdk1_7;
default:
return 0; // unknown
}
}
if (version_jsr14.equals(versionid)) {
return classfileconstants.jdk1_4;
}
if (version_cldc1_1.equals(versionid)) {
return classfileconstants.cldc_1_1;
}
}
return 0; // unknown
}

/**
* return all warning option names for use as keys in compiler options maps.
* @@return all warning option names
* todo (maxime) revise for ensuring completeness
*/
public static string[] warningoptionnames() {
string[] result = {
option_reportannotationsuperinterface,
option_reportassertidentifier,
option_reportautoboxing,
option_reportdeadcode,
option_reportdeprecation,
option_reportdiscouragedreference,
option_reportemptystatement,
option_reportenumidentifier,
option_reportfallthroughcase,
option_reportfieldhiding,
option_reportfinalparameterbound,
option_reportfinallyblocknotcompletingnormally,
option_reportforbiddenreference,
option_reporthiddencatchblock,
option_reportincompatiblenoninheritedinterfacemethod,
option_reportincompleteenumswitch,
option_reportindirectstaticaccess,
option_reportinvalidjavadoc,
option_reportlocalvariablehiding,
option_reportmethodwithconstructorname,
option_reportmissingdeprecatedannotation,
option_reportmissingjavadoccomments,
option_reportmissingjavadoctagdescription,
option_reportmissingjavadoctags,
option_reportmissingoverrideannotation,
option_reportmissingserialversion,
option_reportnoeffectassignment,
option_reportnoimplicitstringconversion,
option_reportnonexternalizedstringliteral,
option_reportnonstaticaccesstostatic,
option_reportnullreference,
option_reportpotentialnullreference,
option_reportredundantnullcheck,
option_reportredundantsuperinterface,
option_reportoverridingpackagedefaultmethod,
option_reportparameterassignment,
option_reportpossibleaccidentalbooleanassignment,
option_reportsyntheticaccessemulation,
option_reporttypeparameterhiding,
option_reportuncheckedtypeoperation,
option_reportundocumentedemptyblock,
option_reportunnecessaryelse,
option_reportunnecessarytypecheck,
option_reportunqualifiedfieldaccess,
option_reportunuseddeclaredthrownexception,
option_reportunusedimport,
option_reportunusedlocal,
option_reportunusedobjectallocation,
option_reportunusedparameter,
option_reportunusedprivatemember,
option_reportvarargsargumentneedcast,
option_reportunhandledwarningtoken,
option_reportunusedwarningtoken,
option_reportoverridingmethodwithoutsuperinvocation,
option_reportunusedtypeargumentsformethodinvocation,
};
return result;
}

/**
* for suppressable warnings
*/
public static string warningtokenfromirritant(int irritant) {
// keep in sync with warningtokens and warningtokentoirritant
switch (irritant) {
case (invalidjavadoc | usingdeprecatedapi) :
case usingdeprecatedapi :
return "deprecation"; //$non-nls-1$
case finallyblocknotcompleting :
return "finally"; //$non-nls-1$
case fieldhiding :
case localvariablehiding :
case maskedcatchblock :
return "hiding"; //$non-nls-1$
case nonexternalizedstring :
return "nls"; //$non-nls-1$
case unnecessarytypecheck :
return "cast"; //$non-nls-1$
case indirectstaticaccess :
case nonstaticaccesstostatic :
return "static-access"; //$non-nls-1$
case accessemulation :
return "synthetic-access"; //$non-nls-1$
case unqualifiedfieldaccess :
return "unqualified-field-access"; //$non-nls-1$
case uncheckedtypeoperation :
return "unchecked"; //$non-nls-1$
case missingserialversion :
return "serial"; //$non-nls-1$
case autoboxing :
return "boxing"; //$non-nls-1$
case typehiding :
return "hiding"; //$non-nls-1$
case incompleteenumswitch :
return "incomplete-switch"; //$non-nls-1$
case missingdeprecatedannotation :
return "dep-ann"; //$non-nls-1$
case rawtypereference :
return "rawtypes"; //$non-nls-1$
case unusedlabel :
case unusedtypearguments :
case redundantsuperinterface :
case unusedlocalvariable :
case unusedargument :
case unusedimport :
case unusedprivatemember :
case unuseddeclaredthrownexception :
case deadcode :
case unusedobjectallocation :
return "unused"; //$non-nls-1$
case discouragedreference :
case forbiddenreference :
return "restriction"; //$non-nls-1$
case nullreference :
case potentialnullreference :
case redundantnullcheck :
return "null"; //$non-nls-1$
case fallthroughcase :
return "fallthrough"; //$non-nls-1$
case overridingmethodwithoutsuperinvocation :
return "super"; //$non-nls-1$
}
return null;
}

public static irritantset warningtokentoirritants(string warningtoken) {
// keep in sync with warningtokens and warningtokenfromirritant
if (warningtoken == null || warningtoken.length() == 0) return null;
switch (warningtoken.charat(0)) {
case 'a' :
if ("all".equals(warningtoken)) //$non-nls-1$
return irritantset.all;
break;
case 'b' :
if ("boxing".equals(warningtoken)) //$non-nls-1$
return irritantset.boxing;
break;
case 'c' :
if ("cast".equals(warningtoken)) //$non-nls-1$
return irritantset.cast;
break;
case 'd' :
if ("deprecation".equals(warningtoken)) //$non-nls-1$
return irritantset.deprecation;
if ("dep-ann".equals(warningtoken)) //$non-nls-1$
return irritantset.dep_ann;
break;
case 'f' :
if ("fallthrough".equals(warningtoken)) //$non-nls-1$
return irritantset.fallthrough;
if ("finally".equals(warningtoken)) //$non-nls-1$
return irritantset.finally;
break;
case 'h' :
if ("hiding".equals(warningtoken)) //$non-nls-1$
return irritantset.hiding;
break;
case 'i' :
if ("incomplete-switch".equals(warningtoken)) //$non-nls-1$
return irritantset.incomplete_switch;
break;
case 'n' :
if ("nls".equals(warningtoken)) //$non-nls-1$
return irritantset.nls;
if ("null".equals(warningtoken)) //$non-nls-1$
return irritantset.null;
break;
case 'r' :
if ("rawtypes".equals(warningtoken)) //$non-nls-1$
return irritantset.raw;
if ("restriction".equals(warningtoken)) //$non-nls-1$
return irritantset.restriction;
break;
case 's' :
if ("serial".equals(warningtoken)) //$non-nls-1$
return irritantset.serial;
if ("static-access".equals(warningtoken)) //$non-nls-1$
return irritantset.static_access;
if ("synthetic-access".equals(warningtoken)) //$non-nls-1$
return irritantset.synthetic_access;
if ("super".equals(warningtoken)) { //$non-nls-1$
return irritantset.super;
}
break;
case 'u' :
if ("unused".equals(warningtoken)) //$non-nls-1$
return irritantset.unused;
if ("unchecked".equals(warningtoken)) //$non-nls-1$
return irritantset.unchecked;
if ("unqualified-field-access".equals(warningtoken)) //$non-nls-1$
return irritantset.unqualified_field_access;
break;
}
return null;
}


public map getmap() {
map optionsmap = new hashmap(30);
optionsmap.put(option_localvariableattribute, (this.producedebugattributes & classfileconstants.attr_vars) != 0 ? generate : do_not_generate);
optionsmap.put(option_linenumberattribute, (this.producedebugattributes & classfileconstants.attr_lines) != 0 ? generate : do_not_generate);
optionsmap.put(option_sourcefileattribute, (this.producedebugattributes & classfileconstants.attr_source) != 0 ? generate : do_not_generate);
optionsmap.put(option_preserveunusedlocal, this.preservealllocalvariables ? preserve : optimize_out);
optionsmap.put(option_doccommentsupport, this.doccommentsupport ? enabled : disabled);
optionsmap.put(option_reportmethodwithconstructorname, getseveritystring(methodwithconstructorname));
optionsmap.put(option_reportoverridingpackagedefaultmethod, getseveritystring(overriddenpackagedefaultmethod));
optionsmap.put(option_reportdeprecation, getseveritystring(usingdeprecatedapi));
optionsmap.put(option_reportdeprecationindeprecatedcode, this.reportdeprecationinsidedeprecatedcode ? enabled : disabled);
optionsmap.put(option_reportdeprecationwhenoverridingdeprecatedmethod, this.reportdeprecationwhenoverridingdeprecatedmethod ? enabled : disabled);
optionsmap.put(option_reporthiddencatchblock, getseveritystring(maskedcatchblock));
optionsmap.put(option_reportunusedlocal, getseveritystring(unusedlocalvariable));
optionsmap.put(option_reportunusedparameter, getseveritystring(unusedargument));
optionsmap.put(option_reportunusedimport, getseveritystring(unusedimport));
optionsmap.put(option_reportsyntheticaccessemulation, getseveritystring(accessemulation));
optionsmap.put(option_reportnoeffectassignment, getseveritystring(noeffectassignment));
optionsmap.put(option_reportnonexternalizedstringliteral, getseveritystring(nonexternalizedstring));
optionsmap.put(option_reportnoimplicitstringconversion, getseveritystring(noimplicitstringconversion));
optionsmap.put(option_reportnonstaticaccesstostatic, getseveritystring(nonstaticaccesstostatic));
optionsmap.put(option_reportindirectstaticaccess, getseveritystring(indirectstaticaccess));
optionsmap.put(option_reportincompatiblenoninheritedinterfacemethod, getseveritystring(incompatiblenoninheritedinterfacemethod));
optionsmap.put(option_reportunusedprivatemember, getseveritystring(unusedprivatemember));
optionsmap.put(option_reportlocalvariablehiding, getseveritystring(localvariablehiding));
optionsmap.put(option_reportfieldhiding, getseveritystring(fieldhiding));
optionsmap.put(option_reporttypeparameterhiding, getseveritystring(typehiding));
optionsmap.put(option_reportpossibleaccidentalbooleanassignment, getseveritystring(accidentalbooleanassign));
optionsmap.put(option_reportemptystatement, getseveritystring(emptystatement));
optionsmap.put(option_reportassertidentifier, getseveritystring(assertusedasanidentifier));
optionsmap.put(option_reportenumidentifier, getseveritystring(enumusedasanidentifier));
optionsmap.put(option_reportundocumentedemptyblock, getseveritystring(undocumentedemptyblock));
optionsmap.put(option_reportunnecessarytypecheck, getseveritystring(unnecessarytypecheck));
optionsmap.put(option_reportunnecessaryelse, getseveritystring(unnecessaryelse));
optionsmap.put(option_reportautoboxing, getseveritystring(autoboxing));
optionsmap.put(option_reportannotationsuperinterface, getseveritystring(annotationsuperinterface));
optionsmap.put(option_reportincompleteenumswitch, getseveritystring(incompleteenumswitch));
optionsmap.put(option_reportinvalidjavadoc, getseveritystring(invalidjavadoc));
optionsmap.put(option_reportinvalidjavadoctagsvisibility, getvisibilitystring(this.reportinvalidjavadoctagsvisibility));
optionsmap.put(option_reportinvalidjavadoctags, this.reportinvalidjavadoctags ? enabled : disabled);
optionsmap.put(option_reportinvalidjavadoctagsdeprecatedref, this.reportinvalidjavadoctagsdeprecatedref ? enabled : disabled);
optionsmap.put(option_reportinvalidjavadoctagsnotvisibleref, this.reportinvalidjavadoctagsnotvisibleref ? enabled : disabled);
optionsmap.put(option_reportmissingjavadoctags, getseveritystring(missingjavadoctags));
optionsmap.put(option_reportmissingjavadoctagsvisibility, getvisibilitystring(this.reportmissingjavadoctagsvisibility));
optionsmap.put(option_reportmissingjavadoctagsoverriding, this.reportmissingjavadoctagsoverriding ? enabled : disabled);
optionsmap.put(option_reportmissingjavadoccomments, getseveritystring(missingjavadoccomments));
optionsmap.put(option_reportmissingjavadoctagdescription, this.reportmissingjavadoctagdescription);
optionsmap.put(option_reportmissingjavadoccommentsvisibility, getvisibilitystring(this.reportmissingjavadoccommentsvisibility));
optionsmap.put(option_reportmissingjavadoccommentsoverriding, this.reportmissingjavadoccommentsoverriding ? enabled : disabled);
optionsmap.put(option_reportfinallyblocknotcompletingnormally, getseveritystring(finallyblocknotcompleting));
optionsmap.put(option_reportunuseddeclaredthrownexception, getseveritystring(unuseddeclaredthrownexception));
optionsmap.put(option_reportunuseddeclaredthrownexceptionwhenoverriding, this.reportunuseddeclaredthrownexceptionwhenoverriding ? enabled : disabled);
optionsmap.put(option_reportunuseddeclaredthrownexceptionincludedoccommentreference, this.reportunuseddeclaredthrownexceptionincludedoccommentreference ? enabled : disabled);
optionsmap.put(option_reportunuseddeclaredthrownexceptionexemptexceptionandthrowable, this.reportunuseddeclaredthrownexceptionexemptexceptionandthrowable ? enabled : disabled);
optionsmap.put(option_reportunqualifiedfieldaccess, getseveritystring(unqualifiedfieldaccess));
optionsmap.put(option_reportuncheckedtypeoperation, getseveritystring(uncheckedtypeoperation));
optionsmap.put(option_reportrawtypereference, getseveritystring(rawtypereference));
optionsmap.put(option_reportfinalparameterbound, getseveritystring(finalparameterbound));
optionsmap.put(option_reportmissingserialversion, getseveritystring(missingserialversion));
optionsmap.put(option_reportforbiddenreference, getseveritystring(forbiddenreference));
optionsmap.put(option_reportdiscouragedreference, getseveritystring(discouragedreference));
optionsmap.put(option_reportvarargsargumentneedcast, getseveritystring(varargsargumentneedcast));
optionsmap.put(option_reportmissingoverrideannotation, getseveritystring(missingoverrideannotation));
optionsmap.put(option_reportmissingoverrideannotationforinterfacemethodimplementation, this.reportmissingoverrideannotationforinterfacemethodimplementation ? enabled : disabled);
optionsmap.put(option_reportmissingdeprecatedannotation, getseveritystring(missingdeprecatedannotation));
optionsmap.put(option_reportincompleteenumswitch, getseveritystring(incompleteenumswitch));
optionsmap.put(option_reportunusedlabel, getseveritystring(unusedlabel));
optionsmap.put(option_reportunusedtypeargumentsformethodinvocation, getseveritystring(unusedtypearguments));
optionsmap.put(option_compliance, versionfromjdklevel(this.compliancelevel));
optionsmap.put(option_source, versionfromjdklevel(this.sourcelevel));
optionsmap.put(option_targetplatform, versionfromjdklevel(this.targetjdk));
optionsmap.put(option_fataloptionalerror, this.treatoptionalerrorasfatal ? enabled : disabled);
if (this.defaultencoding != null) {
optionsmap.put(option_encoding, this.defaultencoding);
}
optionsmap.put(option_tasktags, this.tasktags == null ? util.empty_string : new string(charoperation.concatwith(this.tasktags,',')));
optionsmap.put(option_taskpriorities, this.taskpriorities == null ? util.empty_string : new string(charoperation.concatwith(this.taskpriorities,',')));
optionsmap.put(option_taskcasesensitive, this.istaskcasesensitive ? enabled : disabled);
optionsmap.put(option_reportunusedparameterwhenimplementingabstract, this.reportunusedparameterwhenimplementingabstract ? enabled : disabled);
optionsmap.put(option_reportunusedparameterwhenoverridingconcrete, this.reportunusedparameterwhenoverridingconcrete ? enabled : disabled);
optionsmap.put(option_reportunusedparameterincludedoccommentreference, this.reportunusedparameterincludedoccommentreference ? enabled : disabled);
optionsmap.put(option_reportspecialparameterhidingfield, this.reportspecialparameterhidingfield ? enabled : disabled);
optionsmap.put(option_maxproblemperunit, string.valueof(this.maxproblemsperunit));
optionsmap.put(option_inlinejsr, this.inlinejsrbytecode ? enabled : disabled);
optionsmap.put(option_reportnullreference, getseveritystring(nullreference));
optionsmap.put(option_reportpotentialnullreference, getseveritystring(potentialnullreference));
optionsmap.put(option_reportredundantnullcheck, getseveritystring(redundantnullcheck));
optionsmap.put(option_suppresswarnings, this.suppresswarnings ? enabled : disabled);
optionsmap.put(option_suppressoptionalerrors, this.suppressoptionalerrors ? enabled : disabled);
optionsmap.put(option_reportunhandledwarningtoken, getseveritystring(unhandledwarningtoken));
optionsmap.put(option_reportunusedwarningtoken, getseveritystring(unusedwarningtoken));
optionsmap.put(option_reportparameterassignment, getseveritystring(parameterassignment));
optionsmap.put(option_reportfallthroughcase, getseveritystring(fallthroughcase));
optionsmap.put(option_reportoverridingmethodwithoutsuperinvocation, getseveritystring(overridingmethodwithoutsuperinvocation));
optionsmap.put(option_generateclassfiles, this.generateclassfiles ? enabled : disabled);
optionsmap.put(option_process_annotations, this.processannotations ? enabled : disabled);
optionsmap.put(option_reportredundantsuperinterface, getseveritystring(redundantsuperinterface));
optionsmap.put(option_reportcomparingidentical, getseveritystring(comparingidentical));
optionsmap.put(option_reportmissingsynchronizedoninheritedmethod, getseveritystring(missingsynchronizedmodifierininheritedmethod));
optionsmap.put(option_reportmissinghashcodemethod, getseveritystring(shouldimplementhashcode));
optionsmap.put(option_reportdeadcode, getseveritystring(deadcode));
optionsmap.put(option_reportdeadcodeintrivialifstatement, this.reportdeadcodeintrivialifstatement ? enabled : disabled);
optionsmap.put(option_reporttasks, getseveritystring(tasks));
optionsmap.put(option_reportunusedobjectallocation, getseveritystring(unusedobjectallocation));
return optionsmap;
}

public int getseverity(int irritant) {
if (this.errorthreshold.isset(irritant)) {
if ((irritant & (irritantset.group_mask | unusedwarningtoken)) == unusedwarningtoken) {
return problemseverities.error | problemseverities.optional; // cannot be treated as fatal - codegen already occurred
}
return this.treatoptionalerrorasfatal
? problemseverities.error | problemseverities.optional | problemseverities.fatal
: problemseverities.error | problemseverities.optional;
}
if (this.warningthreshold.isset(irritant)) {
return problemseverities.warning | problemseverities.optional;
}
return problemseverities.ignore;
}

public string getseveritystring(int irritant) {
if(this.errorthreshold.isset(irritant))
return error;
if(this.warningthreshold.isset(irritant))
return warning;
return ignore;
}
public string getvisibilitystring(int level) {
switch (level & extracompilermodifiers.accvisibilitymask) {
case classfileconstants.accpublic:
return public;
case classfileconstants.accprotected:
return protected;
case classfileconstants.accprivate:
return private;
default:
return default;
}
}

public boolean isanyenabled(irritantset irritants) {
return this.warningthreshold.isanyset(irritants) || this.errorthreshold.isanyset(irritants);
}

protected void resetdefaults() {
// problem default severities defined on irritantset
this.errorthreshold = new irritantset(irritantset.compiler_default_errors);
this.warningthreshold = new irritantset(irritantset.compiler_default_warnings);

// by default only lines and source attributes are generated.
this.producedebugattributes = classfileconstants.attr_source | classfileconstants.attr_lines;
this.compliancelevel = classfileconstants.jdk1_4; // by default be compliant with 1.4
this.sourcelevel = classfileconstants.jdk1_3; //1.3 source behavior by default
this.targetjdk = classfileconstants.jdk1_2; // default generates for jvm1.2

this.defaultencoding = null; // will use the platform default encoding

// print what unit is being processed
this.verbose = compiler.debug;

this.producereferenceinfo = false; // no reference info by default

// indicates if unused/optimizable local variables need to be preserved (debugging purpose)
this.preservealllocalvariables = false;

// indicates whether literal expressions are inlined at parse-time or not
this.parseliteralexpressionsasconstants = true;

// max problems per compilation unit
this.maxproblemsperunit = 100; // no more than 100 problems per default

// tags used to recognize tasks in comments
this.tasktags = null;
this.taskpriorities = null;
this.istaskcasesensitive = true;

// deprecation report
this.reportdeprecationinsidedeprecatedcode = false;
this.reportdeprecationwhenoverridingdeprecatedmethod = false;

// unused parameters report
this.reportunusedparameterwhenimplementingabstract = false;
this.reportunusedparameterwhenoverridingconcrete = false;
this.reportunusedparameterincludedoccommentreference = true;

// unused declaration of thrown exception
this.reportunuseddeclaredthrownexceptionwhenoverriding = false;
this.reportunuseddeclaredthrownexceptionincludedoccommentreference = true;
this.reportunuseddeclaredthrownexceptionexemptexceptionandthrowable = true;

// constructor/setter parameter hiding
this.reportspecialparameterhidingfield = false;

// check javadoc comments tags
this.reportinvalidjavadoctagsvisibility = classfileconstants.accpublic;
this.reportinvalidjavadoctags = false;
this.reportinvalidjavadoctagsdeprecatedref = false;
this.reportinvalidjavadoctagsnotvisibleref = false;
this.reportmissingjavadoctagdescription = return_tag;

// check missing javadoc tags
this.reportmissingjavadoctagsvisibility = classfileconstants.accpublic;
this.reportmissingjavadoctagsoverriding = false;

// check missing javadoc comments
this.reportmissingjavadoccommentsvisibility = classfileconstants.accpublic;
this.reportmissingjavadoccommentsoverriding = false;

// jsr bytecode inlining
this.inlinejsrbytecode = false;

// javadoc comment support
this.doccommentsupport = false;

// suppress warning annotation
this.suppresswarnings = true;

// suppress also optional errors
this.suppressoptionalerrors = false;

// treat optional error as non fatal
this.treatoptionalerrorasfatal = false;

// parser perform statements recovery
this.performmethodsfullrecovery = true;

// parser perform statements recovery
this.performstatementsrecovery = true;

// store annotations
this.storeannotations = false;

// annotation processing
this.generateclassfiles = true;

// enable annotation processing by default only in batch mode
this.processannotations = false;

// disable missing override annotation reporting for interface method implementation
this.reportmissingoverrideannotationforinterfacemethodimplementation = true;

// dead code detection
this.reportdeadcodeintrivialifstatement = false;

// ignore method bodies
this.ignoremethodbodies = false;
}

public void set(map optionsmap) {
object optionvalue;
if ((optionvalue = optionsmap.get(option_localvariableattribute)) != null) {
if (generate.equals(optionvalue)) {
this.producedebugattributes |= classfileconstants.attr_vars;
} else if (do_not_generate.equals(optionvalue)) {
this.producedebugattributes &= ~classfileconstants.attr_vars;
}
}
if ((optionvalue = optionsmap.get(option_linenumberattribute)) != null) {
if (generate.equals(optionvalue)) {
this.producedebugattributes |= classfileconstants.attr_lines;
} else if (do_not_generate.equals(optionvalue)) {
this.producedebugattributes &= ~classfileconstants.attr_lines;
}
}
if ((optionvalue = optionsmap.get(option_sourcefileattribute)) != null) {
if (generate.equals(optionvalue)) {
this.producedebugattributes |= classfileconstants.attr_source;
} else if (do_not_generate.equals(optionvalue)) {
this.producedebugattributes &= ~classfileconstants.attr_source;
}
}
if ((optionvalue = optionsmap.get(option_preserveunusedlocal)) != null) {
if (preserve.equals(optionvalue)) {
this.preservealllocalvariables = true;
} else if (optimize_out.equals(optionvalue)) {
this.preservealllocalvariables = false;
}
}
if ((optionvalue = optionsmap.get(option_reportdeprecationindeprecatedcode)) != null) {
if (enabled.equals(optionvalue)) {
this.reportdeprecationinsidedeprecatedcode = true;
} else if (disabled.equals(optionvalue)) {
this.reportdeprecationinsidedeprecatedcode = false;
}
}
if ((optionvalue = optionsmap.get(option_reportdeprecationwhenoverridingdeprecatedmethod)) != null) {
if (enabled.equals(optionvalue)) {
this.reportdeprecationwhenoverridingdeprecatedmethod = true;
} else if (disabled.equals(optionvalue)) {
this.reportdeprecationwhenoverridingdeprecatedmethod = false;
}
}
if ((optionvalue = optionsmap.get(option_reportunuseddeclaredthrownexceptionwhenoverriding)) != null) {
if (enabled.equals(optionvalue)) {
this.reportunuseddeclaredthrownexceptionwhenoverriding = true;
} else if (disabled.equals(optionvalue)) {
this.reportunuseddeclaredthrownexceptionwhenoverriding = false;
}
}
if ((optionvalue = optionsmap.get(option_reportunuseddeclaredthrownexceptionincludedoccommentreference)) != null) {
if (enabled.equals(optionvalue)) {
this.reportunuseddeclaredthrownexceptionincludedoccommentreference = true;
} else if (disabled.equals(optionvalue)) {
this.reportunuseddeclaredthrownexceptionincludedoccommentreference = false;
}
}
if ((optionvalue = optionsmap.get(option_reportunuseddeclaredthrownexceptionexemptexceptionandthrowable)) != null) {
if (enabled.equals(optionvalue)) {
this.reportunuseddeclaredthrownexceptionexemptexceptionandthrowable = true;
} else if (disabled.equals(optionvalue)) {
this.reportunuseddeclaredthrownexceptionexemptexceptionandthrowable = false;
}
}
if ((optionvalue = optionsmap.get(option_compliance)) != null) {
long level = versiontojdklevel(optionvalue);
if (level != 0) this.compliancelevel = level;
}
if ((optionvalue = optionsmap.get(option_source)) != null) {
long level = versiontojdklevel(optionvalue);
if (level != 0) this.sourcelevel = level;
}
if ((optionvalue = optionsmap.get(option_targetplatform)) != null) {
long level = versiontojdklevel(optionvalue);
if (level != 0) {
this.targetjdk = level;
}
if (this.targetjdk >= classfileconstants.jdk1_5) this.inlinejsrbytecode = true; // forced from 1.5 mode on
}
if ((optionvalue = optionsmap.get(option_encoding)) != null) {
if (optionvalue instanceof string) {
this.defaultencoding = null;
string stringvalue = (string) optionvalue;
if (stringvalue.length() > 0){
try {
new inputstreamreader(new bytearrayinputstream(new byte[0]), stringvalue);
this.defaultencoding = stringvalue;
} catch(unsupportedencodingexception e){
// ignore unsupported encoding
}
}
}
}
if ((optionvalue = optionsmap.get(option_reportunusedparameterwhenimplementingabstract)) != null) {
if (enabled.equals(optionvalue)) {
this.reportunusedparameterwhenimplementingabstract = true;
} else if (disabled.equals(optionvalue)) {
this.reportunusedparameterwhenimplementingabstract = false;
}
}
if ((optionvalue = optionsmap.get(option_reportunusedparameterwhenoverridingconcrete)) != null) {
if (enabled.equals(optionvalue)) {
this.reportunusedparameterwhenoverridingconcrete = true;
} else if (disabled.equals(optionvalue)) {
this.reportunusedparameterwhenoverridingconcrete = false;
}
}
if ((optionvalue = optionsmap.get(option_reportunusedparameterincludedoccommentreference)) != null) {
if (enabled.equals(optionvalue)) {
this.reportunusedparameterincludedoccommentreference = true;
} else if (disabled.equals(optionvalue)) {
this.reportunusedparameterincludedoccommentreference = false;
}
}
if ((optionvalue = optionsmap.get(option_reportspecialparameterhidingfield)) != null) {
if (enabled.equals(optionvalue)) {
this.reportspecialparameterhidingfield = true;
} else if (disabled.equals(optionvalue)) {
this.reportspecialparameterhidingfield = false;
}
}
if ((optionvalue = optionsmap.get(option_reportdeadcodeintrivialifstatement )) != null) {
if (enabled.equals(optionvalue)) {
this.reportdeadcodeintrivialifstatement = true;
} else if (disabled.equals(optionvalue)) {
this.reportdeadcodeintrivialifstatement = false;
}
}
if ((optionvalue = optionsmap.get(option_maxproblemperunit)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
try {
int val = integer.parseint(stringvalue);
if (val >= 0) this.maxproblemsperunit = val;
} catch(numberformatexception e){
// ignore ill-formatted limit
}
}
}
if ((optionvalue = optionsmap.get(option_tasktags)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() == 0) {
this.tasktags = null;
} else {
this.tasktags = charoperation.splitandtrimon(',', stringvalue.tochararray());
}
}
}
if ((optionvalue = optionsmap.get(option_taskpriorities)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() == 0) {
this.taskpriorities = null;
} else {
this.taskpriorities = charoperation.splitandtrimon(',', stringvalue.tochararray());
}
}
}
if ((optionvalue = optionsmap.get(option_taskcasesensitive)) != null) {
if (enabled.equals(optionvalue)) {
this.istaskcasesensitive = true;
} else if (disabled.equals(optionvalue)) {
this.istaskcasesensitive = false;
}
}
if ((optionvalue = optionsmap.get(option_inlinejsr)) != null) {
if (this.targetjdk < classfileconstants.jdk1_5) { // only optional if target < 1.5 (inlining on from 1.5 on)
if (enabled.equals(optionvalue)) {
this.inlinejsrbytecode = true;
} else if (disabled.equals(optionvalue)) {
this.inlinejsrbytecode = false;
}
}
}
if ((optionvalue = optionsmap.get(option_suppresswarnings)) != null) {
if (enabled.equals(optionvalue)) {
this.suppresswarnings = true;
} else if (disabled.equals(optionvalue)) {
this.suppresswarnings = false;
}
}
if ((optionvalue = optionsmap.get(option_suppressoptionalerrors)) != null) {
if (enabled.equals(optionvalue)) {
this.suppressoptionalerrors = true;
} else if (disabled.equals(optionvalue)) {
this.suppressoptionalerrors = false;
}
}
if ((optionvalue = optionsmap.get(option_fataloptionalerror)) != null) {
if (enabled.equals(optionvalue)) {
this.treatoptionalerrorasfatal = true;
} else if (disabled.equals(optionvalue)) {
this.treatoptionalerrorasfatal = false;
}
}
if ((optionvalue = optionsmap.get(option_reportmissingoverrideannotationforinterfacemethodimplementation)) != null) {
if (enabled.equals(optionvalue)) {
this.reportmissingoverrideannotationforinterfacemethodimplementation = true;
} else if (disabled.equals(optionvalue)) {
this.reportmissingoverrideannotationforinterfacemethodimplementation = false;
}
}
if ((optionvalue = optionsmap.get(option_reportmethodwithconstructorname)) != null) updateseverity(methodwithconstructorname, optionvalue);
if ((optionvalue = optionsmap.get(option_reportoverridingpackagedefaultmethod)) != null) updateseverity(overriddenpackagedefaultmethod, optionvalue);
if ((optionvalue = optionsmap.get(option_reportdeprecation)) != null) updateseverity(usingdeprecatedapi, optionvalue);
if ((optionvalue = optionsmap.get(option_reporthiddencatchblock)) != null) updateseverity(maskedcatchblock, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunusedlocal)) != null) updateseverity(unusedlocalvariable, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunusedparameter)) != null) updateseverity(unusedargument, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunusedimport)) != null) updateseverity(unusedimport, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunusedprivatemember)) != null) updateseverity(unusedprivatemember, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunuseddeclaredthrownexception)) != null) updateseverity(unuseddeclaredthrownexception, optionvalue);
if ((optionvalue = optionsmap.get(option_reportnoimplicitstringconversion)) != null) updateseverity(noimplicitstringconversion, optionvalue);
if ((optionvalue = optionsmap.get(option_reportsyntheticaccessemulation)) != null) updateseverity(accessemulation, optionvalue);
if ((optionvalue = optionsmap.get(option_reportlocalvariablehiding)) != null) updateseverity(localvariablehiding, optionvalue);
if ((optionvalue = optionsmap.get(option_reportfieldhiding)) != null) updateseverity(fieldhiding, optionvalue);
if ((optionvalue = optionsmap.get(option_reporttypeparameterhiding)) != null) updateseverity(typehiding, optionvalue);
if ((optionvalue = optionsmap.get(option_reportpossibleaccidentalbooleanassignment)) != null) updateseverity(accidentalbooleanassign, optionvalue);
if ((optionvalue = optionsmap.get(option_reportemptystatement)) != null) updateseverity(emptystatement, optionvalue);
if ((optionvalue = optionsmap.get(option_reportnonexternalizedstringliteral)) != null) updateseverity(nonexternalizedstring, optionvalue);
if ((optionvalue = optionsmap.get(option_reportassertidentifier)) != null) updateseverity(assertusedasanidentifier, optionvalue);
if ((optionvalue = optionsmap.get(option_reportenumidentifier)) != null) updateseverity(enumusedasanidentifier, optionvalue);
if ((optionvalue = optionsmap.get(option_reportnonstaticaccesstostatic)) != null) updateseverity(nonstaticaccesstostatic, optionvalue);
if ((optionvalue = optionsmap.get(option_reportindirectstaticaccess)) != null) updateseverity(indirectstaticaccess, optionvalue);
if ((optionvalue = optionsmap.get(option_reportincompatiblenoninheritedinterfacemethod)) != null) updateseverity(incompatiblenoninheritedinterfacemethod, optionvalue);
if ((optionvalue = optionsmap.get(option_reportundocumentedemptyblock)) != null) updateseverity(undocumentedemptyblock, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunnecessarytypecheck)) != null) updateseverity(unnecessarytypecheck, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunnecessaryelse)) != null) updateseverity(unnecessaryelse, optionvalue);
if ((optionvalue = optionsmap.get(option_reportfinallyblocknotcompletingnormally)) != null) updateseverity(finallyblocknotcompleting, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunqualifiedfieldaccess)) != null) updateseverity(unqualifiedfieldaccess, optionvalue);
if ((optionvalue = optionsmap.get(option_reportnoeffectassignment)) != null) updateseverity(noeffectassignment, optionvalue);
if ((optionvalue = optionsmap.get(option_reportuncheckedtypeoperation)) != null) updateseverity(uncheckedtypeoperation, optionvalue);
if ((optionvalue = optionsmap.get(option_reportrawtypereference)) != null) updateseverity(rawtypereference, optionvalue);
if ((optionvalue = optionsmap.get(option_reportfinalparameterbound)) != null) updateseverity(finalparameterbound, optionvalue);
if ((optionvalue = optionsmap.get(option_reportmissingserialversion)) != null) updateseverity(missingserialversion, optionvalue);
if ((optionvalue = optionsmap.get(option_reportforbiddenreference)) != null) updateseverity(forbiddenreference, optionvalue);
if ((optionvalue = optionsmap.get(option_reportdiscouragedreference)) != null) updateseverity(discouragedreference, optionvalue);
if ((optionvalue = optionsmap.get(option_reportvarargsargumentneedcast)) != null) updateseverity(varargsargumentneedcast, optionvalue);
if ((optionvalue = optionsmap.get(option_reportnullreference)) != null) updateseverity(nullreference, optionvalue);
if ((optionvalue = optionsmap.get(option_reportpotentialnullreference)) != null) updateseverity(potentialnullreference, optionvalue);
if ((optionvalue = optionsmap.get(option_reportredundantnullcheck)) != null) updateseverity(redundantnullcheck, optionvalue);
if ((optionvalue = optionsmap.get(option_reportautoboxing)) != null) updateseverity(autoboxing, optionvalue);
if ((optionvalue = optionsmap.get(option_reportannotationsuperinterface)) != null) updateseverity(annotationsuperinterface, optionvalue);
if ((optionvalue = optionsmap.get(option_reportmissingoverrideannotation)) != null) updateseverity(missingoverrideannotation, optionvalue);
if ((optionvalue = optionsmap.get(option_reportmissingdeprecatedannotation)) != null) updateseverity(missingdeprecatedannotation, optionvalue);
if ((optionvalue = optionsmap.get(option_reportincompleteenumswitch)) != null) updateseverity(incompleteenumswitch, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunhandledwarningtoken)) != null) updateseverity(unhandledwarningtoken, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunusedwarningtoken)) != null) updateseverity(unusedwarningtoken, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunusedlabel)) != null) updateseverity(unusedlabel, optionvalue);
if ((optionvalue = optionsmap.get(option_reportparameterassignment)) != null) updateseverity(parameterassignment, optionvalue);
if ((optionvalue = optionsmap.get(option_reportfallthroughcase)) != null) updateseverity(fallthroughcase, optionvalue);
if ((optionvalue = optionsmap.get(option_reportoverridingmethodwithoutsuperinvocation)) != null) updateseverity(overridingmethodwithoutsuperinvocation, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunusedtypeargumentsformethodinvocation)) != null) updateseverity(unusedtypearguments, optionvalue);
if ((optionvalue = optionsmap.get(option_reportredundantsuperinterface)) != null) updateseverity(redundantsuperinterface, optionvalue);
if ((optionvalue = optionsmap.get(option_reportcomparingidentical)) != null) updateseverity(comparingidentical, optionvalue);
if ((optionvalue = optionsmap.get(option_reportmissingsynchronizedoninheritedmethod)) != null) updateseverity(missingsynchronizedmodifierininheritedmethod, optionvalue);
if ((optionvalue = optionsmap.get(option_reportmissinghashcodemethod)) != null) updateseverity(shouldimplementhashcode, optionvalue);
if ((optionvalue = optionsmap.get(option_reportdeadcode)) != null) updateseverity(deadcode, optionvalue);
if ((optionvalue = optionsmap.get(option_reporttasks)) != null) updateseverity(tasks, optionvalue);
if ((optionvalue = optionsmap.get(option_reportunusedobjectallocation)) != null) updateseverity(unusedobjectallocation, optionvalue);

// javadoc options
if ((optionvalue = optionsmap.get(option_doccommentsupport)) != null) {
if (enabled.equals(optionvalue)) {
this.doccommentsupport = true;
} else if (disabled.equals(optionvalue)) {
this.doccommentsupport = false;
}
}
if ((optionvalue = optionsmap.get(option_reportinvalidjavadoc)) != null) {
updateseverity(invalidjavadoc, optionvalue);
}
if ( (optionvalue = optionsmap.get(option_reportinvalidjavadoctagsvisibility)) != null) {
if (public.equals(optionvalue)) {
this.reportinvalidjavadoctagsvisibility = classfileconstants.accpublic;
} else if (protected.equals(optionvalue)) {
this.reportinvalidjavadoctagsvisibility = classfileconstants.accprotected;
} else if (default.equals(optionvalue)) {
this.reportinvalidjavadoctagsvisibility = classfileconstants.accdefault;
} else if (private.equals(optionvalue)) {
this.reportinvalidjavadoctagsvisibility = classfileconstants.accprivate;
}
}
if ((optionvalue = optionsmap.get(option_reportinvalidjavadoctags)) != null) {
if (enabled.equals(optionvalue)) {
this.reportinvalidjavadoctags = true;
} else if (disabled.equals(optionvalue)) {
this.reportinvalidjavadoctags = false;
}
}
if ((optionvalue = optionsmap.get(option_reportinvalidjavadoctagsdeprecatedref)) != null) {
if (enabled.equals(optionvalue)) {
this.reportinvalidjavadoctagsdeprecatedref = true;
} else if (disabled.equals(optionvalue)) {
this.reportinvalidjavadoctagsdeprecatedref = false;
}
}
if ((optionvalue = optionsmap.get(option_reportinvalidjavadoctagsnotvisibleref)) != null) {
if (enabled.equals(optionvalue)) {
this.reportinvalidjavadoctagsnotvisibleref = true;
} else if (disabled.equals(optionvalue)) {
this.reportinvalidjavadoctagsnotvisibleref = false;
}
}
if ((optionvalue = optionsmap.get(option_reportmissingjavadoctags)) != null) {
updateseverity(missingjavadoctags, optionvalue);
}
if ((optionvalue = optionsmap.get(option_reportmissingjavadoctagsvisibility)) != null) {
if (public.equals(optionvalue)) {
this.reportmissingjavadoctagsvisibility = classfileconstants.accpublic;
} else if (protected.equals(optionvalue)) {
this.reportmissingjavadoctagsvisibility = classfileconstants.accprotected;
} else if (default.equals(optionvalue)) {
this.reportmissingjavadoctagsvisibility = classfileconstants.accdefault;
} else if (private.equals(optionvalue)) {
this.reportmissingjavadoctagsvisibility = classfileconstants.accprivate;
}
}
if ((optionvalue = optionsmap.get(option_reportmissingjavadoctagsoverriding)) != null) {
if (enabled.equals(optionvalue)) {
this.reportmissingjavadoctagsoverriding = true;
} else if (disabled.equals(optionvalue)) {
this.reportmissingjavadoctagsoverriding = false;
}
}
if ((optionvalue = optionsmap.get(option_reportmissingjavadoccomments)) != null) {
updateseverity(missingjavadoccomments, optionvalue);
}
if ((optionvalue = optionsmap.get(option_reportmissingjavadoctagdescription)) != null) {
this.reportmissingjavadoctagdescription = (string) optionvalue;
}
if ((optionvalue = optionsmap.get(option_reportmissingjavadoccommentsvisibility)) != null) {
if (public.equals(optionvalue)) {
this.reportmissingjavadoccommentsvisibility = classfileconstants.accpublic;
} else if (protected.equals(optionvalue)) {
this.reportmissingjavadoccommentsvisibility = classfileconstants.accprotected;
} else if (default.equals(optionvalue)) {
this.reportmissingjavadoccommentsvisibility = classfileconstants.accdefault;
} else if (private.equals(optionvalue)) {
this.reportmissingjavadoccommentsvisibility = classfileconstants.accprivate;
}
}
if ((optionvalue = optionsmap.get(option_reportmissingjavadoccommentsoverriding)) != null) {
if (enabled.equals(optionvalue)) {
this.reportmissingjavadoccommentsoverriding = true;
} else if (disabled.equals(optionvalue)) {
this.reportmissingjavadoccommentsoverriding = false;
}
}
if ((optionvalue = optionsmap.get(option_generateclassfiles)) != null) {
if (enabled.equals(optionvalue)) {
this.generateclassfiles = true;
} else if (disabled.equals(optionvalue)) {
this.generateclassfiles = false;
}
}
if ((optionvalue = optionsmap.get(option_process_annotations)) != null) {
if (enabled.equals(optionvalue)) {
this.processannotations = true;
this.storeannotations = true; // annotation processing requires annotation to be stored
this.doccommentsupport = true;  // annotation processing requires javadoc processing
} else if (disabled.equals(optionvalue)) {
this.processannotations = false;
this.storeannotations = false;
}
}
}
public string tostring() {
stringbuffer buf = new stringbuffer("compileroptions:"); //$non-nls-1$
buf.append("\n\t- local variables debug attributes: ").append((this.producedebugattributes & classfileconstants.attr_vars) != 0 ? "on" : " off"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
buf.append("\n\t- line number debug attributes: ").append((this.producedebugattributes & classfileconstants.attr_lines) != 0 ? "on" : " off"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
buf.append("\n\t- source debug attributes: ").append((this.producedebugattributes & classfileconstants.attr_source) != 0 ? "on" : " off"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
buf.append("\n\t- preserve all local variables: ").append(this.preservealllocalvariables ? "on" : " off"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
buf.append("\n\t- method with constructor name: ").append(getseveritystring(methodwithconstructorname)); //$non-nls-1$
buf.append("\n\t- overridden package default method: ").append(getseveritystring(overriddenpackagedefaultmethod)); //$non-nls-1$
buf.append("\n\t- deprecation: ").append(getseveritystring(usingdeprecatedapi)); //$non-nls-1$
buf.append("\n\t- masked catch block: ").append(getseveritystring(maskedcatchblock)); //$non-nls-1$
buf.append("\n\t- unused local variable: ").append(getseveritystring(unusedlocalvariable)); //$non-nls-1$
buf.append("\n\t- unused parameter: ").append(getseveritystring(unusedargument)); //$non-nls-1$
buf.append("\n\t- unused import: ").append(getseveritystring(unusedimport)); //$non-nls-1$
buf.append("\n\t- synthetic access emulation: ").append(getseveritystring(accessemulation)); //$non-nls-1$
buf.append("\n\t- assignment with no effect: ").append(getseveritystring(noeffectassignment)); //$non-nls-1$
buf.append("\n\t- non externalized string: ").append(getseveritystring(nonexternalizedstring)); //$non-nls-1$
buf.append("\n\t- static access receiver: ").append(getseveritystring(nonstaticaccesstostatic)); //$non-nls-1$
buf.append("\n\t- indirect static access: ").append(getseveritystring(indirectstaticaccess)); //$non-nls-1$
buf.append("\n\t- incompatible non inherited interface method: ").append(getseveritystring(incompatiblenoninheritedinterfacemethod)); //$non-nls-1$
buf.append("\n\t- unused private member: ").append(getseveritystring(unusedprivatemember)); //$non-nls-1$
buf.append("\n\t- local variable hiding another variable: ").append(getseveritystring(localvariablehiding)); //$non-nls-1$
buf.append("\n\t- field hiding another variable: ").append(getseveritystring(fieldhiding)); //$non-nls-1$
buf.append("\n\t- type hiding another type: ").append(getseveritystring(typehiding)); //$non-nls-1$
buf.append("\n\t- possible accidental boolean assignment: ").append(getseveritystring(accidentalbooleanassign)); //$non-nls-1$
buf.append("\n\t- superfluous semicolon: ").append(getseveritystring(emptystatement)); //$non-nls-1$
buf.append("\n\t- uncommented empty block: ").append(getseveritystring(undocumentedemptyblock)); //$non-nls-1$
buf.append("\n\t- unnecessary type check: ").append(getseveritystring(unnecessarytypecheck)); //$non-nls-1$
buf.append("\n\t- javadoc comment support: ").append(this.doccommentsupport ? "on" : " off"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
buf.append("\n\t\t+ invalid javadoc: ").append(getseveritystring(invalidjavadoc)); //$non-nls-1$
buf.append("\n\t\t+ report invalid javadoc tags: ").append(this.reportinvalidjavadoctags ? enabled : disabled); //$non-nls-1$
buf.append("\n\t\t\t* deprecated references: ").append(this.reportinvalidjavadoctagsdeprecatedref ? enabled : disabled); //$non-nls-1$
buf.append("\n\t\t\t* not visible references: ").append(this.reportinvalidjavadoctagsnotvisibleref ? enabled : disabled); //$non-nls-1$
buf.append("\n\t\t+ visibility level to report invalid javadoc tags: ").append(getvisibilitystring(this.reportinvalidjavadoctagsvisibility)); //$non-nls-1$
buf.append("\n\t\t+ missing javadoc tags: ").append(getseveritystring(missingjavadoctags)); //$non-nls-1$
buf.append("\n\t\t+ visibility level to report missing javadoc tags: ").append(getvisibilitystring(this.reportmissingjavadoctagsvisibility)); //$non-nls-1$
buf.append("\n\t\t+ report missing javadoc tags in overriding methods: ").append(this.reportmissingjavadoctagsoverriding ? enabled : disabled); //$non-nls-1$
buf.append("\n\t\t+ missing javadoc comments: ").append(getseveritystring(missingjavadoccomments)); //$non-nls-1$
buf.append("\n\t\t+ report missing tag description option: ").append(this.reportmissingjavadoctagdescription); //$non-nls-1$
buf.append("\n\t\t+ visibility level to report missing javadoc comments: ").append(getvisibilitystring(this.reportmissingjavadoccommentsvisibility)); //$non-nls-1$
buf.append("\n\t\t+ report missing javadoc comments in overriding methods: ").append(this.reportmissingjavadoccommentsoverriding ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- finally block not completing normally: ").append(getseveritystring(finallyblocknotcompleting)); //$non-nls-1$
buf.append("\n\t- report unused declared thrown exception: ").append(getseveritystring(unuseddeclaredthrownexception)); //$non-nls-1$
buf.append("\n\t- report unused declared thrown exception when overriding: ").append(this.reportunuseddeclaredthrownexceptionwhenoverriding ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- report unused declared thrown exception include doc comment reference: ").append(this.reportunuseddeclaredthrownexceptionincludedoccommentreference ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- report unused declared thrown exception exempt exception and throwable: ").append(this.reportunuseddeclaredthrownexceptionexemptexceptionandthrowable ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- unnecessary else: ").append(getseveritystring(unnecessaryelse)); //$non-nls-1$
buf.append("\n\t- jdk compliance level: "+ versionfromjdklevel(this.compliancelevel)); //$non-nls-1$
buf.append("\n\t- jdk source level: "+ versionfromjdklevel(this.sourcelevel)); //$non-nls-1$
buf.append("\n\t- jdk target level: "+ versionfromjdklevel(this.targetjdk)); //$non-nls-1$
buf.append("\n\t- verbose : ").append(this.verbose ? "on" : "off"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
buf.append("\n\t- produce reference info : ").append(this.producereferenceinfo ? "on" : "off"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
buf.append("\n\t- parse literal expressions as constants : ").append(this.parseliteralexpressionsasconstants ? "on" : "off"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
buf.append("\n\t- encoding : ").append(this.defaultencoding == null ? "<default>" : this.defaultencoding); //$non-nls-1$ //$non-nls-2$
buf.append("\n\t- task tags: ").append(this.tasktags == null ? util.empty_string : new string(charoperation.concatwith(this.tasktags,',')));  //$non-nls-1$
buf.append("\n\t- task priorities : ").append(this.taskpriorities == null ? util.empty_string : new string(charoperation.concatwith(this.taskpriorities,','))); //$non-nls-1$
buf.append("\n\t- report deprecation inside deprecated code : ").append(this.reportdeprecationinsidedeprecatedcode ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- report deprecation when overriding deprecated method : ").append(this.reportdeprecationwhenoverridingdeprecatedmethod ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- report unused parameter when implementing abstract method : ").append(this.reportunusedparameterwhenimplementingabstract ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- report unused parameter when overriding concrete method : ").append(this.reportunusedparameterwhenoverridingconcrete ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- report unused parameter include doc comment reference : ").append(this.reportunusedparameterincludedoccommentreference ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- report constructor/setter parameter hiding existing field : ").append(this.reportspecialparameterhidingfield ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- inline jsr bytecode : ").append(this.inlinejsrbytecode ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- unsafe type operation: ").append(getseveritystring(uncheckedtypeoperation)); //$non-nls-1$
buf.append("\n\t- unsafe raw type: ").append(getseveritystring(rawtypereference)); //$non-nls-1$
buf.append("\n\t- final bound for type parameter: ").append(getseveritystring(finalparameterbound)); //$non-nls-1$
buf.append("\n\t- missing serialversionuid: ").append(getseveritystring(missingserialversion)); //$non-nls-1$
buf.append("\n\t- varargs argument need cast: ").append(getseveritystring(varargsargumentneedcast)); //$non-nls-1$
buf.append("\n\t- forbidden reference to type with access restriction: ").append(getseveritystring(forbiddenreference)); //$non-nls-1$
buf.append("\n\t- discouraged reference to type with access restriction: ").append(getseveritystring(discouragedreference)); //$non-nls-1$
buf.append("\n\t- null reference: ").append(getseveritystring(nullreference)); //$non-nls-1$
buf.append("\n\t- potential null reference: ").append(getseveritystring(potentialnullreference)); //$non-nls-1$
buf.append("\n\t- redundant null check: ").append(getseveritystring(redundantnullcheck)); //$non-nls-1$
buf.append("\n\t- autoboxing: ").append(getseveritystring(autoboxing)); //$non-nls-1$
buf.append("\n\t- annotation super interface: ").append(getseveritystring(annotationsuperinterface)); //$non-nls-1$
buf.append("\n\t- missing @@override annotation: ").append(getseveritystring(missingoverrideannotation)); //$non-nls-1$
buf.append("\n\t- missing @@override annotation for interface method implementation: ").append(this.reportmissingoverrideannotationforinterfacemethodimplementation ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- missing @@deprecated annotation: ").append(getseveritystring(missingdeprecatedannotation)); //$non-nls-1$
buf.append("\n\t- incomplete enum switch: ").append(getseveritystring(incompleteenumswitch)); //$non-nls-1$
buf.append("\n\t- suppress warnings: ").append(this.suppresswarnings ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- suppress optional errors: ").append(this.suppressoptionalerrors ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- unhandled warning token: ").append(getseveritystring(unhandledwarningtoken)); //$non-nls-1$
buf.append("\n\t- unused warning token: ").append(getseveritystring(unusedwarningtoken)); //$non-nls-1$
buf.append("\n\t- unused label: ").append(getseveritystring(unusedlabel)); //$non-nls-1$
buf.append("\n\t- treat optional error as fatal: ").append(this.treatoptionalerrorasfatal ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- parameter assignment: ").append(getseveritystring(parameterassignment)); //$non-nls-1$
buf.append("\n\t- generate class files: ").append(this.generateclassfiles ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- process annotations: ").append(this.processannotations ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- unused type arguments for method/constructor invocation: ").append(getseveritystring(unusedtypearguments)); //$non-nls-1$
buf.append("\n\t- redundant superinterface: ").append(getseveritystring(redundantsuperinterface)); //$non-nls-1$
buf.append("\n\t- comparing identical expr: ").append(getseveritystring(comparingidentical)); //$non-nls-1$
buf.append("\n\t- missing synchronized on inherited method: ").append(getseveritystring(missingsynchronizedmodifierininheritedmethod)); //$non-nls-1$
buf.append("\n\t- should implement hashcode() method: ").append(getseveritystring(shouldimplementhashcode)); //$non-nls-1$
buf.append("\n\t- dead code: ").append(getseveritystring(deadcode)); //$non-nls-1$
buf.append("\n\t- dead code in trivial if statement: ").append(this.reportdeadcodeintrivialifstatement ? enabled : disabled); //$non-nls-1$
buf.append("\n\t- tasks severity: ").append(getseveritystring(tasks)); //$non-nls-1$
buf.append("\n\t- unused object allocation: ").append(getseveritystring(unusedobjectallocation)); //$non-nls-1$
return buf.tostring();
}

protected void updateseverity(int irritant, object severitystring) {
if (error.equals(severitystring)) {
this.errorthreshold.set(irritant);
this.warningthreshold.clear(irritant);
} else if (warning.equals(severitystring)) {
this.errorthreshold.clear(irritant);
this.warningthreshold.set(irritant);
} else if (ignore.equals(severitystring)) {
this.errorthreshold.clear(irritant);
this.warningthreshold.clear(irritant);
}
}
}
