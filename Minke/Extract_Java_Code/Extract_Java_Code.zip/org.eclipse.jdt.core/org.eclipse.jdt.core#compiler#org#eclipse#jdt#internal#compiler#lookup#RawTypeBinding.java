/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;

/**
* denote a raw type, i.e. a generic type referenced without any type arguments.
* e.g. x<t extends exception> can be used a raw type 'x', in which case it
* 	will behave as x<exception>
*/
public class rawtypebinding extends parameterizedtypebinding {

/**
* raw type arguments are erasure of respective parameter bounds. but we may not have resolved
* these bounds yet if creating raw types while supertype hierarchies are being connected.
* therefore, use 'null' instead, and access these in a lazy way later on (when substituting).
*/
public rawtypebinding(referencebinding type, referencebinding enclosingtype, lookupenvironment environment){
super(type, null, enclosingtype, environment);
if (enclosingtype == null || (enclosingtype.modifiers & extracompilermodifiers.accgenericsignature) == 0)
this.modifiers &= ~extracompilermodifiers.accgenericsignature; // only need signature if enclosing needs one
}

public char[] computeuniquekey(boolean isleaf) {
stringbuffer sig = new stringbuffer(10);
if (ismembertype() && enclosingtype().isparameterizedtype()) {
char[] typesig = enclosingtype().computeuniquekey(false/*not a leaf*/);
sig.append(typesig, 0, typesig.length-1); // copy all but trailing semicolon
sig.append('.').append(sourcename()).append('<').append('>').append(';');
} else {
sig.append(generictype().computeuniquekey(false/*not a leaf*/));
sig.insert(sig.length()-1, "<>"); //$non-nls-1$
}

int siglength = sig.length();
char[] uniquekey = new char[siglength];
sig.getchars(0, siglength, uniquekey, 0);
return uniquekey;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.parameterizedtypebinding#createparameterizedmethod(org.eclipse.jdt.internal.compiler.lookup.methodbinding)
*/
public parameterizedmethodbinding createparameterizedmethod(methodbinding originalmethod) {
if (originalmethod.typevariables == binding.no_type_variables || originalmethod.isstatic()) {
return super.createparameterizedmethod(originalmethod);
}
return this.environment.createparameterizedgenericmethod(originalmethod, this);
}

public int kind() {
return raw_type;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#debugname()
*/
public string debugname() {
stringbuffer namebuffer = new stringbuffer(10);
namebuffer.append(actualtype().sourcename()).append("#raw"); //$non-nls-1$
return namebuffer.tostring();
}

/**
* ltype<param1 ... paramn>;
* ly<tt;>;
*/
public char[] generictypesignature() {
if (this.generictypesignature == null) {
if ((this.modifiers & extracompilermodifiers.accgenericsignature) == 0) {
this.generictypesignature = generictype().signature();
} else {
stringbuffer sig = new stringbuffer(10);
if (ismembertype()) {
referencebinding enclosing = enclosingtype();
char[] typesig = enclosing.generictypesignature();
sig.append(typesig, 0, typesig.length-1);// copy all but trailing semicolon
if ((enclosing.modifiers & extracompilermodifiers.accgenericsignature) != 0) {
sig.append('.');
} else {
sig.append('$');
}
sig.append(sourcename());
} else {
char[] typesig = generictype().signature();
sig.append(typesig, 0, typesig.length-1);// copy all but trailing semicolon
}
sig.append(';');
int siglength = sig.length();
this.generictypesignature = new char[siglength];
sig.getchars(0, siglength, this.generictypesignature, 0);
}
}
return this.generictypesignature;
}

public boolean isequivalentto(typebinding othertype) {
if (this == othertype)
return true;
if (othertype == null)
return false;
switch(othertype.kind()) {

case binding.wildcard_type :
case binding.intersection_type:
return ((wildcardbinding) othertype).boundcheck(this);

case binding.generic_type :
case binding.parameterized_type :
case binding.raw_type :
return erasure() == othertype.erasure();
}
return false;
}

public boolean isprovablydistinct(typebinding othertype) {
if (this == othertype)
return false;
if (othertype == null)
return true;
switch(othertype.kind()) {

case binding.generic_type :
case binding.parameterized_type :
case binding.raw_type :
return erasure() != othertype.erasure();
}
return true;
}

protected void initializearguments() {
typevariablebinding[] typevariables = generictype().typevariables();
int length = typevariables.length;
typebinding[] typearguments = new typebinding[length];
for (int i = 0; i < length; i++) {
// perform raw conversion on variable upper bound - could cause infinite regression if arguments were initialized lazily
typearguments[i] = this.environment.converttorawtype(typevariables[i].erasure(), false /*do not force conversion of enclosing types*/);
}
this.arguments = typearguments;
}
/**
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#readablename()
*/
public char[] readablename() /*java.lang.object,  p.x<t> */ {
char[] readablename;
if (ismembertype()) {
readablename = charoperation.concat(enclosingtype().readablename(), this.sourcename, '.');
} else {
readablename = charoperation.concatwith(actualtype().compoundname, '.');
}
return readablename;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#shortreadablename()
*/
public char[] shortreadablename() /*object*/ {
char[] shortreadablename;
if (ismembertype()) {
shortreadablename = charoperation.concat(enclosingtype().shortreadablename(), this.sourcename, '.');
} else {
shortreadablename = actualtype().sourcename;
}
return shortreadablename;
}
}
