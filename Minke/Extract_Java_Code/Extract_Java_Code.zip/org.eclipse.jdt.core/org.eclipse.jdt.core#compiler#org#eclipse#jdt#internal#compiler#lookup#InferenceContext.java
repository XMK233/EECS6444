/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

/**
* context used during type inference for a generic method invocation
*/
public class inferencecontext {

private typebinding[][][] collectedsubstitutes;
methodbinding genericmethod;
int depth;
int status;
typebinding expectedtype;
boolean hasexplicitexpectedtype; // indicates whether the expectedtype (if set) was explicit in code, or set by default
public boolean isunchecked;
typebinding[] substitutes;
final static int failed = 1;

public inferencecontext(methodbinding genericmethod) {
this.genericmethod = genericmethod;
typevariablebinding[] typevariables = genericmethod.typevariables;
int varlength = typevariables.length;
this.collectedsubstitutes = new typebinding[varlength][3][];
this.substitutes = new typebinding[varlength];
}

public typebinding[] getsubstitutes(typevariablebinding typevariable, int constraint) {
return this.collectedsubstitutes[typevariable.rank][constraint];
}

/**
* returns true if any unresolved variable is detected, i.e. any variable is substituted with itself
*/
public boolean hasunresolvedtypeargument() {
for (int i = 0, varlength = this.substitutes.length; i <varlength; i++) {
if (this.substitutes[i] == null) {
return true;
}
}
return false;
}

public void recordsubstitute(typevariablebinding typevariable, typebinding actualtype, int constraint) {
typebinding[][] variablesubstitutes = this.collectedsubstitutes[typevariable.rank];
insertloop: {
typebinding[] constraintsubstitutes = variablesubstitutes[constraint];
int length;
if (constraintsubstitutes == null) {
length = 0;
constraintsubstitutes = new typebinding[1];
} else {
length = constraintsubstitutes.length;
for (int i = 0; i < length; i++) {
typebinding substitute = constraintsubstitutes[i];
if (substitute == actualtype) return; // already there
if (substitute == null) {
constraintsubstitutes[i] = actualtype;
break insertloop;
}
}
// no free spot found, need to grow by one
system.arraycopy(constraintsubstitutes, 0, constraintsubstitutes = new typebinding[length+1], 0, length);
}
constraintsubstitutes[length] = actualtype;
variablesubstitutes[constraint] = constraintsubstitutes;
}
}
public string tostring() {
stringbuffer buffer = new stringbuffer(20);
buffer.append("inferencecontex for ");//$non-nls-1$
for (int i = 0, length = this.genericmethod.typevariables.length; i < length; i++) {
buffer.append(this.genericmethod.typevariables[i]);
}
buffer.append(this.genericmethod);
buffer.append("\n\t[status=");//$non-nls-1$
switch(this.status) {
case 0 :
buffer.append("ok]");//$non-nls-1$
break;
case failed :
buffer.append("failed]");//$non-nls-1$
break;
}
if (this.expectedtype == null) {
buffer.append(" [expectedtype=null]"); //$non-nls-1$
} else {
buffer.append(" [expectedtype=").append(this.expectedtype.shortreadablename()).append(']'); //$non-nls-1$
}
buffer.append(" [depth=").append(this.depth).append(']'); //$non-nls-1$
buffer.append("\n\t[collected={");//$non-nls-1$
for (int i = 0, length = this.collectedsubstitutes == null ? 0 : this.collectedsubstitutes.length; i < length; i++) {
typebinding[][] collected = this.collectedsubstitutes[i];
for (int j = typeconstants.constraint_equal; j <= typeconstants.constraint_super; j++) {
typebinding[] constraintcollected = collected[j];
if (constraintcollected != null) {
for (int k = 0, clength = constraintcollected.length; k < clength; k++) {
buffer.append("\n\t\t").append(this.genericmethod.typevariables[i].sourcename); //$non-nls-1$
switch (j) {
case typeconstants.constraint_equal :
buffer.append("="); //$non-nls-1$
break;
case typeconstants.constraint_extends :
buffer.append("<:"); //$non-nls-1$
break;
case typeconstants.constraint_super :
buffer.append(">:"); //$non-nls-1$
break;
}
if (constraintcollected[k] != null) {
buffer.append(constraintcollected[k].shortreadablename());
}
}
}
}
}
buffer.append("}]");//$non-nls-1$
buffer.append("\n\t[inferred=");//$non-nls-1$
int count = 0;
for (int i = 0, length = this.substitutes == null ? 0 : this.substitutes.length; i < length; i++) {
if (this.substitutes[i] == null) continue;
count++;
buffer.append('{').append(this.genericmethod.typevariables[i].sourcename);
buffer.append("=").append(this.substitutes[i].shortreadablename()).append('}'); //$non-nls-1$
}
if (count == 0) buffer.append("{}"); //$non-nls-1$
buffer.append(']');
return buffer.tostring();
}
}
