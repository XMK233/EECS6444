/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class exceptionlabel extends label {

public int ranges[] = {pos_not_set,pos_not_set};
public int count = 0; // incremented each time placestart or placeend is called
public typebinding exceptiontype;

public exceptionlabel(codestream codestream, typebinding exceptiontype) {
super(codestream);
this.exceptiontype = exceptiontype;
}

public void place() {
// register the handler inside the codestream then normal place
this.codestream.registerexceptionhandler(this);
this.position = this.codestream.getposition();
}

public void placeend() {
int endposition = this.codestream.position;
if (this.ranges[this.count-1] == endposition) { // start == end ?
// discard empty exception handler
this.count--;
} else {
this.ranges[this.count++] = endposition;
}
}

public void placestart() {
int startposition = this.codestream.position;
if (this.count > 0 && this.ranges[this.count-1] == startposition) { // start == previous end ?
// reopen current handler
this.count--;
return;
}
// only need to grow on even additions (i.e. placestart only)
int length;
if (this.count == (length = this.ranges.length)) {
system.arraycopy(this.ranges, 0, this.ranges = new int[length*2], 0, length);
}
this.ranges[this.count++] = startposition;
}
public string tostring() {
string basic = getclass().getname();
basic = basic.substring(basic.lastindexof('.')+1);
stringbuffer buffer = new stringbuffer(basic);
buffer.append('@@').append(integer.tohexstring(hashcode()));
buffer.append("(type=").append(this.exceptiontype == null ? charoperation.no_char : this.exceptiontype.readablename()); //$non-nls-1$
buffer.append(", position=").append(this.position); //$non-nls-1$
buffer.append(", ranges = "); //$non-nls-1$
if (this.count == 0) {
buffer.append("[]"); //$non-nls-1$
} else {
for (int i = 0; i < this.count; i++) {
if ((i & 1) == 0) {
buffer.append("[").append(this.ranges[i]); //$non-nls-1$
} else {
buffer.append(",").append(this.ranges[i]).append("]"); //$non-nls-1$ //$non-nls-2$
}
}
if ((this.count & 1) == 1) {
buffer.append(",?]"); //$non-nls-1$
}
}
buffer.append(')');
return buffer.tostring();
}
}
