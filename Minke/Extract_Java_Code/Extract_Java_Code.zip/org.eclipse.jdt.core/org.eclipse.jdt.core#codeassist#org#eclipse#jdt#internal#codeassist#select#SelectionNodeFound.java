/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

import org.eclipse.jdt.internal.compiler.lookup.*;

public class selectionnodefound extends runtimeexception {

public binding binding;
public boolean isdeclaration;
private static final long serialversionuid = -7335444736618092295l; // backward compatible

public selectionnodefound() {
this(null, false); // we found a problem in the selection node
}
public selectionnodefound(binding binding) {
this(binding, false);
}
public selectionnodefound(binding binding, boolean isdeclaration) {
this.binding = binding;
this.isdeclaration = isdeclaration;
}
}
