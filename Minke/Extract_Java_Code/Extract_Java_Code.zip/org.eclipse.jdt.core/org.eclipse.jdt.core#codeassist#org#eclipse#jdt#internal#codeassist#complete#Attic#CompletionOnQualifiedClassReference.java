/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

public class completiononqualifiedclassreference extends completiononqualifiedtypereference {
public completiononqualifiedclassreference(char[][] previousidentifiers, char[] completionidentifier, long[] positions) {
super(previousidentifiers, completionidentifier, positions);
}
public stringbuffer printexpression(int indent, stringbuffer output) {

output.append("<completeonclass:"); //$non-nls-1$
for (int i = 0; i < tokens.length; i++) {
output.append(tokens[i]);
output.append('.');
}
output.append(completionidentifier).append('>');
return output;
}
}
