/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.astnode;

public interface tagbits {

// tag bits in the tagbits int of every typebinding
long isarraytype = astnode.bit1;
long isbasetype = astnode.bit2;
long isnestedtype = astnode.bit3;
long ismembertype = astnode.bit4;
long containsnestedtypereferences = astnode.bit12; // method/parameterized type binding
long membertypemask = isnestedtype | ismembertype | containsnestedtypereferences;
long islocaltype = astnode.bit5;
long localtypemask = isnestedtype | islocaltype | containsnestedtypereferences;
long isanonymoustype = astnode.bit6;
long anonymoustypemask = localtypemask | isanonymoustype | containsnestedtypereferences;
long isbinarybinding = astnode.bit7;

// set for all bindings either representing a missing type (type), or directly referencing a missing type (field/method/variable)
long hasmissingtype = astnode.bit8;

// for method
long hasuncheckedtypeargumentforboundcheck = astnode.bit9;

// set when method has argument(s) that couldn't be resolved
long hasunresolvedarguments = astnode.bit10;

// for the type cycle hierarchy check used by classscope
long beginhierarchycheck = astnode.bit9;  // type
long endhierarchycheck = astnode.bit10; // type
long pausehierarchycheck = astnode.bit20; // type
long hasparameterannotations = astnode.bit11; // method/constructor


// test bit to see if default abstract methods were computed
long knowsdefaultabstractmethods = astnode.bit11; // type

long isargument = astnode.bit11; // local
long clearprivatemodifier = astnode.bit10; // constructor binding

// test bits to see if parts of binary types are faulted
long arefieldssorted = astnode.bit13;
long arefieldscomplete = astnode.bit14; // sorted and all resolved
long aremethodssorted = astnode.bit15;
long aremethodscomplete = astnode.bit16; // sorted and all resolved

// test bit to avoid asking a type for a member type (includes inherited member types)
long hasnomembertypes = astnode.bit17;

// test bit to identify if the type's hierarchy is inconsistent
long hierarchyhasproblems = astnode.bit18;

// test bit to identify if the type's type variables have been connected
long typevariablesareconnected = astnode.bit19;

// set for parameterized type with successful bound check
long passedboundcheck = astnode.bit23;

// set for parameterized type not of the form x<?,?>
long isboundparameterizedtype = astnode.bit24;

// used by binarytypebinding
long hasunresolvedtypevariables = astnode.bit25;
long hasunresolvedsuperclass = astnode.bit26;
long hasunresolvedsuperinterfaces = astnode.bit27;
long hasunresolvedenclosingtype = astnode.bit28;
long hasunresolvedmembertypes = astnode.bit29;

long hastypevariable = astnode.bit30; // set either for type variables (direct) or parameterized types indirectly referencing type variables
long hasdirectwildcard = astnode.bit31; // set for parameterized types directly referencing wildcards

// for the annotation cycle hierarchy check used by classscope
long beginannotationcheck = astnode.bit32l;
long endannotationcheck = astnode.bit33l;

// standard annotations
// 9-bits for targets
long annotationresolved = astnode.bit34l;
long deprecatedannotationresolved = astnode.bit35l;
long annotationtarget = astnode.bit36l; // @@target({}) only sets this bit
long annotationfortype = astnode.bit37l;
long annotationforfield = astnode.bit38l;
long annotationformethod = astnode.bit39l;
long annotationforparameter = astnode.bit40l;
long annotationforconstructor = astnode.bit41l;
long annotationforlocalvariable = astnode.bit42l;
long annotationforannotationtype = astnode.bit43l;
long annotationforpackage = astnode.bit44l;
long annotationtargetmask = annotationtarget
| annotationfortype | annotationforfield
| annotationformethod | annotationforparameter
| annotationforconstructor | annotationforlocalvariable
| annotationforannotationtype | annotationforpackage;
// 2-bits for retention (should check (tagbits & retentionmask) == runtimeretention
long annotationsourceretention = astnode.bit45l;
long annotationclassretention = astnode.bit46l;
long annotationruntimeretention = annotationsourceretention | annotationclassretention;
long annotationretentionmask = annotationsourceretention | annotationclassretention | annotationruntimeretention;
// marker annotations
long annotationdeprecated = astnode.bit47l;
long annotationdocumented = astnode.bit48l;
long annotationinherited = astnode.bit49l;
long annotationoverride = astnode.bit50l;
long annotationsuppresswarnings = astnode.bit51l;
long allstandardannotationsmask = annotationtargetmask | annotationretentionmask | annotationdeprecated | annotationdocumented | annotationinherited |  annotationoverride | annotationsuppresswarnings;

long defaultvalueresolved = astnode.bit52l;

// set when type contains non-private constructor(s)
long hasnonprivateconstructor = astnode.bit53l;
}
