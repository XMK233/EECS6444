/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.importreference;

public class importconflictbinding extends importbinding {
public referencebinding conflictingtypebinding; // must ensure the import is resolved

public importconflictbinding(char[][] compoundname, binding methodbinding, referencebinding conflictingtypebinding, importreference reference) {
super(compoundname, false, methodbinding, reference);
this.conflictingtypebinding = conflictingtypebinding;
}
public char[] readablename() {
return charoperation.concatwith(this.compoundname, '.');
}
public string tostring() {
return "method import : " + new string(readablename()); //$non-nls-1$
}
}
