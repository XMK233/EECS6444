/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;


public class annotationarraysingletypereference extends arraytypereference {

public annotationarraysingletypereference(char[] name, int dim, long pos) {
super(name, dim, pos);
this.bits |= insideannotation;
}

/* (non-javadoc)
* redefine to capture annotation specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(iabstractsyntaxtreevisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
