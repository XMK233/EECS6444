/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.*;
import org.eclipse.jdt.internal.compiler.*;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.*;
import org.eclipse.jdt.internal.compiler.problem.*;
import org.eclipse.jdt.internal.compiler.util.util;

public class typedeclaration extends statement implements problemseverities, referencecontext {
// type decl kinds
public static final int class_decl = 1;
public static final int interface_decl = 2;
public static final int enum_decl = 3;
public static final int annotation_type_decl = 4;

public int modifiers = classfileconstants.accdefault;
public int modifierssourcestart;
public annotation[] annotations;
public char[] name;
public typereference superclass;
public typereference[] superinterfaces;
public fielddeclaration[] fields;
public abstractmethoddeclaration[] methods;
public typedeclaration[] membertypes;
public sourcetypebinding binding;
public classscope scope;
public methodscope initializerscope;
public methodscope staticinitializerscope;
public boolean ignorefurtherinvestigation = false;
public int maxfieldcount;
public int declarationsourcestart;
public int declarationsourceend;
public int bodystart;
public int bodyend; // doesn't include the trailing comment if any.
public compilationresult compilationresult;
public methoddeclaration[] missingabstractmethods;
public javadoc javadoc;

public qualifiedallocationexpression allocation; // for anonymous only
public typedeclaration enclosingtype; // for member types only

public fieldbinding enumvaluessyntheticfield; 	// for enum

// 1.5 support
public typeparameter[] typeparameters;

public typedeclaration(compilationresult compilationresult){
this.compilationresult = compilationresult;
}

/*
*	we cause the compilation task to abort to a given extent.
*/
public void abort(int abortlevel, categorizedproblem problem) {
switch (abortlevel) {
case abortcompilation :
throw new abortcompilation(this.compilationresult, problem);
case abortcompilationunit :
throw new abortcompilationunit(this.compilationresult, problem);
case abortmethod :
throw new abortmethod(this.compilationresult, problem);
default :
throw new aborttype(this.compilationresult, problem);
}
}

/**
* this method is responsible for adding a <clinit> method declaration to the type method collections.
* note that this implementation is inserting it in first place (as vaj or javac), and that this
* impacts the behavior of the method constantpool.resetforclinit(int. int), in so far as
* the latter will have to reset the constant pool state accordingly (if it was added first, it does
* not need to preserve some of the method specific cached entries since this will be the first method).
* inserts the clinit method declaration in the first position.
*
* @@see org.eclipse.jdt.internal.compiler.codegen.constantpool#resetforclinit(int, int)
*/
public final void addclinit() {
//see comment on needclassinitmethod
if (needclassinitmethod()) {
int length;
abstractmethoddeclaration[] methoddeclarations;
if ((methoddeclarations = this.methods) == null) {
length = 0;
methoddeclarations = new abstractmethoddeclaration[1];
} else {
length = methoddeclarations.length;
system.arraycopy(
methoddeclarations,
0,
(methoddeclarations = new abstractmethoddeclaration[length + 1]),
1,
length);
}
clinit clinit = new clinit(this.compilationresult);
methoddeclarations[0] = clinit;
// clinit is added in first location, so as to minimize the use of ldcw (big consumer of constant inits)
clinit.declarationsourcestart = clinit.sourcestart = this.sourcestart;
clinit.declarationsourceend = clinit.sourceend = this.sourceend;
clinit.bodyend = this.sourceend;
this.methods = methoddeclarations;
}
}

/*
* internal use only - creates a fake method declaration for the corresponding binding.
* it is used to report errors for missing abstract methods.
*/
public methoddeclaration addmissingabstractmethodfor(methodbinding methodbinding) {
typebinding[] argumenttypes = methodbinding.parameters;
int argumentslength = argumenttypes.length;
//the constructor
methoddeclaration methoddeclaration = new methoddeclaration(this.compilationresult);
methoddeclaration.selector = methodbinding.selector;
methoddeclaration.sourcestart = this.sourcestart;
methoddeclaration.sourceend = this.sourceend;
methoddeclaration.modifiers = methodbinding.getaccessflags() & ~classfileconstants.accabstract;

if (argumentslength > 0) {
string basename = "arg";//$non-nls-1$
argument[] arguments = (methoddeclaration.arguments = new argument[argumentslength]);
for (int i = argumentslength; --i >= 0;) {
arguments[i] = new argument((basename + i).tochararray(), 0l, null /*type ref*/, classfileconstants.accdefault);
}
}

//adding the constructor in the methods list
if (this.missingabstractmethods == null) {
this.missingabstractmethods = new methoddeclaration[] { methoddeclaration };
} else {
methoddeclaration[] newmethods;
system.arraycopy(
this.missingabstractmethods,
0,
newmethods = new methoddeclaration[this.missingabstractmethods.length + 1],
1,
this.missingabstractmethods.length);
newmethods[0] = methoddeclaration;
this.missingabstractmethods = newmethods;
}

//============binding update==========================
methoddeclaration.binding = new methodbinding(
methoddeclaration.modifiers | classfileconstants.accsynthetic, //methoddeclaration
methodbinding.selector,
methodbinding.returntype,
argumentslength == 0 ? binding.no_parameters : argumenttypes, //arguments bindings
methodbinding.thrownexceptions, //exceptions
this.binding); //declaringclass

methoddeclaration.scope = new methodscope(this.scope, methoddeclaration, true);
methoddeclaration.bindarguments();

/*		if (binding.methods == null) {
binding.methods = new methodbinding[] { methoddeclaration.binding };
} else {
methodbinding[] newmethods;
system.arraycopy(
binding.methods,
0,
newmethods = new methodbinding[binding.methods.length + 1],
1,
binding.methods.length);
newmethods[0] = methoddeclaration.binding;
binding.methods = newmethods;
}*/
//===================================================

return methoddeclaration;
}

/**
*	flow analysis for a local innertype
*
*/
public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
if (this.ignorefurtherinvestigation)
return flowinfo;
try {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0) {
this.bits |= astnode.isreachable;
localtypebinding localtype = (localtypebinding) this.binding;
localtype.setconstantpoolname(currentscope.compilationunitscope().computeconstantpoolname(localtype));
}
manageenclosinginstanceaccessifnecessary(currentscope, flowinfo);
updatemaxfieldcount(); // propagate down the max field count
internalanalysecode(flowcontext, flowinfo);
} catch (aborttype e) {
this.ignorefurtherinvestigation = true;
}
return flowinfo;
}

/**
*	flow analysis for a member innertype
*
*/
public void analysecode(classscope enclosingclassscope) {
if (this.ignorefurtherinvestigation)
return;
try {
// propagate down the max field count
updatemaxfieldcount();
internalanalysecode(null, flowinfo.initial(this.maxfieldcount));
} catch (aborttype e) {
this.ignorefurtherinvestigation = true;
}
}

/**
*	flow analysis for a local member innertype
*
*/
public void analysecode(classscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
if (this.ignorefurtherinvestigation)
return;
try {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0) {
this.bits |= astnode.isreachable;
localtypebinding localtype = (localtypebinding) this.binding;
localtype.setconstantpoolname(currentscope.compilationunitscope().computeconstantpoolname(localtype));
}
manageenclosinginstanceaccessifnecessary(currentscope, flowinfo);
updatemaxfieldcount(); // propagate down the max field count
internalanalysecode(flowcontext, flowinfo);
} catch (aborttype e) {
this.ignorefurtherinvestigation = true;
}
}

/**
*	flow analysis for a package member type
*
*/
public void analysecode(compilationunitscope unitscope) {
if (this.ignorefurtherinvestigation)
return;
try {
internalanalysecode(null, flowinfo.initial(this.maxfieldcount));
} catch (aborttype e) {
this.ignorefurtherinvestigation = true;
}
}

/**
* check for constructor vs. method with no return type.
* answers true if at least one constructor is defined
*/
public boolean checkconstructors(parser parser) {
//if a constructor has not the name of the type,
//convert it into a method with 'null' as its return type
boolean hasconstructor = false;
if (this.methods != null) {
for (int i = this.methods.length; --i >= 0;) {
abstractmethoddeclaration am;
if ((am = this.methods[i]).isconstructor()) {
if (!charoperation.equals(am.selector, this.name)) {
// the constructor was in fact a method with no return type
// unless an explicit constructor call was supplied
constructordeclaration c = (constructordeclaration) am;
if (c.constructorcall == null || c.constructorcall.isimplicitsuper()) { //changed to a method
methoddeclaration m = parser.converttomethoddeclaration(c, this.compilationresult);
this.methods[i] = m;
}
} else {
switch (kind(this.modifiers)) {
case typedeclaration.interface_decl :
// report the problem and continue the parsing
parser.problemreporter().interfacecannothaveconstructors((constructordeclaration) am);
break;
case typedeclaration.annotation_type_decl :
// report the problem and continue the parsing
parser.problemreporter().annotationtypedeclarationcannothaveconstructor((constructordeclaration) am);
break;

}
hasconstructor = true;
}
}
}
}
return hasconstructor;
}

public compilationresult compilationresult() {
return this.compilationresult;
}

public constructordeclaration createdefaultconstructor(	boolean needexplicitconstructorcall, boolean needtoinsert) {
//add to method'set, the default constuctor that just recall the
//super constructor with no arguments
//the arguments' type will be positionned by the tc so just use
//the default int instead of just null (consistency purpose)

//the constructor
constructordeclaration constructor = new constructordeclaration(this.compilationresult);
constructor.bits |= astnode.isdefaultconstructor;
constructor.selector = this.name;
constructor.modifiers = this.modifiers & extracompilermodifiers.accvisibilitymask;

//if you change this setting, please update the
//sourceindexer2.buildtypedeclaration(typedeclaration,char[]) method
constructor.declarationsourcestart = constructor.sourcestart = this.sourcestart;
constructor.declarationsourceend =
constructor.sourceend = constructor.bodyend = this.sourceend;

//the super call inside the constructor
if (needexplicitconstructorcall) {
constructor.constructorcall = superreference.implicitsuperconstructorcall();
constructor.constructorcall.sourcestart = this.sourcestart;
constructor.constructorcall.sourceend = this.sourceend;
}

//adding the constructor in the methods list: rank is not critical since bindings will be sorted
if (needtoinsert) {
if (this.methods == null) {
this.methods = new abstractmethoddeclaration[] { constructor };
} else {
abstractmethoddeclaration[] newmethods;
system.arraycopy(
this.methods,
0,
newmethods = new abstractmethoddeclaration[this.methods.length + 1],
1,
this.methods.length);
newmethods[0] = constructor;
this.methods = newmethods;
}
}
return constructor;
}

// anonymous type constructor creation: rank is important since bindings already got sorted
public methodbinding createdefaultconstructorwithbinding(methodbinding inheritedconstructorbinding, boolean erasethrownexceptions) {
//add to method'set, the default constuctor that just recall the
//super constructor with the same arguments
string basename = "$anonymous"; //$non-nls-1$
typebinding[] argumenttypes = inheritedconstructorbinding.parameters;
int argumentslength = argumenttypes.length;
//the constructor
constructordeclaration constructor = new constructordeclaration(this.compilationresult);
constructor.selector = new char[] { 'x' }; //no maining
constructor.sourcestart = this.sourcestart;
constructor.sourceend = this.sourceend;
int newmodifiers = this.modifiers & extracompilermodifiers.accvisibilitymask;
if (inheritedconstructorbinding.isvarargs()) {
newmodifiers |= classfileconstants.accvarargs;
}
constructor.modifiers = newmodifiers;
constructor.bits |= astnode.isdefaultconstructor;

if (argumentslength > 0) {
argument[] arguments = (constructor.arguments = new argument[argumentslength]);
for (int i = argumentslength; --i >= 0;) {
arguments[i] = new argument((basename + i).tochararray(), 0l, null /*type ref*/, classfileconstants.accdefault);
}
}
//the super call inside the constructor
constructor.constructorcall = superreference.implicitsuperconstructorcall();
constructor.constructorcall.sourcestart = this.sourcestart;
constructor.constructorcall.sourceend = this.sourceend;

if (argumentslength > 0) {
expression[] args;
args = constructor.constructorcall.arguments = new expression[argumentslength];
for (int i = argumentslength; --i >= 0;) {
args[i] = new singlenamereference((basename + i).tochararray(), 0l);
}
}

//adding the constructor in the methods list
if (this.methods == null) {
this.methods = new abstractmethoddeclaration[] { constructor };
} else {
abstractmethoddeclaration[] newmethods;
system.arraycopy(this.methods, 0, newmethods = new abstractmethoddeclaration[this.methods.length + 1], 1, this.methods.length);
newmethods[0] = constructor;
this.methods = newmethods;
}

//============binding update==========================
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=277643, align with javac on jls 15.12.2.6
referencebinding[] thrownexceptions = erasethrownexceptions
? this.scope.environment().converttorawtypes(inheritedconstructorbinding.thrownexceptions, true, true)
: inheritedconstructorbinding.thrownexceptions;

sourcetypebinding sourcetype = this.binding;
constructor.binding = new methodbinding(
constructor.modifiers, //methoddeclaration
argumentslength == 0 ? binding.no_parameters : argumenttypes, //arguments bindings
thrownexceptions, //exceptions
sourcetype); //declaringclass
constructor.binding.tagbits |= (inheritedconstructorbinding.tagbits & tagbits.hasmissingtype);
constructor.binding.modifiers |= extracompilermodifiers.accisdefaultconstructor;

constructor.scope = new methodscope(this.scope, constructor, true);
constructor.bindarguments();
constructor.constructorcall.resolve(constructor.scope);

methodbinding[] methodbindings = sourcetype.methods(); // trigger sorting
int length;
system.arraycopy(methodbindings, 0, methodbindings = new methodbinding[(length = methodbindings.length) + 1], 1, length);
methodbindings[0] = constructor.binding;
if (++length > 1)
referencebinding.sortmethods(methodbindings, 0, length);	// need to resort, since could be valid methods ahead (140643) - dom needs eager sorting
sourcetype.setmethods(methodbindings);
//===================================================

return constructor.binding;
}

/**
* find the matching parse node, answers null if nothing found
*/
public fielddeclaration declarationof(fieldbinding fieldbinding) {
if (fieldbinding != null && this.fields != null) {
for (int i = 0, max = this.fields.length; i < max; i++) {
fielddeclaration fielddecl;
if ((fielddecl = this.fields[i]).binding == fieldbinding)
return fielddecl;
}
}
return null;
}

/**
* find the matching parse node, answers null if nothing found
*/
public typedeclaration declarationof(membertypebinding membertypebinding) {
if (membertypebinding != null && this.membertypes != null) {
for (int i = 0, max = this.membertypes.length; i < max; i++) {
typedeclaration membertypedecl;
if ((membertypedecl = this.membertypes[i]).binding == membertypebinding)
return membertypedecl;
}
}
return null;
}

/**
* find the matching parse node, answers null if nothing found
*/
public abstractmethoddeclaration declarationof(methodbinding methodbinding) {
if (methodbinding != null && this.methods != null) {
for (int i = 0, max = this.methods.length; i < max; i++) {
abstractmethoddeclaration methoddecl;

if ((methoddecl = this.methods[i]).binding == methodbinding)
return methoddecl;
}
}
return null;
}

/**
* finds the matching type amoung this type's member types.
* returns null if no type with this name is found.
* the type name is a compound name relative to this type
* e.g. if this type is x and we're looking for y.x.a.b
*     then a type name would be {x, a, b}
*/
public typedeclaration declarationoftype(char[][] typename) {
int typenamelength = typename.length;
if (typenamelength < 1 || !charoperation.equals(typename[0], this.name)) {
return null;
}
if (typenamelength == 1) {
return this;
}
char[][] subtypename = new char[typenamelength - 1][];
system.arraycopy(typename, 1, subtypename, 0, typenamelength - 1);
for (int i = 0; i < this.membertypes.length; i++) {
typedeclaration typedecl = this.membertypes[i].declarationoftype(subtypename);
if (typedecl != null) {
return typedecl;
}
}
return null;
}

/**
* generic bytecode generation for type
*/
public void generatecode(classfile enclosingclassfile) {
if ((this.bits & astnode.hasbeengenerated) != 0)
return;
this.bits |= astnode.hasbeengenerated;
if (this.ignorefurtherinvestigation) {
if (this.binding == null)
return;
classfile.createproblemtype(
this,
this.scope.referencecompilationunit().compilationresult);
return;
}
try {
// create the result for a compiled type
classfile classfile = classfile.getnewinstance(this.binding);
classfile.initialize(this.binding, enclosingclassfile, false);
if (this.binding.ismembertype()) {
classfile.recordinnerclasses(this.binding);
} else if (this.binding.islocaltype()) {
enclosingclassfile.recordinnerclasses(this.binding);
classfile.recordinnerclasses(this.binding);
}
typevariablebinding[] typevariables = this.binding.typevariables();
for (int i = 0, max = typevariables.length; i < max; i++) {
typevariablebinding typevariablebinding = typevariables[i];
if ((typevariablebinding.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(classfile, typevariablebinding);
}
}

// generate all fiels
classfile.addfieldinfos();

if (this.membertypes != null) {
for (int i = 0, max = this.membertypes.length; i < max; i++) {
typedeclaration membertype = this.membertypes[i];
classfile.recordinnerclasses(membertype.binding);
membertype.generatecode(this.scope, classfile);
}
}
// generate all methods
classfile.setformethodinfos();
if (this.methods != null) {
for (int i = 0, max = this.methods.length; i < max; i++) {
this.methods[i].generatecode(this.scope, classfile);
}
}
// generate all synthetic and abstract methods
classfile.addspecialmethods();

if (this.ignorefurtherinvestigation) { // trigger problem type generation for code gen errors
throw new aborttype(this.scope.referencecompilationunit().compilationresult, null);
}

// finalize the compiled type result
classfile.addattributes();
this.scope.referencecompilationunit().compilationresult.record(
this.binding.constantpoolname(),
classfile);
} catch (aborttype e) {
if (this.binding == null)
return;
classfile.createproblemtype(
this,
this.scope.referencecompilationunit().compilationresult);
}
}

/**
* bytecode generation for a local inner type (api as a normal statement code gen)
*/
public void generatecode(blockscope blockscope, codestream codestream) {
if ((this.bits & astnode.isreachable) == 0) {
return;
}
if ((this.bits & astnode.hasbeengenerated) != 0) return;
int pc = codestream.position;
if (this.binding != null) {
syntheticargumentbinding[] enclosinginstances = ((nestedtypebinding) this.binding).syntheticenclosinginstances();
for (int i = 0, slotsize = 0, count = enclosinginstances == null ? 0 : enclosinginstances.length; i < count; i++){
syntheticargumentbinding enclosinginstance = enclosinginstances[i];
enclosinginstance.resolvedposition = ++slotsize; // shift by 1 to leave room for aload0==this
if (slotsize > 0xff) { // no more than 255 words of arguments
blockscope.problemreporter().nomoreavailablespaceforargument(enclosinginstance, blockscope.referencetype());
}
}
}
generatecode(codestream.classfile);
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* bytecode generation for a member inner type
*/
public void generatecode(classscope classscope, classfile enclosingclassfile) {
if ((this.bits & astnode.hasbeengenerated) != 0) return;
if (this.binding != null) {
syntheticargumentbinding[] enclosinginstances = ((nestedtypebinding) this.binding).syntheticenclosinginstances();
for (int i = 0, slotsize = 0, count = enclosinginstances == null ? 0 : enclosinginstances.length; i < count; i++){
syntheticargumentbinding enclosinginstance = enclosinginstances[i];
enclosinginstance.resolvedposition = ++slotsize; // shift by 1 to leave room for aload0==this
if (slotsize > 0xff) { // no more than 255 words of arguments
classscope.problemreporter().nomoreavailablespaceforargument(enclosinginstance, classscope.referencetype());
}
}
}
generatecode(enclosingclassfile);
}

/**
* bytecode generation for a package member
*/
public void generatecode(compilationunitscope unitscope) {
generatecode((classfile) null);
}

public boolean haserrors() {
return this.ignorefurtherinvestigation;
}

/**
*	common flow analysis for all types
*/
private void internalanalysecode(flowcontext flowcontext, flowinfo flowinfo) {
if (!this.binding.isused() && this.binding.isorenclosedbyprivatetype()) {
if (!this.scope.referencecompilationunit().compilationresult.hassyntaxerror) {
this.scope.problemreporter().unusedprivatetype(this);
}
}
initializationflowcontext initializercontext = new initializationflowcontext(null, this, flowinfo, flowcontext, this.initializerscope);
initializationflowcontext staticinitializercontext = new initializationflowcontext(null, this, flowinfo, flowcontext, this.staticinitializerscope);
flowinfo nonstaticfieldinfo = flowinfo.unconditionalfieldlesscopy();
flowinfo staticfieldinfo = flowinfo.unconditionalfieldlesscopy();
if (this.fields != null) {
for (int i = 0, count = this.fields.length; i < count; i++) {
fielddeclaration field = this.fields[i];
if (field.isstatic()) {
if ((staticfieldinfo.tagbits & flowinfo.unreachable) != 0)
field.bits &= ~astnode.isreachable;

/*if (field.isfield()){
staticinitializercontext.handledexceptions = noexceptions; // no exception is allowed jls8.3.2
} else {*/
staticinitializercontext.handledexceptions = binding.any_exception; // tolerate them all, and record them
/*}*/
staticfieldinfo = field.analysecode(this.staticinitializerscope, staticinitializercontext, staticfieldinfo);
// in case the initializer is not reachable, use a reinitialized flowinfo and enter a fake reachable
// branch, since the previous initializer already got the blame.
if (staticfieldinfo == flowinfo.dead_end) {
this.staticinitializerscope.problemreporter().initializermustcompletenormally(field);
staticfieldinfo = flowinfo.initial(this.maxfieldcount).setreachmode(flowinfo.unreachable);
}
} else {
if ((nonstaticfieldinfo.tagbits & flowinfo.unreachable) != 0)
field.bits &= ~astnode.isreachable;

/*if (field.isfield()){
initializercontext.handledexceptions = noexceptions; // no exception is allowed jls8.3.2
} else {*/
initializercontext.handledexceptions = binding.any_exception; // tolerate them all, and record them
/*}*/
nonstaticfieldinfo = field.analysecode(this.initializerscope, initializercontext, nonstaticfieldinfo);
// in case the initializer is not reachable, use a reinitialized flowinfo and enter a fake reachable
// branch, since the previous initializer already got the blame.
if (nonstaticfieldinfo == flowinfo.dead_end) {
this.initializerscope.problemreporter().initializermustcompletenormally(field);
nonstaticfieldinfo = flowinfo.initial(this.maxfieldcount).setreachmode(flowinfo.unreachable);
}
}
}
}
if (this.membertypes != null) {
for (int i = 0, count = this.membertypes.length; i < count; i++) {
if (flowcontext != null){ // local type
this.membertypes[i].analysecode(this.scope, flowcontext, nonstaticfieldinfo.copy().setreachmode(flowinfo.reachmode())); // reset reach mode in case initializers did abrupt completely
} else {
this.membertypes[i].analysecode(this.scope);
}
}
}
if (this.methods != null) {
unconditionalflowinfo outerinfo = flowinfo.unconditionalfieldlesscopy();
flowinfo constructorinfo = nonstaticfieldinfo.unconditionalinits().discardnonfieldinitializations().addinitializationsfrom(outerinfo);
for (int i = 0, count = this.methods.length; i < count; i++) {
abstractmethoddeclaration method = this.methods[i];
if (method.ignorefurtherinvestigation)
continue;
if (method.isinitializationmethod()) {
if (method.isstatic()) { // <clinit>
method.analysecode(
this.scope,
staticinitializercontext,
staticfieldinfo.unconditionalinits().discardnonfieldinitializations().addinitializationsfrom(outerinfo));
} else { // constructor
((constructordeclaration)method).analysecode(this.scope, initializercontext, constructorinfo.copy(), flowinfo.reachmode());
}
} else { // regular method
method.analysecode(this.scope, null, flowinfo.copy());
}
}
}
// enable enum support ?
if (this.binding.isenum() && !this.binding.isanonymoustype()) {
this.enumvaluessyntheticfield = this.binding.addsyntheticfieldforenumvalues();
}
}

public final static int kind(int flags) {
switch (flags & (classfileconstants.accinterface|classfileconstants.accannotation|classfileconstants.accenum)) {
case classfileconstants.accinterface :
return typedeclaration.interface_decl;
case classfileconstants.accinterface|classfileconstants.accannotation :
return typedeclaration.annotation_type_decl;
case classfileconstants.accenum :
return typedeclaration.enum_decl;
default :
return typedeclaration.class_decl;
}
}

/*
* access emulation for a local type
* force to emulation of access to direct enclosing instance.
* by using the initializer scope, we actually only request an argument emulation, the
* field is not added until actually used. however we will force allocations to be qualified
* with an enclosing instance.
* 15.9.2
*/
public void manageenclosinginstanceaccessifnecessary(blockscope currentscope, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) != 0) return;
nestedtypebinding nestedtype = (nestedtypebinding) this.binding;

methodscope methodscope = currentscope.methodscope();
if (!methodscope.isstatic && !methodscope.isconstructorcall){
nestedtype.addsyntheticargumentandfield(nestedtype.enclosingtype());
}
// add superclass enclosing instance arg for anonymous types (if necessary)
if (nestedtype.isanonymoustype()) {
referencebinding superclassbinding = (referencebinding)nestedtype.superclass.erasure();
if (superclassbinding.enclosingtype() != null && !superclassbinding.isstatic()) {
if (!superclassbinding.islocaltype()
|| ((nestedtypebinding)superclassbinding).getsyntheticfield(superclassbinding.enclosingtype(), true) != null){

nestedtype.addsyntheticargument(superclassbinding.enclosingtype());
}
}
// from 1.5 on, provide access to enclosing instance synthetic constructor argument when declared inside constructor call
// only for direct anonymous type
//public class x {
//	void foo() {}
//	class m {
//		m(object o) {}
//		m() { this(new object() { void baz() { foo(); }}); } // access to #foo() indirects through constructor synthetic arg: val$this$0
//	}
//}
if (!methodscope.isstatic && methodscope.isconstructorcall && currentscope.compileroptions().compliancelevel >= classfileconstants.jdk1_5) {
referencebinding enclosing = nestedtype.enclosingtype();
if (enclosing.isnestedtype()) {
nestedtypebinding nestedenclosing = (nestedtypebinding)enclosing;
//					if (nestedenclosing.findsupertypeerasingto(nestedenclosing.enclosingtype()) == null) { // only if not inheriting
syntheticargumentbinding syntheticenclosinginstanceargument = nestedenclosing.getsyntheticargument(nestedenclosing.enclosingtype(), true);
if (syntheticenclosinginstanceargument != null) {
nestedtype.addsyntheticargumentandfield(syntheticenclosinginstanceargument);
}
}
//				}
}
}
}

/**
* access emulation for a local member type
* force to emulation of access to direct enclosing instance.
* by using the initializer scope, we actually only request an argument emulation, the
* field is not added until actually used. however we will force allocations to be qualified
* with an enclosing instance.
*
* local member cannot be static.
*/
public void manageenclosinginstanceaccessifnecessary(classscope currentscope, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0) {
nestedtypebinding nestedtype = (nestedtypebinding) this.binding;
nestedtype.addsyntheticargumentandfield(this.binding.enclosingtype());
}
}

/**
* a <clinit> will be requested as soon as static fields or assertions are present. it will be eliminated during
* classfile creation if no bytecode was actually produced based on some optimizations/compiler settings.
*/
public final boolean needclassinitmethod() {
// always need a <clinit> when assertions are present
if ((this.bits & astnode.containsassertion) != 0)
return true;

switch (kind(this.modifiers)) {
case typedeclaration.interface_decl:
case typedeclaration.annotation_type_decl:
return this.fields != null; // fields are implicitly statics
case typedeclaration.enum_decl:
return true; // even if no enum constants, need to set $values array
}
if (this.fields != null) {
for (int i = this.fields.length; --i >= 0;) {
fielddeclaration field = this.fields[i];
//need to test the modifier directly while there is no binding yet
if ((field.modifiers & classfileconstants.accstatic) != 0)
return true; // todo (philippe) shouldn't it check whether field is initializer or has some initial value ?
}
}
return false;
}

public void parsemethods(parser parser, compilationunitdeclaration unit) {
//connect method bodies
if (unit.ignoremethodbodies)
return;

//members
if (this.membertypes != null) {
int length = this.membertypes.length;
for (int i = 0; i < length; i++) {
typedeclaration typedeclaration = this.membertypes[i];
typedeclaration.parsemethods(parser, unit);
this.bits |= (typedeclaration.bits & astnode.hassyntaxerrors);
}
}

//methods
if (this.methods != null) {
int length = this.methods.length;
for (int i = 0; i < length; i++) {
abstractmethoddeclaration abstractmethoddeclaration = this.methods[i];
abstractmethoddeclaration.parsestatements(parser, unit);
this.bits |= (abstractmethoddeclaration.bits & astnode.hassyntaxerrors);
}
}

//initializers
if (this.fields != null) {
int length = this.fields.length;
for (int i = 0; i < length; i++) {
final fielddeclaration fielddeclaration = this.fields[i];
switch(fielddeclaration.getkind()) {
case abstractvariabledeclaration.initializer:
((initializer) fielddeclaration).parsestatements(parser, this, unit);
this.bits |= (fielddeclaration.bits & astnode.hassyntaxerrors);
break;
}
}
}
}

public stringbuffer print(int indent, stringbuffer output) {
if (this.javadoc != null) {
this.javadoc.print(indent, output);
}
if ((this.bits & astnode.isanonymoustype) == 0) {
printindent(indent, output);
printheader(0, output);
}
return printbody(indent, output);
}

public stringbuffer printbody(int indent, stringbuffer output) {
output.append(" {"); //$non-nls-1$
if (this.membertypes != null) {
for (int i = 0; i < this.membertypes.length; i++) {
if (this.membertypes[i] != null) {
output.append('\n');
this.membertypes[i].print(indent + 1, output);
}
}
}
if (this.fields != null) {
for (int fieldi = 0; fieldi < this.fields.length; fieldi++) {
if (this.fields[fieldi] != null) {
output.append('\n');
this.fields[fieldi].print(indent + 1, output);
}
}
}
if (this.methods != null) {
for (int i = 0; i < this.methods.length; i++) {
if (this.methods[i] != null) {
output.append('\n');
this.methods[i].print(indent + 1, output);
}
}
}
output.append('\n');
return printindent(indent, output).append('}');
}

public stringbuffer printheader(int indent, stringbuffer output) {
printmodifiers(this.modifiers, output);
if (this.annotations != null) printannotations(this.annotations, output);

switch (kind(this.modifiers)) {
case typedeclaration.class_decl :
output.append("class "); //$non-nls-1$
break;
case typedeclaration.interface_decl :
output.append("interface "); //$non-nls-1$
break;
case typedeclaration.enum_decl :
output.append("enum "); //$non-nls-1$
break;
case typedeclaration.annotation_type_decl :
output.append("@@interface "); //$non-nls-1$
break;
}
output.append(this.name);
if (this.typeparameters != null) {
output.append("<");//$non-nls-1$
for (int i = 0; i < this.typeparameters.length; i++) {
if (i > 0) output.append( ", "); //$non-nls-1$
this.typeparameters[i].print(0, output);
}
output.append(">");//$non-nls-1$
}
if (this.superclass != null) {
output.append(" extends ");  //$non-nls-1$
this.superclass.print(0, output);
}
if (this.superinterfaces != null && this.superinterfaces.length > 0) {
switch (kind(this.modifiers)) {
case typedeclaration.class_decl :
case typedeclaration.enum_decl :
output.append(" implements "); //$non-nls-1$
break;
case typedeclaration.interface_decl :
case typedeclaration.annotation_type_decl :
output.append(" extends "); //$non-nls-1$
break;
}
for (int i = 0; i < this.superinterfaces.length; i++) {
if (i > 0) output.append( ", "); //$non-nls-1$
this.superinterfaces[i].print(0, output);
}
}
return output;
}

public stringbuffer printstatement(int tab, stringbuffer output) {
return print(tab, output);
}



public void resolve() {
sourcetypebinding sourcetype = this.binding;
if (sourcetype == null) {
this.ignorefurtherinvestigation = true;
return;
}
try {
boolean old = this.staticinitializerscope.insidetypeannotation;
try {
this.staticinitializerscope.insidetypeannotation = true;
resolveannotations(this.staticinitializerscope, this.annotations, sourcetype);
} finally {
this.staticinitializerscope.insidetypeannotation = old;
}
// check @@deprecated annotation
if ((sourcetype.getannotationtagbits() & tagbits.annotationdeprecated) == 0
&& (sourcetype.modifiers & classfileconstants.accdeprecated) != 0
&& this.scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
this.scope.problemreporter().missingdeprecatedannotationfortype(this);
}
if ((this.bits & astnode.undocumentedemptyblock) != 0) {
this.scope.problemreporter().undocumentedemptyblock(this.bodystart-1, this.bodyend);
}
boolean needserialversion =
this.scope.compileroptions().getseverity(compileroptions.missingserialversion) != problemseverities.ignore
&& sourcetype.isclass()
&& sourcetype.findsupertypeoriginatingfrom(typeids.t_javaioexternalizable, false /*externalizable is not a class*/) == null
&& sourcetype.findsupertypeoriginatingfrom(typeids.t_javaioserializable, false /*serializable is not a class*/) != null;

if (needserialversion) {
// if object writereplace() throws java.io.objectstreamexception is present, then no serialversionuid is needed
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=101476
compilationunitscope compilationunitscope = this.scope.compilationunitscope();
methodbinding methodbinding = sourcetype.getexactmethod(typeconstants.writereplace, new typebinding[0], compilationunitscope);
referencebinding[] throwsexceptions;
needserialversion =
methodbinding == null
|| !methodbinding.isvalidbinding()
|| methodbinding.returntype.id != typeids.t_javalangobject
|| (throwsexceptions = methodbinding.thrownexceptions).length != 1
|| throwsexceptions[0].id != typeids.t_javaioobjectstreamexception;
if (needserialversion) {
// check the presence of an implementation of the methods
// private void writeobject(java.io.objectoutputstream out) throws ioexception
// private void readobject(java.io.objectinputstream out) throws ioexception
boolean haswriteobjectmethod = false;
boolean hasreadobjectmethod = false;
typebinding argumenttypebinding = this.scope.gettype(typeconstants.java_io_objectoutputstream, 3);
if (argumenttypebinding.isvalidbinding()) {
methodbinding = sourcetype.getexactmethod(typeconstants.writeobject, new typebinding[] { argumenttypebinding }, compilationunitscope);
haswriteobjectmethod = methodbinding != null
&& methodbinding.isvalidbinding()
&& methodbinding.modifiers == classfileconstants.accprivate
&& methodbinding.returntype == typebinding.void
&& (throwsexceptions = methodbinding.thrownexceptions).length == 1
&& throwsexceptions[0].id == typeids.t_javaioexception;
}
argumenttypebinding = this.scope.gettype(typeconstants.java_io_objectinputstream, 3);
if (argumenttypebinding.isvalidbinding()) {
methodbinding = sourcetype.getexactmethod(typeconstants.readobject, new typebinding[] { argumenttypebinding }, compilationunitscope);
hasreadobjectmethod = methodbinding != null
&& methodbinding.isvalidbinding()
&& methodbinding.modifiers == classfileconstants.accprivate
&& methodbinding.returntype == typebinding.void
&& (throwsexceptions = methodbinding.thrownexceptions).length == 1
&& throwsexceptions[0].id == typeids.t_javaioexception;
}
needserialversion = !haswriteobjectmethod || !hasreadobjectmethod;
}
}
// generics (and non static generic members) cannot extend throwable
if (sourcetype.findsupertypeoriginatingfrom(typeids.t_javalangthrowable, true) != null) {
referencebinding current = sourcetype;
checkenclosedingeneric : do {
if (current.isgenerictype()) {
this.scope.problemreporter().generictypecannotextendthrowable(this);
break checkenclosedingeneric;
}
if (current.isstatic()) break checkenclosedingeneric;
if (current.islocaltype()) {
nestedtypebinding nestedtype = (nestedtypebinding) current.erasure();
if (nestedtype.scope.methodscope().isstatic) break checkenclosedingeneric;
}
} while ((current = current.enclosingtype()) != null);
}
// this.maxfieldcount might already be set
int localmaxfieldcount = 0;
int lastvisiblefieldid = -1;
boolean hasenumconstants = false;
fielddeclaration[] enumconstantswithoutbody = null;

if (this.typeparameters != null) {
for (int i = 0, count = this.typeparameters.length; i < count; i++) {
this.typeparameters[i].resolve(this.scope);
}
}
if (this.membertypes != null) {
for (int i = 0, count = this.membertypes.length; i < count; i++) {
this.membertypes[i].resolve(this.scope);
}
}
if (this.fields != null) {
for (int i = 0, count = this.fields.length; i < count; i++) {
fielddeclaration field = this.fields[i];
switch(field.getkind()) {
case abstractvariabledeclaration.enum_constant:
hasenumconstants = true;
if (!(field.initialization instanceof qualifiedallocationexpression)) {
if (enumconstantswithoutbody == null)
enumconstantswithoutbody = new fielddeclaration[count];
enumconstantswithoutbody[i] = field;
}
//$fall-through$
case abstractvariabledeclaration.field:
fieldbinding fieldbinding = field.binding;
if (fieldbinding == null) {
// still discover secondary errors
if (field.initialization != null) field.initialization.resolve(field.isstatic() ? this.staticinitializerscope : this.initializerscope);
this.ignorefurtherinvestigation = true;
continue;
}
if (needserialversion
&& ((fieldbinding.modifiers & (classfileconstants.accstatic | classfileconstants.accfinal)) == (classfileconstants.accstatic | classfileconstants.accfinal))
&& charoperation.equals(typeconstants.serialversionuid, fieldbinding.name)
&& typebinding.long == fieldbinding.type) {
needserialversion = false;
}
localmaxfieldcount++;
lastvisiblefieldid = field.binding.id;
break;

case abstractvariabledeclaration.initializer:
((initializer) field).lastvisiblefieldid = lastvisiblefieldid + 1;
break;
}
field.resolve(field.isstatic() ? this.staticinitializerscope : this.initializerscope);
}
}
if (this.maxfieldcount < localmaxfieldcount) {
this.maxfieldcount = localmaxfieldcount;
}
if (needserialversion) {
//check that the current type doesn't extend javax.rmi.corba.stub
typebinding javaxrmicorbastub = this.scope.gettype(typeconstants.javax_rmi_corba_stub, 4);
if (javaxrmicorbastub.isvalidbinding()) {
referencebinding superclassbinding = this.binding.superclass;
loop: while (superclassbinding != null) {
if (superclassbinding == javaxrmicorbastub) {
needserialversion = false;
break loop;
}
superclassbinding = superclassbinding.superclass();
}
}
if (needserialversion) {
this.scope.problemreporter().missingserialversion(this);
}
}

// check extends/implements for annotation type
switch(kind(this.modifiers)) {
case typedeclaration.annotation_type_decl :
if (this.superclass != null) {
this.scope.problemreporter().annotationtypedeclarationcannothavesuperclass(this);
}
if (this.superinterfaces != null) {
this.scope.problemreporter().annotationtypedeclarationcannothavesuperinterfaces(this);
}
break;
case typedeclaration.enum_decl :
// check enum abstract methods
if (this.binding.isabstract()) {
if (!hasenumconstants) {
for (int i = 0, count = this.methods.length; i < count; i++) {
final abstractmethoddeclaration methoddeclaration = this.methods[i];
if (methoddeclaration.isabstract() && methoddeclaration.binding != null)
this.scope.problemreporter().enumabstractmethodmustbeimplemented(methoddeclaration);
}
} else if (enumconstantswithoutbody != null) {
for (int i = 0, count = this.methods.length; i < count; i++) {
final abstractmethoddeclaration methoddeclaration = this.methods[i];
if (methoddeclaration.isabstract() && methoddeclaration.binding != null) {
for (int f = 0, l = enumconstantswithoutbody.length; f < l; f++)
if (enumconstantswithoutbody[f] != null)
this.scope.problemreporter().enumconstantmustimplementabstractmethod(methoddeclaration, enumconstantswithoutbody[f]);
}
}
}
}
break;
}

int missingabstractmethodslength = this.missingabstractmethods == null ? 0 : this.missingabstractmethods.length;
int methodslength = this.methods == null ? 0 : this.methods.length;
if ((methodslength + missingabstractmethodslength) > 0xffff) {
this.scope.problemreporter().toomanymethods(this);
}
if (this.methods != null) {
for (int i = 0, count = this.methods.length; i < count; i++) {
this.methods[i].resolve(this.scope);
}
}
// resolve javadoc
if (this.javadoc != null) {
if (this.scope != null && (this.name != typeconstants.package_info_name)) {
// if the type is package-info, the javadoc was resolved as part of the compilation unit javadoc
this.javadoc.resolve(this.scope);
}
} else if (!sourcetype.islocaltype()) {
// set javadoc visibility
int visibility = sourcetype.modifiers & extracompilermodifiers.accvisibilitymask;
problemreporter reporter = this.scope.problemreporter();
int severity = reporter.computeseverity(iproblem.javadocmissing);
if (severity != problemseverities.ignore) {
if (this.enclosingtype != null) {
visibility = util.computeoutermostvisibility(this.enclosingtype, visibility);
}
int javadocmodifiers = (this.binding.modifiers & ~extracompilermodifiers.accvisibilitymask) | visibility;
reporter.javadocmissing(this.sourcestart, this.sourceend, severity, javadocmodifiers);
}
}
} catch (aborttype e) {
this.ignorefurtherinvestigation = true;
return;
}
}

/**
* resolve a local type declaration
*/
public void resolve(blockscope blockscope) {

// need to build its scope first and proceed with binding's creation
if ((this.bits & astnode.isanonymoustype) == 0) {
// check collision scenarii
binding existing = blockscope.gettype(this.name);
if (existing instanceof referencebinding
&& existing != this.binding
&& existing.isvalidbinding()) {
referencebinding existingtype = (referencebinding) existing;
if (existingtype instanceof typevariablebinding) {
blockscope.problemreporter().typehiding(this, (typevariablebinding) existingtype);
} else if (existingtype instanceof localtypebinding
&& ((localtypebinding) existingtype).scope.methodscope() == blockscope.methodscope()) {
// dup in same method
blockscope.problemreporter().duplicatenestedtype(this);
} else if (blockscope.isdefinedintype(existingtype)) {
//	collision with enclosing type
blockscope.problemreporter().typecollideswithenclosingtype(this);
} else if (blockscope.isdefinedinsameunit(existingtype)){ // only consider hiding inside same unit
// hiding sibling
blockscope.problemreporter().typehiding(this, existingtype);
}
}
blockscope.addlocaltype(this);
}

if (this.binding != null) {
// remember local types binding for innerclass emulation propagation
blockscope.referencecompilationunit().record((localtypebinding)this.binding);

// binding is not set if the receiver could not be created
resolve();
updatemaxfieldcount();
}
}

/**
* resolve a member type declaration (can be a local member)
*/
public void resolve(classscope upperscope) {
// member scopes are already created
// request the construction of a binding if local member type

if (this.binding != null && this.binding instanceof localtypebinding) {
// remember local types binding for innerclass emulation propagation
upperscope.referencecompilationunit().record((localtypebinding)this.binding);
}
resolve();
updatemaxfieldcount();
}

/**
* resolve a top level type declaration
*/
public void resolve(compilationunitscope upperscope) {
// top level : scope are already created
resolve();
updatemaxfieldcount();
}

public void tagashavingerrors() {
this.ignorefurtherinvestigation = true;
}

/**
*	iteration for a package member type
*
*/
public void traverse(astvisitor visitor, compilationunitscope unitscope) {
try {
if (visitor.visit(this, unitscope)) {
if (this.javadoc != null) {
this.javadoc.traverse(visitor, this.scope);
}
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, this.staticinitializerscope);
}
if (this.superclass != null)
this.superclass.traverse(visitor, this.scope);
if (this.superinterfaces != null) {
int length = this.superinterfaces.length;
for (int i = 0; i < length; i++)
this.superinterfaces[i].traverse(visitor, this.scope);
}
if (this.typeparameters != null) {
int length = this.typeparameters.length;
for (int i = 0; i < length; i++) {
this.typeparameters[i].traverse(visitor, this.scope);
}
}
if (this.membertypes != null) {
int length = this.membertypes.length;
for (int i = 0; i < length; i++)
this.membertypes[i].traverse(visitor, this.scope);
}
if (this.fields != null) {
int length = this.fields.length;
for (int i = 0; i < length; i++) {
fielddeclaration field;
if ((field = this.fields[i]).isstatic()) {
field.traverse(visitor, this.staticinitializerscope);
} else {
field.traverse(visitor, this.initializerscope);
}
}
}
if (this.methods != null) {
int length = this.methods.length;
for (int i = 0; i < length; i++)
this.methods[i].traverse(visitor, this.scope);
}
}
visitor.endvisit(this, unitscope);
} catch (aborttype e) {
// silent abort
}
}

/**
*	iteration for a local innertype
*/
public void traverse(astvisitor visitor, blockscope blockscope) {
try {
if (visitor.visit(this, blockscope)) {
if (this.javadoc != null) {
this.javadoc.traverse(visitor, this.scope);
}
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, this.staticinitializerscope);
}
if (this.superclass != null)
this.superclass.traverse(visitor, this.scope);
if (this.superinterfaces != null) {
int length = this.superinterfaces.length;
for (int i = 0; i < length; i++)
this.superinterfaces[i].traverse(visitor, this.scope);
}
if (this.typeparameters != null) {
int length = this.typeparameters.length;
for (int i = 0; i < length; i++) {
this.typeparameters[i].traverse(visitor, this.scope);
}
}
if (this.membertypes != null) {
int length = this.membertypes.length;
for (int i = 0; i < length; i++)
this.membertypes[i].traverse(visitor, this.scope);
}
if (this.fields != null) {
int length = this.fields.length;
for (int i = 0; i < length; i++) {
fielddeclaration field;
if ((field = this.fields[i]).isstatic()) {
// local type cannot have static fields
} else {
field.traverse(visitor, this.initializerscope);
}
}
}
if (this.methods != null) {
int length = this.methods.length;
for (int i = 0; i < length; i++)
this.methods[i].traverse(visitor, this.scope);
}
}
visitor.endvisit(this, blockscope);
} catch (aborttype e) {
// silent abort
}
}

/**
*	iteration for a member innertype
*
*/
public void traverse(astvisitor visitor, classscope classscope) {
try {
if (visitor.visit(this, classscope)) {
if (this.javadoc != null) {
this.javadoc.traverse(visitor, this.scope);
}
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, this.staticinitializerscope);
}
if (this.superclass != null)
this.superclass.traverse(visitor, this.scope);
if (this.superinterfaces != null) {
int length = this.superinterfaces.length;
for (int i = 0; i < length; i++)
this.superinterfaces[i].traverse(visitor, this.scope);
}
if (this.typeparameters != null) {
int length = this.typeparameters.length;
for (int i = 0; i < length; i++) {
this.typeparameters[i].traverse(visitor, this.scope);
}
}
if (this.membertypes != null) {
int length = this.membertypes.length;
for (int i = 0; i < length; i++)
this.membertypes[i].traverse(visitor, this.scope);
}
if (this.fields != null) {
int length = this.fields.length;
for (int i = 0; i < length; i++) {
fielddeclaration field;
if ((field = this.fields[i]).isstatic()) {
field.traverse(visitor, this.staticinitializerscope);
} else {
field.traverse(visitor, this.initializerscope);
}
}
}
if (this.methods != null) {
int length = this.methods.length;
for (int i = 0; i < length; i++)
this.methods[i].traverse(visitor, this.scope);
}
}
visitor.endvisit(this, classscope);
} catch (aborttype e) {
// silent abort
}
}

/**
* maxfieldcount's computation is necessary so as to reserve space for
* the flow info field portions. it corresponds to the maximum amount of
* fields this class or one of its innertypes have.
*
* during name resolution, types are traversed, and the max field count is recorded
* on the outermost type. it is then propagated down during the flow analysis.
*
* this method is doing either up/down propagation.
*/
void updatemaxfieldcount() {
if (this.binding == null)
return; // error scenario
typedeclaration outermosttype = this.scope.outermostclassscope().referencetype();
if (this.maxfieldcount > outermosttype.maxfieldcount) {
outermosttype.maxfieldcount = this.maxfieldcount; // up
} else {
this.maxfieldcount = outermosttype.maxfieldcount; // down
}
}

/**
* returns whether the type is a secondary one or not.
*/
public boolean issecondary() {
return (this.bits & astnode.issecondarytype) != 0;
}
}
