/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.wildcard;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;

/**
* binding for a type parameter, held by source/binary type or method.
*/
public class typevariablebinding extends referencebinding {

public binding declaringelement; // binding of declaring type or method
public int rank; // declaration rank, can be used to match variable in parameterized type

/**
* denote the first explicit (binding) bound amongst the supertypes (from declaration in source)
* if no superclass was specified, then it denotes the first superinterface, or null if none was specified.
*/
public typebinding firstbound;

// actual resolved variable supertypes (if no superclass bound, then associated to object)
public referencebinding superclass;
public referencebinding[] superinterfaces;
public char[] generictypesignature;
lookupenvironment environment;

public typevariablebinding(char[] sourcename, binding declaringelement, int rank, lookupenvironment environment) {
this.sourcename = sourcename;
this.declaringelement = declaringelement;
this.rank = rank;
this.modifiers = classfileconstants.accpublic | extracompilermodifiers.accgenericsignature; // treat type var as public
this.tagbits |= tagbits.hastypevariable;
this.environment = environment;
}

/**
* returns true if the argument type satisfies all bounds of the type parameter
*/
public int boundcheck(substitution substitution, typebinding argumenttype) {
if (argumenttype == typebinding.null || argumenttype == this) {
return typeconstants.ok;
}
boolean hassubstitution = substitution != null;
if (!(argumenttype instanceof referencebinding || argumenttype.isarraytype()))
return typeconstants.mismatch;
// special case for re-entrant source types (selection, code assist, etc)...
// can request additional types during hierarchy walk that are found as source types that also 'need' to connect their hierarchy
if (this.superclass == null)
return typeconstants.ok;

if (argumenttype.kind() == binding.wildcard_type) {
wildcardbinding wildcard = (wildcardbinding) argumenttype;
switch(wildcard.boundkind) {
case wildcard.extends :
typebinding wildcardbound = wildcard.bound;
if (wildcardbound == this)
return typeconstants.ok;
boolean isarraybound = wildcardbound.isarraytype();
if (!wildcardbound.isinterface()) {
typebinding substitutedsupertype = hassubstitution ? scope.substitute(substitution, this.superclass) : this.superclass;
if (substitutedsupertype.id != typeids.t_javalangobject) {
if (isarraybound) {
if (!wildcardbound.iscompatiblewith(substitutedsupertype))
return typeconstants.mismatch;
} else {
typebinding match = wildcardbound.findsupertypeoriginatingfrom(substitutedsupertype);
if (match != null) {
if (substitutedsupertype.isprovablydistinct(match)) {
return typeconstants.mismatch;
}
} else {
match =  substitutedsupertype.findsupertypeoriginatingfrom(wildcardbound);
if (match != null) {
if (match.isprovablydistinct(wildcardbound)) {
return typeconstants.mismatch;
}
} else {
if (!wildcardbound.istypevariable() && !substitutedsupertype.istypevariable()) {
return typeconstants.mismatch;
}
}
}
}
}
}
boolean mustimplement = isarraybound || ((referencebinding)wildcardbound).isfinal();
for (int i = 0, length = this.superinterfaces.length; i < length; i++) {
typebinding substitutedsupertype = hassubstitution ? scope.substitute(substitution, this.superinterfaces[i]) : this.superinterfaces[i];
if (isarraybound) {
if (!wildcardbound.iscompatiblewith(substitutedsupertype))
return typeconstants.mismatch;
} else {
typebinding match = wildcardbound.findsupertypeoriginatingfrom(substitutedsupertype);
if (match != null) {
if (substitutedsupertype.isprovablydistinct(match)) {
return typeconstants.mismatch;
}
} else if (mustimplement) {
return typeconstants.mismatch; // cannot be extended further to satisfy missing bounds
}
}

}
break;

case wildcard.super :
return boundcheck(substitution, wildcard.bound);

case wildcard.unbound :
break;
}
return typeconstants.ok;
}
boolean unchecked = false;
if (this.superclass.id != typeids.t_javalangobject) {
typebinding substitutedsupertype = hassubstitution ? scope.substitute(substitution, this.superclass) : this.superclass;
if (substitutedsupertype != argumenttype) {
if (!argumenttype.iscompatiblewith(substitutedsupertype)) {
return typeconstants.mismatch;
}
typebinding match = argumenttype.findsupertypeoriginatingfrom(substitutedsupertype);
if (match != null){
// enum#raw is not a substitute for <e extends enum<e>> (86838)
if (match.israwtype() && substitutedsupertype.isboundparameterizedtype())
unchecked = true;
}
}
}
for (int i = 0, length = this.superinterfaces.length; i < length; i++) {
typebinding substitutedsupertype = hassubstitution ? scope.substitute(substitution, this.superinterfaces[i]) : this.superinterfaces[i];
if (substitutedsupertype != argumenttype) {
if (!argumenttype.iscompatiblewith(substitutedsupertype)) {
return typeconstants.mismatch;
}
typebinding match = argumenttype.findsupertypeoriginatingfrom(substitutedsupertype);
if (match != null){
// enum#raw is not a substitute for <e extends enum<e>> (86838)
if (match.israwtype() && substitutedsupertype.isboundparameterizedtype())
unchecked = true;
}
}
}
return unchecked ? typeconstants.unchecked : typeconstants.ok;
}

public int boundscount() {
if (this.firstbound == null) {
return 0;
} else if (this.firstbound == this.superclass) {
return this.superinterfaces.length + 1;
} else {
return this.superinterfaces.length;
}
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#canbeinstantiated()
*/
public boolean canbeinstantiated() {
return false;
}
/**
* collect the substitutes into a map for certain type variables inside the receiver type
* e.g.   collection<t>.collectsubstitutes(collection<list<x>>, map), will populate map with: t --> list<x>
* constraints:
*   a << f   corresponds to:   f.collectsubstitutes(..., a, ..., constraint_extends (1))
*   a = f   corresponds to:      f.collectsubstitutes(..., a, ..., constraint_equal (0))
*   a >> f   corresponds to:   f.collectsubstitutes(..., a, ..., constraint_super (2))
*/
public void collectsubstitutes(scope scope, typebinding actualtype, inferencecontext inferencecontext, int constraint) {

//	only infer for type params of the generic method
if (this.declaringelement != inferencecontext.genericmethod) return;

// cannot infer anything from a null type
switch (actualtype.kind()) {
case binding.base_type :
if (actualtype == typebinding.null) return;
typebinding boxedtype = scope.environment().computeboxingtype(actualtype);
if (boxedtype == actualtype) return;
actualtype = boxedtype;
break;
case binding.wildcard_type :
return; // wildcards are not true type expressions (jls 15.12.2.7, p.453 2nd discussion)
}

// reverse constraint, to reflect variable on rhs:   a << t --> t >: a
int variableconstraint;
switch(constraint) {
case typeconstants.constraint_equal :
variableconstraint = typeconstants.constraint_equal;
break;
case typeconstants.constraint_extends :
variableconstraint = typeconstants.constraint_super;
break;
default:
//case constraint_super :
variableconstraint =typeconstants.constraint_extends;
break;
}
inferencecontext.recordsubstitute(this, actualtype, variableconstraint);
}

/*
* declaringuniquekey : generictypesignature
* p.x<t> { ... } --> lp/x;:tt;
* p.x { <t> void foo() {...} } --> lp/x;.foo()v:tt;
*/
public char[] computeuniquekey(boolean isleaf) {
stringbuffer buffer = new stringbuffer();
binding declaring = this.declaringelement;
if (!isleaf && declaring.kind() == binding.method) { // see https://bugs.eclipse.org/bugs/show_bug.cgi?id=97902
methodbinding methodbinding = (methodbinding) declaring;
referencebinding declaringclass = methodbinding.declaringclass;
buffer.append(declaringclass.computeuniquekey(false/*not a leaf*/));
buffer.append(':');
methodbinding[] methods = declaringclass.methods();
if (methods != null)
for (int i = 0, length = methods.length; i < length; i++) {
methodbinding binding = methods[i];
if (binding == methodbinding) {
buffer.append(i);
break;
}
}
} else {
buffer.append(declaring.computeuniquekey(false/*not a leaf*/));
buffer.append(':');
}
buffer.append(generictypesignature());
int length = buffer.length();
char[] uniquekey = new char[length];
buffer.getchars(0, length, uniquekey, 0);
return uniquekey;
}
public char[] constantpoolname() { /* java/lang/object */
if (this.firstbound != null) {
return this.firstbound.constantpoolname();
}
return this.superclass.constantpoolname(); // java/lang/object
}
/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#debugname()
*/
public string debugname() {
return new string(this.sourcename);
}
public typebinding erasure() {
if (this.firstbound != null) {
return this.firstbound.erasure();
}
return this.superclass; // java/lang/object
}
/**
* t::ljava/util/map;:ljava/io/serializable;
* t:ly<tt;>
*/
public char[] genericsignature() {
stringbuffer sig = new stringbuffer(10);
sig.append(this.sourcename).append(':');
int interfacelength = this.superinterfaces == null ? 0 : this.superinterfaces.length;
if (interfacelength == 0 || this.firstbound == this.superclass) {
if (this.superclass != null)
sig.append(this.superclass.generictypesignature());
}
for (int i = 0; i < interfacelength; i++) {
sig.append(':').append(this.superinterfaces[i].generictypesignature());
}
int siglength = sig.length();
char[] genericsignature = new char[siglength];
sig.getchars(0, siglength, genericsignature, 0);
return genericsignature;
}
/**
* t::ljava/util/map;:ljava/io/serializable;
* t:ly<tt;>
*/
public char[] generictypesignature() {
if (this.generictypesignature != null) return this.generictypesignature;
return this.generictypesignature = charoperation.concat('t', this.sourcename, ';');
}

boolean hasonlyrawbounds() {
if (this.superclass != null && this.firstbound == this.superclass)
if (!this.superclass.israwtype())
return false;

if (this.superinterfaces != null)
for (int i = 0, l = this.superinterfaces.length; i < l; i++)
if (!this.superinterfaces[i].israwtype())
return false;

return true;
}

/**
* returns true if the type variable is directly bound to a given type
*/
public boolean iserasureboundto(typebinding type) {
if (this.superclass.erasure() == type)
return true;
for (int i = 0, length = this.superinterfaces.length; i < length; i++) {
if (this.superinterfaces[i].erasure() == type)
return true;
}
return false;
}

public boolean ishierarchyconnected() {
return (this.modifiers & extracompilermodifiers.accunresolved) == 0;
}

/**
* returns true if the 2 variables are playing exact same role: they have
* the same bounds, providing one is substituted with the other: <t1 extends
* list<t1>> is interchangeable with <t2 extends list<t2>>.
*/
public boolean isinterchangeablewith(typevariablebinding othervariable, substitution substitute) {
if (this == othervariable)
return true;
int length = this.superinterfaces.length;
if (length != othervariable.superinterfaces.length)
return false;

if (this.superclass != scope.substitute(substitute, othervariable.superclass))
return false;

next : for (int i = 0; i < length; i++) {
typebinding supertype = scope.substitute(substitute, othervariable.superinterfaces[i]);
for (int j = 0; j < length; j++)
if (supertype == this.superinterfaces[j])
continue next;
return false; // not a match
}
return true;
}

/**
* returns true if the type was declared as a type variable
*/
public boolean istypevariable() {
return true;
}

//	/**
//	 * returns the original type variable for a given variable.
//	 * only different from receiver for type variables of generic methods of parameterized types
//	 * e.g. x<u> {   <v1 extends u> u foo(v1)   } --> x<string> { <v2 extends string> string foo(v2)  }
//	 *         and v2.original() --> v1
//	 */
//	public typevariablebinding original() {
//		if (this.declaringelement.kind() == binding.method) {
//			methodbinding originalmethod = ((methodbinding)this.declaringelement).original();
//			if (originalmethod != this.declaringelement) {
//				return originalmethod.typevariables[this.rank];
//			}
//		} else {
//			referencebinding originaltype = (referencebinding)((referencebinding)this.declaringelement).erasure();
//			if (originaltype != this.declaringelement) {
//				return originaltype.typevariables()[this.rank];
//			}
//		}
//		return this;
//	}

public int kind() {
return binding.type_parameter;
}

public typebinding[] otherupperbounds() {
if (this.firstbound == null)
return binding.no_types;
if (this.firstbound == this.superclass)
return this.superinterfaces;
int otherlength = this.superinterfaces.length - 1;
if (otherlength > 0) {
typebinding[] otherbounds;
system.arraycopy(this.superinterfaces, 1, otherbounds = new typebinding[otherlength], 0, otherlength);
return otherbounds;
}
return binding.no_types;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#readablename()
*/
public char[] readablename() {
return this.sourcename;
}
referencebinding resolve() {
if ((this.modifiers & extracompilermodifiers.accunresolved) == 0)
return this;

typebinding oldsuperclass = this.superclass, oldfirstinterface = null;
if (this.superclass != null) {
referencebinding resolvetype = (referencebinding) binarytypebinding.resolvetype(this.superclass, this.environment, true /* raw conversion */);
this.tagbits |= resolvetype.tagbits & tagbits.containsnestedtypereferences;
this.superclass = resolvetype;
}
referencebinding[] interfaces = this.superinterfaces;
int length;
if ((length = interfaces.length) != 0) {
oldfirstinterface = interfaces[0];
for (int i = length; --i >= 0;) {
referencebinding resolvetype = (referencebinding) binarytypebinding.resolvetype(interfaces[i], this.environment, true /* raw conversion */);
this.tagbits |= resolvetype.tagbits & tagbits.containsnestedtypereferences;
interfaces[i] = resolvetype;
}
}
// refresh the firstbound in case it changed
if (this.firstbound != null) {
if (this.firstbound == oldsuperclass) {
this.firstbound = this.superclass;
} else if (this.firstbound == oldfirstinterface) {
this.firstbound = interfaces[0];
}
}
this.modifiers &= ~extracompilermodifiers.accunresolved;
return this;
}
/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#shortreadablename()
*/
public char[] shortreadablename() {
return readablename();
}
public referencebinding superclass() {
return this.superclass;
}

public referencebinding[] superinterfaces() {
return this.superinterfaces;
}

/**
* @@see java.lang.object#tostring()
*/
public string tostring() {
stringbuffer buffer = new stringbuffer(10);
buffer.append('<').append(this.sourcename);//.append('[').append(this.rank).append(']');
if (this.superclass != null && this.firstbound == this.superclass) {
buffer.append(" extends ").append(this.superclass.debugname()); //$non-nls-1$
}
if (this.superinterfaces != null && this.superinterfaces != binding.no_superinterfaces) {
if (this.firstbound != this.superclass) {
buffer.append(" extends "); //$non-nls-1$
}
for (int i = 0, length = this.superinterfaces.length; i < length; i++) {
if (i > 0 || this.firstbound == this.superclass) {
buffer.append(" & "); //$non-nls-1$
}
buffer.append(this.superinterfaces[i].debugname());
}
}
buffer.append('>');
return buffer.tostring();
}

/**
* upper bound doesn't perform erasure
*/
public typebinding upperbound() {
if (this.firstbound != null) {
return this.firstbound;
}
return this.superclass; // java/lang/object
}
}
