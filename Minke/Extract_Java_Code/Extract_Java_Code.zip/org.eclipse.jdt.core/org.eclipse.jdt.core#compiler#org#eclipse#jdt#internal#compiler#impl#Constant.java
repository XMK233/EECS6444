/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.impl;

import org.eclipse.jdt.internal.compiler.ast.operatorids;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.problem.shouldnotimplement;
import org.eclipse.jdt.internal.compiler.util.messages;

public abstract class constant implements typeids, operatorids {

public static final constant notaconstant = doubleconstant.fromvalue(double.nan);

public boolean booleanvalue() {
throw new shouldnotimplement(messages.bind(messages.constant_cannotcastedinto, new string[] { typename(), "boolean" })); //$non-nls-1$
}

public byte bytevalue() {
throw new shouldnotimplement(messages.bind(messages.constant_cannotcastedinto, new string[] { typename(), "byte" })); //$non-nls-1$
}

public final constant castto(int conversiontotargettype){
//the cast is an int of the form
// (castid<<4)+typeid (in order to follow the
//user written style (cast)expression ....

if (this == notaconstant) return notaconstant;
switch(conversiontotargettype){
case t_undefined : 						return this;
//            target type  <- from type
//	    case (t_undefined<<4)+t_undefined  	 : return notaconstant;
//	    case (t_undefined<<4)+t_byte  		 : return notaconstant;
//	    case (t_undefined<<4)+t_long  		 : return notaconstant;
//	    case (t_undefined<<4)+t_short  		 : return notaconstant;
//	    case (t_undefined<<4)+t_void  		 : return notaconstant;
//	    case (t_undefined<<4)+t_string  	 : return notaconstant;
//	    case (t_undefined<<4)+t_object  	 : return notaconstant;
//	    case (t_undefined<<4)+t_double  	 : return notaconstant;
//	    case (t_undefined<<4)+t_float  		 : return notaconstant;
//	    case (t_undefined<<4)+t_boolean 	 : return notaconstant;
//	    case (t_undefined<<4)+t_char  		 : return notaconstant;
//	    case (t_undefined<<4)+t_int  		 : return notaconstant;

//	    case (t_byte<<4)+t_undefined  	 : return notaconstant;
case (t_byte<<4)+t_byte  		 : return this;
case (t_byte<<4)+t_long  		 : return byteconstant.fromvalue((byte)longvalue());
case (t_byte<<4)+t_short  		 : return byteconstant.fromvalue((byte)shortvalue());
//	    case (t_byte<<4)+t_void  		 : return notaconstant;
//	    case (t_byte<<4)+t_string  	 	 : return notaconstant;
//	    case (t_byte<<4)+t_object  	 	 : return notaconstant;
case (t_byte<<4)+t_double  	 	 : return byteconstant.fromvalue((byte)doublevalue());
case (t_byte<<4)+t_float  		 : return byteconstant.fromvalue((byte)floatvalue());
//	    case (t_byte<<4)+t_boolean  	 : return notaconstant;
case (t_byte<<4)+t_char  		 : return byteconstant.fromvalue((byte)charvalue());
case (t_byte<<4)+t_int  		 : return byteconstant.fromvalue((byte)intvalue());

//	    case (t_long<<4)+t_undefined  	 : return notaconstant;
case (t_long<<4)+t_byte  		 : return longconstant.fromvalue(bytevalue());
case (t_long<<4)+t_long  		 : return this;
case (t_long<<4)+t_short  		 : return longconstant.fromvalue(shortvalue());
//	    case (t_long<<4)+t_void  		 : return notaconstant;
//	    case (t_long<<4)+t_string  		 : return notaconstant;
//	    case (t_long<<4)+t_object  		 : return notaconstant;
case (t_long<<4)+t_double  		 : return longconstant.fromvalue((long)doublevalue());
case (t_long<<4)+t_float  		 : return longconstant.fromvalue((long)floatvalue());
//	    case (t_long<<4)+t_boolean  	 : return notaconstant;
case (t_long<<4)+t_char  		 : return longconstant.fromvalue(charvalue());
case (t_long<<4)+t_int  		 : return longconstant.fromvalue(intvalue());

//	    case (t_short<<4)+t_undefined  	 : return notaconstant;
case (t_short<<4)+t_byte  		 : return shortconstant.fromvalue(bytevalue());
case (t_short<<4)+t_long  		 : return shortconstant.fromvalue((short)longvalue());
case (t_short<<4)+t_short  		 : return this;
//	    case (t_short<<4)+t_void  		 : return notaconstant;
//	    case (t_short<<4)+t_string  	 : return notaconstant;
//	    case (t_short<<4)+t_object  	 : return notaconstant;
case (t_short<<4)+t_double  	 : return shortconstant.fromvalue((short)doublevalue());
case (t_short<<4)+t_float  		 : return shortconstant.fromvalue((short)floatvalue());
//	    case (t_short<<4)+t_boolean 	 : return notaconstant;
case (t_short<<4)+t_char  		 : return shortconstant.fromvalue((short)charvalue());
case (t_short<<4)+t_int  		 : return shortconstant.fromvalue((short)intvalue());

//	    case (t_void<<4)+t_undefined  	 : return notaconstant;
//	    case (t_void<<4)+t_byte  		 : return notaconstant;
//	    case (t_void<<4)+t_long  		 : return notaconstant;
//	    case (t_void<<4)+t_short  		 : return notaconstant;
//	    case (t_void<<4)+t_void  		 : return notaconstant;
//	    case (t_void<<4)+t_string  	 	 : return notaconstant;
//	    case (t_void<<4)+t_object  	 	 : return notaconstant;
//	    case (t_void<<4)+t_double  	 	 : return notaconstant;
//	    case (t_void<<4)+t_float  		 : return notaconstant;
//	    case (t_void<<4)+t_boolean  	 : return notaconstant;
//	    case (t_void<<4)+t_char  		 : return notaconstant;
//	    case (t_void<<4)+t_int  		 : return notaconstant;

//	    case (t_string<<4)+t_undefined   : return notaconstant;
//	    case (t_string<<4)+t_byte  		 : return notaconstant;
//	    case (t_string<<4)+t_long  		 : return notaconstant;
//	    case (t_string<<4)+t_short  	 : return notaconstant;
//	    case (t_string<<4)+t_void  		 : return notaconstant;
case (t_javalangstring<<4)+t_javalangstring  	 : return this;
//	    case (t_string<<4)+t_object  	 : return notaconstant;
//	    case (t_string<<4)+t_double  	 : return notaconstant;
//	    case (t_string<<4)+t_float  	 : return notaconstant;
//	    case (t_string<<4)+t_boolean 	 : return notaconstant;
//	    case (t_string<<4)+t_char  		 : return notaconstant;
//	    case (t_string<<4)+t_int  		 : return notaconstant;

//	    case (t_object<<4)+t_undefined   	: return notaconstant;
//	    case (t_object<<4)+t_byte  		 	: return notaconstant;
//	    case (t_object<<4)+t_long  		 	: return notaconstant;
//	    case (t_object<<4)+t_short 		 	: return notaconstant;
//	    case (t_object<<4)+t_void  		 	: return notaconstant;
//	    case (t_object<<4)+t_string  		: return notaconstant;
//	    case (t_object<<4)+t_object  		: return notaconstant;
//	    case (t_object<<4)+t_double  		: return notaconstant;
//	    case (t_object<<4)+t_float  		: return notaconstant;
//	    case (t_object<<4)+t_boolean 		: return notaconstant;
//	    case (t_object<<4)+t_char  		 	: return notaconstant;
//	    case (t_object<<4)+t_int  			: return notaconstant;

//	    case (t_double<<4)+t_undefined  	: return notaconstant;
case (t_double<<4)+t_byte  		 	: return doubleconstant.fromvalue(bytevalue());
case (t_double<<4)+t_long  		 	: return doubleconstant.fromvalue(longvalue());
case (t_double<<4)+t_short  		: return doubleconstant.fromvalue(shortvalue());
//	    case (t_double<<4)+t_void  		 	: return notaconstant;
//	    case (t_double<<4)+t_string  		: return notaconstant;
//	    case (t_double<<4)+t_object  		: return notaconstant;
case (t_double<<4)+t_double  		: return this;
case (t_double<<4)+t_float  		: return doubleconstant.fromvalue(floatvalue());
//	    case (t_double<<4)+t_boolean  		: return notaconstant;
case (t_double<<4)+t_char  		 	: return doubleconstant.fromvalue(charvalue());
case (t_double<<4)+t_int  			: return doubleconstant.fromvalue(intvalue());

//	    case (t_float<<4)+t_undefined  	 : return notaconstant;
case (t_float<<4)+t_byte  		 : return floatconstant.fromvalue(bytevalue());
case (t_float<<4)+t_long  		 : return floatconstant.fromvalue(longvalue());
case (t_float<<4)+t_short  		 : return floatconstant.fromvalue(shortvalue());
//	    case (t_float<<4)+t_void  		 : return notaconstant;
//	    case (t_float<<4)+t_string  	 : return notaconstant;
//	    case (t_float<<4)+t_object  	 : return notaconstant;
case (t_float<<4)+t_double  	 : return floatconstant.fromvalue((float)doublevalue());
case (t_float<<4)+t_float  		 : return this;
//	    case (t_float<<4)+t_boolean 	 : return notaconstant;
case (t_float<<4)+t_char  		 : return floatconstant.fromvalue(charvalue());
case (t_float<<4)+t_int  		 : return floatconstant.fromvalue(intvalue());

//	    case (t_boolean<<4)+t_undefined  		 : return notaconstant;
//	    case (t_boolean<<4)+t_byte  			 : return notaconstant;
//	    case (t_boolean<<4)+t_long  			 : return notaconstant;
//	    case (t_boolean<<4)+t_short  			 : return notaconstant;
//	    case (t_boolean<<4)+t_void  			 : return notaconstant;
//	    case (t_boolean<<4)+t_string  			 : return notaconstant;
//	    case (t_boolean<<4)+t_object  			 : return notaconstant;
//	    case (t_boolean<<4)+t_double  			 : return notaconstant;
//	    case (t_boolean<<4)+t_float  			 : return notaconstant;
case (t_boolean<<4)+t_boolean  			 : return this;
//	    case (t_boolean<<4)+t_char  			 : return notaconstant;
//	    case (t_boolean<<4)+t_int  				 : return notaconstant;

//	    case (t_char<<4)+t_undefined  	 : return notaconstant;
case (t_char<<4)+t_byte  		 : return charconstant.fromvalue((char)bytevalue());
case (t_char<<4)+t_long  		 : return charconstant.fromvalue((char)longvalue());
case (t_char<<4)+t_short  		 : return charconstant.fromvalue((char)shortvalue());
//	    case (t_char<<4)+t_void  		 : return notaconstant;
//	    case (t_char<<4)+t_string  		 : return notaconstant;
//	    case (t_char<<4)+t_object  		 : return notaconstant;
case (t_char<<4)+t_double  		 : return charconstant.fromvalue((char)doublevalue());
case (t_char<<4)+t_float  		 : return charconstant.fromvalue((char)floatvalue());
//	    case (t_char<<4)+t_boolean  	 : return notaconstant;
case (t_char<<4)+t_char  		 : return this;
case (t_char<<4)+t_int  		 : return charconstant.fromvalue((char)intvalue());

//	    case (t_int<<4)+t_undefined  	 : return notaconstant;
case (t_int<<4)+t_byte  		 : return intconstant.fromvalue(bytevalue());
case (t_int<<4)+t_long  		 : return intconstant.fromvalue((int) longvalue());
case (t_int<<4)+t_short  		 : return intconstant.fromvalue(shortvalue());
//	    case (t_int<<4)+t_void  		 : return notaconstant;
//	    case (t_int<<4)+t_string  		 : return notaconstant;
//	    case (t_int<<4)+t_object  		 : return notaconstant;
case (t_int<<4)+t_double  		 : return intconstant.fromvalue((int) doublevalue());
case (t_int<<4)+t_float  		 : return intconstant.fromvalue((int) floatvalue());
//	    case (t_int<<4)+t_boolean  	 	 : return notaconstant;
case (t_int<<4)+t_char  		 : return intconstant.fromvalue(charvalue());
case (t_int<<4)+t_int  		 	 : return this;

}
return notaconstant;
}

public char charvalue() {
throw new shouldnotimplement(messages.bind(messages.constant_cannotcastedinto, new string[] { typename(), "char" })); //$non-nls-1$
}

public static final constant computeconstantoperation(constant cst, int id, int operator) {
switch (operator) {
case not	:
return booleanconstant.fromvalue(!cst.booleanvalue());
case plus	:
return computeconstantoperationplus(intconstant.fromvalue(0),t_int,cst,id);
case minus	:	//the two special -9223372036854775808l and -2147483648 are inlined at parsetime
switch (id){
case t_float  :	float f;
if ( (f= cst.floatvalue()) == 0.0f)
{ //positive and negative 0....
if (float.floattointbits(f) == 0)
return floatconstant.fromvalue(-0.0f);
else
return floatconstant.fromvalue(0.0f);}
break; //default case
case t_double : double d;
if ( (d= cst.doublevalue()) == 0.0d)
{ //positive and negative 0....
if (double.doubletolongbits(d) == 0)
return doubleconstant.fromvalue(-0.0d);
else
return doubleconstant.fromvalue(0.0d);}
break; //default case
}
return computeconstantoperationminus(intconstant.fromvalue(0),t_int,cst,id);
case twiddle:
switch (id){
case t_char :	return intconstant.fromvalue(~ cst.charvalue());
case t_byte:	return intconstant.fromvalue(~ cst.bytevalue());
case t_short:	return intconstant.fromvalue(~ cst.shortvalue());
case t_int:		return intconstant.fromvalue(~ cst.intvalue());
case t_long:	return longconstant.fromvalue(~ cst.longvalue());
default : return notaconstant;
}
default : return notaconstant;
}
}

public static final constant computeconstantoperation(constant left, int leftid, int operator, constant right, int rightid) {
switch (operator) {
case and		: return computeconstantoperationand		(left,leftid,right,rightid);
case and_and	: return computeconstantoperationand_and	(left,leftid,right,rightid);
case divide 	: return computeconstantoperationdivide		(left,leftid,right,rightid);
case greater	: return computeconstantoperationgreater	(left,leftid,right,rightid);
case greater_equal	: return computeconstantoperationgreater_equal(left,leftid,right,rightid);
case left_shift	: return computeconstantoperationleft_shift	(left,leftid,right,rightid);
case less		: return computeconstantoperationless		(left,leftid,right,rightid);
case less_equal	: return computeconstantoperationless_equal	(left,leftid,right,rightid);
case minus		: return computeconstantoperationminus		(left,leftid,right,rightid);
case multiply	: return computeconstantoperationmultiply	(left,leftid,right,rightid);
case or			: return computeconstantoperationor			(left,leftid,right,rightid);
case or_or		: return computeconstantoperationor_or		(left,leftid,right,rightid);
case plus		: return computeconstantoperationplus		(left,leftid,right,rightid);
case remainder	: return computeconstantoperationremainder	(left,leftid,right,rightid);
case right_shift: return computeconstantoperationright_shift(left,leftid,right,rightid);
case unsigned_right_shift: return computeconstantoperationunsigned_right_shift(left,leftid,right,rightid);
case xor		: return computeconstantoperationxor		(left,leftid,right,rightid);
default : return notaconstant;
}
}

public static final constant computeconstantoperationand(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_boolean :		return booleanconstant.fromvalue(left.booleanvalue() & right.booleanvalue());
case t_char :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.charvalue() & right.charvalue());
case t_byte:	return intconstant.fromvalue(left.charvalue() & right.bytevalue());
case t_short:	return intconstant.fromvalue(left.charvalue() & right.shortvalue());
case t_int:		return intconstant.fromvalue(left.charvalue() & right.intvalue());
case t_long:	return longconstant.fromvalue(left.charvalue() & right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.bytevalue() & right.charvalue());
case t_byte:	return intconstant.fromvalue(left.bytevalue() & right.bytevalue());
case t_short:	return intconstant.fromvalue(left.bytevalue() & right.shortvalue());
case t_int:		return intconstant.fromvalue(left.bytevalue() & right.intvalue());
case t_long:	return longconstant.fromvalue(left.bytevalue() & right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.shortvalue() & right.charvalue());
case t_byte:	return intconstant.fromvalue(left.shortvalue() & right.bytevalue());
case t_short:	return intconstant.fromvalue(left.shortvalue() & right.shortvalue());
case t_int:		return intconstant.fromvalue(left.shortvalue() & right.intvalue());
case t_long:	return longconstant.fromvalue(left.shortvalue() & right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.intvalue() & right.charvalue());
case t_byte:	return intconstant.fromvalue(left.intvalue() & right.bytevalue());
case t_short:	return intconstant.fromvalue(left.intvalue() & right.shortvalue());
case t_int:		return intconstant.fromvalue(left.intvalue() & right.intvalue());
case t_long:	return longconstant.fromvalue(left.intvalue() & right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return longconstant.fromvalue(left.longvalue() & right.charvalue());
case t_byte:	return longconstant.fromvalue(left.longvalue() & right.bytevalue());
case t_short:	return longconstant.fromvalue(left.longvalue() & right.shortvalue());
case t_int:		return longconstant.fromvalue(left.longvalue() & right.intvalue());
case t_long:	return longconstant.fromvalue(left.longvalue() & right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationand_and(constant left, int leftid, constant right, int rightid) {
return booleanconstant.fromvalue(left.booleanvalue() && right.booleanvalue());
}

public static final constant computeconstantoperationdivide(constant left, int leftid, constant right, int rightid) {
// division by zero must be handled outside this method (error reporting)
switch (leftid){
case t_char :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.charvalue() / right.charvalue());
case t_float:	return floatconstant.fromvalue(left.charvalue() / right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.charvalue() / right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.charvalue() / right.bytevalue());
case t_short:	return intconstant.fromvalue(left.charvalue() / right.shortvalue());
case t_int:		return intconstant.fromvalue(left.charvalue() / right.intvalue());
case t_long:	return longconstant.fromvalue(left.charvalue() / right.longvalue());
}
break;
case t_float :
switch (rightid){
case t_char :	return floatconstant.fromvalue(left.floatvalue() / right.charvalue());
case t_float:	return floatconstant.fromvalue(left.floatvalue() / right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.floatvalue() / right.doublevalue());
case t_byte:	return floatconstant.fromvalue(left.floatvalue() / right.bytevalue());
case t_short:	return floatconstant.fromvalue(left.floatvalue() / right.shortvalue());
case t_int:		return floatconstant.fromvalue(left.floatvalue() / right.intvalue());
case t_long:	return floatconstant.fromvalue(left.floatvalue() / right.longvalue());
}
break;
case t_double :
switch (rightid){
case t_char :	return doubleconstant.fromvalue(left.doublevalue() / right.charvalue());
case t_float:	return doubleconstant.fromvalue(left.doublevalue() / right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.doublevalue() / right.doublevalue());
case t_byte:	return doubleconstant.fromvalue(left.doublevalue() / right.bytevalue());
case t_short:	return doubleconstant.fromvalue(left.doublevalue() / right.shortvalue());
case t_int:		return doubleconstant.fromvalue(left.doublevalue() / right.intvalue());
case t_long:	return doubleconstant.fromvalue(left.doublevalue() / right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.bytevalue() / right.charvalue());
case t_float:	return floatconstant.fromvalue(left.bytevalue() / right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.bytevalue() / right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.bytevalue() / right.bytevalue());
case t_short:	return intconstant.fromvalue(left.bytevalue() / right.shortvalue());
case t_int:		return intconstant.fromvalue(left.bytevalue() / right.intvalue());
case t_long:	return longconstant.fromvalue(left.bytevalue() / right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.shortvalue() / right.charvalue());
case t_float:	return floatconstant.fromvalue(left.shortvalue() / right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.shortvalue() / right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.shortvalue() / right.bytevalue());
case t_short:	return intconstant.fromvalue(left.shortvalue() / right.shortvalue());
case t_int:		return intconstant.fromvalue(left.shortvalue() / right.intvalue());
case t_long:	return longconstant.fromvalue(left.shortvalue() / right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.intvalue() / right.charvalue());
case t_float:	return floatconstant.fromvalue(left.intvalue() / right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.intvalue() / right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.intvalue() / right.bytevalue());
case t_short:	return intconstant.fromvalue(left.intvalue() / right.shortvalue());
case t_int:		return intconstant.fromvalue(left.intvalue() / right.intvalue());
case t_long:	return longconstant.fromvalue(left.intvalue() / right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return longconstant.fromvalue(left.longvalue() / right.charvalue());
case t_float:	return floatconstant.fromvalue(left.longvalue() / right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.longvalue() / right.doublevalue());
case t_byte:	return longconstant.fromvalue(left.longvalue() / right.bytevalue());
case t_short:	return longconstant.fromvalue(left.longvalue() / right.shortvalue());
case t_int:		return longconstant.fromvalue(left.longvalue() / right.intvalue());
case t_long:	return longconstant.fromvalue(left.longvalue() / right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationequal_equal(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_boolean :
if (rightid == t_boolean) {
return booleanconstant.fromvalue(left.booleanvalue() == right.booleanvalue());
}
break;
case t_char :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.charvalue() == right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.charvalue() == right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.charvalue() == right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.charvalue() == right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.charvalue() == right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.charvalue() == right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.charvalue() == right.longvalue());}
break;
case t_float :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.floatvalue() == right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.floatvalue() == right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.floatvalue() == right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.floatvalue() == right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.floatvalue() == right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.floatvalue() == right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.floatvalue() == right.longvalue());
}
break;
case t_double :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.doublevalue() == right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.doublevalue() == right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.doublevalue() == right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.doublevalue() == right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.doublevalue() == right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.doublevalue() == right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.doublevalue() == right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.bytevalue() == right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.bytevalue() == right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.bytevalue() == right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.bytevalue() == right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.bytevalue() == right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.bytevalue() == right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.bytevalue() == right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.shortvalue() == right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.shortvalue() == right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.shortvalue() == right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.shortvalue() == right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.shortvalue() == right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.shortvalue() == right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.shortvalue() == right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.intvalue() == right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.intvalue() == right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.intvalue() == right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.intvalue() == right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.intvalue() == right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.intvalue() == right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.intvalue() == right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.longvalue() == right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.longvalue() == right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.longvalue() == right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.longvalue() == right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.longvalue() == right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.longvalue() == right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.longvalue() == right.longvalue());
}
break;
case t_javalangstring :
if (rightid == t_javalangstring) {
//string are interned in th compiler==>thus if two string constant
//get to be compared, it is an equal on the vale which is done
return booleanconstant.fromvalue(((stringconstant)left).hassamevalue(right));
}
break;
case t_null :
if (rightid == t_javalangstring) {
return booleanconstant.fromvalue(false);
} else {
if (rightid == t_null) {
return booleanconstant.fromvalue(true);
}
}
}
return booleanconstant.fromvalue(false);
}

public static final constant computeconstantoperationgreater(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_char :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.charvalue() > right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.charvalue() > right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.charvalue() > right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.charvalue() > right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.charvalue() > right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.charvalue() > right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.charvalue() > right.longvalue());
}
break;
case t_float :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.floatvalue() > right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.floatvalue() > right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.floatvalue() > right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.floatvalue() > right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.floatvalue() > right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.floatvalue() > right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.floatvalue() > right.longvalue());
}
break;
case t_double :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.doublevalue() > right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.doublevalue() > right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.doublevalue() > right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.doublevalue() > right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.doublevalue() > right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.doublevalue() > right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.doublevalue() > right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.bytevalue() > right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.bytevalue() > right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.bytevalue() > right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.bytevalue() > right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.bytevalue() > right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.bytevalue() > right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.bytevalue() > right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.shortvalue() > right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.shortvalue() > right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.shortvalue() > right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.shortvalue() > right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.shortvalue() > right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.shortvalue() > right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.shortvalue() > right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.intvalue() > right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.intvalue() > right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.intvalue() > right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.intvalue() > right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.intvalue() > right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.intvalue() > right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.intvalue() > right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.longvalue() > right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.longvalue() > right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.longvalue() > right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.longvalue() > right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.longvalue() > right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.longvalue() > right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.longvalue() > right.longvalue());
}

}
return notaconstant;
}

public static final constant computeconstantoperationgreater_equal(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_char :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.charvalue() >= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.charvalue() >= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.charvalue() >= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.charvalue() >= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.charvalue() >= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.charvalue() >= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.charvalue() >= right.longvalue());
}
break;
case t_float :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.floatvalue() >= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.floatvalue() >= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.floatvalue() >= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.floatvalue() >= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.floatvalue() >= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.floatvalue() >= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.floatvalue() >= right.longvalue());
}
break;
case t_double :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.doublevalue() >= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.doublevalue() >= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.doublevalue() >= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.doublevalue() >= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.doublevalue() >= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.doublevalue() >= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.doublevalue() >= right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.bytevalue() >= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.bytevalue() >= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.bytevalue() >= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.bytevalue() >= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.bytevalue() >= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.bytevalue() >= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.bytevalue() >= right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.shortvalue() >= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.shortvalue() >= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.shortvalue() >= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.shortvalue() >= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.shortvalue() >= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.shortvalue() >= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.shortvalue() >= right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.intvalue() >= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.intvalue() >= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.intvalue() >= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.intvalue() >= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.intvalue() >= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.intvalue() >= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.intvalue() >= right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.longvalue() >= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.longvalue() >= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.longvalue() >= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.longvalue() >= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.longvalue() >= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.longvalue() >= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.longvalue() >= right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationleft_shift(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_char :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.charvalue() << right.charvalue());
case t_byte:	return intconstant.fromvalue(left.charvalue() << right.bytevalue());
case t_short:	return intconstant.fromvalue(left.charvalue() << right.shortvalue());
case t_int:		return intconstant.fromvalue(left.charvalue() << right.intvalue());
case t_long:	return intconstant.fromvalue(left.charvalue() << right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.bytevalue() << right.charvalue());
case t_byte:	return intconstant.fromvalue(left.bytevalue() << right.bytevalue());
case t_short:	return intconstant.fromvalue(left.bytevalue() << right.shortvalue());
case t_int:		return intconstant.fromvalue(left.bytevalue() << right.intvalue());
case t_long:	return intconstant.fromvalue(left.bytevalue() << right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.shortvalue() << right.charvalue());
case t_byte:	return intconstant.fromvalue(left.shortvalue() << right.bytevalue());
case t_short:	return intconstant.fromvalue(left.shortvalue() << right.shortvalue());
case t_int:		return intconstant.fromvalue(left.shortvalue() << right.intvalue());
case t_long:	return intconstant.fromvalue(left.shortvalue() << right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.intvalue() << right.charvalue());
case t_byte:	return intconstant.fromvalue(left.intvalue() << right.bytevalue());
case t_short:	return intconstant.fromvalue(left.intvalue() << right.shortvalue());
case t_int:		return intconstant.fromvalue(left.intvalue() << right.intvalue());
case t_long:	return intconstant.fromvalue(left.intvalue() << right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return longconstant.fromvalue(left.longvalue() << right.charvalue());
case t_byte:	return longconstant.fromvalue(left.longvalue() << right.bytevalue());
case t_short:	return longconstant.fromvalue(left.longvalue() << right.shortvalue());
case t_int:		return longconstant.fromvalue(left.longvalue() << right.intvalue());
case t_long:	return longconstant.fromvalue(left.longvalue() << right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationless(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_char :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.charvalue() < right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.charvalue() < right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.charvalue() < right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.charvalue() < right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.charvalue() < right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.charvalue() < right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.charvalue() < right.longvalue());
}
break;
case t_float :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.floatvalue() < right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.floatvalue() < right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.floatvalue() < right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.floatvalue() < right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.floatvalue() < right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.floatvalue() < right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.floatvalue() < right.longvalue());
}
break;
case t_double :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.doublevalue() < right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.doublevalue() < right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.doublevalue() < right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.doublevalue() < right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.doublevalue() < right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.doublevalue() < right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.doublevalue() < right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.bytevalue() < right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.bytevalue() < right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.bytevalue() < right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.bytevalue() < right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.bytevalue() < right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.bytevalue() < right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.bytevalue() < right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.shortvalue() < right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.shortvalue() < right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.shortvalue() < right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.shortvalue() < right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.shortvalue() < right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.shortvalue() < right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.shortvalue() < right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.intvalue() < right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.intvalue() < right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.intvalue() < right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.intvalue() < right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.intvalue() < right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.intvalue() < right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.intvalue() < right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.longvalue() < right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.longvalue() < right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.longvalue() < right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.longvalue() < right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.longvalue() < right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.longvalue() < right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.longvalue() < right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationless_equal(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_char :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.charvalue() <= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.charvalue() <= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.charvalue() <= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.charvalue() <= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.charvalue() <= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.charvalue() <= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.charvalue() <= right.longvalue());
}
break;
case t_float :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.floatvalue() <= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.floatvalue() <= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.floatvalue() <= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.floatvalue() <= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.floatvalue() <= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.floatvalue() <= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.floatvalue() <= right.longvalue());
}
break;
case t_double :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.doublevalue() <= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.doublevalue() <= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.doublevalue() <= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.doublevalue() <= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.doublevalue() <= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.doublevalue() <= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.doublevalue() <= right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.bytevalue() <= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.bytevalue() <= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.bytevalue() <= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.bytevalue() <= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.bytevalue() <= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.bytevalue() <= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.bytevalue() <= right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.shortvalue() <= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.shortvalue() <= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.shortvalue() <= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.shortvalue() <= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.shortvalue() <= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.shortvalue() <= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.shortvalue() <= right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.intvalue() <= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.intvalue() <= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.intvalue() <= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.intvalue() <= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.intvalue() <= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.intvalue() <= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.intvalue() <= right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return booleanconstant.fromvalue(left.longvalue() <= right.charvalue());
case t_float:	return booleanconstant.fromvalue(left.longvalue() <= right.floatvalue());
case t_double:	return booleanconstant.fromvalue(left.longvalue() <= right.doublevalue());
case t_byte:	return booleanconstant.fromvalue(left.longvalue() <= right.bytevalue());
case t_short:	return booleanconstant.fromvalue(left.longvalue() <= right.shortvalue());
case t_int:		return booleanconstant.fromvalue(left.longvalue() <= right.intvalue());
case t_long:	return booleanconstant.fromvalue(left.longvalue() <= right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationminus(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_char :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.charvalue() - right.charvalue());
case t_float:	return floatconstant.fromvalue(left.charvalue() - right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.charvalue() - right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.charvalue() - right.bytevalue());
case t_short:	return intconstant.fromvalue(left.charvalue() - right.shortvalue());
case t_int:		return intconstant.fromvalue(left.charvalue() - right.intvalue());
case t_long:	return longconstant.fromvalue(left.charvalue() - right.longvalue());
}
break;
case t_float :
switch (rightid){
case t_char :	return floatconstant.fromvalue(left.floatvalue() - right.charvalue());
case t_float:	return floatconstant.fromvalue(left.floatvalue() - right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.floatvalue() - right.doublevalue());
case t_byte:	return floatconstant.fromvalue(left.floatvalue() - right.bytevalue());
case t_short:	return floatconstant.fromvalue(left.floatvalue() - right.shortvalue());
case t_int:		return floatconstant.fromvalue(left.floatvalue() - right.intvalue());
case t_long:	return floatconstant.fromvalue(left.floatvalue() - right.longvalue());
}
break;
case t_double :
switch (rightid){
case t_char :	return doubleconstant.fromvalue(left.doublevalue() - right.charvalue());
case t_float:	return doubleconstant.fromvalue(left.doublevalue() - right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.doublevalue() - right.doublevalue());
case t_byte:	return doubleconstant.fromvalue(left.doublevalue() - right.bytevalue());
case t_short:	return doubleconstant.fromvalue(left.doublevalue() - right.shortvalue());
case t_int:		return doubleconstant.fromvalue(left.doublevalue() - right.intvalue());
case t_long:	return doubleconstant.fromvalue(left.doublevalue() - right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.bytevalue() - right.charvalue());
case t_float:	return floatconstant.fromvalue(left.bytevalue() - right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.bytevalue() - right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.bytevalue() - right.bytevalue());
case t_short:	return intconstant.fromvalue(left.bytevalue() - right.shortvalue());
case t_int:		return intconstant.fromvalue(left.bytevalue() - right.intvalue());
case t_long:	return longconstant.fromvalue(left.bytevalue() - right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.shortvalue() - right.charvalue());
case t_float:	return floatconstant.fromvalue(left.shortvalue() - right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.shortvalue() - right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.shortvalue() - right.bytevalue());
case t_short:	return intconstant.fromvalue(left.shortvalue() - right.shortvalue());
case t_int:		return intconstant.fromvalue(left.shortvalue() - right.intvalue());
case t_long:	return longconstant.fromvalue(left.shortvalue() - right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.intvalue() - right.charvalue());
case t_float:	return floatconstant.fromvalue(left.intvalue() - right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.intvalue() - right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.intvalue() - right.bytevalue());
case t_short:	return intconstant.fromvalue(left.intvalue() - right.shortvalue());
case t_int:		return intconstant.fromvalue(left.intvalue() - right.intvalue());
case t_long:	return longconstant.fromvalue(left.intvalue() - right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return longconstant.fromvalue(left.longvalue() - right.charvalue());
case t_float:	return floatconstant.fromvalue(left.longvalue() - right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.longvalue() - right.doublevalue());
case t_byte:	return longconstant.fromvalue(left.longvalue() - right.bytevalue());
case t_short:	return longconstant.fromvalue(left.longvalue() - right.shortvalue());
case t_int:		return longconstant.fromvalue(left.longvalue() - right.intvalue());
case t_long:	return longconstant.fromvalue(left.longvalue() - right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationmultiply(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_char :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.charvalue() * right.charvalue());
case t_float:	return floatconstant.fromvalue(left.charvalue() * right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.charvalue() * right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.charvalue() * right.bytevalue());
case t_short:	return intconstant.fromvalue(left.charvalue() * right.shortvalue());
case t_int:		return intconstant.fromvalue(left.charvalue() * right.intvalue());
case t_long:	return longconstant.fromvalue(left.charvalue() * right.longvalue());
}
break;
case t_float :
switch (rightid){
case t_char :	return floatconstant.fromvalue(left.floatvalue() * right.charvalue());
case t_float:	return floatconstant.fromvalue(left.floatvalue() * right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.floatvalue() * right.doublevalue());
case t_byte:	return floatconstant.fromvalue(left.floatvalue() * right.bytevalue());
case t_short:	return floatconstant.fromvalue(left.floatvalue() * right.shortvalue());
case t_int:		return floatconstant.fromvalue(left.floatvalue() * right.intvalue());
case t_long:	return floatconstant.fromvalue(left.floatvalue() * right.longvalue());
}
break;
case t_double :
switch (rightid){
case t_char :	return doubleconstant.fromvalue(left.doublevalue() * right.charvalue());
case t_float:	return doubleconstant.fromvalue(left.doublevalue() * right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.doublevalue() * right.doublevalue());
case t_byte:	return doubleconstant.fromvalue(left.doublevalue() * right.bytevalue());
case t_short:	return doubleconstant.fromvalue(left.doublevalue() * right.shortvalue());
case t_int:		return doubleconstant.fromvalue(left.doublevalue() * right.intvalue());
case t_long:	return doubleconstant.fromvalue(left.doublevalue() * right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.bytevalue() * right.charvalue());
case t_float:	return floatconstant.fromvalue(left.bytevalue() * right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.bytevalue() * right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.bytevalue() * right.bytevalue());
case t_short:	return intconstant.fromvalue(left.bytevalue() * right.shortvalue());
case t_int:		return intconstant.fromvalue(left.bytevalue() * right.intvalue());
case t_long:	return longconstant.fromvalue(left.bytevalue() * right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.shortvalue() * right.charvalue());
case t_float:	return floatconstant.fromvalue(left.shortvalue() * right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.shortvalue() * right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.shortvalue() * right.bytevalue());
case t_short:	return intconstant.fromvalue(left.shortvalue() * right.shortvalue());
case t_int:		return intconstant.fromvalue(left.shortvalue() * right.intvalue());
case t_long:	return longconstant.fromvalue(left.shortvalue() * right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.intvalue() * right.charvalue());
case t_float:	return floatconstant.fromvalue(left.intvalue() * right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.intvalue() * right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.intvalue() * right.bytevalue());
case t_short:	return intconstant.fromvalue(left.intvalue() * right.shortvalue());
case t_int:		return intconstant.fromvalue(left.intvalue() * right.intvalue());
case t_long:	return longconstant.fromvalue(left.intvalue() * right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return longconstant.fromvalue(left.longvalue() * right.charvalue());
case t_float:	return floatconstant.fromvalue(left.longvalue() * right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.longvalue() * right.doublevalue());
case t_byte:	return longconstant.fromvalue(left.longvalue() * right.bytevalue());
case t_short:	return longconstant.fromvalue(left.longvalue() * right.shortvalue());
case t_int:		return longconstant.fromvalue(left.longvalue() * right.intvalue());
case t_long:	return longconstant.fromvalue(left.longvalue() * right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationor(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_boolean :		return booleanconstant.fromvalue(left.booleanvalue() | right.booleanvalue());
case t_char :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.charvalue() | right.charvalue());
case t_byte:	return intconstant.fromvalue(left.charvalue() | right.bytevalue());
case t_short:	return intconstant.fromvalue(left.charvalue() | right.shortvalue());
case t_int:		return intconstant.fromvalue(left.charvalue() | right.intvalue());
case t_long:	return longconstant.fromvalue(left.charvalue() | right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.bytevalue() | right.charvalue());
case t_byte:	return intconstant.fromvalue(left.bytevalue() | right.bytevalue());
case t_short:	return intconstant.fromvalue(left.bytevalue() | right.shortvalue());
case t_int:		return intconstant.fromvalue(left.bytevalue() | right.intvalue());
case t_long:	return longconstant.fromvalue(left.bytevalue() | right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.shortvalue() | right.charvalue());
case t_byte:	return intconstant.fromvalue(left.shortvalue() | right.bytevalue());
case t_short:	return intconstant.fromvalue(left.shortvalue() | right.shortvalue());
case t_int:		return intconstant.fromvalue(left.shortvalue() | right.intvalue());
case t_long:	return longconstant.fromvalue(left.shortvalue() | right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.intvalue() | right.charvalue());
case t_byte:	return intconstant.fromvalue(left.intvalue() | right.bytevalue());
case t_short:	return intconstant.fromvalue(left.intvalue() | right.shortvalue());
case t_int:		return intconstant.fromvalue(left.intvalue() | right.intvalue());
case t_long:	return longconstant.fromvalue(left.intvalue() | right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return longconstant.fromvalue(left.longvalue() | right.charvalue());
case t_byte:	return longconstant.fromvalue(left.longvalue() | right.bytevalue());
case t_short:	return longconstant.fromvalue(left.longvalue() | right.shortvalue());
case t_int:		return longconstant.fromvalue(left.longvalue() | right.intvalue());
case t_long:	return longconstant.fromvalue(left.longvalue() | right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationor_or(constant left, int leftid, constant right, int rightid) {
return booleanconstant.fromvalue(left.booleanvalue() || right.booleanvalue());
}

public static final constant computeconstantoperationplus(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_javalangobject :
if (rightid == t_javalangstring) {
return stringconstant.fromvalue(left.stringvalue() + right.stringvalue());
}
break;
case t_boolean :
if (rightid == t_javalangstring) {
return stringconstant.fromvalue(left.stringvalue() + right.stringvalue());
}
break;
case t_char :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.charvalue() + right.charvalue());
case t_float:	return floatconstant.fromvalue(left.charvalue() + right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.charvalue() + right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.charvalue() + right.bytevalue());
case t_short:	return intconstant.fromvalue(left.charvalue() + right.shortvalue());
case t_int:		return intconstant.fromvalue(left.charvalue() + right.intvalue());
case t_long:	return longconstant.fromvalue(left.charvalue() + right.longvalue());
case t_javalangstring:	return stringconstant.fromvalue(left.stringvalue() + right.stringvalue());
}
break;
case t_float :
switch (rightid){
case t_char :	return floatconstant.fromvalue(left.floatvalue() + right.charvalue());
case t_float:	return floatconstant.fromvalue(left.floatvalue() + right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.floatvalue() + right.doublevalue());
case t_byte:	return floatconstant.fromvalue(left.floatvalue() + right.bytevalue());
case t_short:	return floatconstant.fromvalue(left.floatvalue() + right.shortvalue());
case t_int:		return floatconstant.fromvalue(left.floatvalue() + right.intvalue());
case t_long:	return floatconstant.fromvalue(left.floatvalue() + right.longvalue());
case t_javalangstring:	return stringconstant.fromvalue(left.stringvalue() + right.stringvalue());
}
break;
case t_double :
switch (rightid){
case t_char :	return doubleconstant.fromvalue(left.doublevalue() + right.charvalue());
case t_float:	return doubleconstant.fromvalue(left.doublevalue() + right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.doublevalue() + right.doublevalue());
case t_byte:	return doubleconstant.fromvalue(left.doublevalue() + right.bytevalue());
case t_short:	return doubleconstant.fromvalue(left.doublevalue() + right.shortvalue());
case t_int:		return doubleconstant.fromvalue(left.doublevalue() + right.intvalue());
case t_long:	return doubleconstant.fromvalue(left.doublevalue() + right.longvalue());
case t_javalangstring:	return stringconstant.fromvalue(left.stringvalue() + right.stringvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.bytevalue() + right.charvalue());
case t_float:	return floatconstant.fromvalue(left.bytevalue() + right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.bytevalue() + right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.bytevalue() + right.bytevalue());
case t_short:	return intconstant.fromvalue(left.bytevalue() + right.shortvalue());
case t_int:		return intconstant.fromvalue(left.bytevalue() + right.intvalue());
case t_long:	return longconstant.fromvalue(left.bytevalue() + right.longvalue());
case t_javalangstring:	return stringconstant.fromvalue(left.stringvalue() + right.stringvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.shortvalue() + right.charvalue());
case t_float:	return floatconstant.fromvalue(left.shortvalue() + right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.shortvalue() + right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.shortvalue() + right.bytevalue());
case t_short:	return intconstant.fromvalue(left.shortvalue() + right.shortvalue());
case t_int:		return intconstant.fromvalue(left.shortvalue() + right.intvalue());
case t_long:	return longconstant.fromvalue(left.shortvalue() + right.longvalue());
case t_javalangstring:	return stringconstant.fromvalue(left.stringvalue() + right.stringvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.intvalue() + right.charvalue());
case t_float:	return floatconstant.fromvalue(left.intvalue() + right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.intvalue() + right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.intvalue() + right.bytevalue());
case t_short:	return intconstant.fromvalue(left.intvalue() + right.shortvalue());
case t_int:		return intconstant.fromvalue(left.intvalue() + right.intvalue());
case t_long:	return longconstant.fromvalue(left.intvalue() + right.longvalue());
case t_javalangstring:	return stringconstant.fromvalue(left.stringvalue() + right.stringvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return longconstant.fromvalue(left.longvalue() + right.charvalue());
case t_float:	return floatconstant.fromvalue(left.longvalue() + right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.longvalue() + right.doublevalue());
case t_byte:	return longconstant.fromvalue(left.longvalue() + right.bytevalue());
case t_short:	return longconstant.fromvalue(left.longvalue() + right.shortvalue());
case t_int:		return longconstant.fromvalue(left.longvalue() + right.intvalue());
case t_long:	return longconstant.fromvalue(left.longvalue() + right.longvalue());
case t_javalangstring:	return stringconstant.fromvalue(left.stringvalue() + right.stringvalue());
}
break;
case t_javalangstring :
switch (rightid){
case t_char :	return stringconstant.fromvalue(left.stringvalue() + string.valueof(right.charvalue()));
case t_float:	return stringconstant.fromvalue(left.stringvalue() + string.valueof(right.floatvalue()));
case t_double:	return stringconstant.fromvalue(left.stringvalue() + string.valueof(right.doublevalue()));
case t_byte:	return stringconstant.fromvalue(left.stringvalue() + string.valueof(right.bytevalue()));
case t_short:	return stringconstant.fromvalue(left.stringvalue() + string.valueof(right.shortvalue()));
case t_int:		return stringconstant.fromvalue(left.stringvalue() + string.valueof(right.intvalue()));
case t_long:	return stringconstant.fromvalue(left.stringvalue() + string.valueof(right.longvalue()));
case t_javalangstring:	return stringconstant.fromvalue(left.stringvalue() + right.stringvalue());
case t_boolean:	return stringconstant.fromvalue(left.stringvalue() + right.booleanvalue());
}
break;
//			case t_null :
//				switch (rightid){
//					case t_char :	return constant.fromvalue(left.stringvalue() + string.valueof(right.charvalue()));
//					case t_float:	return constant.fromvalue(left.stringvalue() + string.valueof(right.floatvalue()));
//					case t_double:	return constant.fromvalue(left.stringvalue() + string.valueof(right.doublevalue()));
//					case t_byte:	return constant.fromvalue(left.stringvalue() + string.valueof(right.bytevalue()));
//					case t_short:	return constant.fromvalue(left.stringvalue() + string.valueof(right.shortvalue()));
//					case t_int:		return constant.fromvalue(left.stringvalue() + string.valueof(right.intvalue()));
//					case t_long:	return constant.fromvalue(left.stringvalue() + string.valueof(right.longvalue()));
//					case t_javalangstring:	return constant.fromvalue(left.stringvalue() + right.stringvalue());
//					case t_boolean:	return constant.fromvalue(left.stringvalue() + right.booleanvalue());
//				}
}
return notaconstant;
}

public static final constant computeconstantoperationremainder(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_char :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.charvalue() % right.charvalue());
case t_float:	return floatconstant.fromvalue(left.charvalue() % right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.charvalue() % right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.charvalue() % right.bytevalue());
case t_short:	return intconstant.fromvalue(left.charvalue() % right.shortvalue());
case t_int:		return intconstant.fromvalue(left.charvalue() % right.intvalue());
case t_long:	return longconstant.fromvalue(left.charvalue() % right.longvalue());
}
break;
case t_float :
switch (rightid){
case t_char :	return floatconstant.fromvalue(left.floatvalue() % right.charvalue());
case t_float:	return floatconstant.fromvalue(left.floatvalue() % right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.floatvalue() % right.doublevalue());
case t_byte:	return floatconstant.fromvalue(left.floatvalue() % right.bytevalue());
case t_short:	return floatconstant.fromvalue(left.floatvalue() % right.shortvalue());
case t_int:		return floatconstant.fromvalue(left.floatvalue() % right.intvalue());
case t_long:	return floatconstant.fromvalue(left.floatvalue() % right.longvalue());
}
break;
case t_double :
switch (rightid){
case t_char :	return doubleconstant.fromvalue(left.doublevalue() % right.charvalue());
case t_float:	return doubleconstant.fromvalue(left.doublevalue() % right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.doublevalue() % right.doublevalue());
case t_byte:	return doubleconstant.fromvalue(left.doublevalue() % right.bytevalue());
case t_short:	return doubleconstant.fromvalue(left.doublevalue() % right.shortvalue());
case t_int:		return doubleconstant.fromvalue(left.doublevalue() % right.intvalue());
case t_long:	return doubleconstant.fromvalue(left.doublevalue() % right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.bytevalue() % right.charvalue());
case t_float:	return floatconstant.fromvalue(left.bytevalue() % right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.bytevalue() % right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.bytevalue() % right.bytevalue());
case t_short:	return intconstant.fromvalue(left.bytevalue() % right.shortvalue());
case t_int:		return intconstant.fromvalue(left.bytevalue() % right.intvalue());
case t_long:	return longconstant.fromvalue(left.bytevalue() % right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.shortvalue() % right.charvalue());
case t_float:	return floatconstant.fromvalue(left.shortvalue() % right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.shortvalue() % right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.shortvalue() % right.bytevalue());
case t_short:	return intconstant.fromvalue(left.shortvalue() % right.shortvalue());
case t_int:		return intconstant.fromvalue(left.shortvalue() % right.intvalue());
case t_long:	return longconstant.fromvalue(left.shortvalue() % right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.intvalue() % right.charvalue());
case t_float:	return floatconstant.fromvalue(left.intvalue() % right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.intvalue() % right.doublevalue());
case t_byte:	return intconstant.fromvalue(left.intvalue() % right.bytevalue());
case t_short:	return intconstant.fromvalue(left.intvalue() % right.shortvalue());
case t_int:		return intconstant.fromvalue(left.intvalue() % right.intvalue());
case t_long:	return longconstant.fromvalue(left.intvalue() % right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return longconstant.fromvalue(left.longvalue() % right.charvalue());
case t_float:	return floatconstant.fromvalue(left.longvalue() % right.floatvalue());
case t_double:	return doubleconstant.fromvalue(left.longvalue() % right.doublevalue());
case t_byte:	return longconstant.fromvalue(left.longvalue() % right.bytevalue());
case t_short:	return longconstant.fromvalue(left.longvalue() % right.shortvalue());
case t_int:		return longconstant.fromvalue(left.longvalue() % right.intvalue());
case t_long:	return longconstant.fromvalue(left.longvalue() % right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationright_shift(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_char :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.charvalue() >> right.charvalue());
case t_byte:	return intconstant.fromvalue(left.charvalue() >> right.bytevalue());
case t_short:	return intconstant.fromvalue(left.charvalue() >> right.shortvalue());
case t_int:		return intconstant.fromvalue(left.charvalue() >> right.intvalue());
case t_long:	return intconstant.fromvalue(left.charvalue() >> right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.bytevalue() >> right.charvalue());
case t_byte:	return intconstant.fromvalue(left.bytevalue() >> right.bytevalue());
case t_short:	return intconstant.fromvalue(left.bytevalue() >> right.shortvalue());
case t_int:		return intconstant.fromvalue(left.bytevalue() >> right.intvalue());
case t_long:	return intconstant.fromvalue(left.bytevalue() >> right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.shortvalue() >> right.charvalue());
case t_byte:	return intconstant.fromvalue(left.shortvalue() >> right.bytevalue());
case t_short:	return intconstant.fromvalue(left.shortvalue() >> right.shortvalue());
case t_int:		return intconstant.fromvalue(left.shortvalue() >> right.intvalue());
case t_long:	return intconstant.fromvalue(left.shortvalue() >> right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.intvalue() >> right.charvalue());
case t_byte:	return intconstant.fromvalue(left.intvalue() >> right.bytevalue());
case t_short:	return intconstant.fromvalue(left.intvalue() >> right.shortvalue());
case t_int:		return intconstant.fromvalue(left.intvalue() >> right.intvalue());
case t_long:	return intconstant.fromvalue(left.intvalue() >> right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return longconstant.fromvalue(left.longvalue() >> right.charvalue());
case t_byte:	return longconstant.fromvalue(left.longvalue() >> right.bytevalue());
case t_short:	return longconstant.fromvalue(left.longvalue() >> right.shortvalue());
case t_int:		return longconstant.fromvalue(left.longvalue() >> right.intvalue());
case t_long:	return longconstant.fromvalue(left.longvalue() >> right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationunsigned_right_shift(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_char :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.charvalue() >>> right.charvalue());
case t_byte:	return intconstant.fromvalue(left.charvalue() >>> right.bytevalue());
case t_short:	return intconstant.fromvalue(left.charvalue() >>> right.shortvalue());
case t_int:		return intconstant.fromvalue(left.charvalue() >>> right.intvalue());
case t_long:	return intconstant.fromvalue(left.charvalue() >>> right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.bytevalue() >>> right.charvalue());
case t_byte:	return intconstant.fromvalue(left.bytevalue() >>> right.bytevalue());
case t_short:	return intconstant.fromvalue(left.bytevalue() >>> right.shortvalue());
case t_int:		return intconstant.fromvalue(left.bytevalue() >>> right.intvalue());
case t_long:	return intconstant.fromvalue(left.bytevalue() >>> right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.shortvalue() >>> right.charvalue());
case t_byte:	return intconstant.fromvalue(left.shortvalue() >>> right.bytevalue());
case t_short:	return intconstant.fromvalue(left.shortvalue() >>> right.shortvalue());
case t_int:		return intconstant.fromvalue(left.shortvalue() >>> right.intvalue());
case t_long:	return intconstant.fromvalue(left.shortvalue() >>> right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.intvalue() >>> right.charvalue());
case t_byte:	return intconstant.fromvalue(left.intvalue() >>> right.bytevalue());
case t_short:	return intconstant.fromvalue(left.intvalue() >>> right.shortvalue());
case t_int:		return intconstant.fromvalue(left.intvalue() >>> right.intvalue());
case t_long:	return intconstant.fromvalue(left.intvalue() >>> right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return longconstant.fromvalue(left.longvalue() >>> right.charvalue());
case t_byte:	return longconstant.fromvalue(left.longvalue() >>> right.bytevalue());
case t_short:	return longconstant.fromvalue(left.longvalue() >>> right.shortvalue());
case t_int:		return longconstant.fromvalue(left.longvalue() >>> right.intvalue());
case t_long:	return longconstant.fromvalue(left.longvalue() >>> right.longvalue());
}
}
return notaconstant;
}

public static final constant computeconstantoperationxor(constant left, int leftid, constant right, int rightid) {
switch (leftid){
case t_boolean :		return booleanconstant.fromvalue(left.booleanvalue() ^ right.booleanvalue());
case t_char :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.charvalue() ^ right.charvalue());
case t_byte:	return intconstant.fromvalue(left.charvalue() ^ right.bytevalue());
case t_short:	return intconstant.fromvalue(left.charvalue() ^ right.shortvalue());
case t_int:		return intconstant.fromvalue(left.charvalue() ^ right.intvalue());
case t_long:	return longconstant.fromvalue(left.charvalue() ^ right.longvalue());
}
break;
case t_byte :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.bytevalue() ^ right.charvalue());
case t_byte:	return intconstant.fromvalue(left.bytevalue() ^ right.bytevalue());
case t_short:	return intconstant.fromvalue(left.bytevalue() ^ right.shortvalue());
case t_int:		return intconstant.fromvalue(left.bytevalue() ^ right.intvalue());
case t_long:	return longconstant.fromvalue(left.bytevalue() ^ right.longvalue());
}
break;
case t_short :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.shortvalue() ^ right.charvalue());
case t_byte:	return intconstant.fromvalue(left.shortvalue() ^ right.bytevalue());
case t_short:	return intconstant.fromvalue(left.shortvalue() ^ right.shortvalue());
case t_int:		return intconstant.fromvalue(left.shortvalue() ^ right.intvalue());
case t_long:	return longconstant.fromvalue(left.shortvalue() ^ right.longvalue());
}
break;
case t_int :
switch (rightid){
case t_char :	return intconstant.fromvalue(left.intvalue() ^ right.charvalue());
case t_byte:	return intconstant.fromvalue(left.intvalue() ^ right.bytevalue());
case t_short:	return intconstant.fromvalue(left.intvalue() ^ right.shortvalue());
case t_int:		return intconstant.fromvalue(left.intvalue() ^ right.intvalue());
case t_long:	return longconstant.fromvalue(left.intvalue() ^ right.longvalue());
}
break;
case t_long :
switch (rightid){
case t_char :	return longconstant.fromvalue(left.longvalue() ^ right.charvalue());
case t_byte:	return longconstant.fromvalue(left.longvalue() ^ right.bytevalue());
case t_short:	return longconstant.fromvalue(left.longvalue() ^ right.shortvalue());
case t_int:		return longconstant.fromvalue(left.longvalue() ^ right.intvalue());
case t_long:	return longconstant.fromvalue(left.longvalue() ^ right.longvalue());
}
}
return notaconstant;
}

public double doublevalue() {
throw new shouldnotimplement(messages.bind(messages.constant_cannotcastedinto, new string[] { typename(), "double" })); //$non-nls-1$
}

public float floatvalue() {
throw new shouldnotimplement(messages.bind(messages.constant_cannotcastedinto, new string[] { typename(), "float" })); //$non-nls-1$
}

/**
* returns true if both constants have the same type and the same actual value
* @@param otherconstant
*/
public boolean hassamevalue(constant otherconstant) {
if (this == otherconstant)
return true;
int typeid;
if ((typeid = typeid()) != otherconstant.typeid())
return false;
switch (typeid) {
case typeids.t_boolean:
return booleanvalue() == otherconstant.booleanvalue();
case typeids.t_byte:
return bytevalue() == otherconstant.bytevalue();
case typeids.t_char:
return charvalue() == otherconstant.charvalue();
case typeids.t_double:
return doublevalue() == otherconstant.doublevalue();
case typeids.t_float:
return floatvalue() == otherconstant.floatvalue();
case typeids.t_int:
return intvalue() == otherconstant.intvalue();
case typeids.t_short:
return shortvalue() == otherconstant.shortvalue();
case typeids.t_long:
return longvalue() == otherconstant.longvalue();
case typeids.t_javalangstring:
string value = stringvalue();
return value == null
? otherconstant.stringvalue() == null
: value.equals(otherconstant.stringvalue());
}
return false;
}

public int intvalue() {
throw new shouldnotimplement(messages.bind(messages.constant_cannotcastedinto, new string[] { typename(), "int" })); //$non-nls-1$
}

public long longvalue() {
throw new shouldnotimplement(messages.bind(messages.constant_cannotcastedinto, new string[] { typename(), "long" })); //$non-nls-1$
}

public short shortvalue() {
throw new shouldnotimplement(messages.bind(messages.constant_cannotconvertedto, new string[] { typename(), "short" })); //$non-nls-1$
}

public string stringvalue() {
throw new shouldnotimplement(messages.bind(messages.constant_cannotconvertedto, new string[] { typename(), "string" })); //$non-nls-1$
}

public string tostring(){
if (this == notaconstant) return "(constant) notaconstant"; //$non-nls-1$
return super.tostring(); }

public abstract int typeid();

public string typename() {
switch (typeid()) {
case t_int : return "int"; //$non-nls-1$
case t_byte : return "byte"; //$non-nls-1$
case t_short : return "short"; //$non-nls-1$
case t_char : return "char"; //$non-nls-1$
case t_float : return "float"; //$non-nls-1$
case t_double : return "double"; //$non-nls-1$
case t_boolean : return "boolean"; //$non-nls-1$
case t_long : return "long";//$non-nls-1$
case t_javalangstring : return "java.lang.string"; //$non-nls-1$
case t_null : return "null";	 //$non-nls-1$
default: return "unknown"; //$non-nls-1$
}
}
}
