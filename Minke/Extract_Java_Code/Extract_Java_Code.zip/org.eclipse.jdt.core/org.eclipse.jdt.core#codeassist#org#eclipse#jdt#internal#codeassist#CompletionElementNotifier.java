/*******************************************************************************
* copyright (c) 2008, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import java.util.map;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.codeassist.complete.completiononannotationoftype;
import org.eclipse.jdt.internal.codeassist.complete.completiononargumentname;
import org.eclipse.jdt.internal.codeassist.complete.completiononfieldname;
import org.eclipse.jdt.internal.codeassist.complete.completiononfieldtype;
import org.eclipse.jdt.internal.codeassist.complete.completiononimportreference;
import org.eclipse.jdt.internal.codeassist.complete.completiononkeyword;
import org.eclipse.jdt.internal.codeassist.complete.completiononkeyword2;
import org.eclipse.jdt.internal.codeassist.complete.completiononmethodname;
import org.eclipse.jdt.internal.codeassist.complete.completiononmethodreturntype;
import org.eclipse.jdt.internal.codeassist.complete.completiononmethodtypeparameter;
import org.eclipse.jdt.internal.codeassist.complete.completiononpackagereference;
import org.eclipse.jdt.internal.compiler.sourceelementnotifier;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.argument;
import org.eclipse.jdt.internal.compiler.ast.compilationunitdeclaration;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.ast.importreference;
import org.eclipse.jdt.internal.compiler.ast.qualifiedallocationexpression;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.ast.typeparameter;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.util.hashtableofobjecttoint;

public class completionelementnotifier extends sourceelementnotifier {

private astnode assistnode;

public completionelementnotifier(
completionunitstructurerequestor requestor,
boolean reportlocaldeclarations,
astnode assistnode) {
super(requestor, reportlocaldeclarations);
this.assistnode = assistnode;
}

protected char[][][] getarguments(argument[] arguments) {
int argumentlength = arguments.length;
char[][] argumenttypes = new char[argumentlength][];
char[][] argumentnames = new char[argumentlength][];
int argumentcount = 0;
next : for (int i = 0; i < argumentlength; i++) {
argument argument = arguments[i];

if (argument instanceof completiononargumentname && argument.name.length == 0) continue next;

argumenttypes[argumentcount] = charoperation.concatwith(argument.type.getparameterizedtypename(), '.');
argumentnames[argumentcount++] = argument.name;
}

if (argumentcount < argumentlength) {
system.arraycopy(argumenttypes, 0, argumenttypes = new char[argumentcount][], 0, argumentcount);
system.arraycopy(argumentnames, 0, argumentnames = new char[argumentcount][], 0, argumentcount);
}

return new char[][][] {argumenttypes, argumentnames};
}

protected char[][] getinterfacenames(typedeclaration typedeclaration) {
char[][] interfacenames = null;
int superinterfaceslength = 0;
typereference[] superinterfaces = typedeclaration.superinterfaces;
if (superinterfaces != null) {
superinterfaceslength = superinterfaces.length;
interfacenames = new char[superinterfaceslength][];
} else {
if ((typedeclaration.bits & astnode.isanonymoustype) != 0) {
// see pr 3442
qualifiedallocationexpression alloc = typedeclaration.allocation;
if (alloc != null && alloc.type != null) {
superinterfaces = new typereference[] { alloc.type};
superinterfaceslength = 1;
interfacenames = new char[1][];
}
}
}
if (superinterfaces != null) {
int superinterfacecount = 0;
next: for (int i = 0; i < superinterfaceslength; i++) {
typereference superinterface = superinterfaces[i];

if (superinterface instanceof completiononkeyword) continue next;
if (completionunitstructurerequestor.hasemptyname(superinterface, this.assistnode)) continue next;

interfacenames[superinterfacecount++] = charoperation.concatwith(superinterface.getparameterizedtypename(), '.');
}

if (superinterfacecount == 0) return null;
if (superinterfacecount < superinterfaceslength) {
system.arraycopy(interfacenames, 0, interfacenames = new char[superinterfacecount][], 0, superinterfacecount);
}
}
return interfacenames;
}

protected char[] getsuperclassname(typedeclaration typedeclaration) {
typereference superclass = typedeclaration.superclass;

if (superclass instanceof completiononkeyword) return null;
if (completionunitstructurerequestor.hasemptyname(superclass, this.assistnode)) return null;

return superclass != null ? charoperation.concatwith(superclass.getparameterizedtypename(), '.') : null;
}

protected char[][] getthrownexceptions(abstractmethoddeclaration methoddeclaration) {
char[][] thrownexceptiontypes = null;
typereference[] thrownexceptions = methoddeclaration.thrownexceptions;
if (thrownexceptions != null) {
int thrownexceptionlength = thrownexceptions.length;
int thrownexceptioncount = 0;
thrownexceptiontypes = new char[thrownexceptionlength][];
next : for (int i = 0; i < thrownexceptionlength; i++) {
typereference thrownexception = thrownexceptions[i];

if (thrownexception instanceof completiononkeyword) continue next;
if (completionunitstructurerequestor.hasemptyname(thrownexception, this.assistnode)) continue next;

thrownexceptiontypes[thrownexceptioncount++] =
charoperation.concatwith(thrownexception.getparameterizedtypename(), '.');
}

if (thrownexceptioncount == 0) return null;
if (thrownexceptioncount < thrownexceptionlength) {
system.arraycopy(thrownexceptiontypes, 0, thrownexceptiontypes = new char[thrownexceptioncount][], 0, thrownexceptioncount);
}
}
return thrownexceptiontypes;
}

protected char[][] gettypeparameterbounds(typeparameter typeparameter) {
typereference firstbound = typeparameter.type;
typereference[] otherbounds = typeparameter.bounds;
char[][] typeparameterbounds = null;
if (firstbound != null) {
if (otherbounds != null) {
int otherboundslength = otherbounds.length;
char[][] boundnames = new char[otherboundslength+1][];
int boundcount = 0;
if (!completionunitstructurerequestor.hasemptyname(firstbound, this.assistnode)) {
boundnames[boundcount++] = charoperation.concatwith(firstbound.getparameterizedtypename(), '.');
}
for (int j = 0; j < otherboundslength; j++) {
typereference otherbound = otherbounds[j];
if (!completionunitstructurerequestor.hasemptyname(otherbound, this.assistnode)) {
boundnames[boundcount++] =
charoperation.concatwith(otherbound.getparameterizedtypename(), '.');
}
}

if (boundcount == 0) {
boundnames = charoperation.no_char_char;
} else if (boundcount < otherboundslength + 1){
system.arraycopy(boundnames, 0, boundnames = new char[boundcount][], 0, boundcount);
}
typeparameterbounds = boundnames;
} else {
if (!completionunitstructurerequestor.hasemptyname(firstbound, this.assistnode)) {
typeparameterbounds = new char[][] { charoperation.concatwith(firstbound.getparameterizedtypename(), '.')};
} else {
typeparameterbounds = charoperation.no_char_char;
}
}
} else {
typeparameterbounds = charoperation.no_char_char;
}

return typeparameterbounds;
}

protected void notifysourceelementrequestor(abstractmethoddeclaration methoddeclaration, typedeclaration declaringtype, importreference currentpackage) {
if (methoddeclaration instanceof completiononmethodreturntype) return;
if (methoddeclaration instanceof completiononmethodtypeparameter) return;
if (methoddeclaration instanceof completiononmethodname) return;
super.notifysourceelementrequestor(methoddeclaration, declaringtype, currentpackage);
}

public void notifysourceelementrequestor(compilationunitdeclaration parsedunit, int sourcestart, int sourceend, boolean reportreference, hashtableofobjecttoint sourceendsmap, map nodestocategoriesmap) {
super.notifysourceelementrequestor(parsedunit, sourcestart, sourceend, reportreference, sourceendsmap, nodestocategoriesmap);
}

protected void notifysourceelementrequestor(fielddeclaration fielddeclaration, typedeclaration declaringtype) {
if (fielddeclaration instanceof completiononfieldtype) return;
if (fielddeclaration instanceof completiononfieldname) return;
super.notifysourceelementrequestor(fielddeclaration, declaringtype);
}

protected void notifysourceelementrequestor(importreference importreference, boolean ispackage) {
if (importreference instanceof completiononkeyword2) return;
if (importreference instanceof completiononimportreference ||
importreference instanceof completiononpackagereference) {
if (importreference.tokens[importreference.tokens.length - 1].length == 0) return;
}

super.notifysourceelementrequestor(importreference, ispackage);
}

protected void notifysourceelementrequestor(typedeclaration typedeclaration, boolean notifytypepresence, typedeclaration declaringtype, importreference currentpackage) {
if (typedeclaration instanceof completiononannotationoftype) return;
super.notifysourceelementrequestor(typedeclaration, notifytypepresence, declaringtype, currentpackage);
}
}
