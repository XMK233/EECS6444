/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class continuestatement extends branchstatement {

public continuestatement(char[] label, int sourcestart, int sourceend) {
super(label, sourcestart, sourceend);
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {

// here requires to generate a sequence of finally blocks invocations depending corresponding
// to each of the traversed try statements, so that execution will terminate properly.

// lookup the label, this should answer the returncontext
flowcontext targetcontext = (this.label == null)
? flowcontext.gettargetcontextfordefaultcontinue()
: flowcontext.gettargetcontextforcontinuelabel(this.label);

if (targetcontext == null) {
if (this.label == null) {
currentscope.problemreporter().invalidcontinue(this);
} else {
currentscope.problemreporter().undefinedlabel(this);
}
return flowinfo; // pretend it did not continue since no actual target
}

if (targetcontext == flowcontext.notcontinuablecontext) {
currentscope.problemreporter().invalidcontinue(this);
return flowinfo; // pretend it did not continue since no actual target
}
this.initstateindex =
currentscope.methodscope().recordinitializationstates(flowinfo);

this.targetlabel = targetcontext.continuelabel();
flowcontext traversedcontext = flowcontext;
int subcount = 0;
this.subroutines = new subroutinestatement[5];

do {
subroutinestatement sub;
if ((sub = traversedcontext.subroutine()) != null) {
if (subcount == this.subroutines.length) {
system.arraycopy(this.subroutines, 0, this.subroutines = new subroutinestatement[subcount*2], 0, subcount); // grow
}
this.subroutines[subcount++] = sub;
if (sub.issubroutineescaping()) {
break;
}
}
traversedcontext.recordreturnfrom(flowinfo.unconditionalinits());

if (traversedcontext instanceof insidesubroutineflowcontext) {
astnode node = traversedcontext.associatednode;
if (node instanceof trystatement) {
trystatement trystatement = (trystatement) node;
flowinfo.addinitializationsfrom(trystatement.subroutineinits); // collect inits
}
} else if (traversedcontext == targetcontext) {
// only record continue info once accumulated through subroutines, and only against target context
targetcontext.recordcontinuefrom(flowcontext, flowinfo);
break;
}
} while ((traversedcontext = traversedcontext.parent) != null);

// resize subroutines
if (subcount != this.subroutines.length) {
system.arraycopy(this.subroutines, 0, this.subroutines = new subroutinestatement[subcount], 0, subcount);
}
return flowinfo.dead_end;
}

public stringbuffer printstatement(int tab, stringbuffer output) {
printindent(tab, output).append("continue "); //$non-nls-1$
if (this.label != null) output.append(this.label);
return output.append(';');
}

public void traverse(astvisitor visitor, 	blockscope blockscope) {
visitor.visit(this, blockscope);
visitor.endvisit(this, blockscope);
}
}
