/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;


public class annotationmessagesend extends messagesend {

public int tagsourcestart, tagsourceend;

public annotationmessagesend(char[] name, long pos) {
this.selector = name;
this.namesourceposition = pos;
this.sourcestart = (int) (namesourceposition >>> 32);
this.sourceend = (int) namesourceposition;
this.bits |= insideannotation;
}
public annotationmessagesend(char[] name, long pos, annotationargumentexpression[] arguments) {
this(name, pos);
this.arguments = arguments;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#issuperaccess()
*/
public boolean issuperaccess() {
return false;
}

public stringbuffer printexpression(int indent, stringbuffer output){

if (receiver != null) {
receiver.printexpression(0, output);
}
output.append('#').append(selector).append('(');
if (arguments != null) {
for (int i = 0; i < arguments.length ; i ++) {
if (i > 0) output.append(", "); //$non-nls-1$
arguments[i].printexpression(0, output);
}
}
return output.append(')');
}

public typebinding resolvetype(blockscope scope) {
// answer the signature return type
// base type promotion

constant = notaconstant;
if (this.receiver instanceof castexpression) this.receiver.bits |= ignoreneedforcastcheckmask; // will check later on
if (this.receiver == null) {
sourcetypebinding sourcetypebinding = scope.enclosingsourcetype();
this.receivertype = sourcetypebinding;
this.receiver = new annotationqualifiedtypereference(sourcetypebinding.compoundname, new long[sourcetypebinding.compoundname.length], 0, 0);
}
else {
this.receivertype = receiver.resolvetype(scope);
}
this.qualifyingtype = this.receivertype;

// will check for null after args are resolved
typebinding[] argumenttypes = noparameters;
if (arguments != null) {
boolean arghaserror = false; // typechecks all arguments
int length = arguments.length;
argumenttypes = new typebinding[length];
for (int i = 0; i < length; i++){
expression argument = arguments[i];
if ((argumenttypes[i] = argument.resolvetype(scope)) == null){
arghaserror = true;
}
}
if (arghaserror) {
if(receivertype instanceof referencebinding) {
// record any selector match, for clients who may still need hint about possible method match
this.codegenbinding = this.binding = scope.findmethod((referencebinding)receivertype, selector, new typebinding[]{}, this);
}
return null;
}
}
if (this.receivertype == null) {
return null;
}

// base type cannot receive any message
if (this.receivertype.isbasetype()) {
scope.problemreporter().errornomethodfor(this, this.receivertype, argumenttypes);
return null;
}
this.codegenbinding = this.binding = scope.getmethod(this.receivertype, selector, argumenttypes, this);
if (!binding.isvalidbinding()) {
if (binding.declaringclass == null) {
if (this.receivertype instanceof referencebinding) {
binding.declaringclass = (referencebinding) this.receivertype;
} else {
scope.problemreporter().errornomethodfor(this, this.receivertype, argumenttypes);
return null;
}
}
scope.problemreporter().invalidmethod(this, binding);
// record the closest match, for clients who may still need hint about possible method match
if (binding instanceof problemmethodbinding){
methodbinding closestmatch = ((problemmethodbinding)binding).closestmatch;
if (closestmatch != null) this.codegenbinding = this.binding = closestmatch;
}
return this.resolvedtype = binding == null ? null : binding.returntype;
}
if (arguments != null) {
for (int i = 0; i < arguments.length; i++) {
arguments[i].implicitwidening(binding.parameters[i], argumenttypes[i]);
}
}
if (ismethodusedeprecated(binding, scope)) {
scope.problemreporter().deprecatedmethod(binding, this);
}

return this.resolvedtype = binding.returntype;
}

public typebinding resolvetype(classscope classscope) {
// answer the signature return type
// base type promotion

constant = notaconstant;
if (this.receiver instanceof castexpression) this.receiver.bits |= ignoreneedforcastcheckmask; // will check later on
if (this.receiver == null) {
this.receivertype = classscope.enclosingsourcetype();
}
else if (this.receiver instanceof typereference) {
typereference typeref = (typereference) receiver;
this.receivertype = typeref.gettypebinding(classscope);
if (!this.receivertype.isvalidbinding()) {
classscope.problemreporter().invalidtype(this.receiver, this.receivertype);
return null;
}
}
this.qualifyingtype = this.receivertype;


// will check for null after args are resolved
typebinding[] argumenttypes = noparameters;
if (arguments != null) {
boolean arghaserror = false; // typechecks all arguments
int length = arguments.length;
argumenttypes = new typebinding[length];
for (int i = 0; i < length; i++){
expression expr = arguments[i];
if (expr instanceof annotationargumentexpression) {
annotationargumentexpression argument = (annotationargumentexpression) expr;
if ((argumenttypes[i] = argument.resolvetype(classscope)) == null){
arghaserror = true;
}
} else {
classscope.problemreporter().annotationinvalidseereferenceargs(expr.sourcestart, expr.sourceend);
return null;
}
}
if (arghaserror) {
if(receivertype instanceof referencebinding) {
// record any selector match, for clients who may still need hint about possible method match
this.codegenbinding = this.binding = classscope.findmethod((referencebinding)receivertype, selector, new typebinding[]{}, this);
}
return null;
}
}
if (this.receivertype == null) {
return null;
}

// base type cannot receive any message
if (this.receivertype.isbasetype()) {
classscope.problemreporter().errornomethodfor(this, this.receivertype, argumenttypes);
return null;
}
this.codegenbinding = this.binding = classscope.getmethod(this.receivertype, selector, argumenttypes, this);
if (!this.binding.isvalidbinding()) {
if (this.binding.declaringclass == null) {
if (this.receivertype instanceof referencebinding) {
binding.declaringclass = (referencebinding) this.receivertype;
} else {
classscope.problemreporter().errornomethodfor(this, this.receivertype, argumenttypes);
return null;
}
}
classscope.problemreporter().invalidmethod(this, binding);
// record the closest match, for clients who may still need hint about possible method match
if (binding instanceof problemmethodbinding){
methodbinding closestmatch = ((problemmethodbinding)binding).closestmatch;
if (closestmatch != null) this.codegenbinding = this.binding = closestmatch;
}
return this.resolvedtype = binding == null ? null : binding.returntype;
}
if (arguments != null) {
for (int i = 0; i < arguments.length; i++) {
arguments[i].implicitwidening(binding.parameters[i], argumenttypes[i]);
}
}
if (ismethodusedeprecated(binding, classscope)) {
classscope.problemreporter().deprecatedmethod(binding, this);
}

return this.resolvedtype = binding.returntype;
}

/* (non-javadoc)
* redefine to capture annotation specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(iabstractsyntaxtreevisitor visitor, blockscope blockscope) {
if (visitor.visit(this, blockscope)) {
if (receiver != null) {
receiver.traverse(visitor, blockscope);
}
if (arguments != null) {
int argumentslength = arguments.length;
for (int i = 0; i < argumentslength; i++)
arguments[i].traverse(visitor, blockscope);
}
}
visitor.endvisit(this, blockscope);
}
}
