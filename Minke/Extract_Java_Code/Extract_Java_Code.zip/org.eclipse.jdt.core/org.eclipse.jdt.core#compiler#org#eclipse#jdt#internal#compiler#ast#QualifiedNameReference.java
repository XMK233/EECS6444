/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.codegen.opcodes;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.missingtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.problemfieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.problemreferencebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding;
import org.eclipse.jdt.internal.compiler.lookup.syntheticmethodbinding;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.lookup.variablebinding;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;

public class qualifiednamereference extends namereference {

public char[][] tokens;
public long[] sourcepositions;
public fieldbinding[] otherbindings;
int[] otherdepths;
public int indexoffirstfieldbinding;//points (into tokens) for the first token that corresponds to first fieldbinding
public syntheticmethodbinding syntheticwriteaccessor;
public syntheticmethodbinding[] syntheticreadaccessors;
public typebinding genericcast;
public typebinding[] othergenericcasts;

public qualifiednamereference(char[][] tokens, long[] positions, int sourcestart, int sourceend) {
this.tokens = tokens;
this.sourcepositions = positions;
this.sourcestart = sourcestart;
this.sourceend = sourceend;
}

public flowinfo analyseassignment(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo, assignment assignment, boolean iscompound) {
// determine the rank until which we now we do not need any actual value for the field access
int otherbindingscount = this.otherbindings == null ? 0 : this.otherbindings.length;
boolean needvalue = otherbindingscount == 0 || !this.otherbindings[0].isstatic();
boolean complyto14 = currentscope.compileroptions().compliancelevel >= classfileconstants.jdk1_4;
fieldbinding lastfieldbinding = null;
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // reading a field
lastfieldbinding = (fieldbinding) this.binding;
if (needvalue || complyto14) {
managesyntheticaccessifnecessary(currentscope, lastfieldbinding, 0, flowinfo);
}
// check if final blank field
if (lastfieldbinding.isblankfinal()
&& this.otherbindings != null // the last field binding is only assigned
&& currentscope.needblankfinalfieldinitializationcheck(lastfieldbinding)) {
flowinfo fieldinits = flowcontext.getinitsforfinalblankinitializationcheck(lastfieldbinding.declaringclass.original(), flowinfo);
if (!fieldinits.isdefinitelyassigned(lastfieldbinding)) {
currentscope.problemreporter().uninitializedblankfinalfield(lastfieldbinding, this);
}
}
break;
case binding.local :
// first binding is a local variable
localvariablebinding localbinding;
if (!flowinfo
.isdefinitelyassigned(localbinding = (localvariablebinding) this.binding)) {
currentscope.problemreporter().uninitializedlocalvariable(localbinding, this);
}
if ((flowinfo.tagbits & flowinfo.unreachable) == 0)	{
localbinding.useflag = localvariablebinding.used;
} else if (localbinding.useflag == localvariablebinding.unused) {
localbinding.useflag = localvariablebinding.fake_used;
}
checknpe(currentscope, flowcontext, flowinfo, true);
}

if (needvalue) {
manageenclosinginstanceaccessifnecessary(currentscope, flowinfo);
// only for first binding
}
// all intermediate field accesses are read accesses
if (this.otherbindings != null) {
for (int i = 0; i < otherbindingscount-1; i++) {
lastfieldbinding = this.otherbindings[i];
needvalue = !this.otherbindings[i+1].isstatic();
if (needvalue || complyto14) {
managesyntheticaccessifnecessary(currentscope, lastfieldbinding, i + 1, flowinfo);
}
}
lastfieldbinding = this.otherbindings[otherbindingscount-1];
}

if (iscompound) {
if (otherbindingscount == 0
&& lastfieldbinding.isblankfinal()
&& currentscope.needblankfinalfieldinitializationcheck(lastfieldbinding)) {
flowinfo fieldinits = flowcontext.getinitsforfinalblankinitializationcheck(lastfieldbinding.declaringclass, flowinfo);
if (!fieldinits.isdefinitelyassigned(lastfieldbinding)) {
currentscope.problemreporter().uninitializedblankfinalfield(lastfieldbinding, this);
}
}
managesyntheticaccessifnecessary(currentscope, lastfieldbinding, otherbindingscount, flowinfo);
}

if (assignment.expression != null) {
flowinfo =
assignment
.expression
.analysecode(currentscope, flowcontext, flowinfo)
.unconditionalinits();
}

// the last field access is a write access
if (lastfieldbinding.isfinal()) {
// in a context where it can be assigned?
if (otherbindingscount == 0
&& this.indexoffirstfieldbinding == 1
&& lastfieldbinding.isblankfinal()
&& !iscompound
&& currentscope.allowblankfinalfieldassignment(lastfieldbinding)) {
if (flowinfo.ispotentiallyassigned(lastfieldbinding)) {
currentscope.problemreporter().duplicateinitializationofblankfinalfield(lastfieldbinding, this);
} else {
flowcontext.recordsettingfinal(lastfieldbinding, this, flowinfo);
}
flowinfo.markasdefinitelyassigned(lastfieldbinding);
} else {
currentscope.problemreporter().cannotassigntofinalfield(lastfieldbinding, this);
if (otherbindingscount == 0 && currentscope.allowblankfinalfieldassignment(lastfieldbinding)) { // pretend it got assigned
flowinfo.markasdefinitelyassigned(lastfieldbinding);
}
}
}
managesyntheticaccessifnecessary(currentscope, lastfieldbinding, -1 /*write-access*/, flowinfo);

return flowinfo;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
return analysecode(currentscope, flowcontext, flowinfo, true);
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo, boolean valuerequired) {
// determine the rank until which we now we do not need any actual value for the field access
int otherbindingscount = this.otherbindings == null ? 0 : this.otherbindings.length;

boolean needvalue = otherbindingscount == 0 ? valuerequired : !this.otherbindings[0].isstatic();
boolean complyto14 = currentscope.compileroptions().compliancelevel >= classfileconstants.jdk1_4;
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // reading a field
if (needvalue || complyto14) {
managesyntheticaccessifnecessary(currentscope, (fieldbinding) this.binding, 0, flowinfo);
}
if (this.indexoffirstfieldbinding == 1) { // was an implicit reference to the first field binding
fieldbinding fieldbinding = (fieldbinding) this.binding;
// check if reading a final blank field
if (fieldbinding.isblankfinal()
&& currentscope.needblankfinalfieldinitializationcheck(fieldbinding)) {
flowinfo fieldinits = flowcontext.getinitsforfinalblankinitializationcheck(fieldbinding.declaringclass.original(), flowinfo);
if (!fieldinits.isdefinitelyassigned(fieldbinding)) {
currentscope.problemreporter().uninitializedblankfinalfield(fieldbinding, this);
}
}
}
break;
case binding.local : // reading a local variable
localvariablebinding localbinding;
if (!flowinfo.isdefinitelyassigned(localbinding = (localvariablebinding) this.binding)) {
currentscope.problemreporter().uninitializedlocalvariable(localbinding, this);
}
if ((flowinfo.tagbits & flowinfo.unreachable) == 0)	{
localbinding.useflag = localvariablebinding.used;
} else if (localbinding.useflag == localvariablebinding.unused) {
localbinding.useflag = localvariablebinding.fake_used;
}
checknpe(currentscope, flowcontext, flowinfo, true);
}
if (needvalue) {
manageenclosinginstanceaccessifnecessary(currentscope, flowinfo);
// only for first binding (if value needed only)
}
if (this.otherbindings != null) {
for (int i = 0; i < otherbindingscount; i++) {
needvalue = i < otherbindingscount-1 ? !this.otherbindings[i+1].isstatic() : valuerequired;
if (needvalue || complyto14) {
managesyntheticaccessifnecessary(currentscope, this.otherbindings[i], i + 1, flowinfo);
}
}
}
return flowinfo;
}

public void checknpe(blockscope scope, flowcontext flowcontext, flowinfo flowinfo, boolean checkstring) {
// cannot override localvariablebinding because this would project o.m onto o when
// analysing assignments
if ((this.bits & astnode.restrictiveflagmask) == binding.local) {
localvariablebinding local = (localvariablebinding) this.binding;
if (local != null &&
(local.type.tagbits & tagbits.isbasetype) == 0 &&
(checkstring || local.type.id != typeids.t_javalangstring)) {
if ((this.bits & astnode.isnonnull) == 0) {
flowcontext.recordusingnullreference(scope, local, this,
flowcontext.may_null, flowinfo);
}
flowinfo.markascomparedequaltononnull(local);
// from thereon it is set
if (flowcontext.initsonfinally != null) {
flowcontext.initsonfinally.markascomparedequaltononnull(local);
}
}
}
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#computeconversion(org.eclipse.jdt.internal.compiler.lookup.scope, org.eclipse.jdt.internal.compiler.lookup.typebinding, org.eclipse.jdt.internal.compiler.lookup.typebinding)
*/
public void computeconversion(scope scope, typebinding runtimetimetype, typebinding compiletimetype) {
if (runtimetimetype == null || compiletimetype == null)
return;
// set the generic cast after the fact, once the type expectation is fully known (no need for strict cast)
fieldbinding field = null;
int length = this.otherbindings == null ? 0 : this.otherbindings.length;
if (length == 0) {
if ((this.bits & binding.field) != 0 && this.binding != null && this.binding.isvalidbinding()) {
field = (fieldbinding) this.binding;
}
} else {
field  = this.otherbindings[length-1];
}
if (field != null) {
fieldbinding originalbinding = field.original();
typebinding originaltype = originalbinding.type;
// extra cast needed if field type is type variable
if (originaltype.leafcomponenttype().istypevariable()) {
typebinding targettype = (!compiletimetype.isbasetype() && runtimetimetype.isbasetype())
? compiletimetype  // unboxing: checkcast before conversion
: runtimetimetype;
typebinding typecast = originaltype.genericcast(targettype);
setgenericcast(length, typecast);
if (typecast instanceof referencebinding) {
referencebinding referencecast = (referencebinding) typecast;
if (!referencecast.canbeseenby(scope)) {
scope.problemreporter().invalidtype(this,
new problemreferencebinding(
charoperation.spliton('.', referencecast.shortreadablename()),
referencecast,
problemreasons.notvisible));
}
}
}
}
super.computeconversion(scope, runtimetimetype, compiletimetype);
}

public void generateassignment(blockscope currentscope, codestream codestream, assignment assignment, boolean valuerequired) {
int pc = codestream.position;
fieldbinding lastfieldbinding = generatereadsequence(currentscope, codestream);
codestream.recordpositionsfrom(pc , this.sourcestart);
assignment.expression.generatecode(currentscope, codestream, true);
fieldstore(currentscope, codestream, lastfieldbinding, this.syntheticwriteaccessor, getfinalreceivertype(), false /*implicit this*/, valuerequired);
// equivalent to valuesrequired[maxotherbindings]
if (valuerequired) {
codestream.generateimplicitconversion(assignment.implicitconversion);
}
}

public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
if (this.constant != constant.notaconstant) {
if (valuerequired) {
codestream.generateconstant(this.constant, this.implicitconversion);
}
} else {
fieldbinding lastfieldbinding = generatereadsequence(currentscope, codestream);
if (lastfieldbinding != null) {
boolean isstatic = lastfieldbinding.isstatic();
constant fieldconstant = lastfieldbinding.constant();
if (fieldconstant != constant.notaconstant) {
if (!isstatic){
codestream.invokeobjectgetclass();
codestream.pop();
}
if (valuerequired) { // inline the last field constant
codestream.generateconstant(fieldconstant, this.implicitconversion);
}
} else {
boolean isfirst = lastfieldbinding == this.binding
&& (this.indexoffirstfieldbinding == 1 || lastfieldbinding.declaringclass == currentscope.enclosingreceivertype())
&& this.otherbindings == null; // could be dup: next.next.next
typebinding requiredgenericcast = getgenericcast(this.otherbindings == null ? 0 : this.otherbindings.length);
if (valuerequired
|| (!isfirst && currentscope.compileroptions().compliancelevel >= classfileconstants.jdk1_4)
|| ((this.implicitconversion & typeids.unboxing) != 0)
|| requiredgenericcast != null) {
int lastfieldpc = codestream.position;
if (lastfieldbinding.declaringclass == null) { // array length
codestream.arraylength();
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else {
// could occur if !valuerequired but compliance >= 1.4
codestream.pop();
}
} else {
syntheticmethodbinding accessor = this.syntheticreadaccessors == null ? null : this.syntheticreadaccessors[this.syntheticreadaccessors.length - 1];
if (accessor == null) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, lastfieldbinding, getfinalreceivertype(), isfirst);
if (isstatic) {
codestream.fieldaccess(opcodes.opc_getstatic, lastfieldbinding, constantpooldeclaringclass);
} else {
codestream.fieldaccess(opcodes.opc_getfield, lastfieldbinding, constantpooldeclaringclass);
}
} else {
codestream.invoke(opcodes.opc_invokestatic, accessor, null /* default declaringclass */);
}
if (requiredgenericcast != null) codestream.checkcast(requiredgenericcast);
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else {
boolean isunboxing = (this.implicitconversion & typeids.unboxing) != 0;
// conversion only generated if unboxing
if (isunboxing) codestream.generateimplicitconversion(this.implicitconversion);
switch (isunboxing ? postconversiontype(currentscope).id : lastfieldbinding.type.id) {
case t_long :
case t_double :
codestream.pop2();
break;
default :
codestream.pop();
break;
}
}
}

int fieldposition = (int) (this.sourcepositions[this.sourcepositions.length - 1] >>> 32);
codestream.recordpositionsfrom(lastfieldpc, fieldposition);
} else {
if (!isstatic){
codestream.invokeobjectgetclass(); // perform null check
codestream.pop();
}
}
}
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public void generatecompoundassignment(blockscope currentscope, codestream codestream, expression expression, int operator, int assignmentimplicitconversion, boolean valuerequired) {
fieldbinding lastfieldbinding = generatereadsequence(currentscope, codestream);
boolean isfirst = lastfieldbinding == this.binding
&& (this.indexoffirstfieldbinding == 1 || lastfieldbinding.declaringclass == currentscope.enclosingreceivertype())
&& this.otherbindings == null; // could be dup: next.next.next
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, lastfieldbinding, getfinalreceivertype(), isfirst);
syntheticmethodbinding accessor = this.syntheticreadaccessors == null ? null : this.syntheticreadaccessors[this.syntheticreadaccessors.length - 1];
if (lastfieldbinding.isstatic()) {
if (accessor == null) {
codestream.fieldaccess(opcodes.opc_getstatic, lastfieldbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, accessor, null /* default declaringclass */);
}
} else {
codestream.dup();
if (accessor == null) {
codestream.fieldaccess(opcodes.opc_getfield, lastfieldbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, accessor, null /* default declaringclass */);
}
}
// the last field access is a write access
// perform the actual compound operation
int operationtypeid;
switch(operationtypeid = (this.implicitconversion & typeids.implicit_conversion_mask) >> 4) {
case t_javalangstring :
case t_javalangobject :
case t_undefined :
codestream.generatestringconcatenationappend(currentscope, null, expression);
break;
default :
typebinding requiredgenericcast = getgenericcast(this.otherbindings == null ? 0 : this.otherbindings.length);
if (requiredgenericcast != null) codestream.checkcast(requiredgenericcast);
// promote the array reference to the suitable operation type
codestream.generateimplicitconversion(this.implicitconversion);
// generate the increment value (will by itself  be promoted to the operation value)
if (expression == intliteral.one) { // prefix operation
codestream.generateconstant(expression.constant, this.implicitconversion);
} else {
expression.generatecode(currentscope, codestream, true);
}
// perform the operation
codestream.sendoperator(operator, operationtypeid);
// cast the value back to the array reference type
codestream.generateimplicitconversion(assignmentimplicitconversion);
}
// actual assignment
fieldstore(currentscope, codestream, lastfieldbinding, this.syntheticwriteaccessor, getfinalreceivertype(), false /*implicit this*/, valuerequired);
// equivalent to valuesrequired[maxotherbindings]
}

public void generatepostincrement(blockscope currentscope, codestream codestream, compoundassignment postincrement, boolean valuerequired) {
fieldbinding lastfieldbinding = generatereadsequence(currentscope, codestream);
boolean isfirst = lastfieldbinding == this.binding
&& (this.indexoffirstfieldbinding == 1 || lastfieldbinding.declaringclass == currentscope.enclosingreceivertype())
&& this.otherbindings == null; // could be dup: next.next.next
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, lastfieldbinding, getfinalreceivertype(), isfirst);
syntheticmethodbinding accessor = this.syntheticreadaccessors == null
? null
: this.syntheticreadaccessors[this.syntheticreadaccessors.length - 1];
if (lastfieldbinding.isstatic()) {
if (accessor == null) {
codestream.fieldaccess(opcodes.opc_getstatic, lastfieldbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, accessor, constantpooldeclaringclass);
}
} else {
codestream.dup();
if (accessor == null) {
codestream.fieldaccess(opcodes.opc_getfield, lastfieldbinding, null /* default declaringclass */);
} else {
codestream.invoke(opcodes.opc_invokestatic, accessor, null /* default declaringclass */);
}
}
typebinding requiredgenericcast = getgenericcast(this.otherbindings == null ? 0 : this.otherbindings.length);
typebinding operandtype;
if (requiredgenericcast != null) {
codestream.checkcast(requiredgenericcast);
operandtype = requiredgenericcast;
} else {
operandtype = lastfieldbinding.type;
}
// duplicate the old field value
if (valuerequired) {
if (lastfieldbinding.isstatic()) {
switch (operandtype.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2();
break;
default:
codestream.dup();
break;
}
} else { // stack:  [owner][old field value]  ---> [old field value][owner][old field value]
switch (operandtype.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2_x1();
break;
default:
codestream.dup_x1();
break;
}
}
}
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generateconstant(
postincrement.expression.constant,
this.implicitconversion);
codestream.sendoperator(postincrement.operator, this.implicitconversion & typeids.compile_type_mask);
codestream.generateimplicitconversion(
postincrement.preassignimplicitconversion);
fieldstore(currentscope, codestream, lastfieldbinding, this.syntheticwriteaccessor, getfinalreceivertype(), false /*implicit this*/, false);
}

/*
* generate code for all bindings (local and fields) excluding the last one, which may then be generated code
* for a read or write access.
*/
public fieldbinding generatereadsequence(blockscope currentscope, codestream codestream) {
// determine the rank until which we now we do not need any actual value for the field access
int otherbindingscount = this.otherbindings == null ? 0 : this.otherbindings.length;
boolean needvalue = otherbindingscount == 0 || !this.otherbindings[0].isstatic();
fieldbinding lastfieldbinding;
typebinding lastgenericcast;
typebinding lastreceivertype;
boolean complyto14 = currentscope.compileroptions().compliancelevel >= classfileconstants.jdk1_4;

switch (this.bits & astnode.restrictiveflagmask) {
case binding.field :
lastfieldbinding = ((fieldbinding) this.binding).original();
lastgenericcast = this.genericcast;
lastreceivertype = this.actualreceivertype;
// if first field is actually constant, we can inline it
if (lastfieldbinding.constant() != constant.notaconstant) {
break;
}
if ((needvalue && !lastfieldbinding.isstatic()) || lastgenericcast != null) {
int pc = codestream.position;
if ((this.bits & astnode.depthmask) != 0) {
referencebinding targettype = currentscope.enclosingsourcetype().enclosingtypeat((this.bits & astnode.depthmask) >> astnode.depthshift);
object[] emulationpath = currentscope.getemulationpath(targettype, true /*only exact match*/, false/*consider enclosing arg*/);
codestream.generateouteraccess(emulationpath, this, targettype, currentscope);
} else {
generatereceiver(codestream);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}
break;
case binding.local : // reading the first local variable
lastfieldbinding = null;
lastgenericcast = null;
localvariablebinding localbinding = (localvariablebinding) this.binding;
lastreceivertype = localbinding.type;
if (!needvalue) break; // no value needed
// regular local variable read
constant localconstant = localbinding.constant();
if (localconstant != constant.notaconstant) {
codestream.generateconstant(localconstant, 0);
// no implicit conversion
} else {
// outer local?
if ((this.bits & astnode.depthmask) != 0) {
// outer local can be reached either through a synthetic arg or a synthetic field
variablebinding[] path = currentscope.getemulationpath(localbinding);
codestream.generateouteraccess(path, this, localbinding, currentscope);
} else {
codestream.load(localbinding);
}
}
break;
default : // should not occur
return null;
}

// all intermediate field accesses are read accesses
// only the last field binding is a write access
int positionslength = this.sourcepositions.length;
fieldbinding initialfieldbinding = lastfieldbinding; // can be null if initial was a local binding
if (this.otherbindings != null) {
for (int i = 0; i < otherbindingscount; i++) {
int pc = codestream.position;
fieldbinding nextfield = this.otherbindings[i].original();
typebinding nextgenericcast = this.othergenericcasts == null ? null : this.othergenericcasts[i];
if (lastfieldbinding != null) {
needvalue = !nextfield.isstatic();
constant fieldconstant = lastfieldbinding.constant();
if (fieldconstant != constant.notaconstant) {
if (i > 0 && !lastfieldbinding.isstatic()) {
codestream.invokeobjectgetclass(); // perform null check
codestream.pop();
}
if (needvalue) {
codestream.generateconstant(fieldconstant, 0);
}
} else {
if (needvalue || (i > 0 && complyto14) || lastgenericcast != null) {
methodbinding accessor = this.syntheticreadaccessors == null ? null : this.syntheticreadaccessors[i];
if (accessor == null) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, lastfieldbinding, lastreceivertype, i == 0 && this.indexoffirstfieldbinding == 1);
if (lastfieldbinding.isstatic()) {
codestream.fieldaccess(opcodes.opc_getstatic, lastfieldbinding, constantpooldeclaringclass);
} else {
codestream.fieldaccess(opcodes.opc_getfield, lastfieldbinding, constantpooldeclaringclass);
}
} else {
codestream.invoke(opcodes.opc_invokestatic, accessor, null /* default declaringclass */);
}
if (lastgenericcast != null) {
codestream.checkcast(lastgenericcast);
lastreceivertype = lastgenericcast;
} else {
lastreceivertype = lastfieldbinding.type;
}
if (!needvalue) codestream.pop();
} else {
if (lastfieldbinding == initialfieldbinding) {
if (lastfieldbinding.isstatic()){
// if no valuerequired, still need possible side-effects of <clinit> invocation, if field belongs to different class
if (initialfieldbinding.declaringclass != this.actualreceivertype.erasure()) {
methodbinding accessor = this.syntheticreadaccessors == null ? null : this.syntheticreadaccessors[i];
if (accessor == null) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, lastfieldbinding, lastreceivertype, i == 0 && this.indexoffirstfieldbinding == 1);
codestream.fieldaccess(opcodes.opc_getstatic, lastfieldbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, accessor, null /* default declaringclass */);
}
codestream.pop();
}
}
} else if (!lastfieldbinding.isstatic()){
codestream.invokeobjectgetclass(); // perform null check
codestream.pop();
}
lastreceivertype = lastfieldbinding.type;
}
if ((positionslength - otherbindingscount + i - 1) >= 0) {
int fieldposition = (int) (this.sourcepositions[positionslength - otherbindingscount + i - 1] >>>32);
codestream.recordpositionsfrom(pc, fieldposition);
}
}
}
lastfieldbinding = nextfield;
lastgenericcast = nextgenericcast;
}
}
return lastfieldbinding;
}

public void generatereceiver(codestream codestream) {
codestream.aload_0();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#generictypearguments()
*/
public typebinding[] generictypearguments() {
return null;
}

protected fieldbinding getcodegenbinding(int index) {
if (index == 0){
return ((fieldbinding)this.binding).original();
} else {
return this.otherbindings[index-1].original();
}
}

/**
* returns the receiver type for the final field in sequence (i.e. the return type of the previous binding)
* @@return receiver type for the final field in sequence
*/
protected typebinding getfinalreceivertype() {
int otherbindingscount = this.otherbindings == null ? 0 : this.otherbindings.length;
switch (otherbindingscount) {
case 0 :
return this.actualreceivertype;
case 1 :
return this.genericcast != null ? this.genericcast : ((variablebinding)this.binding).type;
default:
typebinding previousgenericcast = this.othergenericcasts == null ? null : this.othergenericcasts[otherbindingscount-2];
return previousgenericcast != null ? previousgenericcast : this.otherbindings[otherbindingscount-2].type;
}
}

// get the matching generic cast
protected typebinding getgenericcast(int index) {
if (index == 0){
return this.genericcast;
} else {
if (this.othergenericcasts == null) return null;
return this.othergenericcasts[index-1];
}
}
public typebinding getotherfieldbindings(blockscope scope) {
// at this point restrictiveflag may only have two potential value : field local (i.e cast <<(variablebinding) binding>> is valid)
int length = this.tokens.length;
fieldbinding field = ((this.bits & binding.field) != 0) ? (fieldbinding) this.binding : null;
typebinding type = ((variablebinding) this.binding).type;
int index = this.indexoffirstfieldbinding;
if (index == length) { //	restrictiveflag == field
this.constant = ((fieldbinding) this.binding).constant();
// perform capture conversion if read access
return (type != null && (this.bits & astnode.isstrictlyassigned) == 0)
? type.capture(scope, this.sourceend)
: type;
}
// allocation of the fieldbindings array	and its respective constants
int otherbindingslength = length - index;
this.otherbindings = new fieldbinding[otherbindingslength];
this.otherdepths = new int[otherbindingslength];

// fill the first constant (the one of the binding)
this.constant = ((variablebinding) this.binding).constant();
// save first depth, since will be updated by visibility checks of other bindings
int firstdepth = (this.bits & astnode.depthmask) >> astnode.depthshift;
// iteration on each field
while (index < length) {
char[] token = this.tokens[index];
if (type == null)
return null; // could not resolve type prior to this point

this.bits &= ~astnode.depthmask; // flush previous depth if any
fieldbinding previousfield = field;
field = scope.getfield(type.capture(scope, (int)this.sourcepositions[index]), token, this);
int place = index - this.indexoffirstfieldbinding;
this.otherbindings[place] = field;
this.otherdepths[place] = (this.bits & astnode.depthmask) >> astnode.depthshift;
if (field.isvalidbinding()) {
// set generic cast of for previous field (if any)
if (previousfield != null) {
typebinding fieldreceivertype = type;
typebinding oldreceivertype = fieldreceivertype;
fieldreceivertype = fieldreceivertype.geterasurecompatibletype(field.declaringclass);// handle indirect inheritance thru variable secondary bound
fieldbinding originalbinding = previousfield.original();
if (fieldreceivertype != oldreceivertype || originalbinding.type.leafcomponenttype().istypevariable()) { // record need for explicit cast at codegen
setgenericcast(index-1,originalbinding.type.genericcast(fieldreceivertype)); // type cannot be base-type even in boxing case
}
}
// only last field is actually a write access if any
if (isfieldusedeprecated(field, scope, (this.bits & astnode.isstrictlyassigned) !=0 && index+1 == length)) {
scope.problemreporter().deprecatedfield(field, this);
}
// constant propagation can only be performed as long as the previous one is a constant too.
if (this.constant != constant.notaconstant) {
this.constant = field.constant();
}

if (field.isstatic()) {
if ((field.modifiers & classfileconstants.accenum) != 0) { // enum constants are checked even when qualified)
referencebinding declaringclass = field.original().declaringclass;
methodscope methodscope = scope.methodscope();
sourcetypebinding sourcetype = methodscope.enclosingsourcetype();
if ((this.bits & astnode.isstrictlyassigned) == 0
&& sourcetype == declaringclass
&& methodscope.lastvisiblefieldid >= 0
&& field.id >= methodscope.lastvisiblefieldid
&& (!field.isstatic() || methodscope.isstatic)) {
scope.problemreporter().forwardreference(this, index, field);
}
// check if accessing enum static field in initializer
if ((sourcetype == declaringclass || sourcetype.superclass == declaringclass) // enum constant body
&& field.constant() == constant.notaconstant
&& !methodscope.isstatic
&& methodscope.isinsideinitializerorconstructor()) {
scope.problemreporter().enumstaticfieldusedduringinitialization(field, this);
}
}
// static field accessed through receiver? legal but unoptimal (optional warning)
scope.problemreporter().nonstaticaccesstostaticfield(this, field, index);
// indirect static reference ?
if (field.declaringclass != type) {
scope.problemreporter().indirectaccesstostaticfield(this, field);
}
}
type = field.type;
index++;
} else {
this.constant = constant.notaconstant; //don't fill other constants slots...
scope.problemreporter().invalidfield(this, field, index, type);
setdepth(firstdepth);
return null;
}
}
setdepth(firstdepth);
type = (this.otherbindings[otherbindingslength - 1]).type;
// perform capture conversion if read access
return (type != null && (this.bits & astnode.isstrictlyassigned) == 0)
? type.capture(scope, this.sourceend)
: type;
}

public void manageenclosinginstanceaccessifnecessary(blockscope currentscope, flowinfo flowinfo) {
//if inlinable field, forget the access emulation, the code gen will directly target it
if (((this.bits & astnode.depthmask) == 0) || (this.constant != constant.notaconstant)) {
return;
}
if ((this.bits & astnode.restrictiveflagmask) == binding.local) {
localvariablebinding localvariablebinding = (localvariablebinding) this.binding;
if (localvariablebinding != null) {
switch(localvariablebinding.useflag) {
case localvariablebinding.fake_used :
case localvariablebinding.used :
currentscope.emulateouteraccess(localvariablebinding);
}
}
}
}

/**
* index is <0 to denote write access emulation
*/
public void managesyntheticaccessifnecessary(blockscope currentscope, fieldbinding fieldbinding, int index, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) != 0) return;
// index == 0 denotes the first fieldbinding, index > 0 denotes one of the 'otherbindings', index < 0 denotes a write access (to last binding)
if (fieldbinding.constant() != constant.notaconstant)
return;

if (fieldbinding.isprivate()) { // private access
fieldbinding codegenfield = getcodegenbinding(index < 0 ? (this.otherbindings == null ? 0 : this.otherbindings.length) : index);
referencebinding declaringclass = codegenfield.declaringclass;
if (declaringclass != currentscope.enclosingsourcetype()) {
setsyntheticaccessor(fieldbinding, index, ((sourcetypebinding) declaringclass).addsyntheticmethod(codegenfield, index >= 0 /*read-access?*/, false /*not super access*/));
currentscope.problemreporter().needtoemulatefieldaccess(codegenfield, this, index >= 0 /*read-access?*/);
return;
}
} else if (fieldbinding.isprotected()){
int depth = (index == 0 || (index < 0 && this.otherdepths == null))
? (this.bits & astnode.depthmask) >> astnode.depthshift
: this.otherdepths[index < 0 ? this.otherdepths.length-1 : index-1];

// implicit protected access
if (depth > 0 && (fieldbinding.declaringclass.getpackage() != currentscope.enclosingsourcetype().getpackage())) {
fieldbinding codegenfield = getcodegenbinding(index < 0 ? (this.otherbindings == null ? 0 : this.otherbindings.length) : index);
setsyntheticaccessor(fieldbinding, index,
((sourcetypebinding) currentscope.enclosingsourcetype().enclosingtypeat(depth)).addsyntheticmethod(codegenfield, index >= 0 /*read-access?*/, false /*not super access*/));
currentscope.problemreporter().needtoemulatefieldaccess(codegenfield, this, index >= 0 /*read-access?*/);
return;
}
}
}

public int nullstatus(flowinfo flowinfo) {
return flowinfo.unknown;
}

public constant optimizedbooleanconstant() {
switch (this.resolvedtype.id) {
case t_boolean :
case t_javalangboolean :
if (this.constant != constant.notaconstant) return this.constant;
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // reading a field
if (this.otherbindings == null)
return ((fieldbinding)this.binding).constant();
//$fall-through$
case binding.local : // reading a local variable
return this.otherbindings[this.otherbindings.length-1].constant();
}
}
return constant.notaconstant;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#postconversiontype(scope)
*/
public typebinding postconversiontype(scope scope) {
typebinding convertedtype = this.resolvedtype;
typebinding requiredgenericcast = getgenericcast(this.otherbindings == null ? 0 : this.otherbindings.length);
if (requiredgenericcast != null)
convertedtype = requiredgenericcast;
int runtimetype = (this.implicitconversion & typeids.implicit_conversion_mask) >> 4;
switch (runtimetype) {
case t_boolean :
convertedtype = typebinding.boolean;
break;
case t_byte :
convertedtype = typebinding.byte;
break;
case t_short :
convertedtype = typebinding.short;
break;
case t_char :
convertedtype = typebinding.char;
break;
case t_int :
convertedtype = typebinding.int;
break;
case t_float :
convertedtype = typebinding.float;
break;
case t_long :
convertedtype = typebinding.long;
break;
case t_double :
convertedtype = typebinding.double;
break;
default :
}
if ((this.implicitconversion & typeids.boxing) != 0) {
convertedtype = scope.environment().computeboxingtype(convertedtype);
}
return convertedtype;
}

public stringbuffer printexpression(int indent, stringbuffer output) {
for (int i = 0; i < this.tokens.length; i++) {
if (i > 0) output.append('.');
output.append(this.tokens[i]);
}
return output;
}

/**
* normal field binding did not work, try to bind to a field of the delegate receiver.
*/
public typebinding reporterror(blockscope scope) {
if (this.binding instanceof problemfieldbinding) {
scope.problemreporter().invalidfield(this, (fieldbinding) this.binding);
} else if (this.binding instanceof problemreferencebinding || this.binding instanceof missingtypebinding) {
scope.problemreporter().invalidtype(this, (typebinding) this.binding);
} else {
scope.problemreporter().unresolvablereference(this, this.binding);
}
return null;
}

public typebinding resolvetype(blockscope scope) {
// field and/or local are done before type lookups
// the only available value for the restrictiveflag before
// the tc is flag_type flag_localfield and flag_typelocalfield
this.actualreceivertype = scope.enclosingreceivertype();
this.constant = constant.notaconstant;
if ((this.binding = scope.getbinding(this.tokens, this.bits & astnode.restrictiveflagmask, this, true /*resolve*/)).isvalidbinding()) {
switch (this.bits & astnode.restrictiveflagmask) {
case binding.variable : //============only variable===========
case binding.type | binding.variable :
if (this.binding instanceof localvariablebinding) {
this.bits &= ~astnode.restrictiveflagmask; // clear bits
this.bits |= binding.local;
localvariablebinding local = (localvariablebinding) this.binding;
if (!local.isfinal() && ((this.bits & astnode.depthmask) != 0)) {
scope.problemreporter().cannotrefertononfinalouterlocal((localvariablebinding) this.binding, this);
}
if (local.type != null && (local.type.tagbits & tagbits.hasmissingtype) != 0) {
// only complain if field reference (for local, its type got flagged already)
return null;
}
this.resolvedtype = getotherfieldbindings(scope);
if (this.resolvedtype != null && (this.resolvedtype.tagbits & tagbits.hasmissingtype) != 0) {
fieldbinding lastfield = this.otherbindings[this.otherbindings.length - 1];
scope.problemreporter().invalidfield(this, new problemfieldbinding(lastfield.declaringclass, lastfield.name, problemreasons.notfound), this.tokens.length, this.resolvedtype.leafcomponenttype());
return null;
}
return this.resolvedtype;
}
if (this.binding instanceof fieldbinding) {
this.bits &= ~astnode.restrictiveflagmask; // clear bits
this.bits |= binding.field;
fieldbinding fieldbinding = (fieldbinding) this.binding;
methodscope methodscope = scope.methodscope();
referencebinding declaringclass = fieldbinding.original().declaringclass;
sourcetypebinding sourcetype = methodscope.enclosingsourcetype();
// check for forward references
if ((this.indexoffirstfieldbinding == 1 || (fieldbinding.modifiers & classfileconstants.accenum) != 0 || (!fieldbinding.isfinal() && declaringclass.isenum())) // enum constants are checked even when qualified
&& sourcetype == declaringclass
&& methodscope.lastvisiblefieldid >= 0
&& fieldbinding.id >= methodscope.lastvisiblefieldid
&& (!fieldbinding.isstatic() || methodscope.isstatic)) {
scope.problemreporter().forwardreference(this, this.indexoffirstfieldbinding-1, fieldbinding);
}
if (isfieldusedeprecated(fieldbinding, scope, (this.bits & astnode.isstrictlyassigned) != 0 && this.indexoffirstfieldbinding == this.tokens.length)) {
scope.problemreporter().deprecatedfield(fieldbinding, this);
}
if (fieldbinding.isstatic()) {
// only last field is actually a write access if any
// check if accessing enum static field in initializer
if (declaringclass.isenum()) {
if ((sourcetype == declaringclass || sourcetype.superclass == declaringclass) // enum constant body
&& fieldbinding.constant() == constant.notaconstant
&& !methodscope.isstatic
&& methodscope.isinsideinitializerorconstructor()) {
scope.problemreporter().enumstaticfieldusedduringinitialization(fieldbinding, this);
}
}
if (this.indexoffirstfieldbinding > 1
&& fieldbinding.declaringclass != this.actualreceivertype
&& fieldbinding.declaringclass.canbeseenby(scope)) {
scope.problemreporter().indirectaccesstostaticfield(this, fieldbinding);
}
} else {
if (this.indexoffirstfieldbinding == 1 && scope.compileroptions().getseverity(compileroptions.unqualifiedfieldaccess) != problemseverities.ignore) {
scope.problemreporter().unqualifiedfieldaccess(this, fieldbinding);
}
//must check for the static status....
if (this.indexoffirstfieldbinding > 1  //accessing to a field using a type as "receiver" is allowed only with static field
|| scope.methodscope().isstatic) { 	// the field is the first token of the qualified reference....
scope.problemreporter().staticfieldaccesstononstaticvariable(this, fieldbinding);
return null;
}
}

this.resolvedtype = getotherfieldbindings(scope);
if (this.resolvedtype != null
&& (this.resolvedtype.tagbits & tagbits.hasmissingtype) != 0) {
fieldbinding lastfield = this.indexoffirstfieldbinding == this.tokens.length ? (fieldbinding)this.binding : this.otherbindings[this.otherbindings.length - 1];
scope.problemreporter().invalidfield(this, new problemfieldbinding(lastfield.declaringclass, lastfield.name, problemreasons.notfound), this.tokens.length, this.resolvedtype.leafcomponenttype());
return null;
}
return this.resolvedtype;
}
// thus it was a type
this.bits &= ~astnode.restrictiveflagmask; // clear bits
this.bits |= binding.type;
//$fall-through$
case binding.type : //=============only type ==============
typebinding type = (typebinding) this.binding;
//					if (istypeusedeprecated(type, scope))
//						scope.problemreporter().deprecatedtype(type, this);
type = scope.environment().converttorawtype(type, false /*do not force conversion of enclosing types*/);
return this.resolvedtype = type;
}
}
//========error cases===============
return this.resolvedtype = reporterror(scope);
}

public void setfieldindex(int index) {
this.indexoffirstfieldbinding = index;
}

// set the matching codegenbinding and generic cast
protected void setgenericcast(int index, typebinding somegenericcast) {
if (somegenericcast == null) return;
if (index == 0){
this.genericcast = somegenericcast;
} else {
if (this.othergenericcasts == null) {
this.othergenericcasts = new typebinding[this.otherbindings.length];
}
this.othergenericcasts[index-1] = somegenericcast;
}
}

// set the matching synthetic accessor
protected void setsyntheticaccessor(fieldbinding fieldbinding, int index, syntheticmethodbinding syntheticaccessor) {
if (index < 0) { // write-access ?
this.syntheticwriteaccessor = syntheticaccessor;
} else {
if (this.syntheticreadaccessors == null) {
this.syntheticreadaccessors = new syntheticmethodbinding[this.otherbindings == null ? 1 : this.otherbindings.length + 1];
}
this.syntheticreadaccessors[index] = syntheticaccessor;
}
}

public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public string unboundreferenceerrorname() {
return new string(this.tokens[0]);
}
}
