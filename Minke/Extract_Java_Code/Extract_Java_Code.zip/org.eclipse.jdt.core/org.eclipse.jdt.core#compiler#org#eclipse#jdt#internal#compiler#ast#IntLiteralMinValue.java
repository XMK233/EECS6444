/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.impl.*;

public class intliteralminvalue extends intliteral {

final static char[] charvalue = new char[]{'-','2','1','4','7','4','8','3','6','4','8'};

public intliteralminvalue() {
super(charvalue,0,0,integer.min_value);
this.constant = intconstant.fromvalue(integer.min_value);
}

public void computeconstant(){
/*precomputed at creation time*/ }
}
