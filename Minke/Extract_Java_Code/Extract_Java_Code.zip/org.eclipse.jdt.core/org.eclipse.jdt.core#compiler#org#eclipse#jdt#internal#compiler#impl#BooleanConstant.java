/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.impl;

public class booleanconstant extends constant {

private boolean value;

private static final booleanconstant true = new booleanconstant(true);
private static final booleanconstant false = new booleanconstant(false);

public static booleanconstant fromvalue(boolean value) {
return value ? booleanconstant.true : booleanconstant.false;
}

private booleanconstant(boolean value) {
this.value = value;
}

public boolean booleanvalue() {
return this.value;
}

public string stringvalue() {
// spec 15.17.11
return string.valueof(this.value);
}

public string tostring() {
return "(boolean)" + this.value; //$non-nls-1$
}

public int typeid() {
return t_boolean;
}
}
