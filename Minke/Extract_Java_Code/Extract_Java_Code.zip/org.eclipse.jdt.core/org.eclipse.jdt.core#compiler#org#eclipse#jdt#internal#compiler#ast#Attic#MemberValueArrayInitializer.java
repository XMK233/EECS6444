/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

/**
* membervaluearrayinitializer node
*/
public class membervaluearrayinitializer extends expression {

public expression[] membervalues;

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.expression#printexpression(int, java.lang.stringbuffer)
*/
public stringbuffer printexpression(int indent, stringbuffer output) {
output.append('{');
if (this.membervalues != null) {
int j = 2 ;
for (int i = 0 ; i < this.membervalues.length ; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.membervalues[i].printexpression(0, output);
j -- ;
if (j == 0) {
output.append('\n');
printindent(indent+1, output);
j = 2;
}
}
}
return output.append('}');
}
}
