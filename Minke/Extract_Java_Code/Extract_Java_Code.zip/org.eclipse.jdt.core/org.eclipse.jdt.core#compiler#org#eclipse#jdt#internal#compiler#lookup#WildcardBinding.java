/*******************************************************************************
* copyright (c) 2005, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.util.list;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.wildcard;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;

/*
* a wildcard acts as an argument for parameterized types, allowing to
* abstract parameterized types, e.g. list<string> is not compatible with list<object>,
* but compatible with list<?>.
*/
public class wildcardbinding extends referencebinding {

public referencebinding generictype;
public int rank;
public typebinding bound; // when unbound denotes the corresponding type variable (so as to retrieve its bound lazily)
public typebinding[] otherbounds; // only positionned by lub computations (if so, #bound is also set) and associated to extends mode
char[] genericsignature;
public int boundkind;
referencebinding superclass;
referencebinding[] superinterfaces;
typevariablebinding typevariable; // corresponding variable
lookupenvironment environment;

/**
* when unbound, the bound denotes the corresponding type variable (so as to retrieve its bound lazily)
*/
public wildcardbinding(referencebinding generictype, int rank, typebinding bound, typebinding[] otherbounds, int boundkind, lookupenvironment environment) {
this.rank = rank;
this.boundkind = boundkind;
this.modifiers = classfileconstants.accpublic | extracompilermodifiers.accgenericsignature; // treat wildcard as public
this.environment = environment;
initialize(generictype, bound, otherbounds);

//		if (!generictype.isgenerictype() && !(generictype instanceof unresolvedreferencebinding)) {
//			runtimeexception e = new runtimeexception("wildcard with non generic");
//			e.printstacktrace();
//			throw e;
//		}
if (generictype instanceof unresolvedreferencebinding)
((unresolvedreferencebinding) generictype).addwrapper(this, environment);
if (bound instanceof unresolvedreferencebinding)
((unresolvedreferencebinding) bound).addwrapper(this, environment);
this.tagbits |=  tagbits.hasunresolvedtypevariables; // cleared in resolve()
}

public int kind() {
return this.otherbounds == null ? binding.wildcard_type : binding.intersection_type;
}

/**
* returns true if the argument type satisfies the wildcard bound(s)
*/
public boolean boundcheck(typebinding argumenttype) {
switch (this.boundkind) {
case wildcard.unbound :
return true;
case wildcard.extends :
if (!argumenttype.iscompatiblewith(this.bound)) return false;
// check other bounds (lub scenario)
for (int i = 0, length = this.otherbounds == null ? 0 : this.otherbounds.length; i < length; i++) {
if (!argumenttype.iscompatiblewith(this.otherbounds[i])) return false;
}
return true;
default: // super
// ? super exception   ok for:  ioexception, since it would be ok for (exception)ioexception
return argumenttype.iscompatiblewith(this.bound);
}
}
/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#canbeinstantiated()
*/
public boolean canbeinstantiated() {
// cannot be asked per construction
return false;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#collectmissingtypes(java.util.list)
*/
public list collectmissingtypes(list missingtypes) {
if ((this.tagbits & tagbits.hasmissingtype) != 0) {
missingtypes = this.bound.collectmissingtypes(missingtypes);
}
return missingtypes;
}

/**
* collect the substitutes into a map for certain type variables inside the receiver type
* e.g.   collection<t>.collectsubstitutes(collection<list<x>>, map), will populate map with: t --> list<x>
* constraints:
*   a << f   corresponds to:   f.collectsubstitutes(..., a, ..., constraint_extends (1))
*   a = f   corresponds to:      f.collectsubstitutes(..., a, ..., constraint_equal (0))
*   a >> f   corresponds to:   f.collectsubstitutes(..., a, ..., constraint_super (2))
*/
public void collectsubstitutes(scope scope, typebinding actualtype, inferencecontext inferencecontext, int constraint) {

if ((this.tagbits & tagbits.hastypevariable) == 0) return;
if (actualtype == typebinding.null) return;

if (actualtype.iscapture()) {
capturebinding capture = (capturebinding) actualtype;
actualtype = capture.wildcard;
}

switch (constraint) {
case typeconstants.constraint_extends : // a << f
switch (this.boundkind) {
case wildcard.unbound: // f={?}
//						switch (actualtype.kind()) {
//						case binding.wildcard_type :
//							wildcardbinding actualwildcard = (wildcardbinding) actualtype;
//							switch(actualwildcard.kind) {
//								case wildcard.unbound: // a={?} << f={?}  --> 0
//									break;
//								case wildcard.extends: // a={? extends v} << f={?} ---> 0
//									break;
//								case wildcard.super: // a={? super v} << f={?} ---> 0
//									break;
//							}
//							break;
//						case binding.intersection_type :// a={? extends v1&...&vn} << f={?} ---> 0
//							break;
//						default :// a=v << f={?} ---> 0
//							break;
//						}
break;
case wildcard.extends: // f={? extends u}
switch(actualtype.kind()) {
case binding.wildcard_type :
wildcardbinding actualwildcard = (wildcardbinding) actualtype;
switch(actualwildcard.boundkind) {
case wildcard.unbound: // a={?} << f={? extends u}  --> 0
break;
case wildcard.extends: // a={? extends v} << f={? extends u} ---> v << u
this.bound.collectsubstitutes(scope, actualwildcard.bound, inferencecontext, typeconstants.constraint_extends);
break;
case wildcard.super: // a={? super v} << f={? extends u} ---> 0
break;
}
break;
case binding.intersection_type : // a={? extends v1&...&vn} << f={? extends u} ---> v1 << u, ..., vn << u
wildcardbinding actualintersection = (wildcardbinding) actualtype;
this.bound.collectsubstitutes(scope, actualintersection.bound, inferencecontext, typeconstants.constraint_extends);
for (int i = 0, length = actualintersection.otherbounds.length; i < length; i++) {
this.bound.collectsubstitutes(scope, actualintersection.otherbounds[i], inferencecontext, typeconstants.constraint_extends);
}
break;
default : // a=v << f={? extends u} ---> v << u
this.bound.collectsubstitutes(scope, actualtype, inferencecontext, typeconstants.constraint_extends);
break;
}
break;
case wildcard.super: // f={? super u}
switch (actualtype.kind()) {
case binding.wildcard_type :
wildcardbinding actualwildcard = (wildcardbinding) actualtype;
switch(actualwildcard.boundkind) {
case wildcard.unbound: // a={?} << f={? super u}  --> 0
break;
case wildcard.extends: // a={? extends v} << f={? super u} ---> 0
break;
case wildcard.super: // a={? super v} << f={? super u} ---> 0
this.bound.collectsubstitutes(scope, actualwildcard.bound, inferencecontext, typeconstants.constraint_super);
for (int i = 0, length = actualwildcard.otherbounds == null ? 0 : actualwildcard.otherbounds.length; i < length; i++) {
this.bound.collectsubstitutes(scope, actualwildcard.otherbounds[i], inferencecontext, typeconstants.constraint_super);
}
break;
}
break;
case binding.intersection_type : // a={? extends v1&...&vn} << f={? super u} ---> 0
break;
default :// a=v << f={? super u} ---> v >> u
this.bound.collectsubstitutes(scope, actualtype, inferencecontext, typeconstants.constraint_super);
break;
}
break;
}
break;
case typeconstants.constraint_equal : // a == f
switch (this.boundkind) {
case wildcard.unbound: // f={?}
//						switch (actualtype.kind()) {
//						case binding.wildcard_type :
//							wildcardbinding actualwildcard = (wildcardbinding) actualtype;
//							switch(actualwildcard.kind) {
//								case wildcard.unbound: // a={?} == f={?}  --> 0
//									break;
//								case wildcard.extends: // a={? extends v} == f={?} ---> 0
//									break;
//								case wildcard.super: // a={? super v} == f={?} ---> 0
//									break;
//							}
//							break;
//						case binding.intersection_type :// a={? extends v1&...&vn} == f={?} ---> 0
//							break;
//						default :// a=v == f={?} ---> 0
//							break;
//						}
break;
case wildcard.extends: // f={? extends u}
switch (actualtype.kind()) {
case binding.wildcard_type :
wildcardbinding actualwildcard = (wildcardbinding) actualtype;
switch(actualwildcard.boundkind) {
case wildcard.unbound: // a={?} == f={? extends u}  --> 0
break;
case wildcard.extends: // a={? extends v} == f={? extends u} ---> v == u
this.bound.collectsubstitutes(scope, actualwildcard.bound, inferencecontext, typeconstants.constraint_equal);
for (int i = 0, length = actualwildcard.otherbounds == null ? 0 : actualwildcard.otherbounds.length; i < length; i++) {
this.bound.collectsubstitutes(scope, actualwildcard.otherbounds[i], inferencecontext, typeconstants.constraint_equal);
}
break;
case wildcard.super: // a={? super v} == f={? extends u} ---> 0
break;
}
break;
case binding.intersection_type : // a={? extends v1&...&vn} == f={? extends u} ---> v1 == u, ..., vn == u
wildcardbinding actuaintersection = (wildcardbinding) actualtype;
this.bound.collectsubstitutes(scope, actuaintersection.bound, inferencecontext, typeconstants.constraint_equal);
for (int i = 0, length = actuaintersection.otherbounds == null ? 0 : actuaintersection.otherbounds.length; i < length; i++) {
this.bound.collectsubstitutes(scope, actuaintersection.otherbounds[i], inferencecontext, typeconstants.constraint_equal);
}
break;
default : // a=v == f={? extends u} ---> 0
break;
}
break;
case wildcard.super: // f={? super u}
switch (actualtype.kind()) {
case binding.wildcard_type :
wildcardbinding actualwildcard = (wildcardbinding) actualtype;
switch(actualwildcard.boundkind) {
case wildcard.unbound: // a={?} == f={? super u}  --> 0
break;
case wildcard.extends: // a={? extends v} == f={? super u} ---> 0
break;
case wildcard.super: // a={? super v} == f={? super u} ---> 0
this.bound.collectsubstitutes(scope, actualwildcard.bound, inferencecontext, typeconstants.constraint_equal);
for (int i = 0, length = actualwildcard.otherbounds == null ? 0 : actualwildcard.otherbounds.length; i < length; i++) {
this.bound.collectsubstitutes(scope, actualwildcard.otherbounds[i], inferencecontext, typeconstants.constraint_equal);
}
break;
}
break;
case binding.intersection_type :  // a={? extends v1&...&vn} == f={? super u} ---> 0
break;
default : // a=v == f={? super u} ---> 0
break;
}
break;
}
break;
case typeconstants.constraint_super : // a >> f
switch (this.boundkind) {
case wildcard.unbound: // f={?}
//						switch (actualtype.kind()) {
//						case binding.wildcard_type :
//							wildcardbinding actualwildcard = (wildcardbinding) actualtype;
//							switch(actualwildcard.kind) {
//								case wildcard.unbound: // a={?} >> f={?}  --> 0
//									break;
//								case wildcard.extends: // a={? extends v} >> f={?} ---> 0
//									break;
//								case wildcard.super: // a={? super v} >> f={?} ---> 0
//									break;
//							}
//							break;
//						case binding.intersection_type :// a={? extends v1&...&vn} >> f={?} ---> 0
//							break;
//						default :// a=v >> f={?} ---> 0
//							break;
//						}
break;
case wildcard.extends: // f={? extends u}
switch (actualtype.kind()) {
case binding.wildcard_type :
wildcardbinding actualwildcard = (wildcardbinding) actualtype;
switch(actualwildcard.boundkind) {
case wildcard.unbound: // a={?} >> f={? extends u}  --> 0
break;
case wildcard.extends: // a={? extends v} >> f={? extends u} ---> v >> u
this.bound.collectsubstitutes(scope, actualwildcard.bound, inferencecontext, typeconstants.constraint_super);
for (int i = 0, length = actualwildcard.otherbounds == null ? 0 : actualwildcard.otherbounds.length; i < length; i++) {
this.bound.collectsubstitutes(scope, actualwildcard.otherbounds[i], inferencecontext, typeconstants.constraint_super);
}
break;
case wildcard.super: // a={? super v} >> f={? extends u} ---> 0
break;
}
break;
case binding.intersection_type : // a={? extends v1&...&vn} >> f={? extends u} ---> v1 >> u, ..., vn >> u
wildcardbinding actualintersection = (wildcardbinding) actualtype;
this.bound.collectsubstitutes(scope, actualintersection.bound, inferencecontext, typeconstants.constraint_super);
for (int i = 0, length = actualintersection.otherbounds == null ? 0 : actualintersection.otherbounds.length; i < length; i++) {
this.bound.collectsubstitutes(scope, actualintersection.otherbounds[i], inferencecontext, typeconstants.constraint_super);
}
break;
default : // a=v == f={? extends u} ---> 0
break;
}
break;
case wildcard.super: // f={? super u}
switch (actualtype.kind()) {
case binding.wildcard_type :
wildcardbinding actualwildcard = (wildcardbinding) actualtype;
switch(actualwildcard.boundkind) {
case wildcard.unbound: // a={?} >> f={? super u}  --> 0
break;
case wildcard.extends: // a={? extends v} >> f={? super u} ---> 0
break;
case wildcard.super: // a={? super v} >> f={? super u} ---> v >> u
this.bound.collectsubstitutes(scope, actualwildcard.bound, inferencecontext, typeconstants.constraint_super);
for (int i = 0, length = actualwildcard.otherbounds == null ? 0 : actualwildcard.otherbounds.length; i < length; i++) {
this.bound.collectsubstitutes(scope, actualwildcard.otherbounds[i], inferencecontext, typeconstants.constraint_super);
}
break;
}
break;
case binding.intersection_type :  // a={? extends v1&...&vn} >> f={? super u} ---> 0
break;
default : // a=v >> f={? super u} ---> 0
break;
}
break;
}
break;
}
}

/*
* generictypekey {rank}*|+|- [boundkey]
* p.x<t> { x<?> ... } --> lp/x<tt;>;{0}*
*/
public char[] computeuniquekey(boolean isleaf) {
char[] generictypekey = this.generictype.computeuniquekey(false/*not a leaf*/);
char[] wildcardkey;
// we now encode the rank also in the binding key - https://bugs.eclipse.org/bugs/show_bug.cgi?id=234609
char[] rankcomponent = ('{' + string.valueof(this.rank) + '}').tochararray();
switch (this.boundkind) {
case wildcard.unbound :
wildcardkey = typeconstants.wildcard_star;
break;
case wildcard.extends :
wildcardkey = charoperation.concat(typeconstants.wildcard_plus, this.bound.computeuniquekey(false/*not a leaf*/));
break;
default: // super
wildcardkey = charoperation.concat(typeconstants.wildcard_minus, this.bound.computeuniquekey(false/*not a leaf*/));
break;
}
return charoperation.concat(generictypekey, rankcomponent, wildcardkey);
}



/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#constantpoolname()
*/
public char[] constantpoolname() {
return erasure().constantpoolname();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#debugname()
*/
public string debugname() {
return tostring();
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#erasure()
*/
public typebinding erasure() {
if (this.otherbounds == null) {
if (this.boundkind == wildcard.extends)
return this.bound.erasure();
typevariablebinding var = typevariable();
if (var != null)
return var.erasure();
return this.generictype; // if typevariable() == null, then its inconsistent & return this.generictype to avoid npe case
}
// intersection type
return this.bound.id == typeids.t_javalangobject
? this.otherbounds[0].erasure()  // use first explicit bound to improve stackmap
: this.bound.erasure();
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#signature()
*/
public char[] generictypesignature() {
if (this.genericsignature == null) {
switch (this.boundkind) {
case wildcard.unbound :
this.genericsignature = typeconstants.wildcard_star;
break;
case wildcard.extends :
this.genericsignature = charoperation.concat(typeconstants.wildcard_plus, this.bound.generictypesignature());
break;
default: // super
this.genericsignature = charoperation.concat(typeconstants.wildcard_minus, this.bound.generictypesignature());
}
}
return this.genericsignature;
}

public int hashcode() {
return this.generictype.hashcode();
}

void initialize(referencebinding somegenerictype, typebinding somebound, typebinding[] someotherbounds) {
this.generictype = somegenerictype;
this.bound = somebound;
this.otherbounds = someotherbounds;
if (somegenerictype != null) {
this.fpackage = somegenerictype.getpackage();
}
if (somebound != null) {
this.tagbits |= somebound.tagbits & (tagbits.hastypevariable | tagbits.hasmissingtype | tagbits.containsnestedtypereferences);
}
if (someotherbounds != null) {
for (int i = 0, max = someotherbounds.length; i < max; i++) {
typebinding someotherbound = someotherbounds[i];
this.tagbits |= someotherbound.tagbits & tagbits.containsnestedtypereferences;
}
}
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#issuperclassof(org.eclipse.jdt.internal.compiler.lookup.referencebinding)
*/
public boolean issuperclassof(referencebinding othertype) {
if (this.boundkind == wildcard.super) {
if (this.bound instanceof referencebinding) {
return ((referencebinding) this.bound).issuperclassof(othertype);
} else { // array bound
return othertype.id == typeids.t_javalangobject;
}
}
return false;
}

/**
* returns true if the current type denotes an intersection type: number & comparable<?>
*/
public boolean isintersectiontype() {
return this.otherbounds != null;
}

public boolean ishierarchyconnected() {
return this.superclass != null && this.superinterfaces != null;
}

/**
* returns true if the type is a wildcard
*/
public boolean isunboundwildcard() {
return this.boundkind == wildcard.unbound;
}

/**
* returns true if the type is a wildcard
*/
public boolean iswildcard() {
return true;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#readablename()
*/
public char[] readablename() {
switch (this.boundkind) {
case wildcard.unbound :
return typeconstants.wildcard_name;
case wildcard.extends :
if (this.otherbounds == null)
return charoperation.concat(typeconstants.wildcard_name, typeconstants.wildcard_extends, this.bound.readablename());
stringbuffer buffer = new stringbuffer(10);
buffer.append(this.bound.readablename());
for (int i = 0, length = this.otherbounds.length; i < length; i++) {
buffer.append('&').append(this.otherbounds[i].readablename());
}
int length;
char[] result = new char[length = buffer.length()];
buffer.getchars(0, length, result, 0);
return result;
default: // super
return charoperation.concat(typeconstants.wildcard_name, typeconstants.wildcard_super, this.bound.readablename());
}
}

referencebinding resolve() {
if ((this.tagbits & tagbits.hasunresolvedtypevariables) == 0)
return this;

this.tagbits &= ~tagbits.hasunresolvedtypevariables;
binarytypebinding.resolvetype(this.generictype, this.environment, false /* no raw conversion */);
switch(this.boundkind) {
case wildcard.extends :
typebinding resolvetype = binarytypebinding.resolvetype(this.bound, this.environment, true /* raw conversion */);
this.bound = resolvetype;
this.tagbits |= resolvetype.tagbits & tagbits.containsnestedtypereferences;
for (int i = 0, length = this.otherbounds == null ? 0 : this.otherbounds.length; i < length; i++) {
resolvetype = binarytypebinding.resolvetype(this.otherbounds[i], this.environment, true /* raw conversion */);
this.otherbounds[i]= resolvetype;
this.tagbits |= resolvetype.tagbits & tagbits.containsnestedtypereferences;
}
break;
case wildcard.super :
resolvetype = binarytypebinding.resolvetype(this.bound, this.environment, true /* raw conversion */);
this.bound = resolvetype;
this.tagbits |= resolvetype.tagbits & tagbits.containsnestedtypereferences;
break;
case wildcard.unbound :
}
return this;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#shortreadablename()
*/
public char[] shortreadablename() {
switch (this.boundkind) {
case wildcard.unbound :
return typeconstants.wildcard_name;
case wildcard.extends :
if (this.otherbounds == null)
return charoperation.concat(typeconstants.wildcard_name, typeconstants.wildcard_extends, this.bound.shortreadablename());
stringbuffer buffer = new stringbuffer(10);
buffer.append(this.bound.shortreadablename());
for (int i = 0, length = this.otherbounds.length; i < length; i++) {
buffer.append('&').append(this.otherbounds[i].shortreadablename());
}
int length;
char[] result = new char[length = buffer.length()];
buffer.getchars(0, length, result, 0);
return result;
default: // super
return charoperation.concat(typeconstants.wildcard_name, typeconstants.wildcard_super, this.bound.shortreadablename());
}
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#signature()
*/
public char[] signature() {
// should not be called directly on a wildcard; signature should only be asked on
// original methods or type erasures (which cannot denote wildcards at first level)
if (this.signature == null) {
switch (this.boundkind) {
case wildcard.extends :
return this.bound.signature();
default: // super | unbound
return typevariable().signature();
}
}
return this.signature;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#sourcename()
*/
public char[] sourcename() {
switch (this.boundkind) {
case wildcard.unbound :
return typeconstants.wildcard_name;
case wildcard.extends :
return charoperation.concat(typeconstants.wildcard_name, typeconstants.wildcard_extends, this.bound.sourcename());
default: // super
return charoperation.concat(typeconstants.wildcard_name, typeconstants.wildcard_super, this.bound.sourcename());
}
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.typevariablebinding#superclass()
*/
public referencebinding superclass() {
if (this.superclass == null) {
typebinding supertype = null;
if (this.boundkind == wildcard.extends && !this.bound.isinterface()) {
supertype = this.bound;
} else {
typevariablebinding variable = typevariable();
if (variable != null) supertype = variable.firstbound;
}
this.superclass = supertype instanceof referencebinding && !supertype.isinterface()
? (referencebinding) supertype
: this.environment.getresolvedtype(typeconstants.java_lang_object, null);
}

return this.superclass;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#superinterfaces()
*/
public referencebinding[] superinterfaces() {
if (this.superinterfaces == null) {
if (typevariable() != null) {
this.superinterfaces = this.typevariable.superinterfaces();
} else {
this.superinterfaces = binding.no_superinterfaces;
}
if (this.boundkind == wildcard.extends) {
if (this.bound.isinterface()) {
// augment super interfaces with the wildcard bound
int length = this.superinterfaces.length;
system.arraycopy(this.superinterfaces, 0, this.superinterfaces = new referencebinding[length+1], 1, length);
this.superinterfaces[0] = (referencebinding) this.bound; // make bound first
}
if (this.otherbounds != null) {
// augment super interfaces with the wildcard otherbounds (interfaces per construction)
int length = this.superinterfaces.length;
int otherlength = this.otherbounds.length;
system.arraycopy(this.superinterfaces, 0, this.superinterfaces = new referencebinding[length+otherlength], 0, length);
for (int i = 0; i < otherlength; i++) {
this.superinterfaces[length+i] = (referencebinding) this.otherbounds[i];
}
}
}
}
return this.superinterfaces;
}

public void swapunresolved(unresolvedreferencebinding unresolvedtype, referencebinding resolvedtype, lookupenvironment env) {
boolean affected = false;
if (this.generictype == unresolvedtype) {
this.generictype = resolvedtype; // no raw conversion
affected = true;
}
if (this.bound == unresolvedtype) {
this.bound = env.convertunresolvedbinarytorawtype(resolvedtype);
affected = true;
}
if (this.otherbounds != null) {
for (int i = 0, length = this.otherbounds.length; i < length; i++) {
if (this.otherbounds[i] == unresolvedtype) {
this.otherbounds[i] = env.convertunresolvedbinarytorawtype(resolvedtype);
affected = true;
}
}
}
if (affected)
initialize(this.generictype, this.bound, this.otherbounds);
}

/**
* @@see java.lang.object#tostring()
*/
public string tostring() {
switch (this.boundkind) {
case wildcard.unbound :
return new string(typeconstants.wildcard_name);
case wildcard.extends :
if (this.otherbounds == null)
return new string(charoperation.concat(typeconstants.wildcard_name, typeconstants.wildcard_extends, this.bound.debugname().tochararray()));
stringbuffer buffer = new stringbuffer(this.bound.debugname());
for (int i = 0, length = this.otherbounds.length; i < length; i++) {
buffer.append('&').append(this.otherbounds[i].debugname());
}
return buffer.tostring();
default: // super
return new string(charoperation.concat(typeconstants.wildcard_name, typeconstants.wildcard_super, this.bound.debugname().tochararray()));
}
}
/**
* returns associated type variable, or null in case of inconsistency
*/
public typevariablebinding typevariable() {
if (this.typevariable == null) {
typevariablebinding[] typevariables = this.generictype.typevariables();
if (this.rank < typevariables.length)
this.typevariable = typevariables[this.rank];
}
return this.typevariable;
}
}
