package org.eclipse.jdt.internal.codeassist.impl;

/*
* (c) copyright ibm corp. 2000, 2001.
* all rights reserved.
*/
import org.eclipse.jdt.internal.codeassist.*;
import org.eclipse.jdt.internal.compiler.configurableoption;

public class completionoptions {
/**
* option ids
*/
public static final string option_performvisibilitycheck = completionengine.class.getname() + ".performvisibilitycheck"; //$non-nls-1$
public static final string option_entirewordreplacement = completionengine.class.getname() + ".entirewordreplacement"; //$non-nls-1$

private boolean visibilitysensitive = true;
private boolean entirewordreplacement = true;

/**
* initializing the completion engine options with default settings
*/
public completionoptions() {
}
/**
* initializing the completion engine options with external settings
*/
public completionoptions(configurableoption[] settings) {
if (settings == null)
return;

// filter options which are related to the formatter component
string componentname = completionengine.class.getname();
for (int i = 0, max = settings.length; i < max; i++) {
if (settings[i].getcomponentname().equals(componentname)) {
this.setoption(settings[i]);
}
}
}

public void setvisibilitysensitive(boolean visibilitysensitive){
this.visibilitysensitive = visibilitysensitive;
}

public boolean checkvisibilitysensitive(){
return visibilitysensitive;
}

public void setentirewordreplacement(boolean entirewordreplacement){
this.entirewordreplacement = entirewordreplacement;
}

public boolean checkentirewordreplacement(){
return entirewordreplacement;
}

/**
* change the value of the option corresponding to the option number
*
* @@param optionnumber <code>int</code>
* @@param newvalue <code>int</code>
*/
public void setoption(configurableoption setting) {
string componentname = completionengine.class.getname();

string optionid = setting.getid();

if (optionid.equals(option_performvisibilitycheck)) {
setvisibilitysensitive(setting.getvalueindex() == 0);
} else if (optionid.equals(option_entirewordreplacement)) {
setentirewordreplacement(setting.getvalueindex() == 0);
}
}
}@


1.10
log
@*** empty log message ***
