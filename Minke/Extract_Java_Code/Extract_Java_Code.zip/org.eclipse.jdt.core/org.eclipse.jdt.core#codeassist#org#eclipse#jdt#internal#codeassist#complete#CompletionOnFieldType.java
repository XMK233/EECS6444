/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce an type reference located as a potential return type for a class
* member, containing the cursor location.
* this node is only a fake-field wrapper of the actual completion node
* which is accessible as the fake-field type.
* e.g.
*
*	class x {
*    obj[cursor]
*  }
*
*	---> class x {
*         <completeontype:obj>;
*       }
*
* the source range is always of length 0.
* the arguments of the allocation expression are all the arguments defined
* before the cursor.
*/

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.*;

public class completiononfieldtype extends fielddeclaration {
public boolean islocalvariable;

public completiononfieldtype(typereference type, boolean islocalvariable){
super();
this.sourcestart = type.sourcestart;
this.sourceend = type.sourceend;
this.type = type;
this.name = charoperation.no_char;
this.islocalvariable = islocalvariable;
if (type instanceof completiononsingletypereference) {
((completiononsingletypereference) type).fieldtypecompletionnode = this;
}
}

public stringbuffer printstatement(int tab, stringbuffer output) {
return this.type.print(tab, output).append(';');
}
}
