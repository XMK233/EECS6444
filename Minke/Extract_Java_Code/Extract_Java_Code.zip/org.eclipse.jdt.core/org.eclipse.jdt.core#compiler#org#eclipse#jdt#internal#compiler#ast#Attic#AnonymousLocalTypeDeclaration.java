/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.problem.*;

public class anonymouslocaltypedeclaration extends localtypedeclaration {

public static final char[] anonymous_empty_name = new char[] {};
public qualifiedallocationexpression allocation;

public anonymouslocaltypedeclaration(compilationresult compilationresult) {
super(compilationresult);
modifiers = accdefault;
name = anonymous_empty_name;
}

// use a default name in order to th name lookup
// to operate just like a regular type (which has a name)
//without checking systematically if the naem is null ....
public methodbinding createsinternalconstructorwithbinding(methodbinding inheritedconstructorbinding) {

//add to method'set, the default constuctor that just recall the
//super constructor with the same arguments
string basename = "$anonymous"; //$non-nls-1$
typebinding[] argumenttypes = inheritedconstructorbinding.parameters;
int argumentslength = argumenttypes.length;
//the constructor
constructordeclaration cd = new constructordeclaration(this.compilationresult);
cd.selector = new char[] { 'x' }; //no maining
cd.sourcestart = sourcestart;
cd.sourceend = sourceend;
cd.modifiers = modifiers & accvisibilitymask;
cd.isdefaultconstructor = true;

if (argumentslength > 0) {
argument[] arguments = (cd.arguments = new argument[argumentslength]);
for (int i = argumentslength; --i >= 0;) {
arguments[i] = new argument((basename + i).tochararray(), 0l, null /*type ref*/, accdefault);
}
}

//the super call inside the constructor
cd.constructorcall = superreference.implicitsuperconstructorcall();
cd.constructorcall.sourcestart = sourcestart;
cd.constructorcall.sourceend = sourceend;

if (argumentslength > 0) {
expression[] args;
args = cd.constructorcall.arguments = new expression[argumentslength];
for (int i = argumentslength; --i >= 0;) {
args[i] = new singlenamereference((basename + i).tochararray(), 0l);
}
}

//adding the constructor in the methods list
if (methods == null) {
methods = new abstractmethoddeclaration[] { cd };
} else {
abstractmethoddeclaration[] newmethods;
system.arraycopy(
methods,
0,
newmethods = new abstractmethoddeclaration[methods.length + 1],
1,
methods.length);
newmethods[0] = cd;
methods = newmethods;
}

//============binding update==========================
cd.binding = new methodbinding(
cd.modifiers, //methoddeclaration
argumentslength == 0 ? noparameters : argumenttypes, //arguments bindings
inheritedconstructorbinding.thrownexceptions, //exceptions
binding); //declaringclass

cd.scope = new methodscope(scope, cd, true);
cd.bindarguments();
cd.constructorcall.resolve(cd.scope);

if (binding.methods == null) {
binding.methods = new methodbinding[] { cd.binding };
} else {
methodbinding[] newmethods;
system.arraycopy(
binding.methods,
0,
newmethods = new methodbinding[binding.methods.length + 1],
1,
binding.methods.length);
newmethods[0] = cd.binding;
binding.methods = newmethods;
}
//===================================================

return cd.binding;

}

public stringbuffer print(int indent, stringbuffer output) {

return printbody(indent, output);
}

public void resolve(blockscope currentscope) {

if (binding != null) {
// remember local types binding for innerclass emulation propagation
currentscope.referencecompilationunit().record((localtypebinding)binding);
}
// scope and binding are provided in updatebindingsuperclass
resolve();
updatemaxfieldcount();
}

/**
*	iteration for a local anonymous innertype
*
*/
public void traverse(
iabstractsyntaxtreevisitor visitor,
blockscope blockscope) {

if (ignorefurtherinvestigation)
return;
try {
if (visitor.visit(this, blockscope)) {

int fieldslength;
int methodslength;
int membertypeslength;

// <superclass> is bound to the actual type from the allocation expression
// therefore it has already been iterated at this point.

if (membertypes != null) {
membertypeslength = membertypes.length;
for (int i = 0; i < membertypeslength; i++)
membertypes[i].traverse(visitor, scope);
}
if (fields != null) {
fieldslength = fields.length;
for (int i = 0; i < fieldslength; i++) {
fielddeclaration field;
if ((field = fields[i]).isstatic()) {
// local type cannot have static fields
} else {
field.traverse(visitor, initializerscope);
}
}
}
if (methods != null) {
methodslength = methods.length;
for (int i = 0; i < methodslength; i++)
methods[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, blockscope);
} catch (aborttype e) {
// silent abort
}
}
}
