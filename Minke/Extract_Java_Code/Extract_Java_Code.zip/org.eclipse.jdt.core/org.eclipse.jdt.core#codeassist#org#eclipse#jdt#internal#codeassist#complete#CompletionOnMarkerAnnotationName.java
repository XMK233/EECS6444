/*******************************************************************************
* copyright (c) 2004, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.ast.markerannotation;
import org.eclipse.jdt.internal.compiler.ast.qualifiedtypereference;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class completiononmarkerannotationname extends markerannotation {
public completiononmarkerannotationname(typereference type, int sourcestart){
super(type, sourcestart);
}

public typebinding resolvetype(blockscope scope) {
if(this.type instanceof qualifiedtypereference) {
qualifiedtypereference qualifiedtypereference = (qualifiedtypereference) this.type;
binding binding = scope.parent.gettypeorpackage(qualifiedtypereference.tokens); // step up from the classscope
if (!binding.isvalidbinding()) {
scope.problemreporter().invalidtype(this, (typebinding) binding);
throw new completionnodefound();
}
throw new completionnodefound(this, binding, scope);
}
throw new completionnodefound(this, null, scope);
}
}
