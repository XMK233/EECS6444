/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;

public class switchstatement extends statement {

public expression expression;
public statement[] statements;
public blockscope scope;
public int explicitdeclarations;
public branchlabel breaklabel;
public casestatement[] cases;
public casestatement defaultcase;
public int blockstart;
public int casecount;
int[] constants;

// fallthrough
public final static int case = 0;
public final static int fallthrough = 1;
public final static int escaping = 2;


public syntheticmethodbinding synthetic; // use for switch on enums types

// for local variables table attributes
int preswitchinitstateindex = -1;
int mergedinitstateindex = -1;

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
try {
flowinfo = this.expression.analysecode(currentscope, flowcontext, flowinfo);
switchflowcontext switchcontext =
new switchflowcontext(flowcontext, this, (this.breaklabel = new branchlabel()));

// analyse the block by considering specially the case/default statements (need to bind them
// to the entry point)
flowinfo caseinits = flowinfo.dead_end;
// in case of statements before the first case
this.preswitchinitstateindex = currentscope.methodscope().recordinitializationstates(flowinfo);
int caseindex = 0;
if (this.statements != null) {
int initialcomplaintlevel = (flowinfo.reachmode() & flowinfo.unreachable) != 0 ? statement.complained_fake_reachable : statement.not_complained;
int complaintlevel = initialcomplaintlevel;
int fallthroughstate = case;
for (int i = 0, max = this.statements.length; i < max; i++) {
statement statement = this.statements[i];
if ((caseindex < this.casecount) && (statement == this.cases[caseindex])) { // statement is a case
this.scope.enclosingcase = this.cases[caseindex]; // record entering in a switch case block
caseindex++;
if (fallthroughstate == fallthrough
&& (statement.bits & astnode.documentedfallthrough) == 0) { // the case is not fall-through protected by a line comment
this.scope.problemreporter().possiblefallthroughcase(this.scope.enclosingcase);
}
caseinits = caseinits.mergedwith(flowinfo.unconditionalinits());
complaintlevel = initialcomplaintlevel; // reset complaint
fallthroughstate = case;
} else if (statement == this.defaultcase) { // statement is the default case
this.scope.enclosingcase = this.defaultcase; // record entering in a switch case block
if (fallthroughstate == fallthrough
&& (statement.bits & astnode.documentedfallthrough) == 0) {
this.scope.problemreporter().possiblefallthroughcase(this.scope.enclosingcase);
}
caseinits = caseinits.mergedwith(flowinfo.unconditionalinits());
complaintlevel = initialcomplaintlevel; // reset complaint
fallthroughstate = case;
} else {
fallthroughstate = fallthrough; // reset below if needed
}
if ((complaintlevel = statement.complainifunreachable(caseinits, this.scope, complaintlevel)) < statement.complained_unreachable) {
caseinits = statement.analysecode(this.scope, switchcontext, caseinits);
if (caseinits == flowinfo.dead_end) {
fallthroughstate = escaping;
}
}
}
}

final typebinding resolvedtypebinding = this.expression.resolvedtype;
if (this.casecount > 0 && resolvedtypebinding.isenum()) {
final sourcetypebinding sourcetypebinding = this.scope.classscope().referencecontext.binding;
this.synthetic = sourcetypebinding.addsyntheticmethodforswitchenum(resolvedtypebinding);
}
// if no default case, then record it may jump over the block directly to the end
if (this.defaultcase == null) {
// only retain the potential initializations
flowinfo.addpotentialinitializationsfrom(caseinits.mergedwith(switchcontext.initsonbreak));
this.mergedinitstateindex = currentscope.methodscope().recordinitializationstates(flowinfo);
return flowinfo;
}

// merge all branches inits
flowinfo mergedinfo = caseinits.mergedwith(switchcontext.initsonbreak);
this.mergedinitstateindex =
currentscope.methodscope().recordinitializationstates(mergedinfo);
return mergedinfo;
} finally {
if (this.scope != null) this.scope.enclosingcase = null; // no longer inside switch case block
}
}

/**
* switch code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {

try {
if ((this.bits & isreachable) == 0) {
return;
}
int pc = codestream.position;

// prepare the labels and constants
this.breaklabel.initialize(codestream);
caselabel[] caselabels = new caselabel[this.casecount];
boolean needswitch = this.casecount != 0;
for (int i = 0; i < this.casecount; i++) {
this.cases[i].targetlabel = (caselabels[i] = new caselabel(codestream));
caselabels[i].tagbits |= branchlabel.used;
}
caselabel defaultlabel = new caselabel(codestream);
if (needswitch) defaultlabel.tagbits |= branchlabel.used;
if (this.defaultcase != null) {
this.defaultcase.targetlabel = defaultlabel;
}

final typebinding resolvedtype = this.expression.resolvedtype;
if (resolvedtype.isenum()) {
if (needswitch) {
// go through the translation table
codestream.invoke(opcodes.opc_invokestatic, this.synthetic, null /* default declaringclass */);
this.expression.generatecode(currentscope, codestream, true);
// get enum constant ordinal()
codestream.invokeenumordinal(resolvedtype.constantpoolname());
codestream.iaload();
} else {
// no need to go through the translation table
this.expression.generatecode(currentscope, codestream, false);
}
} else {
// generate expression
this.expression.generatecode(currentscope, codestream, needswitch); // value required (switch without cases)
}
// generate the appropriate switch table/lookup bytecode
if (needswitch) {
int[] sortedindexes = new int[this.casecount];
// we sort the keys to be able to generate the code for tableswitch or lookupswitch
for (int i = 0; i < this.casecount; i++) {
sortedindexes[i] = i;
}
int[] localkeyscopy;
system.arraycopy(this.constants, 0, (localkeyscopy = new int[this.casecount]), 0, this.casecount);
codestream.sort(localkeyscopy, 0, this.casecount - 1, sortedindexes);

int max = localkeyscopy[this.casecount - 1];
int min = localkeyscopy[0];
if ((long) (this.casecount * 2.5) > ((long) max - (long) min)) {

// work-around 1.3 vm bug, if max>0x7fff0000, must use lookup bytecode
// see http://dev.eclipse.org/bugs/show_bug.cgi?id=21557
if (max > 0x7fff0000 && currentscope.compileroptions().compliancelevel < classfileconstants.jdk1_4) {
codestream.lookupswitch(defaultlabel, this.constants, sortedindexes, caselabels);

} else {
codestream.tableswitch(
defaultlabel,
min,
max,
this.constants,
sortedindexes,
caselabels);
}
} else {
codestream.lookupswitch(defaultlabel, this.constants, sortedindexes, caselabels);
}
codestream.updatelastrecordedendpc(this.scope, codestream.position);
}

// generate the switch block statements
int caseindex = 0;
if (this.statements != null) {
for (int i = 0, maxcases = this.statements.length; i < maxcases; i++) {
statement statement = this.statements[i];
if ((caseindex < this.casecount) && (statement == this.cases[caseindex])) { // statements[i] is a case
this.scope.enclosingcase = this.cases[caseindex]; // record entering in a switch case block
if (this.preswitchinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.preswitchinitstateindex);
}
caseindex++;
} else {
if (statement == this.defaultcase) { // statements[i] is a case or a default case
this.scope.enclosingcase = this.defaultcase; // record entering in a switch case block
if (this.preswitchinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.preswitchinitstateindex);
}
}
}
statement.generatecode(this.scope, codestream);
}
}
// may loose some local variable initializations : affecting the local variable attributes
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
if (this.scope != currentscope) {
codestream.exituserscope(this.scope);
}
// place the trailing labels (for break and default case)
this.breaklabel.place();
if (this.defaultcase == null) {
// we want to force an line number entry to get an end position after the switch statement
codestream.recordpositionsfrom(codestream.position, this.sourceend, true);
defaultlabel.place();
}
codestream.recordpositionsfrom(pc, this.sourcestart);
} finally {
if (this.scope != null) this.scope.enclosingcase = null; // no longer inside switch case block
}
}

public stringbuffer printstatement(int indent, stringbuffer output) {

printindent(indent, output).append("switch ("); //$non-nls-1$
this.expression.printexpression(0, output).append(") {"); //$non-nls-1$
if (this.statements != null) {
for (int i = 0; i < this.statements.length; i++) {
output.append('\n');
if (this.statements[i] instanceof casestatement) {
this.statements[i].printstatement(indent, output);
} else {
this.statements[i].printstatement(indent+2, output);
}
}
}
output.append("\n"); //$non-nls-1$
return printindent(indent, output).append('}');
}

public void resolve(blockscope upperscope) {

try {
boolean isenumswitch = false;
typebinding expressiontype = this.expression.resolvetype(upperscope);
if (expressiontype != null) {
this.expression.computeconversion(upperscope, expressiontype, expressiontype);
checktype: {
if (!expressiontype.isvalidbinding()) {
expressiontype = null; // fault-tolerance: ignore type mismatch from constants from hereon
break checktype;
} else if (expressiontype.isbasetype()) {
if (this.expression.isconstantvalueoftypeassignabletotype(expressiontype, typebinding.int))
break checktype;
if (expressiontype.iscompatiblewith(typebinding.int))
break checktype;
} else if (expressiontype.isenum()) {
isenumswitch = true;
break checktype;
} else if (upperscope.isboxingcompatiblewith(expressiontype, typebinding.int)) {
this.expression.computeconversion(upperscope, typebinding.int, expressiontype);
break checktype;
}
upperscope.problemreporter().incorrectswitchtype(this.expression, expressiontype);
expressiontype = null; // fault-tolerance: ignore type mismatch from constants from hereon
}
}
if (this.statements != null) {
this.scope = /*explicitdeclarations == 0 ? upperscope : */new blockscope(upperscope);
int length;
// collection of cases is too big but we will only iterate until casecount
this.cases = new casestatement[length = this.statements.length];
this.constants = new int[length];
casestatement[] duplicatecasestatements = null;
int duplicatecasestatementscounter = 0;
int counter = 0;
for (int i = 0; i < length; i++) {
constant constant;
final statement statement = this.statements[i];
if ((constant = statement.resolvecase(this.scope, expressiontype, this)) != constant.notaconstant) {
int key = constant.intvalue();
//----check for duplicate case statement------------
for (int j = 0; j < counter; j++) {
if (this.constants[j] == key) {
final casestatement currentcasestatement = (casestatement) statement;
if (duplicatecasestatements == null) {
this.scope.problemreporter().duplicatecase(this.cases[j]);
this.scope.problemreporter().duplicatecase(currentcasestatement);
duplicatecasestatements = new casestatement[length];
duplicatecasestatements[duplicatecasestatementscounter++] = this.cases[j];
duplicatecasestatements[duplicatecasestatementscounter++] = currentcasestatement;
} else {
boolean found = false;
searchreportedduplicate: for (int k = 2; k < duplicatecasestatementscounter; k++) {
if (duplicatecasestatements[k] == statement) {
found = true;
break searchreportedduplicate;
}
}
if (!found) {
this.scope.problemreporter().duplicatecase(currentcasestatement);
duplicatecasestatements[duplicatecasestatementscounter++] = currentcasestatement;
}
}
}
}
this.constants[counter++] = key;
}
}
if (length != counter) { // resize constants array
system.arraycopy(this.constants, 0, this.constants = new int[counter], 0, counter);
}
} else {
if ((this.bits & undocumentedemptyblock) != 0) {
upperscope.problemreporter().undocumentedemptyblock(this.blockstart, this.sourceend);
}
}
// for enum switch, check if all constants are accounted for (if no default)
if (isenumswitch && this.defaultcase == null
&& upperscope.compileroptions().getseverity(compileroptions.incompleteenumswitch) != problemseverities.ignore) {
int constantcount = this.constants == null ? 0 : this.constants.length; // could be null if no case statement
if (constantcount == this.casecount
&& this.casecount != ((referencebinding)expressiontype).enumconstantcount()) {
fieldbinding[] enumfields = ((referencebinding)expressiontype.erasure()).fields();
for (int i = 0, max = enumfields.length; i <max; i++) {
fieldbinding enumconstant = enumfields[i];
if ((enumconstant.modifiers & classfileconstants.accenum) == 0) continue;
findconstant : {
for (int j = 0; j < this.casecount; j++) {
if ((enumconstant.id + 1) == this.constants[j]) // zero should not be returned see bug 141810
break findconstant;
}
// enum constant did not get referenced from switch
upperscope.problemreporter().missingenumconstantcase(this, enumconstant);
}
}
}
}
} finally {
if (this.scope != null) this.scope.enclosingcase = null; // no longer inside switch case block
}
}

public void traverse(
astvisitor visitor,
blockscope blockscope) {

if (visitor.visit(this, blockscope)) {
this.expression.traverse(visitor, blockscope);
if (this.statements != null) {
int statementslength = this.statements.length;
for (int i = 0; i < statementslength; i++)
this.statements[i].traverse(visitor, this.scope);
}
}
visitor.endvisit(this, blockscope);
}

/**
* dispatch the call on its last statement.
*/
public void branchchainto(branchlabel label) {

// in order to improve debug attributes for stepping (11431)
// we want to inline the jumps to #breaklabel which already got
// generated (if any), and have them directly branch to a better
// location (the argument label).
// we know at this point that the breaklabel already got placed
if (this.breaklabel.forwardreferencecount() > 0) {
label.becomedelegatefor(this.breaklabel);
}
}
}
