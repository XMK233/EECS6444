/*******************************************************************************
* copyright (c) 2000, 2006 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.compilationunitdeclaration;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;

public class missingbinarytypebinding extends binarytypebinding {

/**
* special constructor for constructing proxies of missing binary types (114349)
* @@param packagebinding
* @@param compoundname
* @@param environment
*/
public missingbinarytypebinding(packagebinding packagebinding, char[][] compoundname, lookupenvironment environment) {
this.compoundname = compoundname;
computeid();
this.tagbits |= tagbits.isbinarybinding | tagbits.hierarchyhasproblems;
this.environment = environment;
this.fpackage = packagebinding;
this.filename = charoperation.concatwith(compoundname, '/');
this.sourcename = compoundname[compoundname.length - 1]; // [java][util][map$entry]
this.modifiers = classfileconstants.accpublic;
this.superclass = null; // will be fixed up using #setmissingsuperclass(...)
this.superinterfaces = binding.no_superinterfaces;
this.typevariables = binding.no_type_variables;
this.membertypes = binding.no_member_types;
this.fields = binding.no_fields;
this.methods = binding.no_methods;
}

/**
* missing binary type will answer <code>false</code> to #isvalidbinding()
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#problemid()
*/
public int problemid() {
return problemreasons.notfound;
}

/**
* only used to fixup the superclass hierarchy of proxy binary types
* @@param missingsuperclass
* @@see lookupenvironment#cachemissingbinarytype(char[][], compilationunitdeclaration)
*/
void setmissingsuperclass(referencebinding missingsuperclass) {
this.superclass = missingsuperclass;
}
}
