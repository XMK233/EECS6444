/*******************************************************************************
* copyright (c) 2005, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.ast.membervaluepair;
import org.eclipse.jdt.internal.compiler.ast.normalannotation;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class completiononannotationmembervaluepair extends normalannotation {
public membervaluepair completedmembervaluepair;
public completiononannotationmembervaluepair(typereference type, int sourcestart, membervaluepair[] membervaluepairs, membervaluepair completedmembervaluepair) {
super(type, sourcestart);
this.membervaluepairs = membervaluepairs;
this.completedmembervaluepair = completedmembervaluepair;
}

public typebinding resolvetype(blockscope scope) {
super.resolvetype(scope);

if (this.resolvedtype == null || !this.resolvedtype.isvalidbinding()) {
throw new completionnodefound();
} else {
throw new completionnodefound(this.completedmembervaluepair, scope);
}
}

public stringbuffer printexpression(int indent, stringbuffer output) {
output.append('@@');
this.type.printexpression(0, output);
output.append('(');
if (this.membervaluepairs != null) {
for (int i = 0, max = this.membervaluepairs.length; i < max; i++) {
if (i > 0) {
output.append(',');
}
this.membervaluepairs[i].print(indent, output);
}
output.append(',');
}
this.completedmembervaluepair.print(indent, output);
output.append(')');

return output;
}
}
