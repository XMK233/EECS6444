/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.arraybinding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.problemreferencebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;

public abstract class typereference extends expression {

/*
* answer a base type reference (can be an array of base type).
*/
public static final typereference basetypereference(int basetype, int dim) {

if (dim == 0) {
switch (basetype) {
case (typeids.t_void) :
return new singletypereference(typebinding.void.simplename, 0);
case (typeids.t_boolean) :
return new singletypereference(typebinding.boolean.simplename, 0);
case (typeids.t_char) :
return new singletypereference(typebinding.char.simplename, 0);
case (typeids.t_float) :
return new singletypereference(typebinding.float.simplename, 0);
case (typeids.t_double) :
return new singletypereference(typebinding.double.simplename, 0);
case (typeids.t_byte) :
return new singletypereference(typebinding.byte.simplename, 0);
case (typeids.t_short) :
return new singletypereference(typebinding.short.simplename, 0);
case (typeids.t_int) :
return new singletypereference(typebinding.int.simplename, 0);
default : //t_long
return new singletypereference(typebinding.long.simplename, 0);
}
}
switch (basetype) {
case (typeids.t_void) :
return new arraytypereference(typebinding.void.simplename, dim, 0);
case (typeids.t_boolean) :
return new arraytypereference(typebinding.boolean.simplename, dim, 0);
case (typeids.t_char) :
return new arraytypereference(typebinding.char.simplename, dim, 0);
case (typeids.t_float) :
return new arraytypereference(typebinding.float.simplename, dim, 0);
case (typeids.t_double) :
return new arraytypereference(typebinding.double.simplename, dim, 0);
case (typeids.t_byte) :
return new arraytypereference(typebinding.byte.simplename, dim, 0);
case (typeids.t_short) :
return new arraytypereference(typebinding.short.simplename, dim, 0);
case (typeids.t_int) :
return new arraytypereference(typebinding.int.simplename, dim, 0);
default : //t_long
return new arraytypereference(typebinding.long.simplename, dim, 0);
}
}

// allows us to trap completion & selection nodes
public void abouttoresolve(scope scope) {
// default implementation: do nothing
}
public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
return flowinfo;
}
public void checkbounds(scope scope) {
// only parameterized type references have bounds
}
public abstract typereference copydims(int dim);
public int dimensions() {
return 0;
}

public abstract char[] getlasttoken();

/**
* @@return char[][]
* todo (jerome) should merge back into #gettypename()
*/
public char [][] getparameterizedtypename(){
return gettypename();
}
protected abstract typebinding gettypebinding(scope scope);
/**
* @@return char[][]
*/
public abstract char [][] gettypename() ;

protected typebinding internalresolvetype(scope scope) {
// handle the error here
this.constant = constant.notaconstant;
if (this.resolvedtype != null) { // is a shared type reference which was already resolved
if (this.resolvedtype.isvalidbinding()) {
return this.resolvedtype;
} else {
switch (this.resolvedtype.problemid()) {
case problemreasons.notfound :
case problemreasons.notvisible :
case problemreasons.inheritednamehidesenclosingname :
typebinding type = this.resolvedtype.closestmatch();
if (type == null) return null;
return scope.environment().converttorawtype(type, false /*do not force conversion of enclosing types*/);
default :
return null;
}
}
}
boolean haserror;
typebinding type = this.resolvedtype = gettypebinding(scope);
if (type == null) {
return null; // detected cycle while resolving hierarchy
} else if ((haserror = !type.isvalidbinding()) == true) {
reportinvalidtype(scope);
switch (type.problemid()) {
case problemreasons.notfound :
case problemreasons.notvisible :
case problemreasons.inheritednamehidesenclosingname :
type = type.closestmatch();
if (type == null) return null;
break;
default :
return null;
}
}
if (type.isarraytype() && ((arraybinding) type).leafcomponenttype == typebinding.void) {
scope.problemreporter().cannotallocatevoidarray(this);
return null;
}
if (!(this instanceof qualifiedtypereference)   // qualifiedtypereference#gettypebinding called above will have already checked deprecation
&& istypeusedeprecated(type, scope)) {
reportdeprecatedtype(type, scope);
}
type = scope.environment().converttorawtype(type, false /*do not force conversion of enclosing types*/);
if (type.leafcomponenttype().israwtype()
&& (this.bits & astnode.ignorerawtypecheck) == 0
&& scope.compileroptions().getseverity(compileroptions.rawtypereference) != problemseverities.ignore) {
scope.problemreporter().rawtypereference(this, type);
}
if (haserror) {
// do not store the computed type, keep the problem type instead
return type;
}
return this.resolvedtype = type;
}
public boolean istypereference() {
return true;
}

protected void reportdeprecatedtype(typebinding type, scope scope, int index) {
scope.problemreporter().deprecatedtype(type, this, index);
}

protected void reportdeprecatedtype(typebinding type, scope scope) {
scope.problemreporter().deprecatedtype(type, this, integer.max_value);
}

protected void reportinvalidtype(scope scope) {
scope.problemreporter().invalidtype(this, this.resolvedtype);
}

public typebinding resolvesupertype(classscope scope) {
// assumes the implementation of resolvetype(classscope) will call back to detect cycles
typebinding supertype = resolvetype(scope);
if (supertype == null) return null;

if (supertype.istypevariable()) {
if (this.resolvedtype.isvalidbinding()) {
this.resolvedtype = new problemreferencebinding(gettypename(), (referencebinding)this.resolvedtype, problemreasons.illegalsupertypevariable);
reportinvalidtype(scope);
}
return null;
}
return supertype;
}

public final typebinding resolvetype(blockscope blockscope) {
return resolvetype(blockscope, true /* checkbounds if any */);
}

public typebinding resolvetype(blockscope scope, boolean checkbounds) {
return internalresolvetype(scope);
}

public typebinding resolvetype(classscope scope) {
return internalresolvetype(scope);
}

public typebinding resolvetypeargument(blockscope blockscope, referencebinding generictype, int rank) {
return resolvetype(blockscope, true /* check bounds*/);
}

public typebinding resolvetypeargument(classscope classscope, referencebinding generictype, int rank) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=294057, circularity is allowed when we are
// resolving type arguments i.e interface a<t extends c> {}	interface b extends a<d> {}
// interface d extends c {}	interface c extends b {}
referencebinding ref = classscope.referencecontext.binding;
boolean pausehierarchycheck = false;
try {
if (ref.ishierarchybeingconnected()) {
ref.tagbits |= tagbits.pausehierarchycheck;
pausehierarchycheck = true;
}
return resolvetype(classscope);
} finally {
if (pausehierarchycheck) {
ref.tagbits &= ~tagbits.pausehierarchycheck;
}
}
}

public abstract void traverse(astvisitor visitor, blockscope scope);

public abstract void traverse(astvisitor visitor, classscope scope);
}
