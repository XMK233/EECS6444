/*******************************************************************************
* copyright (c) 2005, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.ast.membervaluepair;

/*
* completion node build by the parser in any case it was intending to
* reduce annotation's attribute name containing the cursor.
* e.g.
*
*	@@annot(attri[cursor]
*	class x {
*  }
*
*	---> @@annot(<completiononattributename:attri>)
*		 class x {
*       }
*/
public class completiononmembervaluename extends membervaluepair {
public completiononmembervaluename(char[] token, int sourcestart, int sourceend) {
super(token, sourcestart, sourceend, null);
}

public stringbuffer print(int indent, stringbuffer output) {
output.append("<completeonattributename:"); //$non-nls-1$
output.append(this.name);
output.append('>');
return output;
}
}
