/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;



public class javadocarrayqualifiedtypereference extends arrayqualifiedtypereference {

public int tagsourcestart, tagsourceend;

public javadocarrayqualifiedtypereference(javadocqualifiedtypereference typeref, int dim) {
super(typeref.tokens, dim, typeref.sourcepositions);
}

protected void reportinvalidtype(scope scope) {
scope.problemreporter().javadocinvalidtype(this, this.resolvedtype, scope.getdeclarationmodifiers());
}
protected void reportdeprecatedtype(typebinding type, scope scope) {
scope.problemreporter().javadocdeprecatedtype(type, this, scope.getdeclarationmodifiers());
}

/* (non-javadoc)
* redefine to capture javadoc specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.astvisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
