/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class javadocfieldreference extends fieldreference {

public int tagsourcestart, tagsourceend;
public int tagvalue;
public methodbinding methodbinding;

public javadocfieldreference(char[] source, long pos) {
super(source, pos);
this.bits |= insidejavadoc;
}

/*
public binding getbinding() {
if (this.methodbinding != null) {
return this.methodbinding;
}
return this.binding;
}
*/

/*
* resolves type on a block or class scope.
*/
protected typebinding internalresolvetype(scope scope) {

this.constant = constant.notaconstant;
if (this.receiver == null) {
this.actualreceivertype = scope.enclosingreceivertype();
} else if (scope.kind == scope.class_scope) {
this.actualreceivertype = this.receiver.resolvetype((classscope) scope);
} else {
this.actualreceivertype = this.receiver.resolvetype((blockscope)scope);
}
if (this.actualreceivertype == null) {
return null;
}

binding fieldbinding = (this.receiver != null && this.receiver.isthis())
? scope.classscope().getbinding(this.token, this.bits & restrictiveflagmask, this, true /*resolve*/)
: scope.getfield(this.actualreceivertype, this.token, this);
if (!fieldbinding.isvalidbinding()) {
// implicit lookup may discover issues due to static/constructor contexts. javadoc must be resilient
switch (fieldbinding.problemid()) {
case problemreasons.nonstaticreferenceinconstructorinvocation:
case problemreasons.nonstaticreferenceinstaticcontext:
case problemreasons.inheritednamehidesenclosingname :
fieldbinding closestmatch = ((problemfieldbinding)fieldbinding).closestmatch;
if (closestmatch != null) {
fieldbinding = closestmatch; // ignore problem if can reach target field through it
}
}
}
// when there's no valid field binding, try to resolve possible method reference without parenthesis
if (!fieldbinding.isvalidbinding() || !(fieldbinding instanceof fieldbinding)) {
if (this.receiver.resolvedtype instanceof problemreferencebinding) {
// problem already got signaled on receiver, do not report secondary problem
return null;
}
if (this.actualreceivertype instanceof referencebinding) {
referencebinding refbinding = (referencebinding) this.actualreceivertype;
methodbinding possiblemethod = this.receiver.isthis()
? scope.getimplicitmethod(this.token, binding.no_types, this)
: scope.getmethod(refbinding, this.token, binding.no_types, this);
if (possiblemethod.isvalidbinding()) {
this.methodbinding = possiblemethod;
} else {
problemmethodbinding problemmethodbinding = (problemmethodbinding) possiblemethod;
if (problemmethodbinding.closestmatch == null) {
if (fieldbinding.isvalidbinding()) {
// when the binding is not on a field (e.g. local variable), we need to create a problem field binding to report the correct problem
// see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=254825
fieldbinding = new problemfieldbinding(refbinding, fieldbinding.readablename(), problemreasons.notfound);
}
scope.problemreporter().javadocinvalidfield(this, fieldbinding, this.actualreceivertype, scope.getdeclarationmodifiers());
} else {
this.methodbinding = problemmethodbinding.closestmatch;
}
}
}
return null;
}
this.binding = (fieldbinding) fieldbinding;

if (isfieldusedeprecated(this.binding, scope, (this.bits & isstrictlyassigned) != 0)) {
scope.problemreporter().javadocdeprecatedfield(this.binding, this, scope.getdeclarationmodifiers());
}
return this.resolvedtype = this.binding.type;
}

public boolean issuperaccess() {
return (this.bits & astnode.superaccess) != 0;
}

public stringbuffer printexpression(int indent, stringbuffer output) {

if (this.receiver != null) {
this.receiver.printexpression(0, output);
}
output.append('#').append(this.token);
return output;
}

public typebinding resolvetype(blockscope scope) {
return internalresolvetype(scope);
}

public typebinding resolvetype(classscope scope) {
return internalresolvetype(scope);
}

/* (non-javadoc)
* redefine to capture javadoc specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.astvisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(astvisitor visitor, blockscope scope) {

if (visitor.visit(this, scope)) {
if (this.receiver != null) {
this.receiver.traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
public void traverse(astvisitor visitor, classscope scope) {

if (visitor.visit(this, scope)) {
if (this.receiver != null) {
this.receiver.traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
