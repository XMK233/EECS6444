package org.eclipse.jdt.internal.compiler.parser;
/*
* (c) copyright ibm corp. 2000, 2001.
* all rights reserved.
*/
import org.eclipse.jdt.internal.compiler.*;

/**
* @@deprecated - use org.eclipse.jdt.core.compiler.invalidinputexception instead
*
*/
public class invalidinputexception extends exception {
/**
* invalidinputexception constructor comment.
*/
public invalidinputexception() {
super();
}
/**
* invalidinputexception constructor comment.
* @@param s java.lang.string
*/
public invalidinputexception(string s) {
super(s);
}
}
