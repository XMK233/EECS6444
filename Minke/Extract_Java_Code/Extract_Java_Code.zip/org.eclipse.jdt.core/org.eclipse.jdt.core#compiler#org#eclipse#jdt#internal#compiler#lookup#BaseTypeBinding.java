/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.lookup.typeids;

public final class basetypebinding extends typebinding {

public static final int[] conversions;
public static final int identity = 1;
public static final int widening = 2;
public static final int narrowing = 4;
public static final int max_conversions = 16*16; // well-known x well-known

static {
conversions	 = initializeconversions();
}

public static final int[] initializeconversions(){
// fromtype   desttype --> conversion
//  0000   0000       				0000

int[] table  = new int[max_conversions];

table[typeids.boolean2boolean] = identity;

table[typeids.byte2byte] 		= identity;
table[typeids.byte2short] 		= widening;
table[typeids.byte2char] 		= narrowing;
table[typeids.byte2int] 			= widening;
table[typeids.byte2long] 		= widening;
table[typeids.byte2float] 		= widening;
table[typeids.byte2double] 	= widening;

table[typeids.short2byte] 		= narrowing;
table[typeids.short2short] 		= identity;
table[typeids.short2char] 		= narrowing;
table[typeids.short2int] 			= widening;
table[typeids.short2long] 		= widening;
table[typeids.short2float]	 	= widening;
table[typeids.short2double] 	= widening;

table[typeids.char2byte] 		= narrowing;
table[typeids.char2short] 		= narrowing;
table[typeids.char2char] 		= identity;
table[typeids.char2int] 			= widening;
table[typeids.char2long] 		= widening;
table[typeids.char2float] 		= widening;
table[typeids.char2double] 	= widening;

table[typeids.int2byte] 			= narrowing;
table[typeids.int2short] 			= narrowing;
table[typeids.int2char] 			= narrowing;
table[typeids.int2int] 				= identity;
table[typeids.int2long] 			= widening;
table[typeids.int2float] 			= widening;
table[typeids.int2double] 		= widening;

table[typeids.long2byte] 		= narrowing;
table[typeids.long2short] 		= narrowing;
table[typeids.long2char] 		= narrowing;
table[typeids.long2int] 			= narrowing;
table[typeids.long2long] 		= identity;
table[typeids.long2float] 		= widening;
table[typeids.long2double] 	= widening;

table[typeids.float2byte] 		= narrowing;
table[typeids.float2short] 		= narrowing;
table[typeids.float2char] 		= narrowing;
table[typeids.float2int] 			= narrowing;
table[typeids.float2long] 		= narrowing;
table[typeids.float2float] 		= identity;
table[typeids.float2double] 	= widening;

table[typeids.double2byte] 	= narrowing;
table[typeids.double2short] 	= narrowing;
table[typeids.double2char] 	= narrowing;
table[typeids.double2int] 		= narrowing;
table[typeids.double2long] 	= narrowing;
table[typeids.double2float] 	= narrowing;
table[typeids.double2double]= identity;

return table;
}
/**
* predicate telling whether "left" can store a "right" using some narrowing conversion
*(is left smaller than right)
* @@param left - the target type to convert to
* @@param right - the actual type
* @@return true if legal narrowing conversion
*/
public static final boolean isnarrowing(int left, int right) {
int right2left = right + (left<<4);
return right2left >= 0
&& right2left < max_conversions
&& (conversions[right2left] & (identity|narrowing)) != 0;
}

/**
* predicate telling whether "left" can store a "right" using some widening conversion
*(is left bigger than right)
* @@param left - the target type to convert to
* @@param right - the actual type
* @@return true if legal widening conversion
*/
public static final boolean iswidening(int left, int right) {
int right2left = right + (left<<4);
return right2left >= 0
&& right2left < max_conversions
&& (conversions[right2left] & (identity|widening)) != 0;
}

public char[] simplename;

private char[] constantpoolname;

basetypebinding(int id, char[] name, char[] constantpoolname) {
this.tagbits |= tagbits.isbasetype;
this.id = id;
this.simplename = name;
this.constantpoolname = constantpoolname;
}

/**
* int -> i
*/
public char[] computeuniquekey(boolean isleaf) {
return constantpoolname();
}

/* answer the receiver's constant pool name.
*/
public char[] constantpoolname() {

return this.constantpoolname;
}

public packagebinding getpackage() {

return null;
}

/* answer true if the receiver type can be assigned to the argument type (right)
*/
public final boolean iscompatiblewith(typebinding left) {
if (this == left)
return true;
int right2left = this.id + (left.id<<4);
if (right2left >= 0
&& right2left < max_conversions
&& (conversions[right2left] & (identity|widening)) != 0)
return true;
return this == typebinding.null && !left.isbasetype();
}

/**
* t_null is acting as an unchecked exception
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#isuncheckedexception(boolean)
*/
public boolean isuncheckedexception(boolean includesupertype) {
return this == typebinding.null;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#kind()
*/
public int kind() {
return binding.base_type;
}
public char[] qualifiedsourcename() {
return this.simplename;
}

public char[] readablename() {
return this.simplename;
}

public char[] shortreadablename() {
return this.simplename;
}

public char[] sourcename() {
return this.simplename;
}

public string tostring() {
return new string(this.constantpoolname) + " (id=" + this.id + ")"; //$non-nls-1$ //$non-nls-2$
}
}
