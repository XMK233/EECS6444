/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;

public class problembinding extends binding {
public char[] name;
public referencebinding searchtype;
private int problemid;
// note: must only answer the subset of the name related to the problem

public problembinding(char[][] compoundname, int problemid) {
this(charoperation.concatwith(compoundname, '.'), problemid);
}
// note: must only answer the subset of the name related to the problem

public problembinding(char[][] compoundname, referencebinding searchtype, int problemid) {
this(charoperation.concatwith(compoundname, '.'), searchtype, problemid);
}
problembinding(char[] name, int problemid) {
this.name = name;
this.problemid = problemid;
}
problembinding(char[] name, referencebinding searchtype, int problemid) {
this(name, problemid);
this.searchtype = searchtype;
}
/* api
* answer the receiver's binding type from binding.bindingid.
*/

public final int kind() {
return variable | type;
}
/* api
* answer the problem id associated with the receiver.
* noerror if the receiver is a valid binding.
*/

public final int problemid() {
return this.problemid;
}
public char[] readablename() {
return this.name;
}
}
