/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

import org.eclipse.jdt.internal.compiler.lookup.typeconstants;

/* todo (olivier) constants should be moved to constantpool */
public interface qualifiednamesconstants {
char[] javalangobjectconstantpoolname = "java/lang/object".tochararray(); //$non-nls-1$
char[] javalangstringconstantpoolname = "java/lang/string".tochararray(); //$non-nls-1$
char[] javalangstringbufferconstantpoolname = "java/lang/stringbuffer".tochararray(); //$non-nls-1$
char[] javalangclassconstantpoolname = "java/lang/class".tochararray(); //$non-nls-1$
char[] javalangthrowableconstantpoolname = "java/lang/throwable".tochararray(); //$non-nls-1$
char[] javalangclassnotfoundexceptionconstantpoolname = "java/lang/classnotfoundexception".tochararray(); //$non-nls-1$
char[] javalangnoclassdeffounderrorconstantpoolname = "java/lang/noclassdeffounderror".tochararray(); //$non-nls-1$
char[] javalangintegerconstantpoolname = "java/lang/integer".tochararray(); //$non-nls-1$
char[] javalangfloatconstantpoolname = "java/lang/float".tochararray(); //$non-nls-1$
char[] javalangdoubleconstantpoolname = "java/lang/double".tochararray(); //$non-nls-1$
char[] javalanglongconstantpoolname = "java/lang/long".tochararray(); //$non-nls-1$
char[] javalangshortconstantpoolname = "java/lang/short".tochararray(); //$non-nls-1$
char[] javalangbyteconstantpoolname = "java/lang/byte".tochararray(); //$non-nls-1$
char[] javalangcharacterconstantpoolname = "java/lang/character".tochararray(); //$non-nls-1$
char[] javalangvoidconstantpoolname = "java/lang/void".tochararray(); //$non-nls-1$
char[] javalangbooleanconstantpoolname = "java/lang/boolean".tochararray(); //$non-nls-1$
char[] javalangsystemconstantpoolname = "java/lang/system".tochararray(); //$non-nls-1$
char[] javalangerrorconstantpoolname = "java/lang/error".tochararray(); //$non-nls-1$
char[] javalangexceptionconstantpoolname = "java/lang/exception".tochararray(); //$non-nls-1$
char[] javalangreflectconstructor = "java/lang/reflect/constructor".tochararray();   //$non-nls-1$
char[] javautiliteratorconstantpoolname = "java/util/iterator".tochararray(); //$non-nls-1$
char[] javalangstringbuilderconstantpoolname = "java/lang/stringbuilder".tochararray(); //$non-nls-1$
char[] append = "append".tochararray(); //$non-nls-1$
char[] tostring = "tostring".tochararray(); //$non-nls-1$
char[] init = "<init>".tochararray(); //$non-nls-1$
char[] clinit = "<clinit>".tochararray(); //$non-nls-1$
char[] valueof = "valueof".tochararray(); //$non-nls-1$
char[] forname = "forname".tochararray(); //$non-nls-1$
char[] getmessage = "getmessage".tochararray(); //$non-nls-1$
char[] newinstance = "newinstance".tochararray(); //$non-nls-1$
char[] getconstructor = "getconstructor".tochararray(); //$non-nls-1$
char[] exit = "exit".tochararray(); //$non-nls-1$
char[] intern = "intern".tochararray(); //$non-nls-1$
char[] out = "out".tochararray(); //$non-nls-1$
char[] type = "type".tochararray(); //$non-nls-1$
char[] this = "this".tochararray(); //$non-nls-1$
char[] javalangclasssignature = "ljava/lang/class;".tochararray(); //$non-nls-1$
char[] fornamesignature = "(ljava/lang/string;)ljava/lang/class;".tochararray(); //$non-nls-1$
char[] getmessagesignature = "()ljava/lang/string;".tochararray(); //$non-nls-1$
char[] getconstructorsignature = "([ljava/lang/class;)ljava/lang/reflect/constructor;".tochararray(); //$non-nls-1$
char[] stringconstructorsignature = "(ljava/lang/string;)v".tochararray(); //$non-nls-1$
char[] newinstancesignature = "(ljava/lang/class;[i)ljava/lang/object;".tochararray(); //$non-nls-1$
char[] javalangreflectconstructornewinstancesignature = "([ljava/lang/object;)ljava/lang/object;".tochararray(); //$non-nls-1$
char[] defaultconstructorsignature = "()v".tochararray(); //$non-nls-1$
char[] clinitsignature = defaultconstructorsignature;
char[] tostringsignature = getmessagesignature;
char[] internsignature = getmessagesignature;
char[] stringbufferappendintsignature = "(i)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
char[] stringbufferappendlongsignature = "(j)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
char[] stringbufferappendfloatsignature = "(f)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
char[] stringbufferappenddoublesignature = "(d)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
char[] stringbufferappendcharsignature = "(c)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
char[] stringbufferappendbooleansignature = "(z)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
char[] stringbufferappendobjectsignature = "(ljava/lang/object;)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
char[] stringbufferappendstringsignature = "(ljava/lang/string;)ljava/lang/stringbuffer;".tochararray(); //$non-nls-1$
char[] stringbuilderappendintsignature = "(i)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
char[] stringbuilderappendlongsignature = "(j)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
char[] stringbuilderappendfloatsignature = "(f)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
char[] stringbuilderappenddoublesignature = "(d)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
char[] stringbuilderappendcharsignature = "(c)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
char[] stringbuilderappendbooleansignature = "(z)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
char[] stringbuilderappendobjectsignature = "(ljava/lang/object;)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
char[] stringbuilderappendstringsignature = "(ljava/lang/string;)ljava/lang/stringbuilder;".tochararray(); //$non-nls-1$
char[] valueofobjectsignature = "(ljava/lang/object;)ljava/lang/string;".tochararray(); //$non-nls-1$
char[] valueofintsignature = "(i)ljava/lang/string;".tochararray(); //$non-nls-1$
char[] valueoflongsignature = "(j)ljava/lang/string;".tochararray(); //$non-nls-1$
char[] valueofcharsignature = "(c)ljava/lang/string;".tochararray(); //$non-nls-1$
char[] valueofbooleansignature = "(z)ljava/lang/string;".tochararray(); //$non-nls-1$
char[] valueofdoublesignature = "(d)ljava/lang/string;".tochararray(); //$non-nls-1$
char[] valueoffloatsignature = "(f)ljava/lang/string;".tochararray(); //$non-nls-1$
char[] javaioprintstreamsignature = "ljava/io/printstream;".tochararray(); //$non-nls-1$
char[] exitintsignature = "(i)v".tochararray(); //$non-nls-1$
char[] arrayjavalangobjectconstantpoolname = "[ljava/lang/object;".tochararray(); //$non-nls-1$
char[] arrayjavalangclassconstantpoolname = "[ljava/lang/class;".tochararray(); //$non-nls-1$
char[] javalangassertionerrorconstantpoolname = "java/lang/assertionerror".tochararray(); //$non-nls-1$
char[] intconstrsignature = "(i)v".tochararray(); //$non-nls-1$
char[] longconstrsignature = "(j)v".tochararray(); //$non-nls-1$
char[] floatconstrsignature = "(f)v".tochararray(); //$non-nls-1$
char[] doubleconstrsignature = "(d)v".tochararray(); //$non-nls-1$
char[] charconstrsignature = "(c)v".tochararray(); //$non-nls-1$
char[] booleanconstrsignature = "(z)v".tochararray(); //$non-nls-1$
char[] objectconstrsignature = "(ljava/lang/object;)v".tochararray(); //$non-nls-1$
char[] shortconstrsignature = "(s)v".tochararray(); //$non-nls-1$
char[] byteconstrsignature = "(b)v".tochararray(); //$non-nls-1$
char[] desiredassertionstatus = "desiredassertionstatus".tochararray(); //$non-nls-1$
char[] desiredassertionstatussignature = "()z".tochararray(); //$non-nls-1$
char[] getclass = "getclass".tochararray(); //$non-nls-1$
char[] getclasssignature = "()ljava/lang/class;".tochararray(); //$non-nls-1$
char[] getcomponenttype = "getcomponenttype".tochararray(); //$non-nls-1$
char[] getcomponenttypesignature = getclasssignature;
char[] hasnext = "hasnext".tochararray();//$non-nls-1$
char[] hasnextsignature = "()z".tochararray();//$non-nls-1$
char[] next = "next".tochararray();//$non-nls-1$
char[] nextsignature = "()ljava/lang/object;".tochararray();//$non-nls-1$
char[] equals = "equals".tochararray(); //$non-nls-1$
char[] equalssignature = "(ljava/lang/object;)z".tochararray(); //$non-nls-1$
char[] ordinal = "ordinal".tochararray(); //$non-nls-1$
char[] ordinalsignature = "()i".tochararray(); //$non-nls-1$
char[] javalangillegalargumentexceptionconstantpoolname = "java/lang/illegalargumentexception".tochararray(); //$non-nls-1$
char[] arraycopy = "arraycopy".tochararray(); //$non-nls-1$
char[] arraycopysignature = "(ljava/lang/object;iljava/lang/object;ii)v".tochararray(); //$non-nls-1$
char[] javalangstringsignature = "ljava/lang/string;".tochararray(); //$non-nls-1$

// predefined type constant names
char[][] java_lang_reflect_field = new char[][] {typeconstants.java, typeconstants.lang, typeconstants.reflect, "field".tochararray()}; //$non-nls-1$
char[][] java_lang_reflect_accessibleobject = new char[][] {typeconstants.java, typeconstants.lang, typeconstants.reflect, "accessibleobject".tochararray()}; //$non-nls-1$
char[][] java_lang_reflect_method = new char[][] {typeconstants.java, typeconstants.lang, typeconstants.reflect, "method".tochararray()}; //$non-nls-1$
char[][] java_lang_reflect_array = new char[][] {typeconstants.java, typeconstants.lang, typeconstants.reflect, "array".tochararray()}; //$non-nls-1$

// predefined methods constant names
char[] getdeclaredfield_name = "getdeclaredfield".tochararray(); //$non-nls-1$
char[] getdeclaredfield_signature = "(ljava/lang/string;)ljava/lang/reflect/field;".tochararray(); //$non-nls-1$
char[] setaccessible_name = "setaccessible".tochararray(); //$non-nls-1$
char[] setaccessible_signature = "(z)v".tochararray(); //$non-nls-1$
char[] javalangreflectfield_constantpoolname = "java/lang/reflect/field".tochararray(); //$non-nls-1$
char[] javalangreflectaccessibleobject_constantpoolname = "java/lang/reflect/accessibleobject".tochararray(); //$non-nls-1$
char[] javalangreflectarray_constantpoolname = "java/lang/reflect/array".tochararray(); //$non-nls-1$
char[] javalangreflectmethod_constantpoolname = "java/lang/reflect/method".tochararray(); //$non-nls-1$
char[] get_int_method_name = "getint".tochararray(); //$non-nls-1$
char[] get_long_method_name = "getlong".tochararray(); //$non-nls-1$
char[] get_double_method_name = "getdouble".tochararray(); //$non-nls-1$
char[] get_float_method_name = "getfloat".tochararray(); //$non-nls-1$
char[] get_byte_method_name = "getbyte".tochararray(); //$non-nls-1$
char[] get_char_method_name = "getchar".tochararray(); //$non-nls-1$
char[] get_boolean_method_name = "getboolean".tochararray(); //$non-nls-1$
char[] get_object_method_name = "get".tochararray(); //$non-nls-1$
char[] get_short_method_name = "getshort".tochararray(); //$non-nls-1$
char[] array_newinstance_name = "newinstance".tochararray(); //$non-nls-1$
char[] get_int_method_signature = "(ljava/lang/object;)i".tochararray(); //$non-nls-1$
char[] get_long_method_signature = "(ljava/lang/object;)j".tochararray(); //$non-nls-1$
char[] get_double_method_signature = "(ljava/lang/object;)d".tochararray(); //$non-nls-1$
char[] get_float_method_signature = "(ljava/lang/object;)f".tochararray(); //$non-nls-1$
char[] get_byte_method_signature = "(ljava/lang/object;)b".tochararray(); //$non-nls-1$
char[] get_char_method_signature = "(ljava/lang/object;)c".tochararray(); //$non-nls-1$
char[] get_boolean_method_signature = "(ljava/lang/object;)z".tochararray(); //$non-nls-1$
char[] get_object_method_signature = "(ljava/lang/object;)ljava/lang/object;".tochararray(); //$non-nls-1$
char[] get_short_method_signature = "(ljava/lang/object;)s".tochararray(); //$non-nls-1$
char[] set_int_method_name = "setint".tochararray(); //$non-nls-1$
char[] set_long_method_name = "setlong".tochararray(); //$non-nls-1$
char[] set_double_method_name = "setdouble".tochararray(); //$non-nls-1$
char[] set_float_method_name = "setfloat".tochararray(); //$non-nls-1$
char[] set_byte_method_name = "setbyte".tochararray(); //$non-nls-1$
char[] set_char_method_name = "setchar".tochararray(); //$non-nls-1$
char[] set_boolean_method_name = "setboolean".tochararray(); //$non-nls-1$
char[] set_object_method_name = "set".tochararray(); //$non-nls-1$
char[] set_short_method_name = "setshort".tochararray(); //$non-nls-1$
char[] set_int_method_signature = "(ljava/lang/object;i)v".tochararray(); //$non-nls-1$
char[] set_long_method_signature = "(ljava/lang/object;j)v".tochararray(); //$non-nls-1$
char[] set_double_method_signature = "(ljava/lang/object;d)v".tochararray(); //$non-nls-1$
char[] set_float_method_signature = "(ljava/lang/object;f)v".tochararray(); //$non-nls-1$
char[] set_byte_method_signature = "(ljava/lang/object;b)v".tochararray(); //$non-nls-1$
char[] set_char_method_signature = "(ljava/lang/object;c)v".tochararray(); //$non-nls-1$
char[] set_boolean_method_signature = "(ljava/lang/object;z)v".tochararray(); //$non-nls-1$
char[] set_object_method_signature = "(ljava/lang/object;ljava/lang/object;)v".tochararray(); //$non-nls-1$
char[] set_short_method_signature = "(ljava/lang/object;s)v".tochararray(); //$non-nls-1$
char[] getdeclaredmethod_name = "getdeclaredmethod".tochararray(); //$non-nls-1$
char[] getdeclaredmethod_signature = "(ljava/lang/string;[ljava/lang/class;)ljava/lang/reflect/method;".tochararray(); //$non-nls-1$
char[] array_newinstance_signature = "(ljava/lang/class;[i)ljava/lang/object;".tochararray(); //$non-nls-1$
char[] invoke_method_method_name = "invoke".tochararray(); //$non-nls-1$
char[] invoke_method_method_signature = "(ljava/lang/object;[ljava/lang/object;)ljava/lang/object;".tochararray(); //$non-nls-1$
char[] bytevalue_byte_method_name = "bytevalue".tochararray(); //$non-nls-1$
char[] bytevalue_byte_method_signature = "()b".tochararray(); //$non-nls-1$
char[] shortvalue_short_method_name = "shortvalue".tochararray(); //$non-nls-1$
char[] doublevalue_double_method_name = "doublevalue".tochararray(); //$non-nls-1$
char[] floatvalue_float_method_name = "floatvalue".tochararray(); //$non-nls-1$
char[] intvalue_integer_method_name = "intvalue".tochararray(); //$non-nls-1$
char[] charvalue_character_method_name = "charvalue".tochararray(); //$non-nls-1$
char[] booleanvalue_boolean_method_name = "booleanvalue".tochararray(); //$non-nls-1$
char[] longvalue_long_method_name = "longvalue".tochararray(); //$non-nls-1$
char[] shortvalue_short_method_signature = "()s".tochararray(); //$non-nls-1$
char[] doublevalue_double_method_signature = "()d".tochararray(); //$non-nls-1$
char[] floatvalue_float_method_signature = "()f".tochararray(); //$non-nls-1$
char[] intvalue_integer_method_signature = "()i".tochararray(); //$non-nls-1$
char[] charvalue_character_method_signature = "()c".tochararray(); //$non-nls-1$
char[] booleanvalue_boolean_method_signature = "()z".tochararray(); //$non-nls-1$
char[] longvalue_long_method_signature = "()j".tochararray(); //$non-nls-1$
char[] getdeclaredconstructor_name = "getdeclaredconstructor".tochararray(); //$non-nls-1$
char[] getdeclaredconstructor_signature = "([ljava/lang/class;)ljava/lang/reflect/constructor;".tochararray(); //$non-nls-1$
char[] name = "name".tochararray(); //$non-nls-1$
char[] namesignature = "()ljava/lang/string;".tochararray(); //$non-nls-1$
char[] intintegersignature = "(i)ljava/lang/integer;".tochararray(); //$non-nls-1$
char[] bytebytesignature = "(b)ljava/lang/byte;".tochararray(); //$non-nls-1$
char[] shortshortsignature = "(s)ljava/lang/short;".tochararray(); //$non-nls-1$
char[] longlongsignature = "(j)ljava/lang/long;".tochararray(); //$non-nls-1$
char[] doubledoublesignature = "(d)ljava/lang/double;".tochararray(); //$non-nls-1$
char[] floatfloatsignature = "(f)ljava/lang/float;".tochararray(); //$non-nls-1$
char[] booleanbooleansignature = "(z)ljava/lang/boolean;".tochararray(); //$non-nls-1$
char[] charcharactersignature = "(c)ljava/lang/character;".tochararray(); //$non-nls-1$
}@


1.24
log
@autoboxing
