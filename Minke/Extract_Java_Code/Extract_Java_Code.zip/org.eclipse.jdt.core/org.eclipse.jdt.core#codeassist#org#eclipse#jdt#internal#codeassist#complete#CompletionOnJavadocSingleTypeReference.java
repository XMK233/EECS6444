/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.ast.javadocsingletypereference;

public class completiononjavadocsingletypereference extends javadocsingletypereference implements completiononjavadoc {
public int completionflags = javadoc;

public completiononjavadocsingletypereference(char[] source, long pos, int tagstart, int tagend) {
super(source, pos, tagstart, tagend);
}

public completiononjavadocsingletypereference(javadocsingletypereference typeref) {
super(typeref.token, (((long)typeref.sourcestart)<<32)+typeref.sourceend, typeref.tagsourcestart, typeref.tagsourcestart);
}

/**
* @@param flags the completionflags to set.
*/
public void addcompletionflags(int flags) {
this.completionflags |= flags;
}

public boolean completeanexception() {
return (this.completionflags & exception) != 0;
}

public boolean completeintext() {
return (this.completionflags & text) != 0;
}

public boolean completebasetypes() {
return (this.completionflags & base_types) != 0;
}

public boolean completeformalreference() {
return (this.completionflags & formal_reference) != 0;
}

/**
* get completion node flags.
*
* @@return int flags of the javadoc completion node.
*/
public int getcompletionflags() {
return this.completionflags;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.singletypereference#printexpression(int, java.lang.stringbuffer)
*/
public stringbuffer printexpression(int indent, stringbuffer output) {
output.append("<completiononjavadocsingletypereference:"); //$non-nls-1$
super.printexpression(indent, output);
indent++;
if (this.completionflags > 0) {
output.append('\n');
for (int i=0; i<indent; i++) output.append('\t');
output.append("infos:"); //$non-nls-1$
char separator = 0;
if (completeanexception()) {
output.append("exception"); //$non-nls-1$
separator = ',';
}
if (completeintext()) {
if (separator != 0) output.append(separator);
output.append("text"); //$non-nls-1$
separator = ',';
}
if (completebasetypes()) {
if (separator != 0) output.append(separator);
output.append("base types"); //$non-nls-1$
separator = ',';
}
if (completeformalreference()) {
if (separator != 0) output.append(separator);
output.append("formal reference"); //$non-nls-1$
separator = ',';
}
output.append('\n');
}
indent--;
for (int i=0; i<indent; i++) output.append('\t');
return output.append('>');
}
}
