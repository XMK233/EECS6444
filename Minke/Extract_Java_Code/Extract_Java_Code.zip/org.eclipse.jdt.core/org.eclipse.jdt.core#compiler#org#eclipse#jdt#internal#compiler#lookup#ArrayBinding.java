/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.util.list;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.constant;

public final class arraybinding extends typebinding {
// creation and initialization of the length field
// the declaringclass of this field is intentionally set to null so it can be distinguished.
public static final fieldbinding arraylength = new fieldbinding(typeconstants.length, typebinding.int, classfileconstants.accpublic | classfileconstants.accfinal, null, constant.notaconstant);

public typebinding leafcomponenttype;
public int dimensions;
lookupenvironment environment;
char[] constantpoolname;
char[] generictypesignature;

public arraybinding(typebinding type, int dimensions, lookupenvironment environment) {
this.tagbits |= tagbits.isarraytype;
this.leafcomponenttype = type;
this.dimensions = dimensions;
this.environment = environment;
if (type instanceof unresolvedreferencebinding)
((unresolvedreferencebinding) type).addwrapper(this, environment);
else
this.tagbits |= type.tagbits & (tagbits.hastypevariable | tagbits.hasdirectwildcard | tagbits.hasmissingtype | tagbits.containsnestedtypereferences);
}

public typebinding closestmatch() {
if (isvalidbinding()) {
return this;
}
typebinding leafclosestmatch = this.leafcomponenttype.closestmatch();
if (leafclosestmatch == null) {
return null;
}
return this.environment.createarraytype(this.leafcomponenttype.closestmatch(), this.dimensions);
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#collectmissingtypes(java.util.list)
*/
public list collectmissingtypes(list missingtypes) {
if ((this.tagbits & tagbits.hasmissingtype) != 0) {
missingtypes = this.leafcomponenttype.collectmissingtypes(missingtypes);
}
return missingtypes;
}

/**
* collect the substitutes into a map for certain type variables inside the receiver type
* e.g.   collection<t>.collectsubstitutes(collection<list<x>>, map), will populate map with: t --> list<x>
* constraints:
*   a << f   corresponds to:   f.collectsubstitutes(..., a, ..., constraint_extends (1))
*   a = f   corresponds to:      f.collectsubstitutes(..., a, ..., constraint_equal (0))
*   a >> f   corresponds to:   f.collectsubstitutes(..., a, ..., constraint_super (2))
*/
public void collectsubstitutes(scope scope, typebinding actualtype, inferencecontext inferencecontext, int constraint) {

if ((this.tagbits & tagbits.hastypevariable) == 0) return;
if (actualtype == typebinding.null) return;

switch(actualtype.kind()) {
case binding.array_type :
int actualdim = actualtype.dimensions();
if (actualdim == this.dimensions) {
this.leafcomponenttype.collectsubstitutes(scope, actualtype.leafcomponenttype(), inferencecontext, constraint);
} else if (actualdim > this.dimensions) {
arraybinding actualreducedtype = this.environment.createarraytype(actualtype.leafcomponenttype(), actualdim - this.dimensions);
this.leafcomponenttype.collectsubstitutes(scope, actualreducedtype, inferencecontext, constraint);
}
break;
case binding.type_parameter :
//typevariablebinding variable = (typevariablebinding) othertype;
// todo (philippe) should consider array bounds, and recurse
break;
}
}

/*
* brakets leafuniquekey
* p.x[][] --> [[lp/x;
*/
public char[] computeuniquekey(boolean isleaf) {
char[] brackets = new char[this.dimensions];
for (int i = this.dimensions - 1; i >= 0; i--) brackets[i] = '[';
return charoperation.concat(brackets, this.leafcomponenttype.computeuniquekey(isleaf));
}

/**
* answer the receiver's constant pool name.
* note: this method should only be used during/after code gen.
* e.g. '[ljava/lang/object;'
*/
public char[] constantpoolname() {
if (this.constantpoolname != null)
return this.constantpoolname;

char[] brackets = new char[this.dimensions];
for (int i = this.dimensions - 1; i >= 0; i--) brackets[i] = '[';
return this.constantpoolname = charoperation.concat(brackets, this.leafcomponenttype.signature());
}
public string debugname() {
stringbuffer brackets = new stringbuffer(this.dimensions * 2);
for (int i = this.dimensions; --i >= 0;)
brackets.append("[]"); //$non-nls-1$
return this.leafcomponenttype.debugname() + brackets.tostring();
}
public int dimensions() {
return this.dimensions;
}

/* answer an array whose dimension size is one less than the receiver.
*
* when the receiver's dimension size is one then answer the leaf component type.
*/

public typebinding elementstype() {
if (this.dimensions == 1) return this.leafcomponenttype;
return this.environment.createarraytype(this.leafcomponenttype, this.dimensions - 1);
}
/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#erasure()
*/
public typebinding erasure() {
typebinding erasedtype = this.leafcomponenttype.erasure();
if (this.leafcomponenttype != erasedtype)
return this.environment.createarraytype(erasedtype, this.dimensions);
return this;
}
public lookupenvironment environment() {
return this.environment;
}

public char[] generictypesignature() {

if (this.generictypesignature == null) {
char[] brackets = new char[this.dimensions];
for (int i = this.dimensions - 1; i >= 0; i--) brackets[i] = '[';
this.generictypesignature = charoperation.concat(brackets, this.leafcomponenttype.generictypesignature());
}
return this.generictypesignature;
}

public packagebinding getpackage() {
return this.leafcomponenttype.getpackage();
}

public int hashcode() {
return this.leafcomponenttype == null ? super.hashcode() : this.leafcomponenttype.hashcode();
}

/* answer true if the receiver type can be assigned to the argument type (right)
*/
public boolean iscompatiblewith(typebinding othertype) {
if (this == othertype)
return true;

switch (othertype.kind()) {
case binding.array_type :
arraybinding otherarray = (arraybinding) othertype;
if (otherarray.leafcomponenttype.isbasetype())
return false; // relying on the fact that all equal arrays are identical
if (this.dimensions == otherarray.dimensions)
return this.leafcomponenttype.iscompatiblewith(otherarray.leafcomponenttype);
if (this.dimensions < otherarray.dimensions)
return false; // cannot assign 'string[]' into 'object[][]' but can assign 'byte[][]' into 'object[]'
break;
case binding.base_type :
return false;
case binding.wildcard_type :
case binding.intersection_type :
return ((wildcardbinding) othertype).boundcheck(this);

case binding.type_parameter :
// check compatibility with capture of ? super x
if (othertype.iscapture()) {
capturebinding othercapture = (capturebinding) othertype;
typebinding otherlowerbound;
if ((otherlowerbound = othercapture.lowerbound) != null) {
if (!otherlowerbound.isarraytype()) return false;
return iscompatiblewith(otherlowerbound);
}
}
return false;

}
//check dimensions - java does not support explicitly sized dimensions for types.
//however, if it did, the type checking support would go here.
switch (othertype.leafcomponenttype().id) {
case typeids.t_javalangobject :
case typeids.t_javalangcloneable :
case typeids.t_javaioserializable :
return true;
}
return false;
}

public int kind() {
return array_type;
}

public typebinding leafcomponenttype(){
return this.leafcomponenttype;
}

/* api
* answer the problem id associated with the receiver.
* noerror if the receiver is a valid binding.
*/
public int problemid() {
return this.leafcomponenttype.problemid();
}
/**
* answer the source name for the type.
* in the case of member types, as the qualified name from its top level type.
* for example, for a member type n defined inside m & a: "a.m.n".
*/

public char[] qualifiedsourcename() {
char[] brackets = new char[this.dimensions * 2];
for (int i = this.dimensions * 2 - 1; i >= 0; i -= 2) {
brackets[i] = ']';
brackets[i - 1] = '[';
}
return charoperation.concat(this.leafcomponenttype.qualifiedsourcename(), brackets);
}
public char[] readablename() /* java.lang.object[] */ {
char[] brackets = new char[this.dimensions * 2];
for (int i = this.dimensions * 2 - 1; i >= 0; i -= 2) {
brackets[i] = ']';
brackets[i - 1] = '[';
}
return charoperation.concat(this.leafcomponenttype.readablename(), brackets);
}
public char[] shortreadablename(){
char[] brackets = new char[this.dimensions * 2];
for (int i = this.dimensions * 2 - 1; i >= 0; i -= 2) {
brackets[i] = ']';
brackets[i - 1] = '[';
}
return charoperation.concat(this.leafcomponenttype.shortreadablename(), brackets);
}
public char[] sourcename() {
char[] brackets = new char[this.dimensions * 2];
for (int i = this.dimensions * 2 - 1; i >= 0; i -= 2) {
brackets[i] = ']';
brackets[i - 1] = '[';
}
return charoperation.concat(this.leafcomponenttype.sourcename(), brackets);
}
public void swapunresolved(unresolvedreferencebinding unresolvedtype, referencebinding resolvedtype, lookupenvironment env) {
if (this.leafcomponenttype == unresolvedtype) {
this.leafcomponenttype = env.convertunresolvedbinarytorawtype(resolvedtype);
this.tagbits |= this.leafcomponenttype.tagbits & (tagbits.hastypevariable | tagbits.hasdirectwildcard | tagbits.hasmissingtype);
}
}
public string tostring() {
return this.leafcomponenttype != null ? debugname() : "null type array"; //$non-nls-1$
}
}
