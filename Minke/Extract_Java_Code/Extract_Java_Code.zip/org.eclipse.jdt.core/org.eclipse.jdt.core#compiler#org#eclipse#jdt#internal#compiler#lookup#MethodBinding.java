/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.util.list;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.classfile;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.argument;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.constantpool;
import org.eclipse.jdt.internal.compiler.util.util;

public class methodbinding extends binding {

public int modifiers;
public char[] selector;
public typebinding returntype;
public typebinding[] parameters;
public referencebinding[] thrownexceptions;
public referencebinding declaringclass;
public typevariablebinding[] typevariables = binding.no_type_variables;
char[] signature;
public long tagbits;

protected methodbinding() {
// for creating problem or synthetic method
}
public methodbinding(int modifiers, char[] selector, typebinding returntype, typebinding[] parameters, referencebinding[] thrownexceptions, referencebinding declaringclass) {
this.modifiers = modifiers;
this.selector = selector;
this.returntype = returntype;
this.parameters = (parameters == null || parameters.length == 0) ? binding.no_parameters : parameters;
this.thrownexceptions = (thrownexceptions == null || thrownexceptions.length == 0) ? binding.no_exceptions : thrownexceptions;
this.declaringclass = declaringclass;

// propagate the strictfp & deprecated modifiers
if (this.declaringclass != null) {
if (this.declaringclass.isstrictfp())
if (!(isnative() || isabstract()))
this.modifiers |= classfileconstants.accstrictfp;
}
}
public methodbinding(int modifiers, typebinding[] parameters, referencebinding[] thrownexceptions, referencebinding declaringclass) {
this(modifiers, typeconstants.init, typebinding.void, parameters, thrownexceptions, declaringclass);
}
// special api used to change method declaring class for runtime visibility check
public methodbinding(methodbinding initialmethodbinding, referencebinding declaringclass) {
this.modifiers = initialmethodbinding.modifiers;
this.selector = initialmethodbinding.selector;
this.returntype = initialmethodbinding.returntype;
this.parameters = initialmethodbinding.parameters;
this.thrownexceptions = initialmethodbinding.thrownexceptions;
this.declaringclass = declaringclass;
declaringclass.storeannotationholder(this, initialmethodbinding.declaringclass.retrieveannotationholder(initialmethodbinding, true));
}
/* answer true if the argument types & the receiver's parameters have the same erasure
*/
public final boolean areparametererasuresequal(methodbinding method) {
typebinding[] args = method.parameters;
if (this.parameters == args)
return true;

int length = this.parameters.length;
if (length != args.length)
return false;

for (int i = 0; i < length; i++)
if (this.parameters[i] != args[i] && this.parameters[i].erasure() != args[i].erasure())
return false;
return true;
}
/*
* returns true if given parameters are compatible with this method parameters.
* callers to this method should first check that the number of typebindings
* passed as argument matches this methodbinding number of parameters
*/
public final boolean areparameterscompatiblewith(typebinding[] arguments) {
int paramlength = this.parameters.length;
int arglength = arguments.length;
int lastindex = arglength;
if (isvarargs()) {
lastindex = paramlength - 1;
if (paramlength == arglength) { // accept x[] but not x or x[][]
typebinding varargtype = this.parameters[lastindex]; // is an arraybinding by definition
typebinding lastargument = arguments[lastindex];
if (varargtype != lastargument && !lastargument.iscompatiblewith(varargtype))
return false;
} else if (paramlength < arglength) { // all remainig argument types must be compatible with the elementstype of varargtype
typebinding varargtype = ((arraybinding) this.parameters[lastindex]).elementstype();
for (int i = lastindex; i < arglength; i++)
if (varargtype != arguments[i] && !arguments[i].iscompatiblewith(varargtype))
return false;
} else if (lastindex != arglength) { // can call foo(int i, x ... x) with foo(1) but not foo();
return false;
}
// now compare standard arguments from 0 to lastindex
}
for (int i = 0; i < lastindex; i++)
if (this.parameters[i] != arguments[i] && !arguments[i].iscompatiblewith(this.parameters[i]))
return false;
return true;
}
/* answer true if the argument types & the receiver's parameters are equal
*/
public final boolean areparametersequal(methodbinding method) {
typebinding[] args = method.parameters;
if (this.parameters == args)
return true;

int length = this.parameters.length;
if (length != args.length)
return false;

for (int i = 0; i < length; i++)
if (this.parameters[i] != args[i])
return false;
return true;
}

/* api
* answer the receiver's binding type from binding.bindingid.
*/

/* answer true if the type variables have the same erasure
*/
public final boolean aretypevariableerasuresequal(methodbinding method) {
typevariablebinding[] vars = method.typevariables;
if (this.typevariables == vars)
return true;

int length = this.typevariables.length;
if (length != vars.length)
return false;

for (int i = 0; i < length; i++)
if (this.typevariables[i] != vars[i] && this.typevariables[i].erasure() != vars[i].erasure())
return false;
return true;
}
methodbinding asrawmethod(lookupenvironment env) {
if (this.typevariables == binding.no_type_variables) return this;

// substitute type arguments with raw types
int length = this.typevariables.length;
typebinding[] arguments = new typebinding[length];
for (int i = 0; i < length; i++) {
typevariablebinding var = this.typevariables[i];
if (var.boundscount() <= 1) {
arguments[i] = env.converttorawtype(var.upperbound(), false /*do not force conversion of enclosing types*/);
} else {
// use an intersection type to retain full bound information if more than 1 bound
typebinding[] itssuperinterfaces = var.superinterfaces();
int superlength = itssuperinterfaces.length;
typebinding rawfirstbound = null;
typebinding[] rawotherbounds = null;
if (var.boundscount() == superlength) {
rawfirstbound = env.converttorawtype(itssuperinterfaces[0], false);
rawotherbounds = new typebinding[superlength - 1];
for (int s = 1; s < superlength; s++)
rawotherbounds[s - 1] = env.converttorawtype(itssuperinterfaces[s], false);
} else {
rawfirstbound = env.converttorawtype(var.superclass(), false);
rawotherbounds = new typebinding[superlength];
for (int s = 0; s < superlength; s++)
rawotherbounds[s] = env.converttorawtype(itssuperinterfaces[s], false);
}
arguments[i] = env.createwildcard(null, 0, rawfirstbound, rawotherbounds, org.eclipse.jdt.internal.compiler.ast.wildcard.extends);
}
}
return env.createparameterizedgenericmethod(this, arguments);
}
/* answer true if the receiver is visible to the type provided by the scope.
* invocationsite implements issuperaccess() to provide additional information
* if the receiver is protected.
*
* note: this method should only be sent if the receiver is a constructor.
*
* note: cannot invoke this method with a compilation unit scope.
*/

public final boolean canbeseenby(invocationsite invocationsite, scope scope) {
if (ispublic()) return true;

sourcetypebinding invocationtype = scope.enclosingsourcetype();
if (invocationtype == this.declaringclass) return true;

if (isprotected()) {
// answer true if the receiver is in the same package as the invocationtype
if (invocationtype.fpackage == this.declaringclass.fpackage) return true;
return invocationsite.issuperaccess();
}

if (isprivate()) {
// answer true if the invocationtype and the declaringclass have a common enclosingtype
// already know they are not the identical type
referencebinding outerinvocationtype = invocationtype;
referencebinding temp = outerinvocationtype.enclosingtype();
while (temp != null) {
outerinvocationtype = temp;
temp = temp.enclosingtype();
}

referencebinding outerdeclaringclass = (referencebinding)this.declaringclass.erasure();
temp = outerdeclaringclass.enclosingtype();
while (temp != null) {
outerdeclaringclass = temp;
temp = temp.enclosingtype();
}
return outerinvocationtype == outerdeclaringclass;
}

// isdefault()
return invocationtype.fpackage == this.declaringclass.fpackage;
}
public final boolean canbeseenby(packagebinding invocationpackage) {
if (ispublic()) return true;
if (isprivate()) return false;

// isprotected() or isdefault()
return invocationpackage == this.declaringclass.getpackage();
}

/* answer true if the receiver is visible to the type provided by the scope.
* invocationsite implements issuperaccess() to provide additional information
* if the receiver is protected.
*
* note: cannot invoke this method with a compilation unit scope.
*/
public final boolean canbeseenby(typebinding receivertype, invocationsite invocationsite, scope scope) {
if (ispublic()) return true;

sourcetypebinding invocationtype = scope.enclosingsourcetype();
if (invocationtype == this.declaringclass && invocationtype == receivertype) return true;

if (invocationtype == null) // static import call
return !isprivate() && scope.getcurrentpackage() == this.declaringclass.fpackage;

if (isprotected()) {
// answer true if the invocationtype is the declaringclass or they are in the same package
// or the invocationtype is a subclass of the declaringclass
//    and the receivertype is the invocationtype or its subclass
//    or the method is a static method accessed directly through a type
//    or previous assertions are true for one of the enclosing type
if (invocationtype == this.declaringclass) return true;
if (invocationtype.fpackage == this.declaringclass.fpackage) return true;

referencebinding currenttype = invocationtype;
typebinding receivererasure = receivertype.erasure();
referencebinding declaringerasure = (referencebinding) this.declaringclass.erasure();
int depth = 0;
do {
if (currenttype.findsupertypeoriginatingfrom(declaringerasure) != null) {
if (invocationsite.issuperaccess())
return true;
// receivertype can be an array binding in one case... see if you can change it
if (receivertype instanceof arraybinding)
return false;
if (isstatic()) {
if (depth > 0) invocationsite.setdepth(depth);
return true; // see 1fmepdl - return invocationsite.istypeaccess();
}
if (currenttype == receivererasure || receivererasure.findsupertypeoriginatingfrom(currenttype) != null) {
if (depth > 0) invocationsite.setdepth(depth);
return true;
}
}
depth++;
currenttype = currenttype.enclosingtype();
} while (currenttype != null);
return false;
}

if (isprivate()) {
// answer true if the receivertype is the declaringclass
// and the invocationtype and the declaringclass have a common enclosingtype
receivercheck: {
if (receivertype != this.declaringclass) {
// special tolerance for type variable direct bounds
if (receivertype.istypevariable() && ((typevariablebinding) receivertype).iserasureboundto(this.declaringclass.erasure()))
break receivercheck;
return false;
}
}

if (invocationtype != this.declaringclass) {
referencebinding outerinvocationtype = invocationtype;
referencebinding temp = outerinvocationtype.enclosingtype();
while (temp != null) {
outerinvocationtype = temp;
temp = temp.enclosingtype();
}

referencebinding outerdeclaringclass = (referencebinding)this.declaringclass.erasure();
temp = outerdeclaringclass.enclosingtype();
while (temp != null) {
outerdeclaringclass = temp;
temp = temp.enclosingtype();
}
if (outerinvocationtype != outerdeclaringclass) return false;
}
return true;
}

// isdefault()
packagebinding declaringpackage = this.declaringclass.fpackage;
if (invocationtype.fpackage != declaringpackage) return false;

// receivertype can be an array binding in one case... see if you can change it
if (receivertype instanceof arraybinding)
return false;
typebinding originaldeclaringclass = this.declaringclass.original();
referencebinding currenttype = (referencebinding) (receivertype);
do {
if (currenttype.iscapture()) { // https://bugs.eclipse.org/bugs/show_bug.cgi?id=285002
if (originaldeclaringclass == currenttype.erasure().original()) return true;
} else {
if (originaldeclaringclass == currenttype.original()) return true;
}
packagebinding currentpackage = currenttype.fpackage;
// package could be null for wildcards/intersection types, ignore and recurse in superclass
if (currentpackage != null && currentpackage != declaringpackage) return false;
} while ((currenttype = currenttype.superclass()) != null);
return false;
}

public list collectmissingtypes(list missingtypes) {
if ((this.tagbits & tagbits.hasmissingtype) != 0) {
missingtypes = this.returntype.collectmissingtypes(missingtypes);
for (int i = 0, max = this.parameters.length; i < max; i++) {
missingtypes = this.parameters[i].collectmissingtypes(missingtypes);
}
for (int i = 0, max = this.thrownexceptions.length; i < max; i++) {
missingtypes = this.thrownexceptions[i].collectmissingtypes(missingtypes);
}
for (int i = 0, max = this.typevariables.length; i < max; i++) {
typevariablebinding variable = this.typevariables[i];
missingtypes = variable.superclass().collectmissingtypes(missingtypes);
referencebinding[] interfaces = variable.superinterfaces();
for (int j = 0, length = interfaces.length; j < length; j++) {
missingtypes = interfaces[j].collectmissingtypes(missingtypes);
}
}
}
if (missingtypes == null) {
system.err.println("could not find missing types in " + this); //$non-nls-1$
}
return missingtypes;
}

methodbinding computesubstitutedmethod(methodbinding method, lookupenvironment env) {
int length = this.typevariables.length;
typevariablebinding[] vars = method.typevariables;
if (length != vars.length)
return null;

// must substitute to detect cases like:
//   <t1 extends x<t1>> void dup() {}
//   <t2 extends x<t2>> object dup() {return null;}
parameterizedgenericmethodbinding substitute =
env.createparameterizedgenericmethod(method, this.typevariables);
for (int i = 0; i < length; i++)
if (!this.typevariables[i].isinterchangeablewith(vars[i], substitute))
return null;
return substitute;
}

/*
* declaringuniquekey dot selector genericsignature
* p.x { <t> void bar(x<t> t) } --> lp/x;.bar<t:ljava/lang/object;>(lx<tt;>;)v
*/
public char[] computeuniquekey(boolean isleaf) {
// declaring class
char[] declaringkey = this.declaringclass.computeuniquekey(false/*not a leaf*/);
int declaringlength = declaringkey.length;

// selector
int selectorlength = this.selector == typeconstants.init ? 0 : this.selector.length;

// generic signature
char[] sig = genericsignature();
boolean isgeneric = sig != null;
if (!isgeneric) sig = signature();
int signaturelength = sig.length;

// thrown exceptions
int thrownexceptionslength = this.thrownexceptions.length;
int thrownexceptionssignaturelength = 0;
char[][] thrownexceptionssignatures = null;
boolean addthrownexceptions = thrownexceptionslength > 0 && (!isgeneric || charoperation.lastindexof('^', sig) < 0);
if (addthrownexceptions) {
thrownexceptionssignatures = new char[thrownexceptionslength][];
for (int i = 0; i < thrownexceptionslength; i++) {
if (this.thrownexceptions[i] != null) {
thrownexceptionssignatures[i] = this.thrownexceptions[i].signature();
thrownexceptionssignaturelength += thrownexceptionssignatures[i].length + 1;	// add one char for separator
}
}
}

char[] uniquekey = new char[declaringlength + 1 + selectorlength + signaturelength + thrownexceptionssignaturelength];
int index = 0;
system.arraycopy(declaringkey, 0, uniquekey, index, declaringlength);
index = declaringlength;
uniquekey[index++] = '.';
system.arraycopy(this.selector, 0, uniquekey, index, selectorlength);
index += selectorlength;
system.arraycopy(sig, 0, uniquekey, index, signaturelength);
if (thrownexceptionssignaturelength > 0) {
index += signaturelength;
for (int i = 0; i < thrownexceptionslength; i++) {
char[] thrownexceptionsignature = thrownexceptionssignatures[i];
if (thrownexceptionsignature != null) {
uniquekey[index++] = '|';
int length = thrownexceptionsignature.length;
system.arraycopy(thrownexceptionsignature, 0, uniquekey, index, length);
index += length;
}
}
}
return uniquekey;
}

/* answer the receiver's constant pool name.
*
* <init> for constructors
* <clinit> for clinit methods
* or the source name of the method
*/
public final char[] constantpoolname() {
return this.selector;
}

public methodbinding findoriginalinheritedmethod(methodbinding inheritedmethod) {
methodbinding inheritedoriginal = inheritedmethod.original();
typebinding supertype = this.declaringclass.findsupertypeoriginatingfrom(inheritedoriginal.declaringclass);
if (supertype == null || !(supertype instanceof referencebinding)) return null;

if (inheritedoriginal.declaringclass != supertype) {
// must find inherited method with the same substituted variables
methodbinding[] supermethods = ((referencebinding) supertype).getmethods(inheritedoriginal.selector, inheritedoriginal.parameters.length);
for (int m = 0, l = supermethods.length; m < l; m++)
if (supermethods[m].original() == inheritedoriginal)
return supermethods[m];
}
return inheritedoriginal;
}

/**
* <pre>
*<typeparam1 ... typeparamm>(param1 ... paramn)returntype thrownexception1 ... thrownexceptionp
* t foo(t t) throws x<t>   --->   (tt;)tt;lx<tt;>;
* void bar(x<t> t)   -->   (lx<tt;>;)v
* <t> void bar(x<t> t)   -->  <t:ljava.lang.object;>(lx<tt;>;)v
* </pre>
*/
public char[] genericsignature() {
if ((this.modifiers & extracompilermodifiers.accgenericsignature) == 0) return null;
stringbuffer sig = new stringbuffer(10);
if (this.typevariables != binding.no_type_variables) {
sig.append('<');
for (int i = 0, length = this.typevariables.length; i < length; i++) {
sig.append(this.typevariables[i].genericsignature());
}
sig.append('>');
}
sig.append('(');
for (int i = 0, length = this.parameters.length; i < length; i++) {
sig.append(this.parameters[i].generictypesignature());
}
sig.append(')');
if (this.returntype != null)
sig.append(this.returntype.generictypesignature());

// only append thrown exceptions if any is generic/parameterized
boolean needexceptionsignatures = false;
int length = this.thrownexceptions.length;
for (int i = 0; i < length; i++) {
if((this.thrownexceptions[i].modifiers & extracompilermodifiers.accgenericsignature) != 0) {
needexceptionsignatures = true;
break;
}
}
if (needexceptionsignatures) {
for (int i = 0; i < length; i++) {
sig.append('^');
sig.append(this.thrownexceptions[i].generictypesignature());
}
}
int siglength = sig.length();
char[] genericsignature = new char[siglength];
sig.getchars(0, siglength, genericsignature, 0);
return genericsignature;
}

public final int getaccessflags() {
return this.modifiers & extracompilermodifiers.accjustflag;
}

public annotationbinding[] getannotations() {
methodbinding originalmethod = original();
return originalmethod.declaringclass.retrieveannotations(originalmethod);
}

/**
* compute the tagbits for standard annotations. for source types, these could require
* lazily resolving corresponding annotation nodes, in case of forward references.
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#getannotationtagbits()
*/
public long getannotationtagbits() {
methodbinding originalmethod = original();
if ((originalmethod.tagbits & tagbits.annotationresolved) == 0 && originalmethod.declaringclass instanceof sourcetypebinding) {
classscope scope = ((sourcetypebinding) originalmethod.declaringclass).scope;
if (scope != null) {
typedeclaration typedecl = scope.referencecontext;
abstractmethoddeclaration methoddecl = typedecl.declarationof(originalmethod);
if (methoddecl != null)
astnode.resolveannotations(methoddecl.scope, methoddecl.annotations, originalmethod);
}
}
return originalmethod.tagbits;
}

/**
* @@return the default value for this annotation method or <code>null</code> if there is no default value
*/
public object getdefaultvalue() {
methodbinding originalmethod = original();
if ((originalmethod.tagbits & tagbits.defaultvalueresolved) == 0) {
//the method has not been resolved nor has its class been resolved.
//it can only be from a source type within compilation units to process.
if (originalmethod.declaringclass instanceof sourcetypebinding) {
sourcetypebinding sourcetype = (sourcetypebinding) originalmethod.declaringclass;
if (sourcetype.scope != null) {
abstractmethoddeclaration methoddeclaration = originalmethod.sourcemethod();
if (methoddeclaration != null && methoddeclaration.isannotationmethod()) {
methoddeclaration.resolve(sourcetype.scope);
}
}
}
originalmethod.tagbits |= tagbits.defaultvalueresolved;
}
annotationholder holder = originalmethod.declaringclass.retrieveannotationholder(originalmethod, true);
return holder == null ? null : holder.getdefaultvalue();
}

/**
* @@return the annotations for each of the method parameters or <code>null></code>
* 	if there's no parameter or no annotation at all.
*/
public annotationbinding[][] getparameterannotations() {
int length;
if ((length = this.parameters.length) == 0) {
return null;
}
methodbinding originalmethod = original();
annotationholder holder = originalmethod.declaringclass.retrieveannotationholder(originalmethod, true);
annotationbinding[][] allparameterannotations = holder == null ? null : holder.getparameterannotations();
if (allparameterannotations == null && (this.tagbits & tagbits.hasparameterannotations) != 0) {
allparameterannotations = new annotationbinding[length][];
// forward reference to method, where param annotations have not yet been associated to method
if (this.declaringclass instanceof sourcetypebinding) {
sourcetypebinding sourcetype = (sourcetypebinding) this.declaringclass;
if (sourcetype.scope != null) {
abstractmethoddeclaration methoddecl = sourcetype.scope.referencetype().declarationof(this);
for (int i = 0; i < length; i++) {
argument argument = methoddecl.arguments[i];
if (argument.annotations != null) {
astnode.resolveannotations(methoddecl.scope, argument.annotations, argument.binding);
allparameterannotations[i] = argument.binding.getannotations();
} else {
allparameterannotations[i] = binding.no_annotations;
}
}
} else {
for (int i = 0; i < length; i++) {
allparameterannotations[i] = binding.no_annotations;
}
}
} else {
for (int i = 0; i < length; i++) {
allparameterannotations[i] = binding.no_annotations;
}
}
setparameterannotations(allparameterannotations);
}
return allparameterannotations;
}

public typevariablebinding gettypevariable(char[] variablename) {
for (int i = this.typevariables.length; --i >= 0;)
if (charoperation.equals(this.typevariables[i].sourcename, variablename))
return this.typevariables[i];
return null;
}

/**
* returns true if method got substituted parameter types
* (see parameterizedmethodbinding)
*/
public boolean hassubstitutedparameters() {
return false;
}

/* answer true if the return type got substituted.
*/
public boolean hassubstitutedreturntype() {
return false;
}

/* answer true if the receiver is an abstract method
*/
public final boolean isabstract() {
return (this.modifiers & classfileconstants.accabstract) != 0;
}

/* answer true if the receiver is a bridge method
*/
public final boolean isbridge() {
return (this.modifiers & classfileconstants.accbridge) != 0;
}

/* answer true if the receiver is a constructor
*/
public final boolean isconstructor() {
return this.selector == typeconstants.init;
}

/* answer true if the receiver has default visibility
*/
public final boolean isdefault() {
return !ispublic() && !isprotected() && !isprivate();
}

/* answer true if the receiver is a system generated default abstract method
*/
public final boolean isdefaultabstract() {
return (this.modifiers & extracompilermodifiers.accdefaultabstract) != 0;
}

/* answer true if the receiver is a deprecated method
*/
public final boolean isdeprecated() {
return (this.modifiers & classfileconstants.accdeprecated) != 0;
}

/* answer true if the receiver is final and cannot be overridden
*/
public final boolean isfinal() {
return (this.modifiers & classfileconstants.accfinal) != 0;
}

/* answer true if the receiver is implementing another method
* in other words, it is overriding and concrete, and overriden method is abstract
* only set for source methods
*/
public final boolean isimplementing() {
return (this.modifiers & extracompilermodifiers.accimplementing) != 0;
}

/*
* answer true if the receiver is a "public static void main(string[])" method
*/
public final boolean ismain() {
if (this.selector.length == 4 && charoperation.equals(this.selector, typeconstants.main)
&& ((this.modifiers & (classfileconstants.accpublic | classfileconstants.accstatic)) != 0)
&& typebinding.void == this.returntype
&& this.parameters.length == 1) {
typebinding paramtype = this.parameters[0];
if (paramtype.dimensions() == 1 && paramtype.leafcomponenttype().id == typeids.t_javalangstring) {
return true;
}
}
return false;
}

/* answer true if the receiver is a native method
*/
public final boolean isnative() {
return (this.modifiers & classfileconstants.accnative) != 0;
}

/* answer true if the receiver is overriding another method
* only set for source methods
*/
public final boolean isoverriding() {
return (this.modifiers & extracompilermodifiers.accoverriding) != 0;
}
/* answer true if the receiver has private visibility
*/
public final boolean isprivate() {
return (this.modifiers & classfileconstants.accprivate) != 0;
}

/* answer true if the receiver has private visibility or if any of its enclosing types do.
*/
public final boolean isorenclosedbyprivatetype() {
if ((this.modifiers & classfileconstants.accprivate) != 0)
return true;
return this.declaringclass != null && this.declaringclass.isorenclosedbyprivatetype();
}

/* answer true if the receiver has protected visibility
*/
public final boolean isprotected() {
return (this.modifiers & classfileconstants.accprotected) != 0;
}

/* answer true if the receiver has public visibility
*/
public final boolean ispublic() {
return (this.modifiers & classfileconstants.accpublic) != 0;
}

/* answer true if the receiver is a static method
*/
public final boolean isstatic() {
return (this.modifiers & classfileconstants.accstatic) != 0;
}

/* answer true if all float operations must adher to ieee 754 float/double rules
*/
public final boolean isstrictfp() {
return (this.modifiers & classfileconstants.accstrictfp) != 0;
}

/* answer true if the receiver is a synchronized method
*/
public final boolean issynchronized() {
return (this.modifiers & classfileconstants.accsynchronized) != 0;
}

/* answer true if the receiver has public visibility
*/
public final boolean issynthetic() {
return (this.modifiers & classfileconstants.accsynthetic) != 0;
}

/* answer true if the receiver has private visibility and is used locally
*/
public final boolean isused() {
return (this.modifiers & extracompilermodifiers.acclocallyused) != 0;
}

/* answer true if the receiver method has varargs
*/
public final boolean isvarargs() {
return (this.modifiers & classfileconstants.accvarargs) != 0;
}

/* answer true if the receiver's declaring type is deprecated (or any of its enclosing types)
*/
public final boolean isviewedasdeprecated() {
return (this.modifiers & (classfileconstants.accdeprecated | extracompilermodifiers.accdeprecatedimplicitly)) != 0;
}

public final int kind() {
return binding.method;
}
/* answer true if the receiver is visible to the invocationpackage.
*/

/**
* returns the original method (as opposed to parameterized instances)
*/
public methodbinding original() {
return this;
}

public char[] readablename() /* foo(int, thread) */ {
stringbuffer buffer = new stringbuffer(this.parameters.length + 1 * 20);
if (isconstructor())
buffer.append(this.declaringclass.sourcename());
else
buffer.append(this.selector);
buffer.append('(');
if (this.parameters != binding.no_parameters) {
for (int i = 0, length = this.parameters.length; i < length; i++) {
if (i > 0)
buffer.append(", "); //$non-nls-1$
buffer.append(this.parameters[i].sourcename());
}
}
buffer.append(')');
return buffer.tostring().tochararray();
}
public void setannotations(annotationbinding[] annotations) {
this.declaringclass.storeannotations(this, annotations);
}
public void setannotations(annotationbinding[] annotations, annotationbinding[][] parameterannotations, object defaultvalue, lookupenvironment optionalenv) {
this.declaringclass.storeannotationholder(this,  annotationholder.storeannotations(annotations, parameterannotations, defaultvalue, optionalenv));
}
public void setdefaultvalue(object defaultvalue) {
methodbinding originalmethod = original();
originalmethod.tagbits |= tagbits.defaultvalueresolved;

annotationholder holder = this.declaringclass.retrieveannotationholder(this, false);
if (holder == null)
setannotations(null, null, defaultvalue, null);
else
setannotations(holder.getannotations(), holder.getparameterannotations(), defaultvalue, null);
}
public void setparameterannotations(annotationbinding[][] parameterannotations) {
annotationholder holder = this.declaringclass.retrieveannotationholder(this, false);
if (holder == null)
setannotations(null, parameterannotations, null, null);
else
setannotations(holder.getannotations(), parameterannotations, holder.getdefaultvalue(), null);
}
protected final void setselector(char[] selector) {
this.selector = selector;
this.signature = null;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#shortreadablename()
*/
public char[] shortreadablename() {
stringbuffer buffer = new stringbuffer(this.parameters.length + 1 * 20);
if (isconstructor())
buffer.append(this.declaringclass.shortreadablename());
else
buffer.append(this.selector);
buffer.append('(');
if (this.parameters != binding.no_parameters) {
for (int i = 0, length = this.parameters.length; i < length; i++) {
if (i > 0)
buffer.append(", "); //$non-nls-1$
buffer.append(this.parameters[i].shortreadablename());
}
}
buffer.append(')');
int namelength = buffer.length();
char[] shortreadablename = new char[namelength];
buffer.getchars(0, namelength, shortreadablename, 0);
return shortreadablename;
}

/* answer the receiver's signature.
*
* note: this method should only be used during/after code gen.
* the signature is cached so if the signature of the return type or any parameter
* type changes, the cached state is invalid.
*/
public final char[] signature() /* (iljava/lang/thread;)ljava/lang/object; */ {
if (this.signature != null)
return this.signature;

stringbuffer buffer = new stringbuffer(this.parameters.length + 1 * 20);
buffer.append('(');

typebinding[] targetparameters = this.parameters;
boolean isconstructor = isconstructor();
if (isconstructor && this.declaringclass.isenum()) { // insert string name,int ordinal
buffer.append(constantpool.javalangstringsignature);
buffer.append(typebinding.int.signature());
}
boolean needsynthetics = isconstructor && this.declaringclass.isnestedtype();
if (needsynthetics) {
// take into account the synthetic argument type signatures as well
referencebinding[] syntheticargumenttypes = this.declaringclass.syntheticenclosinginstancetypes();
if (syntheticargumenttypes != null) {
for (int i = 0, count = syntheticargumenttypes.length; i < count; i++) {
buffer.append(syntheticargumenttypes[i].signature());
}
}

if (this instanceof syntheticmethodbinding) {
targetparameters = ((syntheticmethodbinding)this).targetmethod.parameters;
}
}

if (targetparameters != binding.no_parameters) {
for (int i = 0; i < targetparameters.length; i++) {
buffer.append(targetparameters[i].signature());
}
}
if (needsynthetics) {
syntheticargumentbinding[] syntheticouterarguments = this.declaringclass.syntheticouterlocalvariables();
int count = syntheticouterarguments == null ? 0 : syntheticouterarguments.length;
for (int i = 0; i < count; i++) {
buffer.append(syntheticouterarguments[i].type.signature());
}
// move the extra padding arguments of the synthetic constructor invocation to the end
for (int i = targetparameters.length, extralength = this.parameters.length; i < extralength; i++) {
buffer.append(this.parameters[i].signature());
}
}
buffer.append(')');
if (this.returntype != null)
buffer.append(this.returntype.signature());
int namelength = buffer.length();
this.signature = new char[namelength];
buffer.getchars(0, namelength, this.signature, 0);

return this.signature;
}
/*
* this method is used to record references to nested types inside the method signature.
* this is the one that must be used during code generation.
*
* see https://bugs.eclipse.org/bugs/show_bug.cgi?id=171184
*/
public final char[] signature(classfile classfile) {
if (this.signature != null) {
if ((this.tagbits & tagbits.containsnestedtypereferences) != 0) {
// we need to record inner classes references
boolean isconstructor = isconstructor();
typebinding[] targetparameters = this.parameters;
boolean needsynthetics = isconstructor && this.declaringclass.isnestedtype();
if (needsynthetics) {
// take into account the synthetic argument type signatures as well
referencebinding[] syntheticargumenttypes = this.declaringclass.syntheticenclosinginstancetypes();
if (syntheticargumenttypes != null) {
for (int i = 0, count = syntheticargumenttypes.length; i < count; i++) {
referencebinding syntheticargumenttype = syntheticargumenttypes[i];
if ((syntheticargumenttype.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(classfile, syntheticargumenttype);
}
}
}
if (this instanceof syntheticmethodbinding) {
targetparameters = ((syntheticmethodbinding)this).targetmethod.parameters;
}
}

if (targetparameters != binding.no_parameters) {
for (int i = 0, max = targetparameters.length; i < max; i++) {
typebinding targetparameter = targetparameters[i];
typebinding leaftargetparametertype = targetparameter.leafcomponenttype();
if ((leaftargetparametertype.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(classfile, leaftargetparametertype);
}
}
}
if (needsynthetics) {
// move the extra padding arguments of the synthetic constructor invocation to the end
for (int i = targetparameters.length, extralength = this.parameters.length; i < extralength; i++) {
typebinding parameter = this.parameters[i];
typebinding leafparametertype = parameter.leafcomponenttype();
if ((leafparametertype.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(classfile, leafparametertype);
}
}
}
if (this.returntype != null) {
typebinding ret = this.returntype.leafcomponenttype();
if ((ret.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(classfile, ret);
}
}
}
return this.signature;
}

stringbuffer buffer = new stringbuffer(this.parameters.length + 1 * 20);
buffer.append('(');

typebinding[] targetparameters = this.parameters;
boolean isconstructor = isconstructor();
if (isconstructor && this.declaringclass.isenum()) { // insert string name,int ordinal
buffer.append(constantpool.javalangstringsignature);
buffer.append(typebinding.int.signature());
}
boolean needsynthetics = isconstructor && this.declaringclass.isnestedtype();
if (needsynthetics) {
// take into account the synthetic argument type signatures as well
referencebinding[] syntheticargumenttypes = this.declaringclass.syntheticenclosinginstancetypes();
if (syntheticargumenttypes != null) {
for (int i = 0, count = syntheticargumenttypes.length; i < count; i++) {
referencebinding syntheticargumenttype = syntheticargumenttypes[i];
if ((syntheticargumenttype.tagbits & tagbits.containsnestedtypereferences) != 0) {
this.tagbits |= tagbits.containsnestedtypereferences;
util.recordnestedtype(classfile, syntheticargumenttype);
}
buffer.append(syntheticargumenttype.signature());
}
}

if (this instanceof syntheticmethodbinding) {
targetparameters = ((syntheticmethodbinding)this).targetmethod.parameters;
}
}

if (targetparameters != binding.no_parameters) {
for (int i = 0, max = targetparameters.length; i < max; i++) {
typebinding targetparameter = targetparameters[i];
typebinding leaftargetparametertype = targetparameter.leafcomponenttype();
if ((leaftargetparametertype.tagbits & tagbits.containsnestedtypereferences) != 0) {
this.tagbits |= tagbits.containsnestedtypereferences;
util.recordnestedtype(classfile, leaftargetparametertype);
}
buffer.append(targetparameter.signature());
}
}
if (needsynthetics) {
syntheticargumentbinding[] syntheticouterarguments = this.declaringclass.syntheticouterlocalvariables();
int count = syntheticouterarguments == null ? 0 : syntheticouterarguments.length;
for (int i = 0; i < count; i++) {
buffer.append(syntheticouterarguments[i].type.signature());
}
// move the extra padding arguments of the synthetic constructor invocation to the end
for (int i = targetparameters.length, extralength = this.parameters.length; i < extralength; i++) {
typebinding parameter = this.parameters[i];
typebinding leafparametertype = parameter.leafcomponenttype();
if ((leafparametertype.tagbits & tagbits.containsnestedtypereferences) != 0) {
this.tagbits |= tagbits.containsnestedtypereferences;
util.recordnestedtype(classfile, leafparametertype);
}
buffer.append(parameter.signature());
}
}
buffer.append(')');
if (this.returntype != null) {
typebinding ret = this.returntype.leafcomponenttype();
if ((ret.tagbits & tagbits.containsnestedtypereferences) != 0) {
this.tagbits |= tagbits.containsnestedtypereferences;
util.recordnestedtype(classfile, ret);
}
buffer.append(this.returntype.signature());
}
int namelength = buffer.length();
this.signature = new char[namelength];
buffer.getchars(0, namelength, this.signature, 0);

return this.signature;
}
public final int sourceend() {
abstractmethoddeclaration method = sourcemethod();
if (method == null) {
if (this.declaringclass instanceof sourcetypebinding)
return ((sourcetypebinding) this.declaringclass).sourceend();
return 0;
}
return method.sourceend;
}
public abstractmethoddeclaration sourcemethod() {
if (issynthetic()) {
return null;
}
sourcetypebinding sourcetype;
try {
sourcetype = (sourcetypebinding) this.declaringclass;
} catch (classcastexception e) {
return null;
}

abstractmethoddeclaration[] methods = sourcetype.scope.referencecontext.methods;
if (methods != null) {
for (int i = methods.length; --i >= 0;)
if (this == methods[i].binding)
return methods[i];
}
return null;
}
public final int sourcestart() {
abstractmethoddeclaration method = sourcemethod();
if (method == null) {
if (this.declaringclass instanceof sourcetypebinding)
return ((sourcetypebinding) this.declaringclass).sourcestart();
return 0;
}
return method.sourcestart;
}

/**
* returns the method to use during tiebreak (usually the method itself).
* for generic method invocations, tiebreak needs to use generic method with erasure substitutes.
*/
public methodbinding tiebreakmethod() {
return this;
}
public string tostring() {
stringbuffer output = new stringbuffer(10);
if ((this.modifiers & extracompilermodifiers.accunresolved) != 0) {
output.append("[unresolved] "); //$non-nls-1$
}
astnode.printmodifiers(this.modifiers, output);
output.append(this.returntype != null ? this.returntype.debugname() : "<no type>"); //$non-nls-1$
output.append(" "); //$non-nls-1$
output.append(this.selector != null ? new string(this.selector) : "<no selector>"); //$non-nls-1$
output.append("("); //$non-nls-1$
if (this.parameters != null) {
if (this.parameters != binding.no_parameters) {
for (int i = 0, length = this.parameters.length; i < length; i++) {
if (i  > 0)
output.append(", "); //$non-nls-1$
output.append(this.parameters[i] != null ? this.parameters[i].debugname() : "<no argument type>"); //$non-nls-1$
}
}
} else {
output.append("<no argument types>"); //$non-nls-1$
}
output.append(") "); //$non-nls-1$

if (this.thrownexceptions != null) {
if (this.thrownexceptions != binding.no_exceptions) {
output.append("throws "); //$non-nls-1$
for (int i = 0, length = this.thrownexceptions.length; i < length; i++) {
if (i  > 0)
output.append(", "); //$non-nls-1$
output.append((this.thrownexceptions[i] != null) ? this.thrownexceptions[i].debugname() : "<no exception type>"); //$non-nls-1$
}
}
} else {
output.append("<no exception types>"); //$non-nls-1$
}
return output.tostring();
}
public typevariablebinding[] typevariables() {
return this.typevariables;
}
}
