/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce a explicit constructor call containing the cursor.
* e.g.
*
*	class x {
*    x() {
*      this(1, 2, [cursor]
*    }
*  }
*
*	---> class x {
*         x() {
*           <completeonexplicitconstructorcall:this(1, 2)>
*         }
*       }
*
* the source range is always of length 0.
* the arguments of the constructor call are all the arguments defined
* before the cursor.
*/

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class completiononexplicitconstructorcall extends explicitconstructorcall {

public completiononexplicitconstructorcall(int accessmode) {
super(accessmode);
}

public stringbuffer printstatement(int tab, stringbuffer output) {

printindent(tab, output);
output.append("<completeonexplicitconstructorcall:"); //$non-nls-1$
if (this.qualification != null) this.qualification.printexpression(0, output).append('.');
if (this.accessmode == this) {
output.append("this("); //$non-nls-1$
} else {
output.append("super("); //$non-nls-1$
}
if (this.arguments != null) {
for (int i = 0; i < this.arguments.length; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.arguments[i].printexpression(0, output);
}
}
return output.append(")>;"); //$non-nls-1$
}

public void resolve(blockscope scope) {

referencebinding receivertype = scope.enclosingsourcetype();

if (this.arguments != null) {
int argslength = this.arguments.length;
for (int a = argslength; --a >= 0;)
this.arguments[a].resolvetype(scope);
}

if (this.accessmode != this && receivertype != null) {
if (receivertype.ishierarchyinconsistent())
throw new completionnodefound();
receivertype = receivertype.superclass();
}
if (receivertype == null)
throw new completionnodefound();
else
throw new completionnodefound(this, receivertype, scope);
}
}
