/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.*;

public class initializer extends fielddeclaration {

public block block;
public int lastvisiblefieldid;
public int bodystart;
public int bodyend;

public initializer(block block, int modifiers) {
this.block = block;
this.modifiers = modifiers;

if (block != null) {
this.declarationsourcestart = this.sourcestart = block.sourcestart;
}
}

public flowinfo analysecode(
methodscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {

if (this.block != null) {
return this.block.analysecode(currentscope, flowcontext, flowinfo);
}
return flowinfo;
}

/**
* code generation for a non-static initializer:
*    standard block code gen
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {

if ((this.bits & isreachable) == 0) {
return;
}
int pc = codestream.position;
if (this.block != null) this.block.generatecode(currentscope, codestream);
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.abstractvariabledeclaration#getkind()
*/
public int getkind() {
return initializer;
}

public boolean isstatic() {

return (this.modifiers & classfileconstants.accstatic) != 0;
}

public void parsestatements(
parser parser,
typedeclaration typedeclaration,
compilationunitdeclaration unit) {

//fill up the method body with statement
parser.parse(this, typedeclaration, unit);
}

public stringbuffer printstatement(int indent, stringbuffer output) {

if (this.modifiers != 0) {
printindent(indent, output);
printmodifiers(this.modifiers, output);
if (this.annotations != null) printannotations(this.annotations, output);
output.append("{\n"); //$non-nls-1$
if (this.block != null) {
this.block.printbody(indent, output);
}
printindent(indent, output).append('}');
return output;
} else if (this.block != null) {
this.block.printstatement(indent, output);
} else {
printindent(indent, output).append("{}"); //$non-nls-1$
}
return output;
}

public void resolve(methodscope scope) {

fieldbinding previousfield = scope.initializedfield;
int previousfieldid = scope.lastvisiblefieldid;
try {
scope.initializedfield = null;
scope.lastvisiblefieldid = this.lastvisiblefieldid;
if (isstatic()) {
referencebinding declaringtype = scope.enclosingsourcetype();
if (declaringtype.isnestedtype() && !declaringtype.isstatic())
scope.problemreporter().innertypescannotdeclarestaticinitializers(
declaringtype,
this);
}
if (this.block != null) this.block.resolve(scope);
} finally {
scope.initializedfield = previousfield;
scope.lastvisiblefieldid = previousfieldid;
}
}

public void traverse(astvisitor visitor, methodscope scope) {
if (visitor.visit(this, scope)) {
if (this.block != null) this.block.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
