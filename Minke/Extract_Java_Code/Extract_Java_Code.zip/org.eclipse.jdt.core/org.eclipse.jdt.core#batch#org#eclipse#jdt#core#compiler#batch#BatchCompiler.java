/*******************************************************************************
* copyright (c) 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.core.compiler.batch;

import java.io.printwriter;

import org.eclipse.jdt.core.compiler.compilationprogress;
import org.eclipse.jdt.internal.compiler.batch.main;

/**
* a public api for invoking the eclipse compiler for java. e.g.
* <pre>
* batchcompiler.compile("c:\\mysources\\x.java -d c:\\myoutput", new printwriter(system.out), new printwriter(system.err), null);
* </pre>
*
* @@since 3.4
* @@noinstantiate this class is not intended to be instantiated by clients.
*/
public final class batchcompiler {

/**
* invokes the eclipse compiler for java with the given command line arguments, using the given writers
* to print messages, and reporting progress to the given compilation progress. returns whether
* the compilation completed successfully.
* <p>
* reasons for a compilation failing to complete successfully include:</p>
* <ul>
* <li>an error was reported</li>
* <li>a runtime exception occurred</li>
* <li>the compilation was canceled using the compilation progress</li>
* </ul>
* <p>
* the specification of the command line arguments is defined by running the batch compiler's help
* <pre>batchcompiler.compile("-help", new printwriter(system.out), new printwriter(system.err), null);</pre>
* </p>
*
* @@param commandline the command line arguments passed to the compiler
* @@param outwriter the writer used to print standard messages
* @@param errwriter the writer used to print error messages
* @@param progress the object to report progress to and to provide cancellation, or <code>null</code> if no progress is needed
* @@return whether the compilation completed successfully
*/
public static boolean compile(string commandline, printwriter outwriter, printwriter errwriter, compilationprogress progress) {
return main.compile(main.tokenize(commandline), outwriter, errwriter, progress);
}

/**
* invokes the eclipse compiler for java with the given command line arguments, using the given writers
* to print messages, and reporting progress to the given compilation progress. returns whether
* the compilation completed successfully.
* <p>
* reasons for a compilation failing to complete successfully include:</p>
* <ul>
* <li>an error was reported</li>
* <li>a runtime exception occurred</li>
* <li>the compilation was canceled using the compilation progress</li>
* </ul>
* <p>
* the specification of the command line arguments is defined by running the batch compiler's help
* <pre>batchcompiler.compile("-help", new printwriter(system.out), new printwriter(system.err), null);</pre>
* </p>
* note that a <code>true</code> returned value indicates that no errors were reported, no runtime exceptions
* occurred and that the compilation was not canceled.
*
* @@param commandlinearguments the command line arguments passed to the compiler
* @@param outwriter the writer used to print standard messages
* @@param errwriter the writer used to print error messages
* @@param progress the object to report progress to and to provide cancellation, or <code>null</code> if no progress is needed
* @@return whether the compilation completed successfully
*/
public static boolean compile(string[] commandlinearguments, printwriter outwriter, printwriter errwriter, compilationprogress progress) {
return main.compile(commandlinearguments, outwriter, errwriter, progress);
}

private batchcompiler() {
// prevent instantiation
}
}
