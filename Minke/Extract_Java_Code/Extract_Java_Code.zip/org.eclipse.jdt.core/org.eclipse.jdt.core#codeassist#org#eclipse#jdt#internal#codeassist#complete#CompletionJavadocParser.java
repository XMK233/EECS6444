/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import java.util.arraylist;
import java.util.list;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.invalidinputexception;
import org.eclipse.jdt.internal.codeassist.completionengine;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.parser.javadocparser;
import org.eclipse.jdt.internal.compiler.parser.scannerhelper;
import org.eclipse.jdt.internal.compiler.parser.terminaltokens;

/**
* parser specialized for decoding javadoc comments which includes cursor location for code completion.
*/
public class completionjavadocparser extends javadocparser {

// initialize lengthes for block and inline tags tables
public final static int inline_all_tags_length;
public final static int block_all_tags_length;
static {
int length = 0;
for (int i=0; i<inline_tags_length; i++) {
length += inline_tags[i].length;
}
inline_all_tags_length  = length;
length = 0;
for (int i=0; i<block_tags_length; i++) {
length += block_tags[i].length;
}
block_all_tags_length = length;
}

// level tags are array of inline/block tags depending on compilation source level
char[][][] leveltags = new char[2][][];
int[] leveltagslength = new int[2];

// completion specific info
int cursorlocation;
completiononjavadoc completionnode = null;
boolean pushtext = false;
boolean allpossibletags = false;

public completionjavadocparser(completionparser sourceparser) {
super(sourceparser);
this.scanner = new completionscanner(classfileconstants.jdk1_3);
this.kind = completion_parser | text_parse;
initleveltags();
}

/*
* do not parse comment if completion location is not included.
*/
public boolean checkdeprecation(int commentptr) {
boolean isdeprecated = false;

this.cursorlocation = ((completionparser)this.sourceparser).cursorlocation;
completionscanner completionscanner = (completionscanner)this.scanner;
completionscanner.cursorlocation = this.cursorlocation;
this.javadocstart = this.sourceparser.scanner.commentstarts[commentptr];
this.javadocend = this.sourceparser.scanner.commentstops[commentptr];
if (this.javadocstart <= this.cursorlocation && this.cursorlocation <= this.javadocend) {
if (completionengine.debug) {
system.out.println("completion in javadoc:"); //$non-nls-1$
}
completionscanner.completionidentifier = null;
this.firsttagposition = 1;
super.checkdeprecation(commentptr);
} else {
if (this.sourceparser.scanner.commenttagstarts[commentptr] != 0) {
boolean previousvalue = this.checkdoccomment;
this.checkdoccomment = false;
isdeprecated = super.checkdeprecation(commentptr);
this.checkdoccomment = previousvalue;
}
this.doccomment = null;
}
return isdeprecated;
}

/*
* replace stored javadoc node with specific completion one.
*/
protected boolean commentparse() {
this.doccomment = new completionjavadoc(this.javadocstart, this.javadocend);
return super.commentparse();
}

/*
* create argument expression. if it includes completion location, create and store completion node.
*/
protected object createargumentreference(char[] name, int dim, boolean isvarargs, object typeref, long[] dimpositions, long argnamepos) throws invalidinputexception {
// create argument as we may need it after
char[] argname = name==null ? charoperation.no_char : name;
expression expression = (expression) super.createargumentreference(argname, dim, isvarargs, typeref, dimpositions, argnamepos);
// see if completion location is in argument
int refstart = ((typereference)typeref).sourcestart;
int refend = ((typereference)typeref).sourceend;
boolean incompletion = (refstart <= this.cursorlocation && this.cursorlocation <= refend) // completion cursor is between first and last stacked identifiers
|| ((refstart == (refend+1) && refend == this.cursorlocation)); // or it's a completion on empty token
if (this.completionnode == null && incompletion) {
javadocargumentexpression javadocargument = (javadocargumentexpression) expression;
typereference expressiontype = javadocargument.argument.type;
if (expressiontype instanceof javadocsingletypereference) {
this.completionnode = new completiononjavadocsingletypereference((javadocsingletypereference) expressiontype);
} else if (expressiontype instanceof javadocqualifiedtypereference) {
this.completionnode = new completiononjavadocqualifiedtypereference((javadocqualifiedtypereference) expressiontype);
}
if (completionengine.debug) {
system.out.println("	completion argument="+this.completionnode); //$non-nls-1$
}
return this.completionnode;
}
return expression;
}

/*
* create field reference. if it includes completion location, create and store completion node.
*/
protected object createfieldreference(object receiver) throws invalidinputexception {
int refstart = (int) (this.identifierpositionstack[0] >>> 32);
int refend = (int) this.identifierpositionstack[0];
boolean incompletion = (refstart <= (this.cursorlocation+1) && this.cursorlocation <= refend) // completion cursor is between first and last stacked identifiers
|| ((refstart == (refend+1) && refend == this.cursorlocation)) // or it's a completion on empty token
|| (this.memberstart == this.cursorlocation); // or it's a completion just after the member separator with an identifier after the cursor
if (incompletion) {
javadocfieldreference fieldref = (javadocfieldreference) super.createfieldreference(receiver);
char[] name = this.sourceparser.compilationunit.getmaintypename();
typedeclaration typedecl = getparsedtypedeclaration();
if (typedecl != null) {
name = typedecl.name;
}
this.completionnode = new completiononjavadocfieldreference(fieldref, this.memberstart, name);
if (completionengine.debug) {
system.out.println("	completion field="+this.completionnode); //$non-nls-1$
}
return this.completionnode;
}
return super.createfieldreference(receiver);
}

/*
* verify if method identifier positions include completion location.
* if so, create method reference and store it.
* otherwise return null as we do not need this reference.
*/
protected object createmethodreference(object receiver, list arguments) throws invalidinputexception {
int memberptr = this.identifierlengthstack[0] - 1; // may be > 0 for inner class constructor reference
int refstart = (int) (this.identifierpositionstack[memberptr] >>> 32);
int refend = (int) this.identifierpositionstack[memberptr];
boolean incompletion = (refstart <= (this.cursorlocation+1) && this.cursorlocation <= refend) // completion cursor is between first and last stacked identifiers
|| ((refstart == (refend+1) && refend == this.cursorlocation)) // or it's a completion on empty token
|| (this.memberstart == this.cursorlocation); // or it's a completion just after the member separator with an identifier after the cursor
if (incompletion) {
astnode node = (astnode) super.createmethodreference(receiver, arguments);
if (node instanceof javadocmessagesend) {
javadocmessagesend messagesend = (javadocmessagesend) node;
int namestart = (int) (messagesend.namesourceposition >>> 32);
int nameend = (int) messagesend.namesourceposition;
if ((namestart <= (this.cursorlocation+1) && this.cursorlocation <= nameend)) {
this.completionnode = new completiononjavadocfieldreference(messagesend, this.memberstart);
} else {
this.completionnode = new completiononjavadocmessagesend(messagesend, this.memberstart);
}
} else if (node instanceof javadocallocationexpression) {
this.completionnode = new completiononjavadocallocationexpression((javadocallocationexpression)node, this.memberstart);
}
if (completionengine.debug) {
system.out.println("	completion method="+this.completionnode); //$non-nls-1$
}
return this.completionnode;
}
return super.createmethodreference(receiver, arguments);
}

/*
* create type reference. if it includes completion location, create and store completion node.
*/
protected object createtypereference(int primitivetoken) {
// need to create type ref in case it was needed by members
int nbidentifiers = this.identifierlengthstack[this.identifierlengthptr];
int startptr = this.identifierptr - (nbidentifiers-1);
int refstart = (int) (this.identifierpositionstack[startptr] >>> 32);
int refend = (int) this.identifierpositionstack[this.identifierptr];
boolean incompletion = (refstart <= (this.cursorlocation+1) && this.cursorlocation <= refend) // completion cursor is between first and last stacked identifiers
|| ((refstart == (refend+1) && refend == this.cursorlocation)); // or it's a completion on empty token
if (!incompletion) {
return super.createtypereference(primitivetoken);
}
this.identifierlengthptr--;
if (nbidentifiers == 1) { // single type ref
this.completionnode = new completiononjavadocsingletypereference(
this.identifierstack[this.identifierptr],
this.identifierpositionstack[this.identifierptr],
this.tagsourcestart,
this.tagsourceend);
} else if (nbidentifiers > 1) { // qualified type ref
for (int i=startptr; i<this.identifierptr; i++) {
int start = (int) (this.identifierpositionstack[i] >>> 32);
int end = (int) this.identifierpositionstack[i];
if (start <= this.cursorlocation && this.cursorlocation <= end) {
if (i == startptr) {
this.completionnode = new completiononjavadocsingletypereference(
this.identifierstack[startptr],
this.identifierpositionstack[startptr],
this.tagsourcestart,
this.tagsourceend);
} else {
char[][] tokens = new char[i][];
system.arraycopy(this.identifierstack, startptr, tokens, 0, i);
long[] positions = new long[i+1];
system.arraycopy(this.identifierpositionstack, startptr, positions, 0, i+1);
this.completionnode = new completiononjavadocqualifiedtypereference(tokens, this.identifierstack[i], positions, this.tagsourcestart, this.tagsourceend);
}
break;
}
}
if (this.completionnode == null) {
char[][] tokens = new char[nbidentifiers-1][];
system.arraycopy(this.identifierstack, startptr, tokens, 0, nbidentifiers-1);
long[] positions = new long[nbidentifiers];
system.arraycopy(this.identifierpositionstack, startptr, positions, 0, nbidentifiers);
this.completionnode = new completiononjavadocqualifiedtypereference(tokens, this.identifierstack[this.identifierptr], positions, this.tagsourcestart, this.tagsourceend);
}
}

if (completionengine.debug) {
system.out.println("	completion partial qualified type="+this.completionnode); //$non-nls-1$
}
return this.completionnode;
}

/*
* get possible tags for a given prefix.
*/
private char[][][] possibletags(char[] prefix, boolean newline) {
char[][][] possibletags = new char[2][][];
if (newline) {
system.arraycopy(this.leveltags[block_idx], 0, possibletags[block_idx] = new char[this.leveltagslength[block_idx]][], 0, this.leveltagslength[block_idx]);
} else {
possibletags[block_idx] = charoperation.no_char_char;
}
system.arraycopy(this.leveltags[inline_idx], 0, possibletags[inline_idx] = new char[this.leveltagslength[inline_idx]][], 0, this.leveltagslength[inline_idx]);
if (prefix == null || prefix.length == 0) return possibletags;
int kinds = this.leveltags.length;
for (int k=0; k<kinds; k++) {
int length = possibletags[k].length, size = 0;
int indexes[] = new int[length];
for (int i=0; i<length; i++) {
if (charoperation.prefixequals(prefix, possibletags[k][i], false)) {
indexes[size++] = i;
}
}
char[][] tags = new char[size][];
for (int i=0; i<size; i++) {
tags[i] = possibletags[k][indexes[i]];
}
possibletags[k] = tags;
}
return possibletags;
}

private completionjavadoc getcompletionjavadoc() {
return (completionjavadoc)this.doccomment;
}

private completionparser getcompletionparser() {
return (completionparser)this.sourceparser;
}

/*
* init tags arrays for current source level.
*/
private void initleveltags() {
int level = ((int)(this.compliancelevel >>> 16)) - classfileconstants.major_version_1_1 + 1;
// init block tags
this.leveltags[block_idx] = new char[block_all_tags_length][];
this.leveltagslength[block_idx] = 0;
for (int i=0; i<=level; i++) {
int length = block_tags[i].length;
system.arraycopy(block_tags[i], 0, this.leveltags[block_idx], this.leveltagslength[block_idx], length);
this.leveltagslength[block_idx] += length;
}
if (this.leveltagslength[block_idx] < block_all_tags_length) {
system.arraycopy(this.leveltags[block_idx], 0, this.leveltags[block_idx] = new char[this.leveltagslength[block_idx]][], 0, this.leveltagslength[block_idx]);
}
// init inline tags
this.leveltags[inline_idx] = new char[inline_all_tags_length][];
this.leveltagslength[inline_idx]= 0;
for (int i=0; i<=level; i++) {
int length = inline_tags[i].length;
system.arraycopy(inline_tags[i], 0, this.leveltags[inline_idx], this.leveltagslength[inline_idx], length);
this.leveltagslength[inline_idx] += length;
}
if (this.leveltagslength[inline_idx] < inline_all_tags_length) {
system.arraycopy(this.leveltags[inline_idx], 0, this.leveltags[inline_idx] = new char[this.leveltagslength[inline_idx]][], 0, this.leveltagslength[inline_idx]);
}
}
/*
* parse argument in @@see tag method reference
*/
protected object parsearguments(object receiver) throws invalidinputexception {

if (this.tagsourcestart>this.cursorlocation) {
return super.parsearguments(receiver);
}

// init
int modulo = 0; // should be 2 for (type,type,...) or 3 for (type arg,type arg,...)
int itoken = 0;
char[] argname = null;
list arguments = new arraylist(10);
object typeref = null;
int dim = 0;
boolean isvarargs = false;
long[] dimpositions = new long[20]; // assume that there won't be more than 20 dimensions...
char[] name = null;
long argnamepos = -1;

// parse arguments declaration if method reference
nextarg : while (this.index < this.scanner.eofposition) {

// read argument type reference
try {
typeref = parsequalifiedname(false);
if (this.abort) return null; // may be aborted by specialized parser
} catch (invalidinputexception e) {
break nextarg;
}
boolean firstarg = modulo == 0;
if (firstarg) { // verify position
if (itoken != 0)
break nextarg;
} else if ((itoken % modulo) != 0) {
break nextarg;
}
if (typeref == null) {
if (firstarg && getcurrenttokentype() == terminaltokens.tokennamerparen) {
this.linestarted = true;
return createmethodreference(receiver, null);
}
object methodref = createmethodreference(receiver, arguments);
return syntaxrecoveremptyargumenttype(methodref);
}
if (this.index >= this.scanner.eofposition) {
int argumentstart = ((astnode)typeref).sourcestart;
object argument = createargumentreference(this.scanner.getcurrentidentifiersource(), 0, false, typeref, null, (((long)argumentstart)<<32)+this.tokenpreviousposition-1);
return syntaxrecoverargumenttype(receiver, arguments, argument);
}
if (this.index >= this.cursorlocation) {
if (this.completionnode instanceof completiononjavadocsingletypereference) {
completiononjavadocsingletypereference singletypereference = (completiononjavadocsingletypereference) this.completionnode;
if (singletypereference.token == null || singletypereference.token.length == 0) {
object methodref = createmethodreference(receiver, arguments);
return syntaxrecoveremptyargumenttype(methodref);
}
}
if (this.completionnode instanceof completiononjavadocqualifiedtypereference) {
completiononjavadocqualifiedtypereference qualifiedtypereference = (completiononjavadocqualifiedtypereference) this.completionnode;
if (qualifiedtypereference.tokens == null || qualifiedtypereference.tokens.length < qualifiedtypereference.sourcepositions.length) {
object methodref = createmethodreference(receiver, arguments);
return syntaxrecoveremptyargumenttype(methodref);
}
}
}
itoken++;

// read possible additional type info
dim = 0;
isvarargs = false;
if (readtoken() == terminaltokens.tokennamelbracket) {
// array declaration
int dimstart = this.scanner.getcurrenttokenstartposition();
while (readtoken() == terminaltokens.tokennamelbracket) {
consumetoken();
if (readtoken() != terminaltokens.tokennamerbracket) {
break nextarg;
}
consumetoken();
dimpositions[dim++] = (((long) dimstart) << 32) + this.scanner.getcurrenttokenendposition();
}
} else if (readtoken() == terminaltokens.tokennameellipsis) {
// ellipsis declaration
int dimstart = this.scanner.getcurrenttokenstartposition();
dimpositions[dim++] = (((long) dimstart) << 32) + this.scanner.getcurrenttokenendposition();
consumetoken();
isvarargs = true;
}

// read argument name
argnamepos = -1;
if (readtoken() == terminaltokens.tokennameidentifier) {
consumetoken();
if (firstarg) { // verify position
if (itoken != 1)
break nextarg;
} else if ((itoken % modulo) != 1) {
break nextarg;
}
if (argname == null) { // verify that all arguments name are declared
if (!firstarg) {
break nextarg;
}
}
argname = this.scanner.getcurrentidentifiersource();
argnamepos = (((long)this.scanner.getcurrenttokenstartposition())<<32)+this.scanner.getcurrenttokenendposition();
itoken++;
} else if (argname != null) { // verify that no argument name is declared
break nextarg;
}

// verify token position
if (firstarg) {
modulo = itoken + 1;
} else {
if ((itoken % modulo) != (modulo - 1)) {
break nextarg;
}
}

// read separator or end arguments declaration
int token = readtoken();
name = argname == null ? charoperation.no_char : argname;
if (token == terminaltokens.tokennamecomma) {
// create new argument
object argument = createargumentreference(name, dim, isvarargs, typeref, dimpositions, argnamepos);
if (this.abort) return null; // may be aborted by specialized parser
arguments.add(argument);
consumetoken();
itoken++;
} else if (token == terminaltokens.tokennamerparen) {
// create new argument
object argument = createargumentreference(name, dim, isvarargs, typeref, dimpositions, argnamepos);
if (this.abort) return null; // may be aborted by specialized parser
arguments.add(argument);
consumetoken();
return createmethodreference(receiver, arguments);
} else {
object argument = createargumentreference(name, dim, isvarargs, typeref, dimpositions, argnamepos);
return syntaxrecoverargumenttype(receiver, arguments, argument);
}
}

// something wrong happened => invalid input
throw new invalidinputexception();
}

protected boolean parseparam() throws invalidinputexception {
int startposition = this.index;
int endposition = this.index;
long nameposition = (((long)startposition)<<32) + endposition;
this.identifierptr = -1;
boolean valid = super.parseparam();
if (this.identifierptr > 2) return valid;
// see if expression is concerned by completion
char[] name = null;
completionscanner completionscanner = (completionscanner) this.scanner;
boolean istypeparam = false;
if (this.identifierptr >= 0) {
char[] identifier = null;
switch (this.identifierptr) {
case 2:
if (!valid && completionscanner.completionidentifier != null && completionscanner.completionidentifier.length == 0) {
valid = pushparamname(true);
}
// $fall-through$ - fall through next case to verify and get identifiers stack contents
case 1:
istypeparam = this.identifierstack[0][0] == '<';
identifier = this.identifierstack[1];
nameposition = this.identifierpositionstack[1];
break;
case 0:
identifier = this.identifierstack[0];
nameposition = this.identifierpositionstack[0];
istypeparam = identifier.length > 0 && identifier[0] == '<';
break;
}
if (identifier != null && identifier.length > 0 && scannerhelper.isjavaidentifierpart(identifier[0])) {
name = identifier;
}
startposition = (int)(this.identifierpositionstack[0]>>32);
endposition = (int)this.identifierpositionstack[this.identifierptr];
}
boolean incompletion = (startposition <= (this.cursorlocation+1) && this.cursorlocation <= endposition) // completion cursor is between first and last stacked identifiers
|| ((startposition == (endposition+1) && endposition == this.cursorlocation)); // or it's a completion on empty token
if (incompletion) {
if (this.completionnode == null) {
if (istypeparam) {
this.completionnode = new completiononjavadoctypeparamreference(name, nameposition, startposition, endposition);
} else {
this.completionnode = new completiononjavadocparamnamereference(name, nameposition, startposition, endposition);
}
if (completionengine.debug) {
system.out.println("	completion param="+this.completionnode); //$non-nls-1$
}
} else if (this.completionnode instanceof completiononjavadocparamnamereference) {
completiononjavadocparamnamereference paramnameref = (completiononjavadocparamnamereference)this.completionnode;
int namestart = (int) (nameposition>>32);
paramnameref.sourcestart = namestart;
int nameend = (int) nameposition;
if (namestart<this.cursorlocation && this.cursorlocation<nameend) {
paramnameref.sourceend = this.cursorlocation + 1;
} else {
paramnameref.sourceend = nameend;
}
paramnameref.tagsourcestart = startposition;
paramnameref.tagsourceend = endposition;
} else if (this.completionnode instanceof completiononjavadoctypeparamreference) {
completiononjavadoctypeparamreference typeparamref = (completiononjavadoctypeparamreference)this.completionnode;
int namestart = (int) (nameposition>>32);
typeparamref.sourcestart = namestart;
int nameend = (int) nameposition;
if (namestart<this.cursorlocation && this.cursorlocation<nameend) {
typeparamref.sourceend = this.cursorlocation + 1;
} else {
typeparamref.sourceend = nameend;
}
typeparamref.tagsourcestart = startposition;
typeparamref.tagsourceend = endposition;
}
}
return valid;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#parsereference()
*/
protected boolean parsereference() throws invalidinputexception {
boolean completed = this.completionnode != null;
boolean valid = super.parsereference();
if (!completed && this.completionnode != null) {
this.completionnode.addcompletionflags(completiononjavadoc.formal_reference);
}
return valid;
}

/*(non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#parsetag(int)
*/
protected boolean parsetag(int previousposition) throws invalidinputexception {
int startposition = this.inlinetagstarted ? this.inlinetagstart : previousposition;
boolean newline = !this.linestarted;
boolean valid = super.parsetag(previousposition);
boolean incompletion = (this.tagsourcestart <= (this.cursorlocation+1) && this.cursorlocation <= this.tagsourceend) // completion cursor is between first and last stacked identifiers
|| ((this.tagsourcestart == (this.tagsourceend+1) && this.tagsourceend == this.cursorlocation)); // or it's a completion on empty token
if (incompletion) {
int end = this.tagsourceend;
if (this.inlinetagstarted && this.scanner.currentcharacter == '}') {
end = this.scanner.currentposition;
}
long position = (((long)startposition)<<32) + end;
int length = this.cursorlocation+1-this.tagsourcestart;
char[] tag = new char[length];
system.arraycopy(this.source, this.tagsourcestart, tag, 0, length);
char[][][] tags = possibletags(tag, newline);
if (tags != null) {
this.completionnode = new completiononjavadoctag(tag, position, startposition, end, tags, this.allpossibletags);
}
}
return valid;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#parsethrows()
*/
protected boolean parsethrows() {
try {
object typeref = parsequalifiedname(true);
if (this.completionnode != null) {
this.completionnode.addcompletionflags(completiononjavadoc.exception);
}
return pushthrowname(typeref);
} catch (invalidinputexception ex) {
// ignore
}
return false;
}

/*
* push param name reference. if it includes completion location, create and store completion node.
*/
protected boolean pushparamname(boolean istypeparam) {
if (super.pushparamname(istypeparam)) {
expression expression = (expression) this.aststack[this.astptr];
// see if expression is concerned by completion
if (expression.sourcestart <= (this.cursorlocation+1) && this.cursorlocation <= expression.sourceend) {
if (istypeparam) {
this.completionnode = new completiononjavadoctypeparamreference((javadocsingletypereference)expression);
} else {
this.completionnode = new completiononjavadocparamnamereference((javadocsinglenamereference)expression);
}
if (completionengine.debug) {
system.out.println("	completion param="+this.completionnode); //$non-nls-1$
}
}
return true;
}
return false;
}

/**
* push text. if it includes completion location, then rescan line to see if there's a possible
* reference under the cursor location.
*
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#pushtext(int, int)
*/
protected void pushtext(int start, int end) {
if (start <= this.cursorlocation && this.cursorlocation <= end) {
this.scanner.resetto(start, end);
boolean tokenizewhitespace = this.scanner.tokenizewhitespace;
this.scanner.tokenizewhitespace = true;
try {
object typeref = null;
this.pushtext = true;

// get reference tokens
int previoustoken = terminaltokens.tokennamewhitespace;
while (!this.scanner.atend() && this.completionnode == null && !this.abort) {
int token = readtokensafely();
switch (token) {
case terminaltokens.tokennamestringliteral :
int strstart = 0, strend = 0;
if ((strstart=this.scanner.getcurrenttokenstartposition()+1) <= this.cursorlocation &&
this.cursorlocation <= (strend=this.scanner.getcurrenttokenendposition()-1))
{
this.scanner.resetto(strstart, strend);
}
consumetoken();
break;
case terminaltokens.tokennameerror :
consumetoken();
if (this.scanner.currentcharacter == '#') { // @@see ...#member
object member = null;
try {
this.scanner.tokenizewhitespace = false;
member = parsemember(typeref);
} catch (invalidinputexception e) {
consumetoken();
}
this.scanner.tokenizewhitespace = true;
if (this.completionnode != null) {
int flags = this.inlinetagstarted ? 0 : completiononjavadoc.text|completiononjavadoc.only_inline_tag;
if (member instanceof javadocmessagesend) {
javadocmessagesend msgsend = (javadocmessagesend) member;
this.completionnode = new completiononjavadocmessagesend(msgsend, this.memberstart, flags);
if (completionengine.debug) {
system.out.println("	new completion method="+this.completionnode); //$non-nls-1$
}
} else if (member instanceof javadocallocationexpression) {
javadocallocationexpression alloc = (javadocallocationexpression) member;
this.completionnode = new completiononjavadocallocationexpression(alloc, this.memberstart, flags);
if (completionengine.debug) {
system.out.println("	new completion method="+this.completionnode); //$non-nls-1$
}
} else {
this.completionnode.addcompletionflags(flags);
}
}
}
break;
case terminaltokens.tokennameidentifier :
try {
this.scanner.tokenizewhitespace = false;
typeref = parsequalifiedname(true);
if (this.completionnode == null) {
consumetoken();
this.scanner.resetto(this.tokenpreviousposition, end);
this.index = this.tokenpreviousposition;
}
}
catch (invalidinputexception e) {
consumetoken();
}
finally {
this.scanner.tokenizewhitespace = true;
}
if (previoustoken != terminaltokens.tokennamewhitespace) {
typeref = null;
this.completionnode = null;
}
break;
case terminaltokens.tokennameat:
consumetoken();
try {
this.scanner.tokenizewhitespace = false;
int startposition = this.scanner.getcurrenttokenstartposition();
parsetag(startposition);
if (this.completionnode != null) {
if (this.inlinetagstarted) {
/* may be to replace invalid @@value tag inside text?
if (this.completionnode instanceof completiononjavadocsingletypereference) {
completiononjavadocsingletypereference singletypereference = (completiononjavadocsingletypereference) this.completionnode;
singletypereference.tagsourcestart = startposition;
switch (this.tagvalue) {
case tag_value_value:
//													singletypereference.completionflags |= only_inline_tag;
if (this.sourcelevel < classfileconstants.jdk1_5) singletypereference.completionflags |= replace_tag;
break;
}
} else if (this.completionnode instanceof completiononjavadocqualifiedtypereference) {
completiononjavadocqualifiedtypereference qualifiedtyperef = (completiononjavadocqualifiedtypereference) this.completionnode;
qualifiedtyperef.tagsourcestart = startposition;
switch (this.tagvalue) {
case tag_value_value:
singletypereference.completionflags |= only_inline_tag;
if (this.sourcelevel < classfileconstants.jdk1_5) qualifiedtyperef.completionflags |= replace_tag;
break;
}
}
//										*/
} else {
/* may be to replace non-inline tag inside text?
if (this.completionnode instanceof completiononjavadocsingletypereference) {
completiononjavadocsingletypereference singletypereference = (completiononjavadocsingletypereference) this.completionnode;
singletypereference.tagsourcestart = startposition;
switch (this.tagvalue) {
case tag_link_value:
case tag_linkplain_value:
singletypereference.completionflags |= only_inline_tag;
case tag_see_value:
singletypereference.completionflags |= replace_tag;
break;
}
} else if (this.completionnode instanceof completiononjavadocqualifiedtypereference) {
completiononjavadocqualifiedtypereference qualifiedtyperef = (completiononjavadocqualifiedtypereference) this.completionnode;
qualifiedtyperef.tagsourcestart = startposition;
switch (this.tagvalue) {
case tag_link_value:
case tag_linkplain_value:
qualifiedtyperef.completionflags |= only_inline_tag;
case tag_see_value:
qualifiedtyperef.completionflags |= replace_tag;
break;
}
}
//										*/
}
}
} catch (invalidinputexception e) {
consumetoken();
}
this.scanner.tokenizewhitespace = true;
break;
default :
consumetoken();
typeref = null;
break;
}
previoustoken = token;
}
}
finally {
this.scanner.tokenizewhitespace = tokenizewhitespace;
this.pushtext = false;
}

// reset position to avoid missing tokens when new line was encountered
this.index = end;
this.scanner.currentposition = end;
consumetoken();

if (this.completionnode != null) {
if (this.inlinetagstarted) {
this.completionnode.addcompletionflags(completiononjavadoc.formal_reference);
} else {
this.completionnode.addcompletionflags(completiononjavadoc.text);
}
}
}
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#readtoken()
*/
protected int readtoken() throws invalidinputexception {
int token = super.readtoken();
if (token == terminaltokens.tokennameidentifier && this.scanner.currentposition == this.scanner.startposition) {
// scanner is looping on empty token => read it...
this.scanner.getcurrentidentifiersource();
}
return token;
}

/*
* recover syntax on invalid qualified name.
*/
protected object syntaxrecoverqualifiedname(int primitivetoken) throws invalidinputexception {
if (this.cursorlocation == ((int)this.identifierpositionstack[this.identifierptr])) {
// special case of completion just before the dot.
return createtypereference(primitivetoken);
}
int idlength = this.identifierlengthstack[this.identifierlengthptr];
char[][] tokens = new char[idlength][];
int startptr = this.identifierptr-idlength+1;
system.arraycopy(this.identifierstack, startptr, tokens, 0, idlength);
long[] positions = new long[idlength+1];
system.arraycopy(this.identifierpositionstack, startptr, positions, 0, idlength);
positions[idlength] = (((long)this.tokenpreviousposition)<<32) + this.tokenpreviousposition;
this.completionnode = new completiononjavadocqualifiedtypereference(tokens, charoperation.no_char, positions, this.tagsourcestart, this.tagsourceend);

if (completionengine.debug) {
system.out.println("	completion partial qualified type="+this.completionnode); //$non-nls-1$
}
return this.completionnode;
}

/*
* recover syntax on type argument in invalid method/constructor reference
*/
protected object syntaxrecoverargumenttype(object receiver, list arguments, object argument) throws invalidinputexception {
if (this.completionnode != null && !this.pushtext) {
this.completionnode.addcompletionflags(completiononjavadoc.base_types);
if (this.completionnode instanceof completiononjavadocsingletypereference) {
char[] token = ((completiononjavadocsingletypereference)this.completionnode).token;
if (token != null && token.length > 0) {
return this.completionnode;
}
} else {
return this.completionnode;
}
}
// filter empty token
if (this.completionnode instanceof completiononjavadocsingletypereference) {
completiononjavadocsingletypereference singletypereference = (completiononjavadocsingletypereference) this.completionnode;
if (singletypereference.token != null && singletypereference.token.length > 0) {
arguments.add(argument);
}
} else if (this.completionnode instanceof completiononjavadocqualifiedtypereference) {
completiononjavadocqualifiedtypereference qualifiedtypereference = (completiononjavadocqualifiedtypereference) this.completionnode;
if (qualifiedtypereference.tokens != null && qualifiedtypereference.tokens.length == qualifiedtypereference.sourcepositions.length) {
arguments.add(argument);
}
} else {
arguments.add(argument);
}
object methodref = super.createmethodreference(receiver, arguments);
if (methodref instanceof javadocmessagesend) {
javadocmessagesend msgsend = (javadocmessagesend) methodref;
if (this.index > this.cursorlocation) {
msgsend.sourceend = this.tokenpreviousposition-1;
}
int namestart = (int) (msgsend.namesourceposition >>> 32);
int nameend = (int) msgsend.namesourceposition;
if ((namestart <= (this.cursorlocation+1) && this.cursorlocation <= nameend)) {
this.completionnode = new completiononjavadocfieldreference(msgsend, this.memberstart);
} else {
this.completionnode = new completiononjavadocmessagesend(msgsend, this.memberstart);
}
} else if (methodref instanceof javadocallocationexpression) {
javadocallocationexpression allocexp = (javadocallocationexpression) methodref;
if (this.index > this.cursorlocation) {
allocexp.sourceend = this.tokenpreviousposition-1;
}
this.completionnode = new completiononjavadocallocationexpression(allocexp, this.memberstart);
}
if (completionengine.debug) {
system.out.println("	completion method="+this.completionnode); //$non-nls-1$
}
return this.completionnode;
}

/*
* recover syntax on empty type argument in invalid method/constructor reference
*/
protected object syntaxrecoveremptyargumenttype(object methodref) throws invalidinputexception {
if (methodref instanceof javadocmessagesend) {
javadocmessagesend msgsend = (javadocmessagesend) methodref;
if (this.index > this.cursorlocation) {
msgsend.sourceend = this.tokenpreviousposition-1;
}
this.completionnode = new completiononjavadocmessagesend(msgsend, this.memberstart);
} else if (methodref instanceof javadocallocationexpression) {
javadocallocationexpression allocexp = (javadocallocationexpression) methodref;
if (this.index > this.cursorlocation) {
allocexp.sourceend = this.tokenpreviousposition-1;
}
this.completionnode = new completiononjavadocallocationexpression(allocexp, this.memberstart);
}
if (completionengine.debug) {
system.out.println("	completion method="+this.completionnode); //$non-nls-1$
}
return this.completionnode;
}

/*
* store completion node into doc comment.
*/
protected void updatedoccomment() {
super.updatedoccomment();
if (this.completionnode instanceof expression) {
getcompletionparser().assistnodeparent = this.doccomment;
getcompletionparser().assistnode = (astnode) this.completionnode;
getcompletionjavadoc().completionnode = (expression) this.completionnode;
}
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#verifyspaceorendcomment()
*/
protected boolean verifyspaceorendcomment() {
completionscanner completionscanner = (completionscanner) this.scanner;
if (completionscanner.completionidentifier != null && completionscanner.completedidentifierstart <= this.cursorlocation && this.cursorlocation <= completionscanner.completedidentifierend) {
// if we're on completion location do not verify end...
return true;
}
return super.verifyspaceorendcomment();
}

}
