/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.arraybinding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;

public class arrayreference extends reference {

public expression receiver;
public expression position;

public arrayreference(expression rec, expression pos) {
this.receiver = rec;
this.position = pos;
this.sourcestart = rec.sourcestart;
}

public flowinfo analyseassignment(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo, assignment assignment, boolean compoundassignment) {
// todo (maxime) optimization: unconditionalinits is applied to all existing calls
if (assignment.expression == null) {
return analysecode(currentscope, flowcontext, flowinfo);
}
return assignment
.expression
.analysecode(
currentscope,
flowcontext,
analysecode(currentscope, flowcontext, flowinfo).unconditionalinits());
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
this.receiver.checknpe(currentscope, flowcontext, flowinfo);
flowinfo = this.receiver.analysecode(currentscope, flowcontext, flowinfo);
return this.position.analysecode(currentscope, flowcontext, flowinfo);
}

public void generateassignment(blockscope currentscope, codestream codestream, assignment assignment, boolean valuerequired) {
int pc = codestream.position;
this.receiver.generatecode(currentscope, codestream, true);
if (this.receiver instanceof castexpression	// ((type[])null)[0]
&& ((castexpression)this.receiver).innermostcastedexpression().resolvedtype == typebinding.null){
codestream.checkcast(this.receiver.resolvedtype);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
this.position.generatecode(currentscope, codestream, true);
assignment.expression.generatecode(currentscope, codestream, true);
codestream.arrayatput(this.resolvedtype.id, valuerequired);
if (valuerequired) {
codestream.generateimplicitconversion(assignment.implicitconversion);
}
}

/**
* code generation for a array reference
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
this.receiver.generatecode(currentscope, codestream, true);
if (this.receiver instanceof castexpression	// ((type[])null)[0]
&& ((castexpression)this.receiver).innermostcastedexpression().resolvedtype == typebinding.null){
codestream.checkcast(this.receiver.resolvedtype);
}
this.position.generatecode(currentscope, codestream, true);
codestream.arrayat(this.resolvedtype.id);
// generating code for the potential runtime type checking
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else {
boolean isunboxing = (this.implicitconversion & typeids.unboxing) != 0;
// conversion only generated if unboxing
if (isunboxing) codestream.generateimplicitconversion(this.implicitconversion);
switch (isunboxing ? postconversiontype(currentscope).id : this.resolvedtype.id) {
case t_long :
case t_double :
codestream.pop2();
break;
default :
codestream.pop();
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public void generatecompoundassignment(blockscope currentscope, codestream codestream, expression expression, int operator, int assignmentimplicitconversion, boolean valuerequired) {
this.receiver.generatecode(currentscope, codestream, true);
if (this.receiver instanceof castexpression	// ((type[])null)[0]
&& ((castexpression)this.receiver).innermostcastedexpression().resolvedtype == typebinding.null){
codestream.checkcast(this.receiver.resolvedtype);
}
this.position.generatecode(currentscope, codestream, true);
codestream.dup2();
codestream.arrayat(this.resolvedtype.id);
int operationtypeid;
switch(operationtypeid = (this.implicitconversion & typeids.implicit_conversion_mask) >> 4) {
case t_javalangstring :
case t_javalangobject :
case t_undefined :
codestream.generatestringconcatenationappend(currentscope, null, expression);
break;
default :
// promote the array reference to the suitable operation type
codestream.generateimplicitconversion(this.implicitconversion);
// generate the increment value (will by itself  be promoted to the operation value)
if (expression == intliteral.one) { // prefix operation
codestream.generateconstant(expression.constant, this.implicitconversion);
} else {
expression.generatecode(currentscope, codestream, true);
}
// perform the operation
codestream.sendoperator(operator, operationtypeid);
// cast the value back to the array reference type
codestream.generateimplicitconversion(assignmentimplicitconversion);
}
codestream.arrayatput(this.resolvedtype.id, valuerequired);
}

public void generatepostincrement(blockscope currentscope, codestream codestream, compoundassignment postincrement, boolean valuerequired) {
this.receiver.generatecode(currentscope, codestream, true);
if (this.receiver instanceof castexpression	// ((type[])null)[0]
&& ((castexpression)this.receiver).innermostcastedexpression().resolvedtype == typebinding.null){
codestream.checkcast(this.receiver.resolvedtype);
}
this.position.generatecode(currentscope, codestream, true);
codestream.dup2();
codestream.arrayat(this.resolvedtype.id);
if (valuerequired) {
switch(this.resolvedtype.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2_x2();
break;
default :
codestream.dup_x2();
break;
}
}
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generateconstant(
postincrement.expression.constant,
this.implicitconversion);
codestream.sendoperator(postincrement.operator, this.implicitconversion & typeids.compile_type_mask);
codestream.generateimplicitconversion(
postincrement.preassignimplicitconversion);
codestream.arrayatput(this.resolvedtype.id, false);
}

public int nullstatus(flowinfo flowinfo) {
return flowinfo.unknown;
}

public stringbuffer printexpression(int indent, stringbuffer output) {
this.receiver.printexpression(0, output).append('[');
return this.position.printexpression(0, output).append(']');
}

public typebinding resolvetype(blockscope scope) {
this.constant = constant.notaconstant;
if (this.receiver instanceof castexpression	// no cast check for ((type[])null)[0]
&& ((castexpression)this.receiver).innermostcastedexpression() instanceof nullliteral) {
this.receiver.bits |= astnode.disableunnecessarycastcheck; // will check later on
}
typebinding arraytype = this.receiver.resolvetype(scope);
if (arraytype != null) {
this.receiver.computeconversion(scope, arraytype, arraytype);
if (arraytype.isarraytype()) {
typebinding elementtype = ((arraybinding) arraytype).elementstype();
this.resolvedtype = ((this.bits & astnode.isstrictlyassigned) == 0) ? elementtype.capture(scope, this.sourceend) : elementtype;
} else {
scope.problemreporter().referencemustbearraytypeat(arraytype, this);
}
}
typebinding positiontype = this.position.resolvetypeexpecting(scope, typebinding.int);
if (positiontype != null) {
this.position.computeconversion(scope, typebinding.int, positiontype);
}
return this.resolvedtype;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
this.receiver.traverse(visitor, scope);
this.position.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
