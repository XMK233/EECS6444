/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.iproblem;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;
import org.eclipse.jdt.internal.compiler.util.util;

public class fielddeclaration extends abstractvariabledeclaration {

public fieldbinding binding;
public javadoc javadoc;

//allows to retrieve both the "type" part of the declaration (part1)
//and also the part that decribe the name and the init and optionally
//some other dimension ! ....
//public int[] a, b[] = x, c ;
//for b that would give for
// - part1 : public int[]
// - part2 : b[] = x,

public int endpart1position;
public int endpart2position;

public fielddeclaration() {
// for subtypes or conversion
}

public fielddeclaration(	char[] name, int sourcestart, int sourceend) {
this.name = name;
//due to some declaration like
// int x, y = 3, z , x ;
//the sourcestart and the sourceend is only on  the name
this.sourcestart = sourcestart;
this.sourceend = sourceend;
}

public flowinfo analysecode(methodscope initializationscope, flowcontext flowcontext, flowinfo flowinfo) {
if (this.binding != null && !this.binding.isused() && this.binding.isorenclosedbyprivatetype()) {
if (!initializationscope.referencecompilationunit().compilationresult.hassyntaxerror) {
initializationscope.problemreporter().unusedprivatefield(this);
}
}
// cannot define static non-constant field inside nested class
if (this.binding != null
&& this.binding.isvalidbinding()
&& this.binding.isstatic()
&& this.binding.constant() == constant.notaconstant
&& this.binding.declaringclass.isnestedtype()
&& !this.binding.declaringclass.isstatic()) {
initializationscope.problemreporter().unexpectedstaticmodifierforfield(
(sourcetypebinding) this.binding.declaringclass,
this);
}

if (this.initialization != null) {
flowinfo =
this.initialization
.analysecode(initializationscope, flowcontext, flowinfo)
.unconditionalinits();
flowinfo.markasdefinitelyassigned(this.binding);
}
return flowinfo;
}

/**
* code generation for a field declaration:
*	   standard assignment to a field
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & isreachable) == 0) {
return;
}
// do not generate initialization code if final and static (constant is then
// recorded inside the field itself).
int pc = codestream.position;
boolean isstatic;
if (this.initialization != null
&& !((isstatic = this.binding.isstatic()) && this.binding.constant() != constant.notaconstant)) {
// non-static field, need receiver
if (!isstatic)
codestream.aload_0();
// generate initialization value
this.initialization.generatecode(currentscope, codestream, true);
// store into field
if (isstatic) {
codestream.fieldaccess(opcodes.opc_putstatic, this.binding, null /* default declaringclass */);
} else {
codestream.fieldaccess(opcodes.opc_putfield, this.binding, null /* default declaringclass */);
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.abstractvariabledeclaration#getkind()
*/
public int getkind() {
return this.type == null ? enum_constant : field;
}

public boolean isstatic() {
if (this.binding != null)
return this.binding.isstatic();
return (this.modifiers & classfileconstants.accstatic) != 0;
}

public stringbuffer printstatement(int indent, stringbuffer output) {
if (this.javadoc != null) {
this.javadoc.print(indent, output);
}
return super.printstatement(indent, output);
}

public void resolve(methodscope initializationscope) {
// the two <constant = constant.notaconstant> could be regrouped into
// a single line but it is clearer to have two lines while the reason of their
// existence is not at all the same. see comment for the second one.

//--------------------------------------------------------
if ((this.bits & astnode.hasbeenresolved) != 0) return;
if (this.binding == null || !this.binding.isvalidbinding()) return;

this.bits |= astnode.hasbeenresolved;

// check if field is hiding some variable - issue is that field binding already got inserted in scope
// thus must lookup separately in super type and outer context
classscope classscope = initializationscope.enclosingclassscope();

if (classscope != null) {
checkhiding: {
sourcetypebinding declaringtype = classscope.enclosingsourcetype();
checkhidingsuperfield: {
if (declaringtype.superclass == null) break checkhidingsuperfield;
fieldbinding existingvariable = classscope.findfield(declaringtype.superclass, this.name, this,  false /*do not resolve hidden field*/);
if (existingvariable == null) break checkhidingsuperfield; // keep checking outer scenario
if (!existingvariable.isvalidbinding())  break checkhidingsuperfield; // keep checking outer scenario
if (existingvariable.original() == this.binding) break checkhidingsuperfield; // keep checking outer scenario
if (!existingvariable.canbeseenby(declaringtype, this, initializationscope)) break checkhidingsuperfield; // keep checking outer scenario
// collision with supertype field
initializationscope.problemreporter().fieldhiding(this, existingvariable);
break checkhiding; // already found a matching field
}
// only corner case is: lookup of outer field through static declaringtype, which isn't detected by #getbinding as lookup starts
// from outer scope. subsequent static contexts are detected for free.
scope outerscope = classscope.parent;
if (outerscope.kind == scope.compilation_unit_scope) break checkhiding;
binding existingvariable = outerscope.getbinding(this.name, binding.variable, this, false /*do not resolve hidden field*/);
if (existingvariable == null) break checkhiding;
if (!existingvariable.isvalidbinding()) break checkhiding;
if (existingvariable == this.binding) break checkhiding;
if (existingvariable instanceof fieldbinding) {
fieldbinding existingfield = (fieldbinding) existingvariable;
if (existingfield.original() == this.binding) break checkhiding;
if (!existingfield.isstatic() && declaringtype.isstatic()) break checkhiding;
}
// collision with outer field or local variable
initializationscope.problemreporter().fieldhiding(this, existingvariable);
}
}

if (this.type != null ) { // enum constants have no declared type
this.type.resolvedtype = this.binding.type; // update binding for type reference
}

fieldbinding previousfield = initializationscope.initializedfield;
int previousfieldid = initializationscope.lastvisiblefieldid;
try {
initializationscope.initializedfield = this.binding;
initializationscope.lastvisiblefieldid = this.binding.id;

resolveannotations(initializationscope, this.annotations, this.binding);
// check @@deprecated annotation presence
if ((this.binding.getannotationtagbits() & tagbits.annotationdeprecated) == 0
&& (this.binding.modifiers & classfileconstants.accdeprecated) != 0
&& initializationscope.compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
initializationscope.problemreporter().missingdeprecatedannotationforfield(this);
}
// the resolution of the initialization hasn't been done
if (this.initialization == null) {
this.binding.setconstant(constant.notaconstant);
} else {
// break dead-lock cycles by forcing constant to notaconstant
this.binding.setconstant(constant.notaconstant);

typebinding fieldtype = this.binding.type;
typebinding initializationtype;
this.initialization.setexpectedtype(fieldtype); // needed in case of generic method invocation
if (this.initialization instanceof arrayinitializer) {

if ((initializationtype = this.initialization.resolvetypeexpecting(initializationscope, fieldtype)) != null) {
((arrayinitializer) this.initialization).binding = (arraybinding) initializationtype;
this.initialization.computeconversion(initializationscope, fieldtype, initializationtype);
}
} else if ((initializationtype = this.initialization.resolvetype(initializationscope)) != null) {

if (fieldtype != initializationtype) // must call before computeconversion() and typemismatcherror()
initializationscope.compilationunitscope().recordtypeconversion(fieldtype, initializationtype);
if (this.initialization.isconstantvalueoftypeassignabletotype(initializationtype, fieldtype)
|| initializationtype.iscompatiblewith(fieldtype)) {
this.initialization.computeconversion(initializationscope, fieldtype, initializationtype);
if (initializationtype.needsuncheckedconversion(fieldtype)) {
initializationscope.problemreporter().unsafetypeconversion(this.initialization, initializationtype, fieldtype);
}
if (this.initialization instanceof castexpression
&& (this.initialization.bits & astnode.unnecessarycast) == 0) {
castexpression.checkneedforassignedcast(initializationscope, fieldtype, (castexpression) this.initialization);
}
} else if (isboxingcompatible(initializationtype, fieldtype, this.initialization, initializationscope)) {
this.initialization.computeconversion(initializationscope, fieldtype, initializationtype);
if (this.initialization instanceof castexpression
&& (this.initialization.bits & astnode.unnecessarycast) == 0) {
castexpression.checkneedforassignedcast(initializationscope, fieldtype, (castexpression) this.initialization);
}
} else {
if ((fieldtype.tagbits & tagbits.hasmissingtype) == 0) {
// if problem already got signaled on type, do not report secondary problem
initializationscope.problemreporter().typemismatcherror(initializationtype, fieldtype, this.initialization, null);
}
}
if (this.binding.isfinal()){ // cast from constant actual type to variable type
this.binding.setconstant(this.initialization.constant.castto((this.binding.type.id << 4) + this.initialization.constant.typeid()));
}
} else {
this.binding.setconstant(constant.notaconstant);
}
// check for assignment with no effect
if (this.binding == expression.getdirectbinding(this.initialization)) {
initializationscope.problemreporter().assignmenthasnoeffect(this, this.name);
}
}
// resolve javadoc comment if one is present
if (this.javadoc != null) {
this.javadoc.resolve(initializationscope);
} else if (this.binding != null && this.binding.declaringclass != null && !this.binding.declaringclass.islocaltype()) {
// set javadoc visibility
int javadocvisibility = this.binding.modifiers & extracompilermodifiers.accvisibilitymask;
problemreporter reporter = initializationscope.problemreporter();
int severity = reporter.computeseverity(iproblem.javadocmissing);
if (severity != problemseverities.ignore) {
if (classscope != null) {
javadocvisibility = util.computeoutermostvisibility(classscope.referencetype(), javadocvisibility);
}
int javadocmodifiers = (this.binding.modifiers & ~extracompilermodifiers.accvisibilitymask) | javadocvisibility;
reporter.javadocmissing(this.sourcestart, this.sourceend, severity, javadocmodifiers);
}
}
} finally {
initializationscope.initializedfield = previousfield;
initializationscope.lastvisiblefieldid = previousfieldid;
if (this.binding.constant() == null)
this.binding.setconstant(constant.notaconstant);
}
}

public void traverse(astvisitor visitor, methodscope scope) {
if (visitor.visit(this, scope)) {
if (this.javadoc != null) {
this.javadoc.traverse(visitor, scope);
}
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, scope);
}
if (this.type != null) {
this.type.traverse(visitor, scope);
}
if (this.initialization != null)
this.initialization.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
