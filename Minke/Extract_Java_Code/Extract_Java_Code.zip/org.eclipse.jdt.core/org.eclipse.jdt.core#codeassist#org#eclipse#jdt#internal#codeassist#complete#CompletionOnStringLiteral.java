/*******************************************************************************
* copyright (c) 2005, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.ast.stringliteral;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

/*
* completion node build by the parser in any case it was intending to
* reduce a string literal.
* e.g.
*
*	class x {
*    void foo() {
*      string s = "a[cursor]"
*    }
*  }
*
*	---> class x {
*         void foo() {
*           string s = <completeonstringliteral:a>
*         }
*       }
*/

public class completiononstringliteral extends stringliteral {
public int contentstart;
public int contentend;
public completiononstringliteral(char[] token, int s, int e, int cs, int ce, int linenumber) {
super(token, s, e, linenumber);
this.contentstart = cs;
this.contentend = ce;
}

public completiononstringliteral(int s, int e, int cs, int ce) {
super(s,e);
this.contentstart = cs;
this.contentend = ce;
}
public typebinding resolvetype(classscope scope) {
throw new completionnodefound(this, null, scope);
}
public typebinding resolvetype(blockscope scope) {
throw new completionnodefound(this, null, scope);
}

public stringbuffer printexpression(int indent, stringbuffer output) {
output.append("<completiononstring:"); //$non-nls-1$
output = super.printexpression(indent, output);
return output.append('>');
}
}
