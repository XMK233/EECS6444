/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.env.iconstants;
import org.eclipse.jdt.internal.compiler.lookup.*;


public class annotationargument extends argument {

public annotationargument(char[] name, int startposition, int endposition) {
super(name, (((long) startposition) << 32) + endposition, null, iconstants.accdefault);
this.bits |= insideannotation;
}

public annotationargument(char[] name, int startposition, int endposition, typereference typeref) {
this(name, startposition, endposition);
this.type = typeref;
this.bits |= insideannotation;
}

public stringbuffer print(int indent, stringbuffer output) {

if (type != null) {
type.print(0, output).append(' ');
}
return output.append(this.name);
}

public void resolve(blockscope scope) {

binding existingvariable = scope.getbinding(name, bindingids.variable, this, true /*resolve*/);
if (existingvariable != null && existingvariable.isvalidbinding()){
if (existingvariable instanceof localvariablebinding && this.hiddenvariabledepth == 0) {
localvariablebinding local = (localvariablebinding) existingvariable;
if (local.isargument) {
this.binding = local;
return;
}
}
}
scope.problemreporter().annotationinvalidparamname(this, false);
}

/* (non-javadoc)
* redefine to capture annotation specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(iabstractsyntaxtreevisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (type != null) {
type.traverse(visitor, scope);
}
if (initialization != null) {
initialization.traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}

}
