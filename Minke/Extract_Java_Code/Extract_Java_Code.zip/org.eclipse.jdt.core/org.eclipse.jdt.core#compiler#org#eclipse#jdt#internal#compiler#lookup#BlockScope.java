/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;

public class blockscope extends scope {

// local variable management
public localvariablebinding[] locals;
public int localindex; // position for next variable
public int startindex;	// start position in this scope - for ordering scopes vs. variables
public int offset; // for variable allocation throughout scopes
public int maxoffset; // for variable allocation throughout scopes

// finally scopes must be shifted behind respective try&catch scope(s) so as to avoid
// collisions of secret variables (return address, save value).
public blockscope[] shiftscopes;

public scope[] subscopes = new scope[1]; // need access from code assist
public int subscopecount = 0; // need access from code assist
// record the current case statement being processed (for entire switch case block).
public casestatement enclosingcase; // from 1.4 on, local types should not be accessed across switch case blocks (52221)

public final static variablebinding[] emulationpathtoimplicitthis = {};
public final static variablebinding[] noenclosinginstanceinconstructorcall = {};

public final static variablebinding[] noenclosinginstanceinstaticcontext = {};

public blockscope(blockscope parent) {
this(parent, true);
}

public blockscope(blockscope parent, boolean addtoparentscope) {
this(scope.block_scope, parent);
this.locals = new localvariablebinding[5];
if (addtoparentscope) parent.addsubscope(this);
this.startindex = parent.localindex;
}

public blockscope(blockscope parent, int variablecount) {
this(scope.block_scope, parent);
this.locals = new localvariablebinding[variablecount];
parent.addsubscope(this);
this.startindex = parent.localindex;
}

protected blockscope(int kind, scope parent) {
super(kind, parent);
}

/* create the class scope & binding for the anonymous type.
*/
public final void addanonymoustype(typedeclaration anonymoustype, referencebinding superbinding) {
classscope anonymousclassscope = new classscope(this, anonymoustype);
anonymousclassscope.buildanonymoustypebinding(
enclosingsourcetype(),
superbinding);
}

/* create the class scope & binding for the local type.
*/
public final void addlocaltype(typedeclaration localtype) {
classscope localtypescope = new classscope(this, localtype);
addsubscope(localtypescope);
localtypescope.buildlocaltypebinding(enclosingsourcetype());
}

/* insert a local variable into a given scope, updating its position
* and checking there are not too many locals or arguments allocated.
*/
public final void addlocalvariable(localvariablebinding binding) {
checkandsetmodifiersforvariable(binding);
// insert local in scope
if (this.localindex == this.locals.length)
system.arraycopy(
this.locals,
0,
(this.locals = new localvariablebinding[this.localindex * 2]),
0,
this.localindex);
this.locals[this.localindex++] = binding;

// update local variable binding
binding.declaringscope = this;
binding.id = outermostmethodscope().analysisindex++;
// share the outermost method scope analysisindex
}

public void addsubscope(scope childscope) {
if (this.subscopecount == this.subscopes.length)
system.arraycopy(
this.subscopes,
0,
(this.subscopes = new scope[this.subscopecount * 2]),
0,
this.subscopecount);
this.subscopes[this.subscopecount++] = childscope;
}

/**
* answer true if the receiver is suitable for assigning final blank fields.
* in other words, it is inside an initializer, a constructor or a clinit
*/
public final boolean allowblankfinalfieldassignment(fieldbinding binding) {
if (enclosingreceivertype() != binding.declaringclass)
return false;

methodscope methodscope = methodscope();
if (methodscope.isstatic != binding.isstatic())
return false;
return methodscope.isinsideinitializer() // inside initializer
|| ((abstractmethoddeclaration) methodscope.referencecontext).isinitializationmethod(); // inside constructor or clinit
}

string basictostring(int tab) {
string newline = "\n"; //$non-nls-1$
for (int i = tab; --i >= 0;)
newline += "\t"; //$non-nls-1$

string s = newline + "--- block scope ---"; //$non-nls-1$
newline += "\t"; //$non-nls-1$
s += newline + "locals:"; //$non-nls-1$
for (int i = 0; i < this.localindex; i++)
s += newline + "\t" + this.locals[i].tostring(); //$non-nls-1$
s += newline + "startindex = " + this.startindex; //$non-nls-1$
return s;
}

private void checkandsetmodifiersforvariable(localvariablebinding varbinding) {
int modifiers = varbinding.modifiers;
if ((modifiers & extracompilermodifiers.accalternatemodifierproblem) != 0 && varbinding.declaration != null){
problemreporter().duplicatemodifierforvariable(varbinding.declaration, this instanceof methodscope);
}
int realmodifiers = modifiers & extracompilermodifiers.accjustflag;

int unexpectedmodifiers = ~classfileconstants.accfinal;
if ((realmodifiers & unexpectedmodifiers) != 0 && varbinding.declaration != null){
problemreporter().illegalmodifierforvariable(varbinding.declaration, this instanceof methodscope);
}
varbinding.modifiers = modifiers;
}

/* compute variable positions in scopes given an initial position offset
* ignoring unused local variables.
*
* no argument is expected here (ilocal is the first non-argument local of the outermost scope)
* arguments are managed by the methodscope method
*/
void computelocalvariablepositions(int ilocal, int initoffset, codestream codestream) {
this.offset = initoffset;
this.maxoffset = initoffset;

// local variable init
int maxlocals = this.localindex;
boolean hasmorevariables = ilocal < maxlocals;

// scope init
int iscope = 0, maxscopes = this.subscopecount;
boolean hasmorescopes = maxscopes > 0;

// iterate scopes and variables in parallel
while (hasmorevariables || hasmorescopes) {
if (hasmorescopes
&& (!hasmorevariables || (this.subscopes[iscope].startindex() <= ilocal))) {
// consider subscope first
if (this.subscopes[iscope] instanceof blockscope) {
blockscope subscope = (blockscope) this.subscopes[iscope];
int suboffset = subscope.shiftscopes == null ? this.offset : subscope.maxshiftedoffset();
subscope.computelocalvariablepositions(0, suboffset, codestream);
if (subscope.maxoffset > this.maxoffset)
this.maxoffset = subscope.maxoffset;
}
hasmorescopes = ++iscope < maxscopes;
} else {

// consider variable first
localvariablebinding local = this.locals[ilocal]; // if no local at all, will be locals[ilocal]==null

// check if variable is actually used, and may force it to be preserved
boolean generatecurrentlocalvar = (local.useflag != localvariablebinding.unused && local.constant() == constant.notaconstant);

// do not report fake used variable
if (local.useflag == localvariablebinding.unused
&& (local.declaration != null) // unused (and non secret) local
&& ((local.declaration.bits & astnode.islocaldeclarationreachable) != 0)) { // declaration is reachable

if (!(local.declaration instanceof argument)) // do not report unused catch arguments
problemreporter().unusedlocalvariable(local.declaration);
}

// could be optimized out, but does need to preserve unread variables ?
if (!generatecurrentlocalvar) {
if (local.declaration != null && compileroptions().preservealllocalvariables) {
generatecurrentlocalvar = true; // force it to be preserved in the generated code
local.useflag = localvariablebinding.used;
}
}

// allocate variable
if (generatecurrentlocalvar) {

if (local.declaration != null) {
codestream.record(local); // record user-defined local variables for attribute generation
}
// assign variable position
local.resolvedposition = this.offset;

if ((local.type == typebinding.long) || (local.type == typebinding.double)) {
this.offset += 2;
} else {
this.offset++;
}
if (this.offset > 0xffff) { // no more than 65535 words of locals
problemreporter().nomoreavailablespaceforlocal(
local,
local.declaration == null ? (astnode)methodscope().referencecontext : local.declaration);
}
} else {
local.resolvedposition = -1; // not generated
}
hasmorevariables = ++ilocal < maxlocals;
}
}
if (this.offset > this.maxoffset)
this.maxoffset = this.offset;
}

/*
*	record the suitable binding denoting a synthetic field or constructor argument,
* mapping to the actual outer local variable in the scope context.
* note that this may not need any effect, in case the outer local variable does not
* need to be emulated and can directly be used as is (using its back pointer to its
* declaring scope).
*/
public void emulateouteraccess(localvariablebinding outerlocalvariable) {
blockscope outervariablescope = outerlocalvariable.declaringscope;
if (outervariablescope == null)
return; // no need to further emulate as already inserted (val$this$0)
methodscope currentmethodscope = methodscope();
if (outervariablescope.methodscope() != currentmethodscope) {
nestedtypebinding currenttype = (nestedtypebinding) enclosingsourcetype();

//do nothing for member types, pre emulation was performed already
if (!currenttype.islocaltype()) {
return;
}
// must also add a synthetic field if we're not inside a constructor
if (!currentmethodscope.isinsideinitializerorconstructor()) {
currenttype.addsyntheticargumentandfield(outerlocalvariable);
} else {
currenttype.addsyntheticargument(outerlocalvariable);
}
}
}

/* note that it must never produce a direct access to the targetenclosingtype,
* but instead a field sequence (this$2.this$1.this$0) so as to handle such a test case:
*
* class xx {
*	void foo() {
*		class a {
*			class b {
*				class c {
*					boolean foo() {
*						return (object) a.this == (object) b.this;
*					}
*				}
*			}
*		}
*		new a().new b().new c();
*	}
* }
* where we only want to deal with one enclosing instance for c (could not figure out an a for c)
*/
public final referencebinding findlocaltype(char[] name) {
long compliance = compileroptions().compliancelevel;
for (int i = this.subscopecount-1; i >= 0; i--) {
if (this.subscopes[i] instanceof classscope) {
localtypebinding sourcetype = (localtypebinding)((classscope) this.subscopes[i]).referencecontext.binding;
// from 1.4 on, local types should not be accessed across switch case blocks (52221)
if (compliance >= classfileconstants.jdk1_4 && sourcetype.enclosingcase != null) {
if (!isinsidecase(sourcetype.enclosingcase)) {
continue;
}
}
if (charoperation.equals(sourcetype.sourcename(), name))
return sourcetype;
}
}
return null;
}

/**
* returns all declarations of most specific locals containing a given position in their source range.
* this code does not recurse in nested types.
* returned array may have null values at trailing indexes.
*/
public localdeclaration[] findlocalvariabledeclarations(int position) {
// local variable init
int ilocal = 0, maxlocals = this.localindex;
boolean hasmorevariables = maxlocals > 0;
localdeclaration[] localdeclarations = null;
int declptr = 0;

// scope init
int iscope = 0, maxscopes = this.subscopecount;
boolean hasmorescopes = maxscopes > 0;

// iterate scopes and variables in parallel
while (hasmorevariables || hasmorescopes) {
if (hasmorescopes
&& (!hasmorevariables || (this.subscopes[iscope].startindex() <= ilocal))) {
// consider subscope first
scope subscope = this.subscopes[iscope];
if (subscope.kind == scope.block_scope) { // do not dive in nested types
localdeclarations = ((blockscope)subscope).findlocalvariabledeclarations(position);
if (localdeclarations != null) {
return localdeclarations;
}
}
hasmorescopes = ++iscope < maxscopes;
} else {
// consider variable first
localvariablebinding local = this.locals[ilocal]; // if no local at all, will be locals[ilocal]==null
if (local != null) {
localdeclaration localdecl = local.declaration;
if (localdecl != null) {
if (localdecl.declarationsourcestart <= position) {
if (position <= localdecl.declarationsourceend) {
if (localdeclarations == null) {
localdeclarations = new localdeclaration[maxlocals];
}
localdeclarations[declptr++] = localdecl;
}
} else {
return localdeclarations;
}
}
}
hasmorevariables = ++ilocal < maxlocals;
if (!hasmorevariables && localdeclarations != null) {
return localdeclarations;
}
}
}
return null;
}

public localvariablebinding findvariable(char[] variablename) {
int varlength = variablename.length;
for (int i = this.localindex-1; i >= 0; i--) { // lookup backward to reach latest additions first
localvariablebinding local;
char[] localname;
if ((localname = (local = this.locals[i]).name).length == varlength && charoperation.equals(localname, variablename))
return local;
}
return null;
}

/* api
* flag is a mask of the following values variable (= field or local), type.
* only bindings corresponding to the mask will be answered.
*
*	if the variable mask is set then
*		if the first name provided is a field (or local) then the field (or local) is answered
*		otherwise, package names and type names are consumed until a field is found.
*		in this case, the field is answered.
*
*	if the type mask is set,
*		package names and type names are consumed until the end of the input.
*		only if all of the input is consumed is the type answered
*
*	all other conditions are errors, and a problem binding is returned.
*
*	note: if a problem binding is returned, senders should extract the compound name
*	from the binding & not assume the problem applies to the entire compoundname.
*
*	the variable mask has precedence over the type mask.
*
*	invocationsite implements
*		issuperaccess(); this is used to determine if the discovered field is visible.
*		setfieldindex(int); this is used to record the number of names that were consumed.
*
*	for example, getbinding({"foo","y","q", variable, site) will answer
*	the binding for the field or local named "foo" (or an error binding if none exists).
*	in addition, setfieldindex(1) will be sent to the invocation site.
*	if a type named "foo" exists, it will not be detected (and an error binding will be answered)
*
*	important note: this method is written under the assumption that compoundname is longer than length 1.
*/
public binding getbinding(char[][] compoundname, int mask, invocationsite invocationsite, boolean needresolve) {
binding binding = getbinding(compoundname[0], mask | binding.type | binding.package, invocationsite, needresolve);
invocationsite.setfieldindex(1);
if (binding instanceof variablebinding) return binding;
compilationunitscope unitscope = compilationunitscope();
// in the problem case, we want to ensure we record the qualified dependency in case a type is added
// and we do not know that its package was also added (can happen with compilationparticipants)
unitscope.recordqualifiedreference(compoundname);
if (!binding.isvalidbinding()) return binding;

int length = compoundname.length;
int currentindex = 1;
foundtype : if (binding instanceof packagebinding) {
packagebinding packagebinding = (packagebinding) binding;
while (currentindex < length) {
unitscope.recordreference(packagebinding.compoundname, compoundname[currentindex]);
binding = packagebinding.gettypeorpackage(compoundname[currentindex++]);
invocationsite.setfieldindex(currentindex);
if (binding == null) {
if (currentindex == length) {
// must be a type if its the last name, otherwise we have no idea if its a package or type
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
null,
problemreasons.notfound);
}
return new problembinding(
charoperation.subarray(compoundname, 0, currentindex),
problemreasons.notfound);
}
if (binding instanceof referencebinding) {
if (!binding.isvalidbinding())
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
(referencebinding)((referencebinding)binding).closestmatch(),
binding.problemid());
if (!((referencebinding) binding).canbeseenby(this))
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
(referencebinding) binding,
problemreasons.notvisible);
break foundtype;
}
packagebinding = (packagebinding) binding;
}

// it is illegal to request a package from this method.
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
null,
problemreasons.notfound);
}

// know binding is now a referencebinding
referencebinding referencebinding = (referencebinding) binding;
binding = environment().converttorawtype(referencebinding, false /*do not force conversion of enclosing types*/);
if (invocationsite instanceof astnode) {
astnode invocationnode = (astnode) invocationsite;
if (invocationnode.istypeusedeprecated(referencebinding, this)) {
problemreporter().deprecatedtype(referencebinding, invocationnode);
}
}
while (currentindex < length) {
referencebinding = (referencebinding) binding;
char[] nextname = compoundname[currentindex++];
invocationsite.setfieldindex(currentindex);
invocationsite.setactualreceivertype(referencebinding);
if ((mask & binding.field) != 0 && (binding = findfield(referencebinding, nextname, invocationsite, true /*resolve*/)) != null) {
if (!binding.isvalidbinding()) {
return new problemfieldbinding(
((problemfieldbinding)binding).closestmatch,
((problemfieldbinding)binding).declaringclass,
charoperation.concatwith(charoperation.subarray(compoundname, 0, currentindex), '.'),
binding.problemid());
}
break; // binding is now a field
}
if ((binding = findmembertype(nextname, referencebinding)) == null) {
if ((mask & binding.field) != 0) {
return new problemfieldbinding(
null,
referencebinding,
nextname,
problemreasons.notfound);
} else if ((mask & binding.variable) != 0) {
return new problembinding(
charoperation.subarray(compoundname, 0, currentindex),
referencebinding,
problemreasons.notfound);
}
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
referencebinding,
problemreasons.notfound);
}
// binding is a referencebinding
if (!binding.isvalidbinding())
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
(referencebinding)((referencebinding)binding).closestmatch(),
binding.problemid());
if (invocationsite instanceof astnode) {
referencebinding = (referencebinding) binding;
astnode invocationnode = (astnode) invocationsite;
if (invocationnode.istypeusedeprecated(referencebinding, this)) {
problemreporter().deprecatedtype(referencebinding, invocationnode);
}
}
}
if ((mask & binding.field) != 0 && (binding instanceof fieldbinding)) {
// was looking for a field and found a field
fieldbinding field = (fieldbinding) binding;
if (!field.isstatic())
return new problemfieldbinding(
field,
field.declaringclass,
charoperation.concatwith(charoperation.subarray(compoundname, 0, currentindex), '.'),
problemreasons.nonstaticreferenceinstaticcontext);
return binding;
}
if ((mask & binding.type) != 0 && (binding instanceof referencebinding)) {
// was looking for a type and found a type
return binding;
}

// handle the case when a field or type was asked for but we resolved the compoundname to a type or field
return new problembinding(
charoperation.subarray(compoundname, 0, currentindex),
problemreasons.notfound);
}

// added for code assist... not public api
public final binding getbinding(char[][] compoundname, invocationsite invocationsite) {
int currentindex = 0;
int length = compoundname.length;
binding binding =
getbinding(
compoundname[currentindex++],
binding.variable | binding.type | binding.package,
invocationsite,
true /*resolve*/);
if (!binding.isvalidbinding())
return binding;

foundtype : if (binding instanceof packagebinding) {
while (currentindex < length) {
packagebinding packagebinding = (packagebinding) binding;
binding = packagebinding.gettypeorpackage(compoundname[currentindex++]);
if (binding == null) {
if (currentindex == length) {
// must be a type if its the last name, otherwise we have no idea if its a package or type
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
null,
problemreasons.notfound);
}
return new problembinding(
charoperation.subarray(compoundname, 0, currentindex),
problemreasons.notfound);
}
if (binding instanceof referencebinding) {
if (!binding.isvalidbinding())
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
(referencebinding)((referencebinding)binding).closestmatch(),
binding.problemid());
if (!((referencebinding) binding).canbeseenby(this))
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
(referencebinding) binding,
problemreasons.notvisible);
break foundtype;
}
}
return binding;
}

foundfield : if (binding instanceof referencebinding) {
while (currentindex < length) {
referencebinding typebinding = (referencebinding) binding;
char[] nextname = compoundname[currentindex++];
typebinding receivertype = typebinding.capture(this, invocationsite.sourceend());
if ((binding = findfield(receivertype, nextname, invocationsite, true /*resolve*/)) != null) {
if (!binding.isvalidbinding()) {
return new problemfieldbinding(
(fieldbinding) binding,
((fieldbinding) binding).declaringclass,
charoperation.concatwith(charoperation.subarray(compoundname, 0, currentindex), '.'),
binding.problemid());
}
if (!((fieldbinding) binding).isstatic())
return new problemfieldbinding(
(fieldbinding) binding,
((fieldbinding) binding).declaringclass,
charoperation.concatwith(charoperation.subarray(compoundname, 0, currentindex), '.'),
problemreasons.nonstaticreferenceinstaticcontext);
break foundfield; // binding is now a field
}
if ((binding = findmembertype(nextname, typebinding)) == null) {
return new problembinding(
charoperation.subarray(compoundname, 0, currentindex),
typebinding,
problemreasons.notfound);
}
if (!binding.isvalidbinding()) {
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
(referencebinding)((referencebinding)binding).closestmatch(),
binding.problemid());
}
}
return binding;
}

variablebinding variablebinding = (variablebinding) binding;
while (currentindex < length) {
typebinding typebinding = variablebinding.type;
if (typebinding == null) {
return new problemfieldbinding(
null,
null,
charoperation.concatwith(charoperation.subarray(compoundname, 0, currentindex), '.'),
problemreasons.notfound);
}
typebinding receivertype = typebinding.capture(this, invocationsite.sourceend());
variablebinding = findfield(receivertype, compoundname[currentindex++], invocationsite, true /*resolve*/);
if (variablebinding == null) {
return new problemfieldbinding(
null,
receivertype instanceof referencebinding ? (referencebinding) receivertype : null,
charoperation.concatwith(charoperation.subarray(compoundname, 0, currentindex), '.'),
problemreasons.notfound);
}
if (!variablebinding.isvalidbinding())
return variablebinding;
}
return variablebinding;
}

/*
* this retrieves the argument that maps to an enclosing instance of the suitable type,
* 	if not found then answers nil -- do not create one
*
*		#implicitthis		  	 			: the implicit this will be ok
*		#((arg) this$n)						: available as a constructor arg
* 		#((arg) this$n ... this$p) 			: available as as a constructor arg + a sequence of fields
* 		#((fielddescr) this$n ... this$p) 	: available as a sequence of fields
* 		nil 		 											: not found
*
* 	note that this algorithm should answer the shortest possible sequence when
* 		shortcuts are available:
* 				this$0 . this$0 . this$0
* 		instead of
* 				this$2 . this$1 . this$0 . this$1 . this$0
* 		thus the code generation will be more compact and runtime faster
*/
public variablebinding[] getemulationpath(localvariablebinding outerlocalvariable) {
methodscope currentmethodscope = methodscope();
sourcetypebinding sourcetype = currentmethodscope.enclosingsourcetype();

// identity check
blockscope variablescope = outerlocalvariable.declaringscope;
if (variablescope == null /*val$this$0*/ || currentmethodscope == variablescope.methodscope()) {
return new variablebinding[] { outerlocalvariable };
// implicit this is good enough
}
// use synthetic constructor arguments if possible
if (currentmethodscope.isinsideinitializerorconstructor()
&& (sourcetype.isnestedtype())) {
syntheticargumentbinding syntheticarg;
if ((syntheticarg = ((nestedtypebinding) sourcetype).getsyntheticargument(outerlocalvariable)) != null) {
return new variablebinding[] { syntheticarg };
}
}
// use a synthetic field then
if (!currentmethodscope.isstatic) {
fieldbinding syntheticfield;
if ((syntheticfield = sourcetype.getsyntheticfield(outerlocalvariable)) != null) {
return new variablebinding[] { syntheticfield };
}
}
return null;
}

/*
* this retrieves the argument that maps to an enclosing instance of the suitable type,
* 	if not found then answers nil -- do not create one
*
*		#implicitthis		  	 											:  the implicit this will be ok
*		#((arg) this$n)													: available as a constructor arg
* 	#((arg) this$n access$m... access$p) 		: available as as a constructor arg + a sequence of synthetic accessors to synthetic fields
* 	#((fielddescr) this$n access#m... access$p)	: available as a first synthetic field + a sequence of synthetic accessors to synthetic fields
* 	null 		 															: not found
*	jls 15.9.2 + http://www.ergnosis.com/java-spec-report/java-language/jls-8.8.5.1-d.html
*/
public object[] getemulationpath(referencebinding targetenclosingtype, boolean onlyexactmatch, boolean denyenclosingarginconstructorcall) {
methodscope currentmethodscope = methodscope();
sourcetypebinding sourcetype = currentmethodscope.enclosingsourcetype();

// use 'this' if possible
if (!currentmethodscope.isstatic && !currentmethodscope.isconstructorcall) {
if (sourcetype == targetenclosingtype || (!onlyexactmatch && sourcetype.findsupertypeoriginatingfrom(targetenclosingtype) != null)) {
return blockscope.emulationpathtoimplicitthis; // implicit this is good enough
}
}
if (!sourcetype.isnestedtype() || sourcetype.isstatic()) { // no emulation from within non-inner types
if (currentmethodscope.isconstructorcall) {
return blockscope.noenclosinginstanceinconstructorcall;
} else if (currentmethodscope.isstatic){
return blockscope.noenclosinginstanceinstaticcontext;
}
return null;
}
boolean insideconstructor = currentmethodscope.isinsideinitializerorconstructor();
// use synthetic constructor arguments if possible
if (insideconstructor) {
syntheticargumentbinding syntheticarg;
if ((syntheticarg = ((nestedtypebinding) sourcetype).getsyntheticargument(targetenclosingtype, onlyexactmatch)) != null) {
// reject allocation and super constructor call
if (denyenclosingarginconstructorcall
&& currentmethodscope.isconstructorcall
&& (sourcetype == targetenclosingtype || (!onlyexactmatch && sourcetype.findsupertypeoriginatingfrom(targetenclosingtype) != null))) {
return blockscope.noenclosinginstanceinconstructorcall;
}
return new object[] { syntheticarg };
}
}

// use a direct synthetic field then
if (currentmethodscope.isstatic) {
return blockscope.noenclosinginstanceinstaticcontext;
}
if (sourcetype.isanonymoustype()) {
referencebinding enclosingtype = sourcetype.enclosingtype();
if (enclosingtype.isnestedtype()) {
nestedtypebinding nestedenclosingtype = (nestedtypebinding) enclosingtype;
syntheticargumentbinding enclosingargument = nestedenclosingtype.getsyntheticargument(nestedenclosingtype.enclosingtype(), onlyexactmatch);
if (enclosingargument != null) {
fieldbinding syntheticfield = sourcetype.getsyntheticfield(enclosingargument);
if (syntheticfield != null) {
if (syntheticfield.type == targetenclosingtype || (!onlyexactmatch && ((referencebinding)syntheticfield.type).findsupertypeoriginatingfrom(targetenclosingtype) != null))
return new object[] { syntheticfield };
}
}
}
}
fieldbinding syntheticfield = sourcetype.getsyntheticfield(targetenclosingtype, onlyexactmatch);
if (syntheticfield != null) {
if (currentmethodscope.isconstructorcall){
return blockscope.noenclosinginstanceinconstructorcall;
}
return new object[] { syntheticfield };
}

// could be reached through a sequence of enclosing instance link (nested members)
object[] path = new object[2]; // probably at least 2 of them
referencebinding currenttype = sourcetype.enclosingtype();
if (insideconstructor) {
path[0] = ((nestedtypebinding) sourcetype).getsyntheticargument(currenttype, onlyexactmatch);
} else {
if (currentmethodscope.isconstructorcall){
return blockscope.noenclosinginstanceinconstructorcall;
}
path[0] = sourcetype.getsyntheticfield(currenttype, onlyexactmatch);
}
if (path[0] != null) { // keep accumulating

int count = 1;
referencebinding currentenclosingtype;
while ((currentenclosingtype = currenttype.enclosingtype()) != null) {

//done?
if (currenttype == targetenclosingtype
|| (!onlyexactmatch && currenttype.findsupertypeoriginatingfrom(targetenclosingtype) != null))	break;

if (currentmethodscope != null) {
currentmethodscope = currentmethodscope.enclosingmethodscope();
if (currentmethodscope != null && currentmethodscope.isconstructorcall){
return blockscope.noenclosinginstanceinconstructorcall;
}
if (currentmethodscope != null && currentmethodscope.isstatic){
return blockscope.noenclosinginstanceinstaticcontext;
}
}

syntheticfield = ((nestedtypebinding) currenttype).getsyntheticfield(currentenclosingtype, onlyexactmatch);
if (syntheticfield == null) break;

// append inside the path
if (count == path.length) {
system.arraycopy(path, 0, (path = new object[count + 1]), 0, count);
}
// private access emulation is necessary since synthetic field is private
path[count++] = ((sourcetypebinding) syntheticfield.declaringclass).addsyntheticmethod(syntheticfield, true/*read*/, false /*not super access*/);
currenttype = currentenclosingtype;
}
if (currenttype == targetenclosingtype
|| (!onlyexactmatch && currenttype.findsupertypeoriginatingfrom(targetenclosingtype) != null)) {
return path;
}
}
return null;
}

/* answer true if the variable name already exists within the receiver's scope.
*/
public final boolean isduplicatelocalvariable(char[] name) {
blockscope current = this;
while (true) {
for (int i = 0; i < this.localindex; i++) {
if (charoperation.equals(name, current.locals[i].name))
return true;
}
if (current.kind != scope.block_scope) return false;
current = (blockscope)current.parent;
}
}

public int maxshiftedoffset() {
int max = -1;
if (this.shiftscopes != null){
for (int i = 0, length = this.shiftscopes.length; i < length; i++){
int submaxoffset = this.shiftscopes[i].maxoffset;
if (submaxoffset > max) max = submaxoffset;
}
}
return max;
}

/**
* returns true if the context requires to check initialization of final blank fields.
* in other words, it is inside an initializer, a constructor or a clinit
*/
public final boolean needblankfinalfieldinitializationcheck(fieldbinding binding) {
boolean isstatic = binding.isstatic();
referencebinding fielddeclaringclass = binding.declaringclass;
// loop in enclosing context, until reaching the field declaring context
methodscope methodscope = methodscope();
while (methodscope != null) {
if (methodscope.isstatic != isstatic)
return false;
if (!methodscope.isinsideinitializer() // inside initializer
&& !((abstractmethoddeclaration) methodscope.referencecontext).isinitializationmethod()) { // inside constructor or clinit
return false; // found some non-initializer context
}
referencebinding enclosingtype = methodscope.enclosingreceivertype();
if (enclosingtype == fielddeclaringclass) {
return true; // found the field context, no need to check any further
}
if (!enclosingtype.erasure().isanonymoustype()) {
return false; // only check inside anonymous type
}
methodscope = methodscope.enclosingmethodscope();
}
return false;
}

/* answer the problem reporter to use for raising new problems.
*
* note that as a side-effect, this updates the current reference context
* (unit, type or method) in case the problem handler decides it is necessary
* to abort.
*/
public problemreporter problemreporter() {
return outermostmethodscope().problemreporter();
}

/*
* code responsible to request some more emulation work inside the invocation type, so as to supply
* correct synthetic arguments to any allocation of the target type.
*/
public void propagateinneremulation(referencebinding targettype, boolean isenclosinginstancesupplied) {
// no need to propagate enclosing instances, they got eagerly allocated already.

syntheticargumentbinding[] syntheticarguments;
if ((syntheticarguments = targettype.syntheticouterlocalvariables()) != null) {
for (int i = 0, max = syntheticarguments.length; i < max; i++) {
syntheticargumentbinding syntheticarg = syntheticarguments[i];
// need to filter out the one that could match a supplied enclosing instance
if (!(isenclosinginstancesupplied
&& (syntheticarg.type == targettype.enclosingtype()))) {
emulateouteraccess(syntheticarg.actualouterlocalvariable);
}
}
}
}

/* answer the reference type of this scope.
*
* it is the nearest enclosing type of this scope.
*/
public typedeclaration referencetype() {
return methodscope().referencetype();
}

/*
* answer the index of this scope relatively to its parent.
* for method scope, answers -1 (not a classscope relative position)
*/
public int scopeindex() {
if (this instanceof methodscope) return -1;
blockscope parentscope = (blockscope)this.parent;
scope[] parentsubscopes = parentscope.subscopes;
for (int i = 0, max = parentscope.subscopecount; i < max; i++) {
if (parentsubscopes[i] == this) return i;
}
return -1;
}

// start position in this scope - for ordering scopes vs. variables
int startindex() {
return this.startindex;
}

public string tostring() {
return tostring(0);
}

public string tostring(int tab) {
string s = basictostring(tab);
for (int i = 0; i < this.subscopecount; i++)
if (this.subscopes[i] instanceof blockscope)
s += ((blockscope) this.subscopes[i]).tostring(tab + 1) + "\n"; //$non-nls-1$
return s;
}
}
