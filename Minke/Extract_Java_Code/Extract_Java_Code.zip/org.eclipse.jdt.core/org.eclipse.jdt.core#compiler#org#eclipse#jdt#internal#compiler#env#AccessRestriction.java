/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

public class accessrestriction {

private accessrule accessrule;
public byte classpathentrytype;
public static final byte
command_line = 0,
project = 1,
library = 2;
public string classpathentryname;

public accessrestriction(accessrule accessrule, byte classpathentrytype, string classpathentryname) {
this.accessrule = accessrule;
this.classpathentryname = classpathentryname;
this.classpathentrytype = classpathentrytype;
}

public int getproblemid() {
return this.accessrule.getproblemid();
}

public boolean ignoreifbetter() {
return this.accessrule.ignoreifbetter();
}
}
