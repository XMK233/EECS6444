/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/

package org.eclipse.jdt.internal.compiler.parser;

import org.eclipse.jdt.core.compiler.charoperation;

/**
* javadoc tag constants.
*
* @@since 3.2
*/
public interface javadoctagconstants {

// recognized tags
public static final char[] tag_deprecated = "deprecated".tochararray(); //$non-nls-1$
public static final char[] tag_param = "param".tochararray(); //$non-nls-1$
public static final char[] tag_return = "return".tochararray(); //$non-nls-1$
public static final char[] tag_throws = "throws".tochararray(); //$non-nls-1$
public static final char[] tag_exception = "exception".tochararray(); //$non-nls-1$
public static final char[] tag_see = "see".tochararray(); //$non-nls-1$
public static final char[] tag_link = "link".tochararray(); //$non-nls-1$
public static final char[] tag_linkplain = "linkplain".tochararray(); //$non-nls-1$
public static final char[] tag_inheritdoc = "inheritdoc".tochararray(); //$non-nls-1$
public static final char[] tag_value = "value".tochararray(); //$non-nls-1$
public static final char[] tag_author = "author".tochararray(); //$non-nls-1$
public static final char[] tag_code = "code".tochararray(); //$non-nls-1$
public static final char[] tag_doc_root = "docroot".tochararray(); //$non-nls-1$
public static final char[] tag_literal = "literal".tochararray(); //$non-nls-1$
public static final char[] tag_serial = "serial".tochararray(); //$non-nls-1$
public static final char[] tag_serial_data = "serialdata".tochararray(); //$non-nls-1$
public static final char[] tag_serial_field = "serialfield".tochararray(); //$non-nls-1$
public static final char[] tag_since = "since".tochararray(); //$non-nls-1$
public static final char[] tag_version = "version".tochararray(); //$non-nls-1$
public static final char[] tag_category = "category".tochararray(); //$non-nls-1$

// tags lengthes
public static final int tag_deprecated_length = tag_deprecated.length;
public static final int tag_param_length = tag_param.length;
public static final int tag_return_length = tag_return.length;
public static final int tag_throws_length = tag_throws.length;
public static final int tag_exception_length = tag_exception.length;
public static final int tag_see_length = tag_see.length;
public static final int tag_link_length = tag_link.length;
public static final int tag_linkplain_length = tag_linkplain.length;
public static final int tag_inheritdoc_length = tag_inheritdoc.length;
public static final int tag_value_length = tag_value.length;
public static final int tag_category_length = tag_category.length;
public static final int tag_author_length = tag_author.length;
public static final int tag_serial_length = tag_serial.length;
public static final int tag_serial_data_length = tag_serial_data.length;
public static final int tag_serial_field_length = tag_serial_field.length;
public static final int tag_since_length = tag_since.length;
public static final int tag_version_length = tag_version.length;
public static final int tag_code_length = tag_code.length;
public static final int tag_literal_length = tag_literal.length;
public static final int tag_doc_root_length = tag_doc_root.length;

// tags value
public static final int no_tag_value = 0;
public static final int tag_deprecated_value = 1;
public static final int tag_param_value = 2;
public static final int tag_return_value = 3;
public static final int tag_throws_value = 4;
public static final int tag_exception_value = 5;
public static final int tag_see_value = 6;
public static final int tag_link_value = 7;
public static final int tag_linkplain_value = 8;
public static final int tag_inheritdoc_value = 9;
public static final int tag_value_value = 10;
public static final int tag_category_value = 11;
public static final int tag_author_value = 12;
public static final int tag_serial_value = 13;
public static final int tag_serial_data_value = 14;
public static final int tag_serial_field_value = 15;
public static final int tag_since_value = 16;
public static final int tag_version_value = 17;
public static final int tag_code_value = 18;
public static final int tag_literal_value = 19;
public static final int tag_doc_root_value = 20;
public static final int tag_others_value = 100;

// tag names array
public static final char[][] tag_names = {
charoperation.no_char,
tag_deprecated,		/* 1 */
tag_param,				/* 2 */
tag_return,				/* 3 */
tag_throws,				/* 4 */
tag_exception,			/* 5 */
tag_see,						/* 6 */
tag_link,						/* 7 */
tag_linkplain,			/* 8 */
tag_inheritdoc,		/* 9 */
tag_value,					/* 10 */
tag_category,			/* 11 */
tag_author,				/* 12 */
tag_serial,				/* 13 */
tag_serial_data,	/* 14 */
tag_serial_field,	/* 15 */
tag_since,					/* 16 */
tag_version,				/* 17 */
tag_code,					/* 18 */
tag_literal,				/* 19 */
tag_doc_root,			/* 20 */
};

// tags expected positions
public final static int ordered_tags_number = 3;
public final static int param_tag_expected_order = 0;
public final static int throws_tag_expected_order = 1;
public final static int see_tag_expected_order = 2;

/*
* tag kinds indexes
*/
public final static int block_idx = 0;
public final static int inline_idx = 1;

// href tag
public final static char[] href_tag = {'h', 'r', 'e', 'f'};
/*
* tags versions
*/
public static final char[][][] block_tags = {
// since 1.0
{ tag_author, tag_deprecated, tag_exception, tag_param, tag_return, tag_see, tag_version, tag_category /* 1.6 tag but put here as we support it for all compliances */ },
// since 1.1
{ tag_since },
// since 1.2
{ tag_serial, tag_serial_data, tag_serial_field , tag_throws },
// since 1.3
{},
// since 1.4
{},
// since 1.5
{},
// since 1.6
{},
// since 1.7
{},
};
public static final char[][][] inline_tags = {
// since 1.0
{},
// since 1.1
{},
// since 1.2
{ tag_link },
// since 1.3
{ tag_doc_root },
// since 1.4
{ tag_inheritdoc, tag_linkplain, tag_value },
// since 1.5
{ tag_code, tag_literal },
// since 1.6
{},
// since 1.7
{},
};
public final static int inline_tags_length = inline_tags.length;
public final static int block_tags_length = block_tags.length;
public final static int all_tags_length = block_tags_length+inline_tags_length;

public final static short tag_type_none = 0;
public final static short tag_type_inline = 1;
public final static short tag_type_block = 2;

public static final short[] javadoc_tag_type = {
tag_type_none, 		// no_tag_value = 0;
tag_type_block,		// tag_deprecated_value = 1;
tag_type_block,		// tag_param_value = 2;
tag_type_block,		// tag_return_value = 3;
tag_type_block,		// tag_throws_value = 4;
tag_type_block,		// tag_exception_value = 5;
tag_type_block,		// tag_see_value = 6;
tag_type_inline,	// tag_link_value = 7;
tag_type_inline,	// tag_linkplain_value = 8;
tag_type_inline,	// tag_inheritdoc_value = 9;
tag_type_inline,	// tag_value_value = 10;
tag_type_block,		// tag_category_value = 11;
tag_type_block,		// tag_author_value = 12;
tag_type_block,		// tag_serial_value = 13;
tag_type_block,		// tag_serial_data_value = 14;
tag_type_block,		// tag_serial_field_value = 15;
tag_type_block,		// tag_since_value = 16;
tag_type_block,		// tag_version_value = 17;
tag_type_inline,	// tag_code_value = 18;
tag_type_inline,	// tag_literal_value = 19;
tag_type_inline		// tag_doc_root_value = 20;
};
/*
* tags usage
*/
public static final char[][] package_tags = {
tag_see,
tag_since,
tag_serial,
tag_author,
tag_version,
tag_category,
tag_link,
tag_linkplain,
tag_doc_root,
tag_value,
};
public static final char[][] compilation_unit_tags = {};
public static final char[][] class_tags = {
tag_see,
tag_since,
tag_deprecated,
tag_serial,
tag_author,
tag_version,
tag_param,
tag_category,
tag_link,
tag_linkplain,
tag_doc_root,
tag_value,
tag_code,
tag_literal
};
public static final char[][] field_tags = {
tag_see,
tag_since,
tag_deprecated,
tag_serial,
tag_serial_field,
tag_category,
tag_link,
tag_linkplain,
tag_doc_root,
tag_value,
tag_code,
tag_literal
};
public static final char[][] method_tags = {
tag_see,
tag_since,
tag_deprecated,
tag_param,
tag_return,
tag_throws,
tag_exception,
tag_serial_data,
tag_category,
tag_link,
tag_linkplain,
tag_inheritdoc,
tag_doc_root,
tag_value,
tag_code,
tag_literal
};
}
