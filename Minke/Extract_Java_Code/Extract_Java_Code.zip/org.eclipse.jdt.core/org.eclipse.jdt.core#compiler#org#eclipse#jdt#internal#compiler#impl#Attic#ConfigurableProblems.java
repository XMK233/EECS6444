package org.eclipse.jdt.internal.compiler.impl;
/*
* (c) copyright ibm corp. 2000, 2001.
* all rights reserved.
*/
import org.eclipse.jdt.internal.compiler.*;

// constants used to encode configurable problems (error|warning|ignore)

public interface configurableproblems {
final int unreachablecode = 0x100;
final int importproblem = 0x400;
final int methodwithconstructorname = 0x1000;
final int overriddenpackagedefaultmethod = 0x2000;
final int usingdeprecatedapi = 0x4000;
final int maskedcatchblock = 0x8000;
final int unusedlocalvariable = 0x10000;
final int unusedargument = 0x20000;
final int temporarywarning = 0x40000;
final int accessemulation = 0x80000;
final int nonexternalizedstring = 0x100000;
final int assertusedasanidentifier = 0x200000;
}
