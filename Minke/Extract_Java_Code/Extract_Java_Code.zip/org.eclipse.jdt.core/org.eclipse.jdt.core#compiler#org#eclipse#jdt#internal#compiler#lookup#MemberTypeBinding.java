/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;

public final class membertypebinding extends nestedtypebinding {
public membertypebinding(char[][] compoundname, classscope scope, sourcetypebinding enclosingtype) {
super(compoundname, scope, enclosingtype);
this.tagbits |= tagbits.membertypemask;
}
void checksyntheticargsandfields() {
if (isstatic()) return;
if (isinterface()) return;
this.addsyntheticargumentandfield(this.enclosingtype);
}
/* answer the receiver's constant pool name.
*
* note: this method should only be used during/after code gen.
*/

public char[] constantpoolname() /* java/lang/object */ {
if (this.constantpoolname != null)
return this.constantpoolname;

return this.constantpoolname = charoperation.concat(enclosingtype().constantpoolname(), this.sourcename, '$');
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#initializedeprecatedannotationtagbits()
*/
public void initializedeprecatedannotationtagbits() {
if ((this.tagbits & tagbits.deprecatedannotationresolved) == 0) {
super.initializedeprecatedannotationtagbits();
if ((this.tagbits & tagbits.annotationdeprecated) == 0) {
// check enclosing type
referencebinding enclosing;
if (((enclosing = enclosingtype()).tagbits & tagbits.deprecatedannotationresolved) == 0) {
enclosing.initializedeprecatedannotationtagbits();
}
if (enclosing.isviewedasdeprecated()) {
this.modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
}
}
}
}
public string tostring() {
return "member type : " + new string(sourcename()) + " " + super.tostring(); //$non-nls-2$ //$non-nls-1$
}
}
