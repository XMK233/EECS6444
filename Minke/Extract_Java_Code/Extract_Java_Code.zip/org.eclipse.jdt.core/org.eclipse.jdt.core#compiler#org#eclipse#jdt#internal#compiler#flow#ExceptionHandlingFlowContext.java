/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import java.util.arraylist;

import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.subroutinestatement;
import org.eclipse.jdt.internal.compiler.ast.trystatement;
import org.eclipse.jdt.internal.compiler.codegen.objectcache;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.extracompilermodifiers;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;

/**
* reflects the context of code analysis, keeping track of enclosing
*	try statements, exception handlers, etc...
*/
public class exceptionhandlingflowcontext extends flowcontext {

public final static int bitcachesize = 32; // 32 bits per int

public referencebinding[] handledexceptions;
int[] isreached;
int[] isneeded;
unconditionalflowinfo[] initsonexceptions;
objectcache indexes = new objectcache();
boolean ismethodcontext;

public unconditionalflowinfo initsonreturn;
public flowcontext initializationparent; // special parent relationship only for initialization purpose

// for dealing with anonymous constructor thrown exceptions
public arraylist extendedexceptions;

public exceptionhandlingflowcontext(
flowcontext parent,
astnode associatednode,
referencebinding[] handledexceptions,
flowcontext initializationparent,
blockscope scope,
unconditionalflowinfo flowinfo) {

super(parent, associatednode);
this.ismethodcontext = scope == scope.methodscope();
this.handledexceptions = handledexceptions;
int count = handledexceptions.length, cachesize = (count / exceptionhandlingflowcontext.bitcachesize) + 1;
this.isreached = new int[cachesize]; // none is reached by default
this.isneeded = new int[cachesize]; // none is needed by default
this.initsonexceptions = new unconditionalflowinfo[count];
boolean markexceptionsandthrowableasreached =
!this.ismethodcontext || scope.compileroptions().reportunuseddeclaredthrownexceptionexemptexceptionandthrowable;
for (int i = 0; i < count; i++) {
referencebinding handledexception = handledexceptions[i];
this.indexes.put(handledexception, i); // key type  -> value index
if (handledexception.isuncheckedexception(true)) {
if (markexceptionsandthrowableasreached ||
handledexception.id != typeids.t_javalangthrowable &&
handledexception.id != typeids.t_javalangexception) {
this.isreached[i / exceptionhandlingflowcontext.bitcachesize] |= 1 << (i % exceptionhandlingflowcontext.bitcachesize);
}
this.initsonexceptions[i] = flowinfo.unconditionalcopy();
} else {
this.initsonexceptions[i] = flowinfo.dead_end;
}
}
if (!this.ismethodcontext) {
system.arraycopy(this.isreached, 0, this.isneeded, 0, cachesize);
}
this.initsonreturn = flowinfo.dead_end;
this.	initializationparent = initializationparent;
}

public void complainifunusedexceptionhandlers(abstractmethoddeclaration method) {
methodscope scope = method.scope;
// can optionally skip overriding methods
if ((method.binding.modifiers & (extracompilermodifiers.accoverriding | extracompilermodifiers.accimplementing)) != 0
&& !scope.compileroptions().reportunuseddeclaredthrownexceptionwhenoverriding) {
return;
}

// report errors for unreachable exception handlers
typebinding[] doccommentreferences = null;
int doccommentreferenceslength = 0;
if (scope.compileroptions().
reportunuseddeclaredthrownexceptionincludedoccommentreference &&
method.javadoc != null &&
method.javadoc.exceptionreferences != null &&
(doccommentreferenceslength = method.javadoc.exceptionreferences.length) > 0) {
doccommentreferences = new typebinding[doccommentreferenceslength];
for (int i = 0; i < doccommentreferenceslength; i++) {
doccommentreferences[i] = method.javadoc.exceptionreferences[i].resolvedtype;
}
}
nexthandledexception: for (int i = 0, count = this.handledexceptions.length; i < count; i++) {
int index = this.indexes.get(this.handledexceptions[i]);
if ((this.isreached[index / exceptionhandlingflowcontext.bitcachesize] & 1 << (index % exceptionhandlingflowcontext.bitcachesize)) == 0) {
for (int j = 0; j < doccommentreferenceslength; j++) {
if (doccommentreferences[j] == this.handledexceptions[i]) {
continue nexthandledexception;
}
}
scope.problemreporter().unuseddeclaredthrownexception(
this.handledexceptions[index],
method,
method.thrownexceptions[index]);
}
}
}

public void complainifunusedexceptionhandlers(blockscope scope,trystatement trystatement) {
// report errors for unreachable exception handlers
for (int i = 0, count = this.handledexceptions.length; i < count; i++) {
int index = this.indexes.get(this.handledexceptions[i]);
int cacheindex = index / exceptionhandlingflowcontext.bitcachesize;
int bitmask = 1 << (index % exceptionhandlingflowcontext.bitcachesize);
if ((this.isreached[cacheindex] & bitmask) == 0) {
scope.problemreporter().unreachablecatchblock(
this.handledexceptions[index],
trystatement.catcharguments[index].type);
} else {
if ((this.isneeded[cacheindex] & bitmask) == 0) {
scope.problemreporter().hiddencatchblock(
this.handledexceptions[index],
trystatement.catcharguments[index].type);
}
}
}
}

public string individualtostring() {
stringbuffer buffer = new stringbuffer("exception flow context"); //$non-nls-1$
int length = this.handledexceptions.length;
for (int i = 0; i < length; i++) {
int cacheindex = i / exceptionhandlingflowcontext.bitcachesize;
int bitmask = 1 << (i % exceptionhandlingflowcontext.bitcachesize);
buffer.append('[').append(this.handledexceptions[i].readablename());
if ((this.isreached[cacheindex] & bitmask) != 0) {
if ((this.isneeded[cacheindex] & bitmask) == 0) {
buffer.append("-masked"); //$non-nls-1$
} else {
buffer.append("-reached"); //$non-nls-1$
}
} else {
buffer.append("-not reached"); //$non-nls-1$
}
buffer.append('-').append(this.initsonexceptions[i].tostring()).append(']');
}
buffer.append("[initsonreturn -").append(this.initsonreturn.tostring()).append(']'); //$non-nls-1$
return buffer.tostring();
}

public unconditionalflowinfo initsonexception(referencebinding exceptiontype) {
int index;
if ((index = this.indexes.get(exceptiontype)) < 0) {
return flowinfo.dead_end;
}
return this.initsonexceptions[index];
}

public unconditionalflowinfo initsonreturn(){
return this.initsonreturn;
}

/*
* compute a merged list of unhandled exception types (keeping only the most generic ones).
* this is necessary to add synthetic thrown exceptions for anonymous type constructors (jls 8.6).
*/
public void mergeunhandledexception(typebinding newexception){
if (this.extendedexceptions == null){
this.extendedexceptions = new arraylist(5);
for (int i = 0; i < this.handledexceptions.length; i++){
this.extendedexceptions.add(this.handledexceptions[i]);
}
}
boolean isredundant = false;

for(int i = this.extendedexceptions.size()-1; i >= 0; i--){
switch(scope.comparetypes(newexception, (typebinding)this.extendedexceptions.get(i))){
case scope.more_generic :
this.extendedexceptions.remove(i);
break;
case scope.equal_or_more_specific :
isredundant = true;
break;
case scope.not_related :
break;
}
}
if (!isredundant){
this.extendedexceptions.add(newexception);
}
}

public void recordhandlingexception(
referencebinding exceptiontype,
unconditionalflowinfo flowinfo,
typebinding raisedexception,
astnode invocationsite,
boolean wasalreadydefinitelycaught) {

int index = this.indexes.get(exceptiontype);
int cacheindex = index / exceptionhandlingflowcontext.bitcachesize;
int bitmask = 1 << (index % exceptionhandlingflowcontext.bitcachesize);
if (!wasalreadydefinitelycaught) {
this.isneeded[cacheindex] |= bitmask;
}
this.isreached[cacheindex] |= bitmask;

this.initsonexceptions[index] =
(this.initsonexceptions[index].tagbits & flowinfo.unreachable) == 0 ?
this.initsonexceptions[index].mergedwith(flowinfo):
flowinfo.unconditionalcopy();
}

public void recordreturnfrom(unconditionalflowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0) {
if ((this.initsonreturn.tagbits & flowinfo.unreachable) == 0) {
this.initsonreturn = this.initsonreturn.mergedwith(flowinfo);
}
else {
this.initsonreturn = (unconditionalflowinfo) flowinfo.copy();
}
}
}

/**
* exception handlers (with no finally block) are also included with subroutine
* only once (in case parented with true insidesubroutineflowcontext).
* standard management of subroutines need to also operate on intermediate
* exception handlers.
* @@see org.eclipse.jdt.internal.compiler.flow.flowcontext#subroutine()
*/
public subroutinestatement subroutine() {
if (this.associatednode instanceof subroutinestatement) {
// exception handler context may be child of insidesubroutineflowcontext, which maps to same handler
if (this.parent.subroutine() == this.associatednode)
return null;
return (subroutinestatement) this.associatednode;
}
return null;
}
}
