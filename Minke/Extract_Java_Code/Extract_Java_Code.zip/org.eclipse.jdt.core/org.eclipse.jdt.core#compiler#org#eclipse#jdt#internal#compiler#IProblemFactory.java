/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

import java.util.locale;

import org.eclipse.jdt.core.compiler.categorizedproblem;

/*
* factory used from inside the compiler to build the actual problems
* which are handed back in the compilation result.
*
* this allows sharing the internal problem representation with the environment.
*
* note: the factory is responsible for computing and storing a localized error message.
*/

public interface iproblemfactory {
categorizedproblem createproblem(
char[] originatingfilename,
int problemid,
string[] problemarguments,
string[] messagearguments, // shorter versions of the problemarguments
int severity,
int startposition,
int endposition,
int linenumber,
int columnnumber);

/**
* answer a new iproblem created according to the parameters values.
* @@param originatingfilename the name of the file from which the problem is originated
* @@param problemid the problem id
* @@param problemarguments the fully qualified arguments recorded inside the problem
* @@param elaborationid the message elaboration id (0 for problems that have no message elaboration)
* @@param messagearguments the arguments needed to set the error message (shorter names than problemarguments ones)
* @@param severity the severity of the problem
* @@param startposition the start position of the problem
* @@param endposition the end position of the problem
* @@param linenumber the line on which the problem occurred
* @@return a new iproblem created according to the parameters values.
*/
categorizedproblem createproblem(
char[] originatingfilename,
int problemid,
string[] problemarguments,
int elaborationid,
string[] messagearguments, // shorter versions of the problemarguments
int severity,
int startposition,
int endposition,
int linenumber,
int columnnumber);

locale getlocale();

string getlocalizedmessage(int problemid, string[] messagearguments);

/**
* inject the supplied message arguments into a localized template
* elaborated from the supplied problem id and an optional elaboration id
* and return the resulting message. the arguments number should match the
* highest placeholder index in the template. when an elaboration id is
* used, the template matching that elaboration id replaces '{0}' into the
* template matching the problem id before the message arguments are
* injected.
* @@param problemid the problem id taken from
*        {@@link org.eclipse.jdt.core.compiler.iproblem} constants
* @@param elaborationid 0 if the considered problem has no elaboration, a
*        valid elaboration id else
* @@param messagearguments the arguments to inject into the template
* @@return a localized message elaborated from the supplied problem id,
*         elaboration id and message parameters
*/
string getlocalizedmessage(int problemid, int elaborationid, string[] messagearguments);
}
