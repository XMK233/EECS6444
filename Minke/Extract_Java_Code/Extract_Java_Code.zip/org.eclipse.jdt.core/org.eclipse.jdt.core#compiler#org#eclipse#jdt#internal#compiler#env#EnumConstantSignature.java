/*******************************************************************************
* copyright (c) 2005, 2007 bea systems, inc.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*    tyeung@@bea.com - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

/**
* represents a reference to a enum constant in the class file.
* one of the possible results for the default value of an annotation method.
*/
public class enumconstantsignature {

char[] typename;
char[] constname;

public enumconstantsignature(char[] typename, char[] constname) {
this.typename = typename;
this.constname = constname;
}

/**
* @@return name of the type in the class file format
*/
public char[] gettypename() {
return this.typename;
}

/**
* @@return the name of the enum constant reference.
*/
public char[] getenumconstantname() {
return this.constname;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append(this.typename);
buffer.append('.');
buffer.append(this.constname);
return buffer.tostring();
}
}
