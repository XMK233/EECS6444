/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser.diagnose;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.parser.parser;
import org.eclipse.jdt.internal.compiler.parser.parserbasicinformation;
import org.eclipse.jdt.internal.compiler.parser.recoveryscanner;
import org.eclipse.jdt.internal.compiler.parser.scannerhelper;
import org.eclipse.jdt.internal.compiler.parser.terminaltokens;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;
import org.eclipse.jdt.internal.compiler.util.util;

public class diagnoseparser implements parserbasicinformation, terminaltokens {
private static final boolean debug = false;
private boolean debug_parsecheck = false;

private static final int stack_increment = 256;

//	private static final int error_code = 1;
private static final int before_code = 2;
private static final int insertion_code = 3;
private static final int invalid_code = 4;
private static final int substitution_code = 5;
private static final int deletion_code = 6;
private static final int merge_code = 7;
private static final int misplaced_code = 8;
private static final int scope_code = 9;
private static final int secondary_code = 10;
private static final int eof_code = 11;

private static final int buff_ubound  = 31;
private static final int buff_size    = 32;
private static final int max_distance = 30;
private static final int min_distance = 3;

private compileroptions options;

private lexstream lexstream;
private int errortoken;
private int errortokenstart;

private int currenttoken = 0;

private int stacklength;
private int statestacktop;
private int[] stack;

private int[] locationstack;
private int[] locationstartstack;

private int tempstacktop;
private int[] tempstack;

private int prevstacktop;
private int[] prevstack;
private int nextstacktop;
private int[] nextstack;

private int scopestacktop;
private int[] scopeindex;
private int[] scopeposition;

int[] list = new int[num_symbols + 1];
int[] buffer = new int[buff_size];

private static final int nil = -1;
int[] stateseen;

int statepooltop;
stateinfo[] statepool;

private parser parser;

private recoveryscanner recoveryscanner;

private boolean reportproblem;

private static class repaircandidate {
public int symbol;
public int location;

public repaircandidate(){
this.symbol = 0;
this.location = 0;
}
}

private static class primaryrepairinfo {
public int distance;
public int misspellindex;
public int code;
public int bufferposition;
public int symbol;

public primaryrepairinfo(){
this.distance = 0;
this.misspellindex = 0;
this.code = 0;
this.bufferposition = 0;
this.symbol = 0;
}

public primaryrepairinfo copy(){
primaryrepairinfo c = new primaryrepairinfo();
c.distance = this.distance;
c.misspellindex = this.misspellindex;
c.code = this.code;
c.bufferposition = this .bufferposition;
c.symbol = this.symbol;
return c;

}
}

static class secondaryrepairinfo {
public int code;
public int distance;
public int bufferposition;
public int stackposition;
public int numdeletions;
public int symbol;

boolean recoveryonnextstack;
}

private static class stateinfo {
int state;
int next;

public stateinfo(int state, int next){
this.state = state;
this.next = next;
}
}

public diagnoseparser(parser parser, int firsttoken, int start, int end, compileroptions options) {
this(parser, firsttoken, start, end, util.empty_int_array, util.empty_int_array, util.empty_int_array, options);
}

public diagnoseparser(parser parser, int firsttoken, int start, int end, int[] intervalstarttoskip, int[] intervalendtoskip, int[] intervalflagstoskip, compileroptions options) {
this.parser = parser;
this.options = options;
this.lexstream = new lexstream(buff_size, parser.scanner, intervalstarttoskip, intervalendtoskip, intervalflagstoskip, firsttoken, start, end);
this.recoveryscanner = parser.recoveryscanner;
}

private problemreporter problemreporter(){
return this.parser.problemreporter();
}

private void reallocatestacks()	{
int old_stack_length = this.stacklength;

this.stacklength += stack_increment;

if(old_stack_length == 0){
this.stack = new int[this.stacklength];
this.locationstack = new int[this.stacklength];
this.locationstartstack = new int[this.stacklength];
this.tempstack = new int[this.stacklength];
this.prevstack = new int[this.stacklength];
this.nextstack = new int[this.stacklength];
this.scopeindex = new int[this.stacklength];
this.scopeposition = new int[this.stacklength];
} else {
system.arraycopy(this.stack, 0, this.stack = new int[this.stacklength], 0, old_stack_length);
system.arraycopy(this.locationstack, 0, this.locationstack = new int[this.stacklength], 0, old_stack_length);
system.arraycopy(this.locationstartstack, 0, this.locationstartstack = new int[this.stacklength], 0, old_stack_length);
system.arraycopy(this.tempstack, 0, this.tempstack = new int[this.stacklength], 0, old_stack_length);
system.arraycopy(this.prevstack, 0, this.prevstack = new int[this.stacklength], 0, old_stack_length);
system.arraycopy(this.nextstack, 0, this.nextstack = new int[this.stacklength], 0, old_stack_length);
system.arraycopy(this.scopeindex, 0, this.scopeindex = new int[this.stacklength], 0, old_stack_length);
system.arraycopy(this.scopeposition, 0, this.scopeposition = new int[this.stacklength], 0, old_stack_length);
}
return;
}


public void diagnoseparse(boolean record) {
this.reportproblem = true;
boolean oldrecord = false;
if(this.recoveryscanner != null) {
oldrecord = this.recoveryscanner.record;
this.recoveryscanner.record = record;
}
try {
this.lexstream.reset();

this.currenttoken = this.lexstream.gettoken();

int prev_pos;
int pos;
int next_pos;
int act = start_state;

reallocatestacks();

//
// start parsing
//
this.statestacktop = 0;
this.stack[this.statestacktop] = act;

int tok = this.lexstream.kind(this.currenttoken);
this.locationstack[this.statestacktop] = this.currenttoken;
this.locationstartstack[this.statestacktop] = this.lexstream.start(this.currenttoken);

boolean forcerecoveryafterlbracketmissing = false;
//		int forcerecoverytoken = -1;

//
// process a terminal
//
do {
//
// synchronize state stacks and update the location stack
//
prev_pos = -1;
this.prevstacktop = -1;

next_pos = -1;
this.nextstacktop = -1;

pos = this.statestacktop;
this.tempstacktop = this.statestacktop - 1;
for (int i = 0; i <= this.statestacktop; i++)
this.tempstack[i] = this.stack[i];

act = parser.taction(act, tok);
//
// when a reduce action is encountered, we compute all reduce
// and associated goto actions induced by the current token.
// eventually, a shift, shift-reduce, accept or error action is
// computed...
//
while (act <= num_rules) {
do {
this.tempstacktop -= (parser.rhs[act]-1);
act = parser.ntaction(this.tempstack[this.tempstacktop], parser.lhs[act]);
} while(act <= num_rules);
//
// ... update the maximum useful position of the
// (state_)stack, push goto state into stack, and
// compute next action on current symbol ...
//
if (this.tempstacktop + 1 >= this.stacklength)
reallocatestacks();
pos = pos < this.tempstacktop ? pos : this.tempstacktop;
this.tempstack[this.tempstacktop + 1] = act;
act = parser.taction(act, tok);
}

//
// at this point, we have a shift, shift-reduce, accept or error
// action.  stack contains the configuration of the state stack
// prior to executing any action on curtok. next_stack contains
// the configuration of the state stack after executing all
// reduce actions induced by curtok.  the variable pos indicates
// the highest position in stack that is still useful after the
// reductions are executed.
//
while(act > error_action || act < accept_action) { // shift-reduce action or shift action ?
this.nextstacktop = this.tempstacktop + 1;
for (int i = next_pos + 1; i <= this.nextstacktop; i++)
this.nextstack[i] = this.tempstack[i];

for (int i = pos + 1; i <= this.nextstacktop; i++) {
this.locationstack[i] = this.locationstack[this.statestacktop];
this.locationstartstack[i] = this.locationstartstack[this.statestacktop];
}

//
// if we have a shift-reduce, process it as well as
// the goto-reduce actions that follow it.
//
if (act > error_action) {
act -= error_action;
do {
this.nextstacktop -= (parser.rhs[act]-1);
act = parser.ntaction(this.nextstack[this.nextstacktop], parser.lhs[act]);
} while(act <= num_rules);
pos = pos < this.nextstacktop ? pos : this.nextstacktop;
}

if (this.nextstacktop + 1 >= this.stacklength)
reallocatestacks();

this.tempstacktop = this.nextstacktop;
this.nextstack[++this.nextstacktop] = act;
next_pos = this.nextstacktop;

//
// simulate the parser through the next token without
// destroying stack or next_stack.
//
this.currenttoken = this.lexstream.gettoken();
tok = this.lexstream.kind(this.currenttoken);
act = parser.taction(act, tok);
while(act <= num_rules) {
//
// ... process all goto-reduce actions following
// reduction, until a goto action is computed ...
//
do {
int lhs_symbol = parser.lhs[act];
if(debug) {
system.out.println(parser.name[parser.non_terminal_index[lhs_symbol]]);
}
this.tempstacktop -= (parser.rhs[act]-1);
act = (this.tempstacktop > next_pos
? this.tempstack[this.tempstacktop]
: this.nextstack[this.tempstacktop]);
act = parser.ntaction(act, lhs_symbol);
}   while(act <= num_rules);

//
// ... update the maximum useful position of the
// (state_)stack, push goto state into stack, and
// compute next action on current symbol ...
//
if (this.tempstacktop + 1 >= this.stacklength)
reallocatestacks();

next_pos = next_pos < this.tempstacktop ? next_pos : this.tempstacktop;
this.tempstack[this.tempstacktop + 1] = act;
act = parser.taction(act, tok);
}

//				if((tok != tokennamerbrace || (forcerecoverytoken != currenttoken && (lexstream.flags(currenttoken) & lexstream.lbrace_missing) != 0))
//					&& (lexstream.flags(currenttoken) & lexstream.is_after_jump) !=0) {
//					act = error_action;
//					if(forcerecoverytoken != currenttoken
//						&& (lexstream.flags(currenttoken) & lexstream.lbrace_missing) != 0) {
//						forcerecoveryafterlbracketmissing = true;
//						forcerecoverytoken = currenttoken;
//					}
//				}

//
// no error was detected, read next token into
// prevtok element, advance curtok pointer and
// update stacks.
//
if (act != error_action) {
this.prevstacktop = this.statestacktop;
for (int i = prev_pos + 1; i <= this.prevstacktop; i++)
this.prevstack[i] = this.stack[i];
prev_pos = pos;

this.statestacktop = this.nextstacktop;
for (int i = pos + 1; i <= this.statestacktop; i++)
this.stack[i] = this.nextstack[i];
this.locationstack[this.statestacktop] = this.currenttoken;
this.locationstartstack[this.statestacktop] = this.lexstream.start(this.currenttoken);
pos = next_pos;
}
}

//
// at this stage, either we have an accept or an error
// action.
//
if (act == error_action) {
//
// an error was detected.
//
repaircandidate candidate = errorrecovery(this.currenttoken, forcerecoveryafterlbracketmissing);

forcerecoveryafterlbracketmissing = false;

if(this.parser.reportonlyonesyntaxerror) {
return;
}

if(this.parser.problemreporter().options.maxproblemsperunit < this.parser.compilationunit.compilationresult.problemcount) {
if(this.recoveryscanner == null || !this.recoveryscanner.record) return;
this.reportproblem = false;
}

act = this.stack[this.statestacktop];

//
// if the recovery was successful on a nonterminal candidate,
// parse through that candidate and "read" the next token.
//
if (candidate.symbol == 0) {
break;
} else if (candidate.symbol > nt_offset) {
int lhs_symbol = candidate.symbol - nt_offset;
if(debug) {
system.out.println(parser.name[parser.non_terminal_index[lhs_symbol]]);
}
act = parser.ntaction(act, lhs_symbol);
while(act <= num_rules) {
this.statestacktop -= (parser.rhs[act]-1);
act = parser.ntaction(this.stack[this.statestacktop], parser.lhs[act]);
}
this.stack[++this.statestacktop] = act;
this.currenttoken = this.lexstream.gettoken();
tok = this.lexstream.kind(this.currenttoken);
this.locationstack[this.statestacktop] = this.currenttoken;
this.locationstartstack[this.statestacktop] = this.lexstream.start(this.currenttoken);
} else {
tok = candidate.symbol;
this.locationstack[this.statestacktop] = candidate.location;
this.locationstartstack[this.statestacktop] = this.lexstream.start(candidate.location);
}
}
} while (act != accept_action);
} finally {
if(this.recoveryscanner != null) {
this.recoveryscanner.record = oldrecord;
}
}
return;
}

private static char[] displayescapecharacters(char[] tokensource, int start, int end) {
stringbuffer tokensourcebuffer = new stringbuffer();
for (int i = 0; i < start; i++) {
tokensourcebuffer.append(tokensource[i]);
}
for (int i = start; i < end; i++) {
char c = tokensource[i];

switch (c) {
case '\r' :
tokensourcebuffer.append("\\r"); //$non-nls-1$
break;
case '\n' :
tokensourcebuffer.append("\\n"); //$non-nls-1$
break;
case '\b' :
tokensourcebuffer.append("\\b"); //$non-nls-1$
break;
case '\t' :
tokensourcebuffer.append("\t"); //$non-nls-1$
break;
case '\f' :
tokensourcebuffer.append("\\f"); //$non-nls-1$
break;
case '\"' :
tokensourcebuffer.append("\\\""); //$non-nls-1$
break;
case '\'' :
tokensourcebuffer.append("\\'"); //$non-nls-1$
break;
case '\\' :
tokensourcebuffer.append("\\\\"); //$non-nls-1$
break;
default :
tokensourcebuffer.append(c);
}
}
for (int i = end; i < tokensource.length; i++) {
tokensourcebuffer.append(tokensource[i]);
}
return tokensourcebuffer.tostring().tochararray();
}

//
//		this routine is invoked when an error is encountered.  it
//	   tries to diagnose the error and recover from it.  if it is
//	   successful, the state stack, the current token and the buffer
//	   are readjusted; i.e., after a successful recovery,
//	   state_stack_top points to the location in the state stack
//	   that contains the state on which to recover; curtok
//	   identifies the symbol on which to recover.
//
//	   up to three configurations may be available when this routine
//	   is invoked. prev_stack may contain the sequence of states
//	   preceding any action on prevtok, stack always contains the
//	   sequence of states preceding any action on curtok, and
//	   next_stack may contain the sequence of states preceding any
//	   action on the successor of curtok.
//
private repaircandidate errorrecovery(int error_token, boolean forcederror) {
this.errortoken = error_token;
this.errortokenstart = this.lexstream.start(error_token);

int prevtok = this.lexstream.previous(error_token);
int prevtokkind = this.lexstream.kind(prevtok);

if(forcederror) {
int name_index = parser.terminal_index[tokennamelbrace];

reporterror(insertion_code, name_index, prevtok, prevtok);

repaircandidate candidate = new repaircandidate();
candidate.symbol = tokennamelbrace;
candidate.location = error_token;
this.lexstream.reset(error_token);

this.statestacktop = this.nextstacktop;
for (int j = 0; j <= this.statestacktop; j++) {
this.stack[j] = this.nextstack[j];
}
this.locationstack[this.statestacktop] = error_token;
this.locationstartstack[this.statestacktop] = this.lexstream.start(error_token);

return candidate;
}

//
// try primary phase recoveries. if not successful, try secondary
// phase recoveries.  if not successful and we are at end of the
// file, we issue the end-of-file error and quit. otherwise, ...
//
repaircandidate candidate = primaryphase(error_token);
if (candidate.symbol != 0) {
return candidate;
}

candidate = secondaryphase(error_token);
if (candidate.symbol != 0) {
return candidate;
}

if (this.lexstream.kind(error_token) == eoft_symbol) {
reporterror(eof_code,
parser.terminal_index[eoft_symbol],
prevtok,
prevtok);
candidate.symbol = 0;
candidate.location = error_token;
return candidate;
}

//
// at this point, primary and (initial attempt at) secondary
// recovery did not work.  we will now get into "panic mode" and
// keep trying secondary phase recoveries until we either find
// a successful recovery or have consumed the remaining input
// tokens.
//
while(this.lexstream.kind(this.buffer[buff_ubound]) != eoft_symbol) {
candidate = secondaryphase(this.buffer[max_distance - min_distance + 2]);
if (candidate.symbol != 0) {
return candidate;
}
}

//
// we reached the end of the file while panicking. delete all
// remaining tokens in the input.
//
int i;
for (i = buff_ubound; this.lexstream.kind(this.buffer[i]) == eoft_symbol; i--){/*empty*/}

reporterror(deletion_code,
parser.terminal_index[prevtokkind],//parser.terminal_index[lexstream.kind(prevtok)],
error_token,
this.buffer[i]);

candidate.symbol = 0;
candidate.location = this.buffer[i];

return candidate;
}

//
//	   this function tries primary and scope recovery on each
//	   available configuration.  if a successful recovery is found
//	   and no secondary phase recovery can do better, a diagnosis is
//	   issued, the configuration is updated and the function returns
//	   "true".  otherwise, it returns "false".
//
private repaircandidate primaryphase(int error_token) {
primaryrepairinfo repair = new primaryrepairinfo();
repaircandidate candidate = new repaircandidate();

//
// initialize the buffer.
//
int i = (this.nextstacktop >= 0 ? 3 : 2);
this.buffer[i] = error_token;

for (int j = i; j > 0; j--)
this.buffer[j - 1] = this.lexstream.previous(this.buffer[j]);

for (int k = i + 1; k < buff_size; k++)
this.buffer[k] = this.lexstream.next(this.buffer[k - 1]);

//
// if next_stack_top > 0 then the parse was successful on curtok
// and the error was detected on the successor of curtok. in
// that case, first check whether or not primary recovery is
// possible on next_stack ...
//
if (this.nextstacktop >= 0) {
repair.bufferposition = 3;
repair = checkprimarydistance(this.nextstack, this.nextstacktop, repair);
}

//
// ... next, try primary recovery on the current token...
//
primaryrepairinfo new_repair = repair.copy();

new_repair.bufferposition = 2;
new_repair = checkprimarydistance(this.stack, this.statestacktop, new_repair);
if (new_repair.distance > repair.distance || new_repair.misspellindex > repair.misspellindex) {
repair = new_repair;
}

//
// finally, if prev_stack_top >= 0 then try primary recovery on
// the prev_stack configuration.
//

if (this.prevstacktop >= 0) {
new_repair = repair.copy();
new_repair.bufferposition = 1;
new_repair = checkprimarydistance(this.prevstack,this.prevstacktop, new_repair);
if (new_repair.distance > repair.distance || new_repair.misspellindex > repair.misspellindex) {
repair = new_repair;
}
}

//
// before accepting the best primary phase recovery obtained,
// ensure that we cannot do better with a similar secondary
// phase recovery.
//
if (this.nextstacktop >= 0) {// next_stack available
if (secondarycheck(this.nextstack,this.nextstacktop,3,repair.distance)) {
return candidate;
}
}
else if (secondarycheck(this.stack, this.statestacktop, 2, repair.distance)) {
return candidate;
}

//
// first, adjust distance if the recovery is on the error token;
// it is important that the adjustment be made here and not at
// each primary trial to prevent the distance tests from being
// biased in favor of deferred recoveries which have access to
// more input tokens...
//
repair.distance = repair.distance - repair.bufferposition + 1;

//
// ...next, adjust the distance if the recovery is a deletion or
// (some form of) substitution...
//
if (repair.code == invalid_code      ||
repair.code == deletion_code     ||
repair.code == substitution_code ||
repair.code == merge_code) {
repair.distance--;
}

//
// ... after adjustment, check if the most successful primary
// recovery can be applied.  if not, continue with more radical
// recoveries...
//
if (repair.distance < min_distance) {
return candidate;
}

//
// when processing an insertion error, if the token preceeding
// the error token is not available, we change the repair code
// into a before_code to instruct the reporting routine that it
// indicates that the repair symbol should be inserted before
// the error token.
//
if (repair.code == insertion_code) {
if (this.buffer[repair.bufferposition - 1] == 0) {
repair.code = before_code;
}
}

//
// select the proper sequence of states on which to recover,
// update stack accordingly and call diagnostic routine.
//
if (repair.bufferposition == 1) {
this.statestacktop = this.prevstacktop;
for (int j = 0; j <= this.statestacktop; j++) {
this.stack[j] = this.prevstack[j];
}
} else if (this.nextstacktop >= 0 && repair.bufferposition >= 3) {
this.statestacktop = this.nextstacktop;
for (int j = 0; j <= this.statestacktop; j++) {
this.stack[j] = this.nextstack[j];
}
this.locationstack[this.statestacktop] = this.buffer[3];
this.locationstartstack[this.statestacktop] = this.lexstream.start(this.buffer[3]);
}

return primarydiagnosis(repair);
}


//
//		   this function checks whether or not a given state has a
//	   candidate, whose string representaion is a merging of the two
//	   tokens at positions buffer_position and buffer_position+1 in
//	   the buffer.  if so, it returns the candidate in question;
//	   otherwise it returns 0.
//
private int mergecandidate(int state, int buffer_position) {
char[] name1 = this.lexstream.name(this.buffer[buffer_position]);
char[] name2 = this.lexstream.name(this.buffer[buffer_position + 1]);

int len  = name1.length + name2.length;

char[] str = charoperation.concat(name1, name2);

for (int k = parser.asi(state); parser.asr[k] != 0; k++) {
int l = parser.terminal_index[parser.asr[k]];

if (len == parser.name[l].length()) {
char[] name = parser.name[l].tochararray();

if (charoperation.equals(str, name, false)) {
return parser.asr[k];
}
}
}

return 0;
}


//
//	   this procedure takes as arguments a parsing configuration
//	   consisting of a state stack (stack and stack_top) and a fixed
//	   number of input tokens (starting at buffer_position) in the
//	   input buffer; and some reference arguments: repair_code,
//	   distance, misspell_index, candidate, and stack_position
//	   which it sets based on the best possible recovery that it
//	   finds in the given configuration.  the effectiveness of a
//	   a repair is judged based on two criteria:
//
//		 1) the number of tokens that can be parsed after the repair
//			is applied: distance.
//		 2) how close to perfection is the candidate that is chosen:
//			misspell_index.
//	   when this procedure is entered, distance, misspell_index and
//	   repair_code are assumed to be initialized.
//
private primaryrepairinfo checkprimarydistance(int stck[], int stack_top, primaryrepairinfo repair) {
int i, j, k, next_state, max_pos, act, root, symbol, tok;

//
//  first, try scope and manual recovery.
//
primaryrepairinfo scope_repair = scopetrial(stck, stack_top, repair.copy());
if (scope_repair.distance > repair.distance)
repair = scope_repair;

//
//  next, try merging the error token with its successor.
//
if(this.buffer[repair.bufferposition] != 0 && this.buffer[repair.bufferposition + 1] != 0) {// do not merge the first token
symbol = mergecandidate(stck[stack_top], repair.bufferposition);
if (symbol != 0) {
j = parsecheck(stck, stack_top, symbol, repair.bufferposition+2);
if ((j > repair.distance) || (j == repair.distance && repair.misspellindex < 10)) {
repair.misspellindex = 10;
repair.symbol = symbol;
repair.distance = j;
repair.code = merge_code;
}
}
}

//
// next, try deletion of the error token.
//
j = parsecheck(
stck,
stack_top,
this.lexstream.kind(this.buffer[repair.bufferposition + 1]),
repair.bufferposition + 2);
if (this.lexstream.kind(this.buffer[repair.bufferposition]) == eolt_symbol &&
this.lexstream.aftereol(this.buffer[repair.bufferposition+1])) {
k = 10;
} else {
k = 0;
}
if (j > repair.distance || (j == repair.distance && k > repair.misspellindex)) {
repair.misspellindex = k;
repair.code = deletion_code;
repair.distance = j;
}

//
// update the error configuration by simulating all reduce and
// goto actions induced by the error token. then assign the top
// most state of the new configuration to next_state.
//
next_state = stck[stack_top];
max_pos = stack_top;
this.tempstacktop = stack_top - 1;

tok = this.lexstream.kind(this.buffer[repair.bufferposition]);
this.lexstream.reset(this.buffer[repair.bufferposition + 1]);
act = parser.taction(next_state, tok);
while(act <= num_rules) {
do {
this.tempstacktop -= (parser.rhs[act]-1);
symbol = parser.lhs[act];
act = (this.tempstacktop > max_pos
? this.tempstack[this.tempstacktop]
: stck[this.tempstacktop]);
act = parser.ntaction(act, symbol);
} while(act <= num_rules);
max_pos = max_pos < this.tempstacktop ? max_pos : this.tempstacktop;
this.tempstack[this.tempstacktop + 1] = act;
next_state = act;
act = parser.taction(next_state, tok);
}

//
//  next, place the list of candidates in proper order.
//
root = 0;
for (i = parser.asi(next_state); parser.asr[i] != 0; i++) {
symbol = parser.asr[i];
if (symbol != eoft_symbol && symbol != error_symbol) {
if (root == 0) {
this.list[symbol] = symbol;
} else {
this.list[symbol] = this.list[root];
this.list[root] = symbol;
}
root = symbol;
}
}

if (stck[stack_top] != next_state) {
for (i = parser.asi(stck[stack_top]); parser.asr[i] != 0; i++) {
symbol = parser.asr[i];
if (symbol != eoft_symbol && symbol != error_symbol && this.list[symbol] == 0) {
if (root == 0) {
this.list[symbol] = symbol;
} else {
this.list[symbol] = this.list[root];
this.list[root] = symbol;
}
root = symbol;
}
}
}

i = this.list[root];
this.list[root] = 0;
root = i;

//
//  next, try insertion for each possible candidate available in
// the current state, except eoft and error_symbol.
//
symbol = root;
while(symbol != 0) {
if (symbol == eolt_symbol && this.lexstream.aftereol(this.buffer[repair.bufferposition])) {
k = 10;
} else {
k = 0;
}
j = parsecheck(stck, stack_top, symbol, repair.bufferposition);
if (j > repair.distance) {
repair.misspellindex = k;
repair.distance = j;
repair.symbol = symbol;
repair.code = insertion_code;
} else if (j == repair.distance && k > repair.misspellindex) {
repair.misspellindex = k;
repair.distance = j;
repair.symbol = symbol;
repair.code = insertion_code;
}

symbol = this.list[symbol];
}

//
//  next, try substitution for each possible candidate available
// in the current state, except eoft and error_symbol.
//
symbol = root;

if(this.buffer[repair.bufferposition] != 0) {// do not replace the first token
while(symbol != 0) {
if (symbol == eolt_symbol && this.lexstream.aftereol(this.buffer[repair.bufferposition+1])) {
k = 10;
} else {
k = misspell(symbol, this.buffer[repair.bufferposition]);
}
j = parsecheck(stck, stack_top, symbol, repair.bufferposition+1);
if (j > repair.distance) {
repair.misspellindex = k;
repair.distance = j;
repair.symbol = symbol;
repair.code = substitution_code;
} else if (j == repair.distance && k > repair.misspellindex) {
repair.misspellindex = k;
repair.symbol = symbol;
repair.code = substitution_code;
}
i = symbol;
symbol = this.list[symbol];
this.list[i] = 0;                             // reset element
}
}


//
// next, we try to insert a nonterminal candidate in front of the
// error token, or substituting a nonterminal candidate for the
// error token. precedence is given to insertion.
//
for (i = parser.nasi(stck[stack_top]); parser.nasr[i] != 0; i++) {
symbol = parser.nasr[i] + nt_offset;
j = parsecheck(stck, stack_top, symbol, repair.bufferposition+1);
if (j > repair.distance) {
repair.misspellindex = 0;
repair.distance = j;
repair.symbol = symbol;
repair.code = invalid_code;
}

j = parsecheck(stck, stack_top, symbol, repair.bufferposition);
if ((j > repair.distance) || (j == repair.distance && repair.code == invalid_code)) {
repair.misspellindex = 0;
repair.distance = j;
repair.symbol = symbol;
repair.code = insertion_code;
}
}

return repair;
}


//
//	   this procedure is invoked to issue a diagnostic message and
//	   adjust the input buffer.  the recovery in question is either
//	   the insertion of one or more scopes, the merging of the error
//	   token with its successor, the deletion of the error token,
//	   the insertion of a single token in front of the error token
//	   or the substitution of another token for the error token.
//
private repaircandidate primarydiagnosis(primaryrepairinfo repair) {
int name_index;

//
//  issue diagnostic.
//
int prevtok = this.buffer[repair.bufferposition - 1];
int	curtok  = this.buffer[repair.bufferposition];

switch(repair.code) {
case insertion_code:
case before_code: {
if (repair.symbol > nt_offset)
name_index = getntermindex(this.stack[this.statestacktop],
repair.symbol,
repair.bufferposition);
else name_index = gettermindex(this.stack,
this.statestacktop,
repair.symbol,
repair.bufferposition);

int t = (repair.code == insertion_code ? prevtok : curtok);
reporterror(repair.code, name_index, t, t);
break;
}
case invalid_code: {
name_index = getntermindex(this.stack[this.statestacktop],
repair.symbol,
repair.bufferposition + 1);
reporterror(repair.code, name_index, curtok, curtok);
break;
}
case substitution_code: {
if (repair.misspellindex >= 6)
name_index = parser.terminal_index[repair.symbol];
else
{
name_index = gettermindex(this.stack, this.statestacktop,
repair.symbol,
repair.bufferposition + 1);
if (name_index != parser.terminal_index[repair.symbol])
repair.code = invalid_code;
}
reporterror(repair.code, name_index, curtok, curtok);
break;
}
case merge_code: {
reporterror(repair.code,
parser.terminal_index[repair.symbol],
curtok,
this.lexstream.next(curtok));
break;
}
case scope_code: {
for (int i = 0; i < this.scopestacktop; i++) {
reporterror(repair.code,
-this.scopeindex[i],
this.locationstack[this.scopeposition[i]],
prevtok,
parser.non_terminal_index[parser.scope_lhs[this.scopeindex[i]]]);
}

repair.symbol = parser.scope_lhs[this.scopeindex[this.scopestacktop]] + nt_offset;
this.statestacktop = this.scopeposition[this.scopestacktop];
reporterror(repair.code,
-this.scopeindex[this.scopestacktop],
this.locationstack[this.scopeposition[this.scopestacktop]],
prevtok,
getntermindex(this.stack[this.statestacktop],
repair.symbol,
repair.bufferposition)
);
break;
}
default: {// deletion
reporterror(repair.code, parser.terminal_index[error_symbol], curtok, curtok);
}
}

//
//  update buffer.
//
repaircandidate candidate = new repaircandidate();
switch (repair.code) {
case insertion_code:
case before_code:
case scope_code: {
candidate.symbol = repair.symbol;
candidate.location = this.buffer[repair.bufferposition];
this.lexstream.reset(this.buffer[repair.bufferposition]);
break;
}
case invalid_code:
case substitution_code: {
candidate.symbol = repair.symbol;
candidate.location = this.buffer[repair.bufferposition];
this.lexstream.reset(this.buffer[repair.bufferposition + 1]);
break;
}
case merge_code: {
candidate.symbol = repair.symbol;
candidate.location = this.buffer[repair.bufferposition];
this.lexstream.reset(this.buffer[repair.bufferposition + 2]);
break;
}
default: {// deletion
candidate.location = this.buffer[repair.bufferposition + 1];
candidate.symbol =
this.lexstream.kind(this.buffer[repair.bufferposition + 1]);
this.lexstream.reset(this.buffer[repair.bufferposition + 2]);
break;
}
}

return candidate;
}


//
//	   this function takes as parameter an integer stack_top that
//	   points to a stack element containing the state on which a
//	   primary recovery will be made; the terminal candidate on which
//	   to recover; and an integer: buffer_position, which points to
//	   the position of the next input token in the buffer.  the
//	   parser is simulated until a shift (or shift-reduce) action
//	   is computed on the candidate.  then we proceed to compute the
//	   the name index of the highest level nonterminal that can
//	   directly or indirectly produce the candidate.
//
private int gettermindex(int stck[], int stack_top, int tok, int buffer_position) {
//
// initialize stack index of temp_stack and initialize maximum
// position of state stack that is still useful.
//
int act = stck[stack_top],
max_pos = stack_top,
highest_symbol = tok;

this.tempstacktop = stack_top - 1;

//
// compute all reduce and associated actions induced by the
// candidate until a shift or shift-reduce is computed. error
// and accept actions cannot be computed on the candidate in
// this context, since we know that it is suitable for recovery.
//
this.lexstream.reset(this.buffer[buffer_position]);
act = parser.taction(act, tok);
while(act <= num_rules) {
//
// process all goto-reduce actions following reduction,
// until a goto action is computed ...
//
do {
this.tempstacktop -= (parser.rhs[act]-1);
int lhs_symbol = parser.lhs[act];
act = (this.tempstacktop > max_pos
? this.tempstack[this.tempstacktop]
: stck[this.tempstacktop]);
act = parser.ntaction(act, lhs_symbol);
} while(act <= num_rules);

//
// compute new maximum useful position of (state_)stack,
// push goto state into the stack, and compute next
// action on candidate ...
//
max_pos = max_pos < this.tempstacktop ? max_pos : this.tempstacktop;
this.tempstack[this.tempstacktop + 1] = act;
act = parser.taction(act, tok);
}

//
// at this stage, we have simulated all actions induced by the
// candidate and we are ready to shift or shift-reduce it. first,
// set tok and next_ptr appropriately and identify the candidate
// as the initial highest_symbol. if a shift action was computed
// on the candidate, update the stack and compute the next
// action. next, simulate all actions possible on the next input
// token until we either have to shift it or are about to reduce
// below the initial starting point in the stack (indicated by
// max_pos as computed in the previous loop).  at that point,
// return the highest_symbol computed.
//
this.tempstacktop++; // adjust top of stack to reflect last goto
// next move is shift or shift-reduce.
int threshold = this.tempstacktop;

tok = this.lexstream.kind(this.buffer[buffer_position]);
this.lexstream.reset(this.buffer[buffer_position + 1]);

if (act > error_action) {  // shift-reduce on candidate?
act -= error_action;
} else {
this.tempstack[this.tempstacktop + 1] = act;
act = parser.taction(act, tok);
}

while(act <= num_rules) {
//
// process all goto-reduce actions following reduction,
// until a goto action is computed ...
//
do {
this.tempstacktop -= (parser.rhs[act]-1);

if (this.tempstacktop < threshold) {
return (highest_symbol > nt_offset
? parser.non_terminal_index[highest_symbol - nt_offset]
: parser.terminal_index[highest_symbol]);
}

int lhs_symbol = parser.lhs[act];
if (this.tempstacktop == threshold)
highest_symbol = lhs_symbol + nt_offset;
act = (this.tempstacktop > max_pos
? this.tempstack[this.tempstacktop]
: stck[this.tempstacktop]);
act = parser.ntaction(act, lhs_symbol);
} while(act <= num_rules);

this.tempstack[this.tempstacktop + 1] = act;
act = parser.taction(act, tok);
}

return (highest_symbol > nt_offset
? parser.non_terminal_index[highest_symbol - nt_offset]
: parser.terminal_index[highest_symbol]);
}

//
//	   this function takes as parameter a starting state number:
//	   start, a nonterminal symbol, a (candidate), and an integer,
//	   buffer_position,  which points to the position of the next
//	   input token in the buffer.
//	   it returns the highest level non-terminal b such that
//	   b =>*rm a.  i.e., there does not exists a nonterminal c such
//	   that c =>+rm b. (recall that for an lalr(k) grammar if
//	   c =>+rm b, it cannot be the case that b =>+rm c)
//
private int getntermindex(int start, int sym, int buffer_position) {
int highest_symbol = sym - nt_offset,
tok = this.lexstream.kind(this.buffer[buffer_position]);
this.lexstream.reset(this.buffer[buffer_position + 1]);

//
// initialize stack index of temp_stack and initialize maximum
// position of state stack that is still useful.
//
this.tempstacktop = 0;
this.tempstack[this.tempstacktop] = start;

int act = parser.ntaction(start, highest_symbol);
if (act > num_rules) { // goto action?
this.tempstack[this.tempstacktop + 1] = act;
act = parser.taction(act, tok);
}

while(act <= num_rules) {
//
// process all goto-reduce actions following reduction,
// until a goto action is computed ...
//
do {
this.tempstacktop -= (parser.rhs[act]-1);
if (this.tempstacktop < 0)
return parser.non_terminal_index[highest_symbol];
if (this.tempstacktop == 0)
highest_symbol = parser.lhs[act];
act = parser.ntaction(this.tempstack[this.tempstacktop], parser.lhs[act]);
} while(act <= num_rules);
this.tempstack[this.tempstacktop + 1] = act;
act = parser.taction(act, tok);
}

return parser.non_terminal_index[highest_symbol];
}

//
//		   check whether or not there is a high probability that a
//	   given string is a misspelling of another.
//	   certain singleton symbols (such as ":" and ";") are also
//	   considered to be misspelling of each other.
//
private int misspell(int sym, int tok) {


//
//
//
char[] name = parser.name[parser.terminal_index[sym]].tochararray();
int n = name.length;
char[] s1 = new char[n + 1];
for (int k = 0; k < n; k++) {
char c = name[k];
s1[k] = scannerhelper.tolowercase(c);
}
s1[n] = '\0';

//
//
//
char[] tokenname = this.lexstream.name(tok);
int len = tokenname.length;
int m = len < max_name_length ? len : max_name_length;
char[] s2 = new char[m + 1];
for (int k = 0; k < m; k++) {
char c = tokenname[k];
s2[k] = scannerhelper.tolowercase(c);
}
s2[m] = '\0';

//
//  singleton mispellings:
//
//  ;      <---->     ,
//
//  ;      <---->     :
//
//  .      <---->     ,
//
//  '      <---->     "
//
//
if (n == 1  &&  m == 1) {
if ((s1[0] == ';'  &&  s2[0] == ',')  ||
(s1[0] == ','  &&  s2[0] == ';')  ||
(s1[0] == ';'  &&  s2[0] == ':')  ||
(s1[0] == ':'  &&  s2[0] == ';')  ||
(s1[0] == '.'  &&  s2[0] == ',')  ||
(s1[0] == ','  &&  s2[0] == '.')  ||
(s1[0] == '\'' &&  s2[0] == '\"')  ||
(s1[0] == '\"'  &&  s2[0] == '\'')) {
return 3;
}
}

//
// scan the two strings. increment "match" count for each match.
// when a transposition is encountered, increase "match" count
// by two but count it as an error. when a typo is found, skip
// it and count it as an error. otherwise we have a mismatch; if
// one of the strings is longer, increment its index, otherwise,
// increment both indices and continue.
//
// this algorithm is an adaptation of a boolean misspelling
// algorithm proposed by juergen uhl.
//
int count = 0;
int prefix_length = 0;
int num_errors = 0;

int i = 0;
int j = 0;
while ((i < n)  &&  (j < m)) {
if (s1[i] == s2[j]) {
count++;
i++;
j++;
if (num_errors == 0) {
prefix_length++;
}
} else if (s1[i+1] == s2[j]  &&  s1[i] == s2[j+1]) {
count += 2;
i += 2;
j += 2;
num_errors++;
} else if (s1[i+1] == s2[j+1]) {
i++;
j++;
num_errors++;
} else {
if ((n - i) > (m - j)) {
i++;
} else if ((m - j) > (n - i)) {
j++;
} else {
i++;
j++;
}
num_errors++;
}
}

if (i < n  ||  j < m)
num_errors++;

if (num_errors > ((n < m ? n : m) / 6 + 1))
count = prefix_length;

return(count * 10 / ((n < len ? len : n) + num_errors));
}

private primaryrepairinfo scopetrial(int stck[], int stack_top, primaryrepairinfo repair) {
this.stateseen = new int[this.stacklength];
for (int i = 0; i < this.stacklength; i++)
this.stateseen[i] = nil;

this.statepooltop = 0;
this.statepool = new stateinfo[this.stacklength];

scopetrialcheck(stck, stack_top, repair, 0);

this.stateseen = null;
this.statepooltop = 0;

repair.code = scope_code;
repair.misspellindex = 10;

return repair;
}

private void scopetrialcheck(int stck[], int stack_top, primaryrepairinfo repair, int indx) {
if(indx > 20) return; // avoid too much recursive call to improve performance

int act = stck[stack_top];

for (int i = this.stateseen[stack_top]; i != nil; i = this.statepool[i].next) {
if (this.statepool[i].state == act) return;
}

int old_state_pool_top = this.statepooltop++;
if(this.statepooltop >= this.statepool.length) {
system.arraycopy(this.statepool, 0, this.statepool = new stateinfo[this.statepooltop * 2], 0, this.statepooltop);
}

this.statepool[old_state_pool_top] = new stateinfo(act, this.stateseen[stack_top]);
this.stateseen[stack_top] = old_state_pool_top;

next : for (int i = 0; i < scope_size; i++) {
//
// use the scope lookahead symbol to force all reductions
// inducible by that symbol.
//
act = stck[stack_top];
this.tempstacktop = stack_top - 1;
int max_pos = stack_top;
int tok = parser.scope_la[i];
this.lexstream.reset(this.buffer[repair.bufferposition]);
act = parser.taction(act, tok);
while(act <= num_rules) {
//
// ... process all goto-reduce actions following
// reduction, until a goto action is computed ...
//
do  {
this.tempstacktop -= (parser.rhs[act]-1);
int lhs_symbol = parser.lhs[act];
act =  (this.tempstacktop > max_pos
?  this.tempstack[this.tempstacktop]
:  stck[this.tempstacktop]);
act = parser.ntaction(act, lhs_symbol);
}  while(act <= num_rules);
if (this.tempstacktop + 1 >= this.stacklength)
return;
max_pos = max_pos < this.tempstacktop ? max_pos : this.tempstacktop;
this.tempstack[this.tempstacktop + 1] = act;
act = parser.taction(act, tok);
}

//
// if the lookahead symbol is parsable, then we check
// whether or not we have a match between the scope
// prefix and the transition symbols corresponding to
// the states on top of the stack.
//
if (act != error_action) {
int j, k;
k = parser.scope_prefix[i];
for (j = this.tempstacktop + 1;
j >= (max_pos + 1) &&
parser.in_symbol(this.tempstack[j]) == parser.scope_rhs[k]; j--) {
k++;
}
if (j == max_pos) {
for (j = max_pos;
j >= 1 && parser.in_symbol(stck[j]) == parser.scope_rhs[k];
j--) {
k++;
}
}
//
// if the prefix matches, check whether the state
// newly exposed on top of the stack, (after the
// corresponding prefix states are popped from the
// stack), is in the set of "source states" for the
// scope in question and that it is at a position
// below the threshold indicated by marked_pos.
//
int marked_pos = (max_pos < stack_top ? max_pos + 1 : stack_top);
if (parser.scope_rhs[k] == 0 && j < marked_pos) { // match?
int stack_position = j;
for (j = parser.scope_state_set[i];
stck[stack_position] != parser.scope_state[j] &&
parser.scope_state[j] != 0;
j++){/*empty*/}
//
// if the top state is valid for scope recovery,
// the left-hand side of the scope is used as
// starting symbol and we calculate how far the
// parser can advance within the forward context
// after parsing the left-hand symbol.
//
if (parser.scope_state[j] != 0) {     // state was found
int previous_distance = repair.distance;
int distance = parsecheck(stck,
stack_position,
parser.scope_lhs[i]+nt_offset,
repair.bufferposition);
//
// if the recovery is not successful, we
// update the stack with all actions induced
// by the left-hand symbol, and recursively
// call scope_trial_check to try again.
// otherwise, the recovery is successful. if
// the new distance is greater than the
// initial scope_distance, we update
// scope_distance and set scope_stack_top to indx
// to indicate the number of scopes that are
// to be applied for a succesful  recovery.
// note that this procedure cannot get into
// an infinite loop, since each prefix match
// is guaranteed to take us to a lower point
// within the stack.
//
if ((distance - repair.bufferposition + 1) < min_distance) {
int top = stack_position;
act = parser.ntaction(stck[top], parser.scope_lhs[i]);
while(act <= num_rules) {
if(parser.rules_compliance[act] > this.options.sourcelevel) {
continue next;
}
top -= (parser.rhs[act]-1);
act = parser.ntaction(stck[top], parser.lhs[act]);
}
top++;

j = act;
act = stck[top];  // save
stck[top] = j;    // swap
scopetrialcheck(stck, top, repair, indx+1);
stck[top] = act; // restore
} else if (distance > repair.distance) {
this.scopestacktop = indx;
repair.distance = distance;
}

if (this.lexstream.kind(this.buffer[repair.bufferposition]) == eoft_symbol &&
repair.distance == previous_distance) {
this.scopestacktop = indx;
repair.distance = max_distance;
}

//
// if this scope recovery has beaten the
// previous distance, then we have found a
// better recovery (or this recovery is one
// of a list of scope recoveries). record
// its information at the proper location
// (indx) in scope_index and scope_stack.
//
if (repair.distance > previous_distance) {
this.scopeindex[indx] = i;
this.scopeposition[indx] = stack_position;
return;
}
}
}
}
}
}
//
//	   this function computes the parsecheck distance for the best
//	   possible secondary recovery for a given configuration that
//	   either deletes none or only one symbol in the forward context.
//	   if the recovery found is more effective than the best primary
//	   recovery previously computed, then the function returns true.
//	   only misplacement, scope and manual recoveries are attempted;
//	   simple insertion or substitution of a nonterminal are tried
//	   in check_primary_distance as part of primary recovery.
//
private boolean secondarycheck(int stck[], int stack_top, int buffer_position, int distance) {
int top, j;

for (top = stack_top - 1; top >= 0; top--) {
j = parsecheck(stck, top,
this.lexstream.kind(this.buffer[buffer_position]),
buffer_position + 1);
if (((j - buffer_position + 1) > min_distance) && (j > distance))
return true;
}

primaryrepairinfo repair = new primaryrepairinfo();
repair.bufferposition = buffer_position + 1;
repair.distance = distance;
repair = scopetrial(stck, stack_top, repair);
if ((repair.distance - buffer_position) > min_distance && repair.distance > distance)
return true;
return false;
}


//
//	   secondary_phase is a boolean function that checks whether or
//	   not some form of secondary recovery is applicable to one of
//	   the error configurations. first, if "next_stack" is available,
//	   misplacement and secondary recoveries are attempted on it.
//	   then, in any case, these recoveries are attempted on "stack".
//	   if a successful recovery is found, a diagnosis is issued, the
//	   configuration is updated and the function returns "true".
//	   otherwise, the function returns false.
//
private repaircandidate secondaryphase(int error_token) {
secondaryrepairinfo repair = new secondaryrepairinfo();
secondaryrepairinfo misplaced = new secondaryrepairinfo();

repaircandidate candidate = new repaircandidate();

int i, j, k, top;
int	next_last_index = 0;
int	last_index;

candidate.symbol = 0;

repair.code = 0;
repair.distance = 0;
repair.recoveryonnextstack = false;

misplaced.distance = 0;
misplaced.recoveryonnextstack = false;

//
// if the next_stack is available, try misplaced and secondary
// recovery on it first.
//
if (this.nextstacktop >= 0) {
int  save_location;

this.buffer[2] = error_token;
this.buffer[1] = this.lexstream.previous(this.buffer[2]);
this.buffer[0] = this.lexstream.previous(this.buffer[1]);

for (k = 3; k < buff_ubound; k++)
this.buffer[k] = this.lexstream.next(this.buffer[k - 1]);

this.buffer[buff_ubound] = this.lexstream.badtoken();// elmt not available

//
// if we are at the end of the input stream, compute the
// index position of the first eoft symbol (last useful
// index).
//
for (next_last_index = max_distance - 1;
next_last_index >= 1 &&
this.lexstream.kind(this.buffer[next_last_index]) == eoft_symbol;
next_last_index--){/*empty*/}
next_last_index = next_last_index + 1;

save_location = this.locationstack[this.nextstacktop];
int save_location_start = this.locationstartstack[this.nextstacktop];
this.locationstack[this.nextstacktop] = this.buffer[2];
this.locationstartstack[this.nextstacktop] = this.lexstream.start(this.buffer[2]);
misplaced.numdeletions = this.nextstacktop;
misplaced = misplacementrecovery(this.nextstack, this.nextstacktop,
next_last_index,
misplaced, true);
if (misplaced.recoveryonnextstack)
misplaced.distance++;

repair.numdeletions = this.nextstacktop + buff_ubound;
repair = secondaryrecovery(this.nextstack, this.nextstacktop,
next_last_index,
repair, true);
if (repair.recoveryonnextstack)
repair.distance++;

this.locationstack[this.nextstacktop] = save_location;
this.locationstartstack[this.nextstacktop] = save_location_start;
} else {            // next_stack not available, initialize ...
misplaced.numdeletions = this.statestacktop;
repair.numdeletions = this.statestacktop + buff_ubound;
}

//
// try secondary recovery on the "stack" configuration.
//
this.buffer[3] = error_token;

this.buffer[2] = this.lexstream.previous(this.buffer[3]);
this.buffer[1] = this.lexstream.previous(this.buffer[2]);
this.buffer[0] = this.lexstream.previous(this.buffer[1]);

for (k = 4; k < buff_size; k++)
this.buffer[k] = this.lexstream.next(this.buffer[k - 1]);

for (last_index = max_distance - 1;
last_index >= 1 && this.lexstream.kind(this.buffer[last_index]) == eoft_symbol;
last_index--){/*empty*/}
last_index++;

misplaced = misplacementrecovery(this.stack, this.statestacktop,
last_index,
misplaced, false);

repair = secondaryrecovery(this.stack, this.statestacktop,
last_index, repair, false);

//
// if a successful misplaced recovery was found, compare it with
// the most successful secondary recovery.  if the misplaced
// recovery either deletes fewer symbols or parse-checks further
// then it is chosen.
//
if (misplaced.distance > min_distance) {
if (misplaced.numdeletions <= repair.numdeletions ||
(misplaced.distance - misplaced.numdeletions) >=
(repair.distance - repair.numdeletions)) {
repair.code = misplaced_code;
repair.stackposition = misplaced.stackposition;
repair.bufferposition = 2;
repair.numdeletions = misplaced.numdeletions;
repair.distance = misplaced.distance;
repair.recoveryonnextstack = misplaced.recoveryonnextstack;
}
}

//
// if the successful recovery was on next_stack, update: stack,
// buffer, location_stack and last_index.
//
if (repair.recoveryonnextstack) {
this.statestacktop = this.nextstacktop;
for (i = 0; i <= this.statestacktop; i++)
this.stack[i] = this.nextstack[i];

this.buffer[2] = error_token;
this.buffer[1] = this.lexstream.previous(this.buffer[2]);
this.buffer[0] = this.lexstream.previous(this.buffer[1]);

for (k = 3; k < buff_ubound; k++)
this.buffer[k] = this.lexstream.next(this.buffer[k - 1]);

this.buffer[buff_ubound] = this.lexstream.badtoken();// elmt not available

this.locationstack[this.nextstacktop] = this.buffer[2];
this.locationstartstack[this.nextstacktop] = this.lexstream.start(this.buffer[2]);
last_index = next_last_index;
}

//
// next, try scope recoveries after deletion of one, two, three,
// four ... buffer_position tokens from the input stream.
//
if (repair.code == secondary_code || repair.code == deletion_code) {
primaryrepairinfo scope_repair = new primaryrepairinfo();

scope_repair.distance = 0;
for (scope_repair.bufferposition = 2;
scope_repair.bufferposition <= repair.bufferposition &&
repair.code != scope_code; scope_repair.bufferposition++) {
scope_repair = scopetrial(this.stack, this.statestacktop, scope_repair);
j = (scope_repair.distance == max_distance
? last_index
: scope_repair.distance);
k = scope_repair.bufferposition - 1;
if ((j - k) > min_distance && (j - k) > (repair.distance - repair.numdeletions)) {
repair.code = scope_code;
i = this.scopeindex[this.scopestacktop];       // upper bound
repair.symbol = parser.scope_lhs[i] + nt_offset;
repair.stackposition = this.statestacktop;
repair.bufferposition = scope_repair.bufferposition;
}
}
}

//
// if no successful recovery is found and we have reached the
// end of the file, check whether or not scope recovery is
// applicable at the end of the file after discarding some
// states.
//
if (repair.code == 0 && this.lexstream.kind(this.buffer[last_index]) == eoft_symbol) {
primaryrepairinfo scope_repair = new primaryrepairinfo();

scope_repair.bufferposition = last_index;
scope_repair.distance = 0;
for (top = this.statestacktop;
top >= 0 && repair.code == 0; top--)
{
scope_repair = scopetrial(this.stack, top, scope_repair);
if (scope_repair.distance > 0)
{
repair.code = scope_code;
i = this.scopeindex[this.scopestacktop];    // upper bound
repair.symbol = parser.scope_lhs[i] + nt_offset;
repair.stackposition = top;
repair.bufferposition = scope_repair.bufferposition;
}
}
}

//
// if a successful repair was not found, quit!  otherwise, issue
// diagnosis and adjust configuration...
//
if (repair.code == 0)
return candidate;

secondarydiagnosis(repair);

//
// update buffer based on number of elements that are deleted.
//
switch(repair.code) {
case misplaced_code:
candidate.location = this.buffer[2];
candidate.symbol = this.lexstream.kind(this.buffer[2]);
this.lexstream.reset(this.lexstream.next(this.buffer[2]));

break;

case deletion_code:
candidate.location = this.buffer[repair.bufferposition];
candidate.symbol =
this.lexstream.kind(this.buffer[repair.bufferposition]);
this.lexstream.reset(this.lexstream.next(this.buffer[repair.bufferposition]));

break;

default: // scope_code || secondary_code
candidate.symbol = repair.symbol;
candidate.location = this.buffer[repair.bufferposition];
this.lexstream.reset(this.buffer[repair.bufferposition]);

break;
}

return candidate;
}


//
//	   this boolean function checks whether or not a given
//	   configuration yields a better misplacement recovery than
//	   the best misplacement recovery computed previously.
//
private secondaryrepairinfo misplacementrecovery(int stck[], int stack_top, int last_index, secondaryrepairinfo repair, boolean stack_flag) {
int  previous_loc = this.buffer[2];
int stack_deletions = 0;

for (int top = stack_top - 1; top >= 0; top--) {
if (this.locationstack[top] < previous_loc) {
stack_deletions++;
}
previous_loc = this.locationstack[top];

int j = parsecheck(stck, top, this.lexstream.kind(this.buffer[2]), 3);
if (j == max_distance) {
j = last_index;
}
if ((j > min_distance) && (j - stack_deletions) > (repair.distance - repair.numdeletions)) {
repair.stackposition = top;
repair.distance = j;
repair.numdeletions = stack_deletions;
repair.recoveryonnextstack = stack_flag;
}
}

return repair;
}


//
//	   this boolean function checks whether or not a given
//	   configuration yields a better secondary recovery than the
//	   best misplacement recovery computed previously.
//
private secondaryrepairinfo secondaryrecovery(int stck[],int stack_top, int last_index, secondaryrepairinfo repair, boolean stack_flag) {
int previous_loc;
int stack_deletions = 0;

previous_loc = this.buffer[2];
for (int top = stack_top; top >= 0 && repair.numdeletions >= stack_deletions; top--) {
if (this.locationstack[top] < previous_loc) {
stack_deletions++;
}
previous_loc = this.locationstack[top];

for (int i = 2;
i <= (last_index - min_distance + 1) &&
(repair.numdeletions >= (stack_deletions + i - 1)); i++) {
int j = parsecheck(stck, top, this.lexstream.kind(this.buffer[i]), i + 1);

if (j == max_distance) {
j = last_index;
}
if ((j - i + 1) > min_distance) {
int k = stack_deletions + i - 1;
if ((k < repair.numdeletions) ||
(j - k) > (repair.distance - repair.numdeletions) ||
((repair.code == secondary_code) && (j - k) == (repair.distance - repair.numdeletions))) {
repair.code = deletion_code;
repair.distance = j;
repair.stackposition = top;
repair.bufferposition = i;
repair.numdeletions = k;
repair.recoveryonnextstack = stack_flag;
}
}

for (int l = parser.nasi(stck[top]); l >= 0 && parser.nasr[l] != 0; l++) {
int symbol = parser.nasr[l] + nt_offset;
j = parsecheck(stck, top, symbol, i);
if (j == max_distance) {
j = last_index;
}
if ((j - i + 1) > min_distance) {
int k = stack_deletions + i - 1;
if (k < repair.numdeletions || (j - k) > (repair.distance - repair.numdeletions)) {
repair.code = secondary_code;
repair.symbol = symbol;
repair.distance = j;
repair.stackposition = top;
repair.bufferposition = i;
repair.numdeletions = k;
repair.recoveryonnextstack = stack_flag;
}
}
}
}
}

return repair;
}


//
//	   this procedure is invoked to issue a secondary diagnosis and
//	   adjust the input buffer.  the recovery in question is either
//	   an automatic scope recovery, a manual scope recovery, a
//	   secondary substitution or a secondary deletion.
//
private void secondarydiagnosis(secondaryrepairinfo repair) {
switch(repair.code) {
case scope_code: {
if (repair.stackposition < this.statestacktop) {
reporterror(deletion_code,
parser.terminal_index[error_symbol],
this.locationstack[repair.stackposition],
this.buffer[1]);
}
for (int i = 0; i < this.scopestacktop; i++) {
reporterror(scope_code,
-this.scopeindex[i],
this.locationstack[this.scopeposition[i]],
this.buffer[1],
parser.non_terminal_index[parser.scope_lhs[this.scopeindex[i]]]);
}

repair.symbol = parser.scope_lhs[this.scopeindex[this.scopestacktop]] + nt_offset;
this.statestacktop = this.scopeposition[this.scopestacktop];
reporterror(scope_code,
-this.scopeindex[this.scopestacktop],
this.locationstack[this.scopeposition[this.scopestacktop]],
this.buffer[1],
getntermindex(this.stack[this.statestacktop],
repair.symbol,
repair.bufferposition)
);
break;
}
default: {
reporterror(repair.code,
(repair.code == secondary_code
? getntermindex(this.stack[repair.stackposition],
repair.symbol,
repair.bufferposition)
: parser.terminal_index[error_symbol]),
this.locationstack[repair.stackposition],
this.buffer[repair.bufferposition - 1]);
this.statestacktop = repair.stackposition;
}
}
}




//
//	   try to parse until first_token and all tokens in buffer have
//	   been consumed, or an error is encountered. return the number
//	   of tokens that were expended before the parse blocked.
//
private int parsecheck(int stck[], int stack_top, int first_token, int buffer_position) {
int max_pos;
int indx;
int ct;
int act;

//
// initialize pointer for temp_stack and initialize maximum
// position of state stack that is still useful.
//
act = stck[stack_top];
if (first_token > nt_offset) {
this.tempstacktop = stack_top;
if(this.debug_parsecheck) {
system.out.println(this.tempstacktop);
}
max_pos = stack_top;
indx = buffer_position;
ct = this.lexstream.kind(this.buffer[indx]);
this.lexstream.reset(this.lexstream.next(this.buffer[indx]));
int lhs_symbol = first_token - nt_offset;
act = parser.ntaction(act, lhs_symbol);
if (act <= num_rules) {
// same loop as 'process_non_terminal'
do {
this.tempstacktop -= (parser.rhs[act]-1);

if(this.debug_parsecheck) {
system.out.print(this.tempstacktop);
system.out.print(" ("); //$non-nls-1$
system.out.print(-(parser.rhs[act]-1));
system.out.print(") [max:"); //$non-nls-1$
system.out.print(max_pos);
system.out.print("]\tprocess_non_terminal\t"); //$non-nls-1$
system.out.print(act);
system.out.print("\t"); //$non-nls-1$
system.out.print(parser.name[parser.non_terminal_index[parser.lhs[act]]]);
system.out.println();
}

if(parser.rules_compliance[act] > this.options.sourcelevel) {
return 0;
}
lhs_symbol = parser.lhs[act];
act = (this.tempstacktop > max_pos
? this.tempstack[this.tempstacktop]
: stck[this.tempstacktop]);
act = parser.ntaction(act, lhs_symbol);
} while(act <= num_rules);

max_pos = max_pos < this.tempstacktop ? max_pos : this.tempstacktop;
}
} else {
this.tempstacktop = stack_top - 1;

if(this.debug_parsecheck) {
system.out.println(this.tempstacktop);
}

max_pos = this.tempstacktop;
indx = buffer_position - 1;
ct = first_token;
this.lexstream.reset(this.buffer[buffer_position]);
}

process_terminal: for (;;) {
if(this.debug_parsecheck) {
system.out.print(this.tempstacktop + 1);
system.out.print(" (+1) [max:"); //$non-nls-1$
system.out.print(max_pos);
system.out.print("]\tprocess_terminal    \t"); //$non-nls-1$
system.out.print(ct);
system.out.print("\t"); //$non-nls-1$
system.out.print(parser.name[parser.terminal_index[ct]]);
system.out.println();
}

if (++this.tempstacktop >= this.stacklength)  // stack overflow!!!
return indx;
this.tempstack[this.tempstacktop] = act;

act = parser.taction(act, ct);

if (act <= num_rules) {               // reduce action
this.tempstacktop--;

if(this.debug_parsecheck) {
system.out.print(this.tempstacktop);
system.out.print(" (-1) [max:"); //$non-nls-1$
system.out.print(max_pos);
system.out.print("]\treduce"); //$non-nls-1$
system.out.println();
}
} else if (act < accept_action ||     // shift action
act > error_action) {        // shift-reduce action
if (indx == max_distance)
return indx;
indx++;
ct = this.lexstream.kind(this.buffer[indx]);
this.lexstream.reset(this.lexstream.next(this.buffer[indx]));
if (act > error_action) {
act -= error_action;

if(this.debug_parsecheck) {
system.out.print(this.tempstacktop);
system.out.print("\tshift reduce"); //$non-nls-1$
system.out.println();
}
} else {
if(this.debug_parsecheck) {
system.out.println("\tshift"); //$non-nls-1$
}
continue process_terminal;
}
} else if (act == accept_action) {           // accept action
return max_distance;
} else {
return indx;                         // error action
}

// same loop as first token initialization
// process_non_terminal:
do {
this.tempstacktop -= (parser.rhs[act]-1);

if(this.debug_parsecheck) {
system.out.print(this.tempstacktop);
system.out.print(" ("); //$non-nls-1$
system.out.print(-(parser.rhs[act]-1));
system.out.print(") [max:"); //$non-nls-1$
system.out.print(max_pos);
system.out.print("]\tprocess_non_terminal\t"); //$non-nls-1$
system.out.print(act);
system.out.print("\t"); //$non-nls-1$
system.out.print(parser.name[parser.non_terminal_index[parser.lhs[act]]]);
system.out.println();
}

if(act <= num_rules) {
if(parser.rules_compliance[act] > this.options.sourcelevel) {
return 0;
}
}
int lhs_symbol = parser.lhs[act];
act = (this.tempstacktop > max_pos
? this.tempstack[this.tempstacktop]
: stck[this.tempstacktop]);
act = parser.ntaction(act, lhs_symbol);
} while(act <= num_rules);

max_pos = max_pos < this.tempstacktop ? max_pos : this.tempstacktop;
} // process_terminal;
}
private void reporterror(int msgcode, int nameindex, int lefttoken, int righttoken) {
reporterror(msgcode, nameindex, lefttoken, righttoken, 0);
}

private void reporterror(int msgcode, int nameindex, int lefttoken, int righttoken, int scopenameindex) {
int ltoken = (lefttoken > righttoken ? righttoken : lefttoken);

if (ltoken < righttoken) {
reportsecondaryerror(msgcode, nameindex, ltoken, righttoken, scopenameindex);
} else {
reportprimaryerror(msgcode, nameindex, righttoken, scopenameindex);
}
}

private void reportprimaryerror(int msgcode, int nameindex, int token, int scopenameindex) {
string name;
if (nameindex >= 0) {
name = parser.readablename[nameindex];
} else {
name = util.empty_string;
}

int errorstart = this.lexstream.start(token);
int errorend = this.lexstream.end(token);
int currentkind = this.lexstream.kind(token);
string errortokenname = parser.name[parser.terminal_index[this.lexstream.kind(token)]];
char[] errortokensource = this.lexstream.name(token);
if (currentkind == terminaltokens.tokennamestringliteral) {
errortokensource = displayescapecharacters(errortokensource, 1, errortokensource.length - 1);
}

int addedtoken = -1;
if(this.recoveryscanner != null) {
if (nameindex >= 0) {
addedtoken = parser.reverse_index[nameindex];
}
}
switch(msgcode) {
case before_code:
if(this.recoveryscanner != null) {
if(addedtoken > -1) {
this.recoveryscanner.inserttoken(addedtoken, -1, errorstart);
} else {
int[] template = getntermtemplate(-addedtoken);
if(template != null) {
this.recoveryscanner.inserttokens(template, -1, errorstart);
}
}
}
if(this.reportproblem) problemreporter().parseerrorinsertbeforetoken(
errorstart,
errorend,
currentkind,
errortokensource,
errortokenname,
name);
break;
case insertion_code:
if(this.recoveryscanner != null) {
if(addedtoken > -1) {
this.recoveryscanner.inserttoken(addedtoken, -1, errorend);
} else {
int[] template = getntermtemplate(-addedtoken);
if(template != null) {
this.recoveryscanner.inserttokens(template, -1, errorend);
}
}
}
if(this.reportproblem) problemreporter().parseerrorinsertaftertoken(
errorstart,
errorend,
currentkind,
errortokensource,
errortokenname,
name);
break;
case deletion_code:
if(this.recoveryscanner != null) {
this.recoveryscanner.removetokens(errorstart, errorend);
}
if(this.reportproblem) problemreporter().parseerrordeletetoken(
errorstart,
errorend,
currentkind,
errortokensource,
errortokenname);
break;
case invalid_code:
if (name.length() == 0) {
if(this.recoveryscanner != null) {
this.recoveryscanner.removetokens(errorstart, errorend);
}
if(this.reportproblem) problemreporter().parseerrorreplacetoken(
errorstart,
errorend,
currentkind,
errortokensource,
errortokenname,
name);
} else {
if(this.recoveryscanner != null) {
if(addedtoken > -1) {
this.recoveryscanner.replacetokens(addedtoken, errorstart, errorend);
} else {
int[] template = getntermtemplate(-addedtoken);
if(template != null) {
this.recoveryscanner.replacetokens(template, errorstart, errorend);
}
}
}
if(this.reportproblem) problemreporter().parseerrorinvalidtoken(
errorstart,
errorend,
currentkind,
errortokensource,
errortokenname,
name);
}
break;
case substitution_code:
if(this.recoveryscanner != null) {
if(addedtoken > -1) {
this.recoveryscanner.replacetokens(addedtoken, errorstart, errorend);
} else {
int[] template = getntermtemplate(-addedtoken);
if(template != null) {
this.recoveryscanner.replacetokens(template, errorstart, errorend);
}
}
}
if(this.reportproblem) problemreporter().parseerrorreplacetoken(
errorstart,
errorend,
currentkind,
errortokensource,
errortokenname,
name);
break;
case scope_code:
stringbuffer buf = new stringbuffer();

int[] addedtokens = null;
int addedtokencount = 0;
if(this.recoveryscanner != null) {
addedtokens = new int[parser.scope_rhs.length - parser.scope_suffix[- nameindex]];
}

for (int i = parser.scope_suffix[- nameindex]; parser.scope_rhs[i] != 0; i++) {
buf.append(parser.readablename[parser.scope_rhs[i]]);
if (parser.scope_rhs[i + 1] != 0) // any more symbols to print?
buf.append(' ');

if(addedtokens != null) {
int tmpaddedtoken = parser.reverse_index[parser.scope_rhs[i]];
if (tmpaddedtoken > -1) {
int length = addedtokens.length;
if(addedtokencount == length) {
system.arraycopy(addedtokens, 0, addedtokens = new int[length * 2], 0, length);
}
addedtokens[addedtokencount++] = tmpaddedtoken;
} else {
int[] template = getntermtemplate(-tmpaddedtoken);
if(template != null) {
for (int j = 0; j < template.length; j++) {
int length = addedtokens.length;
if(addedtokencount == length) {
system.arraycopy(addedtokens, 0, addedtokens = new int[length * 2], 0, length);
}
addedtokens[addedtokencount++] = template[j];
}
} else {
addedtokencount = 0;
addedtokens = null;
}
}
}
}

if(addedtokencount > 0) {
system.arraycopy(addedtokens, 0, addedtokens = new int[addedtokencount], 0, addedtokencount);

int completedtoken = -1;
if(scopenameindex != 0) {
completedtoken = -parser.reverse_index[scopenameindex];
}
this.recoveryscanner.inserttokens(addedtokens, completedtoken, errorend);
}

if (scopenameindex != 0) {
if(this.reportproblem) problemreporter().parseerrorinserttocomplete(
errorstart,
errorend,
buf.tostring(),
parser.readablename[scopenameindex]);
} else {
if(this.reportproblem) problemreporter().parseerrorinserttocompletescope(
errorstart,
errorend,
buf.tostring());
}

break;
case eof_code:
if(this.reportproblem) problemreporter().parseerrorunexpectedend(
errorstart,
errorend);
break;
case merge_code:
if(this.recoveryscanner != null) {
if(addedtoken > -1) {
this.recoveryscanner.replacetokens(addedtoken, errorstart, errorend);
} else {
int[] template = getntermtemplate(-addedtoken);
if(template != null) {
this.recoveryscanner.replacetokens(template, errorstart, errorend);
}
}
}
if(this.reportproblem) problemreporter().parseerrormergetokens(
errorstart,
errorend,
name);
break;
case misplaced_code:
if(this.recoveryscanner != null) {
this.recoveryscanner.removetokens(errorstart, errorend);
}
if(this.reportproblem) problemreporter().parseerrormisplacedconstruct(
errorstart,
errorend);
break;
default:
if (name.length() == 0) {
if(this.recoveryscanner != null) {
this.recoveryscanner.removetokens(errorstart, errorend);
}
if(this.reportproblem) problemreporter().parseerrornosuggestion(
errorstart,
errorend,
currentkind,
errortokensource,
errortokenname);
} else {
if(this.recoveryscanner != null) {
if(addedtoken > -1) {
this.recoveryscanner.replacetokens(addedtoken, errorstart, errorend);
} else {
int[] template = getntermtemplate(-addedtoken);
if(template != null) {
this.recoveryscanner.replacetokens(template, errorstart, errorend);
}
}
}
if(this.reportproblem) problemreporter().parseerrorreplacetoken(
errorstart,
errorend,
currentkind,
errortokensource,
errortokenname,
name);
}
break;
}
}

private void reportsecondaryerror(int msgcode,	int nameindex,	int lefttoken,	int righttoken, int scopenameindex) {
string name;
if (nameindex >= 0) {
name = parser.readablename[nameindex];
} else {
name = util.empty_string;
}

int errorstart = -1;
if(this.lexstream.isinsidestream(lefttoken)) {
if(lefttoken == 0) {
errorstart = this.lexstream.start(lefttoken + 1);
} else {
errorstart = this.lexstream.start(lefttoken);
}
} else {
if(lefttoken == this.errortoken) {
errorstart = this.errortokenstart;
} else {
for (int i = 0; i <= this.statestacktop; i++) {
if(this.locationstack[i] == lefttoken) {
errorstart = this.locationstartstack[i];
}
}
}
if(errorstart == -1) {
errorstart = this.lexstream.start(righttoken);
}
}
int errorend = this.lexstream.end(righttoken);

int addedtoken = -1;
if(this.recoveryscanner != null) {
if (nameindex >= 0) {
addedtoken = parser.reverse_index[nameindex];
}
}

switch(msgcode) {
case misplaced_code:
if(this.recoveryscanner != null) {
this.recoveryscanner.removetokens(errorstart, errorend);
}
if(this.reportproblem) problemreporter().parseerrormisplacedconstruct(
errorstart,
errorend);
break;
case scope_code:
// error start is on the last token start
errorstart = this.lexstream.start(righttoken);

stringbuffer buf = new stringbuffer();

int[] addedtokens = null;
int addedtokencount = 0;
if(this.recoveryscanner != null) {
addedtokens = new int[parser.scope_rhs.length - parser.scope_suffix[- nameindex]];
}

for (int i = parser.scope_suffix[- nameindex]; parser.scope_rhs[i] != 0; i++) {

buf.append(parser.readablename[parser.scope_rhs[i]]);
if (parser.scope_rhs[i+1] != 0)
buf.append(' ');

if(addedtokens != null) {
int tmpaddedtoken = parser.reverse_index[parser.scope_rhs[i]];
if (tmpaddedtoken > -1) {
int length = addedtokens.length;
if(addedtokencount == length) {
system.arraycopy(addedtokens, 0, addedtokens = new int[length * 2], 0, length);
}
addedtokens[addedtokencount++] = tmpaddedtoken;
} else {
int[] template = getntermtemplate(-tmpaddedtoken);
if(template != null) {
for (int j = 0; j < template.length; j++) {
int length = addedtokens.length;
if(addedtokencount == length) {
system.arraycopy(addedtokens, 0, addedtokens = new int[length * 2], 0, length);
}
addedtokens[addedtokencount++] = template[j];
}
} else {
addedtokencount = 0;
addedtokens = null;
}
}
}
}
if(addedtokencount > 0) {
system.arraycopy(addedtokens, 0, addedtokens = new int[addedtokencount], 0, addedtokencount);
int completedtoken = -1;
if(scopenameindex != 0) {
completedtoken = -parser.reverse_index[scopenameindex];
}
this.recoveryscanner.inserttokens(addedtokens, completedtoken, errorend);
}
if (scopenameindex != 0) {
if(this.reportproblem) problemreporter().parseerrorinserttocomplete(
errorstart,
errorend,
buf.tostring(),
parser.readablename[scopenameindex]);
} else {
if(this.reportproblem) problemreporter().parseerrorinserttocompletephrase(
errorstart,
errorend,
buf.tostring());
}
break;
case merge_code:
if(this.recoveryscanner != null) {
if(addedtoken > -1) {
this.recoveryscanner.replacetokens(addedtoken, errorstart, errorend);
} else {
int[] template = getntermtemplate(-addedtoken);
if(template != null) {
this.recoveryscanner.replacetokens(template, errorstart, errorend);
}
}
}
if(this.reportproblem) problemreporter().parseerrormergetokens(
errorstart,
errorend,
name);
break;
case deletion_code:
if(this.recoveryscanner != null) {
this.recoveryscanner.removetokens(errorstart, errorend);
}
if(this.reportproblem) problemreporter().parseerrordeletetokens(
errorstart,
errorend);
break;
default:
if (name.length() == 0) {
if(this.recoveryscanner != null) {
this.recoveryscanner.removetokens(errorstart, errorend);
}
if(this.reportproblem) problemreporter().parseerrornosuggestionfortokens(
errorstart,
errorend);
} else {
if(this.recoveryscanner != null) {
if(addedtoken > -1) {
this.recoveryscanner.replacetokens(addedtoken, errorstart, errorend);
} else {
int[] template = getntermtemplate(-addedtoken);
if(template != null) {
this.recoveryscanner.replacetokens(template, errorstart, errorend);
}
}
}
if(this.reportproblem) problemreporter().parseerrorreplacetokens(
errorstart,
errorend,
name);
}
}
return;
}

private int[] getntermtemplate(int sym) {
int templateindex = parser.recovery_templates_index[sym];
if(templateindex > 0) {
int[] result = new int[parser.recovery_templates.length];
int count = 0;
for(int j = templateindex; parser.recovery_templates[j] != 0; j++) {
result[count++] = parser.recovery_templates[j];
}
system.arraycopy(result, 0, result = new int[count], 0, count);
return result;
} else {
return null;
}
}

public string tostring() {
stringbuffer res = new stringbuffer();

res.append(this.lexstream.tostring());

return res.tostring();
}
}
