/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

import org.eclipse.jdt.internal.compiler.ast.astnode;

public interface classfileconstants {

int accdefault = 0;
/*
* modifiers
*/
int accpublic       = 0x0001;
int accprivate      = 0x0002;
int accprotected    = 0x0004;
int accstatic       = 0x0008;
int accfinal        = 0x0010;
int accsynchronized = 0x0020;
int accvolatile     = 0x0040;
int accbridge       = 0x0040;
int acctransient    = 0x0080;
int accvarargs      = 0x0080;
int accnative       = 0x0100;
int accinterface    = 0x0200;
int accabstract     = 0x0400;
int accstrictfp     = 0x0800;
int accsynthetic    = 0x1000;
int accannotation   = 0x2000;
int accenum         = 0x4000;

/**
* other vm flags.
*/
int accsuper = 0x0020;

/**
* extra flags for types and members attributes.
*/
int accannotationdefault = astnode.bit18; // indicate presence of an attribute  "defaultvalue" (annotation method)
int accdeprecated = astnode.bit21; // indicate presence of an attribute "deprecated"

int utf8tag = 1;
int integertag = 3;
int floattag = 4;
int longtag = 5;
int doubletag = 6;
int classtag = 7;
int stringtag = 8;
int fieldreftag = 9;
int methodreftag = 10;
int interfacemethodreftag = 11;
int nameandtypetag = 12;

int constantmethodreffixedsize = 5;
int constantclassfixedsize = 3;
int constantdoublefixedsize = 9;
int constantfieldreffixedsize = 5;
int constantfloatfixedsize = 5;
int constantintegerfixedsize = 5;
int constantinterfacemethodreffixedsize = 5;
int constantlongfixedsize = 9;
int constantstringfixedsize = 3;
int constantutf8fixedsize = 3;
int constantnameandtypefixedsize = 5;

int major_version_1_1 = 45;
int major_version_1_2 = 46;
int major_version_1_3 = 47;
int major_version_1_4 = 48;
int major_version_1_5 = 49;
int major_version_1_6 = 50;
int major_version_1_7 = 51;

int minor_version_0 = 0;
int minor_version_1 = 1;
int minor_version_2 = 2;
int minor_version_3 = 3;
int minor_version_4 = 4;

// jdk 1.1 -> 1.7, comparable value allowing to check both major/minor version at once 1.4.1 > 1.4.0
// 16 unsigned bits for major, then 16 bits for minor
long jdk1_1 = ((long)classfileconstants.major_version_1_1 << 16) + classfileconstants.minor_version_3; // 1.1. is 45.3
long jdk1_2 =  ((long)classfileconstants.major_version_1_2 << 16) + classfileconstants.minor_version_0;
long jdk1_3 =  ((long)classfileconstants.major_version_1_3 << 16) + classfileconstants.minor_version_0;
long jdk1_4 = ((long)classfileconstants.major_version_1_4 << 16) + classfileconstants.minor_version_0;
long jdk1_5 = ((long)classfileconstants.major_version_1_5 << 16) + classfileconstants.minor_version_0;
long jdk1_6 = ((long)classfileconstants.major_version_1_6 << 16) + classfileconstants.minor_version_0;
long jdk1_7 = ((long)classfileconstants.major_version_1_7 << 16) + classfileconstants.minor_version_0;

/*
* cldc1.1 is 45.3, but we modify it to be different from jdk1_1.
* in the code gen, we will generate the same target value as jdk1_1
*/
long cldc_1_1 = ((long)classfileconstants.major_version_1_1 << 16) + classfileconstants.minor_version_4;

// jdk level used to denote future releases: optional behavior is not enabled for now, but may become so. in order to enable these,
// search for references to this constant, and change it to one of the official jdt constants above.
long jdk_deferred = long.max_value;

int int_array = 10;
int byte_array = 8;
int boolean_array = 4;
int short_array = 9;
int char_array = 5;
int long_array = 11;
int float_array = 6;
int double_array = 7;

// debug attributes
int attr_source = 0x1; // sourcefileattribute
int attr_lines = 0x2; // linenumberattribute
int attr_vars = 0x4; // localvariabletableattribute
int attr_stack_map_table = 0x8; // stack map table attribute
int attr_stack_map = 0x10; // stack map attribute: cldc
}
