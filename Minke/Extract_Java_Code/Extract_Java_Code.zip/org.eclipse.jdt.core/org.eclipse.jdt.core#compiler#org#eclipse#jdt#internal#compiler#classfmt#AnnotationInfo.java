/*******************************************************************************
* copyright (c) 2005, 2009 bea systems, inc.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*    tyeung@@bea.com - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.annotation;
import org.eclipse.jdt.internal.compiler.codegen.constantpool;
import org.eclipse.jdt.internal.compiler.env.*;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;

public class annotationinfo extends classfilestruct implements ibinaryannotation {
/** the name of the annotation type */
private char[] typename;
/**
* null until this annotation is initialized
* @@see #getelementvaluepairs()
*/
private elementvaluepairinfo[] pairs;

long standardannotationtagbits = 0;
int readoffset = 0;

static object[] emptyvaluearray = new object[0];

annotationinfo(byte[] classfilebytes, int[] contantpooloffsets, int offset) {
super(classfilebytes, contantpooloffsets, offset);
}
/**
* @@param classfilebytes
* @@param offset the offset into <code>classfilebytes</code> for the "type_index" of the annotation attribute.
* @@param populate <code>true</code> to indicate to build out the annotation structure.
*/
annotationinfo(byte[] classfilebytes, int[] contantpooloffsets, int offset, boolean runtimevisible, boolean populate) {
this(classfilebytes, contantpooloffsets, offset);
if (populate)
decodeannotation();
else
this.readoffset = scanannotation(0, runtimevisible, true);
}
private void decodeannotation() {
this.readoffset = 0;
int utf8offset = this.constantpooloffsets[u2at(0)] - this.structoffset;
this.typename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
int numberofpairs = u2at(2);
// u2 type_index + u2 num_member_value_pair
this.readoffset += 4;
this.pairs = numberofpairs == 0 ? elementvaluepairinfo.nomembers : new elementvaluepairinfo[numberofpairs];
for (int i = 0; i < numberofpairs; i++) {
// u2 member_name_index;
utf8offset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
char[] membername = utf8at(utf8offset + 3, u2at(utf8offset + 1));
this.readoffset += 2;
object value = decodedefaultvalue();
this.pairs[i] = new elementvaluepairinfo(membername, value);
}
}
object decodedefaultvalue() {
object value = null;
// u1 tag;
int tag = u1at(this.readoffset);
this.readoffset++;
int constvalueoffset = -1;
switch (tag) {
case 'z': // boolean constant
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
value = booleanconstant.fromvalue(i4at(constvalueoffset + 1) == 1);
this.readoffset += 2;
break;
case 'i': // integer constant
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
value = intconstant.fromvalue(i4at(constvalueoffset + 1));
this.readoffset += 2;
break;
case 'c': // char constant
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
value = charconstant.fromvalue((char) i4at(constvalueoffset + 1));
this.readoffset += 2;
break;
case 'b': // byte constant
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
value = byteconstant.fromvalue((byte) i4at(constvalueoffset + 1));
this.readoffset += 2;
break;
case 's': // short constant
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
value = shortconstant.fromvalue((short) i4at(constvalueoffset + 1));
this.readoffset += 2;
break;
case 'd': // double constant
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
value = doubleconstant.fromvalue(doubleat(constvalueoffset + 1));
this.readoffset += 2;
break;
case 'f': // float constant
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
value = floatconstant.fromvalue(floatat(constvalueoffset + 1));
this.readoffset += 2;
break;
case 'j': // long constant
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
value = longconstant.fromvalue(i8at(constvalueoffset + 1));
this.readoffset += 2;
break;
case 's': // string
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
value = stringconstant.fromvalue(string.valueof(utf8at(constvalueoffset + 3, u2at(constvalueoffset + 1))));
this.readoffset += 2;
break;
case 'e':
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
char[] typename = utf8at(constvalueoffset + 3, u2at(constvalueoffset + 1));
this.readoffset += 2;
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
char[] constname = utf8at(constvalueoffset + 3, u2at(constvalueoffset + 1));
this.readoffset += 2;
value = new enumconstantsignature(typename, constname);
break;
case 'c':
constvalueoffset = this.constantpooloffsets[u2at(this.readoffset)] - this.structoffset;
char[] classname = utf8at(constvalueoffset + 3, u2at(constvalueoffset + 1));
value = new classsignature(classname);
this.readoffset += 2;
break;
case '@@':
value = new annotationinfo(this.reference, this.constantpooloffsets, this.readoffset + this.structoffset, false, true);
this.readoffset += ((annotationinfo) value).readoffset;
break;
case '[':
int numberofvalues = u2at(this.readoffset);
this.readoffset += 2;
if (numberofvalues == 0) {
value = emptyvaluearray;
} else {
object[] arrayelements = new object[numberofvalues];
value = arrayelements;
for (int i = 0; i < numberofvalues; i++)
arrayelements[i] = decodedefaultvalue();
}
break;
default:
throw new illegalstateexception("unrecognized tag " + (char) tag); //$non-nls-1$
}
return value;
}
public ibinaryelementvaluepair[] getelementvaluepairs() {
if (this.pairs == null)
initialize();
return this.pairs;
}
public char[] gettypename() {
return this.typename;
}
void initialize() {
if (this.pairs == null)
decodeannotation();
}
private int readretentionpolicy(int offset) {
int currentoffset = offset;
int tag = u1at(currentoffset);
currentoffset++;
switch (tag) {
case 'e':
int utf8offset = this.constantpooloffsets[u2at(currentoffset)] - this.structoffset;
char[] typename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
currentoffset += 2;
if (typename.length == 38 && charoperation.equals(typename, constantpool.java_lang_annotation_retentionpolicy)) {
utf8offset = this.constantpooloffsets[u2at(currentoffset)] - this.structoffset;
char[] constname = utf8at(utf8offset + 3, u2at(utf8offset + 1));
this.standardannotationtagbits |= annotation.getretentionpolicy(constname);
}
currentoffset += 2;
break;
case 'b':
case 'c':
case 'd':
case 'f':
case 'i':
case 'j':
case 's':
case 'z':
case 's':
case 'c':
currentoffset += 2;
break;
case '@@':
// none of the supported standard annotation are in the nested
// level.
currentoffset = scanannotation(currentoffset, false, false);
break;
case '[':
int numberofvalues = u2at(currentoffset);
currentoffset += 2;
for (int i = 0; i < numberofvalues; i++)
currentoffset = scanelementvalue(currentoffset);
break;
default:
throw new illegalstateexception();
}
return currentoffset;
}
private int readtargetvalue(int offset) {
int currentoffset = offset;
int tag = u1at(currentoffset);
currentoffset++;
switch (tag) {
case 'e':
int utf8offset = this.constantpooloffsets[u2at(currentoffset)] - this.structoffset;
char[] typename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
currentoffset += 2;
if (typename.length == 34 && charoperation.equals(typename, constantpool.java_lang_annotation_elementtype)) {
utf8offset = this.constantpooloffsets[u2at(currentoffset)] - this.structoffset;
char[] constname = utf8at(utf8offset + 3, u2at(utf8offset + 1));
this.standardannotationtagbits |= annotation.gettargetelementtype(constname);
}
currentoffset += 2;
break;
case 'b':
case 'c':
case 'd':
case 'f':
case 'i':
case 'j':
case 's':
case 'z':
case 's':
case 'c':
currentoffset += 2;
break;
case '@@':
// none of the supported standard annotation are in the nested
// level.
currentoffset = scanannotation(currentoffset, false, false);
break;
case '[':
int numberofvalues = u2at(currentoffset);
currentoffset += 2;
if (numberofvalues == 0) {
this.standardannotationtagbits |= tagbits.annotationtarget;
} else {
for (int i = 0; i < numberofvalues; i++)
currentoffset = readtargetvalue(currentoffset);
}
break;
default:
throw new illegalstateexception();
}
return currentoffset;
}
/**
* read through this annotation in order to figure out the necessary tag
* bits and the length of this annotation. the data structure will not be
* flushed out.
*
* the tag bits are derived from the following (supported) standard
* annotation. java.lang.annotation.documented,
* java.lang.annotation.retention, java.lang.annotation.target, and
* java.lang.deprecated
*
* @@param expectruntimevisibleanno
*            <code>true</cod> to indicate that this is a runtime-visible annotation
* @@param toplevel <code>false</code> to indicate that an nested annotation is read.
* 		<code>true</code> otherwise
* @@return the next offset to read.
*/
private int scanannotation(int offset, boolean expectruntimevisibleanno, boolean toplevel) {
int currentoffset = offset;
int utf8offset = this.constantpooloffsets[u2at(offset)] - this.structoffset;
char[] typename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
if (toplevel)
this.typename = typename;
int numberofpairs = u2at(offset + 2);
// u2 type_index + u2 number_member_value_pair
currentoffset += 4;
if (expectruntimevisibleanno && toplevel) {
switch (typename.length) {
case 22:
if (charoperation.equals(typename, constantpool.java_lang_deprecated)) {
this.standardannotationtagbits |= tagbits.annotationdeprecated;
return currentoffset;
}
break;
case 29:
if (charoperation.equals(typename, constantpool.java_lang_annotation_target)) {
currentoffset += 2;
return readtargetvalue(currentoffset);
}
break;
case 33:
if (charoperation.equals(typename, constantpool.java_lang_annotation_documented)) {
this.standardannotationtagbits |= tagbits.annotationdocumented;
return currentoffset;
}
break;
case 32:
if (charoperation.equals(typename, constantpool.java_lang_annotation_retention)) {
currentoffset += 2;
return readretentionpolicy(currentoffset);
}
if (charoperation.equals(typename, constantpool.java_lang_annotation_inherited)) {
this.standardannotationtagbits |= tagbits.annotationinherited;
return currentoffset;
}
break;
}
}
for (int i = 0; i < numberofpairs; i++) {
// u2 member_name_index
currentoffset += 2;
currentoffset = scanelementvalue(currentoffset);
}
return currentoffset;
}
/**
* @@param offset
*            the offset to start reading.
* @@return the next offset to read.
*/
private int scanelementvalue(int offset) {
int currentoffset = offset;
int tag = u1at(currentoffset);
currentoffset++;
switch (tag) {
case 'b':
case 'c':
case 'd':
case 'f':
case 'i':
case 'j':
case 's':
case 'z':
case 's':
case 'c':
currentoffset += 2;
break;
case 'e':
currentoffset += 4;
break;
case '@@':
// none of the supported standard annotation are in the nested
// level.
currentoffset = scanannotation(currentoffset, false, false);
break;
case '[':
int numberofvalues = u2at(currentoffset);
currentoffset += 2;
for (int i = 0; i < numberofvalues; i++)
currentoffset = scanelementvalue(currentoffset);
break;
default:
throw new illegalstateexception();
}
return currentoffset;
}
public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append('@@');
buffer.append(this.typename);
if (this.pairs != null) {
buffer.append('(');
buffer.append("\n\t"); //$non-nls-1$
for (int i = 0, len = this.pairs.length; i < len; i++) {
if (i > 0)
buffer.append(",\n\t"); //$non-nls-1$
buffer.append(this.pairs[i]);
}
buffer.append(')');
}
return buffer.tostring();
}
}
