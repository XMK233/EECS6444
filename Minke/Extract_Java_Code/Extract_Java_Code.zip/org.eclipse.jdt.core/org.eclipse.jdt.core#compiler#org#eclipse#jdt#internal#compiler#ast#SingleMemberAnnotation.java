/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;

/**
* singlememberannotation node
*/
public class singlememberannotation extends annotation {

public expression membervalue;
private membervaluepair[] singlepairs; // fake pair set, only value has accurate positions

public singlememberannotation(typereference type, int sourcestart) {
this.type = type;
this.sourcestart = sourcestart;
this.sourceend = type.sourceend;
}

public elementvaluepair[] computeelementvaluepairs() {
return new elementvaluepair[] {membervaluepairs()[0].compilerelementpair};
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.annotation#membervaluepairs()
*/
public membervaluepair[] membervaluepairs() {
if (this.singlepairs == null) {
this.singlepairs =
new membervaluepair[]{
new membervaluepair(value, this.membervalue.sourcestart, this.membervalue.sourceend, this.membervalue)
};
}
return this.singlepairs;
}

public stringbuffer printexpression(int indent, stringbuffer output) {
super.printexpression(indent, output);
output.append('(');
this.membervalue.printexpression(indent, output);
return output.append(')');
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.type != null) {
this.type.traverse(visitor, scope);
}
if (this.membervalue != null) {
this.membervalue.traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
