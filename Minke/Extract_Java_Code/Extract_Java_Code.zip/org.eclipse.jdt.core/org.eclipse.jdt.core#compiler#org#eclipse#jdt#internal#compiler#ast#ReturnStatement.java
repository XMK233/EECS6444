/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class returnstatement extends statement {

public expression expression;
public subroutinestatement[] subroutines;
public localvariablebinding savevaluevariable;
public int initstateindex = -1;

public returnstatement(expression expression, int sourcestart, int sourceend) {
this.sourcestart = sourcestart;
this.sourceend = sourceend;
this.expression = expression ;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {	// here requires to generate a sequence of finally blocks invocations depending corresponding
// to each of the traversed try statements, so that execution will terminate properly.

// lookup the label, this should answer the returncontext

if (this.expression != null) {
flowinfo = this.expression.analysecode(currentscope, flowcontext, flowinfo);
}
this.initstateindex =
currentscope.methodscope().recordinitializationstates(flowinfo);
// compute the return sequence (running the finally blocks)
flowcontext traversedcontext = flowcontext;
int subcount = 0;
boolean savevalueneeded = false;
boolean hasvaluetosave = needvaluestore();
do {
subroutinestatement sub;
if ((sub = traversedcontext.subroutine()) != null) {
if (this.subroutines == null){
this.subroutines = new subroutinestatement[5];
}
if (subcount == this.subroutines.length) {
system.arraycopy(this.subroutines, 0, (this.subroutines = new subroutinestatement[subcount*2]), 0, subcount); // grow
}
this.subroutines[subcount++] = sub;
if (sub.issubroutineescaping()) {
savevalueneeded = false;
this.bits |= astnode.isanysubroutineescaping;
break;
}
}
traversedcontext.recordreturnfrom(flowinfo.unconditionalinits());

if (traversedcontext instanceof insidesubroutineflowcontext) {
astnode node = traversedcontext.associatednode;
if (node instanceof synchronizedstatement) {
this.bits |= astnode.issynchronized;
} else if (node instanceof trystatement) {
trystatement trystatement = (trystatement) node;
flowinfo.addinitializationsfrom(trystatement.subroutineinits); // collect inits
if (hasvaluetosave) {
if (this.savevaluevariable == null){ // closest subroutine secret variable is used
preparesavevaluelocation(trystatement);
}
savevalueneeded = true;
this.initstateindex =
currentscope.methodscope().recordinitializationstates(flowinfo);
}
}
} else if (traversedcontext instanceof initializationflowcontext) {
currentscope.problemreporter().cannotreturnininitializer(this);
return flowinfo.dead_end;
}
} while ((traversedcontext = traversedcontext.parent) != null);

// resize subroutines
if ((this.subroutines != null) && (subcount != this.subroutines.length)) {
system.arraycopy(this.subroutines, 0, (this.subroutines = new subroutinestatement[subcount]), 0, subcount);
}

// secret local variable for return value (note that this can only occur in a real method)
if (savevalueneeded) {
if (this.savevaluevariable != null) {
this.savevaluevariable.useflag = localvariablebinding.used;
}
} else {
this.savevaluevariable = null;
if (((this.bits & astnode.issynchronized) == 0) && this.expression != null && this.expression.resolvedtype == typebinding.boolean) {
this.expression.bits |= astnode.isreturnedvalue;
}
}
return flowinfo.dead_end;
}

/**
* retrun statement code generation
*
*   generate the finallyinvocationsequence.
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & astnode.isreachable) == 0) {
return;
}
int pc = codestream.position;
boolean alreadygeneratedexpression = false;
// generate the expression
if (needvaluestore()) {
alreadygeneratedexpression = true;
this.expression.generatecode(currentscope, codestream, needvalue()); // no value needed if non-returning subroutine
generatestoresavevalueifnecessary(codestream);
}

// generation of code responsible for invoking the finally blocks in sequence
if (this.subroutines != null) {
object reusablejsrtarget = this.expression == null ? (object)typebinding.void : this.expression.reusablejsrtarget();
for (int i = 0, max = this.subroutines.length; i < max; i++) {
subroutinestatement sub = this.subroutines[i];
boolean didescape = sub.generatesubroutineinvocation(currentscope, codestream, reusablejsrtarget, this.initstateindex, this.savevaluevariable);
if (didescape) {
codestream.recordpositionsfrom(pc, this.sourcestart);
subroutinestatement.reenterallexceptionhandlers(this.subroutines, i, codestream);
return;
}
}
}
if (this.savevaluevariable != null) {
codestream.addvariable(this.savevaluevariable);
codestream.load(this.savevaluevariable);
}
if (this.expression != null && !alreadygeneratedexpression) {
this.expression.generatecode(currentscope, codestream, true);
generatestoresavevalueifnecessary(codestream);
}
// output the suitable return bytecode or wrap the value inside a descriptor for doits
generatereturnbytecode(codestream);
if (this.savevaluevariable != null) {
codestream.removevariable(this.savevaluevariable);
}
if (this.initstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.initstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.initstateindex);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
subroutinestatement.reenterallexceptionhandlers(this.subroutines, -1, codestream);
}

/**
* dump the suitable return bytecode for a return statement
*
*/
public void generatereturnbytecode(codestream codestream) {
codestream.generatereturnbytecode(this.expression);
}

public void generatestoresavevalueifnecessary(codestream codestream){
if (this.savevaluevariable != null) {
codestream.store(this.savevaluevariable, false);
}
}

private boolean needvaluestore() {
return this.expression != null
&& (this.expression.constant == constant.notaconstant || (this.expression.implicitconversion & typeids.boxing)!= 0)
&& !(this.expression instanceof nullliteral);
}

public boolean needvalue() {
return this.savevaluevariable != null
|| (this.bits & astnode.issynchronized) != 0
|| ((this.bits & astnode.isanysubroutineescaping) == 0);
}

public void preparesavevaluelocation(trystatement targettrystatement){
this.savevaluevariable = targettrystatement.secretreturnvalue;
}

public stringbuffer printstatement(int tab, stringbuffer output){
printindent(tab, output).append("return "); //$non-nls-1$
if (this.expression != null )
this.expression.printexpression(0, output) ;
return output.append(';');
}

public void resolve(blockscope scope) {
methodscope methodscope = scope.methodscope();
methodbinding methodbinding;
typebinding methodtype =
(methodscope.referencecontext instanceof abstractmethoddeclaration)
? ((methodbinding = ((abstractmethoddeclaration) methodscope.referencecontext).binding) == null
? null
: methodbinding.returntype)
: typebinding.void;
typebinding expressiontype;
if (methodtype == typebinding.void) {
// the expression should be null
if (this.expression == null)
return;
if ((expressiontype = this.expression.resolvetype(scope)) != null)
scope.problemreporter().attempttoreturnnonvoidexpression(this, expressiontype);
return;
}
if (this.expression == null) {
if (methodtype != null) scope.problemreporter().shouldreturn(methodtype, this);
return;
}
this.expression.setexpectedtype(methodtype); // needed in case of generic method invocation
if ((expressiontype = this.expression.resolvetype(scope)) == null) return;
if (expressiontype == typebinding.void) {
scope.problemreporter().attempttoreturnvoidvalue(this);
return;
}
if (methodtype == null)
return;

if (methodtype != expressiontype) // must call before computeconversion() and typemismatcherror()
scope.compilationunitscope().recordtypeconversion(methodtype, expressiontype);
if (this.expression.isconstantvalueoftypeassignabletotype(expressiontype, methodtype)
|| expressiontype.iscompatiblewith(methodtype)) {

this.expression.computeconversion(scope, methodtype, expressiontype);
if (expressiontype.needsuncheckedconversion(methodtype)) {
scope.problemreporter().unsafetypeconversion(this.expression, expressiontype, methodtype);
}
if (this.expression instanceof castexpression
&& (this.expression.bits & (astnode.unnecessarycast|astnode.disableunnecessarycastcheck)) == 0) {
castexpression.checkneedforassignedcast(scope, methodtype, (castexpression) this.expression);
}
return;
} else if (isboxingcompatible(expressiontype, methodtype, this.expression, scope)) {
this.expression.computeconversion(scope, methodtype, expressiontype);
if (this.expression instanceof castexpression
&& (this.expression.bits & (astnode.unnecessarycast|astnode.disableunnecessarycastcheck)) == 0) {
castexpression.checkneedforassignedcast(scope, methodtype, (castexpression) this.expression);
}			return;
}
if ((methodtype.tagbits & tagbits.hasmissingtype) == 0) {
// no need to complain if return type was missing (avoid secondary error : 220967)
scope.problemreporter().typemismatcherror(expressiontype, methodtype, this.expression, null);
}
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.expression != null)
this.expression.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
