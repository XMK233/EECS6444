/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.batch;

import java.io.file;
import java.io.filenamefilter;
import java.io.ioexception;
import java.util.hashtable;
import java.util.list;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.classfmt.classfilereader;
import org.eclipse.jdt.internal.compiler.classfmt.classformatexception;
import org.eclipse.jdt.internal.compiler.env.accessruleset;
import org.eclipse.jdt.internal.compiler.env.nameenvironmentanswer;
import org.eclipse.jdt.internal.compiler.parser.scannerhelper;
import org.eclipse.jdt.internal.compiler.util.util;

public class classpathdirectory extends classpathlocation {

private hashtable directorycache;
private string[] missingpackageholder = new string[1];
private int mode; // ability to only consider one kind of files (source vs. binaries), by default use both
private string encoding; // only useful if referenced in the source path

classpathdirectory(file directory, string encoding, int mode,
accessruleset accessruleset, string destinationpath) {
super(accessruleset, destinationpath);
this.mode = mode;
try {
this.path = directory.getcanonicalpath();
} catch (ioexception e) {
// should not happen as we know that the file exists
this.path = directory.getabsolutepath();
}
if (!this.path.endswith(file.separator))
this.path += file.separator;
this.directorycache = new hashtable(11);
this.encoding = encoding;
}
string[] directorylist(string qualifiedpackagename) {
string[] dirlist = (string[]) this.directorycache.get(qualifiedpackagename);
if (dirlist == this.missingpackageholder) return null; // package exists in another classpath directory or jar
if (dirlist != null) return dirlist;

file dir = new file(this.path + qualifiedpackagename);
notfound : if (dir.isdirectory()) {
// must protect against a case insensitive file call
// walk the qualifiedpackagename backwards looking for an uppercase character before the '/'
int index = qualifiedpackagename.length();
int last = qualifiedpackagename.lastindexof(file.separatorchar);
while (--index > last && !scannerhelper.isuppercase(qualifiedpackagename.charat(index))){/*empty*/}
if (index > last) {
if (last == -1) {
if (!doesfileexist(qualifiedpackagename, util.empty_string))
break notfound;
} else {
string packagename = qualifiedpackagename.substring(last + 1);
string parentpackage = qualifiedpackagename.substring(0, last);
if (!doesfileexist(packagename, parentpackage))
break notfound;
}
}
if ((dirlist = dir.list()) == null)
dirlist = charoperation.no_strings;
this.directorycache.put(qualifiedpackagename, dirlist);
return dirlist;
}
this.directorycache.put(qualifiedpackagename, this.missingpackageholder);
return null;
}
boolean doesfileexist(string filename, string qualifiedpackagename) {
string[] dirlist = directorylist(qualifiedpackagename);
if (dirlist == null) return false; // most common case

for (int i = dirlist.length; --i >= 0;)
if (filename.equals(dirlist[i]))
return true;
return false;
}
public list fetchlinkedjars(filesystem.classpathsectionproblemreporter problemreporter) {
return null;
}
public nameenvironmentanswer findclass(char[] typename, string qualifiedpackagename, string qualifiedbinaryfilename) {
return findclass(typename, qualifiedpackagename, qualifiedbinaryfilename, false);
}
public nameenvironmentanswer findclass(char[] typename, string qualifiedpackagename, string qualifiedbinaryfilename, boolean asbinaryonly) {
if (!ispackage(qualifiedpackagename)) return null; // most common case

string filename = new string(typename);
boolean binaryexists = ((this.mode & binary) != 0) && doesfileexist(filename + suffix_string_class, qualifiedpackagename);
boolean sourceexists = ((this.mode & source) != 0) && doesfileexist(filename + suffix_string_java, qualifiedpackagename);
if (sourceexists && !asbinaryonly) {
string fullsourcepath = this.path + qualifiedbinaryfilename.substring(0, qualifiedbinaryfilename.length() - 6)  + suffix_string_java;
if (!binaryexists)
return new nameenvironmentanswer(new compilationunit(null,
fullsourcepath, this.encoding, this.destinationpath),
fetchaccessrestriction(qualifiedbinaryfilename));
string fullbinarypath = this.path + qualifiedbinaryfilename;
long binarymodified = new file(fullbinarypath).lastmodified();
long sourcemodified = new file(fullsourcepath).lastmodified();
if (sourcemodified > binarymodified)
return new nameenvironmentanswer(new compilationunit(null,
fullsourcepath, this.encoding, this.destinationpath),
fetchaccessrestriction(qualifiedbinaryfilename));
}
if (binaryexists) {
try {
classfilereader reader = classfilereader.read(this.path + qualifiedbinaryfilename);
if (reader != null)
return new nameenvironmentanswer(
reader,
fetchaccessrestriction(qualifiedbinaryfilename));
} catch (ioexception e) {
// treat as if file is missing
} catch (classformatexception e) {
// treat as if file is missing
}
}
return null;
}
public char[][][] findtypenames(string qualifiedpackagename) {
if (!ispackage(qualifiedpackagename)) {
return null; // most common case
}
file dir = new file(this.path + qualifiedpackagename);
if (!dir.exists() || !dir.isdirectory()) {
return null;
}
string[] listfiles = dir.list(new filenamefilter() {
public boolean accept(file directory, string name) {
string filename = name.tolowercase();
return filename.endswith(".class") || filename.endswith(".java"); //$non-nls-1$ //$non-nls-2$
}
});
int length;
if (listfiles == null || (length = listfiles.length) == 0) {
return null;
}
char[][][] result = new char[length][][];
char[][] packagename = charoperation.spliton(file.separatorchar, qualifiedpackagename.tochararray());
for (int i = 0; i < length; i++) {
string filename = listfiles[i];
int indexoflastdot = filename.indexof('.');
result[i] = charoperation.arrayconcat(packagename, filename.substring(0, indexoflastdot).tochararray());
}
return result;
}
public void initialize() throws ioexception {
// nothing to do
}
public boolean ispackage(string qualifiedpackagename) {
return directorylist(qualifiedpackagename) != null;
}
public void reset() {
this.directorycache = new hashtable(11);
}
public string tostring() {
return "classpathdirectory " + this.path; //$non-nls-1$
}
public char[] normalizedpath() {
if (this.normalizedpath == null) {
this.normalizedpath = this.path.tochararray();
if (file.separatorchar == '\\') {
charoperation.replace(this.normalizedpath, '\\', '/');
}
}
return this.normalizedpath;
}
public string getpath() {
return this.path;
}
}
