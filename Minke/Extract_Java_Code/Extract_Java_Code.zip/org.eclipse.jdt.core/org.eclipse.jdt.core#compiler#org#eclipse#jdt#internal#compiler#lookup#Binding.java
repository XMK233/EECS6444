/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.astnode;

public abstract class binding {

// binding kinds
public static final int field = astnode.bit1;
public static final int local = astnode.bit2;
public static final int variable = field | local;
public static final int type = astnode.bit3;
public static final int method = astnode.bit4;
public static final int package = astnode.bit5;
public static final int import = astnode.bit6;
public static final int array_type = type | astnode.bit7;
public static final int base_type = type | astnode.bit8;
public static final int parameterized_type = type | astnode.bit9;
public static final int wildcard_type = type | astnode.bit10;
public static final int raw_type = type | astnode.bit11;
public static final int generic_type = type | astnode.bit12;
public static final int type_parameter = type | astnode.bit13;
public static final int intersection_type = type | astnode.bit14;

// shared binding collections
public static final typebinding[] no_types = new typebinding[0];
public static final typebinding[] no_parameters = new typebinding[0];
public static final referencebinding[] no_exceptions = new referencebinding[0];
public static final referencebinding[] any_exception = new referencebinding[] { null }; // special handler for all exceptions
public static final fieldbinding[] no_fields = new fieldbinding[0];
public static final methodbinding[] no_methods = new methodbinding[0];
public static final referencebinding[] no_superinterfaces = new referencebinding[0];
public static final referencebinding[] no_member_types = new referencebinding[0];
public static final typevariablebinding[] no_type_variables = new typevariablebinding[0];
public static final annotationbinding[] no_annotations = new annotationbinding[0];
public static final elementvaluepair[] no_element_value_pairs = new elementvaluepair[0];

public static final fieldbinding[] uninitialized_fields = new fieldbinding[0];
public static final methodbinding[] uninitialized_methods = new methodbinding[0];
public static final referencebinding[] uninitialized_reference_types = new referencebinding[0];

/*
* answer the receiver's binding type from binding.bindingid.
*/
public abstract int kind();
/*
* computes a key that uniquely identifies this binding.
* returns null if binding is not a typebinding, a methodbinding, a fieldbinding or a packagebinding.
*/
public char[] computeuniquekey() {
return computeuniquekey(true/*leaf*/);
}
/*
* computes a key that uniquely identifies this binding. optionally include access flags.
* returns null if binding is not a typebinding, a methodbinding, a fieldbinding or a packagebinding.
*/
public char[] computeuniquekey(boolean isleaf) {
return null;
}

/**
* compute the tagbits for standard annotations. for source types, these could require
* lazily resolving corresponding annotation nodes, in case of forward references.
* @@see org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding#getannotationtagbits()
*/
public long getannotationtagbits() {
return 0;
}

/**
* compute the tag bits for @@deprecated annotations, avoiding resolving
* entire annotation if not necessary.
* @@see org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding#initializedeprecatedannotationtagbits()
*/
public void initializedeprecatedannotationtagbits() {
// empty block
}

/* api
* answer true if the receiver is not a problem binding
*/
public final boolean isvalidbinding() {
return problemid() == problemreasons.noerror;
}
/* api
* answer the problem id associated with the receiver.
* noerror if the receiver is a valid binding.
* note: a parameterized type or an array type are always valid, but may be formed of invalid pieces.
*/
// todo (philippe) should rename into problemreason()
public int problemid() {
return problemreasons.noerror;
}
/* answer a printable representation of the receiver.
*/
public abstract char[] readablename();
/* shorter printable representation of the receiver (no qualified type)
*/
public char[] shortreadablename(){
return readablename();
}
}
