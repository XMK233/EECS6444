/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class javadocimplicittypereference extends typereference {

public char[] token;

public javadocimplicittypereference(char[] name, int pos) {
super();
this.token = name;
this.sourcestart = pos;
this.sourceend = pos;
}
/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.typereference#copydims(int)
*/
public typereference copydims(int dim) {
return null;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.typereference#gettypebinding(org.eclipse.jdt.internal.compiler.lookup.scope)
*/
protected typebinding gettypebinding(scope scope) {
this.constant = constant.notaconstant;
return this.resolvedtype = scope.enclosingreceivertype();
}

public char[] getlasttoken() {
return this.token;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.typereference#gettypename()
*/
public char[][] gettypename() {
if (this.token != null) {
char[][] tokens = { this.token };
return tokens;
}
return null;
}
public boolean isthis() {
return true;
}

/*
* resolves type on a block, class or compilationunit scope.
* we need to modify resoling behavior to avoid raw type creation.
*/
protected typebinding internalresolvetype(scope scope) {
// handle the error here
this.constant = constant.notaconstant;
if (this.resolvedtype != null) { // is a shared type reference which was already resolved
if (this.resolvedtype.isvalidbinding()) {
return this.resolvedtype;
} else {
switch (this.resolvedtype.problemid()) {
case problemreasons.notfound :
case problemreasons.notvisible :
typebinding type = this.resolvedtype.closestmatch();
return type;
default :
return null;
}
}
}
boolean haserror;
typebinding type = this.resolvedtype = gettypebinding(scope);
if (type == null) {
return null; // detected cycle while resolving hierarchy
} else if ((haserror = !type.isvalidbinding())== true) {
reportinvalidtype(scope);
switch (type.problemid()) {
case problemreasons.notfound :
case problemreasons.notvisible :
type = type.closestmatch();
if (type == null) return null;
break;
default :
return null;
}
}
if (type.isarraytype() && ((arraybinding) type).leafcomponenttype == typebinding.void) {
scope.problemreporter().cannotallocatevoidarray(this);
return null;
}
if (istypeusedeprecated(type, scope)) {
reportdeprecatedtype(type, scope);
}
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=209936
// raw convert all enclosing types when dealing with javadoc references
if (type.isgenerictype() || type.isparameterizedtype()) {
type = scope.environment().converttorawtype(type, true /*force the conversion of enclosing types*/);
}

if (haserror) {
// do not store the computed type, keep the problem type instead
return type;
}
return this.resolvedtype = type;
}

protected void reportinvalidtype(scope scope) {
scope.problemreporter().javadocinvalidtype(this, this.resolvedtype, scope.getdeclarationmodifiers());
}
protected void reportdeprecatedtype(typebinding type, scope scope) {
scope.problemreporter().javadocdeprecatedtype(type, this, scope.getdeclarationmodifiers());
}

public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public stringbuffer printexpression(int indent, stringbuffer output) {
return new stringbuffer();
}
}
