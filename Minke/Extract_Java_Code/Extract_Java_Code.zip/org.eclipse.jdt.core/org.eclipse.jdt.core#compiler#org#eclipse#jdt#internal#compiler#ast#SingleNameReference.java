/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.codegen.opcodes;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.missingtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.problemfieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.problemreferencebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.lookup.variablebinding;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;

public class singlenamereference extends namereference implements operatorids {

public static final int read = 0;
public static final int write = 1;
public char[] token;
public methodbinding[] syntheticaccessors; // [0]=read accessor [1]=write accessor
public typebinding genericcast;

public singlenamereference(char[] source, long pos) {
super();
this.token = source;
this.sourcestart = (int) (pos >>> 32);
this.sourceend = (int) pos;
}

public flowinfo analyseassignment(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo, assignment assignment, boolean iscompound) {
boolean isreachable = (flowinfo.tagbits & flowinfo.unreachable) == 0;
// compound assignment extra work
if (iscompound) { // check the variable part is initialized if blank final
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // reading a field
fieldbinding fieldbinding;
if ((fieldbinding = (fieldbinding) this.binding).isblankfinal()
&& currentscope.needblankfinalfieldinitializationcheck(fieldbinding)) {
flowinfo fieldinits = flowcontext.getinitsforfinalblankinitializationcheck(fieldbinding.declaringclass.original(), flowinfo);
if (!fieldinits.isdefinitelyassigned(fieldbinding)) {
currentscope.problemreporter().uninitializedblankfinalfield(fieldbinding, this);
}
}
managesyntheticaccessifnecessary(currentscope, flowinfo, true /*read-access*/);
break;
case binding.local : // reading a local variable
// check if assigning a final blank field
localvariablebinding localbinding;
if (!flowinfo.isdefinitelyassigned(localbinding = (localvariablebinding) this.binding)) {
currentscope.problemreporter().uninitializedlocalvariable(localbinding, this);
// we could improve error msg here telling "cannot use compound assignment on final local variable"
}
if (isreachable) {
localbinding.useflag = localvariablebinding.used;
} else if (localbinding.useflag == localvariablebinding.unused) {
localbinding.useflag = localvariablebinding.fake_used;
}
}
}
if (assignment.expression != null) {
flowinfo = assignment.expression.analysecode(currentscope, flowcontext, flowinfo).unconditionalinits();
}
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // assigning to a field
managesyntheticaccessifnecessary(currentscope, flowinfo, false /*write-access*/);

// check if assigning a final field
fieldbinding fieldbinding = (fieldbinding) this.binding;
if (fieldbinding.isfinal()) {
// inside a context where allowed
if (!iscompound && fieldbinding.isblankfinal() && currentscope.allowblankfinalfieldassignment(fieldbinding)) {
if (flowinfo.ispotentiallyassigned(fieldbinding)) {
currentscope.problemreporter().duplicateinitializationofblankfinalfield(fieldbinding, this);
} else {
flowcontext.recordsettingfinal(fieldbinding, this, flowinfo);
}
flowinfo.markasdefinitelyassigned(fieldbinding);
} else {
currentscope.problemreporter().cannotassigntofinalfield(fieldbinding, this);
}
}
break;
case binding.local : // assigning to a local variable
localvariablebinding localbinding = (localvariablebinding) this.binding;
if (!flowinfo.isdefinitelyassigned(localbinding)){// for local variable debug attributes
this.bits |= astnode.firstassignmenttolocal;
} else {
this.bits &= ~astnode.firstassignmenttolocal;
}
if (localbinding.isfinal()) {
if ((this.bits & astnode.depthmask) == 0) {
// tolerate assignment to final local in unreachable code (45674)
if ((isreachable && iscompound) || !localbinding.isblankfinal()){
currentscope.problemreporter().cannotassigntofinallocal(localbinding, this);
} else if (flowinfo.ispotentiallyassigned(localbinding)) {
currentscope.problemreporter().duplicateinitializationoffinallocal(localbinding, this);
} else {
flowcontext.recordsettingfinal(localbinding, this, flowinfo);
}
} else {
currentscope.problemreporter().cannotassigntofinalouterlocal(localbinding, this);
}
}
else /* avoid double diagnostic */ if ((localbinding.tagbits & tagbits.isargument) != 0) {
currentscope.problemreporter().parameterassignment(localbinding, this);
}
flowinfo.markasdefinitelyassigned(localbinding);
}
manageenclosinginstanceaccessifnecessary(currentscope, flowinfo);
return flowinfo;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
return analysecode(currentscope, flowcontext, flowinfo, true);
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo, boolean valuerequired) {
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // reading a field
if (valuerequired || currentscope.compileroptions().compliancelevel >= classfileconstants.jdk1_4) {
managesyntheticaccessifnecessary(currentscope, flowinfo, true /*read-access*/);
}
// check if reading a final blank field
fieldbinding fieldbinding = (fieldbinding) this.binding;
if (fieldbinding.isblankfinal() && currentscope.needblankfinalfieldinitializationcheck(fieldbinding)) {
flowinfo fieldinits = flowcontext.getinitsforfinalblankinitializationcheck(fieldbinding.declaringclass.original(), flowinfo);
if (!fieldinits.isdefinitelyassigned(fieldbinding)) {
currentscope.problemreporter().uninitializedblankfinalfield(fieldbinding, this);
}
}
break;
case binding.local : // reading a local variable
localvariablebinding localbinding;
if (!flowinfo.isdefinitelyassigned(localbinding = (localvariablebinding) this.binding)) {
currentscope.problemreporter().uninitializedlocalvariable(localbinding, this);
}
if ((flowinfo.tagbits & flowinfo.unreachable) == 0) {
localbinding.useflag = localvariablebinding.used;
} else if (localbinding.useflag == localvariablebinding.unused) {
localbinding.useflag = localvariablebinding.fake_used;
}
}
if (valuerequired) {
manageenclosinginstanceaccessifnecessary(currentscope, flowinfo);
}
return flowinfo;
}

public typebinding checkfieldaccess(blockscope scope) {
fieldbinding fieldbinding = (fieldbinding) this.binding;
this.constant = fieldbinding.constant();

this.bits &= ~astnode.restrictiveflagmask; // clear bits
this.bits |= binding.field;
methodscope methodscope = scope.methodscope();
if (fieldbinding.isstatic()) {
// check if accessing enum static field in initializer
referencebinding declaringclass = fieldbinding.declaringclass;
if (declaringclass.isenum()) {
sourcetypebinding sourcetype = scope.enclosingsourcetype();
if (this.constant == constant.notaconstant
&& !methodscope.isstatic
&& (sourcetype == declaringclass || sourcetype.superclass == declaringclass) // enum constant body
&& methodscope.isinsideinitializerorconstructor()) {
scope.problemreporter().enumstaticfieldusedduringinitialization(fieldbinding, this);
}
}
} else {
if (scope.compileroptions().getseverity(compileroptions.unqualifiedfieldaccess) != problemseverities.ignore) {
scope.problemreporter().unqualifiedfieldaccess(this, fieldbinding);
}
// must check for the static status....
if (methodscope.isstatic) {
scope.problemreporter().staticfieldaccesstononstaticvariable(this, fieldbinding);
return fieldbinding.type;
}
}

if (isfieldusedeprecated(fieldbinding, scope, (this.bits & astnode.isstrictlyassigned) !=0))
scope.problemreporter().deprecatedfield(fieldbinding, this);

if ((this.bits & astnode.isstrictlyassigned) == 0
&& methodscope.enclosingsourcetype() == fieldbinding.original().declaringclass
&& methodscope.lastvisiblefieldid >= 0
&& fieldbinding.id >= methodscope.lastvisiblefieldid
&& (!fieldbinding.isstatic() || methodscope.isstatic)) {
scope.problemreporter().forwardreference(this, 0, fieldbinding);
this.bits |= astnode.ignorenoeffectassigncheck;
}
return fieldbinding.type;

}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#computeconversion(org.eclipse.jdt.internal.compiler.lookup.scope, org.eclipse.jdt.internal.compiler.lookup.typebinding, org.eclipse.jdt.internal.compiler.lookup.typebinding)
*/
public void computeconversion(scope scope, typebinding runtimetimetype, typebinding compiletimetype) {
if (runtimetimetype == null || compiletimetype == null)
return;
if ((this.bits & binding.field) != 0 && this.binding != null && this.binding.isvalidbinding()) {
// set the generic cast after the fact, once the type expectation is fully known (no need for strict cast)
fieldbinding field = (fieldbinding) this.binding;
fieldbinding originalbinding = field.original();
typebinding originaltype = originalbinding.type;
// extra cast needed if field type is type variable
if (originaltype.leafcomponenttype().istypevariable()) {
typebinding targettype = (!compiletimetype.isbasetype() && runtimetimetype.isbasetype())
? compiletimetype  // unboxing: checkcast before conversion
: runtimetimetype;
this.genericcast = originaltype.genericcast(scope.boxing(targettype));
if (this.genericcast instanceof referencebinding) {
referencebinding referencecast = (referencebinding) this.genericcast;
if (!referencecast.canbeseenby(scope)) {
scope.problemreporter().invalidtype(this,
new problemreferencebinding(
charoperation.spliton('.', referencecast.shortreadablename()),
referencecast,
problemreasons.notvisible));
}
}
}
}
super.computeconversion(scope, runtimetimetype, compiletimetype);
}

public void generateassignment(blockscope currentscope, codestream codestream, assignment assignment, boolean valuerequired) {
// optimizing assignment like: i = i + 1 or i = 1 + i
if (assignment.expression.iscompactableoperation()) {
binaryexpression operation = (binaryexpression) assignment.expression;
int operator = (operation.bits & astnode.operatormask) >> astnode.operatorshift;
singlenamereference variablereference;
if ((operation.left instanceof singlenamereference) && ((variablereference = (singlenamereference) operation.left).binding == this.binding)) {
// i = i + value, then use the variable on the right hand side, since it has the correct implicit conversion
variablereference.generatecompoundassignment(currentscope, codestream, this.syntheticaccessors == null ? null : this.syntheticaccessors[singlenamereference.write], operation.right, operator, operation.implicitconversion, valuerequired);
if (valuerequired) {
codestream.generateimplicitconversion(assignment.implicitconversion);
}
return;
}
if ((operation.right instanceof singlenamereference)
&& ((operator == operatorids.plus) || (operator == operatorids.multiply)) // only commutative operations
&& ((variablereference = (singlenamereference) operation.right).binding == this.binding)
&& (operation.left.constant != constant.notaconstant) // exclude non constant expressions, since could have side-effect
&& (((operation.left.implicitconversion & typeids.implicit_conversion_mask) >> 4) != typeids.t_javalangstring) // exclude string concatenation which would occur backwards
&& (((operation.right.implicitconversion & typeids.implicit_conversion_mask) >> 4) != typeids.t_javalangstring)) { // exclude string concatenation which would occur backwards
// i = value + i, then use the variable on the right hand side, since it has the correct implicit conversion
variablereference.generatecompoundassignment(currentscope, codestream, this.syntheticaccessors == null ? null : this.syntheticaccessors[singlenamereference.write], operation.left, operator, operation.implicitconversion, valuerequired);
if (valuerequired) {
codestream.generateimplicitconversion(assignment.implicitconversion);
}
return;
}
}
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // assigning to a field
int pc = codestream.position;
fieldbinding codegenbinding = ((fieldbinding) this.binding).original();
if (!codegenbinding.isstatic()) { // need a receiver?
if ((this.bits & astnode.depthmask) != 0) {
referencebinding targettype = currentscope.enclosingsourcetype().enclosingtypeat((this.bits & astnode.depthmask) >> astnode.depthshift);
object[] emulationpath = currentscope.getemulationpath(targettype, true /*only exact match*/, false/*consider enclosing arg*/);
codestream.generateouteraccess(emulationpath, this, targettype, currentscope);
} else {
generatereceiver(codestream);
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
assignment.expression.generatecode(currentscope, codestream, true);
fieldstore(currentscope, codestream, codegenbinding, this.syntheticaccessors == null ? null : this.syntheticaccessors[singlenamereference.write], this.actualreceivertype, true /*implicit this*/, valuerequired);
if (valuerequired) {
codestream.generateimplicitconversion(assignment.implicitconversion);
}
// no need for generic cast as value got dupped
return;
case binding.local : // assigning to a local variable
localvariablebinding localbinding = (localvariablebinding) this.binding;
if (localbinding.resolvedposition != -1) {
assignment.expression.generatecode(currentscope, codestream, true);
} else {
if (assignment.expression.constant != constant.notaconstant) {
// assigning an unused local to a constant value = no actual assignment is necessary
if (valuerequired) {
codestream.generateconstant(assignment.expression.constant, assignment.implicitconversion);
}
} else {
assignment.expression.generatecode(currentscope, codestream, true);
/* even though the value may not be required, we force it to be produced, and discard it later
on if it was actually not necessary, so as to provide the same behavior as jdk1.2beta3.	*/
if (valuerequired) {
codestream.generateimplicitconversion(assignment.implicitconversion); // implicit conversion
} else {
switch(localbinding.type.id) {
case typeids.t_long :
case typeids.t_double :
codestream.pop2();
break;
default :
codestream.pop();
break;
}
}
}
return;
}
// 26903, need extra cast to store null in array local var
if (localbinding.type.isarraytype()
&& (assignment.expression.resolvedtype == typebinding.null	// arrayloc = null
|| ((assignment.expression instanceof castexpression)	// arrayloc = (type[])null
&& (((castexpression)assignment.expression).innermostcastedexpression().resolvedtype == typebinding.null)))){
codestream.checkcast(localbinding.type);
}

// normal local assignment (since cannot store in outer local which are final locations)
codestream.store(localbinding, valuerequired);
if ((this.bits & astnode.firstassignmenttolocal) != 0) { // for local variable debug attributes
localbinding.recordinitializationstartpc(codestream.position);
}
// implicit conversion
if (valuerequired) {
codestream.generateimplicitconversion(assignment.implicitconversion);
}
}
}

public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
if (this.constant != constant.notaconstant) {
if (valuerequired) {
codestream.generateconstant(this.constant, this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
} else {
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // reading a field
fieldbinding codegenfield = ((fieldbinding) this.binding).original();
constant fieldconstant = codegenfield.constant();
if (fieldconstant != constant.notaconstant) {
// directly use inlined value for constant fields
if (valuerequired) {
codestream.generateconstant(fieldconstant, this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
if (codegenfield.isstatic()) {
if (!valuerequired
// if no valuerequired, still need possible side-effects of <clinit> invocation, if field belongs to different class
&& ((fieldbinding)this.binding).original().declaringclass == this.actualreceivertype.erasure()
&& ((this.implicitconversion & typeids.unboxing) == 0)
&& this.genericcast == null) {
// if no valuerequired, optimize out entire gen
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
// managing private access
if ((this.syntheticaccessors == null) || (this.syntheticaccessors[singlenamereference.read] == null)) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenfield, this.actualreceivertype, true /* implicit this */);
codestream.fieldaccess(opcodes.opc_getstatic, codegenfield, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessors[singlenamereference.read], null /* default declaringclass */);
}
} else {
if (!valuerequired
&& (this.implicitconversion & typeids.unboxing) == 0
&& this.genericcast == null) {
// if no valuerequired, optimize out entire gen
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
// managing enclosing instance access
if ((this.bits & astnode.depthmask) != 0) {
referencebinding targettype = currentscope.enclosingsourcetype().enclosingtypeat((this.bits & astnode.depthmask) >> astnode.depthshift);
object[] emulationpath = currentscope.getemulationpath(targettype, true /*only exact match*/, false/*consider enclosing arg*/);
codestream.generateouteraccess(emulationpath, this, targettype, currentscope);
} else {
generatereceiver(codestream);
}
// managing private access
if ((this.syntheticaccessors == null) || (this.syntheticaccessors[singlenamereference.read] == null)) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenfield, this.actualreceivertype, true /* implicit this */);
codestream.fieldaccess(opcodes.opc_getfield, codegenfield, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessors[singlenamereference.read], null /* default declaringclass */);
}
}
break;
case binding.local : // reading a local
localvariablebinding localbinding = (localvariablebinding) this.binding;
if (!valuerequired && (this.implicitconversion & typeids.unboxing) == 0) {
// if no valuerequired, optimize out entire gen
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
// outer local?
if ((this.bits & astnode.depthmask) != 0) {
// outer local can be reached either through a synthetic arg or a synthetic field
variablebinding[] path = currentscope.getemulationpath(localbinding);
codestream.generateouteraccess(path, this, localbinding, currentscope);
} else {
// regular local variable read
codestream.load(localbinding);
}
break;
default: // type
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
}
// required cast must occur even if no value is required
if (this.genericcast != null) codestream.checkcast(this.genericcast);
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else {
boolean isunboxing = (this.implicitconversion & typeids.unboxing) != 0;
// conversion only generated if unboxing
if (isunboxing) codestream.generateimplicitconversion(this.implicitconversion);
switch (isunboxing ? postconversiontype(currentscope).id : this.resolvedtype.id) {
case t_long :
case t_double :
codestream.pop2();
break;
default :
codestream.pop();
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/*
* regular api for compound assignment, relies on the fact that there is only one reference to the
* variable, which carries both synthetic read/write accessors.
* the apis with an extra argument is used whenever there are two references to the same variable which
* are optimized in one access: e.g "a = a + 1" optimized into "a++".
*/
public void generatecompoundassignment(blockscope currentscope, codestream codestream, expression expression, int operator, int assignmentimplicitconversion, boolean valuerequired) {
this.generatecompoundassignment(
currentscope,
codestream,
this.syntheticaccessors == null ? null : this.syntheticaccessors[singlenamereference.write],
expression,
operator,
assignmentimplicitconversion,
valuerequired);
}

/*
* the apis with an extra argument is used whenever there are two references to the same variable which
* are optimized in one access: e.g "a = a + 1" optimized into "a++".
*/
public void generatecompoundassignment(blockscope currentscope, codestream codestream, methodbinding writeaccessor, expression expression, int operator, int assignmentimplicitconversion, boolean valuerequired) {
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // assigning to a field
fieldbinding codegenfield = ((fieldbinding) this.binding).original();
if (codegenfield.isstatic()) {
if ((this.syntheticaccessors == null) || (this.syntheticaccessors[singlenamereference.read] == null)) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenfield, this.actualreceivertype, true /* implicit this */);
codestream.fieldaccess(opcodes.opc_getstatic, codegenfield, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessors[singlenamereference.read], null /* default declaringclass */);
}
} else {
if ((this.bits & astnode.depthmask) != 0) {
referencebinding targettype = currentscope.enclosingsourcetype().enclosingtypeat((this.bits & astnode.depthmask) >> astnode.depthshift);
object[] emulationpath = currentscope.getemulationpath(targettype, true /*only exact match*/, false/*consider enclosing arg*/);
codestream.generateouteraccess(emulationpath, this, targettype, currentscope);
} else {
codestream.aload_0();
}
codestream.dup();
if ((this.syntheticaccessors == null) || (this.syntheticaccessors[singlenamereference.read] == null)) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenfield, this.actualreceivertype, true /* implicit this */);
codestream.fieldaccess(opcodes.opc_getfield, codegenfield, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessors[singlenamereference.read], null /* default declaringclass */);
}
}
break;
case binding.local : // assigning to a local variable (cannot assign to outer local)
localvariablebinding localbinding = (localvariablebinding) this.binding;
// using incr bytecode if possible
switch (localbinding.type.id) {
case t_javalangstring :
codestream.generatestringconcatenationappend(currentscope, this, expression);
if (valuerequired) {
codestream.dup();
}
codestream.store(localbinding, false);
return;
case t_int :
constant assignconstant;
if (((assignconstant = expression.constant) != constant.notaconstant)
&& (assignconstant.typeid() != typeids.t_float) // only for integral types
&& (assignconstant.typeid() != typeids.t_double)) {// todo (philippe) is this test needed ?
switch (operator) {
case plus :
int increment  = assignconstant.intvalue();
if (increment != (short) increment) break; // not representable as a 16-bits value
codestream.iinc(localbinding.resolvedposition, increment);
if (valuerequired) {
codestream.load(localbinding);
}
return;
case minus :
increment  = -assignconstant.intvalue();
if (increment != (short) increment) break; // not representable as a 16-bits value
codestream.iinc(localbinding.resolvedposition, increment);
if (valuerequired) {
codestream.load(localbinding);
}
return;
}
}
//$fall-through$
default :
codestream.load(localbinding);
}
}
// perform the actual compound operation
int operationtypeid;
switch(operationtypeid = (this.implicitconversion & typeids.implicit_conversion_mask) >> 4) {
case t_javalangstring :
case t_javalangobject :
case t_undefined :
// we enter here if the single name reference is a field of type java.lang.string or if the type of the
// operation is java.lang.object
// for example: o = o + ""; // where the compiled type of o is java.lang.object.
codestream.generatestringconcatenationappend(currentscope, null, expression);
// no need for generic cast on previous #getfield since using object string buffer methods.
break;
default :
// promote the array reference to the suitable operation type
if (this.genericcast != null)
codestream.checkcast(this.genericcast);
codestream.generateimplicitconversion(this.implicitconversion);
// generate the increment value (will by itself  be promoted to the operation value)
if (expression == intliteral.one){ // prefix operation
codestream.generateconstant(expression.constant, this.implicitconversion);
} else {
expression.generatecode(currentscope, codestream, true);
}
// perform the operation
codestream.sendoperator(operator, operationtypeid);
// cast the value back to the array reference type
codestream.generateimplicitconversion(assignmentimplicitconversion);
}
// store the result back into the variable
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // assigning to a field
fieldbinding codegenfield = ((fieldbinding) this.binding).original();
fieldstore(currentscope, codestream, codegenfield, writeaccessor, this.actualreceivertype, true /* implicit this*/, valuerequired);
// no need for generic cast as value got dupped
return;
case binding.local : // assigning to a local variable
localvariablebinding localbinding = (localvariablebinding) this.binding;
if (valuerequired) {
switch (localbinding.type.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2();
break;
default:
codestream.dup();
break;
}
}
codestream.store(localbinding, false);
}
}

public void generatepostincrement(blockscope currentscope, codestream codestream, compoundassignment postincrement, boolean valuerequired) {
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // assigning to a field
fieldbinding codegenfield = (((fieldbinding)this.binding).original());
if (codegenfield.isstatic()) {
if ((this.syntheticaccessors == null) || (this.syntheticaccessors[singlenamereference.read] == null)) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenfield, this.actualreceivertype, true /* implicit this */);
codestream.fieldaccess(opcodes.opc_getstatic, codegenfield, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessors[singlenamereference.read], null /* default declaringclass */);
}
} else {
if ((this.bits & astnode.depthmask) != 0) {
referencebinding targettype = currentscope.enclosingsourcetype().enclosingtypeat((this.bits & astnode.depthmask) >> astnode.depthshift);
object[] emulationpath = currentscope.getemulationpath(targettype, true /*only exact match*/, false/*consider enclosing arg*/);
codestream.generateouteraccess(emulationpath, this, targettype, currentscope);
} else {
codestream.aload_0();
}
codestream.dup();
if ((this.syntheticaccessors == null) || (this.syntheticaccessors[singlenamereference.read] == null)) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenfield, this.actualreceivertype, true /* implicit this */);
codestream.fieldaccess(opcodes.opc_getfield, codegenfield, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessors[singlenamereference.read], null /* default declaringclass */);
}
}
typebinding operandtype;
if (this.genericcast != null) {
codestream.checkcast(this.genericcast);
operandtype = this.genericcast;
} else {
operandtype = codegenfield.type;
}
if (valuerequired) {
if (codegenfield.isstatic()) {
switch (operandtype.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2();
break;
default:
codestream.dup();
break;
}
} else { // stack:  [owner][old field value]  ---> [old field value][owner][old field value]
switch (operandtype.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2_x1();
break;
default:
codestream.dup_x1();
break;
}
}
}
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generateconstant(postincrement.expression.constant, this.implicitconversion);
codestream.sendoperator(postincrement.operator, this.implicitconversion & typeids.compile_type_mask);
codestream.generateimplicitconversion(postincrement.preassignimplicitconversion);
fieldstore(currentscope, codestream, codegenfield, this.syntheticaccessors == null ? null : this.syntheticaccessors[singlenamereference.write], this.actualreceivertype, true /*implicit this*/, false);
// no need for generic cast
return;
case binding.local : // assigning to a local variable
localvariablebinding localbinding = (localvariablebinding) this.binding;
// using incr bytecode if possible
if (localbinding.type == typebinding.int) {
if (valuerequired) {
codestream.load(localbinding);
}
if (postincrement.operator == operatorids.plus) {
codestream.iinc(localbinding.resolvedposition, 1);
} else {
codestream.iinc(localbinding.resolvedposition, -1);
}
} else {
codestream.load(localbinding);
if (valuerequired){
switch (localbinding.type.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2();
break;
default:
codestream.dup();
break;
}
}
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generateconstant(postincrement.expression.constant, this.implicitconversion);
codestream.sendoperator(postincrement.operator, this.implicitconversion & typeids.compile_type_mask);
codestream.generateimplicitconversion(postincrement.preassignimplicitconversion);
codestream.store(localbinding, false);
}
}
}

public void generatereceiver(codestream codestream) {
codestream.aload_0();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#generictypearguments()
*/
public typebinding[] generictypearguments() {
return null;
}

/**
* returns the local variable referenced by this node. can be a direct reference (singlenamereference)
* or thru a cast expression etc...
*/
public localvariablebinding localvariablebinding() {
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // reading a field
break;
case binding.local : // reading a local variable
return (localvariablebinding) this.binding;
}
return null;
}

public void manageenclosinginstanceaccessifnecessary(blockscope currentscope, flowinfo flowinfo) {
//if inlinable field, forget the access emulation, the code gen will directly target it
if (((this.bits & astnode.depthmask) == 0) || (this.constant != constant.notaconstant)) {
return;
}
if ((this.bits & astnode.restrictiveflagmask) == binding.local) {
localvariablebinding localvariablebinding = (localvariablebinding) this.binding;
if (localvariablebinding != null) {
switch(localvariablebinding.useflag) {
case localvariablebinding.fake_used :
case localvariablebinding.used :
currentscope.emulateouteraccess(localvariablebinding);
}
}
}
}

public void managesyntheticaccessifnecessary(blockscope currentscope, flowinfo flowinfo, boolean isreadaccess) {
if ((flowinfo.tagbits & flowinfo.unreachable) != 0)	return;

//if inlinable field, forget the access emulation, the code gen will directly target it
if (this.constant != constant.notaconstant)
return;

if ((this.bits & binding.field) != 0) {
fieldbinding fieldbinding = (fieldbinding) this.binding;
fieldbinding codegenfield = fieldbinding.original();
if (((this.bits & astnode.depthmask) != 0)
&& (codegenfield.isprivate() // private access
|| (codegenfield.isprotected() // implicit protected access
&& codegenfield.declaringclass.getpackage() != currentscope.enclosingsourcetype().getpackage()))) {
if (this.syntheticaccessors == null)
this.syntheticaccessors = new methodbinding[2];
this.syntheticaccessors[isreadaccess ? singlenamereference.read : singlenamereference.write] =
((sourcetypebinding)currentscope.enclosingsourcetype().
enclosingtypeat((this.bits & astnode.depthmask) >> astnode.depthshift)).addsyntheticmethod(codegenfield, isreadaccess, false /*not super access*/);
currentscope.problemreporter().needtoemulatefieldaccess(codegenfield, this, isreadaccess);
return;
}
}
}

public int nullstatus(flowinfo flowinfo) {
if (this.constant != null && this.constant != constant.notaconstant) {
return flowinfo.non_null; // constant expression cannot be null
}
switch (this.bits & astnode.restrictiveflagmask) {
case binding.field : // reading a field
return flowinfo.unknown;
case binding.local : // reading a local variable
localvariablebinding local = (localvariablebinding) this.binding;
if (local != null) {
if (flowinfo.isdefinitelynull(local))
return flowinfo.null;
if (flowinfo.isdefinitelynonnull(local))
return flowinfo.non_null;
return flowinfo.unknown;
}
}
return flowinfo.non_null; // never get there
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#postconversiontype(scope)
*/
public typebinding postconversiontype(scope scope) {
typebinding convertedtype = this.resolvedtype;
if (this.genericcast != null)
convertedtype = this.genericcast;
int runtimetype = (this.implicitconversion & typeids.implicit_conversion_mask) >> 4;
switch (runtimetype) {
case t_boolean :
convertedtype = typebinding.boolean;
break;
case t_byte :
convertedtype = typebinding.byte;
break;
case t_short :
convertedtype = typebinding.short;
break;
case t_char :
convertedtype = typebinding.char;
break;
case t_int :
convertedtype = typebinding.int;
break;
case t_float :
convertedtype = typebinding.float;
break;
case t_long :
convertedtype = typebinding.long;
break;
case t_double :
convertedtype = typebinding.double;
break;
default :
}
if ((this.implicitconversion & typeids.boxing) != 0) {
convertedtype = scope.environment().computeboxingtype(convertedtype);
}
return convertedtype;
}

public stringbuffer printexpression(int indent, stringbuffer output){
return output.append(this.token);
}
public typebinding reporterror(blockscope scope) {
//=====error cases=======
this.constant = constant.notaconstant;
if (this.binding instanceof problemfieldbinding) {
scope.problemreporter().invalidfield(this, (fieldbinding) this.binding);
} else if (this.binding instanceof problemreferencebinding || this.binding instanceof missingtypebinding) {
scope.problemreporter().invalidtype(this, (typebinding) this.binding);
} else {
scope.problemreporter().unresolvablereference(this, this.binding);
}
return null;
}

public typebinding resolvetype(blockscope scope) {
// for code gen, harm the restrictiveflag

if (this.actualreceivertype != null) {
this.binding = scope.getfield(this.actualreceivertype, this.token, this);
} else {
this.actualreceivertype = scope.enclosingsourcetype();
this.binding = scope.getbinding(this.token, this.bits & astnode.restrictiveflagmask, this, true /*resolve*/);
}
if (this.binding.isvalidbinding()) {
switch (this.bits & astnode.restrictiveflagmask) {
case binding.variable : // =========only variable============
case binding.variable | binding.type : //====both variable and type============
if (this.binding instanceof variablebinding) {
variablebinding variable = (variablebinding) this.binding;
typebinding variabletype;
if (this.binding instanceof localvariablebinding) {
this.bits &= ~astnode.restrictiveflagmask;  // clear bits
this.bits |= binding.local;
if (!variable.isfinal() && (this.bits & astnode.depthmask) != 0) {
scope.problemreporter().cannotrefertononfinalouterlocal((localvariablebinding)variable, this);
}
variabletype = variable.type;
this.constant = (this.bits & astnode.isstrictlyassigned) == 0 ? variable.constant() : constant.notaconstant;
} else {
// a field
variabletype = checkfieldaccess(scope);
}
// perform capture conversion if read access
if (variabletype != null) {
this.resolvedtype = variabletype = (((this.bits & astnode.isstrictlyassigned) == 0)
? variabletype.capture(scope, this.sourceend)
: variabletype);
if ((variabletype.tagbits & tagbits.hasmissingtype) != 0) {
if ((this.bits & binding.local) == 0) {
// only complain if field reference (for local, its type got flagged already)
scope.problemreporter().invalidtype(this, variabletype);
}
return null;
}
}
return variabletype;
}

// thus it was a type
this.bits &= ~astnode.restrictiveflagmask;  // clear bits
this.bits |= binding.type;
//$fall-through$
case binding.type : //========only type==============
this.constant = constant.notaconstant;
//deprecated test
typebinding type = (typebinding)this.binding;
if (istypeusedeprecated(type, scope))
scope.problemreporter().deprecatedtype(type, this);
type = scope.environment().converttorawtype(type, false /*do not force conversion of enclosing types*/);
return this.resolvedtype = type;
}
}
// error scenarii
return this.resolvedtype = reporterror(scope);
}

public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public string unboundreferenceerrorname(){
return new string(this.token);
}
}
