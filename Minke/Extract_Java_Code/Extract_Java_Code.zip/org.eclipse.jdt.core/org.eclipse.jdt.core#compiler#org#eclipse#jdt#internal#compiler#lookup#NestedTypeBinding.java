/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

public class nestedtypebinding extends sourcetypebinding {

public sourcetypebinding enclosingtype;

public syntheticargumentbinding[] enclosinginstances;
private referencebinding[] enclosingtypes = binding.uninitialized_reference_types;
public syntheticargumentbinding[] outerlocalvariables;
private int outerlocalvariablesslotsize = -1; // amount of slots used by synthetic outer local variables

public nestedtypebinding(char[][] typename, classscope scope, sourcetypebinding enclosingtype) {
super(typename, enclosingtype.fpackage, scope);
this.tagbits |= (tagbits.isnestedtype | tagbits.containsnestedtypereferences);
this.enclosingtype = enclosingtype;
}

/* add a new synthetic argument for <actualouterlocalvariable>.
* answer the new argument or the existing argument if one already existed.
*/
public syntheticargumentbinding addsyntheticargument(localvariablebinding actualouterlocalvariable) {
syntheticargumentbinding synthlocal = null;

if (this.outerlocalvariables == null) {
synthlocal = new syntheticargumentbinding(actualouterlocalvariable);
this.outerlocalvariables = new syntheticargumentbinding[] {synthlocal};
} else {
int size = this.outerlocalvariables.length;
int newargindex = size;
for (int i = size; --i >= 0;) {		// must search backwards
if (this.outerlocalvariables[i].actualouterlocalvariable == actualouterlocalvariable)
return this.outerlocalvariables[i];	// already exists
if (this.outerlocalvariables[i].id > actualouterlocalvariable.id)
newargindex = i;
}
syntheticargumentbinding[] synthlocals = new syntheticargumentbinding[size + 1];
system.arraycopy(this.outerlocalvariables, 0, synthlocals, 0, newargindex);
synthlocals[newargindex] = synthlocal = new syntheticargumentbinding(actualouterlocalvariable);
system.arraycopy(this.outerlocalvariables, newargindex, synthlocals, newargindex + 1, size - newargindex);
this.outerlocalvariables = synthlocals;
}
//system.out.println("adding synth arg for local var: " + new string(actualouterlocalvariable.name) + " to: " + new string(this.readablename()));
if (this.scope.referencecompilationunit().ispropagatinginnerclassemulation)
updateinneremulationdependents();
return synthlocal;
}

/* add a new synthetic argument for <enclosingtype>.
* answer the new argument or the existing argument if one already existed.
*/
public syntheticargumentbinding addsyntheticargument(referencebinding targetenclosingtype) {
syntheticargumentbinding synthlocal = null;
if (this.enclosinginstances == null) {
synthlocal = new syntheticargumentbinding(targetenclosingtype);
this.enclosinginstances = new syntheticargumentbinding[] {synthlocal};
} else {
int size = this.enclosinginstances.length;
int newargindex = size;
for (int i = size; --i >= 0;) {
if (this.enclosinginstances[i].type == targetenclosingtype)
return this.enclosinginstances[i]; // already exists
if (enclosingtype() == targetenclosingtype)
newargindex = 0;
}
syntheticargumentbinding[] newinstances = new syntheticargumentbinding[size + 1];
system.arraycopy(this.enclosinginstances, 0, newinstances, newargindex == 0 ? 1 : 0, size);
newinstances[newargindex] = synthlocal = new syntheticargumentbinding(targetenclosingtype);
this.enclosinginstances = newinstances;
}
//system.out.println("adding synth arg for enclosing type: " + new string(enclosingtype.readablename()) + " to: " + new string(this.readablename()));
if (this.scope.referencecompilationunit().ispropagatinginnerclassemulation)
updateinneremulationdependents();
return synthlocal;
}

/* add a new synthetic argument and field for <actualouterlocalvariable>.
* answer the new argument or the existing argument if one already existed.
*/
public syntheticargumentbinding addsyntheticargumentandfield(localvariablebinding actualouterlocalvariable) {
syntheticargumentbinding synthlocal = addsyntheticargument(actualouterlocalvariable);
if (synthlocal == null) return null;

if (synthlocal.matchingfield == null)
synthlocal.matchingfield = addsyntheticfieldforinnerclass(actualouterlocalvariable);
return synthlocal;
}

/* add a new synthetic argument and field for <enclosingtype>.
* answer the new argument or the existing argument if one already existed.
*/
public syntheticargumentbinding addsyntheticargumentandfield(referencebinding targetenclosingtype) {
syntheticargumentbinding synthlocal = addsyntheticargument(targetenclosingtype);
if (synthlocal == null) return null;

if (synthlocal.matchingfield == null)
synthlocal.matchingfield = addsyntheticfieldforinnerclass(targetenclosingtype);
return synthlocal;
}

/* answer the receiver's enclosing type... null if the receiver is a top level type.
*/
public referencebinding enclosingtype() {
return this.enclosingtype;
}

/**
* @@return the enclosinginstancesslotsize
*/
public int getenclosinginstancesslotsize() {
return this.enclosinginstances == null ? 0 : this.enclosinginstances.length;
}

/**
* @@return the outerlocalvariablesslotsize
*/
public int getouterlocalvariablesslotsize() {
if (this.outerlocalvariablesslotsize < 0) {
this.outerlocalvariablesslotsize = 0;
int outerlocalscount = this.outerlocalvariables == null ? 0 : this.outerlocalvariables.length;
for (int i = 0; i < outerlocalscount; i++){
syntheticargumentbinding argument = this.outerlocalvariables[i];
switch (argument.type.id) {
case typeids.t_long :
case typeids.t_double :
this.outerlocalvariablesslotsize  += 2;
break;
default :
this.outerlocalvariablesslotsize  ++;
break;
}
}
}
return this.outerlocalvariablesslotsize;
}

/* answer the synthetic argument for <actualouterlocalvariable> or null if one does not exist.
*/
public syntheticargumentbinding getsyntheticargument(localvariablebinding actualouterlocalvariable) {
if (this.outerlocalvariables == null) return null;		// is null if no outer local variables are known
for (int i = this.outerlocalvariables.length; --i >= 0;)
if (this.outerlocalvariables[i].actualouterlocalvariable == actualouterlocalvariable)
return this.outerlocalvariables[i];
return null;
}

/* answer the synthetic argument for <targetenclosingtype> or null if one does not exist.
*/
public syntheticargumentbinding getsyntheticargument(referencebinding targetenclosingtype, boolean onlyexactmatch) {
if (this.enclosinginstances == null) return null;		// is null if no enclosing instances are known
// exact match
for (int i = this.enclosinginstances.length; --i >= 0;)
if (this.enclosinginstances[i].type == targetenclosingtype)
if (this.enclosinginstances[i].actualouterlocalvariable == null)
return this.enclosinginstances[i];

// type compatibility : to handle cases such as
// class t { class m{}}
// class s extends t { class n extends m {}} --> need to use s as a default enclosing instance for the super constructor call in n().
if (!onlyexactmatch){
for (int i = this.enclosinginstances.length; --i >= 0;)
if (this.enclosinginstances[i].actualouterlocalvariable == null)
if (this.enclosinginstances[i].type.findsupertypeoriginatingfrom(targetenclosingtype) != null)
return this.enclosinginstances[i];
}
return null;
}

public syntheticargumentbinding[] syntheticenclosinginstances() {
return this.enclosinginstances;		// is null if no enclosing instances are required
}

public referencebinding[] syntheticenclosinginstancetypes() {
if (this.enclosingtypes == uninitialized_reference_types) {
if (this.enclosinginstances == null) {
this.enclosingtypes = null;
} else {
int length = this.enclosinginstances.length;
this.enclosingtypes = new referencebinding[length];
for (int i = 0; i < length; i++) {
this.enclosingtypes[i] = (referencebinding) this.enclosinginstances[i].type;
}
}
}
return this.enclosingtypes;
}

public syntheticargumentbinding[] syntheticouterlocalvariables() {
return this.outerlocalvariables;		// is null if no outer locals are required
}

/*
* trigger the dependency mechanism forcing the innerclass emulation
* to be propagated to all dependent source types.
*/
public void updateinneremulationdependents() {
// nothing to do in general, only local types are doing anything
}
}
