/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

/**
* specific local variable location used to:
* - either provide emulation for outer local variables used from within innerclass constructs,
* - or provide emulation to enclosing instances.
* when it is mapping to an outer local variable, this actual outer local is accessible through
* the public field #actualouterlocalvariable.
*
* such a synthetic argument binding will be inserted in all constructors of local innertypes before
* the user arguments.
*/

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;

public class syntheticargumentbinding extends localvariablebinding {

{
this.tagbits |= tagbits.isargument;
this.useflag = used;
}

// if the argument is mapping to an outer local variable, this denotes the outer actual variable
public localvariablebinding actualouterlocalvariable;
// if the argument has a matching synthetic field
public fieldbinding matchingfield;

public syntheticargumentbinding(localvariablebinding actualouterlocalvariable) {

super(
charoperation.concat(typeconstants.synthetic_outer_local_prefix, actualouterlocalvariable.name),
actualouterlocalvariable.type,
classfileconstants.accfinal,
true);
this.actualouterlocalvariable = actualouterlocalvariable;
}

public syntheticargumentbinding(referencebinding enclosingtype) {

super(
charoperation.concat(
typeconstants.synthetic_enclosing_instance_prefix,
string.valueof(enclosingtype.depth()).tochararray()),
enclosingtype,
classfileconstants.accfinal,
true);
}
}
