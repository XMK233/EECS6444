/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class conditionalexpression extends operatorexpression {

public expression condition, valueiftrue, valueiffalse;
public constant optimizedbooleanconstant;
public constant optimizediftrueconstant;
public constant optimizediffalseconstant;

// for local variables table attributes
int trueinitstateindex = -1;
int falseinitstateindex = -1;
int mergedinitstateindex = -1;

public conditionalexpression(
expression condition,
expression valueiftrue,
expression valueiffalse) {
this.condition = condition;
this.valueiftrue = valueiftrue;
this.valueiffalse = valueiffalse;
this.sourcestart = condition.sourcestart;
this.sourceend = valueiffalse.sourceend;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext,
flowinfo flowinfo) {
int initialcomplaintlevel = (flowinfo.reachmode() & flowinfo.unreachable) != 0 ? statement.complained_fake_reachable : statement.not_complained;
constant cst = this.condition.optimizedbooleanconstant();
boolean isconditionoptimizedtrue = cst != constant.notaconstant && cst.booleanvalue() == true;
boolean isconditionoptimizedfalse = cst != constant.notaconstant && cst.booleanvalue() == false;

int mode = flowinfo.reachmode();
flowinfo = this.condition.analysecode(currentscope, flowcontext, flowinfo, cst == constant.notaconstant);

// process the if-true part
flowinfo trueflowinfo = flowinfo.initswhentrue().copy();
if (isconditionoptimizedfalse) {
if ((mode & flowinfo.unreachable) == 0) {
trueflowinfo.setreachmode(flowinfo.unreachable);
}
if (!isknowdeadcodepattern(this.condition) || currentscope.compileroptions().reportdeadcodeintrivialifstatement) {
this.valueiftrue.complainifunreachable(trueflowinfo, currentscope, initialcomplaintlevel);
}
}
this.trueinitstateindex = currentscope.methodscope().recordinitializationstates(trueflowinfo);
trueflowinfo = this.valueiftrue.analysecode(currentscope, flowcontext, trueflowinfo);

// process the if-false part
flowinfo falseflowinfo = flowinfo.initswhenfalse().copy();
if (isconditionoptimizedtrue) {
if ((mode & flowinfo.unreachable) == 0) {
falseflowinfo.setreachmode(flowinfo.unreachable);
}
if (!isknowdeadcodepattern(this.condition) || currentscope.compileroptions().reportdeadcodeintrivialifstatement) {
this.valueiffalse.complainifunreachable(falseflowinfo, currentscope, initialcomplaintlevel);
}
}
this.falseinitstateindex = currentscope.methodscope().recordinitializationstates(falseflowinfo);
falseflowinfo = this.valueiffalse.analysecode(currentscope, flowcontext, falseflowinfo);

// merge if-true & if-false initializations
flowinfo mergedinfo;
if (isconditionoptimizedtrue){
mergedinfo = trueflowinfo.addpotentialinitializationsfrom(falseflowinfo);
} else if (isconditionoptimizedfalse) {
mergedinfo = falseflowinfo.addpotentialinitializationsfrom(trueflowinfo);
} else {
// if ((t && (v = t)) ? t : t && (v = f)) r = v;  -- ok
cst = this.optimizediftrueconstant;
boolean isvalueiftrueoptimizedtrue = cst != null && cst != constant.notaconstant && cst.booleanvalue() == true;
boolean isvalueiftrueoptimizedfalse = cst != null && cst != constant.notaconstant && cst.booleanvalue() == false;

cst = this.optimizediffalseconstant;
boolean isvalueiffalseoptimizedtrue = cst != null && cst != constant.notaconstant && cst.booleanvalue() == true;
boolean isvalueiffalseoptimizedfalse = cst != null && cst != constant.notaconstant && cst.booleanvalue() == false;

unconditionalflowinfo trueinfowhentrue = trueflowinfo.initswhentrue().unconditionalcopy();
unconditionalflowinfo falseinfowhentrue = falseflowinfo.initswhentrue().unconditionalcopy();
unconditionalflowinfo trueinfowhenfalse = trueflowinfo.initswhenfalse().unconditionalinits();
unconditionalflowinfo falseinfowhenfalse = falseflowinfo.initswhenfalse().unconditionalinits();
if (isvalueiftrueoptimizedfalse) {
trueinfowhentrue.setreachmode(flowinfo.unreachable);
}
if (isvalueiffalseoptimizedfalse) {
falseinfowhentrue.setreachmode(flowinfo.unreachable);
}
if (isvalueiftrueoptimizedtrue) {
trueinfowhenfalse.setreachmode(flowinfo.unreachable);
}
if (isvalueiffalseoptimizedtrue) {
falseinfowhenfalse.setreachmode(flowinfo.unreachable);
}
mergedinfo =
flowinfo.conditional(
trueinfowhentrue.mergedwith(falseinfowhentrue),
trueinfowhenfalse.mergedwith(falseinfowhenfalse));
}
this.mergedinitstateindex =
currentscope.methodscope().recordinitializationstates(mergedinfo);
mergedinfo.setreachmode(mode);
return mergedinfo;
}

/**
* code generation for the conditional operator ?:
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(
blockscope currentscope,
codestream codestream,
boolean valuerequired) {

int pc = codestream.position;
branchlabel endiflabel, falselabel;
if (this.constant != constant.notaconstant) {
if (valuerequired)
codestream.generateconstant(this.constant, this.implicitconversion);
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
constant cst = this.condition.optimizedbooleanconstant();
boolean needtruepart = !(cst != constant.notaconstant && cst.booleanvalue() == false);
boolean needfalsepart = 	!(cst != constant.notaconstant && cst.booleanvalue() == true);
endiflabel = new branchlabel(codestream);

// generate code for the condition
falselabel = new branchlabel(codestream);
falselabel.tagbits |= branchlabel.used;
this.condition.generateoptimizedboolean(
currentscope,
codestream,
null,
falselabel,
cst == constant.notaconstant);

if (this.trueinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(
currentscope,
this.trueinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.trueinitstateindex);
}
// then code generation
if (needtruepart) {
this.valueiftrue.generatecode(currentscope, codestream, valuerequired);
if (needfalsepart) {
// jump over the else part
int position = codestream.position;
codestream.goto_(endiflabel);
codestream.updatelastrecordedendpc(currentscope, position);
// tune codestream stack size
if (valuerequired) {
switch(this.resolvedtype.id) {
case typeids.t_long :
case typeids.t_double :
codestream.decrstacksize(2);
break;
default :
codestream.decrstacksize(1);
break;
}
}
}
}
if (needfalsepart) {
if (this.falseinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(
currentscope,
this.falseinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.falseinitstateindex);
}
if (falselabel.forwardreferencecount() > 0) {
falselabel.place();
}
this.valueiffalse.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
codestream.recordexpressiontype(this.resolvedtype);
}
if (needtruepart) {
// end of if statement
endiflabel.place();
}
}
// may loose some local variable initializations : affecting the local variable attributes
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(
currentscope,
this.mergedinitstateindex);
}
// implicit conversion
if (valuerequired)
codestream.generateimplicitconversion(this.implicitconversion);
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* optimized boolean code generation for the conditional operator ?:
*/
public void generateoptimizedboolean(
blockscope currentscope,
codestream codestream,
branchlabel truelabel,
branchlabel falselabel,
boolean valuerequired) {

if ((this.constant != constant.notaconstant) && (this.constant.typeid() == t_boolean) // constant
|| ((this.valueiftrue.implicitconversion & implicit_conversion_mask) >> 4) != t_boolean) { // non boolean values
super.generateoptimizedboolean(currentscope, codestream, truelabel, falselabel, valuerequired);
return;
}
constant cst = this.condition.constant;
constant condcst = this.condition.optimizedbooleanconstant();
boolean needtruepart =
!(((cst != constant.notaconstant) && (cst.booleanvalue() == false))
|| ((condcst != constant.notaconstant) && (condcst.booleanvalue() == false)));
boolean needfalsepart =
!(((cst != constant.notaconstant) && (cst.booleanvalue() == true))
|| ((condcst != constant.notaconstant) && (condcst.booleanvalue() == true)));

branchlabel internalfalselabel, endiflabel = new branchlabel(codestream);

// generate code for the condition
boolean needconditionvalue = (cst == constant.notaconstant) && (condcst == constant.notaconstant);
this.condition.generateoptimizedboolean(
currentscope,
codestream,
null,
internalfalselabel = new branchlabel(codestream),
needconditionvalue);

if (this.trueinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(
currentscope,
this.trueinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.trueinitstateindex);
}
// then code generation
if (needtruepart) {
this.valueiftrue.generateoptimizedboolean(currentscope, codestream, truelabel, falselabel, valuerequired);

if (needfalsepart) {
// jump over the else part
jumpendif: {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
cst = this.optimizediftrueconstant;
boolean isvalueiftrueoptimizedtrue = cst != null && cst != constant.notaconstant && cst.booleanvalue() == true;
if (isvalueiftrueoptimizedtrue) break jumpendif; // no need to jump over, since branched to true already
}
} else {
// implicit falling through the true case
if (truelabel == null) {
cst = this.optimizediftrueconstant;
boolean isvalueiftrueoptimizedfalse = cst != null && cst != constant.notaconstant && cst.booleanvalue() == false;
if (isvalueiftrueoptimizedfalse) break jumpendif; // no need to jump over, since branched to false already
} else {
// no implicit fall through true/false --> should never occur
}
}
int position = codestream.position;
codestream.goto_(endiflabel);
codestream.updatelastrecordedendpc(currentscope, position);
}
// no need to decrement codestream stack size
// since valueiftrue was already consumed by branch bytecode
}
}
if (needfalsepart) {
internalfalselabel.place();
if (this.falseinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.falseinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.falseinitstateindex);
}
this.valueiffalse.generateoptimizedboolean(currentscope, codestream, truelabel, falselabel, valuerequired);

// end of if statement
endiflabel.place();
}
// may loose some local variable initializations : affecting the local variable attributes
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
// no implicit conversion for boolean values
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}

public int nullstatus(flowinfo flowinfo) {
constant cst = this.condition.optimizedbooleanconstant();
if (cst != constant.notaconstant) {
if (cst.booleanvalue()) {
return this.valueiftrue.nullstatus(flowinfo);
}
return this.valueiffalse.nullstatus(flowinfo);
}
int iftruenullstatus = this.valueiftrue.nullstatus(flowinfo),
iffalsenullstatus = this.valueiffalse.nullstatus(flowinfo);
if (iftruenullstatus == iffalsenullstatus) {
return iftruenullstatus;
}
return flowinfo.unknown;
// cannot decide which branch to take, and they disagree
}

public constant optimizedbooleanconstant() {

return this.optimizedbooleanconstant == null ? this.constant : this.optimizedbooleanconstant;
}

public stringbuffer printexpressionnoparenthesis(int indent, stringbuffer output) {

this.condition.printexpression(indent, output).append(" ? "); //$non-nls-1$
this.valueiftrue.printexpression(0, output).append(" : "); //$non-nls-1$
return this.valueiffalse.printexpression(0, output);
}

public typebinding resolvetype(blockscope scope) {
// jls3 15.25
this.constant = constant.notaconstant;
lookupenvironment env = scope.environment();
boolean use15specifics = scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
typebinding conditiontype = this.condition.resolvetypeexpecting(scope, typebinding.boolean);
this.condition.computeconversion(scope, typebinding.boolean, conditiontype);

if (this.valueiftrue instanceof castexpression) this.valueiftrue.bits |= disableunnecessarycastcheck; // will check later on
typebinding originalvalueiftruetype = this.valueiftrue.resolvetype(scope);

if (this.valueiffalse instanceof castexpression) this.valueiffalse.bits |= disableunnecessarycastcheck; // will check later on
typebinding originalvalueiffalsetype = this.valueiffalse.resolvetype(scope);

if (conditiontype == null || originalvalueiftruetype == null || originalvalueiffalsetype == null)
return null;

typebinding valueiftruetype = originalvalueiftruetype;
typebinding valueiffalsetype = originalvalueiffalsetype;
if (use15specifics && valueiftruetype != valueiffalsetype) {
if (valueiftruetype.isbasetype()) {
if (valueiffalsetype.isbasetype()) {
// bool ? basetype : basetype
if (valueiftruetype == typebinding.null) {  // bool ? null : 12 --> integer
valueiffalsetype = env.computeboxingtype(valueiffalsetype); // boxing
} else if (valueiffalsetype == typebinding.null) {  // bool ? 12 : null --> integer
valueiftruetype = env.computeboxingtype(valueiftruetype); // boxing
}
} else {
// bool ? basetype : nonbasetype
typebinding unboxediffalsetype = valueiffalsetype.isbasetype() ? valueiffalsetype : env.computeboxingtype(valueiffalsetype);
if (valueiftruetype.isnumerictype() && unboxediffalsetype.isnumerictype()) {
valueiffalsetype = unboxediffalsetype; // unboxing
} else if (valueiftruetype != typebinding.null) {  // bool ? 12 : new integer(12) --> int
valueiffalsetype = env.computeboxingtype(valueiffalsetype); // unboxing
}
}
} else if (valueiffalsetype.isbasetype()) {
// bool ? nonbasetype : basetype
typebinding unboxediftruetype = valueiftruetype.isbasetype() ? valueiftruetype : env.computeboxingtype(valueiftruetype);
if (unboxediftruetype.isnumerictype() && valueiffalsetype.isnumerictype()) {
valueiftruetype = unboxediftruetype; // unboxing
} else if (valueiffalsetype != typebinding.null) {  // bool ? new integer(12) : 12 --> int
valueiftruetype = env.computeboxingtype(valueiftruetype); // unboxing
}
} else {
// bool ? nonbasetype : nonbasetype
typebinding unboxediftruetype = env.computeboxingtype(valueiftruetype);
typebinding unboxediffalsetype = env.computeboxingtype(valueiffalsetype);
if (unboxediftruetype.isnumerictype() && unboxediffalsetype.isnumerictype()) {
valueiftruetype = unboxediftruetype;
valueiffalsetype = unboxediffalsetype;
}
}
}
// propagate the constant value from the valueiftrue and valueiffalse expression if it is possible
constant condconstant, trueconstant, falseconstant;
if ((condconstant = this.condition.constant) != constant.notaconstant
&& (trueconstant = this.valueiftrue.constant) != constant.notaconstant
&& (falseconstant = this.valueiffalse.constant) != constant.notaconstant) {
// all terms are constant expression so we can propagate the constant
// from valueiftrue or valueiffalse to the receiver constant
this.constant = condconstant.booleanvalue() ? trueconstant : falseconstant;
}
if (valueiftruetype == valueiffalsetype) { // harmed the implicit conversion
this.valueiftrue.computeconversion(scope, valueiftruetype, originalvalueiftruetype);
this.valueiffalse.computeconversion(scope, valueiffalsetype, originalvalueiffalsetype);
if (valueiftruetype == typebinding.boolean) {
this.optimizediftrueconstant = this.valueiftrue.optimizedbooleanconstant();
this.optimizediffalseconstant = this.valueiffalse.optimizedbooleanconstant();
if (this.optimizediftrueconstant != constant.notaconstant
&& this.optimizediffalseconstant != constant.notaconstant
&& this.optimizediftrueconstant.booleanvalue() == this.optimizediffalseconstant.booleanvalue()) {
// a ? true : true  /   a ? false : false
this.optimizedbooleanconstant = this.optimizediftrueconstant;
} else if ((condconstant = this.condition.optimizedbooleanconstant()) != constant.notaconstant) { // propagate the optimized boolean constant if possible
this.optimizedbooleanconstant = condconstant.booleanvalue()
? this.optimizediftrueconstant
: this.optimizediffalseconstant;
}
}
return this.resolvedtype = valueiftruetype;
}
// determine the return type depending on argument types
// numeric types
if (valueiftruetype.isnumerictype() && valueiffalsetype.isnumerictype()) {
// (short x byte) or (byte x short)"
if ((valueiftruetype == typebinding.byte && valueiffalsetype == typebinding.short)
|| (valueiftruetype == typebinding.short && valueiffalsetype == typebinding.byte)) {
this.valueiftrue.computeconversion(scope, typebinding.short, originalvalueiftruetype);
this.valueiffalse.computeconversion(scope, typebinding.short, originalvalueiffalsetype);
return this.resolvedtype = typebinding.short;
}
// <byte|short|char> x constant(int)  ---> <byte|short|char>   and reciprocally
if ((valueiftruetype == typebinding.byte || valueiftruetype == typebinding.short || valueiftruetype == typebinding.char)
&& (valueiffalsetype == typebinding.int
&& this.valueiffalse.isconstantvalueoftypeassignabletotype(valueiffalsetype, valueiftruetype))) {
this.valueiftrue.computeconversion(scope, valueiftruetype, originalvalueiftruetype);
this.valueiffalse.computeconversion(scope, valueiftruetype, originalvalueiffalsetype);
return this.resolvedtype = valueiftruetype;
}
if ((valueiffalsetype == typebinding.byte
|| valueiffalsetype == typebinding.short
|| valueiffalsetype == typebinding.char)
&& (valueiftruetype == typebinding.int
&& this.valueiftrue.isconstantvalueoftypeassignabletotype(valueiftruetype, valueiffalsetype))) {
this.valueiftrue.computeconversion(scope, valueiffalsetype, originalvalueiftruetype);
this.valueiffalse.computeconversion(scope, valueiffalsetype, originalvalueiffalsetype);
return this.resolvedtype = valueiffalsetype;
}
// manual binary numeric promotion
// int
if (basetypebinding.isnarrowing(valueiftruetype.id, t_int)
&& basetypebinding.isnarrowing(valueiffalsetype.id, t_int)) {
this.valueiftrue.computeconversion(scope, typebinding.int, originalvalueiftruetype);
this.valueiffalse.computeconversion(scope, typebinding.int, originalvalueiffalsetype);
return this.resolvedtype = typebinding.int;
}
// long
if (basetypebinding.isnarrowing(valueiftruetype.id, t_long)
&& basetypebinding.isnarrowing(valueiffalsetype.id, t_long)) {
this.valueiftrue.computeconversion(scope, typebinding.long, originalvalueiftruetype);
this.valueiffalse.computeconversion(scope, typebinding.long, originalvalueiffalsetype);
return this.resolvedtype = typebinding.long;
}
// float
if (basetypebinding.isnarrowing(valueiftruetype.id, t_float)
&& basetypebinding.isnarrowing(valueiffalsetype.id, t_float)) {
this.valueiftrue.computeconversion(scope, typebinding.float, originalvalueiftruetype);
this.valueiffalse.computeconversion(scope, typebinding.float, originalvalueiffalsetype);
return this.resolvedtype = typebinding.float;
}
// double
this.valueiftrue.computeconversion(scope, typebinding.double, originalvalueiftruetype);
this.valueiffalse.computeconversion(scope, typebinding.double, originalvalueiffalsetype);
return this.resolvedtype = typebinding.double;
}
// type references (null null is already tested)
if (valueiftruetype.isbasetype() && valueiftruetype != typebinding.null) {
if (use15specifics) {
valueiftruetype = env.computeboxingtype(valueiftruetype);
} else {
scope.problemreporter().conditionalargumentsincompatibletypes(this, valueiftruetype, valueiffalsetype);
return null;
}
}
if (valueiffalsetype.isbasetype() && valueiffalsetype != typebinding.null) {
if (use15specifics) {
valueiffalsetype = env.computeboxingtype(valueiffalsetype);
} else {
scope.problemreporter().conditionalargumentsincompatibletypes(this, valueiftruetype, valueiffalsetype);
return null;
}
}
if (use15specifics) {
// >= 1.5 : lub(operand types) must exist
typebinding commontype = null;
if (valueiftruetype == typebinding.null) {
commontype = valueiffalsetype;
} else if (valueiffalsetype == typebinding.null) {
commontype = valueiftruetype;
} else {
commontype = scope.lowerupperbound(new typebinding[] { valueiftruetype, valueiffalsetype });
}
if (commontype != null) {
this.valueiftrue.computeconversion(scope, commontype, originalvalueiftruetype);
this.valueiffalse.computeconversion(scope, commontype, originalvalueiffalsetype);
return this.resolvedtype = commontype.capture(scope, this.sourceend);
}
} else {
// < 1.5 : one operand must be convertible to the other
if (valueiffalsetype.iscompatiblewith(valueiftruetype)) {
this.valueiftrue.computeconversion(scope, valueiftruetype, originalvalueiftruetype);
this.valueiffalse.computeconversion(scope, valueiftruetype, originalvalueiffalsetype);
return this.resolvedtype = valueiftruetype;
} else if (valueiftruetype.iscompatiblewith(valueiffalsetype)) {
this.valueiftrue.computeconversion(scope, valueiffalsetype, originalvalueiftruetype);
this.valueiffalse.computeconversion(scope, valueiffalsetype, originalvalueiffalsetype);
return this.resolvedtype = valueiffalsetype;
}
}
scope.problemreporter().conditionalargumentsincompatibletypes(
this,
valueiftruetype,
valueiffalsetype);
return null;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
this.condition.traverse(visitor, scope);
this.valueiftrue.traverse(visitor, scope);
this.valueiffalse.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
