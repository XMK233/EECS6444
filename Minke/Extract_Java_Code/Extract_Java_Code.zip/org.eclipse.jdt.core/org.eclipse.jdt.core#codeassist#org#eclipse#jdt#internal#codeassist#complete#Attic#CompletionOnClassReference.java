/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

public class completiononclassreference extends completiononsingletypereference {

public completiononclassreference(char[] source, long pos) {

super(source, pos);
}

public stringbuffer printexpression(int indent, stringbuffer output) {

return output.append("<completeonclass:").append(this.token).append('>'); //$non-nls-1$
}
}
