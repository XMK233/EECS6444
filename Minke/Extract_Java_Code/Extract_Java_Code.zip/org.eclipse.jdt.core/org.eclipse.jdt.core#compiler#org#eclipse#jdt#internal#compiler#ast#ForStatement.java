/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class forstatement extends statement {

public statement[] initializations;
public expression condition;
public statement[] increments;
public statement action;

//when there is no local declaration, there is no need of a new scope
//scope is positioned either to a new scope, or to the "upper"scope (see resolvetype)
public blockscope scope;

private branchlabel breaklabel, continuelabel;

// for local variables table attributes
int precondinitstateindex = -1;
int preincrementsinitstateindex = -1;
int condiftrueinitstateindex = -1;
int mergedinitstateindex = -1;

public forstatement(
statement[] initializations,
expression condition,
statement[] increments,
statement action,
boolean neededscope,
int s,
int e) {

this.sourcestart = s;
this.sourceend = e;
this.initializations = initializations;
this.condition = condition;
this.increments = increments;
this.action = action;
// remember useful empty statement
if (action instanceof emptystatement) action.bits |= astnode.isusefulemptystatement;
if (neededscope) {
this.bits |= astnode.neededscope;
}
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
this.breaklabel = new branchlabel();
this.continuelabel = new branchlabel();
int initialcomplaintlevel = (flowinfo.reachmode() & flowinfo.unreachable) != 0 ? statement.complained_fake_reachable : statement.not_complained;

// process the initializations
if (this.initializations != null) {
for (int i = 0, count = this.initializations.length; i < count; i++) {
flowinfo = this.initializations[i].analysecode(this.scope, flowcontext, flowinfo);
}
}
this.precondinitstateindex =
currentscope.methodscope().recordinitializationstates(flowinfo);

constant cst = this.condition == null ? null : this.condition.constant;
boolean isconditiontrue = cst == null || (cst != constant.notaconstant && cst.booleanvalue() == true);
boolean isconditionfalse = cst != null && (cst != constant.notaconstant && cst.booleanvalue() == false);

cst = this.condition == null ? null : this.condition.optimizedbooleanconstant();
boolean isconditionoptimizedtrue = cst == null ||  (cst != constant.notaconstant && cst.booleanvalue() == true);
boolean isconditionoptimizedfalse = cst != null && (cst != constant.notaconstant && cst.booleanvalue() == false);

// process the condition
loopingflowcontext condloopcontext = null;
flowinfo condinfo = flowinfo.nullinfolessunconditionalcopy();
if (this.condition != null) {
if (!isconditiontrue) {
condinfo =
this.condition.analysecode(
this.scope,
(condloopcontext =
new loopingflowcontext(flowcontext, flowinfo, this, null,
null, this.scope)),
condinfo);
}
}

// process the action
loopingflowcontext loopingcontext;
unconditionalflowinfo actioninfo;
if (this.action == null
|| (this.action.isemptyblock() && currentscope.compileroptions().compliancelevel <= classfileconstants.jdk1_3)) {
if (condloopcontext != null)
condloopcontext.complainondeferredfinalchecks(this.scope, condinfo);
if (isconditiontrue) {
if (condloopcontext != null) {
condloopcontext.complainondeferrednullchecks(currentscope,
condinfo);
}
return flowinfo.dead_end;
} else {
if (isconditionfalse){
this.continuelabel = null; // for(;false;p());
}
actioninfo = condinfo.initswhentrue().unconditionalcopy();
loopingcontext =
new loopingflowcontext(flowcontext, flowinfo, this,
this.breaklabel, this.continuelabel, this.scope);
}
}
else {
loopingcontext =
new loopingflowcontext(flowcontext, flowinfo, this, this.breaklabel,
this.continuelabel, this.scope);
flowinfo initswhentrue = condinfo.initswhentrue();
this.condiftrueinitstateindex =
currentscope.methodscope().recordinitializationstates(initswhentrue);

if (isconditionfalse) {
actioninfo = flowinfo.dead_end;
} else {
actioninfo = initswhentrue.unconditionalcopy();
if (isconditionoptimizedfalse){
actioninfo.setreachmode(flowinfo.unreachable);
}
}
if (this.action.complainifunreachable(actioninfo, this.scope, initialcomplaintlevel) < statement.complained_unreachable) {
actioninfo = this.action.analysecode(this.scope, loopingcontext, actioninfo).unconditionalinits();
}

// code generation can be optimized when no need to continue in the loop
if ((actioninfo.tagbits &
loopingcontext.initsoncontinue.tagbits &
flowinfo.unreachable) != 0) {
this.continuelabel = null;
}
else {
if (condloopcontext != null) {
condloopcontext.complainondeferredfinalchecks(this.scope,
condinfo);
}
actioninfo = actioninfo.mergedwith(loopingcontext.initsoncontinue);
loopingcontext.complainondeferredfinalchecks(this.scope,
actioninfo);
}
}
// for increments
flowinfo exitbranch = flowinfo.copy();
// recover null inits from before condition analysis
loopingflowcontext incrementcontext = null;
if (this.continuelabel != null) {
if (this.increments != null) {
incrementcontext =
new loopingflowcontext(flowcontext, flowinfo, this, null,
null, this.scope);
flowinfo incrementinfo = actioninfo;
this.preincrementsinitstateindex =
currentscope.methodscope().recordinitializationstates(incrementinfo);
for (int i = 0, count = this.increments.length; i < count; i++) {
incrementinfo = this.increments[i].
analysecode(this.scope, incrementcontext, incrementinfo);
}
incrementcontext.complainondeferredfinalchecks(this.scope,
actioninfo = incrementinfo.unconditionalinits());
}
exitbranch.addpotentialinitializationsfrom(actioninfo).
addinitializationsfrom(condinfo.initswhenfalse());
} else {
exitbranch.addinitializationsfrom(condinfo.initswhenfalse());
if (this.increments != null) {
if (initialcomplaintlevel == statement.not_complained) {
currentscope.problemreporter().fakereachable(this.increments[0]);
}
}
}
// nulls checks
if (condloopcontext != null) {
condloopcontext.complainondeferrednullchecks(currentscope,
actioninfo);
}
loopingcontext.complainondeferrednullchecks(currentscope,
actioninfo);
if (incrementcontext != null) {
incrementcontext.complainondeferrednullchecks(currentscope,
actioninfo);
}

//end of loop
flowinfo mergedinfo = flowinfo.mergedoptimizedbranches(
(loopingcontext.initsonbreak.tagbits &
flowinfo.unreachable) != 0 ?
loopingcontext.initsonbreak :
flowinfo.addinitializationsfrom(loopingcontext.initsonbreak), // recover upstream null info
isconditionoptimizedtrue,
exitbranch,
isconditionoptimizedfalse,
!isconditiontrue /*for(;;){}while(true); unreachable(); */);
this.mergedinitstateindex = currentscope.methodscope().recordinitializationstates(mergedinfo);
return mergedinfo;
}

/**
* for statement code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {

if ((this.bits & isreachable) == 0) {
return;
}
int pc = codestream.position;

// generate the initializations
if (this.initializations != null) {
for (int i = 0, max = this.initializations.length; i < max; i++) {
this.initializations[i].generatecode(this.scope, codestream);
}
}
constant cst = this.condition == null ? null : this.condition.optimizedbooleanconstant();
boolean isconditionoptimizedfalse = cst != null && (cst != constant.notaconstant && cst.booleanvalue() == false);
if (isconditionoptimizedfalse) {
this.condition.generatecode(this.scope, codestream, false);
// may loose some local variable initializations : affecting the local variable attributes
if ((this.bits & astnode.neededscope) != 0) {
codestream.exituserscope(this.scope);
}
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}

// label management
branchlabel actionlabel = new branchlabel(codestream);
actionlabel.tagbits |= branchlabel.used;
branchlabel conditionlabel = new branchlabel(codestream);
this.breaklabel.initialize(codestream);
if (this.continuelabel == null) {
conditionlabel.place();
if ((this.condition != null) && (this.condition.constant == constant.notaconstant)) {
this.condition.generateoptimizedboolean(this.scope, codestream, null, this.breaklabel, true);
}
} else {
this.continuelabel.initialize(codestream);
// jump over the actionblock
if ((this.condition != null)
&& (this.condition.constant == constant.notaconstant)
&& !((this.action == null || this.action.isemptyblock()) && (this.increments == null))) {
conditionlabel.tagbits |= branchlabel.used;
int jumppc = codestream.position;
codestream.goto_(conditionlabel);
codestream.recordpositionsfrom(jumppc, this.condition.sourcestart);
}
}

// generate the loop action
if (this.action != null) {
// required to fix 1pr0xvs: lfre:winnt - compiler: variable table for method appears incorrect
if (this.condiftrueinitstateindex != -1) {
// insert all locals initialized inside the condition into the action generated prior to the condition
codestream.adddefinitelyassignedvariables(
currentscope,
this.condiftrueinitstateindex);
}
actionlabel.place();
this.action.generatecode(this.scope, codestream);
} else {
actionlabel.place();
}
if (this.preincrementsinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.preincrementsinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.preincrementsinitstateindex);
}
// continuation point
if (this.continuelabel != null) {
this.continuelabel.place();
// generate the increments for next iteration
if (this.increments != null) {
for (int i = 0, max = this.increments.length; i < max; i++) {
this.increments[i].generatecode(this.scope, codestream);
}
}
// may loose some local variable initializations : affecting the local variable attributes
if (this.precondinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.precondinitstateindex);
}
// generate the condition
conditionlabel.place();
if ((this.condition != null) && (this.condition.constant == constant.notaconstant)) {
this.condition.generateoptimizedboolean(this.scope, codestream, actionlabel, null, true);
} else {
codestream.goto_(actionlabel);
}

} else {
// may loose some local variable initializations : affecting the local variable attributes
if (this.precondinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.precondinitstateindex);
}
}


// may loose some local variable initializations : affecting the local variable attributes
if ((this.bits & astnode.neededscope) != 0) {
codestream.exituserscope(this.scope);
}
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
this.breaklabel.place();
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public stringbuffer printstatement(int tab, stringbuffer output) {

printindent(tab, output).append("for ("); //$non-nls-1$
//inits
if (this.initializations != null) {
for (int i = 0; i < this.initializations.length; i++) {
//nice only with expressions
if (i > 0) output.append(", "); //$non-nls-1$
this.initializations[i].print(0, output);
}
}
output.append("; "); //$non-nls-1$
//cond
if (this.condition != null) this.condition.printexpression(0, output);
output.append("; "); //$non-nls-1$
//updates
if (this.increments != null) {
for (int i = 0; i < this.increments.length; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.increments[i].print(0, output);
}
}
output.append(") "); //$non-nls-1$
//block
if (this.action == null)
output.append(';');
else {
output.append('\n');
this.action.printstatement(tab + 1, output);
}
return output;
}

public void resolve(blockscope upperscope) {

// use the scope that will hold the init declarations
this.scope = (this.bits & astnode.neededscope) != 0 ? new blockscope(upperscope) : upperscope;
if (this.initializations != null)
for (int i = 0, length = this.initializations.length; i < length; i++)
this.initializations[i].resolve(this.scope);
if (this.condition != null) {
typebinding type = this.condition.resolvetypeexpecting(this.scope, typebinding.boolean);
this.condition.computeconversion(this.scope, type, type);
}
if (this.increments != null)
for (int i = 0, length = this.increments.length; i < length; i++)
this.increments[i].resolve(this.scope);
if (this.action != null)
this.action.resolve(this.scope);
}

public void traverse(
astvisitor visitor,
blockscope blockscope) {

if (visitor.visit(this, blockscope)) {
if (this.initializations != null) {
int initializationslength = this.initializations.length;
for (int i = 0; i < initializationslength; i++)
this.initializations[i].traverse(visitor, this.scope);
}

if (this.condition != null)
this.condition.traverse(visitor, this.scope);

if (this.increments != null) {
int incrementslength = this.increments.length;
for (int i = 0; i < incrementslength; i++)
this.increments[i].traverse(visitor, this.scope);
}

if (this.action != null)
this.action.traverse(visitor, this.scope);
}
visitor.endvisit(this, blockscope);
}
}
