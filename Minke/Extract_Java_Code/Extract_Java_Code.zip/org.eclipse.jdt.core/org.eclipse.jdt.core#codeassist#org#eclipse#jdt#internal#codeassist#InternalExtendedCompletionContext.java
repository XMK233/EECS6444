/*******************************************************************************
* copyright (c) 2008, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import java.util.hashmap;
import java.util.map;

import org.eclipse.jdt.core.icompilationunit;
import org.eclipse.jdt.core.ijavaelement;
import org.eclipse.jdt.core.ityperoot;
import org.eclipse.jdt.core.javamodelexception;
import org.eclipse.jdt.core.workingcopyowner;
import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.codeassist.complete.completionnodedetector;
import org.eclipse.jdt.internal.codeassist.complete.completionparser;
import org.eclipse.jdt.internal.codeassist.impl.assistcompilationunit;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.compilationunitdeclaration;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.ast.initializer;
import org.eclipse.jdt.internal.compiler.ast.localdeclaration;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.ast.typeparameter;
import org.eclipse.jdt.internal.compiler.impl.referencecontext;
import org.eclipse.jdt.internal.compiler.lookup.binarytypebinding;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.importbinding;
import org.eclipse.jdt.internal.compiler.lookup.invocationsite;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.lookupenvironment;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.parameterizedtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.signaturewrapper;
import org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typevariablebinding;
import org.eclipse.jdt.internal.compiler.problem.abortcompilation;
import org.eclipse.jdt.internal.compiler.util.objectvector;
import org.eclipse.jdt.internal.core.compilationunitelementinfo;
import org.eclipse.jdt.internal.core.javaelement;
import org.eclipse.jdt.internal.core.localvariable;
import org.eclipse.jdt.internal.core.util.util;

public class internalextendedcompletioncontext {
private static util.bindingstonodesmap emptynodemap = new util.bindingstonodesmap() {
public astnode get(binding binding) {
return null;
}
};

private internalcompletioncontext completioncontext;

// static data
private ityperoot typeroot;
private compilationunitdeclaration compilationunitdeclaration;
private lookupenvironment lookupenvironment;
private scope assistscope;
private astnode assistnode;
private workingcopyowner owner;

private completionparser parser;

// computed data
private boolean hascomputedvisibleelementbindings;
private objectvector visiblelocalvariables;
private objectvector visiblefields;
private objectvector visiblemethods;

private boolean hascomputedenclosingjavaelements;
private map bindingstohandles;
private map nodeswithproblemstohandles;
private icompilationunit compilationunit;

public internalextendedcompletioncontext(
internalcompletioncontext completioncontext,
ityperoot typeroot,
compilationunitdeclaration compilationunitdeclaration,
lookupenvironment lookupenvironment,
scope assistscope,
astnode assistnode,
workingcopyowner owner,
completionparser parser) {
this.completioncontext = completioncontext;
this.typeroot = typeroot;
this.compilationunitdeclaration = compilationunitdeclaration;
this.lookupenvironment = lookupenvironment;
this.assistscope = assistscope;
this.assistnode = assistnode;
this.owner = owner;
this.parser = parser;
}

private void computeenclosingjavaelements() {
this.hascomputedenclosingjavaelements = true;

if (this.typeroot == null) return;

if (this.typeroot.getelementtype() == ijavaelement.compilation_unit) {
icompilationunit original = (org.eclipse.jdt.core.icompilationunit)this.typeroot;

hashmap handletobinding = new hashmap();
hashmap bindingtohandle = new hashmap();
hashmap nodewithproblemtohandle = new hashmap();
hashmap handletoinfo = new hashmap();

org.eclipse.jdt.core.icompilationunit handle = new assistcompilationunit(original, this.owner, handletobinding, handletoinfo);
compilationunitelementinfo info = new compilationunitelementinfo();

handletoinfo.put(handle, info);

completionunitstructurerequestor structurerequestor =
new completionunitstructurerequestor(
handle,
info,
this.parser,
this.assistnode,
handletobinding,
bindingtohandle,
nodewithproblemtohandle,
handletoinfo);

completionelementnotifier notifier =
new completionelementnotifier(
structurerequestor,
true,
this.assistnode);

notifier.notifysourceelementrequestor(
this.compilationunitdeclaration,
this.compilationunitdeclaration.sourcestart,
this.compilationunitdeclaration.sourceend,
false,
this.parser.sourceends,
new hashmap());

this.bindingstohandles = bindingtohandle;
this.nodeswithproblemstohandles = nodewithproblemtohandle;
this.compilationunit = handle;
}
}

private void computevisibleelementbindings() {
compilationunitdeclaration previousunitbeingcompleted = this.lookupenvironment.unitbeingcompleted;
this.lookupenvironment.unitbeingcompleted = this.compilationunitdeclaration;
try {
this.hascomputedvisibleelementbindings = true;

scope scope = this.assistscope;
astnode astnode = this.assistnode;
boolean notinjavadoc = this.completioncontext.javadoc == 0;

this.visiblelocalvariables = new objectvector();
this.visiblefields = new objectvector();
this.visiblemethods = new objectvector();

referencecontext referencecontext = scope.referencecontext();
if (referencecontext instanceof abstractmethoddeclaration) {
// completion is inside a method body
searchvisiblevariablesandmethods(scope, this.visiblelocalvariables, this.visiblefields, this.visiblemethods, notinjavadoc);
} else if (referencecontext instanceof typedeclaration) {
typedeclaration typedeclaration = (typedeclaration) referencecontext;
fielddeclaration[] fields = typedeclaration.fields;
if (fields != null) {
done : for (int i = 0; i < fields.length; i++) {
if (fields[i] instanceof initializer) {
initializer initializer = (initializer) fields[i];
if (initializer.block.sourcestart <= astnode.sourcestart &&
astnode.sourcestart < initializer.bodyend) {
// completion is inside an initializer
searchvisiblevariablesandmethods(scope, this.visiblelocalvariables, this.visiblefields, this.visiblemethods, notinjavadoc);
break done;
}
} else {
fielddeclaration fielddeclaration = fields[i];
if (fielddeclaration.initialization != null &&
fielddeclaration.initialization.sourcestart <= astnode.sourcestart &&
astnode.sourceend <= fielddeclaration.initialization.sourceend) {
// completion is inside a field initializer
searchvisiblevariablesandmethods(scope, this.visiblelocalvariables, this.visiblefields, this.visiblemethods, notinjavadoc);
break done;
}
}
}
}
}
} finally {
this.lookupenvironment.unitbeingcompleted = previousunitbeingcompleted;
}
}

public ijavaelement getenclosingelement() {
try {
if (!this.hascomputedenclosingjavaelements) {
computeenclosingjavaelements();
}
if (this.compilationunit == null) return null;
ijavaelement enclosingelement = this.compilationunit.getelementat(this.completioncontext.offset);
return enclosingelement == null ? this.compilationunit : enclosingelement;
} catch (javamodelexception e) {
util.log(e, "cannot compute enclosing element"); //$non-nls-1$
return null;
}
}

private javaelement getjavaelement(localvariablebinding binding) {
localdeclaration local = binding.declaration;

javaelement parent = null;
referencecontext referencecontext = binding.declaringscope.referencecontext();
if (referencecontext instanceof abstractmethoddeclaration) {
abstractmethoddeclaration methoddeclaration = (abstractmethoddeclaration) referencecontext;
parent = this.getjavaelementofcompilationunit(methoddeclaration, methoddeclaration.binding);
} else if (referencecontext instanceof typedeclaration){
// local variable is declared inside an initializer
typedeclaration typedeclaration = (typedeclaration) referencecontext;

javaelement type = this.getjavaelementofcompilationunit(typedeclaration, typedeclaration.binding);
parent = util.getunresolvedjavaelement(local.sourcestart, local.sourceend, type);
}
if (parent == null) return null;

return new localvariable(
parent,
new string(local.name),
local.declarationsourcestart,
local.declarationsourceend,
local.sourcestart,
local.sourceend,
util.typesignature(local.type),
binding.declaration.annotations);
}

private javaelement getjavaelementofcompilationunit(binding binding) {
if (!this.hascomputedenclosingjavaelements) {
computeenclosingjavaelements();
}
if (this.bindingstohandles == null) return null;
return (javaelement)this.bindingstohandles.get(binding);
}

private javaelement getjavaelementofcompilationunit(astnode node, binding binding) {
if (!this.hascomputedenclosingjavaelements) {
computeenclosingjavaelements();
}
if (binding != null) {
if (this.bindingstohandles == null) return null;
return (javaelement)this.bindingstohandles.get(binding);
} else {
if (this.nodeswithproblemstohandles == null) return null;
return (javaelement)this.nodeswithproblemstohandles.get(node);
}
}

private typebinding gettypefromsignature(string typesignature, scope scope) {
typebinding assignabletypebinding = null;

typevariablebinding[] typevariables = binding.no_type_variables;
referencecontext referencecontext = scope.referencecontext();
if (referencecontext instanceof abstractmethoddeclaration) {
abstractmethoddeclaration methoddeclaration = (abstractmethoddeclaration) referencecontext;
typeparameter[] typeparameters = methoddeclaration.typeparameters();
if (typeparameters != null && typeparameters.length > 0) {
int length = typeparameters.length;
int count = 0;
typevariables = new typevariablebinding[length];
for (int i = 0; i < length; i++) {
if (typeparameters[i].binding != null) {
typevariables[count++] = typeparameters[i].binding;
}
}

if (count != length) {
system.arraycopy(typevariables, 0, typevariables = new typevariablebinding[count], 0, count);
}
}
}

compilationunitdeclaration previousunitbeingcompleted = this.lookupenvironment.unitbeingcompleted;
this.lookupenvironment.unitbeingcompleted = this.compilationunitdeclaration;
try {

signaturewrapper wrapper = new signaturewrapper(replacepackagesdot(typesignature.tochararray()));
assignabletypebinding = this.lookupenvironment.gettypefromtypesignature(wrapper, typevariables, this.assistscope.enclosingclassscope().referencecontext.binding, null);
assignabletypebinding = binarytypebinding.resolvetype(assignabletypebinding, this.lookupenvironment, true);
} catch (abortcompilation e) {
assignabletypebinding = null;
} finally {
this.lookupenvironment.unitbeingcompleted = previousunitbeingcompleted;
}
return assignabletypebinding;
}

private char[] replacepackagesdot(char[] signature) {
boolean replace = true;
int length = signature.length;
for (int i = 0; i < length; i++) {
switch (signature[i]) {
case '.':
if (replace) signature[i] = '/';
break;
case '<':
replace = true;
break;
case '>':
replace = false;
break;
}
}
return signature;
}

public ijavaelement[] getvisibleelements(string typesignature) {
if (this.assistscope == null) return new ijavaelement[0];

if (!this.hascomputedvisibleelementbindings) {
computevisibleelementbindings();
}

typebinding assignabletypebinding = null;
if (typesignature != null) {
assignabletypebinding = gettypefromsignature(typesignature, this.assistscope);
if (assignabletypebinding == null) return new ijavaelement[0];
}

int length = this.visiblelocalvariables.size() + this.visiblefields.size() + this.visiblemethods.size();
if (length == 0) return new ijavaelement[0];

ijavaelement[] result = new ijavaelement[length];

int elementcount = 0;

int size = this.visiblelocalvariables.size();
if (size > 0) {
next : for (int i = 0; i < size; i++) {
try {
localvariablebinding binding = (localvariablebinding) this.visiblelocalvariables.elementat(i);
if (assignabletypebinding != null && !binding.type.iscompatiblewith(assignabletypebinding)) continue next;
javaelement localvariable = getjavaelement(binding);
if (localvariable != null) result[elementcount++] = localvariable;
} catch(abortcompilation e) {
// log the exception and proceed
util.logrepeatedmessage(e.getkey(), e);
}
}

}
size = this.visiblefields.size();
if (size > 0) {
next : for (int i = 0; i < size; i++) {
try {
fieldbinding binding = (fieldbinding) this.visiblefields.elementat(i);
if (assignabletypebinding != null && !binding.type.iscompatiblewith(assignabletypebinding)) continue next;
if (this.assistscope.isdefinedinsameunit(binding.declaringclass)) {
javaelement field = getjavaelementofcompilationunit(binding);
if (field != null) result[elementcount++] = field;
} else {
javaelement field = util.getunresolvedjavaelement(binding, this.owner, emptynodemap);
if (field != null) result[elementcount++] = field.resolved(binding);
}
} catch(abortcompilation e) {
// log the exception and proceed
util.logrepeatedmessage(e.getkey(), e);
}
}

}
size = this.visiblemethods.size();
if (size > 0) {
next : for (int i = 0; i < size; i++) {
try {
methodbinding binding = (methodbinding) this.visiblemethods.elementat(i);
if (assignabletypebinding != null && !binding.returntype.iscompatiblewith(assignabletypebinding)) continue next;
if (this.assistscope.isdefinedinsameunit(binding.declaringclass)) {
javaelement method = getjavaelementofcompilationunit(binding);
if (method != null) result[elementcount++] = method;
} else {
javaelement method = util.getunresolvedjavaelement(binding, this.owner, emptynodemap);
if (method != null) result[elementcount++] = method.resolved(binding);
}
} catch(abortcompilation e) {
// log the exception and proceed
util.logrepeatedmessage(e.getkey(), e);
}
}
}

if (elementcount != result.length) {
system.arraycopy(result, 0, result = new ijavaelement[elementcount], 0, elementcount);
}

return result;
}

private void searchvisiblefields(
fieldbinding[] fields,
referencebinding receivertype,
scope scope,
invocationsite invocationsite,
scope invocationscope,
boolean onlystaticfields,
objectvector localsfound,
objectvector fieldsfound) {
objectvector newfieldsfound = new objectvector();
// inherited fields which are hidden by subclasses are filtered out
// no visibility checks can be performed without the scope & invocationsite

next : for (int f = fields.length; --f >= 0;) {
fieldbinding field = fields[f];

if (field.issynthetic()) continue next;

if (onlystaticfields && !field.isstatic()) continue next;

if (!field.canbeseenby(receivertype, invocationsite, scope)) continue next;

for (int i = fieldsfound.size; --i >= 0;) {
fieldbinding otherfield = (fieldbinding) fieldsfound.elementat(i);
if (charoperation.equals(field.name, otherfield.name, true)) {
continue next;
}
}

for (int l = localsfound.size; --l >= 0;) {
localvariablebinding local = (localvariablebinding) localsfound.elementat(l);

if (charoperation.equals(field.name, local.name, true)) {
continue next;
}
}

newfieldsfound.add(field);
}

fieldsfound.addall(newfieldsfound);
}

private void searchvisiblefields(
referencebinding receivertype,
scope scope,
invocationsite invocationsite,
scope invocationscope,
boolean onlystaticfields,
boolean notinjavadoc,
objectvector localsfound,
objectvector fieldsfound) {

referencebinding currenttype = receivertype;
referencebinding[] interfacestovisit = null;
int nextposition = 0;
do {
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (notinjavadoc && itsinterfaces != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}

fieldbinding[] fields = currenttype.availablefields();
if(fields != null && fields.length > 0) {

searchvisiblefields(
fields,
receivertype,
scope,
invocationsite,
invocationscope,
onlystaticfields,
localsfound,
fieldsfound);
}
currenttype = currenttype.superclass();
} while (notinjavadoc && currenttype != null);

if (notinjavadoc && interfacestovisit != null) {
for (int i = 0; i < nextposition; i++) {
referencebinding aninterface = interfacestovisit[i];
fieldbinding[] fields = aninterface.availablefields();
if(fields !=  null) {
searchvisiblefields(
fields,
receivertype,
scope,
invocationsite,
invocationscope,
onlystaticfields,
localsfound,
fieldsfound);
}

referencebinding[] itsinterfaces = aninterface.superinterfaces();
if (itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
}

private void searchvisibleinterfacemethods(
referencebinding[] itsinterfaces,
referencebinding receivertype,
scope scope,
invocationsite invocationsite,
scope invocationscope,
boolean onlystaticmethods,
objectvector methodsfound) {
if (itsinterfaces != binding.no_superinterfaces) {
referencebinding[] interfacestovisit = itsinterfaces;
int nextposition = interfacestovisit.length;

for (int i = 0; i < nextposition; i++) {
referencebinding currenttype = interfacestovisit[i];
methodbinding[] methods = currenttype.availablemethods();
if(methods != null) {
searchvisiblelocalmethods(
methods,
receivertype,
scope,
invocationsite,
invocationscope,
onlystaticmethods,
methodsfound);
}

itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
}

private void searchvisiblelocalmethods(
methodbinding[] methods,
referencebinding receivertype,
scope scope,
invocationsite invocationsite,
scope invocationscope,
boolean onlystaticmethods,
objectvector methodsfound) {
objectvector newmethodsfound =  new objectvector();
// inherited methods which are hidden by subclasses are filtered out
// no visibility checks can be performed without the scope & invocationsite

next : for (int f = methods.length; --f >= 0;) {
methodbinding method = methods[f];

if (method.issynthetic()) continue next;

if (method.isdefaultabstract())	continue next;

if (method.isconstructor()) continue next;

if (onlystaticmethods && !method.isstatic()) continue next;

if (!method.canbeseenby(receivertype, invocationsite, scope)) continue next;

for (int i = methodsfound.size; --i >= 0;) {
methodbinding othermethod = (methodbinding) methodsfound.elementat(i);
if (method == othermethod)
continue next;

if (charoperation.equals(method.selector, othermethod.selector, true)) {
if (this.lookupenvironment.methodverifier().ismethodsubsignature(othermethod, method)) {
continue next;
}
}
}

newmethodsfound.add(method);
}

methodsfound.addall(newmethodsfound);
}

private void searchvisiblemethods(
referencebinding receivertype,
scope scope,
invocationsite invocationsite,
scope invocationscope,
boolean onlystaticmethods,
boolean notinjavadoc,
objectvector methodsfound) {
referencebinding currenttype = receivertype;
if (notinjavadoc) {
if (receivertype.isinterface()) {
searchvisibleinterfacemethods(
new referencebinding[]{currenttype},
receivertype,
scope,
invocationsite,
invocationscope,
onlystaticmethods,
methodsfound);

currenttype = scope.getjavalangobject();
}
}
boolean haspotentialdefaultabstractmethods = true;
while (currenttype != null) {

methodbinding[] methods = currenttype.availablemethods();
if (methods != null) {
searchvisiblelocalmethods(
methods,
receivertype,
scope,
invocationsite,
invocationscope,
onlystaticmethods,
methodsfound);
}

if (notinjavadoc &&
haspotentialdefaultabstractmethods &&
(currenttype.isabstract() ||
currenttype.istypevariable() ||
currenttype.isintersectiontype() ||
currenttype.isenum())){

referencebinding[] superinterfaces = currenttype.superinterfaces();
if (superinterfaces != null && currenttype.isintersectiontype()) {
for (int i = 0; i < superinterfaces.length; i++) {
superinterfaces[i] = (referencebinding)superinterfaces[i].capture(invocationscope, invocationsite.sourceend());
}
}

searchvisibleinterfacemethods(
superinterfaces,
receivertype,
scope,
invocationsite,
invocationscope,
onlystaticmethods,
methodsfound);
} else {
haspotentialdefaultabstractmethods = false;
}
if(currenttype.isparameterizedtype()) {
currenttype = ((parameterizedtypebinding)currenttype).generictype().superclass();
} else {
currenttype = currenttype.superclass();
}
}
}
private void searchvisiblevariablesandmethods(
scope scope,
objectvector localsfound,
objectvector fieldsfound,
objectvector methodsfound,
boolean notinjavadoc) {

invocationsite invocationsite = completionengine.fakeinvocationsite;

boolean staticsonly = false;
// need to know if we're in a static context (or inside a constructor)

scope currentscope = scope;

done1 : while (true) { // done when a compilation_unit_scope is found

switch (currentscope.kind) {

case scope.method_scope :
// handle the error case inside an explicit constructor call (see methodscope>>findfield)
methodscope methodscope = (methodscope) currentscope;
staticsonly |= methodscope.isstatic | methodscope.isconstructorcall;
//$fall-through$
case scope.block_scope :
blockscope blockscope = (blockscope) currentscope;

next : for (int i = 0, length = blockscope.locals.length; i < length; i++) {
localvariablebinding local = blockscope.locals[i];

if (local == null)
break next;

if (local.issecret())
continue next;
// if the local variable declaration's initialization statement itself has the completion,
// then don't propose the local variable
if (local.declaration.initialization != null) {
if(local.declaration.initialization.sourceend > 0) {
if (this.assistnode.sourceend <= local.declaration.initialization.sourceend
&& this.assistnode.sourcestart >= local.declaration.initialization.sourcestart) {
continue next;
}
} else {
completionnodedetector detector = new completionnodedetector(
this.assistnode,
local.declaration.initialization);
if (detector.containscompletionnode()) {
continue next;
}
}
}
for (int f = 0; f < localsfound.size; f++) {
localvariablebinding otherlocal =
(localvariablebinding) localsfound.elementat(f);
if (charoperation.equals(otherlocal.name, local.name, true))
continue next;
}

localsfound.add(local);
}
break;

case scope.compilation_unit_scope :
break done1;
}
currentscope = currentscope.parent;
}

staticsonly = false;
currentscope = scope;

done2 : while (true) { // done when a compilation_unit_scope is found

switch (currentscope.kind) {
case scope.method_scope :
// handle the error case inside an explicit constructor call (see methodscope>>findfield)
methodscope methodscope = (methodscope) currentscope;
staticsonly |= methodscope.isstatic | methodscope.isconstructorcall;
break;
case scope.class_scope :
classscope classscope = (classscope) currentscope;
sourcetypebinding enclosingtype = classscope.referencecontext.binding;

searchvisiblefields(
enclosingtype,
classscope,
invocationsite,
scope,
staticsonly,
notinjavadoc,
localsfound,
fieldsfound);

searchvisiblemethods(
enclosingtype,
classscope,
invocationsite,
scope,
staticsonly,
notinjavadoc,
methodsfound);

staticsonly |= enclosingtype.isstatic();
break;

case scope.compilation_unit_scope :
break done2;
}
currentscope = currentscope.parent;
}

// search in static import
importbinding[] importbindings = scope.compilationunitscope().imports;
for (int i = 0; i < importbindings.length; i++) {
importbinding importbinding = importbindings[i];
if(importbinding.isvalidbinding() && importbinding.isstatic()) {
binding binding = importbinding.resolvedimport;
if(binding != null && binding.isvalidbinding()) {
if(importbinding.ondemand) {
if((binding.kind() & binding.type) != 0) {
searchvisiblefields(
(referencebinding)binding,
scope,
invocationsite,
scope,
staticsonly,
notinjavadoc,
localsfound,
fieldsfound);

searchvisiblemethods(
(referencebinding)binding,
scope,
invocationsite,
scope,
staticsonly,
notinjavadoc,
methodsfound);
}
} else {
if ((binding.kind() & binding.field) != 0) {
searchvisiblefields(
new fieldbinding[]{(fieldbinding)binding},
((fieldbinding)binding).declaringclass,
scope,
invocationsite,
scope,
staticsonly,
localsfound,
fieldsfound);
} else if ((binding.kind() & binding.method) != 0) {
methodbinding methodbinding = (methodbinding)binding;

searchvisiblelocalmethods(
methodbinding.declaringclass.getmethods(methodbinding.selector),
methodbinding.declaringclass,
scope,
invocationsite,
scope,
true,
methodsfound);
}
}
}
}
}
}
}
