/*******************************************************************************
* copyright (c) 2005, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

import java.util.arrays;

import org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding;

public class classfilepool {
public static final int pool_size = 25; // need to have enough for 2 units
classfile[] classfiles;

private classfilepool() {
// prevent instantiation
this.classfiles = new classfile[pool_size];
}

public static classfilepool newinstance() {
return new classfilepool();
}

public synchronized classfile acquire(sourcetypebinding typebinding) {
for (int i = 0; i < pool_size; i++) {
classfile classfile = this.classfiles[i];
if (classfile == null) {
classfile newclassfile = new classfile(typebinding);
this.classfiles[i] = newclassfile;
newclassfile.isshared = true;
return newclassfile;
}
if (!classfile.isshared) {
classfile.reset(typebinding);
classfile.isshared = true;
return classfile;
}
}
return new classfile(typebinding);
}
public synchronized void release(classfile classfile) {
classfile.isshared = false;
}
public void reset() {
arrays.fill(this.classfiles, null);
}
}
