/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class importreference extends astnode {

public char[][] tokens;
public long[] sourcepositions; //each entry is using the code : (start<<32) + end
public int declarationend; // doesn't include an potential trailing comment
public int declarationsourcestart;
public int declarationsourceend;
public int modifiers; // 1.5 addition for static imports
public annotation[] annotations;

public importreference(
char[][] tokens,
long[] sourcepositions,
boolean ondemand,
int modifiers) {

this.tokens = tokens;
this.sourcepositions = sourcepositions;
if (ondemand) {
this.bits |= astnode.ondemand;
}
this.sourceend = (int) (sourcepositions[sourcepositions.length-1] & 0x00000000ffffffff);
this.sourcestart = (int) (sourcepositions[0] >>> 32);
this.modifiers = modifiers;
}

public boolean isstatic() {
return (this.modifiers & classfileconstants.accstatic) != 0;
}

/**
* @@return char[][]
*/
public char[][] getimportname() {

return this.tokens;
}

public stringbuffer print(int indent, stringbuffer output) {

return print(indent, output, true);
}

public stringbuffer print(int tab, stringbuffer output, boolean withondemand) {

/* when withondemand is false, only the name is printed */
for (int i = 0; i < this.tokens.length; i++) {
if (i > 0) output.append('.');
output.append(this.tokens[i]);
}
if (withondemand && ((this.bits & astnode.ondemand) != 0)) {
output.append(".*"); //$non-nls-1$
}
return output;
}

public void traverse(astvisitor visitor, compilationunitscope scope) {
// annotations are traversed during the compilation unit traversal using a class scope
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
