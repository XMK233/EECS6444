/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

public class problemfieldbinding extends fieldbinding {
private int problemid;
public fieldbinding closestmatch;

// note: must only answer the subset of the name related to the problem

public problemfieldbinding(referencebinding declaringclass, char[] name, int problemid) {
this(null, declaringclass, name, problemid);
}
public problemfieldbinding(fieldbinding closestmatch, referencebinding declaringclass, char[] name, int problemid) {
this.closestmatch = closestmatch;
this.declaringclass = declaringclass;
this.name = name;
this.problemid = problemid;
}
/* api
* answer the problem id associated with the receiver.
* noerror if the receiver is a valid binding.
*/

public final int problemid() {
return this.problemid;
}
}
