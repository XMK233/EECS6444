/*******************************************************************************
* copyright (c) 2005, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.util.list;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.ast.wildcard;

/**
* a parameterized type encapsulates a type with type arguments,
*/
public class parameterizedtypebinding extends referencebinding implements substitution {

private referencebinding type; // must ensure the type is resolved
public typebinding[] arguments;
public lookupenvironment environment;
public char[] generictypesignature;
public referencebinding superclass;
public referencebinding[] superinterfaces;
public fieldbinding[] fields;
public referencebinding[] membertypes;
public methodbinding[] methods;
private referencebinding enclosingtype;

public parameterizedtypebinding(referencebinding type, typebinding[] arguments,  referencebinding enclosingtype, lookupenvironment environment){
this.environment = environment;
this.enclosingtype = enclosingtype; // never unresolved, never lazy per construction
//		if (enclosingtype != null && enclosingtype.isgenerictype()) {
//			runtimeexception e = new runtimeexception("param type with generic enclosing");
//			e.printstacktrace();
//			throw e;
//		}
//		if (!(type instanceof unresolvedreferencebinding) && type.typevariables() == binding.no_type_variables) {
//			system.out.println();
//		}
initialize(type, arguments);
if (type instanceof unresolvedreferencebinding)
((unresolvedreferencebinding) type).addwrapper(this, environment);
if (arguments != null) {
for (int i = 0, l = arguments.length; i < l; i++)
if (arguments[i] instanceof unresolvedreferencebinding)
((unresolvedreferencebinding) arguments[i]).addwrapper(this, environment);
}
this.tagbits |=  tagbits.hasunresolvedtypevariables; // cleared in resolve()
}

/**
* may return an unresolvedreferencebinding.
* @@see parameterizedtypebinding#generictype()
*/
protected referencebinding actualtype() {
return this.type;
}

/**
* iterate type arguments, and validate them according to corresponding variable bounds.
*/
public void boundcheck(scope scope, typereference[] argumentreferences) {
if ((this.tagbits & tagbits.passedboundcheck) == 0) {
boolean haserrors = false;
typevariablebinding[] typevariables = this.type.typevariables();
if (this.arguments != null && typevariables != null) { // arguments may be null in error cases
for (int i = 0, length = typevariables.length; i < length; i++) {
if (typevariables[i].boundcheck(this, this.arguments[i])  != typeconstants.ok) {
haserrors = true;
if ((this.arguments[i].tagbits & tagbits.hasmissingtype) == 0) {
// do not report secondary error, if type reference already got complained against
scope.problemreporter().typemismatcherror(this.arguments[i], typevariables[i], this.type, argumentreferences[i]);
}
}
}
}
if (!haserrors) this.tagbits |= tagbits.passedboundcheck; // no need to recheck it in the future
}
}
/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#canbeinstantiated()
*/
public boolean canbeinstantiated() {
return ((this.tagbits & tagbits.hasdirectwildcard) == 0) && super.canbeinstantiated(); // cannot instantiate param type with wildcard arguments
}
/**
* perform capture conversion for a parameterized type with wildcard arguments
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#capture(scope,int)
*/
public typebinding capture(scope scope, int position) {
if ((this.tagbits & tagbits.hasdirectwildcard) == 0)
return this;

typebinding[] originalarguments = this.arguments;
int length = originalarguments.length;
typebinding[] capturedarguments = new typebinding[length];

// retrieve the type context for capture bindingkey
referencebinding contexttype = scope.enclosingsourcetype();
if (contexttype != null) contexttype = contexttype.outermostenclosingtype(); // maybe null when used programmatically by dom

for (int i = 0; i < length; i++) {
typebinding argument = originalarguments[i];
if (argument.kind() == binding.wildcard_type) { // no capture for intersection types
capturedarguments[i] = new capturebinding((wildcardbinding) argument, contexttype, position, scope.compilationunitscope().nextcaptureid());
} else {
capturedarguments[i] = argument;
}
}
parameterizedtypebinding capturedparameterizedtype = this.environment.createparameterizedtype(this.type, capturedarguments, enclosingtype());
for (int i = 0; i < length; i++) {
typebinding argument = capturedarguments[i];
if (argument.iscapture()) {
((capturebinding)argument).initializebounds(scope, capturedparameterizedtype);
}
}
return capturedparameterizedtype;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#collectmissingtypes(java.util.list)
*/
public list collectmissingtypes(list missingtypes) {
if ((this.tagbits & tagbits.hasmissingtype) != 0) {
if (this.enclosingtype != null) {
missingtypes = this.enclosingtype.collectmissingtypes(missingtypes);
}
missingtypes = generictype().collectmissingtypes(missingtypes);
if (this.arguments != null) {
for (int i = 0, max = this.arguments.length; i < max; i++) {
missingtypes = this.arguments[i].collectmissingtypes(missingtypes);
}
}
}
return missingtypes;
}

/**
* collect the substitutes into a map for certain type variables inside the receiver type
* e.g.   collection<t>.collectsubstitutes(collection<list<x>>, map), will populate map with: t --> list<x>
* constraints:
*   a << f   corresponds to:   f.collectsubstitutes(..., a, ..., constraint_extends (1))
*   a = f   corresponds to:      f.collectsubstitutes(..., a, ..., constraint_equal (0))
*   a >> f   corresponds to:   f.collectsubstitutes(..., a, ..., constraint_super (2))
*/
public void collectsubstitutes(scope scope, typebinding actualtype, inferencecontext inferencecontext, int constraint) {
if ((this.tagbits & tagbits.hastypevariable) == 0) {
typebinding actualequivalent = actualtype.findsupertypeoriginatingfrom(this.type);
if (actualequivalent != null && actualequivalent.israwtype()) {
inferencecontext.isunchecked = true;
}
return;
}
if (actualtype == typebinding.null) return;

if (!(actualtype instanceof referencebinding)) return;
typebinding formalequivalent, actualequivalent;
switch (constraint) {
case typeconstants.constraint_equal :
case typeconstants.constraint_extends :
formalequivalent = this;
actualequivalent = actualtype.findsupertypeoriginatingfrom(this.type);
if (actualequivalent == null) return;
break;
case typeconstants.constraint_super :
default:
formalequivalent = this.findsupertypeoriginatingfrom(actualtype);
if (formalequivalent == null) return;
actualequivalent = actualtype;
break;
}
// collect through enclosing type
referencebinding formalenclosingtype = formalequivalent.enclosingtype();
if (formalenclosingtype != null) {
formalenclosingtype.collectsubstitutes(scope, actualequivalent.enclosingtype(), inferencecontext, constraint);
}
// collect through type arguments
if (this.arguments == null) return;
typebinding[] formalarguments;
switch (formalequivalent.kind()) {
case binding.generic_type :
formalarguments = formalequivalent.typevariables();
break;
case binding.parameterized_type :
formalarguments = ((parameterizedtypebinding)formalequivalent).arguments;
break;
case binding.raw_type :
if (inferencecontext.depth > 0) {
inferencecontext.status = inferencecontext.failed; // marker for impossible inference
}
return;
default :
return;
}
typebinding[] actualarguments;
switch (actualequivalent.kind()) {
case binding.generic_type :
actualarguments = actualequivalent.typevariables();
break;
case binding.parameterized_type :
actualarguments = ((parameterizedtypebinding)actualequivalent).arguments;
break;
case binding.raw_type :
if (inferencecontext.depth > 0) {
inferencecontext.status = inferencecontext.failed; // marker for impossible inference
} else {
inferencecontext.isunchecked = true;
}
return;
default :
return;
}
inferencecontext.depth++;
for (int i = 0, length = formalarguments.length; i < length; i++) {
typebinding formalargument = formalarguments[i];
typebinding actualargument = actualarguments[i];
if (formalargument.iswildcard()) {
formalargument.collectsubstitutes(scope, actualargument, inferencecontext, constraint);
continue;
} else if (actualargument.iswildcard()){
wildcardbinding actualwildcardargument = (wildcardbinding) actualargument;
if (actualwildcardargument.otherbounds == null) {
if (constraint == typeconstants.constraint_super) { // jls 15.12.7, p.459
switch(actualwildcardargument.boundkind) {
case wildcard.extends :
formalargument.collectsubstitutes(scope, actualwildcardargument.bound, inferencecontext, typeconstants.constraint_super);
continue;
case wildcard.super :
formalargument.collectsubstitutes(scope, actualwildcardargument.bound, inferencecontext, typeconstants.constraint_extends);
continue;
default :
continue; // cannot infer anything further from unbound wildcard
}
} else {
continue; // cannot infer anything further from wildcard
}
}
}
// by default, use equal constraint
formalargument.collectsubstitutes(scope, actualargument, inferencecontext, typeconstants.constraint_equal);
}
inferencecontext.depth--;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#computeid()
*/
public void computeid() {
this.id = typeids.noid;
}

public char[] computeuniquekey(boolean isleaf) {
stringbuffer sig = new stringbuffer(10);
referencebinding enclosing;
if (ismembertype() && ((enclosing = enclosingtype()).isparameterizedtype() || enclosing.israwtype())) {
char[] typesig = enclosing.computeuniquekey(false/*not a leaf*/);
sig.append(typesig, 0, typesig.length-1); // copy all but trailing semicolon
sig.append('.').append(sourcename());
} else if(this.type.islocaltype()){
localtypebinding localtypebinding = (localtypebinding) this.type;
enclosing = localtypebinding.enclosingtype();
referencebinding temp;
while ((temp = enclosing.enclosingtype()) != null)
enclosing = temp;
char[] typesig = enclosing.computeuniquekey(false/*not a leaf*/);
sig.append(typesig, 0, typesig.length-1); // copy all but trailing semicolon
sig.append('$');
sig.append(localtypebinding.sourcestart);
} else {
char[] typesig = this.type.computeuniquekey(false/*not a leaf*/);
sig.append(typesig, 0, typesig.length-1); // copy all but trailing semicolon
}
referencebinding capturesourcetype = null;
if (this.arguments != null) {
sig.append('<');
for (int i = 0, length = this.arguments.length; i < length; i++) {
typebinding typebinding = this.arguments[i];
sig.append(typebinding.computeuniquekey(false/*not a leaf*/));
if (typebinding instanceof capturebinding)
capturesourcetype = ((capturebinding) typebinding).sourcetype;
}
sig.append('>');
}
sig.append(';');
if (capturesourcetype != null && capturesourcetype != this.type) {
// contains a capture binding
sig.insert(0, "&"); //$non-nls-1$
sig.insert(0, capturesourcetype.computeuniquekey(false/*not a leaf*/));
}

int siglength = sig.length();
char[] uniquekey = new char[siglength];
sig.getchars(0, siglength, uniquekey, 0);
return uniquekey;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#constantpoolname()
*/
public char[] constantpoolname() {
return this.type.constantpoolname(); // erasure
}

public parameterizedmethodbinding createparameterizedmethod(methodbinding originalmethod) {
return new parameterizedmethodbinding(this, originalmethod);
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#debugname()
*/
public string debugname() {
stringbuffer namebuffer = new stringbuffer(10);
if (this.type instanceof unresolvedreferencebinding) {
namebuffer.append(this.type);
} else {
namebuffer.append(this.type.sourcename());
}
if (this.arguments != null) {
namebuffer.append('<');
for (int i = 0, length = this.arguments.length; i < length; i++) {
if (i > 0) namebuffer.append(',');
namebuffer.append(this.arguments[i].debugname());
}
namebuffer.append('>');
}
return namebuffer.tostring();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#enclosingtype()
*/
public referencebinding enclosingtype() {
return this.enclosingtype;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.substitution#environment()
*/
public lookupenvironment environment() {
return this.environment;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#erasure()
*/
public typebinding erasure() {
return this.type.erasure(); // erasure
}
/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#fieldcount()
*/
public int fieldcount() {
return this.type.fieldcount(); // same as erasure (lazy)
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#fields()
*/
public fieldbinding[] fields() {
if ((this.tagbits & tagbits.arefieldscomplete) != 0)
return this.fields;

try {
fieldbinding[] originalfields = this.type.fields();
int length = originalfields.length;
fieldbinding[] parameterizedfields = new fieldbinding[length];
for (int i = 0; i < length; i++)
// substitute all fields, so as to get updated declaring class at least
parameterizedfields[i] = new parameterizedfieldbinding(this, originalfields[i]);
this.fields = parameterizedfields;
} finally {
// if the original fields cannot be retrieved (ex. abortcompilation), then assume we do not have any fields
if (this.fields == null)
this.fields = binding.no_fields;
this.tagbits |= tagbits.arefieldscomplete;
}
return this.fields;
}

/**
* return the original generic type from which the parameterized type got instantiated from.
* this will perform lazy resolution automatically if needed.
* @@see parameterizedtypebinding#actualtype() if no resolution is required (unlikely)
*/
public referencebinding generictype() {
if (this.type instanceof unresolvedreferencebinding)
((unresolvedreferencebinding) this.type).resolve(this.environment, false);
return this.type;
}

/**
* ltype<param1 ... paramn>;
* ly<tt;>;
*/
public char[] generictypesignature() {
if (this.generictypesignature == null) {
if ((this.modifiers & extracompilermodifiers.accgenericsignature) == 0) {
this.generictypesignature = this.type.signature();
} else {
stringbuffer sig = new stringbuffer(10);
if (ismembertype()) {
referencebinding enclosing = enclosingtype();
char[] typesig = enclosing.generictypesignature();
sig.append(typesig, 0, typesig.length-1);// copy all but trailing semicolon
if ((enclosing.modifiers & extracompilermodifiers.accgenericsignature) != 0) {
sig.append('.');
} else {
sig.append('$');
}
sig.append(sourcename());
} else {
char[] typesig = this.type.signature();
sig.append(typesig, 0, typesig.length-1);// copy all but trailing semicolon
}
if (this.arguments != null) {
sig.append('<');
for (int i = 0, length = this.arguments.length; i < length; i++) {
sig.append(this.arguments[i].generictypesignature());
}
sig.append('>');
}
sig.append(';');
int siglength = sig.length();
this.generictypesignature = new char[siglength];
sig.getchars(0, siglength, this.generictypesignature, 0);
}
}
return this.generictypesignature;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#getannotationtagbits()
*/
public long getannotationtagbits() {
return this.type.getannotationtagbits();
}

public int getenclosinginstancesslotsize() {
return generictype().getenclosinginstancesslotsize();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#getexactconstructor(typebinding[])
*/
public methodbinding getexactconstructor(typebinding[] argumenttypes) {
int argcount = argumenttypes.length;
methodbinding match = null;

if ((this.tagbits & tagbits.aremethodscomplete) != 0) { // have resolved all arg types & return type of the methods
long range;
if ((range = referencebinding.binarysearch(typeconstants.init, this.methods)) >= 0) {
nextmethod: for (int imethod = (int)range, end = (int)(range >> 32); imethod <= end; imethod++) {
methodbinding method = this.methods[imethod];
if (method.parameters.length == argcount) {
typebinding[] tomatch = method.parameters;
for (int iarg = 0; iarg < argcount; iarg++)
if (tomatch[iarg] != argumenttypes[iarg])
continue nextmethod;
if (match != null) return null; // collision case
match = method;
}
}
}
} else {
methodbinding[] matchingmethods = getmethods(typeconstants.init); // takes care of duplicates & default abstract methods
nextmethod : for (int m = matchingmethods.length; --m >= 0;) {
methodbinding method = matchingmethods[m];
typebinding[] tomatch = method.parameters;
if (tomatch.length == argcount) {
for (int p = 0; p < argcount; p++)
if (tomatch[p] != argumenttypes[p])
continue nextmethod;
if (match != null) return null; // collision case
match = method;
}
}
}
return match;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#getexactmethod(char[], typebinding[],compilationunitscope)
*/
public methodbinding getexactmethod(char[] selector, typebinding[] argumenttypes, compilationunitscope refscope) {
// sender from refscope calls recordtypereference(this)
int argcount = argumenttypes.length;
boolean foundnothing = true;
methodbinding match = null;

if ((this.tagbits & tagbits.aremethodscomplete) != 0) { // have resolved all arg types & return type of the methods
long range;
if ((range = referencebinding.binarysearch(selector, this.methods)) >= 0) {
nextmethod: for (int imethod = (int)range, end = (int)(range >> 32); imethod <= end; imethod++) {
methodbinding method = this.methods[imethod];
foundnothing = false; // inner type lookups must know that a method with this name exists
if (method.parameters.length == argcount) {
typebinding[] tomatch = method.parameters;
for (int iarg = 0; iarg < argcount; iarg++)
if (tomatch[iarg] != argumenttypes[iarg])
continue nextmethod;
if (match != null) return null; // collision case
match = method;
}
}
}
} else {
methodbinding[] matchingmethods = getmethods(selector); // takes care of duplicates & default abstract methods
foundnothing = matchingmethods == binding.no_methods;
nextmethod : for (int m = matchingmethods.length; --m >= 0;) {
methodbinding method = matchingmethods[m];
typebinding[] tomatch = method.parameters;
if (tomatch.length == argcount) {
for (int p = 0; p < argcount; p++)
if (tomatch[p] != argumenttypes[p])
continue nextmethod;
if (match != null) return null; // collision case
match = method;
}
}
}
if (match != null) {
// cannot be picked up as an exact match if its a possible anonymous case, such as:
// class a<t extends number> { public void id(t t) {} }
// class b<tt> extends a<integer> { public <zz> void id(integer i) {} }
if (match.hassubstitutedparameters()) return null;
return match;
}

if (foundnothing && (this.arguments == null || this.arguments.length <= 1)) {
if (isinterface()) {
if (superinterfaces().length == 1) {
if (refscope != null)
refscope.recordtypereference(this.superinterfaces[0]);
return this.superinterfaces[0].getexactmethod(selector, argumenttypes, refscope);
}
} else if (superclass() != null) {
if (refscope != null)
refscope.recordtypereference(this.superclass);
return this.superclass.getexactmethod(selector, argumenttypes, refscope);
}
}
return null;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#getfield(char[], boolean)
*/
public fieldbinding getfield(char[] fieldname, boolean needresolve) {
fields(); // ensure fields have been initialized... must create all at once unlike methods
return referencebinding.binarysearch(fieldname, this.fields);
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#getmembertype(char[])
*/
public referencebinding getmembertype(char[] typename) {
membertypes(); // ensure membertypes have been initialized... must create all at once unlike methods
int typelength = typename.length;
for (int i = this.membertypes.length; --i >= 0;) {
referencebinding membertype = this.membertypes[i];
if (membertype.sourcename.length == typelength && charoperation.equals(membertype.sourcename, typename))
return membertype;
}
return null;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#getmethods(char[])
*/
public methodbinding[] getmethods(char[] selector) {
if (this.methods != null) {
long range;
if ((range = referencebinding.binarysearch(selector, this.methods)) >= 0) {
int start = (int) range;
int length = (int) (range >> 32) - start + 1;
// cannot optimize since some clients rely on clone array
// if (start == 0 && length == this.methods.length)
//	return this.methods; // current set is already interesting subset
methodbinding[] result;
system.arraycopy(this.methods, start, result = new methodbinding[length], 0, length);
return result;
}
}
if ((this.tagbits & tagbits.aremethodscomplete) != 0)
return binding.no_methods; // have created all the methods and there are no matches

methodbinding[] parameterizedmethods = null;
try {
methodbinding[] originalmethods = this.type.getmethods(selector);
int length = originalmethods.length;
if (length == 0) return binding.no_methods;

parameterizedmethods = new methodbinding[length];
for (int i = 0; i < length; i++)
// substitute methods, so as to get updated declaring class at least
parameterizedmethods[i] = createparameterizedmethod(originalmethods[i]);
if (this.methods == null) {
methodbinding[] temp = new methodbinding[length];
system.arraycopy(parameterizedmethods, 0, temp, 0, length);
this.methods = temp; // must be a copy of parameterizedmethods since it will be returned below
} else {
int total = length + this.methods.length;
methodbinding[] temp = new methodbinding[total];
system.arraycopy(parameterizedmethods, 0, temp, 0, length);
system.arraycopy(this.methods, 0, temp, length, this.methods.length);
if (total > 1)
referencebinding.sortmethods(temp, 0, total); // resort to ensure order is good
this.methods = temp;
}
return parameterizedmethods;
} finally {
// if the original methods cannot be retrieved (ex. abortcompilation), then assume we do not have any methods
if (parameterizedmethods == null)
this.methods = parameterizedmethods = binding.no_methods;
}
}

public int getouterlocalvariablesslotsize() {
return generictype().getouterlocalvariablesslotsize();
}

public boolean hasmembertypes() {
return this.type.hasmembertypes();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#implementsmethod(methodbinding)
*/
public boolean implementsmethod(methodbinding method) {
return this.type.implementsmethod(method); // erasure
}

void initialize(referencebinding sometype, typebinding[] somearguments) {
this.type = sometype;
this.sourcename = sometype.sourcename;
this.compoundname = sometype.compoundname;
this.fpackage = sometype.fpackage;
this.filename = sometype.filename;
// should not be set yet
// this.superclass = null;
// this.superinterfaces = null;
// this.fields = null;
// this.methods = null;
this.modifiers = sometype.modifiers & ~extracompilermodifiers.accgenericsignature; // discard generic signature, will compute later
// only set accgenericsignature if parameterized or have enclosing type required signature
if (somearguments != null) {
this.modifiers |= extracompilermodifiers.accgenericsignature;
} else if (this.enclosingtype != null) {
this.modifiers |= (this.enclosingtype.modifiers & extracompilermodifiers.accgenericsignature);
this.tagbits |= this.enclosingtype.tagbits & (tagbits.hastypevariable | tagbits.hasmissingtype);
}
if (somearguments != null) {
this.arguments = somearguments;
for (int i = 0, length = somearguments.length; i < length; i++) {
typebinding someargument = somearguments[i];
switch (someargument.kind()) {
case binding.wildcard_type :
this.tagbits |= tagbits.hasdirectwildcard;
if (((wildcardbinding) someargument).boundkind != wildcard.unbound) {
this.tagbits |= tagbits.isboundparameterizedtype;
}
break;
case binding.intersection_type :
this.tagbits |= tagbits.hasdirectwildcard;
break;
default :
this.tagbits |= tagbits.isboundparameterizedtype;
break;
}
this.tagbits |= someargument.tagbits & (tagbits.hastypevariable | tagbits.hasmissingtype | tagbits.containsnestedtypereferences);
}
}
this.tagbits |= sometype.tagbits & (tagbits.islocaltype| tagbits.ismembertype | tagbits.isnestedtype | tagbits.hasmissingtype | tagbits.containsnestedtypereferences);
this.tagbits &= ~(tagbits.arefieldscomplete|tagbits.aremethodscomplete);
}

protected void initializearguments() {
// do nothing for true parameterized types (only for raw types)
}

void initializeforstaticimports() {
this.type.initializeforstaticimports();
}

public boolean isequivalentto(typebinding othertype) {
if (this == othertype)
return true;
if (othertype == null)
return false;
switch(othertype.kind()) {

case binding.wildcard_type :
case binding.intersection_type:
return ((wildcardbinding) othertype).boundcheck(this);

case binding.parameterized_type :
parameterizedtypebinding otherparamtype = (parameterizedtypebinding) othertype;
if (this.type != otherparamtype.type)
return false;
if (!isstatic()) { // static member types do not compare their enclosing
referencebinding enclosing = enclosingtype();
if (enclosing != null) {
referencebinding otherenclosing = otherparamtype.enclosingtype();
if (otherenclosing == null) return false;
if ((otherenclosing.tagbits & tagbits.hasdirectwildcard) == 0) {
if (enclosing != otherenclosing) return false;
} else {
if (!enclosing.isequivalentto(otherparamtype.enclosingtype())) return false;
}
}
}
if (this.arguments == null) {
return otherparamtype.arguments == null;
}
int length = this.arguments.length;
typebinding[] otherarguments = otherparamtype.arguments;
if (otherarguments == null || otherarguments.length != length) return false;
for (int i = 0; i < length; i++) {
if (!this.arguments[i].istypeargumentcontainedby(otherarguments[i]))
return false;
}
return true;

case binding.raw_type :
return erasure() == othertype.erasure();
}
return false;
}

public boolean ishierarchyconnected() {
return this.superclass != null && this.superinterfaces != null;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.substitution#israwsubstitution()
*/
public boolean israwsubstitution() {
return israwtype();
}

public int kind() {
return parameterized_type;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#membertypes()
*/
public referencebinding[] membertypes() {
if (this.membertypes == null) {
try {
referencebinding[] originalmembertypes = this.type.membertypes();
int length = originalmembertypes.length;
referencebinding[] parameterizedmembertypes = new referencebinding[length];
// boolean israw = this.israwtype();
for (int i = 0; i < length; i++)
// substitute all member types, so as to get updated enclosing types
parameterizedmembertypes[i] = /*israw && originalmembertypes[i].isgenerictype()
? this.environment.createrawtype(originalmembertypes[i], this)
: */ this.environment.createparameterizedtype(originalmembertypes[i], null, this);
this.membertypes = parameterizedmembertypes;
} finally {
// if the original fields cannot be retrieved (ex. abortcompilation), then assume we do not have any fields
if (this.membertypes == null)
this.membertypes = binding.no_member_types;
}
}
return this.membertypes;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#methods()
*/
public methodbinding[] methods() {
if ((this.tagbits & tagbits.aremethodscomplete) != 0)
return this.methods;

try {
methodbinding[] originalmethods = this.type.methods();
int length = originalmethods.length;
methodbinding[] parameterizedmethods = new methodbinding[length];
for (int i = 0; i < length; i++)
// substitute all methods, so as to get updated declaring class at least
parameterizedmethods[i] = createparameterizedmethod(originalmethods[i]);
this.methods = parameterizedmethods;
} finally {
// if the original methods cannot be retrieved (ex. abortcompilation), then assume we do not have any methods
if (this.methods == null)
this.methods = binding.no_methods;

this.tagbits |=  tagbits.aremethodscomplete;
}
return this.methods;
}
/**
* define to be able to get the computeid() for the inner type binding.
*
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#problemid()
*/
public int problemid() {
return this.type.problemid();
}
/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#qualifiedpackagename()
*/
public char[] qualifiedpackagename() {
return this.type.qualifiedpackagename();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#qualifiedsourcename()
*/
public char[] qualifiedsourcename() {
return this.type.qualifiedsourcename();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#readablename()
*/
public char[] readablename() {
stringbuffer namebuffer = new stringbuffer(10);
if (ismembertype()) {
namebuffer.append(charoperation.concat(enclosingtype().readablename(), this.sourcename, '.'));
} else {
namebuffer.append(charoperation.concatwith(this.type.compoundname, '.'));
}
if (this.arguments != null) {
namebuffer.append('<');
for (int i = 0, length = this.arguments.length; i < length; i++) {
if (i > 0) namebuffer.append(',');
namebuffer.append(this.arguments[i].readablename());
}
namebuffer.append('>');
}
int namelength = namebuffer.length();
char[] readablename = new char[namelength];
namebuffer.getchars(0, namelength, readablename, 0);
return readablename;
}

referencebinding resolve() {
if ((this.tagbits & tagbits.hasunresolvedtypevariables) == 0)
return this;

this.tagbits &= ~tagbits.hasunresolvedtypevariables; // can be recursive so only want to call once
referencebinding resolvedtype = (referencebinding) binarytypebinding.resolvetype(this.type, this.environment, false /* no raw conversion */); // still part of parameterized type ref
this.tagbits |= resolvedtype.tagbits & tagbits.containsnestedtypereferences;
if (this.arguments != null) {
int arglength = this.arguments.length;
for (int i = 0; i < arglength; i++) {
typebinding resolvetype = binarytypebinding.resolvetype(this.arguments[i], this.environment, true /* raw conversion */);
this.arguments[i] = resolvetype;
this.tagbits |= resolvedtype.tagbits & tagbits.containsnestedtypereferences;
}
// arity check
typevariablebinding[] reftypevariables = resolvedtype.typevariables();
if (reftypevariables == binding.no_type_variables) { // check generic
if ((resolvedtype.tagbits & tagbits.hasmissingtype) == 0) {
this.environment.problemreporter.nongenerictypecannotbeparameterized(0, null, resolvedtype, this.arguments);
}
return this;
} else if (arglength != reftypevariables.length) { // check arity
this.environment.problemreporter.incorrectarityforparameterizedtype(null, resolvedtype, this.arguments);
return this; // cannot reach here as abortcompilation is thrown
}
// check argument type compatibility... removed for now since incremental build will propagate change & detect in source
//			for (int i = 0; i < arglength; i++) {
//			    typebinding resolvedargument = this.arguments[i];
//				if (reftypevariables[i].boundcheck(this, resolvedargument) != typeconstants.ok) {
//					this.environment.problemreporter.typemismatcherror(resolvedargument, reftypevariables[i], resolvedtype, null);
//			    }
//			}
}
return this;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#shortreadablename()
*/
public char[] shortreadablename() {
stringbuffer namebuffer = new stringbuffer(10);
if (ismembertype()) {
namebuffer.append(charoperation.concat(enclosingtype().shortreadablename(), this.sourcename, '.'));
} else {
namebuffer.append(this.type.sourcename);
}
if (this.arguments != null) {
namebuffer.append('<');
for (int i = 0, length = this.arguments.length; i < length; i++) {
if (i > 0) namebuffer.append(',');
namebuffer.append(this.arguments[i].shortreadablename());
}
namebuffer.append('>');
}
int namelength = namebuffer.length();
char[] shortreadablename = new char[namelength];
namebuffer.getchars(0, namelength, shortreadablename, 0);
return shortreadablename;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#signature()
*/
public char[] signature() {
if (this.signature == null) {
this.signature = this.type.signature();  // erasure
}
return this.signature;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#sourcename()
*/
public char[] sourcename() {
return this.type.sourcename();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.substitution#substitute(org.eclipse.jdt.internal.compiler.lookup.typevariablebinding)
*/
public typebinding substitute(typevariablebinding originalvariable) {

parameterizedtypebinding currenttype = this;
while (true) {
typevariablebinding[] typevariables = currenttype.type.typevariables();
int length = typevariables.length;
// check this variable can be substituted given parameterized type
if (originalvariable.rank < length && typevariables[originalvariable.rank] == originalvariable) {
// lazy init, since cannot do so during binding creation if during supertype connection
if (currenttype.arguments == null)
currenttype.initializearguments(); // only for raw types
if (currenttype.arguments != null)
return currenttype.arguments[originalvariable.rank];
}
// recurse on enclosing type, as it may hold more substitutions to perform
if (currenttype.isstatic()) break;
referencebinding enclosing = currenttype.enclosingtype();
if (!(enclosing instanceof parameterizedtypebinding))
break;
currenttype = (parameterizedtypebinding) enclosing;
}
return originalvariable;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#superclass()
*/
public referencebinding superclass() {
if (this.superclass == null) {
// note: object cannot be generic
referencebinding genericsuperclass = this.type.superclass();
if (genericsuperclass == null) return null; // e.g. interfaces
this.superclass = (referencebinding) scope.substitute(this, genericsuperclass);
}
return this.superclass;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#superinterfaces()
*/
public referencebinding[] superinterfaces() {
if (this.superinterfaces == null) {
if (this.type.ishierarchybeingconnected())
return binding.no_superinterfaces; // prevent superinterfaces from being assigned before they are connected
this.superinterfaces = scope.substitute(this, this.type.superinterfaces());
}
return this.superinterfaces;
}

public void swapunresolved(unresolvedreferencebinding unresolvedtype, referencebinding resolvedtype, lookupenvironment env) {
boolean update = false;
if (this.type == unresolvedtype) {
this.type = resolvedtype; // cannot be raw since being parameterized below
update = true;
referencebinding enclosing = resolvedtype.enclosingtype();
if (enclosing != null) {
this.enclosingtype = (referencebinding) env.convertunresolvedbinarytorawtype(enclosing); // needed when binding unresolved member type
}
}
if (this.arguments != null) {
for (int i = 0, l = this.arguments.length; i < l; i++) {
if (this.arguments[i] == unresolvedtype) {
this.arguments[i] = env.convertunresolvedbinarytorawtype(resolvedtype);
update = true;
}
}
}
if (update)
initialize(this.type, this.arguments);
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#syntheticenclosinginstancetypes()
*/
public referencebinding[] syntheticenclosinginstancetypes() {
return generictype().syntheticenclosinginstancetypes();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#syntheticouterlocalvariables()
*/
public syntheticargumentbinding[] syntheticouterlocalvariables() {
return generictype().syntheticouterlocalvariables();
}

/**
* @@see java.lang.object#tostring()
*/
public string tostring() {
stringbuffer buffer = new stringbuffer(30);
if (this.type instanceof unresolvedreferencebinding) {
buffer.append(debugname());
} else {
if (isdeprecated()) buffer.append("deprecated "); //$non-nls-1$
if (ispublic()) buffer.append("public "); //$non-nls-1$
if (isprotected()) buffer.append("protected "); //$non-nls-1$
if (isprivate()) buffer.append("private "); //$non-nls-1$
if (isabstract() && isclass()) buffer.append("abstract "); //$non-nls-1$
if (isstatic() && isnestedtype()) buffer.append("static "); //$non-nls-1$
if (isfinal()) buffer.append("final "); //$non-nls-1$

if (isenum()) buffer.append("enum "); //$non-nls-1$
else if (isannotationtype()) buffer.append("@@interface "); //$non-nls-1$
else if (isclass()) buffer.append("class "); //$non-nls-1$
else buffer.append("interface "); //$non-nls-1$
buffer.append(debugname());

buffer.append("\n\textends "); //$non-nls-1$
buffer.append((this.superclass != null) ? this.superclass.debugname() : "null type"); //$non-nls-1$

if (this.superinterfaces != null) {
if (this.superinterfaces != binding.no_superinterfaces) {
buffer.append("\n\timplements : "); //$non-nls-1$
for (int i = 0, length = this.superinterfaces.length; i < length; i++) {
if (i  > 0)
buffer.append(", "); //$non-nls-1$
buffer.append((this.superinterfaces[i] != null) ? this.superinterfaces[i].debugname() : "null type"); //$non-nls-1$
}
}
} else {
buffer.append("null superinterfaces"); //$non-nls-1$
}

if (enclosingtype() != null) {
buffer.append("\n\tenclosing type : "); //$non-nls-1$
buffer.append(enclosingtype().debugname());
}

if (this.fields != null) {
if (this.fields != binding.no_fields) {
buffer.append("\n/*   fields   */"); //$non-nls-1$
for (int i = 0, length = this.fields.length; i < length; i++)
buffer.append('\n').append((this.fields[i] != null) ? this.fields[i].tostring() : "null field"); //$non-nls-1$
}
} else {
buffer.append("null fields"); //$non-nls-1$
}

if (this.methods != null) {
if (this.methods != binding.no_methods) {
buffer.append("\n/*   methods   */"); //$non-nls-1$
for (int i = 0, length = this.methods.length; i < length; i++)
buffer.append('\n').append((this.methods[i] != null) ? this.methods[i].tostring() : "null method"); //$non-nls-1$
}
} else {
buffer.append("null methods"); //$non-nls-1$
}

//		if (membertypes != null) {
//			if (membertypes != nomembertypes) {
//				buffer.append("\n/*   members   */");
//				for (int i = 0, length = membertypes.length; i < length; i++)
//					buffer.append('\n').append((membertypes[i] != null) ? membertypes[i].tostring() : "null type");
//			}
//		} else {
//			buffer.append("null member types");
//		}

buffer.append("\n\n"); //$non-nls-1$
}
return buffer.tostring();

}

public typevariablebinding[] typevariables() {
if (this.arguments == null) {
// retain original type variables if not substituted (member type of parameterized type)
return this.type.typevariables();
}
return binding.no_type_variables;
}
}
