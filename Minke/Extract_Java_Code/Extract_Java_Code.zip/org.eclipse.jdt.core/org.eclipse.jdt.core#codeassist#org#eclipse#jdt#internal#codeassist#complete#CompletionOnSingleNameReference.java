/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce a single name reference containing the completion identifier.
* e.g.
*
*	class x {
*    void foo() {
*      ba[cursor]
*    }
*  }
*
*	---> class x {
*         void foo() {
*           <completeonname:ba>
*         }
*       }
*
* the source range of the completion node denotes the source range
* which should be replaced by the completion.
*/

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class completiononsinglenamereference extends singlenamereference {

public char[][] possiblekeywords;
public boolean canbeexplicitconstructor;
public boolean isinsideannotationattribute;
public boolean isprecededbymodifiers;

public completiononsinglenamereference(char[] source, long pos, boolean isinsideannotationattribute) {
this(source, pos, null, false, isinsideannotationattribute);
}

public completiononsinglenamereference(char[] source, long pos, char[][] possiblekeywords, boolean canbeexplicitconstructor, boolean isinsideannotationattribute) {
super(source, pos);
this.possiblekeywords = possiblekeywords;
this.canbeexplicitconstructor = canbeexplicitconstructor;
this.isinsideannotationattribute = isinsideannotationattribute;
}

public stringbuffer printexpression(int indent, stringbuffer output) {

output.append("<completeonname:"); //$non-nls-1$
return super.printexpression(0, output).append('>');
}

public typebinding resolvetype(blockscope scope) {
if(scope instanceof methodscope) {
throw new completionnodefound(this, scope, ((methodscope)scope).insidetypeannotation);
}
throw new completionnodefound(this, scope);
}
}
