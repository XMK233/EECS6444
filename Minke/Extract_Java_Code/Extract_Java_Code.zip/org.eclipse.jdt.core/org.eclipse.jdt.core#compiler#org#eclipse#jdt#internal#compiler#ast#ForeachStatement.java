/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.branchlabel;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.flow.loopingflowcontext;
import org.eclipse.jdt.internal.compiler.flow.unconditionalflowinfo;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.arraybinding;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.parameterizedtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class foreachstatement extends statement {

public localdeclaration elementvariable;
public int elementvariableimplicitwidening = -1;
public expression collection;
public statement action;

// set the kind of foreach
private int kind;
// possible kinds of iterating behavior
private static final int array = 0;
private static final int raw_iterable = 1;
private static final int generic_iterable = 2;

private typebinding iteratorreceivertype;
private typebinding collectionelementtype;

// loop labels
private branchlabel breaklabel;
private branchlabel continuelabel;

public blockscope scope;

// secret variables for codegen
public localvariablebinding indexvariable;
public localvariablebinding collectionvariable;	// to store the collection expression value
public localvariablebinding maxvariable;
// secret variable names
private static final char[] secretiteratorvariablename = " iterator".tochararray(); //$non-nls-1$
private static final char[] secretindexvariablename = " index".tochararray(); //$non-nls-1$
private static final char[] secretcollectionvariablename = " collection".tochararray(); //$non-nls-1$
private static final char[] secretmaxvariablename = " max".tochararray(); //$non-nls-1$

int postcollectioninitstateindex = -1;
int mergedinitstateindex = -1;

public foreachstatement(
localdeclaration elementvariable,
int start) {

this.elementvariable = elementvariable;
this.sourcestart = start;
this.kind = -1;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
// initialize break and continue labels
this.breaklabel = new branchlabel();
this.continuelabel = new branchlabel();
int initialcomplaintlevel = (flowinfo.reachmode() & flowinfo.unreachable) != 0 ? statement.complained_fake_reachable : statement.not_complained;

// process the element variable and collection
this.collection.checknpe(currentscope, flowcontext, flowinfo);
flowinfo = this.elementvariable.analysecode(this.scope, flowcontext, flowinfo);
flowinfo condinfo = this.collection.analysecode(this.scope, flowcontext, flowinfo.copy());

// element variable will be assigned when iterating
condinfo.markasdefinitelyassigned(this.elementvariable.binding);

this.postcollectioninitstateindex = currentscope.methodscope().recordinitializationstates(condinfo);

// process the action
loopingflowcontext loopingcontext =
new loopingflowcontext(flowcontext, flowinfo, this, this.breaklabel,
this.continuelabel, this.scope);
unconditionalflowinfo actioninfo =
condinfo.nullinfolessunconditionalcopy();
actioninfo.markasdefinitelyunknown(this.elementvariable.binding);
flowinfo exitbranch;
if (!(this.action == null || (this.action.isemptyblock()
&& currentscope.compileroptions().compliancelevel <= classfileconstants.jdk1_3))) {

if (this.action.complainifunreachable(actioninfo, this.scope, initialcomplaintlevel) < statement.complained_unreachable) {
actioninfo = this.action.analysecode(this.scope, loopingcontext, actioninfo).unconditionalcopy();
}

// code generation can be optimized when no need to continue in the loop
exitbranch = flowinfo.unconditionalcopy().
addinitializationsfrom(condinfo.initswhenfalse());
// todo (maxime) no need to test when false: can optimize (same for action being unreachable above)
if ((actioninfo.tagbits & loopingcontext.initsoncontinue.tagbits &
flowinfo.unreachable) != 0) {
this.continuelabel = null;
} else {
actioninfo = actioninfo.mergedwith(loopingcontext.initsoncontinue);
loopingcontext.complainondeferredfinalchecks(this.scope, actioninfo);
exitbranch.addpotentialinitializationsfrom(actioninfo);
}
} else {
exitbranch = condinfo.initswhenfalse();
}

// we need the variable to iterate the collection even if the
// element variable is not used
final boolean hasemptyaction = this.action == null
|| this.action.isemptyblock()
|| ((this.action.bits & isusefulemptystatement) != 0);

switch(this.kind) {
case array :
if (!hasemptyaction
|| this.elementvariable.binding.resolvedposition != -1) {
this.collectionvariable.useflag = localvariablebinding.used;
if (this.continuelabel != null) {
this.indexvariable.useflag = localvariablebinding.used;
this.maxvariable.useflag = localvariablebinding.used;
}
}
break;
case raw_iterable :
case generic_iterable :
this.indexvariable.useflag = localvariablebinding.used;
break;
}
//end of loop
loopingcontext.complainondeferrednullchecks(currentscope, actioninfo);

flowinfo mergedinfo = flowinfo.mergedoptimizedbranches(
(loopingcontext.initsonbreak.tagbits &
flowinfo.unreachable) != 0 ?
loopingcontext.initsonbreak :
flowinfo.addinitializationsfrom(loopingcontext.initsonbreak), // recover upstream null info
false,
exitbranch,
false,
true /*for(;;){}while(true); unreachable(); */);
this.mergedinitstateindex = currentscope.methodscope().recordinitializationstates(mergedinfo);
return mergedinfo;
}

/**
* for statement code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {

if ((this.bits & isreachable) == 0) {
return;
}
int pc = codestream.position;
final boolean hasemptyaction = this.action == null
|| this.action.isemptyblock()
|| ((this.action.bits & isusefulemptystatement) != 0);

if (hasemptyaction
&& this.elementvariable.binding.resolvedposition == -1
&& this.kind == array) {
this.collection.generatecode(this.scope, codestream, false);
codestream.exituserscope(this.scope);
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}

// generate the initializations
switch(this.kind) {
case array :
this.collection.generatecode(this.scope, codestream, true);
codestream.store(this.collectionvariable, true);
codestream.addvariable(this.collectionvariable);
if (this.continuelabel != null) {
// int length = (collectionvariable = [collection]).length;
codestream.arraylength();
codestream.store(this.maxvariable, false);
codestream.addvariable(this.maxvariable);
codestream.iconst_0();
codestream.store(this.indexvariable, false);
codestream.addvariable(this.indexvariable);
} else {
// leave collectionvariable on execution stack (will be consumed when swapping condition further down)
}
break;
case raw_iterable :
case generic_iterable :
this.collection.generatecode(this.scope, codestream, true);
// declaringclass.iterator();
codestream.invokeiterableiterator(this.iteratorreceivertype);
codestream.store(this.indexvariable, false);
codestream.addvariable(this.indexvariable);
break;
}
// label management
branchlabel actionlabel = new branchlabel(codestream);
actionlabel.tagbits |= branchlabel.used;
branchlabel conditionlabel = new branchlabel(codestream);
conditionlabel.tagbits |= branchlabel.used;
this.breaklabel.initialize(codestream);
if (this.continuelabel == null) {
// generate the condition (swapped for optimizing)
conditionlabel.place();
int conditionpc = codestream.position;
switch(this.kind) {
case array :
// inline the arraylength call
// collectionvariable is already on execution stack
codestream.arraylength();
codestream.ifeq(this.breaklabel);
break;
case raw_iterable :
case generic_iterable :
codestream.load(this.indexvariable);
codestream.invokejavautiliteratorhasnext();
codestream.ifeq(this.breaklabel);
break;
}
codestream.recordpositionsfrom(conditionpc, this.elementvariable.sourcestart);
} else {
this.continuelabel.initialize(codestream);
this.continuelabel.tagbits |= branchlabel.used;
// jump over the actionblock
codestream.goto_(conditionlabel);
}

// generate the loop action
actionlabel.place();

// generate the loop action
switch(this.kind) {
case array :
if (this.elementvariable.binding.resolvedposition != -1) {
codestream.load(this.collectionvariable);
if (this.continuelabel == null) {
codestream.iconst_0(); // no continue, thus simply hardcode offset 0
} else {
codestream.load(this.indexvariable);
}
codestream.arrayat(this.collectionelementtype.id);
if (this.elementvariableimplicitwidening != -1) {
codestream.generateimplicitconversion(this.elementvariableimplicitwidening);
}
codestream.store(this.elementvariable.binding, false);
codestream.addvisiblelocalvariable(this.elementvariable.binding);
if (this.postcollectioninitstateindex != -1) {
codestream.adddefinitelyassignedvariables(
currentscope,
this.postcollectioninitstateindex);
}
}
break;
case raw_iterable :
case generic_iterable :
codestream.load(this.indexvariable);
codestream.invokejavautiliteratornext();
if (this.elementvariable.binding.type.id != t_javalangobject) {
if (this.elementvariableimplicitwidening != -1) {
codestream.checkcast(this.collectionelementtype);
codestream.generateimplicitconversion(this.elementvariableimplicitwidening);
} else {
codestream.checkcast(this.elementvariable.binding.type);
}
}
if (this.elementvariable.binding.resolvedposition == -1) {
codestream.pop();
} else {
codestream.store(this.elementvariable.binding, false);
codestream.addvisiblelocalvariable(this.elementvariable.binding);
if (this.postcollectioninitstateindex != -1) {
codestream.adddefinitelyassignedvariables(
currentscope,
this.postcollectioninitstateindex);
}
}
break;
}

if (!hasemptyaction) {
this.action.generatecode(this.scope, codestream);
}
codestream.removevariable(this.elementvariable.binding);
if (this.postcollectioninitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.postcollectioninitstateindex);
}
// continuation point
if (this.continuelabel != null) {
this.continuelabel.place();
int continuationpc = codestream.position;
// generate the increments for next iteration
switch(this.kind) {
case array :
if (!hasemptyaction || this.elementvariable.binding.resolvedposition >= 0) {
codestream.iinc(this.indexvariable.resolvedposition, 1);
}
// generate the condition
conditionlabel.place();
codestream.load(this.indexvariable);
codestream.load(this.maxvariable);
codestream.if_icmplt(actionlabel);
break;
case raw_iterable :
case generic_iterable :
// generate the condition
conditionlabel.place();
codestream.load(this.indexvariable);
codestream.invokejavautiliteratorhasnext();
codestream.ifne(actionlabel);
break;
}
codestream.recordpositionsfrom(continuationpc, this.elementvariable.sourcestart);
}
switch(this.kind) {
case array :
codestream.removevariable(this.indexvariable);
codestream.removevariable(this.maxvariable);
codestream.removevariable(this.collectionvariable);
break;
case raw_iterable :
case generic_iterable :
// generate the condition
codestream.removevariable(this.indexvariable);
break;
}
codestream.exituserscope(this.scope);
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
this.breaklabel.place();
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public stringbuffer printstatement(int indent, stringbuffer output) {

printindent(indent, output).append("for ("); //$non-nls-1$
this.elementvariable.printasexpression(0, output);
output.append(" : ");//$non-nls-1$
if (this.collection != null) {
this.collection.print(0, output).append(") "); //$non-nls-1$
} else {
output.append(')');
}
//block
if (this.action == null) {
output.append(';');
} else {
output.append('\n');
this.action.printstatement(indent + 1, output);
}
return output;
}

public void resolve(blockscope upperscope) {
// use the scope that will hold the init declarations
this.scope = new blockscope(upperscope);
this.elementvariable.resolve(this.scope); // collection expression can see itemvariable
typebinding elementtype = this.elementvariable.type.resolvedtype;
typebinding collectiontype = this.collection == null ? null : this.collection.resolvetype(this.scope);

typebinding expectedcollectiontype = null;
if (elementtype != null && collectiontype != null) {
boolean istargetjsr14 = this.scope.compileroptions().targetjdk == classfileconstants.jdk1_4;
if (collectiontype.isarraytype()) { // for(e e : e[])
this.kind = array;
this.collectionelementtype = ((arraybinding) collectiontype).elementstype();
if (!this.collectionelementtype.iscompatiblewith(elementtype)
&& !this.scope.isboxingcompatiblewith(this.collectionelementtype, elementtype)) {
this.scope.problemreporter().notcompatibletypeserrorinforeach(this.collection, this.collectionelementtype, elementtype);
}
// in case we need to do a conversion
int compiletimetypeid = this.collectionelementtype.id;
if (elementtype.isbasetype()) {
this.collection.computeconversion(this.scope, collectiontype, collectiontype);
if (!this.collectionelementtype.isbasetype()) {
compiletimetypeid = this.scope.environment().computeboxingtype(this.collectionelementtype).id;
this.elementvariableimplicitwidening = unboxing;
if (elementtype.isbasetype()) {
this.elementvariableimplicitwidening |= (elementtype.id << 4) + compiletimetypeid;
this.scope.problemreporter().autoboxing(this.collection, this.collectionelementtype, elementtype);
}
} else {
this.elementvariableimplicitwidening = (elementtype.id << 4) + compiletimetypeid;
}
} else if (this.collectionelementtype.isbasetype()) {
this.collection.computeconversion(this.scope, collectiontype, collectiontype);
int boxedid = this.scope.environment().computeboxingtype(this.collectionelementtype).id;
this.elementvariableimplicitwidening = boxing | (compiletimetypeid << 4) | compiletimetypeid; // use primitive type in implicit conversion
compiletimetypeid = boxedid;
this.scope.problemreporter().autoboxing(this.collection, this.collectionelementtype, elementtype);
} else {
expectedcollectiontype = upperscope.createarraytype(elementtype, 1);
this.collection.computeconversion(this.scope, expectedcollectiontype, collectiontype);
}
} else if (collectiontype instanceof referencebinding) {
referencebinding iterabletype = ((referencebinding)collectiontype).findsupertypeoriginatingfrom(t_javalangiterable, false /*iterable is not a class*/);
if (iterabletype == null && istargetjsr14) {
iterabletype = ((referencebinding)collectiontype).findsupertypeoriginatingfrom(t_javautilcollection, false /*iterable is not a class*/);
}
checkiterable: {
if (iterabletype == null) break checkiterable;

this.iteratorreceivertype = collectiontype.erasure();
if (istargetjsr14) {
if (((referencebinding)this.iteratorreceivertype).findsupertypeoriginatingfrom(t_javautilcollection, false) == null) {
this.iteratorreceivertype = iterabletype; // handle indirect inheritance thru variable secondary bound
this.collection.computeconversion(this.scope, iterabletype, collectiontype);
} else {
this.collection.computeconversion(this.scope, collectiontype, collectiontype);
}
} else if (((referencebinding)this.iteratorreceivertype).findsupertypeoriginatingfrom(t_javalangiterable, false) == null) {
this.iteratorreceivertype = iterabletype; // handle indirect inheritance thru variable secondary bound
this.collection.computeconversion(this.scope, iterabletype, collectiontype);
} else {
this.collection.computeconversion(this.scope, collectiontype, collectiontype);
}

typebinding[] arguments = null;
switch (iterabletype.kind()) {
case binding.raw_type : // for(object o : iterable)
this.kind = raw_iterable;
this.collectionelementtype = this.scope.getjavalangobject();
if (!this.collectionelementtype.iscompatiblewith(elementtype)
&& !this.scope.isboxingcompatiblewith(this.collectionelementtype, elementtype)) {
this.scope.problemreporter().notcompatibletypeserrorinforeach(this.collection, this.collectionelementtype, elementtype);
}
// no conversion needed as only for reference types
break checkiterable;

case binding.generic_type : // for (t t : iterable<t>) - in case used inside iterable itself
arguments = iterabletype.typevariables();
break;

case binding.parameterized_type : // for(e e : iterable<e>)
arguments = ((parameterizedtypebinding)iterabletype).arguments;
break;

default:
break checkiterable;
}
// generic or parameterized case
if (arguments.length != 1) break checkiterable; // per construction can only be one
this.kind = generic_iterable;

this.collectionelementtype = arguments[0];
if (!this.collectionelementtype.iscompatiblewith(elementtype)
&& !this.scope.isboxingcompatiblewith(this.collectionelementtype, elementtype)) {
this.scope.problemreporter().notcompatibletypeserrorinforeach(this.collection, this.collectionelementtype, elementtype);
}
int compiletimetypeid = this.collectionelementtype.id;
// no conversion needed as only for reference types
if (elementtype.isbasetype()) {
if (!this.collectionelementtype.isbasetype()) {
compiletimetypeid = this.scope.environment().computeboxingtype(this.collectionelementtype).id;
this.elementvariableimplicitwidening = unboxing;
if (elementtype.isbasetype()) {
this.elementvariableimplicitwidening |= (elementtype.id << 4) + compiletimetypeid;
}
} else {
this.elementvariableimplicitwidening = (elementtype.id << 4) + compiletimetypeid;
}
} else {
if (this.collectionelementtype.isbasetype()) {
this.elementvariableimplicitwidening = boxing | (compiletimetypeid << 4) | compiletimetypeid; // use primitive type in implicit conversion
}
}
}
}
switch(this.kind) {
case array :
// allocate #index secret variable (of type int)
this.indexvariable = new localvariablebinding(secretindexvariablename, typebinding.int, classfileconstants.accdefault, false);
this.scope.addlocalvariable(this.indexvariable);
this.indexvariable.setconstant(constant.notaconstant); // not inlinable
// allocate #max secret variable
this.maxvariable = new localvariablebinding(secretmaxvariablename, typebinding.int, classfileconstants.accdefault, false);
this.scope.addlocalvariable(this.maxvariable);
this.maxvariable.setconstant(constant.notaconstant); // not inlinable
// add #array secret variable (of collection type)
if (expectedcollectiontype == null) {
this.collectionvariable = new localvariablebinding(secretcollectionvariablename, collectiontype, classfileconstants.accdefault, false);
} else {
this.collectionvariable = new localvariablebinding(secretcollectionvariablename, expectedcollectiontype, classfileconstants.accdefault, false);
}
this.scope.addlocalvariable(this.collectionvariable);
this.collectionvariable.setconstant(constant.notaconstant); // not inlinable
break;
case raw_iterable :
case generic_iterable :
// allocate #index secret variable (of type iterator)
this.indexvariable = new localvariablebinding(secretiteratorvariablename, this.scope.getjavautiliterator(), classfileconstants.accdefault, false);
this.scope.addlocalvariable(this.indexvariable);
this.indexvariable.setconstant(constant.notaconstant); // not inlinable
break;
default :
if (istargetjsr14) {
this.scope.problemreporter().invalidtypeforcollectiontarget14(this.collection);
} else {
this.scope.problemreporter().invalidtypeforcollection(this.collection);
}
}
}
if (this.action != null) {
this.action.resolve(this.scope);
}
}

public void traverse(
astvisitor visitor,
blockscope blockscope) {

if (visitor.visit(this, blockscope)) {
this.elementvariable.traverse(visitor, this.scope);
if (this.collection != null) {
this.collection.traverse(visitor, this.scope);
}
if (this.action != null) {
this.action.traverse(visitor, this.scope);
}
}
visitor.endvisit(this, blockscope);
}
}
