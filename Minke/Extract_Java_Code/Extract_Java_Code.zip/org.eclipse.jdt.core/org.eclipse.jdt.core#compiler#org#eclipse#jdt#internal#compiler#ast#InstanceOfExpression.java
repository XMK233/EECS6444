/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class instanceofexpression extends operatorexpression {

public expression expression;
public typereference type;

public instanceofexpression(expression expression, typereference type) {
this.expression = expression;
this.type = type;
type.bits |= ignorerawtypecheck; // https://bugs.eclipse.org/bugs/show_bug.cgi?id=282141
this.bits |= instanceof << operatorshift;
this.sourcestart = expression.sourcestart;
this.sourceend = type.sourceend;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
localvariablebinding local = this.expression.localvariablebinding();
if (local != null && (local.type.tagbits & tagbits.isbasetype) == 0) {
flowinfo = this.expression.analysecode(currentscope, flowcontext, flowinfo).
unconditionalinits();
flowinfo initswhentrue = flowinfo.copy();
initswhentrue.markascomparedequaltononnull(local);
flowcontext.recordusingnullreference(currentscope, local,
this.expression, flowcontext.can_only_null | flowcontext.in_instanceof, flowinfo);
// no impact upon enclosing try context
return flowinfo.conditional(initswhentrue, flowinfo.copy());
}
return this.expression.analysecode(currentscope, flowcontext, flowinfo).
unconditionalinits();
}

/**
* code generation for instanceofexpression
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
this.expression.generatecode(currentscope, codestream, true);
codestream.instance_of(this.type.resolvedtype);
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else {
codestream.pop();
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public stringbuffer printexpressionnoparenthesis(int indent, stringbuffer output) {
this.expression.printexpression(indent, output).append(" instanceof "); //$non-nls-1$
return this.type.print(0, output);
}

public typebinding resolvetype(blockscope scope) {
this.constant = constant.notaconstant;
typebinding expressiontype = this.expression.resolvetype(scope);
typebinding checkedtype = this.type.resolvetype(scope, true /* check bounds*/);
if (expressiontype == null || checkedtype == null)
return null;

if (!checkedtype.isreifiable()) {
scope.problemreporter().illegalinstanceofgenerictype(checkedtype, this);
} else if ((expressiontype != typebinding.null && expressiontype.isbasetype()) // disallow autoboxing
|| !checkcasttypescompatibility(scope, checkedtype, expressiontype, null)) {
scope.problemreporter().notcompatibletypeserror(this, expressiontype, checkedtype);
}
return this.resolvedtype = typebinding.boolean;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#tagasunnecessarycast(scope,typebinding)
*/
public void tagasunnecessarycast(scope scope, typebinding casttype) {
// null is not instanceof type, recognize direct scenario
if (this.expression.resolvedtype != typebinding.null)
scope.problemreporter().unnecessaryinstanceof(this, casttype);
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
this.expression.traverse(visitor, scope);
this.type.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
