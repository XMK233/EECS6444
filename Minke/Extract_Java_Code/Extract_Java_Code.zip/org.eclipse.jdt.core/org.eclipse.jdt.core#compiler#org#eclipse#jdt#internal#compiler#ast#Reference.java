/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.codegen.opcodes;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;

public abstract class reference extends expression  {
/**
* baselevelreference constructor comment.
*/
public reference() {
super();
}
public abstract flowinfo analyseassignment(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo, assignment assignment, boolean iscompound);

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
return flowinfo;
}

public fieldbinding fieldbinding() {
//this method should be sent one field-tagged references
//  (ref.bits & bindingids.field != 0)()
return null ;
}

public void fieldstore(scope currentscope, codestream codestream, fieldbinding fieldbinding, methodbinding syntheticwriteaccessor, typebinding receivertype, boolean isimplicitthisreceiver, boolean valuerequired) {
int pc = codestream.position;
if (fieldbinding.isstatic()) {
if (valuerequired) {
switch (fieldbinding.type.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2();
break;
default :
codestream.dup();
break;
}
}
if (syntheticwriteaccessor == null) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, fieldbinding, receivertype, isimplicitthisreceiver);
codestream.fieldaccess(opcodes.opc_putstatic, fieldbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, syntheticwriteaccessor, null /* default declaringclass */);
}
} else { // stack:  [owner][new field value]  ---> [new field value][owner][new field value]
if (valuerequired) {
switch (fieldbinding.type.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2_x1();
break;
default :
codestream.dup_x1();
break;
}
}
if (syntheticwriteaccessor == null) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, fieldbinding, receivertype, isimplicitthisreceiver);
codestream.fieldaccess(opcodes.opc_putfield, fieldbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, syntheticwriteaccessor, null /* default declaringclass */);
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public abstract void generateassignment(blockscope currentscope, codestream codestream, assignment assignment, boolean valuerequired);

public abstract void generatecompoundassignment(blockscope currentscope, codestream codestream, expression expression, int operator, int assignmentimplicitconversion, boolean valuerequired);

public abstract void generatepostincrement(blockscope currentscope, codestream codestream, compoundassignment postincrement, boolean valuerequired);
}
