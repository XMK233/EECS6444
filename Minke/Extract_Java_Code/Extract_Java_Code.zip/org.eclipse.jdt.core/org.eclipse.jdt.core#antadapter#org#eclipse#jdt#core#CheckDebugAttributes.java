/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.core;

import java.io.ioexception;
import java.util.enumeration;
import java.util.zip.zipentry;
import java.util.zip.zipexception;
import java.util.zip.zipfile;

import org.apache.tools.ant.buildexception;
import org.apache.tools.ant.task;
import org.eclipse.jdt.core.util.iclassfilereader;
import org.eclipse.jdt.core.util.icodeattribute;
import org.eclipse.jdt.core.util.imethodinfo;
import org.eclipse.jdt.internal.antadapter.antadaptermessages;

/**
* <p>an ant task to find out if a class file or a jar contains debug attributes. if this is the case,
* the property contains the value "has debug" after the call.
* </p>
* <p>
* <code>&lt;eclipse.checkdebugattributes property="hasdebug" file="${basedir}/bin/p/a.class"/&gt;</code>
* </p>
* <p>
* for more information on ant check out the website at http://jakarta.apache.org/ant/ .
* </p>
*
* this is not intended to be subclassed by users.
* @@since 2.0
*/
public final class checkdebugattributes extends task {

private string file;
private string property;

public void execute() throws buildexception {
if (this.file == null) {
throw new buildexception(antadaptermessages.getstring("checkdebugattributes.file.argument.cannot.be.null")); //$non-nls-1$
}
if (this.property == null) {
throw new buildexception(antadaptermessages.getstring("checkdebugattributes.property.argument.cannot.be.null")); //$non-nls-1$
}
try {
boolean hasdebugattributes = false;
if (org.eclipse.jdt.internal.compiler.util.util.isclassfilename(this.file)) {
iclassfilereader classfilereader = toolfactory.createdefaultclassfilereader(this.file, iclassfilereader.all);
hasdebugattributes = checkclassfile(classfilereader);
} else {
zipfile jarfile = null;
try {
jarfile = new zipfile(this.file);
} catch (zipexception e) {
throw new buildexception(antadaptermessages.getstring("checkdebugattributes.file.argument.must.be.a.classfile.or.a.jarfile")); //$non-nls-1$
}
for (enumeration entries = jarfile.entries(); !hasdebugattributes && entries.hasmoreelements(); ) {
zipentry entry = (zipentry) entries.nextelement();
if (org.eclipse.jdt.internal.compiler.util.util.isclassfilename(entry.getname())) {
iclassfilereader classfilereader = toolfactory.createdefaultclassfilereader(this.file, entry.getname(), iclassfilereader.all);
hasdebugattributes = checkclassfile(classfilereader);
}
}
}
if (hasdebugattributes) {
getproject().setuserproperty(this.property, "has debug"); //$non-nls-1$
}
} catch (ioexception e) {
throw new buildexception(antadaptermessages.getstring("checkdebugattributes.ioexception.occured") + this.file); //$non-nls-1$
}
}

private boolean checkclassfile(iclassfilereader classfilereader) {
imethodinfo[] methodinfos = classfilereader.getmethodinfos();
for (int i = 0, max = methodinfos.length; i < max; i++) {
icodeattribute codeattribute = methodinfos[i].getcodeattribute();
if (codeattribute != null && codeattribute.getlinenumberattribute() != null) {
return true;
}
}
return false;
}

public void setfile(string value) {
this.file = value;
}

public void setproperty(string value) {
this.property = value;
}
}
