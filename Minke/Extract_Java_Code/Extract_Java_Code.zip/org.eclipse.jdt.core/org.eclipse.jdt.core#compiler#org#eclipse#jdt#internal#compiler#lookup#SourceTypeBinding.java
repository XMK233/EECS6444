/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.util.hashmap;
import java.util.iterator;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.abstractvariabledeclaration;
import org.eclipse.jdt.internal.compiler.ast.argument;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.ast.methoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.ast.typeparameter;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.util.simplelookuptable;
import org.eclipse.jdt.internal.compiler.util.util;

public class sourcetypebinding extends referencebinding {
public referencebinding superclass;
public referencebinding[] superinterfaces;
private fieldbinding[] fields;
private methodbinding[] methods;
public referencebinding[] membertypes;
public typevariablebinding[] typevariables;

public classscope scope;

// synthetics are separated into 4 categories: methods, super methods, fields, class literals and bridge methods
// if a new category is added, also increment max_synthetics
private final static int method_emul = 0;
private final static int field_emul = 1;
private final static int class_literal_emul = 2;

private final static int max_synthetics = 3;

hashmap[] synthetics;
char[] genericreferencetypesignature;

private simplelookuptable storedannotations = null; // keys are this referencebinding & its fields and methods, value is an annotationholder

public sourcetypebinding(char[][] compoundname, packagebinding fpackage, classscope scope) {
this.compoundname = compoundname;
this.fpackage = fpackage;
this.filename = scope.referencecompilationunit().getfilename();
this.modifiers = scope.referencecontext.modifiers;
this.sourcename = scope.referencecontext.name;
this.scope = scope;

// expect the fields & methods to be initialized correctly later
this.fields = binding.uninitialized_fields;
this.methods = binding.uninitialized_methods;

computeid();
}

private void adddefaultabstractmethods() {
if ((this.tagbits & tagbits.knowsdefaultabstractmethods) != 0) return;

this.tagbits |= tagbits.knowsdefaultabstractmethods;
if (isclass() && isabstract()) {
if (this.scope.compileroptions().targetjdk >= classfileconstants.jdk1_2)
return; // no longer added for post 1.2 targets

referencebinding[] itsinterfaces = superinterfaces();
if (itsinterfaces != binding.no_superinterfaces) {
methodbinding[] defaultabstracts = null;
int defaultabstractscount = 0;
referencebinding[] interfacestovisit = itsinterfaces;
int nextposition = interfacestovisit.length;
for (int i = 0; i < nextposition; i++) {
referencebinding supertype = interfacestovisit[i];
if (supertype.isvalidbinding()) {
methodbinding[] supermethods = supertype.methods();
nextabstractmethod: for (int m = supermethods.length; --m >= 0;) {
methodbinding method = supermethods[m];
// explicitly implemented ?
if (implementsmethod(method))
continue nextabstractmethod;
if (defaultabstractscount == 0) {
defaultabstracts = new methodbinding[5];
} else {
// already added as default abstract ?
for (int k = 0; k < defaultabstractscount; k++) {
methodbinding alreadyadded = defaultabstracts[k];
if (charoperation.equals(alreadyadded.selector, method.selector) && alreadyadded.areparametersequal(method))
continue nextabstractmethod;
}
}
methodbinding defaultabstract = new methodbinding(
method.modifiers | extracompilermodifiers.accdefaultabstract | classfileconstants.accsynthetic,
method.selector,
method.returntype,
method.parameters,
method.thrownexceptions,
this);
if (defaultabstractscount == defaultabstracts.length)
system.arraycopy(defaultabstracts, 0, defaultabstracts = new methodbinding[2 * defaultabstractscount], 0, defaultabstractscount);
defaultabstracts[defaultabstractscount++] = defaultabstract;
}

if ((itsinterfaces = supertype.superinterfaces()) != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
if (defaultabstractscount > 0) {
int length = this.methods.length;
system.arraycopy(this.methods, 0, this.methods = new methodbinding[length + defaultabstractscount], 0, length);
system.arraycopy(defaultabstracts, 0, this.methods, length, defaultabstractscount);
// re-sort methods
length = length + defaultabstractscount;
if (length > 1)
referencebinding.sortmethods(this.methods, 0, length);
// this.tagbits |= tagbits.aremethodssorted; -- already set in #methods()
}
}
}
}
/* add a new synthetic field for <actualouterlocalvariable>.
*	answer the new field or the existing field if one already existed.
*/
public fieldbinding addsyntheticfieldforinnerclass(localvariablebinding actualouterlocalvariable) {
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.field_emul] == null)
this.synthetics[sourcetypebinding.field_emul] = new hashmap(5);

fieldbinding synthfield = (fieldbinding) this.synthetics[sourcetypebinding.field_emul].get(actualouterlocalvariable);
if (synthfield == null) {
synthfield = new syntheticfieldbinding(
charoperation.concat(typeconstants.synthetic_outer_local_prefix, actualouterlocalvariable.name),
actualouterlocalvariable.type,
classfileconstants.accprivate | classfileconstants.accfinal | classfileconstants.accsynthetic,
this,
constant.notaconstant,
this.synthetics[sourcetypebinding.field_emul].size());
this.synthetics[sourcetypebinding.field_emul].put(actualouterlocalvariable, synthfield);
}

// ensure there is not already such a field defined by the user
boolean needrecheck;
int index = 1;
do {
needrecheck = false;
fieldbinding existingfield;
if ((existingfield = getfield(synthfield.name, true /*resolve*/)) != null) {
typedeclaration typedecl = this.scope.referencecontext;
for (int i = 0, max = typedecl.fields.length; i < max; i++) {
fielddeclaration fielddecl = typedecl.fields[i];
if (fielddecl.binding == existingfield) {
synthfield.name = charoperation.concat(
typeconstants.synthetic_outer_local_prefix,
actualouterlocalvariable.name,
("$" + string.valueof(index++)).tochararray()); //$non-nls-1$
needrecheck = true;
break;
}
}
}
} while (needrecheck);
return synthfield;
}
/* add a new synthetic field for <enclosingtype>.
*	answer the new field or the existing field if one already existed.
*/
public fieldbinding addsyntheticfieldforinnerclass(referencebinding enclosingtype) {
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.field_emul] == null)
this.synthetics[sourcetypebinding.field_emul] = new hashmap(5);

fieldbinding synthfield = (fieldbinding) this.synthetics[sourcetypebinding.field_emul].get(enclosingtype);
if (synthfield == null) {
synthfield = new syntheticfieldbinding(
charoperation.concat(
typeconstants.synthetic_enclosing_instance_prefix,
string.valueof(enclosingtype.depth()).tochararray()),
enclosingtype,
classfileconstants.accdefault | classfileconstants.accfinal | classfileconstants.accsynthetic,
this,
constant.notaconstant,
this.synthetics[sourcetypebinding.field_emul].size());
this.synthetics[sourcetypebinding.field_emul].put(enclosingtype, synthfield);
}
// ensure there is not already such a field defined by the user
boolean needrecheck;
do {
needrecheck = false;
fieldbinding existingfield;
if ((existingfield = getfield(synthfield.name, true /*resolve*/)) != null) {
typedeclaration typedecl = this.scope.referencecontext;
for (int i = 0, max = typedecl.fields.length; i < max; i++) {
fielddeclaration fielddecl = typedecl.fields[i];
if (fielddecl.binding == existingfield) {
if (this.scope.compileroptions().compliancelevel >= classfileconstants.jdk1_5) {
synthfield.name = charoperation.concat(
synthfield.name,
"$".tochararray()); //$non-nls-1$
needrecheck = true;
} else {
this.scope.problemreporter().duplicatefieldintype(this, fielddecl);
}
break;
}
}
}
} while (needrecheck);
return synthfield;
}
/* add a new synthetic field for a class literal access.
*	answer the new field or the existing field if one already existed.
*/
public fieldbinding addsyntheticfieldforclassliteral(typebinding targettype, blockscope blockscope) {
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.class_literal_emul] == null)
this.synthetics[sourcetypebinding.class_literal_emul] = new hashmap(5);

// use a different table than fields, given there might be a collision between emulation of x.this$0 and x.class.
fieldbinding synthfield = (fieldbinding) this.synthetics[sourcetypebinding.class_literal_emul].get(targettype);
if (synthfield == null) {
synthfield = new syntheticfieldbinding(
charoperation.concat(
typeconstants.synthetic_class,
string.valueof(this.synthetics[sourcetypebinding.class_literal_emul].size()).tochararray()),
blockscope.getjavalangclass(),
classfileconstants.accdefault | classfileconstants.accstatic | classfileconstants.accsynthetic,
this,
constant.notaconstant,
this.synthetics[sourcetypebinding.class_literal_emul].size());
this.synthetics[sourcetypebinding.class_literal_emul].put(targettype, synthfield);
}
// ensure there is not already such a field defined by the user
fieldbinding existingfield;
if ((existingfield = getfield(synthfield.name, true /*resolve*/)) != null) {
typedeclaration typedecl = blockscope.referencetype();
for (int i = 0, max = typedecl.fields.length; i < max; i++) {
fielddeclaration fielddecl = typedecl.fields[i];
if (fielddecl.binding == existingfield) {
blockscope.problemreporter().duplicatefieldintype(this, fielddecl);
break;
}
}
}
return synthfield;
}
/* add a new synthetic field for the emulation of the assert statement.
*	answer the new field or the existing field if one already existed.
*/
public fieldbinding addsyntheticfieldforassert(blockscope blockscope) {
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.field_emul] == null)
this.synthetics[sourcetypebinding.field_emul] = new hashmap(5);

fieldbinding synthfield = (fieldbinding) this.synthetics[sourcetypebinding.field_emul].get("assertionemulation"); //$non-nls-1$
if (synthfield == null) {
synthfield = new syntheticfieldbinding(
typeconstants.synthetic_assert_disabled,
typebinding.boolean,
classfileconstants.accdefault | classfileconstants.accstatic | classfileconstants.accsynthetic | classfileconstants.accfinal,
this,
constant.notaconstant,
this.synthetics[sourcetypebinding.field_emul].size());
this.synthetics[sourcetypebinding.field_emul].put("assertionemulation", synthfield); //$non-nls-1$
}
// ensure there is not already such a field defined by the user
// ensure there is not already such a field defined by the user
boolean needrecheck;
int index = 0;
do {
needrecheck = false;
fieldbinding existingfield;
if ((existingfield = getfield(synthfield.name, true /*resolve*/)) != null) {
typedeclaration typedecl = this.scope.referencecontext;
for (int i = 0, max = typedecl.fields.length; i < max; i++) {
fielddeclaration fielddecl = typedecl.fields[i];
if (fielddecl.binding == existingfield) {
synthfield.name = charoperation.concat(
typeconstants.synthetic_assert_disabled,
("_" + string.valueof(index++)).tochararray()); //$non-nls-1$
needrecheck = true;
break;
}
}
}
} while (needrecheck);
return synthfield;
}
/* add a new synthetic field for recording all enum constant values
*	answer the new field or the existing field if one already existed.
*/
public fieldbinding addsyntheticfieldforenumvalues() {
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.field_emul] == null)
this.synthetics[sourcetypebinding.field_emul] = new hashmap(5);

fieldbinding synthfield = (fieldbinding) this.synthetics[sourcetypebinding.field_emul].get("enumconstantvalues"); //$non-nls-1$
if (synthfield == null) {
synthfield = new syntheticfieldbinding(
typeconstants.synthetic_enum_values,
this.scope.createarraytype(this,1),
classfileconstants.accprivate | classfileconstants.accstatic | classfileconstants.accsynthetic | classfileconstants.accfinal,
this,
constant.notaconstant,
this.synthetics[sourcetypebinding.field_emul].size());
this.synthetics[sourcetypebinding.field_emul].put("enumconstantvalues", synthfield); //$non-nls-1$
}
// ensure there is not already such a field defined by the user
// ensure there is not already such a field defined by the user
boolean needrecheck;
int index = 0;
do {
needrecheck = false;
fieldbinding existingfield;
if ((existingfield = getfield(synthfield.name, true /*resolve*/)) != null) {
typedeclaration typedecl = this.scope.referencecontext;
for (int i = 0, max = typedecl.fields.length; i < max; i++) {
fielddeclaration fielddecl = typedecl.fields[i];
if (fielddecl.binding == existingfield) {
synthfield.name = charoperation.concat(
typeconstants.synthetic_enum_values,
("_" + string.valueof(index++)).tochararray()); //$non-nls-1$
needrecheck = true;
break;
}
}
}
} while (needrecheck);
return synthfield;
}
/* add a new synthetic access method for read/write access to <targetfield>.
answer the new method or the existing method if one already existed.
*/
public syntheticmethodbinding addsyntheticmethod(fieldbinding targetfield, boolean isreadaccess, boolean issuperaccess) {
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.method_emul] == null)
this.synthetics[sourcetypebinding.method_emul] = new hashmap(5);

syntheticmethodbinding accessmethod = null;
syntheticmethodbinding[] accessors = (syntheticmethodbinding[]) this.synthetics[sourcetypebinding.method_emul].get(targetfield);
if (accessors == null) {
accessmethod = new syntheticmethodbinding(targetfield, isreadaccess, issuperaccess, this);
this.synthetics[sourcetypebinding.method_emul].put(targetfield, accessors = new syntheticmethodbinding[2]);
accessors[isreadaccess ? 0 : 1] = accessmethod;
} else {
if ((accessmethod = accessors[isreadaccess ? 0 : 1]) == null) {
accessmethod = new syntheticmethodbinding(targetfield, isreadaccess, issuperaccess, this);
accessors[isreadaccess ? 0 : 1] = accessmethod;
}
}
return accessmethod;
}
/* add a new synthetic method the enum type. selector can either be 'values' or 'valueof'.
* char[] constants from typeconstants must be used: typeconstants.values/valueof
*/
public syntheticmethodbinding addsyntheticenummethod(char[] selector) {
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.method_emul] == null)
this.synthetics[sourcetypebinding.method_emul] = new hashmap(5);

syntheticmethodbinding accessmethod = null;
syntheticmethodbinding[] accessors = (syntheticmethodbinding[]) this.synthetics[sourcetypebinding.method_emul].get(selector);
if (accessors == null) {
accessmethod = new syntheticmethodbinding(this, selector);
this.synthetics[sourcetypebinding.method_emul].put(selector, accessors = new syntheticmethodbinding[2]);
accessors[0] = accessmethod;
} else {
if ((accessmethod = accessors[0]) == null) {
accessmethod = new syntheticmethodbinding(this, selector);
accessors[0] = accessmethod;
}
}
return accessmethod;
}
/*
* add a synthetic field to handle the cache of the switch translation table for the corresponding enum type
*/
public syntheticfieldbinding addsyntheticfieldforswitchenum(char[] fieldname, string key) {
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.field_emul] == null)
this.synthetics[sourcetypebinding.field_emul] = new hashmap(5);

syntheticfieldbinding synthfield = (syntheticfieldbinding) this.synthetics[sourcetypebinding.field_emul].get(key);
if (synthfield == null) {
synthfield = new syntheticfieldbinding(
fieldname,
this.scope.createarraytype(typebinding.int,1),
classfileconstants.accprivate | classfileconstants.accstatic | classfileconstants.accsynthetic,
this,
constant.notaconstant,
this.synthetics[sourcetypebinding.field_emul].size());
this.synthetics[sourcetypebinding.field_emul].put(key, synthfield);
}
// ensure there is not already such a field defined by the user
boolean needrecheck;
int index = 0;
do {
needrecheck = false;
fieldbinding existingfield;
if ((existingfield = getfield(synthfield.name, true /*resolve*/)) != null) {
typedeclaration typedecl = this.scope.referencecontext;
for (int i = 0, max = typedecl.fields.length; i < max; i++) {
fielddeclaration fielddecl = typedecl.fields[i];
if (fielddecl.binding == existingfield) {
synthfield.name = charoperation.concat(
fieldname,
("_" + string.valueof(index++)).tochararray()); //$non-nls-1$
needrecheck = true;
break;
}
}
}
} while (needrecheck);
return synthfield;
}
/* add a new synthetic method the enum type. selector can either be 'values' or 'valueof'.
* char[] constants from typeconstants must be used: typeconstants.values/valueof
*/
public syntheticmethodbinding addsyntheticmethodforswitchenum(typebinding enumbinding) {
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.method_emul] == null)
this.synthetics[sourcetypebinding.method_emul] = new hashmap(5);

syntheticmethodbinding accessmethod = null;
char[] selector = charoperation.concat(typeconstants.synthetic_switch_enum_table, enumbinding.constantpoolname());
charoperation.replace(selector, '/', '$');
final string key = new string(selector);
syntheticmethodbinding[] accessors = (syntheticmethodbinding[]) this.synthetics[sourcetypebinding.method_emul].get(key);
// first add the corresponding synthetic field
if (accessors == null) {
// then create the synthetic method
final syntheticfieldbinding fieldbinding = addsyntheticfieldforswitchenum(selector, key);
accessmethod = new syntheticmethodbinding(fieldbinding, this, enumbinding, selector);
this.synthetics[sourcetypebinding.method_emul].put(key, accessors = new syntheticmethodbinding[2]);
accessors[0] = accessmethod;
} else {
if ((accessmethod = accessors[0]) == null) {
final syntheticfieldbinding fieldbinding = addsyntheticfieldforswitchenum(selector, key);
accessmethod = new syntheticmethodbinding(fieldbinding, this, enumbinding, selector);
accessors[0] = accessmethod;
}
}
return accessmethod;
}
/* add a new synthetic access method for access to <targetmethod>.
* must distinguish access method used for super access from others (need to use invokespecial bytecode)
answer the new method or the existing method if one already existed.
*/
public syntheticmethodbinding addsyntheticmethod(methodbinding targetmethod, boolean issuperaccess) {
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.method_emul] == null)
this.synthetics[sourcetypebinding.method_emul] = new hashmap(5);

syntheticmethodbinding accessmethod = null;
syntheticmethodbinding[] accessors = (syntheticmethodbinding[]) this.synthetics[sourcetypebinding.method_emul].get(targetmethod);
if (accessors == null) {
accessmethod = new syntheticmethodbinding(targetmethod, issuperaccess, this);
this.synthetics[sourcetypebinding.method_emul].put(targetmethod, accessors = new syntheticmethodbinding[2]);
accessors[issuperaccess ? 0 : 1] = accessmethod;
} else {
if ((accessmethod = accessors[issuperaccess ? 0 : 1]) == null) {
accessmethod = new syntheticmethodbinding(targetmethod, issuperaccess, this);
accessors[issuperaccess ? 0 : 1] = accessmethod;
}
}
return accessmethod;
}
/*
* record the fact that bridge methods need to be generated to override certain inherited methods
*/
public syntheticmethodbinding addsyntheticbridgemethod(methodbinding inheritedmethodtobridge, methodbinding targetmethod) {
if (isinterface()) return null; // only classes & enums get bridge methods
// targetmethod may be inherited
if (inheritedmethodtobridge.returntype.erasure() == targetmethod.returntype.erasure()
&& inheritedmethodtobridge.areparametererasuresequal(targetmethod)) {
return null; // do not need bridge method
}
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.method_emul] == null) {
this.synthetics[sourcetypebinding.method_emul] = new hashmap(5);
} else {
// check to see if there is another equivalent inheritedmethod already added
iterator synthmethods = this.synthetics[sourcetypebinding.method_emul].keyset().iterator();
while (synthmethods.hasnext()) {
object synthetic = synthmethods.next();
if (synthetic instanceof methodbinding) {
methodbinding method = (methodbinding) synthetic;
if (charoperation.equals(inheritedmethodtobridge.selector, method.selector)
&& inheritedmethodtobridge.returntype.erasure() == method.returntype.erasure()
&& inheritedmethodtobridge.areparametererasuresequal(method)) {
return null;
}
}
}
}

syntheticmethodbinding accessmethod = null;
syntheticmethodbinding[] accessors = (syntheticmethodbinding[]) this.synthetics[sourcetypebinding.method_emul].get(inheritedmethodtobridge);
if (accessors == null) {
accessmethod = new syntheticmethodbinding(inheritedmethodtobridge, targetmethod, this);
this.synthetics[sourcetypebinding.method_emul].put(inheritedmethodtobridge, accessors = new syntheticmethodbinding[2]);
accessors[1] = accessmethod;
} else {
if ((accessmethod = accessors[1]) == null) {
accessmethod = new syntheticmethodbinding(inheritedmethodtobridge, targetmethod, this);
accessors[1] = accessmethod;
}
}
return accessmethod;
}
/*
* https://bugs.eclipse.org/bugs/show_bug.cgi?id=288658. generate a bridge method if a public method is inherited
* from a non-public class into a public class (only in 1.6 or greater)
*/
public syntheticmethodbinding addsyntheticbridgemethod(methodbinding inheritedmethodtobridge) {
if (this.scope.compileroptions().compliancelevel <= classfileconstants.jdk1_5) {
return null;
}
if (isinterface()) return null;
if (inheritedmethodtobridge.isabstract() || inheritedmethodtobridge.isfinal() || inheritedmethodtobridge.isstatic()) {
return null;
}
if (this.synthetics == null)
this.synthetics = new hashmap[max_synthetics];
if (this.synthetics[sourcetypebinding.method_emul] == null) {
this.synthetics[sourcetypebinding.method_emul] = new hashmap(5);
} else {
// check to see if there is another equivalent inheritedmethod already added
iterator synthmethods = this.synthetics[sourcetypebinding.method_emul].keyset().iterator();
while (synthmethods.hasnext()) {
object synthetic = synthmethods.next();
if (synthetic instanceof methodbinding) {
methodbinding method = (methodbinding) synthetic;
if (charoperation.equals(inheritedmethodtobridge.selector, method.selector)
&& inheritedmethodtobridge.returntype.erasure() == method.returntype.erasure()
&& inheritedmethodtobridge.areparametererasuresequal(method)) {
return null;
}
}
}
}

syntheticmethodbinding accessmethod = null;
syntheticmethodbinding[] accessors = (syntheticmethodbinding[]) this.synthetics[sourcetypebinding.method_emul].get(inheritedmethodtobridge);
if (accessors == null) {
accessmethod = new syntheticmethodbinding(inheritedmethodtobridge, this);
this.synthetics[sourcetypebinding.method_emul].put(inheritedmethodtobridge, accessors = new syntheticmethodbinding[2]);
accessors[0] = accessmethod;
} else {
if ((accessmethod = accessors[0]) == null) {
accessmethod = new syntheticmethodbinding(inheritedmethodtobridge, this);
accessors[0] = accessmethod;
}
}
return accessmethod;
}
boolean arefieldsinitialized() {
return this.fields != binding.uninitialized_fields;
}
boolean aremethodsinitialized() {
return this.methods != binding.uninitialized_methods;
}
public int kind() {
if (this.typevariables != binding.no_type_variables) return binding.generic_type;
return binding.type;
}

public char[] computeuniquekey(boolean isleaf) {
char[] uniquekey = super.computeuniquekey(isleaf);
if (uniquekey.length == 2) return uniquekey; // problem type's unique key is "l;"
if (util.isclassfilename(this.filename)) return uniquekey; // no need to insert compilation unit name for a .class file

// insert compilation unit name if the type name is not the main type name
int end = charoperation.lastindexof('.', this.filename);
if (end != -1) {
int start = charoperation.lastindexof('/', this.filename) + 1;
char[] maintypename = charoperation.subarray(this.filename, start, end);
start = charoperation.lastindexof('/', uniquekey) + 1;
if (start == 0)
start = 1; // start after l
end = charoperation.indexof('$', uniquekey, start);
if (end == -1)
end = charoperation.indexof('<', uniquekey, start);
if (end == -1)
end = charoperation.indexof(';', uniquekey, start);
char[] topleveltype = charoperation.subarray(uniquekey, start, end);
if (!charoperation.equals(topleveltype, maintypename)) {
stringbuffer buffer = new stringbuffer();
buffer.append(uniquekey, 0, start);
buffer.append(maintypename);
buffer.append('~');
buffer.append(topleveltype);
buffer.append(uniquekey, end, uniquekey.length - end);
int length = buffer.length();
uniquekey = new char[length];
buffer.getchars(0, length, uniquekey, 0);
return uniquekey;
}
}
return uniquekey;
}

void faultintypesforfieldsandmethods() {
// check @@deprecated annotation
getannotationtagbits(); // marks as deprecated by side effect
referencebinding enclosingtype = enclosingtype();
if (enclosingtype != null && enclosingtype.isviewedasdeprecated() && !isdeprecated())
this.modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
fields();
methods();

for (int i = 0, length = this.membertypes.length; i < length; i++)
((sourcetypebinding) this.membertypes[i]).faultintypesforfieldsandmethods();
}
// note: the type of each field of a source type is resolved when needed
public fieldbinding[] fields() {
if ((this.tagbits & tagbits.arefieldscomplete) != 0)
return this.fields;

int failed = 0;
fieldbinding[] resolvedfields = this.fields;
try {
// lazily sort fields
if ((this.tagbits & tagbits.arefieldssorted) == 0) {
int length = this.fields.length;
if (length > 1)
referencebinding.sortfields(this.fields, 0, length);
this.tagbits |= tagbits.arefieldssorted;
}
for (int i = 0, length = this.fields.length; i < length; i++) {
if (resolvetypefor(this.fields[i]) == null) {
// do not alter original field array until resolution is over, due to reentrance (143259)
if (resolvedfields == this.fields) {
system.arraycopy(this.fields, 0, resolvedfields = new fieldbinding[length], 0, length);
}
resolvedfields[i] = null;
failed++;
}
}
} finally {
if (failed > 0) {
// ensure fields are consistent reqardless of the error
int newsize = resolvedfields.length - failed;
if (newsize == 0)
return this.fields = binding.no_fields;

fieldbinding[] newfields = new fieldbinding[newsize];
for (int i = 0, j = 0, length = resolvedfields.length; i < length; i++) {
if (resolvedfields[i] != null)
newfields[j++] = resolvedfields[i];
}
this.fields = newfields;
}
}
this.tagbits |= tagbits.arefieldscomplete;
return this.fields;
}
/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#generictypesignature()
*/
public char[] generictypesignature() {
if (this.genericreferencetypesignature == null)
this.genericreferencetypesignature = computegenerictypesignature(this.typevariables);
return this.genericreferencetypesignature;
}
/**
* <param1 ... paramn>superclass superinterface1 ... superinterfacen
* <t:ly<tt;>;u:ljava/lang/object;v::ljava/lang/runnable;:ljava/lang/cloneable;:ljava/util/map;>ljava/lang/exception;ljava/lang/runnable;
*/
public char[] genericsignature() {
stringbuffer sig = null;
if (this.typevariables != binding.no_type_variables) {
sig = new stringbuffer(10);
sig.append('<');
for (int i = 0, length = this.typevariables.length; i < length; i++)
sig.append(this.typevariables[i].genericsignature());
sig.append('>');
} else {
// could still need a signature if any of supertypes is parameterized
nosignature: if (this.superclass == null || !this.superclass.isparameterizedtype()) {
for (int i = 0, length = this.superinterfaces.length; i < length; i++)
if (this.superinterfaces[i].isparameterizedtype())
break nosignature;
return null;
}
sig = new stringbuffer(10);
}
if (this.superclass != null)
sig.append(this.superclass.generictypesignature());
else // interface scenario only (as object cannot be generic) - 65953
sig.append(this.scope.getjavalangobject().generictypesignature());
for (int i = 0, length = this.superinterfaces.length; i < length; i++)
sig.append(this.superinterfaces[i].generictypesignature());
return sig.tostring().tochararray();
}

/**
* compute the tagbits for standard annotations. for source types, these could require
* lazily resolving corresponding annotation nodes, in case of forward references.
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#getannotationtagbits()
*/
public long getannotationtagbits() {
if ((this.tagbits & tagbits.annotationresolved) == 0 && this.scope != null) {
typedeclaration typedecl = this.scope.referencecontext;
boolean old = typedecl.staticinitializerscope.insidetypeannotation;
try {
typedecl.staticinitializerscope.insidetypeannotation = true;
astnode.resolveannotations(typedecl.staticinitializerscope, typedecl.annotations, this);
} finally {
typedecl.staticinitializerscope.insidetypeannotation = old;
}
if ((this.tagbits & tagbits.annotationdeprecated) != 0)
this.modifiers |= classfileconstants.accdeprecated;
}
return this.tagbits;
}
public methodbinding[] getdefaultabstractmethods() {
int count = 0;
for (int i = this.methods.length; --i >= 0;)
if (this.methods[i].isdefaultabstract())
count++;
if (count == 0) return binding.no_methods;

methodbinding[] result = new methodbinding[count];
count = 0;
for (int i = this.methods.length; --i >= 0;)
if (this.methods[i].isdefaultabstract())
result[count++] = this.methods[i];
return result;
}
// note: the return type, arg & exception types of each method of a source type are resolved when needed
public methodbinding getexactconstructor(typebinding[] argumenttypes) {
int argcount = argumenttypes.length;
if ((this.tagbits & tagbits.aremethodscomplete) != 0) { // have resolved all arg types & return type of the methods
long range;
if ((range = referencebinding.binarysearch(typeconstants.init, this.methods)) >= 0) {
nextmethod: for (int imethod = (int)range, end = (int)(range >> 32); imethod <= end; imethod++) {
methodbinding method = this.methods[imethod];
if (method.parameters.length == argcount) {
typebinding[] tomatch = method.parameters;
for (int iarg = 0; iarg < argcount; iarg++)
if (tomatch[iarg] != argumenttypes[iarg])
continue nextmethod;
return method;
}
}
}
} else {
// lazily sort methods
if ((this.tagbits & tagbits.aremethodssorted) == 0) {
int length = this.methods.length;
if (length > 1)
referencebinding.sortmethods(this.methods, 0, length);
this.tagbits |= tagbits.aremethodssorted;
}
long range;
if ((range = referencebinding.binarysearch(typeconstants.init, this.methods)) >= 0) {
nextmethod: for (int imethod = (int)range, end = (int)(range >> 32); imethod <= end; imethod++) {
methodbinding method = this.methods[imethod];
if (resolvetypesfor(method) == null || method.returntype == null) {
methods();
return getexactconstructor(argumenttypes);  // try again since the problem methods have been removed
}
if (method.parameters.length == argcount) {
typebinding[] tomatch = method.parameters;
for (int iarg = 0; iarg < argcount; iarg++)
if (tomatch[iarg] != argumenttypes[iarg])
continue nextmethod;
return method;
}
}
}
}
return null;
}

//note: the return type, arg & exception types of each method of a source type are resolved when needed
//searches up the hierarchy as long as no potential (but not exact) match was found.
public methodbinding getexactmethod(char[] selector, typebinding[] argumenttypes, compilationunitscope refscope) {
// sender from refscope calls recordtypereference(this)
int argcount = argumenttypes.length;
boolean foundnothing = true;

if ((this.tagbits & tagbits.aremethodscomplete) != 0) { // have resolved all arg types & return type of the methods
long range;
if ((range = referencebinding.binarysearch(selector, this.methods)) >= 0) {
nextmethod: for (int imethod = (int)range, end = (int)(range >> 32); imethod <= end; imethod++) {
methodbinding method = this.methods[imethod];
foundnothing = false; // inner type lookups must know that a method with this name exists
if (method.parameters.length == argcount) {
typebinding[] tomatch = method.parameters;
for (int iarg = 0; iarg < argcount; iarg++)
if (tomatch[iarg] != argumenttypes[iarg])
continue nextmethod;
return method;
}
}
}
} else {
// lazily sort methods
if ((this.tagbits & tagbits.aremethodssorted) == 0) {
int length = this.methods.length;
if (length > 1)
referencebinding.sortmethods(this.methods, 0, length);
this.tagbits |= tagbits.aremethodssorted;
}

long range;
if ((range = referencebinding.binarysearch(selector, this.methods)) >= 0) {
// check unresolved method
int start = (int) range, end = (int) (range >> 32);
for (int imethod = start; imethod <= end; imethod++) {
methodbinding method = this.methods[imethod];
if (resolvetypesfor(method) == null || method.returntype == null) {
methods();
return getexactmethod(selector, argumenttypes, refscope); // try again since the problem methods have been removed
}
}
// check dup collisions
boolean issource15 = this.scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
for (int i = start; i <= end; i++) {
methodbinding method1 = this.methods[i];
for (int j = end; j > i; j--) {
methodbinding method2 = this.methods[j];
boolean paramsmatch = issource15
? method1.areparametererasuresequal(method2)
: method1.areparametersequal(method2);
if (paramsmatch) {
methods();
return getexactmethod(selector, argumenttypes, refscope); // try again since the problem methods have been removed
}
}
}
nextmethod: for (int imethod = start; imethod <= end; imethod++) {
methodbinding method = this.methods[imethod];
typebinding[] tomatch = method.parameters;
if (tomatch.length == argcount) {
for (int iarg = 0; iarg < argcount; iarg++)
if (tomatch[iarg] != argumenttypes[iarg])
continue nextmethod;
return method;
}
}
}
}

if (foundnothing) {
if (isinterface()) {
if (this.superinterfaces.length == 1) {
if (refscope != null)
refscope.recordtypereference(this.superinterfaces[0]);
return this.superinterfaces[0].getexactmethod(selector, argumenttypes, refscope);
}
} else if (this.superclass != null) {
if (refscope != null)
refscope.recordtypereference(this.superclass);
return this.superclass.getexactmethod(selector, argumenttypes, refscope);
}
}
return null;
}

//note: the type of a field of a source type is resolved when needed
public fieldbinding getfield(char[] fieldname, boolean needresolve) {

if ((this.tagbits & tagbits.arefieldscomplete) != 0)
return referencebinding.binarysearch(fieldname, this.fields);

// lazily sort fields
if ((this.tagbits & tagbits.arefieldssorted) == 0) {
int length = this.fields.length;
if (length > 1)
referencebinding.sortfields(this.fields, 0, length);
this.tagbits |= tagbits.arefieldssorted;
}
// always resolve anyway on source types
fieldbinding field = referencebinding.binarysearch(fieldname, this.fields);
if (field != null) {
fieldbinding result = null;
try {
result = resolvetypefor(field);
return result;
} finally {
if (result == null) {
// ensure fields are consistent reqardless of the error
int newsize = this.fields.length - 1;
if (newsize == 0) {
this.fields = binding.no_fields;
} else {
fieldbinding[] newfields = new fieldbinding[newsize];
int index = 0;
for (int i = 0, length = this.fields.length; i < length; i++) {
fieldbinding f = this.fields[i];
if (f == field) continue;
newfields[index++] = f;
}
this.fields = newfields;
}
}
}
}
return null;
}

// note: the return type, arg & exception types of each method of a source type are resolved when needed
public methodbinding[] getmethods(char[] selector) {
if ((this.tagbits & tagbits.aremethodscomplete) != 0) {
long range;
if ((range = referencebinding.binarysearch(selector, this.methods)) >= 0) {
int start = (int) range, end = (int) (range >> 32);
int length = end - start + 1;
methodbinding[] result;
system.arraycopy(this.methods, start, result = new methodbinding[length], 0, length);
return result;
} else {
return binding.no_methods;
}
}
// lazily sort methods
if ((this.tagbits & tagbits.aremethodssorted) == 0) {
int length = this.methods.length;
if (length > 1)
referencebinding.sortmethods(this.methods, 0, length);
this.tagbits |= tagbits.aremethodssorted;
}
methodbinding[] result;
long range;
if ((range = referencebinding.binarysearch(selector, this.methods)) >= 0) {
int start = (int) range, end = (int) (range >> 32);
for (int i = start; i <= end; i++) {
methodbinding method = this.methods[i];
if (resolvetypesfor(method) == null || method.returntype == null) {
methods();
return getmethods(selector); // try again since the problem methods have been removed
}
}
int length = end - start + 1;
system.arraycopy(this.methods, start, result = new methodbinding[length], 0, length);
} else {
return binding.no_methods;
}
boolean issource15 = this.scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
for (int i = 0, length = result.length - 1; i < length; i++) {
methodbinding method = result[i];
for (int j = length; j > i; j--) {
boolean paramsmatch = issource15
? method.areparametererasuresequal(result[j])
: method.areparametersequal(result[j]);
if (paramsmatch) {
methods();
return getmethods(selector); // try again since the duplicate methods have been removed
}
}
}
return result;
}
/* answer the synthetic field for <actualouterlocalvariable>
*	or null if one does not exist.
*/
public fieldbinding getsyntheticfield(localvariablebinding actualouterlocalvariable) {
if (this.synthetics == null || this.synthetics[sourcetypebinding.field_emul] == null) return null;
return (fieldbinding) this.synthetics[sourcetypebinding.field_emul].get(actualouterlocalvariable);
}
/* answer the synthetic field for <targetenclosingtype>
*	or null if one does not exist.
*/
public fieldbinding getsyntheticfield(referencebinding targetenclosingtype, boolean onlyexactmatch) {

if (this.synthetics == null || this.synthetics[sourcetypebinding.field_emul] == null) return null;
fieldbinding field = (fieldbinding) this.synthetics[sourcetypebinding.field_emul].get(targetenclosingtype);
if (field != null) return field;

// type compatibility : to handle cases such as
// class t { class m{}}
// class s extends t { class n extends m {}} --> need to use s as a default enclosing instance for the super constructor call in n().
if (!onlyexactmatch){
iterator accessfields = this.synthetics[sourcetypebinding.field_emul].values().iterator();
while (accessfields.hasnext()) {
field = (fieldbinding) accessfields.next();
if (charoperation.prefixequals(typeconstants.synthetic_enclosing_instance_prefix, field.name)
&& field.type.findsupertypeoriginatingfrom(targetenclosingtype) != null)
return field;
}
}
return null;
}
/*
* answer the bridge method associated for an  inherited methods or null if one does not exist
*/
public syntheticmethodbinding getsyntheticbridgemethod(methodbinding inheritedmethodtobridge) {
if (this.synthetics == null) return null;
if (this.synthetics[sourcetypebinding.method_emul] == null) return null;
syntheticmethodbinding[] accessors = (syntheticmethodbinding[]) this.synthetics[sourcetypebinding.method_emul].get(inheritedmethodtobridge);
if (accessors == null) return null;
return accessors[1];
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#initializedeprecatedannotationtagbits()
*/
public void initializedeprecatedannotationtagbits() {
if ((this.tagbits & tagbits.deprecatedannotationresolved) == 0) {
typedeclaration typedecl = this.scope.referencecontext;
boolean old = typedecl.staticinitializerscope.insidetypeannotation;
try {
typedecl.staticinitializerscope.insidetypeannotation = true;
astnode.resolvedeprecatedannotations(typedecl.staticinitializerscope, typedecl.annotations, this);
this.tagbits |= tagbits.deprecatedannotationresolved;
} finally {
typedecl.staticinitializerscope.insidetypeannotation = old;
}
if ((this.tagbits & tagbits.annotationdeprecated) != 0) {
this.modifiers |= classfileconstants.accdeprecated;
}
}
}

// ensure the receiver knows its hierarchy & fields/methods so static imports can be resolved correctly
// see bug 230026
void initializeforstaticimports() {
if (this.scope == null) return; // already initialized

if (this.superinterfaces == null)
this.scope.connecttypehierarchy();
this.scope.buildfields();
this.scope.buildmethods();
}

/**
* returns true if a type is identical to another one,
* or for generic types, true if compared to its raw type.
*/
public boolean isequivalentto(typebinding othertype) {

if (this == othertype) return true;
if (othertype == null) return false;
switch(othertype.kind()) {

case binding.wildcard_type :
case binding.intersection_type:
return ((wildcardbinding) othertype).boundcheck(this);

case binding.parameterized_type :
if ((othertype.tagbits & tagbits.hasdirectwildcard) == 0 && (!ismembertype() || !othertype.ismembertype()))
return false; // should have been identical
parameterizedtypebinding otherparamtype = (parameterizedtypebinding) othertype;
if (this != otherparamtype.generictype())
return false;
if (!isstatic()) { // static member types do not compare their enclosing
referencebinding enclosing = enclosingtype();
if (enclosing != null) {
referencebinding otherenclosing = otherparamtype.enclosingtype();
if (otherenclosing == null) return false;
if ((otherenclosing.tagbits & tagbits.hasdirectwildcard) == 0) {
if (enclosing != otherenclosing) return false;
} else {
if (!enclosing.isequivalentto(otherparamtype.enclosingtype())) return false;
}
}
}
int length = this.typevariables == null ? 0 : this.typevariables.length;
typebinding[] otherarguments = otherparamtype.arguments;
int otherlength = otherarguments == null ? 0 : otherarguments.length;
if (otherlength != length)
return false;
for (int i = 0; i < length; i++)
if (!this.typevariables[i].istypeargumentcontainedby(otherarguments[i]))
return false;
return true;

case binding.raw_type :
return othertype.erasure() == this;
}
return false;
}
public boolean isgenerictype() {
return this.typevariables != binding.no_type_variables;
}
public boolean ishierarchyconnected() {
return (this.tagbits & tagbits.endhierarchycheck) != 0;
}
public referencebinding[] membertypes() {
return this.membertypes;
}

public boolean hasmembertypes() {
return this.membertypes.length > 0;
}

// note: the return type, arg & exception types of each method of a source type are resolved when needed
public methodbinding[] methods() {
if ((this.tagbits & tagbits.aremethodscomplete) != 0)
return this.methods;

// lazily sort methods
if ((this.tagbits & tagbits.aremethodssorted) == 0) {
int length = this.methods.length;
if (length > 1)
referencebinding.sortmethods(this.methods, 0, length);
this.tagbits |= tagbits.aremethodssorted;
}

int failed = 0;
methodbinding[] resolvedmethods = this.methods;
try {
for (int i = 0, length = this.methods.length; i < length; i++) {
if (resolvetypesfor(this.methods[i]) == null) {
// do not alter original method array until resolution is over, due to reentrance (143259)
if (resolvedmethods == this.methods) {
system.arraycopy(this.methods, 0, resolvedmethods = new methodbinding[length], 0, length);
}
resolvedmethods[i] = null; // unable to resolve parameters
failed++;
}
}

// find & report collision cases
boolean complyto15 = this.scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
for (int i = 0, length = this.methods.length; i < length; i++) {
methodbinding method = resolvedmethods[i];
if (method == null)
continue;
char[] selector = method.selector;
abstractmethoddeclaration methoddecl = null;
nextsibling: for (int j = i + 1; j < length; j++) {
methodbinding method2 = resolvedmethods[j];
if (method2 == null)
continue nextsibling;
if (!charoperation.equals(selector, method2.selector))
break nextsibling; // methods with same selector are contiguous

if (complyto15 ? !method.areparametererasuresequal(method2) : !method.areparametersequal(method2))
continue nextsibling; // otherwise duplicates / name clash
boolean isenumspecialmethod = isenum() && (charoperation.equals(selector,typeconstants.valueof) || charoperation.equals(selector,typeconstants.values));
// report duplicate
boolean removemethod2 = true;
if (methoddecl == null) {
methoddecl = method.sourcemethod(); // cannot be retrieved after binding is lost & may still be null if method is special
if (methoddecl != null && methoddecl.binding != null) { // ensure its a valid user defined method
boolean removemethod = method.returntype == null && method2.returntype != null;
if (isenumspecialmethod) {
this.scope.problemreporter().duplicateenumspecialmethod(this, methoddecl);
// remove user defined methods & keep the synthetic
removemethod = true;
} else {
this.scope.problemreporter().duplicatemethodintype(this, methoddecl, method.areparametersequal(method2));
}
if (removemethod) {
removemethod2 = false;
methoddecl.binding = null;
// do not alter original method array until resolution is over, due to reentrance (143259)
if (resolvedmethods == this.methods)
system.arraycopy(this.methods, 0, resolvedmethods = new methodbinding[length], 0, length);
resolvedmethods[i] = null;
failed++;
}
}
}
abstractmethoddeclaration method2decl = method2.sourcemethod();
if (method2decl != null && method2decl.binding != null) { // ensure its a valid user defined method
if (isenumspecialmethod) {
this.scope.problemreporter().duplicateenumspecialmethod(this, method2decl);
removemethod2 = true;
} else {
this.scope.problemreporter().duplicatemethodintype(this, method2decl, method.areparametersequal(method2));
}
if (removemethod2) {
method2decl.binding = null;
// do not alter original method array until resolution is over, due to reentrance (143259)
if (resolvedmethods == this.methods)
system.arraycopy(this.methods, 0, resolvedmethods = new methodbinding[length], 0, length);
resolvedmethods[j] = null;
failed++;
}
}
}
if (method.returntype == null && resolvedmethods[i] != null) { // forget method with invalid return type... was kept to detect possible collisions
methoddecl = method.sourcemethod();
if (methoddecl != null)
methoddecl.binding = null;
// do not alter original method array until resolution is over, due to reentrance (143259)
if (resolvedmethods == this.methods)
system.arraycopy(this.methods, 0, resolvedmethods = new methodbinding[length], 0, length);
resolvedmethods[i] = null;
failed++;
}
}
} finally {
if (failed > 0) {
int newsize = resolvedmethods.length - failed;
if (newsize == 0) {
this.methods = binding.no_methods;
} else {
methodbinding[] newmethods = new methodbinding[newsize];
for (int i = 0, j = 0, length = resolvedmethods.length; i < length; i++)
if (resolvedmethods[i] != null)
newmethods[j++] = resolvedmethods[i];
this.methods = newmethods;
}
}

// handle forward references to potential default abstract methods
adddefaultabstractmethods();
this.tagbits |= tagbits.aremethodscomplete;
}
return this.methods;
}
public fieldbinding resolvetypefor(fieldbinding field) {
if ((field.modifiers & extracompilermodifiers.accunresolved) == 0)
return field;

if (this.scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
if ((field.getannotationtagbits() & tagbits.annotationdeprecated) != 0)
field.modifiers |= classfileconstants.accdeprecated;
}
if (isviewedasdeprecated() && !field.isdeprecated())
field.modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
if (hasrestrictedaccess())
field.modifiers |= extracompilermodifiers.accrestrictedaccess;
fielddeclaration[] fielddecls = this.scope.referencecontext.fields;
for (int f = 0, length = fielddecls.length; f < length; f++) {
if (fielddecls[f].binding != field)
continue;

methodscope initializationscope = field.isstatic()
? this.scope.referencecontext.staticinitializerscope
: this.scope.referencecontext.initializerscope;
fieldbinding previousfield = initializationscope.initializedfield;
try {
initializationscope.initializedfield = field;
fielddeclaration fielddecl = fielddecls[f];
typebinding fieldtype =
fielddecl.getkind() == abstractvariabledeclaration.enum_constant
? initializationscope.environment().converttorawtype(this, false /*do not force conversion of enclosing types*/) // enum constant is implicitly of declaring enum type
: fielddecl.type.resolvetype(initializationscope, true /* check bounds*/);
field.type = fieldtype;
field.modifiers &= ~extracompilermodifiers.accunresolved;
if (fieldtype == null) {
fielddecl.binding = null;
return null;
}
if (fieldtype == typebinding.void) {
this.scope.problemreporter().variabletypecannotbevoid(fielddecl);
fielddecl.binding = null;
return null;
}
if (fieldtype.isarraytype() && ((arraybinding) fieldtype).leafcomponenttype == typebinding.void) {
this.scope.problemreporter().variabletypecannotbevoidarray(fielddecl);
fielddecl.binding = null;
return null;
}
if ((fieldtype.tagbits & tagbits.hasmissingtype) != 0) {
field.tagbits |= tagbits.hasmissingtype;
}
typebinding leaftype = fieldtype.leafcomponenttype();
if (leaftype instanceof referencebinding && (((referencebinding)leaftype).modifiers & extracompilermodifiers.accgenericsignature) != 0) {
field.modifiers |= extracompilermodifiers.accgenericsignature;
}
} finally {
initializationscope.initializedfield = previousfield;
}
return field;
}
return null; // should never reach this point
}
public methodbinding resolvetypesfor(methodbinding method) {
if ((method.modifiers & extracompilermodifiers.accunresolved) == 0)
return method;

if (this.scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
if ((method.getannotationtagbits() & tagbits.annotationdeprecated) != 0)
method.modifiers |= classfileconstants.accdeprecated;
}
if (isviewedasdeprecated() && !method.isdeprecated())
method.modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
if (hasrestrictedaccess())
method.modifiers |= extracompilermodifiers.accrestrictedaccess;

abstractmethoddeclaration methoddecl = method.sourcemethod();
if (methoddecl == null) return null; // method could not be resolved in previous iteration

typeparameter[] typeparameters = methoddecl.typeparameters();
if (typeparameters != null) {
methoddecl.scope.connecttypevariables(typeparameters, true);
// perform deferred bound checks for type variables (only done after type variable hierarchy is connected)
for (int i = 0, paramlength = typeparameters.length; i < paramlength; i++)
typeparameters[i].checkbounds(methoddecl.scope);
}
typereference[] exceptiontypes = methoddecl.thrownexceptions;
if (exceptiontypes != null) {
int size = exceptiontypes.length;
method.thrownexceptions = new referencebinding[size];
int count = 0;
referencebinding resolvedexceptiontype;
for (int i = 0; i < size; i++) {
resolvedexceptiontype = (referencebinding) exceptiontypes[i].resolvetype(methoddecl.scope, true /* check bounds*/);
if (resolvedexceptiontype == null)
continue;
if (resolvedexceptiontype.isboundparameterizedtype()) {
methoddecl.scope.problemreporter().invalidparameterizedexceptiontype(resolvedexceptiontype, exceptiontypes[i]);
continue;
}
if (resolvedexceptiontype.findsupertypeoriginatingfrom(typeids.t_javalangthrowable, true) == null) {
if (resolvedexceptiontype.isvalidbinding()) {
methoddecl.scope.problemreporter().cannotthrowtype(exceptiontypes[i], resolvedexceptiontype);
continue;
}
}
if ((resolvedexceptiontype.tagbits & tagbits.hasmissingtype) != 0) {
method.tagbits |= tagbits.hasmissingtype;
}
method.modifiers |= (resolvedexceptiontype.modifiers & extracompilermodifiers.accgenericsignature);
method.thrownexceptions[count++] = resolvedexceptiontype;
}
if (count < size)
system.arraycopy(method.thrownexceptions, 0, method.thrownexceptions = new referencebinding[count], 0, count);
}

boolean foundargproblem = false;
argument[] arguments = methoddecl.arguments;
if (arguments != null) {
int size = arguments.length;
method.parameters = binding.no_parameters;
typebinding[] newparameters = new typebinding[size];
for (int i = 0; i < size; i++) {
argument arg = arguments[i];
if (arg.annotations != null) {
method.tagbits |= tagbits.hasparameterannotations;
}
typebinding parametertype = arg.type.resolvetype(methoddecl.scope, true /* check bounds*/);
if (parametertype == null) {
foundargproblem = true;
} else if (parametertype == typebinding.void) {
methoddecl.scope.problemreporter().argumenttypecannotbevoid(this, methoddecl, arg);
foundargproblem = true;
} else {
if ((parametertype.tagbits & tagbits.hasmissingtype) != 0) {
method.tagbits |= tagbits.hasmissingtype;
}
typebinding leaftype = parametertype.leafcomponenttype();
if (leaftype instanceof referencebinding && (((referencebinding) leaftype).modifiers & extracompilermodifiers.accgenericsignature) != 0)
method.modifiers |= extracompilermodifiers.accgenericsignature;
newparameters[i] = parametertype;
arg.binding = new localvariablebinding(arg, parametertype, arg.modifiers, true);
}
}
// only assign parameters if no problems are found
if (!foundargproblem) {
method.parameters = newparameters;
}
}

boolean foundreturntypeproblem = false;
if (!method.isconstructor()) {
typereference returntype = methoddecl instanceof methoddeclaration
? ((methoddeclaration) methoddecl).returntype
: null;
if (returntype == null) {
methoddecl.scope.problemreporter().missingreturntype(methoddecl);
method.returntype = null;
foundreturntypeproblem = true;
} else {
typebinding methodtype = returntype.resolvetype(methoddecl.scope, true /* check bounds*/);
if (methodtype == null) {
foundreturntypeproblem = true;
} else if (methodtype.isarraytype() && ((arraybinding) methodtype).leafcomponenttype == typebinding.void) {
methoddecl.scope.problemreporter().returntypecannotbevoidarray((methoddeclaration) methoddecl);
foundreturntypeproblem = true;
} else {
if ((methodtype.tagbits & tagbits.hasmissingtype) != 0) {
method.tagbits |= tagbits.hasmissingtype;
}
method.returntype = methodtype;
typebinding leaftype = methodtype.leafcomponenttype();
if (leaftype instanceof referencebinding && (((referencebinding) leaftype).modifiers & extracompilermodifiers.accgenericsignature) != 0)
method.modifiers |= extracompilermodifiers.accgenericsignature;
}
}
}
if (foundargproblem) {
methoddecl.binding = null;
method.parameters = binding.no_parameters; // see 107004
// nullify type parameter bindings as well as they have a backpointer to the method binding
// (see https://bugs.eclipse.org/bugs/show_bug.cgi?id=81134)
if (typeparameters != null)
for (int i = 0, length = typeparameters.length; i < length; i++)
typeparameters[i].binding = null;
return null;
}
if (foundreturntypeproblem)
return method; // but its still unresolved with a null return type & is still connected to its method declaration

method.modifiers &= ~extracompilermodifiers.accunresolved;
return method;
}
public annotationholder retrieveannotationholder(binding binding, boolean forceinitialization) {
if (forceinitialization)
binding.getannotationtagbits(); // ensure annotations are up to date
return super.retrieveannotationholder(binding, false);
}
public void setfields(fieldbinding[] fields) {
this.fields = fields;
}
public void setmethods(methodbinding[] methods) {
this.methods = methods;
}
public final int sourceend() {
return this.scope.referencecontext.sourceend;
}
public final int sourcestart() {
return this.scope.referencecontext.sourcestart;
}
simplelookuptable storedannotations(boolean forceinitialize) {
if (forceinitialize && this.storedannotations == null && this.scope != null) { // scope null when no annotation cached, and type got processed fully (159631)
this.scope.referencecompilationunit().compilationresult.hasannotations = true;
if (!this.scope.environment().globaloptions.storeannotations)
return null; // not supported during this compile
this.storedannotations = new simplelookuptable(3);
}
return this.storedannotations;
}
public referencebinding superclass() {
return this.superclass;
}
public referencebinding[] superinterfaces() {
return this.superinterfaces;
}

public syntheticmethodbinding[] syntheticmethods() {
if (this.synthetics == null
|| this.synthetics[sourcetypebinding.method_emul] == null
|| this.synthetics[sourcetypebinding.method_emul].size() == 0) {
return null;
}
// difficult to compute size up front because of the embedded arrays so assume there is only 1
int index = 0;
syntheticmethodbinding[] bindings = new syntheticmethodbinding[1];
iterator methodarrayiterator = this.synthetics[sourcetypebinding.method_emul].values().iterator();
while (methodarrayiterator.hasnext()) {
syntheticmethodbinding[] methodaccessors = (syntheticmethodbinding[]) methodarrayiterator.next();
for (int i = 0, max = methodaccessors.length; i < max; i++) {
if (methodaccessors[i] != null) {
if (index+1 > bindings.length) {
system.arraycopy(bindings, 0, (bindings = new syntheticmethodbinding[index + 1]), 0, index);
}
bindings[index++] = methodaccessors[i];
}
}
}
// sort them in according to their own indexes
int length;
syntheticmethodbinding[] sortedbindings = new syntheticmethodbinding[length = bindings.length];
for (int i = 0; i < length; i++){
syntheticmethodbinding binding = bindings[i];
sortedbindings[binding.index] = binding;
}
return sortedbindings;
}
/**
* answer the collection of synthetic fields to append into the classfile
*/
public fieldbinding[] syntheticfields() {
if (this.synthetics == null) return null;
int fieldsize = this.synthetics[sourcetypebinding.field_emul] == null ? 0 : this.synthetics[sourcetypebinding.field_emul].size();
int literalsize = this.synthetics[sourcetypebinding.class_literal_emul] == null ? 0 :this.synthetics[sourcetypebinding.class_literal_emul].size();
int totalsize = fieldsize + literalsize;
if (totalsize == 0) return null;
fieldbinding[] bindings = new fieldbinding[totalsize];

// add innerclass synthetics
if (this.synthetics[sourcetypebinding.field_emul] != null){
iterator elements = this.synthetics[sourcetypebinding.field_emul].values().iterator();
for (int i = 0; i < fieldsize; i++) {
syntheticfieldbinding synthbinding = (syntheticfieldbinding) elements.next();
bindings[synthbinding.index] = synthbinding;
}
}
// add class literal synthetics
if (this.synthetics[sourcetypebinding.class_literal_emul] != null){
iterator elements = this.synthetics[sourcetypebinding.class_literal_emul].values().iterator();
for (int i = 0; i < literalsize; i++) {
syntheticfieldbinding synthbinding = (syntheticfieldbinding) elements.next();
bindings[fieldsize+synthbinding.index] = synthbinding;
}
}
return bindings;
}
public string tostring() {
stringbuffer buffer = new stringbuffer(30);
buffer.append("(id="); //$non-nls-1$
if (this.id == typeids.noid)
buffer.append("noid"); //$non-nls-1$
else
buffer.append(this.id);
buffer.append(")\n"); //$non-nls-1$
if (isdeprecated()) buffer.append("deprecated "); //$non-nls-1$
if (ispublic()) buffer.append("public "); //$non-nls-1$
if (isprotected()) buffer.append("protected "); //$non-nls-1$
if (isprivate()) buffer.append("private "); //$non-nls-1$
if (isabstract() && isclass()) buffer.append("abstract "); //$non-nls-1$
if (isstatic() && isnestedtype()) buffer.append("static "); //$non-nls-1$
if (isfinal()) buffer.append("final "); //$non-nls-1$

if (isenum()) buffer.append("enum "); //$non-nls-1$
else if (isannotationtype()) buffer.append("@@interface "); //$non-nls-1$
else if (isclass()) buffer.append("class "); //$non-nls-1$
else buffer.append("interface "); //$non-nls-1$
buffer.append((this.compoundname != null) ? charoperation.tostring(this.compoundname) : "unnamed type"); //$non-nls-1$

if (this.typevariables == null) {
buffer.append("<null type variables>"); //$non-nls-1$
} else if (this.typevariables != binding.no_type_variables) {
buffer.append("<"); //$non-nls-1$
for (int i = 0, length = this.typevariables.length; i < length; i++) {
if (i  > 0) buffer.append(", "); //$non-nls-1$
if (this.typevariables[i] == null) {
buffer.append("null type variable"); //$non-nls-1$
continue;
}
char[] varchars = this.typevariables[i].tostring().tochararray();
buffer.append(varchars, 1, varchars.length - 2);
}
buffer.append(">"); //$non-nls-1$
}
buffer.append("\n\textends "); //$non-nls-1$
buffer.append((this.superclass != null) ? this.superclass.debugname() : "null type"); //$non-nls-1$

if (this.superinterfaces != null) {
if (this.superinterfaces != binding.no_superinterfaces) {
buffer.append("\n\timplements : "); //$non-nls-1$
for (int i = 0, length = this.superinterfaces.length; i < length; i++) {
if (i  > 0)
buffer.append(", "); //$non-nls-1$
buffer.append((this.superinterfaces[i] != null) ? this.superinterfaces[i].debugname() : "null type"); //$non-nls-1$
}
}
} else {
buffer.append("null superinterfaces"); //$non-nls-1$
}

if (enclosingtype() != null) {
buffer.append("\n\tenclosing type : "); //$non-nls-1$
buffer.append(enclosingtype().debugname());
}

if (this.fields != null) {
if (this.fields != binding.no_fields) {
buffer.append("\n/*   fields   */"); //$non-nls-1$
for (int i = 0, length = this.fields.length; i < length; i++)
buffer.append('\n').append((this.fields[i] != null) ? this.fields[i].tostring() : "null field"); //$non-nls-1$
}
} else {
buffer.append("null fields"); //$non-nls-1$
}

if (this.methods != null) {
if (this.methods != binding.no_methods) {
buffer.append("\n/*   methods   */"); //$non-nls-1$
for (int i = 0, length = this.methods.length; i < length; i++)
buffer.append('\n').append((this.methods[i] != null) ? this.methods[i].tostring() : "null method"); //$non-nls-1$
}
} else {
buffer.append("null methods"); //$non-nls-1$
}

if (this.membertypes != null) {
if (this.membertypes != binding.no_member_types) {
buffer.append("\n/*   members   */"); //$non-nls-1$
for (int i = 0, length = this.membertypes.length; i < length; i++)
buffer.append('\n').append((this.membertypes[i] != null) ? this.membertypes[i].tostring() : "null type"); //$non-nls-1$
}
} else {
buffer.append("null member types"); //$non-nls-1$
}

buffer.append("\n\n"); //$non-nls-1$
return buffer.tostring();
}
public typevariablebinding[] typevariables() {
return this.typevariables != null ? this.typevariables : binding.no_type_variables;
}
void verifymethods(methodverifier verifier) {
verifier.verify(this);

for (int i = this.membertypes.length; --i >= 0;)
((sourcetypebinding) this.membertypes[i]).verifymethods(verifier);
}

public fieldbinding[] unresolvedfields() {
return this.fields;
}
}
