/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.codegen.branchlabel;
import org.eclipse.jdt.internal.compiler.impl.booleanconstant;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class trueliteral extends magicliteral {

static final char[] source = {'t' , 'r' , 'u' , 'e'};

public trueliteral(int s , int e) {
super(s,e);
}
public void computeconstant() {
this.constant = booleanconstant.fromvalue(true);
}
/**
* code generation for the true literal
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
if (valuerequired) {
codestream.generateconstant(this.constant, this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}
public void generateoptimizedboolean(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {

// truelabel being not nil means that we will not fall through into the true case

int pc = codestream.position;
// constant == true
if (valuerequired) {
if (falselabel == null) {
// implicit falling through the false case
if (truelabel != null) {
codestream.goto_(truelabel);
}
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}
public typebinding literaltype(blockscope scope) {
return typebinding.boolean;
}
/**
*
*/
public char[] source() {
return source;
}
public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
