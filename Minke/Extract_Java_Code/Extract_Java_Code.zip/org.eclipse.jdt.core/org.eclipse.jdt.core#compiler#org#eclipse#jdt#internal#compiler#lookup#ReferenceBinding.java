/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.util.arrays;
import java.util.comparator;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.methoddeclaration;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.util.simplelookuptable;

/*
not all fields defined by this type (& its subclasses) are initialized when it is created.
some are initialized only when needed.

accessors have been provided for some public fields so all typebindings have the same api...
but access public fields directly whenever possible.
non-public fields have accessors which should be used everywhere you expect the field to be initialized.

null is not a valid value for a non-public field... it just means the field is not initialized.
*/

abstract public class referencebinding extends typebinding {

public char[][] compoundname;
public char[] sourcename;
public int modifiers;
public packagebinding fpackage;
char[] filename;
char[] constantpoolname;
char[] signature;

private simplelookuptable compatiblecache;

public static final referencebinding lub_generic = new referencebinding() { /* used for lub computation */};

private static final comparator field_comparator = new comparator() {
public int compare(object o1, object o2) {
char[] n1 = ((fieldbinding) o1).name;
char[] n2 = ((fieldbinding) o2).name;
return referencebinding.compare(n1, n2, n1.length, n2.length);
}
};
private static final comparator method_comparator = new comparator() {
public int compare(object o1, object o2) {
methodbinding m1 = (methodbinding) o1;
methodbinding m2 = (methodbinding) o2;
char[] s1 = m1.selector;
char[] s2 = m2.selector;
int c = referencebinding.compare(s1, s2, s1.length, s2.length);
return c == 0 ? m1.parameters.length - m2.parameters.length : c;
}
};

public static fieldbinding binarysearch(char[] name, fieldbinding[] sortedfields) {
if (sortedfields == null)
return null;
int max = sortedfields.length;
if (max == 0)
return null;
int left = 0, right = max - 1, namelength = name.length;
int mid = 0;
char[] midname;
while (left <= right) {
mid = left + (right - left) /2;
int compare = compare(name, midname = sortedfields[mid].name, namelength, midname.length);
if (compare < 0) {
right = mid-1;
} else if (compare > 0) {
left = mid+1;
} else {
return sortedfields[mid];
}
}
return null;
}

/**
* returns a combined range value representing: (start + (end<<32)), where start is the index of the first matching method
* (remember methods are sorted alphabetically on selectors), and end is the index of last contiguous methods with same
* selector.
* -1 means no method got found
* @@param selector
* @@param sortedmethods
* @@return (start + (end<<32)) or -1 if no method found
*/
public static long binarysearch(char[] selector, methodbinding[] sortedmethods) {
if (sortedmethods == null)
return -1;
int max = sortedmethods.length;
if (max == 0)
return -1;
int left = 0, right = max - 1, selectorlength = selector.length;
int mid = 0;
char[] midselector;
while (left <= right) {
mid = left + (right - left) /2;
int compare = compare(selector, midselector = sortedmethods[mid].selector, selectorlength, midselector.length);
if (compare < 0) {
right = mid-1;
} else if (compare > 0) {
left = mid+1;
} else {
int start = mid, end = mid;
// find first method with same selector
while (start > left && charoperation.equals(sortedmethods[start-1].selector, selector)){ start--; }
// find last method with same selector
while (end < right && charoperation.equals(sortedmethods[end+1].selector, selector)){ end++; }
return start + ((long)end<< 32);
}
}
return -1;
}

/**
* compares two strings lexicographically.
* the comparison is based on the unicode value of each character in
* the strings.
*
* @@return  the value <code>0</code> if the str1 is equal to str2;
*          a value less than <code>0</code> if str1
*          is lexicographically less than str2;
*          and a value greater than <code>0</code> if str1 is
*          lexicographically greater than str2.
*/
static int compare(char[] str1, char[] str2, int len1, int len2) {
int n= math.min(len1, len2);
int i= 0;
while (n-- != 0) {
char c1= str1[i];
char c2= str2[i++];
if (c1 != c2) {
return c1 - c2;
}
}
return len1 - len2;
}

/**
* sort the field array using a quicksort
*/
public static void sortfields(fieldbinding[] sortedfields, int left, int right) {
arrays.sort(sortedfields, left, right, field_comparator);
}

/**
* sort the field array using a quicksort
*/
public static void sortmethods(methodbinding[] sortedmethods, int left, int right) {
arrays.sort(sortedmethods, left, right, method_comparator);
}

/**
* return the array of resolvable fields (resilience)
*/
public fieldbinding[] availablefields() {
return fields();
}

/**
* return the array of resolvable methods (resilience)
*/
public methodbinding[] availablemethods() {
return methods();
}

/**
* answer true if the receiver can be instantiated
*/
public boolean canbeinstantiated() {
return (this.modifiers & (classfileconstants.accabstract | classfileconstants.accinterface | classfileconstants.accenum | classfileconstants.accannotation)) == 0;
}

/**
* answer true if the receiver is visible to the invocationpackage.
*/
public final boolean canbeseenby(packagebinding invocationpackage) {
if (ispublic()) return true;
if (isprivate()) return false;

// isprotected() or isdefault()
return invocationpackage == this.fpackage;
}

/**
* answer true if the receiver is visible to the receivertype and the invocationtype.
*/
public final boolean canbeseenby(referencebinding receivertype, referencebinding invocationtype) {
if (ispublic()) return true;

if (invocationtype == this && invocationtype == receivertype) return true;

if (isprotected()) {
// answer true if the invocationtype is the declaringclass or they are in the same package
// or the invocationtype is a subclass of the declaringclass
//    and the invocationtype is the invocationtype or its subclass
//    or the type is a static method accessed directly through a type
//    or previous assertions are true for one of the enclosing type
if (invocationtype == this) return true;
if (invocationtype.fpackage == this.fpackage) return true;

typebinding currenttype = invocationtype.erasure();
typebinding declaringclass = enclosingtype().erasure(); // protected types always have an enclosing one
if (declaringclass == invocationtype) return true;
if (declaringclass == null) return false; // could be null if incorrect top-level protected type
//int depth = 0;
do {
if (currenttype.findsupertypeoriginatingfrom(declaringclass) != null) return true;
//depth++;
currenttype = currenttype.enclosingtype();
} while (currenttype != null);
return false;
}

if (isprivate()) {
// answer true if the receivertype is the receiver or its enclosingtype
// and the invocationtype and the receiver have a common enclosingtype
receivercheck: {
if (!(receivertype == this || receivertype == enclosingtype())) {
// special tolerance for type variable direct bounds
if (receivertype.istypevariable()) {
typevariablebinding typevariable = (typevariablebinding) receivertype;
if (typevariable.iserasureboundto(erasure()) || typevariable.iserasureboundto(enclosingtype().erasure()))
break receivercheck;
}
return false;
}
}

if (invocationtype != this) {
referencebinding outerinvocationtype = invocationtype;
referencebinding temp = outerinvocationtype.enclosingtype();
while (temp != null) {
outerinvocationtype = temp;
temp = temp.enclosingtype();
}

referencebinding outerdeclaringclass = (referencebinding)erasure();
temp = outerdeclaringclass.enclosingtype();
while (temp != null) {
outerdeclaringclass = temp;
temp = temp.enclosingtype();
}
if (outerinvocationtype != outerdeclaringclass) return false;
}
return true;
}

// isdefault()
if (invocationtype.fpackage != this.fpackage) return false;

referencebinding currenttype = receivertype;
typebinding originaldeclaringclass = (enclosingtype() == null ? this : enclosingtype()).original();
do {
if (currenttype.iscapture()) {  // https://bugs.eclipse.org/bugs/show_bug.cgi?id=285002
if (originaldeclaringclass == currenttype.erasure().original()) return true;
} else {
if (originaldeclaringclass == currenttype.original()) return true;
}
packagebinding currentpackage = currenttype.fpackage;
// package could be null for wildcards/intersection types, ignore and recurse in superclass
if (currentpackage != null && currentpackage != this.fpackage) return false;
} while ((currenttype = currenttype.superclass()) != null);
return false;
}

/**
* answer true if the receiver is visible to the type provided by the scope.
*/
public final boolean canbeseenby(scope scope) {
if (ispublic()) return true;

sourcetypebinding invocationtype = scope.enclosingsourcetype();
if (invocationtype == this) return true;

if (invocationtype == null) // static import call
return !isprivate() && scope.getcurrentpackage() == this.fpackage;

if (isprotected()) {
// answer true if the invocationtype is the declaringclass or they are in the same package
// or the invocationtype is a subclass of the declaringclass
//    and the invocationtype is the invocationtype or its subclass
//    or the type is a static method accessed directly through a type
//    or previous assertions are true for one of the enclosing type
if (invocationtype.fpackage == this.fpackage) return true;

typebinding declaringclass = enclosingtype(); // protected types always have an enclosing one
if (declaringclass == null) return false; // could be null if incorrect top-level protected type
declaringclass = declaringclass.erasure();// erasure cannot be null
typebinding currenttype = invocationtype.erasure();
// int depth = 0;
do {
if (declaringclass == invocationtype) return true;
if (currenttype.findsupertypeoriginatingfrom(declaringclass) != null) return true;
// depth++;
currenttype = currenttype.enclosingtype();
} while (currenttype != null);
return false;
}
if (isprivate()) {
// answer true if the receiver and the invocationtype have a common enclosingtype
// already know they are not the identical type
referencebinding outerinvocationtype = invocationtype;
referencebinding temp = outerinvocationtype.enclosingtype();
while (temp != null) {
outerinvocationtype = temp;
temp = temp.enclosingtype();
}

referencebinding outerdeclaringclass = (referencebinding)erasure();
temp = outerdeclaringclass.enclosingtype();
while (temp != null) {
outerdeclaringclass = temp;
temp = temp.enclosingtype();
}
return outerinvocationtype == outerdeclaringclass;
}

// isdefault()
return invocationtype.fpackage == this.fpackage;
}

public char[] computegenerictypesignature(typevariablebinding[] typevariables) {

boolean ismemberofgeneric = ismembertype() && (enclosingtype().modifiers & extracompilermodifiers.accgenericsignature) != 0;
if (typevariables == binding.no_type_variables && !ismemberofgeneric) {
return signature();
}
stringbuffer sig = new stringbuffer(10);
if (ismemberofgeneric) {
char[] typesig = enclosingtype().generictypesignature();
sig.append(typesig, 0, typesig.length-1); // copy all but trailing semicolon
sig.append('.'); // note: cannot override trailing ';' with '.' in enclosing signature, since shared char[]
sig.append(this.sourcename);
}	else {
char[] typesig = signature();
sig.append(typesig, 0, typesig.length-1); // copy all but trailing semicolon
}
if (typevariables == binding.no_type_variables) {
sig.append(';');
} else {
sig.append('<');
for (int i = 0, length = typevariables.length; i < length; i++) {
sig.append(typevariables[i].generictypesignature());
}
sig.append(">;"); //$non-nls-1$
}
int siglength = sig.length();
char[] result = new char[siglength];
sig.getchars(0, siglength, result, 0);
return result;
}

public void computeid() {
// try to avoid multiple checks against a package/type name
switch (this.compoundname.length) {

case 3 :
if (!charoperation.equals(typeconstants.java, this.compoundname[0]))
return;

char[] packagename = this.compoundname[1];
if (packagename.length == 0) return; // just to be safe
char[] typename = this.compoundname[2];
if (typename.length == 0) return; // just to be safe
// remaining types must be in java.*.*
if (!charoperation.equals(typeconstants.lang, this.compoundname[1])) {
switch (packagename[0]) {
case 'i' :
if (charoperation.equals(packagename, typeconstants.io)) {
switch (typename[0]) {
case 'e' :
if (charoperation.equals(typename, typeconstants.java_io_externalizable[2]))
this.id = typeids.t_javaioexternalizable;
return;
case 'i' :
if (charoperation.equals(typename, typeconstants.java_io_ioexception[2]))
this.id = typeids.t_javaioexception;
return;
case 'o' :
if (charoperation.equals(typename, typeconstants.java_io_objectstreamexception[2]))
this.id = typeids.t_javaioobjectstreamexception;
return;
case 'p' :
if (charoperation.equals(typename, typeconstants.java_io_printstream[2]))
this.id = typeids.t_javaioprintstream;
return;
case 's' :
if (charoperation.equals(typename, typeconstants.java_io_serializable[2]))
this.id = typeids.t_javaioserializable;
return;
}
}
return;
case 'u' :
if (charoperation.equals(packagename, typeconstants.util)) {
switch (typename[0]) {
case 'c' :
if (charoperation.equals(typename, typeconstants.java_util_collection[2]))
this.id = typeids.t_javautilcollection;
return;
case 'i' :
if (charoperation.equals(typename, typeconstants.java_util_iterator[2]))
this.id = typeids.t_javautiliterator;
return;
}
}
return;
}
return;
}

// remaining types must be in java.lang.*
switch (typename[0]) {
case 'a' :
if (charoperation.equals(typename, typeconstants.java_lang_assertionerror[2]))
this.id = typeids.t_javalangassertionerror;
return;
case 'b' :
switch (typename.length) {
case 4 :
if (charoperation.equals(typename, typeconstants.java_lang_byte[2]))
this.id = typeids.t_javalangbyte;
return;
case 7 :
if (charoperation.equals(typename, typeconstants.java_lang_boolean[2]))
this.id = typeids.t_javalangboolean;
return;
}
return;
case 'c' :
switch (typename.length) {
case 5 :
if (charoperation.equals(typename, typeconstants.java_lang_class[2]))
this.id = typeids.t_javalangclass;
return;
case 9 :
if (charoperation.equals(typename, typeconstants.java_lang_character[2]))
this.id = typeids.t_javalangcharacter;
else if (charoperation.equals(typename, typeconstants.java_lang_cloneable[2]))
this.id = typeids.t_javalangcloneable;
return;
case 22 :
if (charoperation.equals(typename, typeconstants.java_lang_classnotfoundexception[2]))
this.id = typeids.t_javalangclassnotfoundexception;
return;
}
return;
case 'd' :
switch (typename.length) {
case 6 :
if (charoperation.equals(typename, typeconstants.java_lang_double[2]))
this.id = typeids.t_javalangdouble;
return;
case 10 :
if (charoperation.equals(typename, typeconstants.java_lang_deprecated[2]))
this.id = typeids.t_javalangdeprecated;
return;
}
return;
case 'e' :
switch (typename.length) {
case 4 :
if (charoperation.equals(typename, typeconstants.java_lang_enum[2]))
this.id = typeids.t_javalangenum;
return;
case 5 :
if (charoperation.equals(typename, typeconstants.java_lang_error[2]))
this.id = typeids.t_javalangerror;
return;
case 9 :
if (charoperation.equals(typename, typeconstants.java_lang_exception[2]))
this.id = typeids.t_javalangexception;
return;
}
return;
case 'f' :
if (charoperation.equals(typename, typeconstants.java_lang_float[2]))
this.id = typeids.t_javalangfloat;
return;
case 'i' :
switch (typename.length) {
case 7 :
if (charoperation.equals(typename, typeconstants.java_lang_integer[2]))
this.id = typeids.t_javalanginteger;
return;
case 8 :
if (charoperation.equals(typename, typeconstants.java_lang_iterable[2]))
this.id = typeids.t_javalangiterable;
return;
case 24 :
if (charoperation.equals(typename, typeconstants.java_lang_illegalargumentexception[2]))
this.id = typeids.t_javalangillegalargumentexception;
return;
}
return;
case 'l' :
if (charoperation.equals(typename, typeconstants.java_lang_long[2]))
this.id = typeids.t_javalanglong;
return;
case 'n' :
if (charoperation.equals(typename, typeconstants.java_lang_noclassdeferror[2]))
this.id = typeids.t_javalangnoclassdeferror;
return;
case 'o' :
switch (typename.length) {
case 6 :
if (charoperation.equals(typename, typeconstants.java_lang_object[2]))
this.id = typeids.t_javalangobject;
return;
case 8 :
if (charoperation.equals(typename, typeconstants.java_lang_override[2]))
this.id = typeids.t_javalangoverride;
return;
}
return;
case 'r' :
if (charoperation.equals(typename, typeconstants.java_lang_runtimeexception[2]))
this.id = 	typeids.t_javalangruntimeexception;
break;
case 's' :
switch (typename.length) {
case 5 :
if (charoperation.equals(typename, typeconstants.java_lang_short[2]))
this.id = typeids.t_javalangshort;
return;
case 6 :
if (charoperation.equals(typename, typeconstants.java_lang_string[2]))
this.id = typeids.t_javalangstring;
else if (charoperation.equals(typename, typeconstants.java_lang_system[2]))
this.id = typeids.t_javalangsystem;
return;
case 12 :
if (charoperation.equals(typename, typeconstants.java_lang_stringbuffer[2]))
this.id = typeids.t_javalangstringbuffer;
return;
case 13 :
if (charoperation.equals(typename, typeconstants.java_lang_stringbuilder[2]))
this.id = typeids.t_javalangstringbuilder;
return;
case 16 :
if (charoperation.equals(typename, typeconstants.java_lang_suppresswarnings[2]))
this.id = typeids.t_javalangsuppresswarnings;
return;
}
return;
case 't' :
if (charoperation.equals(typename, typeconstants.java_lang_throwable[2]))
this.id = typeids.t_javalangthrowable;
return;
case 'v' :
if (charoperation.equals(typename, typeconstants.java_lang_void[2]))
this.id = typeids.t_javalangvoid;
return;
}
break;

case 4:
if (!charoperation.equals(typeconstants.java, this.compoundname[0]))
return;
if (!charoperation.equals(typeconstants.lang, this.compoundname[1]))
return;
packagename = this.compoundname[2];
if (packagename.length == 0) return; // just to be safe
typename = this.compoundname[3];
if (typename.length == 0) return; // just to be safe
switch (packagename[0]) {
case 'a' :
if (charoperation.equals(packagename, typeconstants.annotation)) {
switch (typename[0]) {
case 'a' :
if (charoperation.equals(typename, typeconstants.java_lang_annotation_annotation[3]))
this.id = typeids.t_javalangannotationannotation;
return;
case 'd' :
if (charoperation.equals(typename, typeconstants.java_lang_annotation_documented[3]))
this.id = typeids.t_javalangannotationdocumented;
return;
case 'e' :
if (charoperation.equals(typename, typeconstants.java_lang_annotation_elementtype[3]))
this.id = typeids.t_javalangannotationelementtype;
return;
case 'i' :
if (charoperation.equals(typename, typeconstants.java_lang_annotation_inherited[3]))
this.id = typeids.t_javalangannotationinherited;
return;
case 'r' :
switch (typename.length) {
case 9 :
if (charoperation.equals(typename, typeconstants.java_lang_annotation_retention[3]))
this.id = typeids.t_javalangannotationretention;
return;
case 15 :
if (charoperation.equals(typename, typeconstants.java_lang_annotation_retentionpolicy[3]))
this.id = typeids.t_javalangannotationretentionpolicy;
return;
}
return;
case 't' :
if (charoperation.equals(typename, typeconstants.java_lang_annotation_target[3]))
this.id = typeids.t_javalangannotationtarget;
return;
}
}
return;
case 'r' :
if (charoperation.equals(packagename, typeconstants.reflect)) {
switch (typename[0]) {
case 'c' :
if (charoperation.equals(typename, typeconstants.java_lang_reflect_constructor[2]))
this.id = typeids.t_javalangreflectconstructor;
return;
case 'f' :
if (charoperation.equals(typename, typeconstants.java_lang_reflect_field[2]))
this.id = typeids.t_javalangreflectfield;
return;
case 'm' :
if (charoperation.equals(typename, typeconstants.java_lang_reflect_method[2]))
this.id = typeids.t_javalangreflectmethod;
return;
}
}
return;
}
break;
}
}

/**
* p.x<t extends y & i, u extends y> {} -> lp/x<tt;tu;>;
*/
public char[] computeuniquekey(boolean isleaf) {
if (!isleaf) return signature();
return generictypesignature();
}

/**
* answer the receiver's constant pool name.
*
* note: this method should only be used during/after code gen.
*/
public char[] constantpoolname() /* java/lang/object */ {
if (this.constantpoolname != null) return this.constantpoolname;
return this.constantpoolname = charoperation.concatwith(this.compoundname, '/');
}

public string debugname() {
return (this.compoundname != null) ? new string(readablename()) : "unnamed type"; //$non-nls-1$
}

public final int depth() {
int depth = 0;
referencebinding current = this;
while ((current = current.enclosingtype()) != null)
depth++;
return depth;
}

public boolean detectannotationcycle() {
if ((this.tagbits & tagbits.endannotationcheck) != 0) return false; // already checked
if ((this.tagbits & tagbits.beginannotationcheck) != 0) return true; // in the middle of checking its methods

this.tagbits |= tagbits.beginannotationcheck;
methodbinding[] currentmethods = methods();
boolean incycle = false; // check each method before failing
for (int i = 0, l = currentmethods.length; i < l; i++) {
typebinding returntype = currentmethods[i].returntype.leafcomponenttype().erasure();
if (this == returntype) {
if (this instanceof sourcetypebinding) {
methoddeclaration decl = (methoddeclaration) currentmethods[i].sourcemethod();
((sourcetypebinding) this).scope.problemreporter().annotationcircularity(this, this, decl != null ? decl.returntype : null);
}
} else if (returntype.isannotationtype() && ((referencebinding) returntype).detectannotationcycle()) {
if (this instanceof sourcetypebinding) {
methoddeclaration decl = (methoddeclaration) currentmethods[i].sourcemethod();
((sourcetypebinding) this).scope.problemreporter().annotationcircularity(this, returntype, decl != null ? decl.returntype : null);
}
incycle = true;
}
}
if (incycle)
return true;
this.tagbits |= tagbits.endannotationcheck;
return false;
}

public final referencebinding enclosingtypeat(int relativedepth) {
referencebinding current = this;
while (relativedepth-- > 0 && current != null)
current = current.enclosingtype();
return current;
}

public int enumconstantcount() {
int count = 0;
fieldbinding[] fields = fields();
for (int i = 0, length = fields.length; i < length; i++) {
if ((fields[i].modifiers & classfileconstants.accenum) != 0) count++;
}
return count;
}

public int fieldcount() {
return fields().length;
}

public fieldbinding[] fields() {
return binding.no_fields;
}

public final int getaccessflags() {
return this.modifiers & extracompilermodifiers.accjustflag;
}

/**
* @@return the jsr 175 annotations for this type.
*/
public annotationbinding[] getannotations() {
return retrieveannotations(this);
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#getannotationtagbits()
*/
public long getannotationtagbits() {
return this.tagbits;
}

/**
* @@return the enclosinginstancesslotsize
*/
public int getenclosinginstancesslotsize() {
if (isstatic()) return 0;
return enclosingtype() == null ? 0 : 1;
}

public methodbinding getexactconstructor(typebinding[] argumenttypes) {
return null;
}

public methodbinding getexactmethod(char[] selector, typebinding[] argumenttypes, compilationunitscope refscope) {
return null;
}
public fieldbinding getfield(char[] fieldname, boolean needresolve) {
return null;
}
/**
* @@see org.eclipse.jdt.internal.compiler.env.idependent#getfilename()
*/
public char[] getfilename() {
return this.filename;
}

public referencebinding getmembertype(char[] typename) {
referencebinding[] membertypes = membertypes();
for (int i = membertypes.length; --i >= 0;)
if (charoperation.equals(membertypes[i].sourcename, typename))
return membertypes[i];
return null;
}

public methodbinding[] getmethods(char[] selector) {
return binding.no_methods;
}

// answer methods named selector, which take no more than the suggestedparameterlength.
// the suggested parameter length is optional and may not be guaranteed by every type.
public methodbinding[] getmethods(char[] selector, int suggestedparameterlength) {
return getmethods(selector);
}

/**
* @@return the outerlocalvariablesslotsize
*/
public int getouterlocalvariablesslotsize() {
return 0;
}

public packagebinding getpackage() {
return this.fpackage;
}

public typevariablebinding gettypevariable(char[] variablename) {
typevariablebinding[] typevariables = typevariables();
for (int i = typevariables.length; --i >= 0;)
if (charoperation.equals(typevariables[i].sourcename, variablename))
return typevariables[i];
return null;
}

public int hashcode() {
// ensure referencebindings hash to the same posiiton as unresolvedreferencebindings so they can be replaced without rehashing
// all referencebindings are unique when created so equals() is the same as ==
return (this.compoundname == null || this.compoundname.length == 0)
? super.hashcode()
: charoperation.hashcode(this.compoundname[this.compoundname.length - 1]);
}

/**
* returns true if the two types have an incompatible common supertype,
* e.g. list<string> and list<integer>
*/
public boolean hasincompatiblesupertype(referencebinding othertype) {

if (this == othertype) return false;

referencebinding[] interfacestovisit = null;
int nextposition = 0;
referencebinding currenttype = this;
typebinding match;
do {
match = othertype.findsupertypeoriginatingfrom(currenttype);
if (match != null && match.isprovablydistinct(currenttype))
return true;

referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
} while ((currenttype = currenttype.superclass()) != null);

for (int i = 0; i < nextposition; i++) {
currenttype = interfacestovisit[i];
if (currenttype == othertype) return false;
match = othertype.findsupertypeoriginatingfrom(currenttype);
if (match != null && match.isprovablydistinct(currenttype))
return true;

referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
return false;
}

public boolean hasmembertypes() {
return false;
}

public final boolean hasrestrictedaccess() {
return (this.modifiers & extracompilermodifiers.accrestrictedaccess) != 0;
}

/** answer true if the receiver implements aninterface or is identical to aninterface.
* if searchhierarchy is true, then also search the receiver's superclasses.
*
* note: assume that aninterface is an interface.
*/
public boolean implementsinterface(referencebinding aninterface, boolean searchhierarchy) {
if (this == aninterface)
return true;

referencebinding[] interfacestovisit = null;
int nextposition = 0;
referencebinding currenttype = this;
do {
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) { // in code assist cases when source types are added late, may not be finished connecting hierarchy
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
} while (searchhierarchy && (currenttype = currenttype.superclass()) != null);

for (int i = 0; i < nextposition; i++) {
currenttype = interfacestovisit[i];
if (currenttype.isequivalentto(aninterface))
return true;

referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) { // in code assist cases when source types are added late, may not be finished connecting hierarchy
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
return false;
}

// internal method... assume its only sent to classes not interfaces
boolean implementsmethod(methodbinding method) {
char[] selector = method.selector;
referencebinding type = this;
while (type != null) {
methodbinding[] methods = type.methods();
long range;
if ((range = referencebinding.binarysearch(selector, methods)) >= 0) {
int start = (int) range, end = (int) (range >> 32);
for (int i = start; i <= end; i++) {
if (methods[i].areparametersequal(method))
return true;
}
}
type = type.superclass();
}
return false;
}

/**
* answer true if the receiver is an abstract type
*/
public final boolean isabstract() {
return (this.modifiers & classfileconstants.accabstract) != 0;
}

public boolean isannotationtype() {
return (this.modifiers & classfileconstants.accannotation) != 0;
}

public final boolean isbinarybinding() {
return (this.tagbits & tagbits.isbinarybinding) != 0;
}

public boolean isclass() {
return (this.modifiers & (classfileconstants.accinterface | classfileconstants.accannotation | classfileconstants.accenum)) == 0;
}

/**
* answer true if the receiver type can be assigned to the argument type (right)
* in addition to improving performance, caching also ensures there is no infinite regression
* since per nature, the compatibility check is recursive through parameterized type arguments (122775)
*/
public boolean iscompatiblewith(typebinding othertype) {
if (othertype == this)
return true;
if (othertype.id == typeids.t_javalangobject)
return true;
object result;
if (this.compatiblecache == null) {
this.compatiblecache = new simplelookuptable(3);
result = null;
} else {
result = this.compatiblecache.get(othertype); // [dbg reset] this.compatiblecache.put(othertype,null)
if (result != null) {
return result == boolean.true;
}
}
this.compatiblecache.put(othertype, boolean.false); // protect from recursive call
if (iscompatiblewith0(othertype)) {
this.compatiblecache.put(othertype, boolean.true);
return true;
}
return false;
}

/**
* answer true if the receiver type can be assigned to the argument type (right)
*/
private boolean iscompatiblewith0(typebinding othertype) {
if (othertype == this)
return true;
if (othertype.id == typeids.t_javalangobject)
return true;
// equivalence may allow compatibility with array type through wildcard
// bound
if (isequivalentto(othertype))
return true;
switch (othertype.kind()) {
case binding.wildcard_type :
case binding.intersection_type:
return false; // should have passed equivalence check above if
// wildcard
case binding.type_parameter :
// check compatibility with capture of ? super x
if (othertype.iscapture()) {
capturebinding othercapture = (capturebinding) othertype;
typebinding otherlowerbound;
if ((otherlowerbound = othercapture.lowerbound) != null) {
if (otherlowerbound.isarraytype()) return false;
return iscompatiblewith(otherlowerbound);
}
}
//$fall-through$
case binding.generic_type :
case binding.type :
case binding.parameterized_type :
case binding.raw_type :
switch (kind()) {
case binding.generic_type :
case binding.parameterized_type :
case binding.raw_type :
if (erasure() == othertype.erasure())
return false; // should have passed equivalence check
// above if same erasure
}
referencebinding otherreferencetype = (referencebinding) othertype;
if (otherreferencetype.isinterface()) // could be annotation type
return implementsinterface(otherreferencetype, true);
if (isinterface())  // explicit conversion from an interface
// to a class is not allowed
return false;
return otherreferencetype.issuperclassof(this);
default :
return false;
}
}

/**
* answer true if the receiver has default visibility
*/
public final boolean isdefault() {
return (this.modifiers & (classfileconstants.accpublic | classfileconstants.accprotected | classfileconstants.accprivate)) == 0;
}

/**
* answer true if the receiver is a deprecated type
*/
public final boolean isdeprecated() {
return (this.modifiers & classfileconstants.accdeprecated) != 0;
}

public boolean isenum() {
return (this.modifiers & classfileconstants.accenum) != 0;
}

/**
* answer true if the receiver is final and cannot be subclassed
*/
public final boolean isfinal() {
return (this.modifiers & classfileconstants.accfinal) != 0;
}

/**
* returns true if the type hierarchy is being connected
*/
public boolean ishierarchybeingconnected() {
return (this.tagbits & tagbits.endhierarchycheck) == 0 && (this.tagbits & tagbits.beginhierarchycheck) != 0;
}
/**
* returns true if the type hierarchy is being connected "actively" i.e not paused momentatrily,
* while resolving type arguments. see https://bugs.eclipse.org/bugs/show_bug.cgi?id=294057
*/
public boolean ishierarchybeingactivelyconnected() {
return (this.tagbits & tagbits.endhierarchycheck) == 0 && (this.tagbits & tagbits.beginhierarchycheck) != 0 && (this.tagbits & tagbits.pausehierarchycheck) == 0;
}

/**
* returns true if the type hierarchy is connected
*/
public boolean ishierarchyconnected() {
return true;
}

public boolean isinterface() {
// consider strict interfaces and annotation types
return (this.modifiers & classfileconstants.accinterface) != 0;
}

/**
* answer true if the receiver has private visibility
*/
public final boolean isprivate() {
return (this.modifiers & classfileconstants.accprivate) != 0;
}

/**
* answer true if the receiver or any of its enclosing types have private visibility
*/
public final boolean isorenclosedbyprivatetype() {
if (islocaltype()) return true; // catch all local types
referencebinding type = this;
while (type != null) {
if ((type.modifiers & classfileconstants.accprivate) != 0)
return true;
type = type.enclosingtype();
}
return false;
}

/**
* answer true if the receiver has protected visibility
*/
public final boolean isprotected() {
return (this.modifiers & classfileconstants.accprotected) != 0;
}

/**
* answer true if the receiver has public visibility
*/
public final boolean ispublic() {
return (this.modifiers & classfileconstants.accpublic) != 0;
}

/**
* answer true if the receiver is a static member type (or toplevel)
*/
public final boolean isstatic() {
return (this.modifiers & (classfileconstants.accstatic | classfileconstants.accinterface)) != 0 || (this.tagbits & tagbits.isnestedtype) == 0;
}

/**
* answer true if all float operations must adher to ieee 754 float/double rules
*/
public final boolean isstrictfp() {
return (this.modifiers & classfileconstants.accstrictfp) != 0;
}

/**
* answer true if the receiver is in the superclass hierarchy of atype
* note: object.issuperclassof(object) -> false
*/
public boolean issuperclassof(referencebinding othertype) {
while ((othertype = othertype.superclass()) != null) {
if (othertype.isequivalentto(this)) return true;
}
return false;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#isthrowable()
*/
public boolean isthrowable() {
referencebinding current = this;
do {
switch (current.id) {
case typeids.t_javalangthrowable :
case typeids.t_javalangerror :
case typeids.t_javalangruntimeexception :
case typeids.t_javalangexception :
return true;
}
} while ((current = current.superclass()) != null);
return false;
}

/**
* jls 11.5 ensures that throwable, exception, runtimeexception and error are directly connected.
* (throwable<- exception <- rumtimeexception, throwable <- error). thus no need to check #iscompatiblewith
* but rather check in type ids so as to avoid some eager class loading for jcl writers.
* when 'includesupertype' is true, answers true if the given type can be a supertype of some unchecked exception
* type (i.e. throwable or exception).
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#isuncheckedexception(boolean)
*/
public boolean isuncheckedexception(boolean includesupertype) {
switch (this.id) {
case typeids.t_javalangerror :
case typeids.t_javalangruntimeexception :
return true;
case typeids.t_javalangthrowable :
case typeids.t_javalangexception :
return includesupertype;
}
referencebinding current = this;
while ((current = current.superclass()) != null) {
switch (current.id) {
case typeids.t_javalangerror :
case typeids.t_javalangruntimeexception :
return true;
case typeids.t_javalangthrowable :
case typeids.t_javalangexception :
return false;
}
}
return false;
}

/**
* answer true if the receiver has private visibility and is used locally
*/
public final boolean isused() {
return (this.modifiers & extracompilermodifiers.acclocallyused) != 0;
}

/**
* answer true if the receiver is deprecated (or any of its enclosing types)
*/
public final boolean isviewedasdeprecated() {
return (this.modifiers & (classfileconstants.accdeprecated | extracompilermodifiers.accdeprecatedimplicitly)) != 0
|| getpackage().isviewedasdeprecated();
}

public referencebinding[] membertypes() {
return binding.no_member_types;
}

public methodbinding[] methods() {
return binding.no_methods;
}

public final referencebinding outermostenclosingtype() {
referencebinding current = this;
while (true) {
referencebinding last = current;
if ((current = current.enclosingtype()) == null)
return last;
}
}

/**
* answer the source name for the type.
* in the case of member types, as the qualified name from its top level type.
* for example, for a member type n defined inside m & a: "a.m.n".
*/
public char[] qualifiedsourcename() {
if (ismembertype())
return charoperation.concat(enclosingtype().qualifiedsourcename(), sourcename(), '.');
return sourcename();
}

/**
* answer the receiver's signature.
*
* note: this method should only be used during/after code gen.
*/
public char[] readablename() /*java.lang.object,  p.x<t> */ {
char[] readablename;
if (ismembertype()) {
readablename = charoperation.concat(enclosingtype().readablename(), this.sourcename, '.');
} else {
readablename = charoperation.concatwith(this.compoundname, '.');
}
typevariablebinding[] typevars;
if ((typevars = typevariables()) != binding.no_type_variables) {
stringbuffer namebuffer = new stringbuffer(10);
namebuffer.append(readablename).append('<');
for (int i = 0, length = typevars.length; i < length; i++) {
if (i > 0) namebuffer.append(',');
namebuffer.append(typevars[i].readablename());
}
namebuffer.append('>');
int namelength = namebuffer.length();
readablename = new char[namelength];
namebuffer.getchars(0, namelength, readablename, 0);
}
return readablename;
}

public annotationholder retrieveannotationholder(binding binding, boolean forceinitialization) {
simplelookuptable store = storedannotations(false);
return store == null ? null : (annotationholder) store.get(binding);
}

annotationbinding[] retrieveannotations(binding binding) {
annotationholder holder = retrieveannotationholder(binding, true);
return holder == null ? binding.no_annotations : holder.getannotations();
}

public void setannotations(annotationbinding[] annotations) {
storeannotations(this, annotations);
}

public char[] shortreadablename() /*object*/ {
char[] shortreadablename;
if (ismembertype()) {
shortreadablename = charoperation.concat(enclosingtype().shortreadablename(), this.sourcename, '.');
} else {
shortreadablename = this.sourcename;
}
typevariablebinding[] typevars;
if ((typevars = typevariables()) != binding.no_type_variables) {
stringbuffer namebuffer = new stringbuffer(10);
namebuffer.append(shortreadablename).append('<');
for (int i = 0, length = typevars.length; i < length; i++) {
if (i > 0) namebuffer.append(',');
namebuffer.append(typevars[i].shortreadablename());
}
namebuffer.append('>');
int namelength = namebuffer.length();
shortreadablename = new char[namelength];
namebuffer.getchars(0, namelength, shortreadablename, 0);
}
return shortreadablename;
}

public char[] signature() /* ljava/lang/object; */ {
if (this.signature != null)
return this.signature;

return this.signature = charoperation.concat('l', constantpoolname(), ';');
}

public char[] sourcename() {
return this.sourcename;
}

void storeannotationholder(binding binding, annotationholder holder) {
if (holder == null) {
simplelookuptable store = storedannotations(false);
if (store != null)
store.removekey(binding);
} else {
simplelookuptable store = storedannotations(true);
if (store != null)
store.put(binding, holder);
}
}

void storeannotations(binding binding, annotationbinding[] annotations) {
annotationholder holder = null;
if (annotations == null || annotations.length == 0) {
simplelookuptable store = storedannotations(false);
if (store != null)
holder = (annotationholder) store.get(binding);
if (holder == null) return; // nothing to delete
} else {
simplelookuptable store = storedannotations(true);
if (store == null) return; // not supported
holder = (annotationholder) store.get(binding);
if (holder == null)
holder = new annotationholder();
}
storeannotationholder(binding, holder.setannotations(annotations));
}

simplelookuptable storedannotations(boolean forceinitialize) {
return null; // overrride if interested in storing annotations for the receiver, its fields and methods
}

public referencebinding superclass() {
return null;
}

public referencebinding[] superinterfaces() {
return binding.no_superinterfaces;
}

public referencebinding[] syntheticenclosinginstancetypes() {
if (isstatic()) return null;
referencebinding enclosingtype = enclosingtype();
if (enclosingtype == null)
return null;
return new referencebinding[] {enclosingtype};
}
public syntheticargumentbinding[] syntheticouterlocalvariables() {
return null;		// is null if no enclosing instances are required
}

methodbinding[] unresolvedmethods() { // for the methodverifier so it doesn't resolve types
return methods();
}
}
