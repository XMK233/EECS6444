package org.eclipse.jdt.internal.compiler;

/*
* (c) copyright ibm corp. 2000, 2001.
* all rights reserved.
*/

import org.eclipse.jdt.internal.compiler.env.*;

/**
*
* partial implementation of an igenerictype used to
* answer hierarchies.
*/
public class hierarchytype implements igenerictype {

public hierarchytype enclosingtype;
public boolean isclass;
public char[] name;
public int modifiers;
public char[] superclassname;
public char[][] superinterfacenames;
public icompilationunit originatingunit;

public hierarchytype(
hierarchytype enclosingtype,
boolean isclass,
char[] name,
int modifiers,
char[] superclassname,
char[][] superinterfacenames,
icompilationunit originatingunit) {

this.enclosingtype = enclosingtype;
this.isclass = isclass;
this.name = name;
this.modifiers = modifiers;
this.superclassname = superclassname;
this.superinterfacenames = superinterfacenames;
this.originatingunit = originatingunit;
}
/**
* answer the file name which defines the type.
*
* the path part (optional) must be separated from the actual
* file proper name by a java.io.file.separator.
*
* the proper file name includes the suffix extension (e.g. ".java")
*
* e.g. "c:/com/ibm/compiler/java/api/compiler.java"
*/
public char[] getfilename() {
return originatingunit.getfilename();
}
/**
* answer an int whose bits are set according the access constants
* defined by the vm spec.
*/
public int getmodifiers() {
return this.modifiers;
}
/**
* answer whether the receiver contains the resolved binary form
* or the unresolved source form of the type.
*/
public boolean isbinarytype() {
return false;
}
/**
* isclass method comment.
*/
public boolean isclass() {
return this.isclass;
}
/**
* isinterface method comment.
*/
public boolean isinterface() {
return !isclass;
}
}
