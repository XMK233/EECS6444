/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     ibm corporation - added the following constants
*								   nonstaticaccesstostaticfield
*								   nonstaticaccesstostaticmethod
*								   task
*								   expressionshouldbeavariable
*								   assignmenthasnoeffect
*     ibm corporation - added the following constants
*								   toomanysyntheticargumentslots
*								   toomanyarraydimensions
*								   toomanybytesforstringconstant
*								   toomanymethods
*								   toomanyfields
*								   nonblankfinallocalassignment
*								   objectcannothavesupertypes
*								   missingsemicolon
*								   invalidparenthesizedexpression
*								   enclosinginstanceinconstructorcall
*								   bytecodeexceeds64klimitforconstructor
*								   incompatiblereturntypefornoninheritedinterfacemethod
*								   unusedprivatemethod
*								   unusedprivateconstructor
*								   unusedprivatetype
*								   unusedprivatefield
*								   incompatibleexceptioninthrowsclausefornoninheritedinterfacemethod
*								   invalidexplicitconstructorcall
*     ibm corporation - added the following constants
*								   possibleaccidentalbooleanassignment
*								   superfluoussemicolon
*								   indirectaccesstostaticfield
*								   indirectaccesstostaticmethod
*								   indirectaccesstostatictype
*								   booleanmethodthrowingexception
*								   unnecessarycast
*								   unnecessaryargumentcast
*								   unnecessaryinstanceof
*								   finallymustcompletenormally
*								   unusedmethoddeclaredthrownexception
*								   unusedconstructordeclaredthrownexception
*								   invalidcatchblocksequence
*								   unqualifiedfieldaccess
*     ibm corporation - added the following constants
*								   javadoc
*								   javadocunexpectedtag
*								   javadocmissingparamtag
*								   javadocmissingparamname
*								   javadocduplicateparamname
*								   javadocinvalidparamname
*								   javadocmissingreturntag
*								   javadocduplicatereturntag
*								   javadocmissingthrowstag
*								   javadocmissingthrowsclassname
*								   javadocinvalidthrowsclass
*								   javadocduplicatethrowsclassname
*								   javadocinvalidthrowsclassname
*								   javadocmissingseereference
*								   javadocinvalidseereference
*								   javadocinvalidseehref
*								   javadocinvalidseeargs
*								   javadocmissing
*								   javadocinvalidtag
*								   javadocmessageprefix
*								   emptycontrolflowstatement
*     ibm corporation - added the following constants
*								   illegalusageofqualifiedtypereference
*								   invaliddigit
*     ibm corporation - added the following constants
*								   parameterassignment
*								   fallthroughcase
*     ibm corporation - added the following constants
*                                 unusedlabel
*                                 unnecessarynlstag
*                                 localvariablemaybenull
*                                 enumconstantscannotbesurroundedbyparenthesis
*                                 javadocmissingidentifier
*                                 javadocnonstatictypefromstaticinvocation
*                                 rawtypereference
*                                 noadditionalboundaftertypevariable
*                                 unsafegenericarrayforvarargs
*                                 illegalaccessfromtypevariable
*                                 annotationvaluemustbearrayinitializer
*                                 invalidencoding
*                                 cannotreadsource
*                                 enumstaticfieldinininitializercontext
*                                 externalproblemnotfixable
*                                 externalproblemfixable
*     ibm corporation - added the following constants
*                                 annotationvaluemustbeanenumconstant
*                                 overridingmethodwithoutsuperinvocation
*                                 methodmustoverrideorimplement
*                                 typehidingtypeparameterfromtype
*                                 typehidingtypeparameterfrommethod
*                                 typehidingtype
*     ibm corporation - added the following constants
*								   nulllocalvariablereference
*								   potentialnulllocalvariablereference
*								   redundantnullcheckonnulllocalvariable
* 								   nulllocalvariablecomparisonyieldsfalse
* 								   redundantlocalvariablenullassignment
* 								   nulllocalvariableinstanceofyieldsfalse
* 								   redundantnullcheckonnonnulllocalvariable
* 								   nonnulllocalvariablecomparisonyieldsfalse
*     ibm corporation - added the following constants
*                                 invalidusageoftypeparametersforannotationdeclaration
*                                 invalidusageoftypeparametersforenumdeclaration
*     ibm corporation - added the following constants
*								   redundantsuperinterface
*		benjamin muskalla - added the following constants
*									missingsynchronizedmodifierininheritedmethod
*		stephan herrmann  - added the following constants
*									unusedobjectallocation
*******************************************************************************/
package org.eclipse.jdt.core.compiler;

import org.eclipse.jdt.internal.compiler.lookup.problemreasons;

/**
* description of a java problem, as detected by the compiler or some of the underlying
* technology reusing the compiler.
* a problem provides access to:
* <ul>
* <li> its location (originating source file name, source position, line number), </li>
* <li> its message description and a predicate to check its severity (warning or error). </li>
* <li> its id : a number identifying the very nature of this problem. all possible ids are listed
* as constants on this interface. </li>
* </ul>
*
* note: the compiler produces iproblems internally, which are turned into markers by the javabuilder
* so as to persist problem descriptions. this explains why there is no api allowing to reach iproblem detected
* when compiling. however, the java problem markers carry equivalent information to iproblem, in particular
* their id (attribute "id") is set to one of the ids defined on this interface.
*
* @@since 2.0
* @@noimplement this interface is not intended to be implemented by clients.
* @@noextend this interface is not intended to be extended by clients.
*/
public interface iproblem {

/**
* answer back the original arguments recorded into the problem.
* @@return the original arguments recorded into the problem
*/
string[] getarguments();

/**
* returns the problem id
*
* @@return the problem id
*/
int getid();

/**
* answer a localized, human-readable message string which describes the problem.
*
* @@return a localized, human-readable message string which describes the problem
*/
string getmessage();

/**
* answer the file name in which the problem was found.
*
* @@return the file name in which the problem was found
*/
char[] getoriginatingfilename();

/**
* answer the end position of the problem (inclusive), or -1 if unknown.
*
* @@return the end position of the problem (inclusive), or -1 if unknown
*/
int getsourceend();

/**
* answer the line number in source where the problem begins.
*
* @@return the line number in source where the problem begins
*/
int getsourcelinenumber();

/**
* answer the start position of the problem (inclusive), or -1 if unknown.
*
* @@return the start position of the problem (inclusive), or -1 if unknown
*/
int getsourcestart();

/**
* checks the severity to see if the error bit is set.
*
* @@return true if the error bit is set for the severity, false otherwise
*/
boolean iserror();

/**
* checks the severity to see if the error bit is not set.
*
* @@return true if the error bit is not set for the severity, false otherwise
*/
boolean iswarning();

/**
* set the end position of the problem (inclusive), or -1 if unknown.
* used for shifting problem positions.
*
* @@param sourceend the given end position
*/
void setsourceend(int sourceend);

/**
* set the line number in source where the problem begins.
*
* @@param linenumber the given line number
*/
void setsourcelinenumber(int linenumber);

/**
* set the start position of the problem (inclusive), or -1 if unknown.
* used for shifting problem positions.
*
* @@param sourcestart the given start position
*/
void setsourcestart(int sourcestart);


/**
* problem categories
* the high bits of a problem id contains information about the category of a problem.
* for example, (problemid & typerelated) != 0, indicates that this problem is type related.
*
* a problem category can help to implement custom problem filters. indeed, when numerous problems
* are listed, focusing on import related problems first might be relevant.
*
* when a problem is tagged as internal, it means that no change other than a local source code change
* can  fix the corresponding problem. a type related problem could be addressed by changing the type
* involved in it.
*/
int typerelated = 0x01000000;
int fieldrelated = 0x02000000;
int methodrelated = 0x04000000;
int constructorrelated = 0x08000000;
int importrelated = 0x10000000;
int internal = 0x20000000;
int syntax = 0x40000000;
/** @@since 3.0 */
int javadoc = 0x80000000;

/**
* mask to use in order to filter out the category portion of the problem id.
*/
int ignorecategoriesmask = 0xffffff;

/**
* below are listed all available problem ids. note that this list could be augmented in the future,
* as new features are added to the java core implementation.
*/

/**
* id reserved for referencing an internal error inside the javacore implementation which
* may be surfaced as a problem associated with the compilation unit which caused it to occur.
*/
int unclassified = 0;

/**
* general type related problems
*/
int objecthasnosuperclass = typerelated + 1;
int undefinedtype = typerelated + 2;
int notvisibletype = typerelated + 3;
int ambiguoustype = typerelated + 4;
int usingdeprecatedtype = typerelated + 5;
int internaltypenameprovided = typerelated + 6;
/** @@since 2.1 */
int unusedprivatetype = internal + typerelated + 7;

int incompatibletypesinequalityoperator = typerelated + 15;
int incompatibletypesinconditionaloperator = typerelated + 16;
int typemismatch = typerelated + 17;
/** @@since 3.0 */
int indirectaccesstostatictype = internal + typerelated + 18;

/**
* inner types related problems
*/
int missingenclosinginstanceforconstructorcall = typerelated + 20;
int missingenclosinginstance = typerelated + 21;
int incorrectenclosinginstancereference = typerelated + 22;
int illegalenclosinginstancespecification = typerelated + 23;
int cannotdefinestaticinitializerinlocaltype = internal + 24;
int outerlocalmustbefinal = internal + 25;
int cannotdefineinterfaceinlocaltype = internal + 26;
int illegalprimitiveorarraytypeforenclosinginstance = typerelated + 27;
/** @@since 2.1 */
int enclosinginstanceinconstructorcall = internal + 28;
int anonymousclasscannotextendfinalclass = typerelated + 29;
/** @@since 3.1 */
int cannotdefineannotationinlocaltype = internal + 30;
/** @@since 3.1 */
int cannotdefineenuminlocaltype = internal + 31;
/** @@since 3.1 */
int nonstaticcontextforenummembertype = internal + 32;
/** @@since 3.3 */
int typehidingtype = typerelated + 33;

// variables
int undefinedname = internal + fieldrelated + 50;
int uninitializedlocalvariable = internal + 51;
int variabletypecannotbevoid = internal + 52;
/** @@deprecated - problem is no longer generated, use {@@link #cannotallocatevoidarray} instead */
int variabletypecannotbevoidarray = internal + 53;
int cannotallocatevoidarray = internal + 54;
// local variables
int redefinedlocal = internal + 55;
int redefinedargument = internal + 56;
// final local variables
int duplicatefinallocalinitialization = internal + 57;
/** @@since 2.1 */
int nonblankfinallocalassignment = internal + 58;
/** @@since 3.2 */
int parameterassignment = internal + 59;
int finalouterlocalassignment = internal + 60;
int localvariableisneverused = internal + 61;
int argumentisneverused = internal + 62;
int bytecodeexceeds64klimit = internal + 63;
int bytecodeexceeds64klimitforclinit = internal + 64;
int toomanyargumentslots = internal + 65;
int toomanylocalvariableslots = internal + 66;
/** @@since 2.1 */
int toomanysyntheticargumentslots = internal + 67;
/** @@since 2.1 */
int toomanyarraydimensions = internal + 68;
/** @@since 2.1 */
int bytecodeexceeds64klimitforconstructor = internal + 69;

// fields
int undefinedfield = fieldrelated + 70;
int notvisiblefield = fieldrelated + 71;
int ambiguousfield = fieldrelated + 72;
int usingdeprecatedfield = fieldrelated + 73;
int nonstaticfieldfromstaticinvocation = fieldrelated + 74;
int referencetoforwardfield = fieldrelated + internal + 75;
/** @@since 2.1 */
int nonstaticaccesstostaticfield = internal + fieldrelated + 76;
/** @@since 2.1 */
int unusedprivatefield = internal + fieldrelated + 77;
/** @@since 3.0 */
int indirectaccesstostaticfield = internal + fieldrelated + 78;
/** @@since 3.0 */
int unqualifiedfieldaccess = internal + fieldrelated + 79;
int finalfieldassignment = fieldrelated + 80;
int uninitializedblankfinalfield = fieldrelated + 81;
int duplicateblankfinalfieldinitialization = fieldrelated + 82;
/** @@since 3.6 */
int unresolvedvariable = fieldrelated + 83;

// variable hiding
/** @@since 3.0 */
int localvariablehidinglocalvariable = internal + 90;
/** @@since 3.0 */
int localvariablehidingfield = internal + fieldrelated + 91;
/** @@since 3.0 */
int fieldhidinglocalvariable = internal + fieldrelated + 92;
/** @@since 3.0 */
int fieldhidingfield = internal + fieldrelated + 93;
/** @@since 3.0 */
int argumenthidinglocalvariable = internal + 94;
/** @@since 3.0 */
int argumenthidingfield = internal + 95;
/** @@since 3.1 */
int missingserialversion = internal + 96;

// methods
int undefinedmethod = methodrelated + 100;
int notvisiblemethod = methodrelated + 101;
int ambiguousmethod = methodrelated + 102;
int usingdeprecatedmethod = methodrelated + 103;
int directinvocationofabstractmethod = methodrelated + 104;
int voidmethodreturnsvalue = methodrelated + 105;
int methodreturnsvoid = methodrelated + 106;
int methodrequiresbody = internal + methodrelated + 107;
int shouldreturnvalue = internal + methodrelated + 108;
int methodbutwithconstructorname = methodrelated + 110;
int missingreturntype = typerelated + 111;
int bodyfornativemethod = internal + methodrelated + 112;
int bodyforabstractmethod = internal + methodrelated + 113;
int nomessagesendonbasetype = methodrelated + 114;
int parametermismatch = methodrelated + 115;
int nomessagesendonarraytype = methodrelated + 116;
/** @@since 2.1 */
int nonstaticaccesstostaticmethod = internal + methodrelated + 117;
/** @@since 2.1 */
int unusedprivatemethod = internal + methodrelated + 118;
/** @@since 3.0 */
int indirectaccesstostaticmethod = internal + methodrelated + 119;
/** @@since 3.4 */
int missingtypeinmethod = methodrelated + 120;

// constructors
/** @@since 3.4 */
int missingtypeinconstructor = constructorrelated + 129;
int undefinedconstructor = constructorrelated + 130;
int notvisibleconstructor = constructorrelated + 131;
int ambiguousconstructor = constructorrelated + 132;
int usingdeprecatedconstructor = constructorrelated + 133;
/** @@since 2.1 */
int unusedprivateconstructor = internal + methodrelated + 134;
// explicit constructor calls
int instancefieldduringconstructorinvocation = constructorrelated + 135;
int instancemethodduringconstructorinvocation = constructorrelated + 136;
int recursiveconstructorinvocation = constructorrelated + 137;
int thissuperduringconstructorinvocation = constructorrelated + 138;
/** @@since 3.0 */
int invalidexplicitconstructorcall = constructorrelated + syntax + 139;
// implicit constructor calls
int undefinedconstructorindefaultconstructor = constructorrelated + 140;
int notvisibleconstructorindefaultconstructor = constructorrelated + 141;
int ambiguousconstructorindefaultconstructor = constructorrelated + 142;
int undefinedconstructorinimplicitconstructorcall = constructorrelated + 143;
int notvisibleconstructorinimplicitconstructorcall = constructorrelated + 144;
int ambiguousconstructorinimplicitconstructorcall = constructorrelated + 145;
int unhandledexceptionindefaultconstructor = typerelated + 146;
int unhandledexceptioninimplicitconstructorcall = typerelated + 147;

// expressions
/** @@since 3.6 */
int unusedobjectallocation = internal + 148;
/** @@since 3.5 */
int deadcode = internal + 149;
int arrayreferencerequired = internal + 150;
int noimplicitstringconversionforchararrayexpression = internal + 151;
// constant expressions
int stringconstantisexceedingutf8limit = internal + 152;
int nonconstantexpression = internal + 153;
int numericvalueoutofrange = internal + 154;
// cast expressions
int illegalcast = typerelated + 156;
// allocations
int invalidclassinstantiation = typerelated + 157;
int cannotdefinedimensionexpressionswithinit = internal + 158;
int mustdefineeitherdimensionexpressionsorinitializer = internal + 159;
// operators
int invalidoperator = internal + 160;
// statements
int codecannotbereached = internal + 161;
int cannotreturnininitializer = internal + 162;
int initializermustcompletenormally = internal + 163;
// assert
int invalidvoidexpression = internal + 164;
// try
int maskedcatch = typerelated + 165;
int duplicatedefaultcase = internal + 166;
int unreachablecatch = typerelated + methodrelated + 167;
int unhandledexception = typerelated + 168;
// switch
int incorrectswitchtype = typerelated + 169;
int duplicatecase = fieldrelated + 170;

// labelled
int duplicatelabel = internal + 171;
int invalidbreak = internal + 172;
int invalidcontinue = internal + 173;
int undefinedlabel = internal + 174;
//synchronized
int invalidtypetosynchronized = internal + 175;
int invalidnulltosynchronized = internal + 176;
// throw
int cannotthrownull = internal + 177;
// assignment
/** @@since 2.1 */
int assignmenthasnoeffect = internal + 178;
/** @@since 3.0 */
int possibleaccidentalbooleanassignment = internal + 179;
/** @@since 3.0 */
int superfluoussemicolon = internal + 180;
/** @@since 3.0 */
int unnecessarycast = internal + typerelated + 181;
/** @@deprecated - no longer generated, use {@@link #unnecessarycast} instead
*   @@since 3.0 */
int unnecessaryargumentcast = internal + typerelated + 182;
/** @@since 3.0 */
int unnecessaryinstanceof = internal + typerelated + 183;
/** @@since 3.0 */
int finallymustcompletenormally = internal + 184;
/** @@since 3.0 */
int unusedmethoddeclaredthrownexception = internal + 185;
/** @@since 3.0 */
int unusedconstructordeclaredthrownexception = internal + 186;
/** @@since 3.0 */
int invalidcatchblocksequence = internal + typerelated + 187;
/** @@since 3.0 */
int emptycontrolflowstatement = internal + typerelated + 188;
/** @@since 3.0 */
int unnecessaryelse = internal + 189;

// inner emulation
int needtoemulatefieldreadaccess = fieldrelated + 190;
int needtoemulatefieldwriteaccess = fieldrelated + 191;
int needtoemulatemethodaccess = methodrelated + 192;
int needtoemulateconstructoraccess = methodrelated + 193;

/** @@since 3.2 */
int fallthroughcase = internal + 194;

//inherited name hides enclosing name (sort of ambiguous)
int inheritedmethodhidesenclosingname = methodrelated + 195;
int inheritedfieldhidesenclosingname = fieldrelated + 196;
int inheritedtypehidesenclosingname = typerelated + 197;

/** @@since 3.1 */
int illegalusageofqualifiedtypereference = internal + syntax + 198;

// miscellaneous
/** @@since 3.2 */
int unusedlabel = internal + 199;
int thisinstaticcontext = internal + 200;
int staticmethodrequested = internal + methodrelated + 201;
int illegaldimension = internal + 202;
int invalidtypeexpression = internal + 203;
int parsingerror = syntax + internal + 204;
int parsingerrornosuggestion = syntax + internal + 205;
int invalidunaryexpression = syntax + internal + 206;

// syntax errors
int interfacecannothaveconstructors = syntax + internal + 207;
int arrayconstantsonlyinarrayinitializers = syntax + internal + 208;
int parsingerroronkeyword = syntax + internal + 209;
int parsingerroronkeywordnosuggestion = syntax + internal + 210;

/** @@since 3.5 */
int comparingidentical = internal + 211;

int unmatchedbracket = syntax + internal + 220;
int nofieldonbasetype = fieldrelated + 221;
int invalidexpressionasstatement = syntax + internal + 222;
/** @@since 2.1 */
int expressionshouldbeavariable = syntax + internal + 223;
/** @@since 2.1 */
int missingsemicolon = syntax + internal + 224;
/** @@since 2.1 */
int invalidparenthesizedexpression = syntax + internal + 225;

/** @@since 3.0 */
int parsingerrorinserttokenbefore = syntax + internal + 230;
/** @@since 3.0 */
int parsingerrorinserttokenafter = syntax + internal + 231;
/** @@since 3.0 */
int parsingerrordeletetoken = syntax + internal + 232;
/** @@since 3.0 */
int parsingerrordeletetokens = syntax + internal + 233;
/** @@since 3.0 */
int parsingerrormergetokens = syntax + internal + 234;
/** @@since 3.0 */
int parsingerrorinvalidtoken = syntax + internal + 235;
/** @@since 3.0 */
int parsingerrormisplacedconstruct = syntax + internal + 236;
/** @@since 3.0 */
int parsingerrorreplacetokens = syntax + internal + 237;
/** @@since 3.0 */
int parsingerrornosuggestionfortokens = syntax + internal + 238;
/** @@since 3.0 */
int parsingerrorunexpectedeof = syntax + internal + 239;
/** @@since 3.0 */
int parsingerrorinserttocomplete = syntax + internal + 240;
/** @@since 3.0 */
int parsingerrorinserttocompletescope = syntax + internal + 241;
/** @@since 3.0 */
int parsingerrorinserttocompletephrase = syntax + internal + 242;

// scanner errors
int endofsource = syntax + internal + 250;
int invalidhexa = syntax + internal + 251;
int invalidoctal = syntax + internal + 252;
int invalidcharacterconstant = syntax + internal + 253;
int invalidescape = syntax + internal + 254;
int invalidinput = syntax + internal + 255;
int invalidunicodeescape = syntax + internal + 256;
int invalidfloat = syntax + internal + 257;
int nullsourcestring = syntax + internal + 258;
int unterminatedstring = syntax + internal + 259;
int unterminatedcomment = syntax + internal + 260;
int nonexternalizedstringliteral = internal + 261;
/** @@since 3.1 */
int invaliddigit = syntax + internal + 262;
/** @@since 3.1 */
int invalidlowsurrogate = syntax + internal + 263;
/** @@since 3.1 */
int invalidhighsurrogate = syntax + internal + 264;
/** @@since 3.2 */
int unnecessarynlstag = internal + 265;

// type related problems
/** @@since 3.1 */
int discouragedreference = typerelated + 280;

int interfacecannothaveinitializers = typerelated + 300;
int duplicatemodifierfortype = typerelated + 301;
int illegalmodifierforclass = typerelated + 302;
int illegalmodifierforinterface = typerelated + 303;
int illegalmodifierformemberclass = typerelated + 304;
int illegalmodifierformemberinterface = typerelated + 305;
int illegalmodifierforlocalclass = typerelated + 306;
/** @@since 3.1 */
int forbiddenreference = typerelated + 307;
int illegalmodifiercombinationfinalabstractforclass = typerelated + 308;
int illegalvisibilitymodifierforinterfacemembertype = typerelated + 309;
int illegalvisibilitymodifiercombinationformembertype = typerelated + 310;
int illegalstaticmodifierformembertype = typerelated + 311;
int superclassmustbeaclass = typerelated + 312;
int classextendfinalclass = typerelated + 313;
int duplicatesuperinterface = typerelated + 314;
int superinterfacemustbeaninterface = typerelated + 315;
int hierarchycircularityselfreference = typerelated + 316;
int hierarchycircularity = typerelated + 317;
int hidingenclosingtype = typerelated + 318;
int duplicatenestedtype = typerelated + 319;
int cannotthrowtype = typerelated + 320;
int packagecollideswithtype = typerelated + 321;
int typecollideswithpackage = typerelated + 322;
int duplicatetypes = typerelated + 323;
int isclasspathcorrect = typerelated + 324;
int publicclassmustmatchfilename = typerelated + 325;
int mustspecifypackage = internal + 326;
int hierarchyhasproblems = typerelated + 327;
int packageisnotexpectedpackage = internal + 328;
/** @@since 2.1 */
int objectcannothavesupertypes = internal + 329;
/** @@since 3.1 */
int objectmustbeclass = internal + 330;
/** @@since 3.4 */
int redundantsuperinterface = typerelated + 331;
/** @@since 3.5 */
int shouldimplementhashcode = typerelated + 332;
/** @@since 3.5 */
int abstractmethodsinconcreteclass = typerelated + 333;

/** @@deprecated - problem is no longer generated, use {@@link #undefinedtype} instead */
int superclassnotfound =  typerelated + 329 + problemreasons.notfound; // typerelated + 330
/** @@deprecated - problem is no longer generated, use {@@link #notvisibletype} instead */
int superclassnotvisible =  typerelated + 329 + problemreasons.notvisible; // typerelated + 331
/** @@deprecated - problem is no longer generated, use {@@link #ambiguoustype} instead */
int superclassambiguous =  typerelated + 329 + problemreasons.ambiguous; // typerelated + 332
/** @@deprecated - problem is no longer generated, use {@@link #internaltypenameprovided} instead */
int superclassinternalnameprovided =  typerelated + 329 + problemreasons.internalnameprovided; // typerelated + 333
/** @@deprecated - problem is no longer generated, use {@@link #inheritedtypehidesenclosingname} instead */
int superclassinheritednamehidesenclosingname =  typerelated + 329 + problemreasons.inheritednamehidesenclosingname; // typerelated + 334

/** @@deprecated - problem is no longer generated, use {@@link #undefinedtype} instead */
int interfacenotfound =  typerelated + 334 + problemreasons.notfound; // typerelated + 335
/** @@deprecated - problem is no longer generated, use {@@link #notvisibletype} instead */
int interfacenotvisible =  typerelated + 334 + problemreasons.notvisible; // typerelated + 336
/** @@deprecated - problem is no longer generated, use {@@link #ambiguoustype} instead */
int interfaceambiguous =  typerelated + 334 + problemreasons.ambiguous; // typerelated + 337
/** @@deprecated - problem is no longer generated, use {@@link #internaltypenameprovided} instead */
int interfaceinternalnameprovided =  typerelated + 334 + problemreasons.internalnameprovided; // typerelated + 338
/** @@deprecated - problem is no longer generated, use {@@link #inheritedtypehidesenclosingname} instead */
int interfaceinheritednamehidesenclosingname =  typerelated + 334 + problemreasons.inheritednamehidesenclosingname; // typerelated + 339

// field related problems
int duplicatefield = fieldrelated + 340;
int duplicatemodifierforfield = fieldrelated + 341;
int illegalmodifierforfield = fieldrelated + 342;
int illegalmodifierforinterfacefield = fieldrelated + 343;
int illegalvisibilitymodifiercombinationforfield = fieldrelated + 344;
int illegalmodifiercombinationfinalvolatileforfield = fieldrelated + 345;
int unexpectedstaticmodifierforfield = fieldrelated + 346;

/** @@deprecated - problem is no longer generated, use {@@link #undefinedtype} instead */
int fieldtypenotfound =  fieldrelated + 349 + problemreasons.notfound; // fieldrelated + 350
/** @@deprecated - problem is no longer generated, use {@@link #notvisibletype} instead */
int fieldtypenotvisible =  fieldrelated + 349 + problemreasons.notvisible; // fieldrelated + 351
/** @@deprecated - problem is no longer generated, use {@@link #ambiguoustype} instead */
int fieldtypeambiguous =  fieldrelated + 349 + problemreasons.ambiguous; // fieldrelated + 352
/** @@deprecated - problem is no longer generated, use {@@link #internaltypenameprovided} instead */
int fieldtypeinternalnameprovided =  fieldrelated + 349 + problemreasons.internalnameprovided; // fieldrelated + 353
/** @@deprecated - problem is no longer generated, use {@@link #inheritedtypehidesenclosingname} instead */
int fieldtypeinheritednamehidesenclosingname =  fieldrelated + 349 + problemreasons.inheritednamehidesenclosingname; // fieldrelated + 354

// method related problems
int duplicatemethod = methodrelated + 355;
int illegalmodifierforargument = methodrelated + 356;
int duplicatemodifierformethod = methodrelated + 357;
int illegalmodifierformethod = methodrelated + 358;
int illegalmodifierforinterfacemethod = methodrelated + 359;
int illegalvisibilitymodifiercombinationformethod = methodrelated + 360;
int unexpectedstaticmodifierformethod = methodrelated + 361;
int illegalabstractmodifiercombinationformethod = methodrelated + 362;
int abstractmethodinabstractclass = methodrelated + 363;
int argumenttypecannotbevoid = methodrelated + 364;
/** @@deprecated - problem is no longer generated, use {@@link #cannotallocatevoidarray} instead */
int argumenttypecannotbevoidarray = methodrelated + 365;
/** @@deprecated - problem is no longer generated, use {@@link #cannotallocatevoidarray} instead */
int returntypecannotbevoidarray = methodrelated + 366;
int nativemethodscannotbestrictfp = methodrelated + 367;
int duplicatemodifierforargument = methodrelated + 368;
/** @@since 3.5 */
int illegalmodifierforconstructor = methodrelated + 369;

/** @@deprecated - problem is no longer generated, use {@@link #undefinedtype} instead */
int argumenttypenotfound =  methodrelated + 369 + problemreasons.notfound; // methodrelated + 370
/** @@deprecated - problem is no longer generated, use {@@link #notvisibletype} instead */
int argumenttypenotvisible =  methodrelated + 369 + problemreasons.notvisible; // methodrelated + 371
/** @@deprecated - problem is no longer generated, use {@@link #ambiguoustype} instead */
int argumenttypeambiguous =  methodrelated + 369 + problemreasons.ambiguous; // methodrelated + 372
/** @@deprecated - problem is no longer generated, use {@@link #internaltypenameprovided} instead */
int argumenttypeinternalnameprovided =  methodrelated + 369 + problemreasons.internalnameprovided; // methodrelated + 373
/** @@deprecated - problem is no longer generated, use {@@link #inheritedtypehidesenclosingname} instead */
int argumenttypeinheritednamehidesenclosingname =  methodrelated + 369 + problemreasons.inheritednamehidesenclosingname; // methodrelated + 374

/** @@deprecated - problem is no longer generated, use {@@link #undefinedtype} instead */
int exceptiontypenotfound =  methodrelated + 374 + problemreasons.notfound; // methodrelated + 375
/** @@deprecated - problem is no longer generated, use {@@link #notvisibletype} instead */
int exceptiontypenotvisible =  methodrelated + 374 + problemreasons.notvisible; // methodrelated + 376
/** @@deprecated - problem is no longer generated, use {@@link #ambiguoustype} instead */
int exceptiontypeambiguous =  methodrelated + 374 + problemreasons.ambiguous; // methodrelated + 377
/** @@deprecated - problem is no longer generated, use {@@link #internaltypenameprovided} instead */
int exceptiontypeinternalnameprovided =  methodrelated + 374 + problemreasons.internalnameprovided; // methodrelated + 378
/** @@deprecated - problem is no longer generated, use {@@link #inheritedtypehidesenclosingname} instead */
int exceptiontypeinheritednamehidesenclosingname =  methodrelated + 374 + problemreasons.inheritednamehidesenclosingname; // methodrelated + 379

/** @@deprecated - problem is no longer generated, use {@@link #undefinedtype} instead */
int returntypenotfound =  methodrelated + 379 + problemreasons.notfound; // methodrelated + 380
/** @@deprecated - problem is no longer generated, use {@@link #notvisibletype} instead */
int returntypenotvisible =  methodrelated + 379 + problemreasons.notvisible; // methodrelated + 381
/** @@deprecated - problem is no longer generated, use {@@link #ambiguoustype} instead */
int returntypeambiguous =  methodrelated + 379 + problemreasons.ambiguous; // methodrelated + 382
/** @@deprecated - problem is no longer generated, use {@@link #internaltypenameprovided} instead */
int returntypeinternalnameprovided =  methodrelated + 379 + problemreasons.internalnameprovided; // methodrelated + 383
/** @@deprecated - problem is no longer generated, use {@@link #inheritedtypehidesenclosingname} instead */
int returntypeinheritednamehidesenclosingname =  methodrelated + 379 + problemreasons.inheritednamehidesenclosingname; // methodrelated + 384

// import related problems
int conflictingimport = importrelated + 385;
int duplicateimport = importrelated + 386;
int cannotimportpackage = importrelated + 387;
int unusedimport = importrelated + 388;

int importnotfound =  importrelated + 389 + problemreasons.notfound; // importrelated + 390
/** @@deprecated - problem is no longer generated, use {@@link #notvisibletype} instead */
int importnotvisible =  importrelated + 389 + problemreasons.notvisible; // importrelated + 391
/** @@deprecated - problem is no longer generated, use {@@link #ambiguoustype} instead */
int importambiguous =  importrelated + 389 + problemreasons.ambiguous; // importrelated + 392
/** @@deprecated - problem is no longer generated, use {@@link #internaltypenameprovided} instead */
int importinternalnameprovided =  importrelated + 389 + problemreasons.internalnameprovided; // importrelated + 393
/** @@deprecated - problem is no longer generated, use {@@link #inheritedtypehidesenclosingname} instead */
int importinheritednamehidesenclosingname =  importrelated + 389 + problemreasons.inheritednamehidesenclosingname; // importrelated + 394

/** @@since 3.1 */
int invalidtypeforstaticimport =  importrelated + 391;

// local variable related problems
int duplicatemodifierforvariable = methodrelated + 395;
int illegalmodifierforvariable = methodrelated + 396;
/** @@deprecated - problem is no longer generated, use {@@link #redundantnullcheckonnonnulllocalvariable} instead */
int localvariablecannotbenull = internal + 397; // since 3.3: semantics are localvariableredundantcheckonnonnull
/** @@deprecated - problem is no longer generated, use {@@link #nulllocalvariablereference}, {@@link #redundantnullcheckonnulllocalvariable} or {@@link #redundantlocalvariablenullassignment} instead */
int localvariablecanonlybenull = internal + 398; // since 3.3: split with localvariableredundantcheckonnull depending on context
/** @@deprecated - problem is no longer generated, use {@@link #potentialnulllocalvariablereference} instead */
int localvariablemaybenull = internal + 399;

// method verifier problems
int abstractmethodmustbeimplemented = methodrelated + 400;
int finalmethodcannotbeoverridden = methodrelated + 401;
int incompatibleexceptioninthrowsclause = methodrelated + 402;
int incompatibleexceptionininheritedmethodthrowsclause = methodrelated + 403;
int incompatiblereturntype = methodrelated + 404;
int inheritedmethodreducesvisibility = methodrelated + 405;
int cannotoverrideastaticmethodwithaninstancemethod = methodrelated + 406;
int cannothideaninstancemethodwithastaticmethod = methodrelated + 407;
int staticinheritedmethodconflicts = methodrelated + 408;
int methodreducesvisibility = methodrelated + 409;
int overridingnonvisiblemethod = methodrelated + 410;
int abstractmethodcannotbeoverridden = methodrelated + 411;
int overridingdeprecatedmethod = methodrelated + 412;
/** @@since 2.1 */
int incompatiblereturntypefornoninheritedinterfacemethod = methodrelated + 413;
/** @@since 2.1 */
int incompatibleexceptioninthrowsclausefornoninheritedinterfacemethod = methodrelated + 414;
/** @@since 3.1 */
int illegalvararg = methodrelated + 415;
/** @@since 3.3 */
int overridingmethodwithoutsuperinvocation = methodrelated + 416;
/** @@since 3.5 */
int missingsynchronizedmodifierininheritedmethod= methodrelated + 417;
/** @@since 3.5 */
int abstractmethodmustbeimplementedoverconcretemethod = methodrelated + 418;
/** @@since 3.5 */
int inheritedincompatiblereturntype = methodrelated + 419;

// code snippet support
int codesnippetmissingclass = internal + 420;
int codesnippetmissingmethod = internal + 421;
int cannotusesuperincodesnippet = internal + 422;

//constant pool
int toomanyconstantsinconstantpool = internal + 430;
/** @@since 2.1 */
int toomanybytesforstringconstant = internal + 431;

// static constraints
/** @@since 2.1 */
int toomanyfields = internal + 432;
/** @@since 2.1 */
int toomanymethods = internal + 433;

// 1.4 features
// assertion warning
int useassertasanidentifier = internal + 440;

// 1.5 features
int useenumasanidentifier = internal + 441;
/** @@since 3.2 */
int enumconstantscannotbesurroundedbyparenthesis = syntax + internal + 442;

// detected task
/** @@since 2.1 */
int task = internal + 450;

// local variables related problems, cont'd
/** @@since 3.3 */
int nulllocalvariablereference = internal + 451;
/** @@since 3.3 */
int potentialnulllocalvariablereference = internal + 452;
/** @@since 3.3 */
int redundantnullcheckonnulllocalvariable = internal + 453;
/** @@since 3.3 */
int nulllocalvariablecomparisonyieldsfalse = internal + 454;
/** @@since 3.3 */
int redundantlocalvariablenullassignment = internal + 455;
/** @@since 3.3 */
int nulllocalvariableinstanceofyieldsfalse = internal + 456;
/** @@since 3.3 */
int redundantnullcheckonnonnulllocalvariable = internal + 457;
/** @@since 3.3 */
int nonnulllocalvariablecomparisonyieldsfalse = internal + 458;

// block
/** @@since 3.0 */
int undocumentedemptyblock = internal + 460;

/*
* javadoc comments
*/
/**
* problem signaled on an invalid url reference.
* valid syntax example: @@see "http://www.eclipse.org/"
* @@since 3.4
*/
int javadocinvalidseeurlreference = javadoc + internal + 462;
/**
* problem warned on missing tag description.
* @@since 3.4
*/
int javadocmissingtagdescription = javadoc + internal + 463;
/**
* problem warned on duplicated tag.
* @@since 3.3
*/
int javadocduplicatetag = javadoc + internal + 464;
/**
* problem signaled on an hidden reference due to a too low visibility level.
* @@since 3.3
*/
int javadochiddenreference = javadoc + internal + 465;
/**
* problem signaled on an invalid qualification for member type reference.
* @@since 3.3
*/
int javadocinvalidmembertypequalification = javadoc + internal + 466;
/** @@since 3.2 */
int javadocmissingidentifier = javadoc + internal + 467;
/** @@since 3.2 */
int javadocnonstatictypefromstaticinvocation = javadoc + internal + 468;
/** @@since 3.1 */
int javadocinvalidparamtagtypeparameter = javadoc + internal + 469;
/** @@since 3.0 */
int javadocunexpectedtag = javadoc + internal + 470;
/** @@since 3.0 */
int javadocmissingparamtag = javadoc + internal + 471;
/** @@since 3.0 */
int javadocmissingparamname = javadoc + internal + 472;
/** @@since 3.0 */
int javadocduplicateparamname = javadoc + internal + 473;
/** @@since 3.0 */
int javadocinvalidparamname = javadoc + internal + 474;
/** @@since 3.0 */
int javadocmissingreturntag = javadoc + internal + 475;
/** @@since 3.0 */
int javadocduplicatereturntag = javadoc + internal + 476;
/** @@since 3.0 */
int javadocmissingthrowstag = javadoc + internal + 477;
/** @@since 3.0 */
int javadocmissingthrowsclassname = javadoc + internal + 478;
/** @@since 3.0 */
int javadocinvalidthrowsclass = javadoc + internal + 479;
/** @@since 3.0 */
int javadocduplicatethrowsclassname = javadoc + internal + 480;
/** @@since 3.0 */
int javadocinvalidthrowsclassname = javadoc + internal + 481;
/** @@since 3.0 */
int javadocmissingseereference = javadoc + internal + 482;
/** @@since 3.0 */
int javadocinvalidseereference = javadoc + internal + 483;
/**
* problem signaled on an invalid url reference that does not conform to the href syntax.
* valid syntax example: @@see <a href="http://www.eclipse.org/">eclipse home page</a>
* @@since 3.0
*/
int javadocinvalidseehref = javadoc + internal + 484;
/** @@since 3.0 */
int javadocinvalidseeargs = javadoc + internal + 485;
/** @@since 3.0 */
int javadocmissing = javadoc + internal + 486;
/** @@since 3.0 */
int javadocinvalidtag = javadoc + internal + 487;
/*
* id for field errors in javadoc
*/
/** @@since 3.0 */
int javadocundefinedfield = javadoc + internal + 488;
/** @@since 3.0 */
int javadocnotvisiblefield = javadoc + internal + 489;
/** @@since 3.0 */
int javadocambiguousfield = javadoc + internal + 490;
/** @@since 3.0 */
int javadocusingdeprecatedfield = javadoc + internal + 491;
/*
* ids for constructor errors in javadoc
*/
/** @@since 3.0 */
int javadocundefinedconstructor = javadoc + internal + 492;
/** @@since 3.0 */
int javadocnotvisibleconstructor = javadoc + internal + 493;
/** @@since 3.0 */
int javadocambiguousconstructor = javadoc + internal + 494;
/** @@since 3.0 */
int javadocusingdeprecatedconstructor = javadoc + internal + 495;
/*
* ids for method errors in javadoc
*/
/** @@since 3.0 */
int javadocundefinedmethod = javadoc + internal + 496;
/** @@since 3.0 */
int javadocnotvisiblemethod = javadoc + internal + 497;
/** @@since 3.0 */
int javadocambiguousmethod = javadoc + internal + 498;
/** @@since 3.0 */
int javadocusingdeprecatedmethod = javadoc + internal + 499;
/** @@since 3.0 */
int javadocnomessagesendonbasetype = javadoc + internal + 500;
/** @@since 3.0 */
int javadocparametermismatch = javadoc + internal + 501;
/** @@since 3.0 */
int javadocnomessagesendonarraytype = javadoc + internal + 502;
/*
* ids for type errors in javadoc
*/
/** @@since 3.0 */
int javadocundefinedtype = javadoc + internal + 503;
/** @@since 3.0 */
int javadocnotvisibletype = javadoc + internal + 504;
/** @@since 3.0 */
int javadocambiguoustype = javadoc + internal + 505;
/** @@since 3.0 */
int javadocusingdeprecatedtype = javadoc + internal + 506;
/** @@since 3.0 */
int javadocinternaltypenameprovided = javadoc + internal + 507;
/** @@since 3.0 */
int javadocinheritedmethodhidesenclosingname = javadoc + internal + 508;
/** @@since 3.0 */
int javadocinheritedfieldhidesenclosingname = javadoc + internal + 509;
/** @@since 3.0 */
int javadocinheritednamehidesenclosingtypename = javadoc + internal + 510;
/** @@since 3.0 */
int javadocambiguousmethodreference = javadoc + internal + 511;
/** @@since 3.0 */
int javadocunterminatedinlinetag = javadoc + internal + 512;
/** @@since 3.0 */
int javadocmalformedseereference = javadoc + internal + 513;
/** @@since 3.0 */
int javadocmessageprefix = internal + 514;

/** @@since 3.1 */
int javadocmissinghashcharacter = javadoc + internal + 515;
/** @@since 3.1 */
int javadocemptyreturntag = javadoc + internal + 516;
/** @@since 3.1 */
int javadocinvalidvaluereference = javadoc + internal + 517;
/** @@since 3.1 */
int javadocunexpectedtext = javadoc + internal + 518;
/** @@since 3.1 */
int javadocinvalidparamtagname = javadoc + internal + 519;

/**
* generics
*/
/** @@since 3.1 */
int duplicatetypevariable = internal + 520;
/** @@since 3.1 */
int illegaltypevariablesuperreference = internal + 521;
/** @@since 3.1 */
int nonstatictypefromstaticinvocation = internal + 522;
/** @@since 3.1 */
int objectcannotbegeneric = internal + 523;
/** @@since 3.1 */
int nongenerictype = typerelated + 524;
/** @@since 3.1 */
int incorrectarityforparameterizedtype = typerelated + 525;
/** @@since 3.1 */
int typeargumentmismatch = typerelated + 526;
/** @@since 3.1 */
int duplicatemethoderasure = typerelated + 527;
/** @@since 3.1 */
int referencetoforwardtypevariable = typerelated + 528;
/** @@since 3.1 */
int boundmustbeaninterface = typerelated + 529;
/** @@since 3.1 */
int unsaferawconstructorinvocation = typerelated + 530;
/** @@since 3.1 */
int unsaferawmethodinvocation = typerelated + 531;
/** @@since 3.1 */
int unsafetypeconversion = typerelated + 532;
/** @@since 3.1 */
int invalidtypevariableexceptiontype = typerelated + 533;
/** @@since 3.1 */
int invalidparameterizedexceptiontype = typerelated + 534;
/** @@since 3.1 */
int illegalgenericarray = typerelated + 535;
/** @@since 3.1 */
int unsaferawfieldassignment = typerelated + 536;
/** @@since 3.1 */
int finalboundfortypevariable = typerelated + 537;
/** @@since 3.1 */
int undefinedtypevariable = internal + 538;
/** @@since 3.1 */
int superinterfacescollide = typerelated + 539;
/** @@since 3.1 */
int wildcardconstructorinvocation = typerelated + 540;
/** @@since 3.1 */
int wildcardmethodinvocation = typerelated + 541;
/** @@since 3.1 */
int wildcardfieldassignment = typerelated + 542;
/** @@since 3.1 */
int genericmethodtypeargumentmismatch = typerelated + 543;
/** @@since 3.1 */
int genericconstructortypeargumentmismatch = typerelated + 544;
/** @@since 3.1 */
int unsafegenericcast = typerelated + 545;
/** @@since 3.1 */
int illegalinstanceofparameterizedtype = internal + 546;
/** @@since 3.1 */
int illegalinstanceoftypeparameter = internal + 547;
/** @@since 3.1 */
int nongenericmethod = typerelated + 548;
/** @@since 3.1 */
int incorrectarityforparameterizedmethod = typerelated + 549;
/** @@since 3.1 */
int parameterizedmethodargumenttypemismatch = typerelated + 550;
/** @@since 3.1 */
int nongenericconstructor = typerelated + 551;
/** @@since 3.1 */
int incorrectarityforparameterizedconstructor = typerelated + 552;
/** @@since 3.1 */
int parameterizedconstructorargumenttypemismatch = typerelated + 553;
/** @@since 3.1 */
int typeargumentsforrawgenericmethod = typerelated + 554;
/** @@since 3.1 */
int typeargumentsforrawgenericconstructor = typerelated + 555;
/** @@since 3.1 */
int supertypeusingwildcard = typerelated + 556;
/** @@since 3.1 */
int generictypecannotextendthrowable = typerelated + 557;
/** @@since 3.1 */
int illegalclassliteralfortypevariable = typerelated + 558;
/** @@since 3.1 */
int unsafereturntypeoverride = methodrelated + 559;
/** @@since 3.1 */
int methodnameclash = methodrelated + 560;
/** @@since 3.1 */
int rawmembertypecannotbeparameterized = typerelated + 561;
/** @@since 3.1 */
int missingargumentsforparameterizedmembertype = typerelated + 562;
/** @@since 3.1 */
int staticmemberofparameterizedtype = typerelated + 563;
/** @@since 3.1 */
int boundhasconflictingarguments = typerelated + 564;
/** @@since 3.1 */
int duplicateparameterizedmethods = methodrelated + 565;
/** @@since 3.1 */
int illegalqualifiedparameterizedtypeallocation = typerelated + 566;
/** @@since 3.1 */
int duplicatebounds = typerelated + 567;
/** @@since 3.1 */
int boundcannotbearray = typerelated + 568;
/** @@since 3.1 */
int unsaferawgenericconstructorinvocation = typerelated + 569;
/** @@since 3.1 */
int unsaferawgenericmethodinvocation = typerelated + 570;
/** @@since 3.1 */
int typeparameterhidingtype = typerelated + 571;
/** @@since 3.2 */
int rawtypereference = typerelated + 572;
/** @@since 3.2 */
int noadditionalboundaftertypevariable = typerelated + 573;
/** @@since 3.2 */
int unsafegenericarrayforvarargs = methodrelated + 574;
/** @@since 3.2 */
int illegalaccessfromtypevariable = typerelated + 575;
/** @@since 3.3 */
int typehidingtypeparameterfromtype = typerelated + 576;
/** @@since 3.3 */
int typehidingtypeparameterfrommethod = typerelated + 577;
/** @@since 3.3 */
int invalidusageofwildcard = syntax + internal + 578;
/** @@since 3.4 */
int unusedtypeargumentsformethodinvocation = methodrelated + 579;

/**
* foreach
*/
/** @@since 3.1 */
int incompatibletypesinforeach = typerelated + 580;
/** @@since 3.1 */
int invalidtypeforcollection = internal + 581;
/** @@since 3.6*/
int invalidtypeforcollectiontarget14 = internal + 582;

/**
* 1.5 syntax errors (when source level < 1.5)
*/
/** @@since 3.1 */
int invalidusageoftypeparameters = syntax + internal + 590;
/** @@since 3.1 */
int invalidusageofstaticimports = syntax + internal + 591;
/** @@since 3.1 */
int invalidusageofforeachstatements = syntax + internal + 592;
/** @@since 3.1 */
int invalidusageoftypearguments = syntax + internal + 593;
/** @@since 3.1 */
int invalidusageofenumdeclarations = syntax + internal + 594;
/** @@since 3.1 */
int invalidusageofvarargs = syntax + internal + 595;
/** @@since 3.1 */
int invalidusageofannotations = syntax + internal + 596;
/** @@since 3.1 */
int invalidusageofannotationdeclarations = syntax + internal + 597;
/** @@since 3.4 */
int invalidusageoftypeparametersforannotationdeclaration = syntax + internal + 598;
/** @@since 3.4 */
int invalidusageoftypeparametersforenumdeclaration = syntax + internal + 599;
/**
* annotation
*/
/** @@since 3.1 */
int illegalmodifierforannotationmethod = methodrelated + 600;
/** @@since 3.1 */
int illegalextendeddimensions = methodrelated + 601;
/** @@since 3.1 */
int invalidfilenameforpackageannotations = syntax + internal + 602;
/** @@since 3.1 */
int illegalmodifierforannotationtype = typerelated + 603;
/** @@since 3.1 */
int illegalmodifierforannotationmembertype = typerelated + 604;
/** @@since 3.1 */
int invalidannotationmembertype = typerelated + 605;
/** @@since 3.1 */
int annotationcircularityselfreference = typerelated + 606;
/** @@since 3.1 */
int annotationcircularity = typerelated + 607;
/** @@since 3.1 */
int duplicateannotation = typerelated + 608;
/** @@since 3.1 */
int missingvalueforannotationmember = typerelated + 609;
/** @@since 3.1 */
int duplicateannotationmember = internal + 610;
/** @@since 3.1 */
int undefinedannotationmember = methodrelated + 611;
/** @@since 3.1 */
int annotationvaluemustbeclassliteral = internal + 612;
/** @@since 3.1 */
int annotationvaluemustbeconstant = internal + 613;
/** @@deprecated - problem is no longer generated (code is legite)
*   @@since 3.1 */
int annotationfieldneedconstantinitialization = internal + 614;
/** @@since 3.1 */
int illegalmodifierforannotationfield = internal + 615;
/** @@since 3.1 */
int annotationcannotoverridemethod = methodrelated + 616;
/** @@since 3.1 */
int annotationmemberscannothaveparameters = syntax + internal + 617;
/** @@since 3.1 */
int annotationmemberscannothavetypeparameters = syntax + internal + 618;
/** @@since 3.1 */
int annotationtypedeclarationcannothavesuperclass = syntax + internal + 619;
/** @@since 3.1 */
int annotationtypedeclarationcannothavesuperinterfaces = syntax + internal + 620;
/** @@since 3.1 */
int duplicatetargetintargetannotation = internal + 621;
/** @@since 3.1 */
int disallowedtargetforannotation = typerelated + 622;
/** @@since 3.1 */
int methodmustoverride = methodrelated + 623;
/** @@since 3.1 */
int annotationtypedeclarationcannothaveconstructor = syntax + internal + 624;
/** @@since 3.1 */
int annotationvaluemustbeannotation = internal + 625;
/** @@since 3.1 */
int annotationtypeusedassuperinterface = typerelated + 626;
/** @@since 3.1 */
int missingoverrideannotation = methodrelated + 627;
/** @@since 3.1 */
int fieldmissingdeprecatedannotation = internal + 628;
/** @@since 3.1 */
int methodmissingdeprecatedannotation = internal + 629;
/** @@since 3.1 */
int typemissingdeprecatedannotation = internal + 630;
/** @@since 3.1 */
int unhandledwarningtoken = internal + 631;
/** @@since 3.2 */
int annotationvaluemustbearrayinitializer = internal + 632;
/** @@since 3.3 */
int annotationvaluemustbeanenumconstant = internal + 633;
/** @@since 3.3 */
int methodmustoverrideorimplement = methodrelated + 634;
/** @@since 3.4 */
int unusedwarningtoken = internal + 635;
/** @@since 3.6 */
int missingoverrideannotationforinterfacemethodimplementation = methodrelated + 636;

/**
* more problems in generics
*/
/** @@since 3.4 */
int unusedtypeargumentsforconstructorinvocation = methodrelated + 660;

/**
* corrupted binaries
*/
/** @@since 3.1 */
int corruptedsignature = internal + 700;
/**
* corrupted source
*/
/** @@since 3.2 */
int invalidencoding = internal + 701;
/** @@since 3.2 */
int cannotreadsource = internal + 702;

/**
* autoboxing
*/
/** @@since 3.1 */
int boxingconversion = internal + 720;
/** @@since 3.1 */
int unboxingconversion = internal + 721;

/**
* enum
*/
/** @@since 3.1 */
int illegalmodifierforenum = typerelated + 750;
/** @@since 3.1 */
int illegalmodifierforenumconstant = fieldrelated + 751;
/** @@deprecated - problem could not be reported, enums cannot be local takes precedence
*   @@since 3.1 */
int illegalmodifierforlocalenum = typerelated + 752;
/** @@since 3.1 */
int illegalmodifierformemberenum = typerelated + 753;
/** @@since 3.1 */
int cannotdeclareenumspecialmethod = methodrelated + 754;
/** @@since 3.1 */
int illegalqualifiedenumconstantlabel = fieldrelated + 755;
/** @@since 3.1 */
int cannotextendenum = typerelated + 756;
/** @@since 3.1 */
int cannotinvokesuperconstructorinenum = methodrelated + 757;
/** @@since 3.1 */
int enumabstractmethodmustbeimplemented = methodrelated + 758;
/** @@since 3.1 */
int enumswitchcannottargetfield = fieldrelated + 759;
/** @@since 3.1 */
int illegalmodifierforenumconstructor = methodrelated + 760;
/** @@since 3.1 */
int missingenumconstantcase = fieldrelated + 761;
/** @@since 3.2 */ // todo need to fix 3.1.1 contribution (inline this constant on client side)
int enumstaticfieldinininitializercontext = fieldrelated + 762;
/** @@since 3.4 */
int enumconstantmustimplementabstractmethod = methodrelated + 763;
/** @@since 3.5 */
int enumconstantcannotdefineabstractmethod = methodrelated + 764;
/** @@since 3.5 */
int abstractmethodinenum = methodrelated + 765;

/**
* var args
*/
/** @@since 3.1 */
int illegalextendeddimensionsforvarargs = syntax + internal + 800;
/** @@since 3.1 */
int methodvarargsargumentneedcast = methodrelated + 801;
/** @@since 3.1 */
int constructorvarargsargumentneedcast = constructorrelated + 802;
/** @@since 3.1 */
int varargsconflict = methodrelated + 803;

/**
* javadoc generic
*/
/** @@since 3.1 */
int javadocgenericmethodtypeargumentmismatch = javadoc + internal + 850;
/** @@since 3.1 */
int javadocnongenericmethod = javadoc + internal + 851;
/** @@since 3.1 */
int javadocincorrectarityforparameterizedmethod = javadoc + internal + 852;
/** @@since 3.1 */
int javadocparameterizedmethodargumenttypemismatch = javadoc + internal + 853;
/** @@since 3.1 */
int javadoctypeargumentsforrawgenericmethod = javadoc + internal + 854;
/** @@since 3.1 */
int javadocgenericconstructortypeargumentmismatch = javadoc + internal + 855;
/** @@since 3.1 */
int javadocnongenericconstructor = javadoc + internal + 856;
/** @@since 3.1 */
int javadocincorrectarityforparameterizedconstructor = javadoc + internal + 857;
/** @@since 3.1 */
int javadocparameterizedconstructorargumenttypemismatch = javadoc + internal + 858;
/** @@since 3.1 */
int javadoctypeargumentsforrawgenericconstructor = javadoc + internal + 859;

/**
* external problems -- these are problems defined by other plugins
*/

/** @@since 3.2 */
int externalproblemnotfixable = 900;

// indicates an externally defined problem that has a quick-assist processor
// associated with it
/** @@since 3.2 */
int externalproblemfixable = 901;
}
