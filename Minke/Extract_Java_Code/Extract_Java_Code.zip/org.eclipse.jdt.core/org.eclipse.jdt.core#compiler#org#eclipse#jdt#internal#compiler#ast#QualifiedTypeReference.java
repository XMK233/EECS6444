/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.problem.abortcompilation;

public class qualifiedtypereference extends typereference {

public char[][] tokens;
public long[] sourcepositions;

public qualifiedtypereference(char[][] sources , long[] poss) {

this.tokens = sources ;
this.sourcepositions = poss ;
this.sourcestart = (int) (this.sourcepositions[0]>>>32) ;
this.sourceend = (int)(this.sourcepositions[this.sourcepositions.length-1] & 0x00000000ffffffffl ) ;
}

public typereference copydims(int dim){
//return a type reference copy of me with some dimensions
//warning : the new type ref has a null binding
return new arrayqualifiedtypereference(this.tokens, dim, this.sourcepositions);
}

protected typebinding findnexttypebinding(int tokenindex, scope scope, packagebinding packagebinding) {
lookupenvironment env = scope.environment();
try {
env.missingclassfilelocation = this;
if (this.resolvedtype == null) {
this.resolvedtype = scope.gettype(this.tokens[tokenindex], packagebinding);
} else {
this.resolvedtype = scope.getmembertype(this.tokens[tokenindex], (referencebinding) this.resolvedtype);
if (!this.resolvedtype.isvalidbinding()) {
this.resolvedtype = new problemreferencebinding(
charoperation.subarray(this.tokens, 0, tokenindex + 1),
(referencebinding)this.resolvedtype.closestmatch(),
this.resolvedtype.problemid());
}
}
return this.resolvedtype;
} catch (abortcompilation e) {
e.updatecontext(this, scope.referencecompilationunit().compilationresult);
throw e;
} finally {
env.missingclassfilelocation = null;
}
}

public char[] getlasttoken() {
return this.tokens[this.tokens.length-1];
}
protected typebinding gettypebinding(scope scope) {

if (this.resolvedtype != null) {
return this.resolvedtype;
}
binding binding = scope.getpackage(this.tokens);
if (binding != null && !binding.isvalidbinding()) {
if (binding instanceof problemreferencebinding && binding.problemid() == problemreasons.notfound) {
problemreferencebinding problembinding = (problemreferencebinding) binding;
binding pkg = scope.gettypeorpackage(this.tokens);
return new problemreferencebinding(problembinding.compoundname, pkg instanceof packagebinding ? null : scope.environment().createmissingtype(null, this.tokens), problemreasons.notfound);
}
return (referencebinding) binding; // not found
}
packagebinding packagebinding = binding == null ? null : (packagebinding) binding;
boolean isclassscope = scope.kind == scope.class_scope;
referencebinding qualifiedtype = null;
for (int i = packagebinding == null ? 0 : packagebinding.compoundname.length, max = this.tokens.length, last = max-1; i < max; i++) {
findnexttypebinding(i, scope, packagebinding);
if (!this.resolvedtype.isvalidbinding())
return this.resolvedtype;
if (i == 0 && this.resolvedtype.istypevariable() && ((typevariablebinding) this.resolvedtype).firstbound == null) { // cannot select from a type variable
scope.problemreporter().illegalaccessfromtypevariable((typevariablebinding) this.resolvedtype, this);
return null;
}
if (i <= last && istypeusedeprecated(this.resolvedtype, scope)) {
reportdeprecatedtype(this.resolvedtype, scope, i);
}
if (isclassscope)
if (((classscope) scope).detecthierarchycycle(this.resolvedtype, this)) // must connect hierarchy to find inherited member types
return null;
referencebinding currenttype = (referencebinding) this.resolvedtype;
if (qualifiedtype != null) {
referencebinding enclosingtype = currenttype.enclosingtype();
if (enclosingtype != null && enclosingtype.erasure() != qualifiedtype.erasure()) {
qualifiedtype = enclosingtype; // inherited member type, leave it associated with its enclosing rather than subtype
}
boolean rawqualified;
if (currenttype.isgenerictype()) {
qualifiedtype = scope.environment().createrawtype(currenttype, qualifiedtype);
} else if ((rawqualified = qualifiedtype.israwtype()) && !currenttype.isstatic()) {
qualifiedtype = scope.environment().createrawtype((referencebinding)currenttype.erasure(), qualifiedtype);
} else if ((rawqualified || qualifiedtype.isparameterizedtype()) && qualifiedtype.erasure() == currenttype.enclosingtype().erasure()) {
qualifiedtype = scope.environment().createparameterizedtype((referencebinding)currenttype.erasure(), null, qualifiedtype);
} else {
qualifiedtype = currenttype;
}
} else {
qualifiedtype = currenttype.isgenerictype() ? (referencebinding)scope.environment().converttorawtype(currenttype, false /*do not force conversion of enclosing types*/) : currenttype;
}
}
this.resolvedtype = qualifiedtype;
return this.resolvedtype;
}

public char[][] gettypename(){

return this.tokens;
}

public stringbuffer printexpression(int indent, stringbuffer output) {

for (int i = 0; i < this.tokens.length; i++) {
if (i > 0) output.append('.');
output.append(this.tokens[i]);
}
return output;
}

public void traverse(astvisitor visitor, blockscope scope) {

visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {

visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
