/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.codegen.branchlabel;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;

/**
* reflects the context of code analysis, keeping track of enclosing
*	try statements, exception handlers, etc...
*/
public class labelflowcontext extends switchflowcontext {

public char[] labelname;

public labelflowcontext(flowcontext parent, astnode associatednode, char[] labelname, branchlabel breaklabel, blockscope scope) {
super(parent, associatednode, breaklabel);
this.labelname = labelname;
checklabelvalidity(scope);
}

void checklabelvalidity(blockscope scope) {
// check if label was already defined above
flowcontext current = this.parent;
while (current != null) {
char[] currentlabelname;
if (((currentlabelname = current.labelname()) != null)
&& charoperation.equals(currentlabelname, this.labelname)) {
scope.problemreporter().alreadydefinedlabel(this.labelname, this.associatednode);
}
current = current.parent;
}
}

public string individualtostring() {
return "label flow context [label:" + string.valueof(this.labelname) + "]"; //$non-nls-2$ //$non-nls-1$
}

public char[] labelname() {
return this.labelname;
}
}
