/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     genady beriozkin - added support for reporting assignment with no effect
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class assignment extends expression {

public expression lhs;
public expression expression;

public assignment(expression lhs, expression expression, int sourceend) {
//lhs is always a reference by construction ,
//but is build as an expression ==> the checkcast cannot fail
this.lhs = lhs;
lhs.bits |= isstrictlyassigned; // tag lhs as assigned
this.expression = expression;
this.sourcestart = lhs.sourcestart;
this.sourceend = sourceend;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
// record setting a variable: various scenarii are possible, setting an array reference,
// a field reference, a blank final field reference, a field of an enclosing instance or
// just a local variable.
localvariablebinding local = this.lhs.localvariablebinding();
int nullstatus = this.expression.nullstatus(flowinfo);
if (local != null && (local.type.tagbits & tagbits.isbasetype) == 0) {
if (nullstatus == flowinfo.null) {
flowcontext.recordusingnullreference(currentscope, local, this.lhs,
flowcontext.can_only_null | flowcontext.in_assignment, flowinfo);
}
}
flowinfo = ((reference) this.lhs)
.analyseassignment(currentscope, flowcontext, flowinfo, this, false)
.unconditionalinits();
if (local != null && (local.type.tagbits & tagbits.isbasetype) == 0) {
switch(nullstatus) {
case flowinfo.null :
flowinfo.markasdefinitelynull(local);
break;
case flowinfo.non_null :
flowinfo.markasdefinitelynonnull(local);
break;
default:
flowinfo.markasdefinitelyunknown(local);
}
if (flowcontext.initsonfinally != null) {
switch(nullstatus) {
case flowinfo.null :
flowcontext.initsonfinally.markasdefinitelynull(local);
break;
case flowinfo.non_null :
flowcontext.initsonfinally.markasdefinitelynonnull(local);
break;
default:
flowcontext.initsonfinally.markasdefinitelyunknown(local);
}
}
}
return flowinfo;
}

void checkassignment(blockscope scope, typebinding lhstype, typebinding rhstype) {
fieldbinding leftfield = getlastfield(this.lhs);
if (leftfield != null &&  rhstype != typebinding.null && (lhstype.kind() == binding.wildcard_type) && ((wildcardbinding)lhstype).boundkind != wildcard.super) {
scope.problemreporter().wildcardassignment(lhstype, rhstype, this.expression);
} else if (leftfield != null && !leftfield.isstatic() && leftfield.declaringclass != null /*length pseudo field*/&& leftfield.declaringclass.israwtype()) {
scope.problemreporter().unsaferawfieldassignment(leftfield, rhstype, this.lhs);
} else if (rhstype.needsuncheckedconversion(lhstype)) {
scope.problemreporter().unsafetypeconversion(this.expression, rhstype, lhstype);
}
}

public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
// various scenarii are possible, setting an array reference,
// a field reference, a blank final field reference, a field of an enclosing instance or
// just a local variable.

int pc = codestream.position;
((reference) this.lhs).generateassignment(currentscope, codestream, this, valuerequired);
// variable may have been optimized out
// the lhs is responsible to perform the implicitconversion generation for the assignment since optimized for unused local assignment.
codestream.recordpositionsfrom(pc, this.sourcestart);
}

fieldbinding getlastfield(expression someexpression) {
if (someexpression instanceof singlenamereference) {
if ((someexpression.bits & restrictiveflagmask) == binding.field) {
return (fieldbinding) ((singlenamereference)someexpression).binding;
}
} else if (someexpression instanceof fieldreference) {
return ((fieldreference)someexpression).binding;
} else if (someexpression instanceof qualifiednamereference) {
qualifiednamereference qname = (qualifiednamereference) someexpression;
if (qname.otherbindings == null) {
if ((someexpression.bits & restrictiveflagmask) == binding.field) {
return (fieldbinding)qname.binding;
}
} else {
return qname.otherbindings[qname.otherbindings.length - 1];
}
}
return null;
}

public int nullstatus(flowinfo flowinfo) {
return this.expression.nullstatus(flowinfo);
}

public stringbuffer print(int indent, stringbuffer output) {
//no () when used as a statement
printindent(indent, output);
return printexpressionnoparenthesis(indent, output);
}
public stringbuffer printexpression(int indent, stringbuffer output) {
//subclass redefine printexpressionnoparenthesis()
output.append('(');
return printexpressionnoparenthesis(0, output).append(')');
}

public stringbuffer printexpressionnoparenthesis(int indent, stringbuffer output) {
this.lhs.printexpression(indent, output).append(" = "); //$non-nls-1$
return this.expression.printexpression(0, output);
}

public stringbuffer printstatement(int indent, stringbuffer output) {
//no () when used as a statement
return print(indent, output).append(';');
}

public typebinding resolvetype(blockscope scope) {
// due to syntax lhs may be only a namereference, a fieldreference or an arrayreference
this.constant = constant.notaconstant;
if (!(this.lhs instanceof reference) || this.lhs.isthis()) {
scope.problemreporter().expressionshouldbeavariable(this.lhs);
return null;
}
typebinding lhstype = this.lhs.resolvetype(scope);
this.expression.setexpectedtype(lhstype); // needed in case of generic method invocation
if (lhstype != null) {
this.resolvedtype = lhstype.capture(scope, this.sourceend);
}
typebinding rhstype = this.expression.resolvetype(scope);
if (lhstype == null || rhstype == null) {
return null;
}
// check for assignment with no effect
binding left = getdirectbinding(this.lhs);
if (left != null && left == getdirectbinding(this.expression)) {
scope.problemreporter().assignmenthasnoeffect(this, left.shortreadablename());
}

// compile-time conversion of base-types : implicit narrowing integer into byte/short/character
// may require to widen the rhs expression at runtime
if (lhstype != rhstype) { // must call before computeconversion() and typemismatcherror()
scope.compilationunitscope().recordtypeconversion(lhstype, rhstype);
}
if (this.expression.isconstantvalueoftypeassignabletotype(rhstype, lhstype)
|| rhstype.iscompatiblewith(lhstype)) {
this.expression.computeconversion(scope, lhstype, rhstype);
checkassignment(scope, lhstype, rhstype);
if (this.expression instanceof castexpression
&& (this.expression.bits & astnode.unnecessarycast) == 0) {
castexpression.checkneedforassignedcast(scope, lhstype, (castexpression) this.expression);
}
return this.resolvedtype;
} else if (isboxingcompatible(rhstype, lhstype, this.expression, scope)) {
this.expression.computeconversion(scope, lhstype, rhstype);
if (this.expression instanceof castexpression
&& (this.expression.bits & astnode.unnecessarycast) == 0) {
castexpression.checkneedforassignedcast(scope, lhstype, (castexpression) this.expression);
}
return this.resolvedtype;
}
scope.problemreporter().typemismatcherror(rhstype, lhstype, this.expression, this.lhs);
return lhstype;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#resolvetypeexpecting(org.eclipse.jdt.internal.compiler.lookup.blockscope, org.eclipse.jdt.internal.compiler.lookup.typebinding)
*/
public typebinding resolvetypeexpecting(blockscope scope, typebinding expectedtype) {

typebinding type = super.resolvetypeexpecting(scope, expectedtype);
if (type == null) return null;
typebinding lhstype = this.resolvedtype;
typebinding rhstype = this.expression.resolvedtype;
// signal possible accidental boolean assignment (instead of using '==' operator)
if (expectedtype == typebinding.boolean
&& lhstype == typebinding.boolean
&& (this.lhs.bits & isstrictlyassigned) != 0) {
scope.problemreporter().possibleaccidentalbooleanassignment(this);
}
checkassignment(scope, lhstype, rhstype);
return type;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
this.lhs.traverse(visitor, scope);
this.expression.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
public localvariablebinding localvariablebinding() {
return this.lhs.localvariablebinding();
}
}
