/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.scannerhelper;

public class longliteral extends numberliteral {

public longliteral(char[] token, int s,int e) {
super(token, s,e);
}

public void computeconstant() {
//the overflow (when radix=10) is tested using the fact that
//the value should always grow during its computation
int length = this.source.length - 1; //minus one because the last char is 'l' or 'l'
long computedvalue ;
if (this.source[0] == '0') {
if (length == 1) {
this.constant = longconstant.fromvalue(0l);
return;
}
final int shift,radix;
int j ;
if ( (this.source[1] == 'x') || (this.source[1] == 'x') ) {
shift = 4 ; j = 2; radix = 16;
} else {
shift = 3 ; j = 1; radix = 8;
}
int nbdigit = 0;
while (this.source[j]=='0') {
j++; //jump over redondant zero
if ( j == length) {
//watch for 0000000000000l
this.constant = longconstant.fromvalue(0l);
return;
}
}

int digitvalue ;
if ((digitvalue = scannerhelper.digit(this.source[j++],radix)) < 0 ) {
return; /*constant stays null*/
}
if (digitvalue >= 8)
nbdigit = 4;
else if (digitvalue >= 4)
nbdigit = 3;
else if (digitvalue >= 2)
nbdigit = 2;
else
nbdigit = 1; //digitvalue is not 0
computedvalue = digitvalue ;
while (j<length) {
if ((digitvalue = scannerhelper.digit(this.source[j++],radix)) < 0) {
return; /*constant stays null*/
}
if ((nbdigit += shift) > 64)
return; /*constant stays null*/
computedvalue = (computedvalue<<shift) | digitvalue ;
}
} else {
//-----------case radix=10-----------------
long previous = 0;
computedvalue = 0;
final long limit = long.max_value / 10; // needed to check prior to the multiplication
for (int i = 0 ; i < length; i++) {
int digitvalue ;
if ((digitvalue = scannerhelper.digit(this.source[i], 10)) < 0 ) return /*constant stays null*/;
previous = computedvalue;
if (computedvalue > limit)
return; /*constant stays null*/
computedvalue *= 10;
if ((computedvalue + digitvalue) > long.max_value)
return; /*constant stays null*/
computedvalue += digitvalue;
if (previous > computedvalue)
return; /*constant stays null*/
}
}
this.constant = longconstant.fromvalue(computedvalue);
}

/**
* code generation for long literal
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
if (valuerequired) {
codestream.generateconstant(this.constant, this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public typebinding literaltype(blockscope scope) {
return typebinding.long;
}

public final boolean mayrepresentmin_value(){
//a special autorized int literral is 9223372036854775808l
//which is one over the limit. this special case
//only is used in combinaison with - to denote
//the minimal value of int -9223372036854775808l
return ((this.source.length == 20) &&
(this.source[0] == '9') &&
(this.source[1] == '2') &&
(this.source[2] == '2') &&
(this.source[3] == '3') &&
(this.source[4] == '3') &&
(this.source[5] == '7') &&
(this.source[6] == '2') &&
(this.source[7] == '0') &&
(this.source[8] == '3') &&
(this.source[9] == '6') &&
(this.source[10] == '8') &&
(this.source[11] == '5') &&
(this.source[12] == '4') &&
(this.source[13] == '7') &&
(this.source[14] == '7') &&
(this.source[15] == '5') &&
(this.source[16] == '8') &&
(this.source[17] == '0') &&
(this.source[18] == '8') &&
(((this.bits & astnode.parenthesizedmask) >> astnode.parenthesizedshift) == 0));
}

public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
