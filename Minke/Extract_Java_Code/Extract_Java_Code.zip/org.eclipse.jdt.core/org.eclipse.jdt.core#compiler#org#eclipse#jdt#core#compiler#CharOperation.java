/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     luiz-otavio zorzella <zorzella at gmail dot com> - improve camelcase algorithm
*******************************************************************************/
package org.eclipse.jdt.core.compiler;

import org.eclipse.jdt.internal.compiler.parser.scannerhelper;

/**
* this class is a collection of helper methods to manipulate char arrays.
*
* @@since 2.1
* @@noinstantiate this class is not intended to be instantiated by clients.
*/
public final class charoperation {

/**
* constant for an empty char array
*/
public static final char[] no_char = new char[0];

/**
* constant for an empty char array with two dimensions.
*/
public static final char[][] no_char_char = new char[0][];

/**
* constant for an empty string array.
* @@since 3.1
*/
public static final string[] no_strings = new string[0];

/**
* answers a new array with appending the suffix character at the end of the array.
* <br>
* <br>
* for example:<br>
* <ol>
* <li><pre>
*    array = { 'a', 'b' }
*    suffix = 'c'
*    => result = { 'a', 'b' , 'c' }
* </pre>
* </li>
* <li><pre>
*    array = null
*    suffix = 'c'
*    => result = { 'c' }
* </pre></li>
* </ol>
*
* @@param array the array that is concatenated with the suffix character
* @@param suffix the suffix character
* @@return the new array
*/
public static final char[] append(char[] array, char suffix) {
if (array == null)
return new char[] { suffix };
int length = array.length;
system.arraycopy(array, 0, array = new char[length + 1], 0, length);
array[length] = suffix;
return array;
}

/**
* append the given sub-array to the target array starting at the given index in the target array.
* the start of the sub-array is inclusive, the end is exclusive.
* answers a new target array if it needs to grow, otherwise answers the same target array.
* <br>
* for example:<br>
* <ol>
* <li><pre>
*    target = { 'a', 'b', '0' }
*    index = 2
*    array = { 'c', 'd' }
*    start = 0
*    end = 1
*    => result = { 'a', 'b' , 'c' }
* </pre>
* </li>
* <li><pre>
*    target = { 'a', 'b' }
*    index = 2
*    array = { 'c', 'd' }
*    start = 0
*    end = 1
*    => result = { 'a', 'b' , 'c', '0', '0' , '0' } (new array)
* </pre></li>
* <li><pre>
*    target = { 'a', 'b', 'c' }
*    index = 1
*    array = { 'c', 'd', 'e', 'f' }
*    start = 1
*    end = 4
*    => result = { 'a', 'd' , 'e', 'f', '0', '0', '0', '0' } (new array)
* </pre></li>
* </ol>
*
* @@param target the given target
* @@param index the given index
* @@param array the given array
* @@param start the given start index
* @@param end the given end index
*
* @@return the new array
* @@throws nullpointerexception if the target array is null
*/
public static final char[] append(char[] target, int index, char[] array, int start, int end) {
int targetlength = target.length;
int sublength = end-start;
int newtargetlength = sublength+index;
if (newtargetlength > targetlength) {
system.arraycopy(target, 0, target = new char[newtargetlength*2], 0, index);
}
system.arraycopy(array, start, target, index, sublength);
return target;
}

/**
* answers the concatenation of the two arrays. it answers null if the two arrays are null.
* if the first array is null, then the second array is returned.
* if the second array is null, then the first array is returned.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    first = null
*    second = null
*    => result = null
* </pre>
* </li>
* <li><pre>
*    first = { { ' a' } }
*    second = null
*    => result = { { ' a' } }
* </pre>
* </li>
* <li><pre>
*    first = null
*    second = { { ' a' } }
*    => result = { { ' a' } }
* </pre>
* </li>
* <li><pre>
*    first = { { ' b' } }
*    second = { { ' a' } }
*    => result = { { ' b' }, { ' a' } }
* </pre>
* </li>
* </ol>
*
* @@param first the first array to concatenate
* @@param second the second array to concatenate
* @@return the concatenation of the two arrays, or null if the two arrays are null.
*/
public static final char[][] arrayconcat(char[][] first, char[][] second) {
if (first == null)
return second;
if (second == null)
return first;

int length1 = first.length;
int length2 = second.length;
char[][] result = new char[length1 + length2][];
system.arraycopy(first, 0, result, 0, length1);
system.arraycopy(second, 0, result, length1, length2);
return result;
}

/**
* answers true if the pattern matches the given name using camelcase rules, or
* false otherwise. char[] camelcase matching does not accept explicit wild-cards
* '*' and '?' and is inherently case sensitive.
* <p>
* camelcase denotes the convention of writing compound names without spaces,
* and capitalizing every term. this function recognizes both upper and lower
* camelcase, depending whether the leading character is capitalized or not.
* the leading part of an upper camelcase pattern is assumed to contain a
* sequence of capitals which are appearing in the matching name; e.g. 'npe' will
* match 'nullpointerexception', but not 'newperfdata'. a lower camelcase pattern
* uses a lowercase first character. in java, type names follow the upper
* camelcase convention, whereas method or field names follow the lower
* camelcase convention.
* <p>
* the pattern may contain lowercase characters, which will be matched in a case
* sensitive way. these characters must appear in sequence in the name.
* for instance, 'npexcep' will match 'nullpointerexception', but not
* 'nullpointerexception' or 'nupoex' will match 'nullpointerexception', but not
* 'nopointerexception'.
* <p>
* digit characters are treated in a special way. they can be used in the pattern
* but are not always considered as leading character. for instance, both
* 'utf16dss' and 'utfdss' patterns will match 'utf16documentscannersupport'.
* <p>
* using this method allows matching names to have more parts than the specified
* pattern (see {@@link #camelcasematch(char[], char[], boolean)}).<br>
* for instance, 'hm' , 'hama' and  'hmap' patterns will match 'hashmap',
* 'hatmapper' <b>and also</b> 'hashmapentry'.
* <p>
* <pre>
* examples:<ol>
* <li> pattern = "npe".tochararray()
* name = "nullpointerexception".tochararray()
* result => true</li>
* <li> pattern = "npe".tochararray()
* name = "nopermissionexception".tochararray()
* result => true</li>
* <li> pattern = "nupoex".tochararray()
* name = "nullpointerexception".tochararray()
* result => true</li>
* <li> pattern = "nupoex".tochararray()
* name = "nopermissionexception".tochararray()
* result => false</li>
* <li> pattern = "npe".tochararray()
* name = "nullpointerexception".tochararray()
* result => false</li>
* <li> pattern = "ipl3".tochararray()
* name = "iperspectivelistener3".tochararray()
* result => true</li>
* <li> pattern = "hm".tochararray()
* name = "hashmapentry".tochararray()
* result => true</li>
* </ol></pre>
*
* @@param pattern the given pattern
* @@param name the given name
* @@return true if the pattern matches the given name, false otherwise
* @@since 3.2
*/
public static final boolean camelcasematch(char[] pattern, char[] name) {
if (pattern == null)
return true; // null pattern is equivalent to '*'
if (name == null)
return false; // null name cannot match

return camelcasematch(pattern, 0, pattern.length, name, 0, name.length, false/*not the same count of parts*/);
}

/**
* answers true if the pattern matches the given name using camelcase rules, or
* false otherwise. char[] camelcase matching does not accept explicit wild-cards
* '*' and '?' and is inherently case sensitive.
* <p>
* camelcase denotes the convention of writing compound names without spaces,
* and capitalizing every term. this function recognizes both upper and lower
* camelcase, depending whether the leading character is capitalized or not.
* the leading part of an upper camelcase pattern is assumed to contain a
* sequence of capitals which are appearing in the matching name; e.g. 'npe' will
* match 'nullpointerexception', but not 'newperfdata'. a lower camelcase pattern
* uses a lowercase first character. in java, type names follow the upper
* camelcase convention, whereas method or field names follow the lower
* camelcase convention.
* <p>
* the pattern may contain lowercase characters, which will be matched in a case
* sensitive way. these characters must appear in sequence in the name.
* for instance, 'npexcep' will match 'nullpointerexception', but not
* 'nullpointerexception' or 'nupoex' will match 'nullpointerexception', but not
* 'nopointerexception'.
* <p>
* digit characters are treated in a special way. they can be used in the pattern
* but are not always considered as leading character. for instance, both
* 'utf16dss' and 'utfdss' patterns will match 'utf16documentscannersupport'.
* <p>
* camelcase can be restricted to match only the same count of parts. when this
* restriction is specified the given pattern and the given name must have <b>exactly</b>
* the same number of parts (i.e. the same number of uppercase characters).<br>
* for instance, 'hm' , 'hama' and  'hmap' patterns will match 'hashmap' and
* 'hatmapper' <b>but not</b> 'hashmapentry'.
* <p>
* <pre>
* examples:<ol>
* <li> pattern = "npe".tochararray()
* name = "nullpointerexception".tochararray()
* result => true</li>
* <li> pattern = "npe".tochararray()
* name = "nopermissionexception".tochararray()
* result => true</li>
* <li> pattern = "nupoex".tochararray()
* name = "nullpointerexception".tochararray()
* result => true</li>
* <li> pattern = "nupoex".tochararray()
* name = "nopermissionexception".tochararray()
* result => false</li>
* <li> pattern = "npe".tochararray()
* name = "nullpointerexception".tochararray()
* result => false</li>
* <li> pattern = "ipl3".tochararray()
* name = "iperspectivelistener3".tochararray()
* result => true</li>
* <li> pattern = "hm".tochararray()
* name = "hashmapentry".tochararray()
* result => (samepartcount == false)</li>
* </ol></pre>
*
* @@param pattern the given pattern
* @@param name the given name
* @@param samepartcount flag telling whether the pattern and the name should
* 	have the same count of parts or not.<br>
* 	&nbsp;&nbsp;for example:
* 	<ul>
* 		<li>'hm' type string pattern will match 'hashmap' and 'htmlmapper' types,
* 				but not 'hashmapentry'</li>
* 		<li>'hmap' type string pattern will still match previous 'hashmap' and
* 				'htmlmapper' types, but not 'highmagnitude'</li>
* 	</ul>
* @@return true if the pattern matches the given name, false otherwise
* @@since 3.4
*/
public static final boolean camelcasematch(char[] pattern, char[] name, boolean samepartcount) {
if (pattern == null)
return true; // null pattern is equivalent to '*'
if (name == null)
return false; // null name cannot match

return camelcasematch(pattern, 0, pattern.length, name, 0, name.length, samepartcount);
}

/**
* answers true if a sub-pattern matches the sub-part of the given name using
* camelcase rules, or false otherwise.  char[] camelcase matching does not
* accept explicit wild-cards '*' and '?' and is inherently case sensitive.
* can match only subset of name/pattern, considering end positions as non-inclusive.
* the sub-pattern is defined by the patternstart and patternend positions.
* <p>
* camelcase denotes the convention of writing compound names without spaces,
* and capitalizing every term. this function recognizes both upper and lower
* camelcase, depending whether the leading character is capitalized or not.
* the leading part of an upper camelcase pattern is assumed to contain a
* sequence of capitals which are appearing in the matching name; e.g. 'npe' will
* match 'nullpointerexception', but not 'newperfdata'. a lower camelcase pattern
* uses a lowercase first character. in java, type names follow the upper
* camelcase convention, whereas method or field names follow the lower
* camelcase convention.
* <p>
* the pattern may contain lowercase characters, which will be matched in a case
* sensitive way. these characters must appear in sequence in the name.
* for instance, 'npexcep' will match 'nullpointerexception', but not
* 'nullpointerexception' or 'nupoex' will match 'nullpointerexception', but not
* 'nopointerexception'.
* <p>
* digit characters are treated in a special way. they can be used in the pattern
* but are not always considered as leading character. for instance, both
* 'utf16dss' and 'utfdss' patterns will match 'utf16documentscannersupport'.
* <p>
* digit characters are treated in a special way. they can be used in the pattern
* but are not always considered as leading character. for instance, both
* 'utf16dss' and 'utfdss' patterns will match 'utf16documentscannersupport'.
* <p>
* using this method allows matching names to have more parts than the specified
* pattern (see {@@link #camelcasematch(char[], int, int, char[], int, int, boolean)}).<br>
* for instance, 'hm' , 'hama' and  'hmap' patterns will match 'hashmap',
* 'hatmapper' <b>and also</b> 'hashmapentry'.
* <p>
* examples:
* <ol>
* <li> pattern = "npe".tochararray()
* patternstart = 0
* patternend = 3
* name = "nullpointerexception".tochararray()
* namestart = 0
* nameend = 20
* result => true</li>
* <li> pattern = "npe".tochararray()
* patternstart = 0
* patternend = 3
* name = "nopermissionexception".tochararray()
* namestart = 0
* nameend = 21
* result => true</li>
* <li> pattern = "nupoex".tochararray()
* patternstart = 0
* patternend = 6
* name = "nullpointerexception".tochararray()
* namestart = 0
* nameend = 20
* result => true</li>
* <li> pattern = "nupoex".tochararray()
* patternstart = 0
* patternend = 6
* name = "nopermissionexception".tochararray()
* namestart = 0
* nameend = 21
* result => false</li>
* <li> pattern = "npe".tochararray()
* patternstart = 0
* patternend = 3
* name = "nullpointerexception".tochararray()
* namestart = 0
* nameend = 20
* result => false</li>
* <li> pattern = "ipl3".tochararray()
* patternstart = 0
* patternend = 4
* name = "iperspectivelistener3".tochararray()
* namestart = 0
* nameend = 21
* result => true</li>
* <li> pattern = "hm".tochararray()
* patternstart = 0
* patternend = 2
* name = "hashmapentry".tochararray()
* namestart = 0
* nameend = 12
* result => true</li>
* </ol>
*
* @@param pattern the given pattern
* @@param patternstart the start index of the pattern, inclusive
* @@param patternend the end index of the pattern, exclusive
* @@param name the given name
* @@param namestart the start index of the name, inclusive
* @@param nameend the end index of the name, exclusive
* @@return true if a sub-pattern matches the sub-part of the given name, false otherwise
* @@since 3.2
*/
public static final boolean camelcasematch(char[] pattern, int patternstart, int patternend, char[] name, int namestart, int nameend) {
return camelcasematch(pattern, patternstart, patternend, name, namestart, nameend, false/*not the same count of parts*/);
}

/**
* answers true if a sub-pattern matches the sub-part of the given name using
* camelcase rules, or false otherwise.  char[] camelcase matching does not
* accept explicit wild-cards '*' and '?' and is inherently case sensitive.
* can match only subset of name/pattern, considering end positions as
* non-inclusive. the sub-pattern is defined by the patternstart and patternend
* positions.
* <p>
* camelcase denotes the convention of writing compound names without spaces,
* and capitalizing every term. this function recognizes both upper and lower
* camelcase, depending whether the leading character is capitalized or not.
* the leading part of an upper camelcase pattern is assumed to contain
* a sequence of capitals which are appearing in the matching name; e.g. 'npe' will
* match 'nullpointerexception', but not 'newperfdata'. a lower camelcase pattern
* uses a lowercase first character. in java, type names follow the upper
* camelcase convention, whereas method or field names follow the lower
* camelcase convention.
* <p>
* the pattern may contain lowercase characters, which will be matched in a case
* sensitive way. these characters must appear in sequence in the name.
* for instance, 'npexcep' will match 'nullpointerexception', but not
* 'nullpointerexception' or 'nupoex' will match 'nullpointerexception', but not
* 'nopointerexception'.
* <p>
* digit characters are treated in a special way. they can be used in the pattern
* but are not always considered as leading character. for instance, both
* 'utf16dss' and 'utfdss' patterns will match 'utf16documentscannersupport'.
* <p>
* camelcase can be restricted to match only the same count of parts. when this
* restriction is specified the given pattern and the given name must have <b>exactly</b>
* the same number of parts (i.e. the same number of uppercase characters).<br>
* for instance, 'hm' , 'hama' and  'hmap' patterns will match 'hashmap' and
* 'hatmapper' <b>but not</b> 'hashmapentry'.
* <p>
* <pre>
* examples:
* <ol>
* <li> pattern = "npe".tochararray()
* patternstart = 0
* patternend = 3
* name = "nullpointerexception".tochararray()
* namestart = 0
* nameend = 20
* result => true</li>
* <li> pattern = "npe".tochararray()
* patternstart = 0
* patternend = 3
* name = "nopermissionexception".tochararray()
* namestart = 0
* nameend = 21
* result => true</li>
* <li> pattern = "nupoex".tochararray()
* patternstart = 0
* patternend = 6
* name = "nullpointerexception".tochararray()
* namestart = 0
* nameend = 20
* result => true</li>
* <li> pattern = "nupoex".tochararray()
* patternstart = 0
* patternend = 6
* name = "nopermissionexception".tochararray()
* namestart = 0
* nameend = 21
* result => false</li>
* <li> pattern = "npe".tochararray()
* patternstart = 0
* patternend = 3
* name = "nullpointerexception".tochararray()
* namestart = 0
* nameend = 20
* result => false</li>
* <li> pattern = "ipl3".tochararray()
* patternstart = 0
* patternend = 4
* name = "iperspectivelistener3".tochararray()
* namestart = 0
* nameend = 21
* result => true</li>
* <li> pattern = "hm".tochararray()
* patternstart = 0
* patternend = 2
* name = "hashmapentry".tochararray()
* namestart = 0
* nameend = 12
* result => (samepartcount == false)</li>
* </ol>
* </pre>
*
* @@param pattern the given pattern
* @@param patternstart the start index of the pattern, inclusive
* @@param patternend the end index of the pattern, exclusive
* @@param name the given name
* @@param namestart the start index of the name, inclusive
* @@param nameend the end index of the name, exclusive
* @@param samepartcount flag telling whether the pattern and the name should
* 	have the same count of parts or not.<br>
* 	&nbsp;&nbsp;for example:
* 	<ul>
* 		<li>'hm' type string pattern will match 'hashmap' and 'htmlmapper' types,
* 				but not 'hashmapentry'</li>
* 		<li>'hmap' type string pattern will still match previous 'hashmap' and
* 				'htmlmapper' types, but not 'highmagnitude'</li>
* 	</ul>
* @@return true if a sub-pattern matches the sub-part of the given name, false otherwise
* @@since 3.4
*/
public static final boolean camelcasematch(char[] pattern, int patternstart, int patternend, char[] name, int namestart, int nameend, boolean samepartcount) {

/* !!!!!!!!!! warning !!!!!!!!!!
* the algorithm implemented in this method has been heavily used in
* stringoperation#getcamelcasematchingregions(string, int, int, string, int, int, boolean)
* method.
*
* so, if any change needs to be applied in the current algorithm,
* do not forget to also apply the same change in the stringoperation method!
*/

if (name == null)
return false; // null name cannot match
if (pattern == null)
return true; // null pattern is equivalent to '*'
if (patternend < 0) 	patternend = pattern.length;
if (nameend < 0) nameend = name.length;

if (patternend <= patternstart) return nameend <= namestart;
if (nameend <= namestart) return false;
// check first pattern char
if (name[namestart] != pattern[patternstart]) {
// first char must strictly match (upper/lower)
return false;
}

char patternchar, namechar;
int ipattern = patternstart;
int iname = namestart;

// main loop is on pattern characters
while (true) {

ipattern++;
iname++;

if (ipattern == patternend) { // we have exhausted pattern...
// it's a match if the name can have additional parts (i.e. uppercase characters) or is also exhausted
if (!samepartcount || iname == nameend) return true;

// otherwise it's a match only if the name has no more uppercase characters
while (true) {
if (iname == nameend) {
// we have exhausted the name, so it's a match
return true;
}
namechar = name[iname];
// test if the name character is uppercase
if (namechar < scannerhelper.max_obvious) {
if ((scannerhelper.obvious_ident_char_natures[namechar] & scannerhelper.c_upper_letter) != 0) {
return false;
}
}
else if (!character.isjavaidentifierpart(namechar) || character.isuppercase(namechar)) {
return false;
}
iname++;
}
}

if (iname == nameend){
// we have exhausted the name (and not the pattern), so it's not a match
return false;
}

// for as long as we're exactly matching, bring it on (even if it's a lower case character)
if ((patternchar = pattern[ipattern]) == name[iname]) {
continue;
}

// if characters are not equals, then it's not a match if patternchar is lowercase
if (patternchar < scannerhelper.max_obvious) {
if ((scannerhelper.obvious_ident_char_natures[patternchar] & (scannerhelper.c_upper_letter | scannerhelper.c_digit)) == 0) {
return false;
}
}
else if (character.isjavaidentifierpart(patternchar) && !character.isuppercase(patternchar) && !character.isdigit(patternchar)) {
return false;
}

// patternchar is uppercase, so let's find the next uppercase in name
while (true) {
if (iname == nameend){
//	we have exhausted name (and not pattern), so it's not a match
return false;
}

namechar = name[iname];
if (namechar < scannerhelper.max_obvious) {
int charnature = scannerhelper.obvious_ident_char_natures[namechar];
if ((charnature & (scannerhelper.c_lower_letter | scannerhelper.c_special)) != 0) {
// namechar is lowercase
iname++;
} else if ((charnature & scannerhelper.c_digit) != 0) {
// namechar is digit => break if the digit is current pattern character otherwise consume it
if (patternchar == namechar) break;
iname++;
// namechar is uppercase...
} else  if (patternchar != namechar) {
//.. and it does not match patternchar, so it's not a match
return false;
} else {
//.. and it matched patternchar. back to the big loop
break;
}
}
// same tests for non-obvious characters
else if (character.isjavaidentifierpart(namechar) && !character.isuppercase(namechar)) {
iname++;
} else if (character.isdigit(namechar)) {
if (patternchar == namechar) break;
iname++;
} else  if (patternchar != namechar) {
return false;
} else {
break;
}
}
// at this point, either name has been exhausted, or it is at an uppercase letter.
// since pattern is also at an uppercase letter
}
}

/**
* returns the char arrays as an array of strings
*
* @@param chararrays the char array to convert
* @@return the char arrays as an array of strings or null if the given char arrays is null.
* @@since 3.0
*/
public static string[] chararraytostringarray(char[][] chararrays) {
if (chararrays == null)
return null;
int length = chararrays.length;
if (length == 0)
return no_strings;
string[] strings= new string[length];
for (int i= 0; i < length; i++)
strings[i]= new string(chararrays[i]);
return strings;
}

/**
* returns the char array as a string

* @@param chararray the char array to convert
* @@return the char array as a string or null if the given char array is null.
* @@since 3.0
*/
public static string chartostring(char[] chararray) {
if (chararray == null) return null;
return new string(chararray);
}

/**
* answers a new array adding the second array at the end of first array.
* it answers null if the first and second are null.
* if the first array is null, then a new array char[][] is created with second.
* if the second array is null, then the first array is returned.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    first = null
*    second = { 'a' }
*    => result = { { ' a' } }
* </pre>
* <li><pre>
*    first = { { ' a' } }
*    second = null
*    => result = { { ' a' } }
* </pre>
* </li>
* <li><pre>
*    first = { { ' a' } }
*    second = { ' b' }
*    => result = { { ' a' } , { ' b' } }
* </pre>
* </li>
* </ol>
*
* @@param first the first array to concatenate
* @@param second the array to add at the end of the first array
* @@return a new array adding the second array at the end of first array, or null if the two arrays are null.
*/
public static final char[][] arrayconcat(char[][] first, char[] second) {
if (second == null)
return first;
if (first == null)
return new char[][] { second };

int length = first.length;
char[][] result = new char[length + 1][];
system.arraycopy(first, 0, result, 0, length);
result[length] = second;
return result;
}
/**
* compares the two char arrays lexicographically.
*
* returns a negative integer if array1 lexicographically precedes the array2,
* a positive integer if this array1 lexicographically follows the array2, or
* zero if both arrays are equal.
*
* @@param array1 the first given array
* @@param array2 the second given array
* @@return the returned value of the comparison between array1 and array2
* @@throws nullpointerexception if one of the arrays is null
* @@since 3.3
*/
public static final int compareto(char[] array1, char[] array2) {
int length1 = array1.length;
int length2 = array2.length;
int min = math.min(length1, length2);
for (int i = 0; i < min; i++) {
if (array1[i] != array2[i]) {
return array1[i] - array2[i];
}
}
return length1 - length2;
}
/**
* compares the contents of the two arrays array and prefix. returns
* <ul>
* <li>zero if the array starts with the prefix contents</li>
* <li>the difference between the first two characters that are not equal </li>
* <li>one if array length is lower than the prefix length and that the prefix starts with the
* array contents.</li>
* </ul>
* <p>
* for example:
* <ol>
* <li><pre>
*    array = null
*    prefix = null
*    => result = nullpointerexception
* </pre>
* </li>
* <li><pre>
*    array = { 'a', 'b', 'c', 'd', 'e' }
*    prefix = { 'a', 'b', 'c'}
*    => result = 0
* </pre>
* </li>
* <li><pre>
*    array = { 'a', 'b', 'c', 'd', 'e' }
*    prefix = { 'a', 'b', 'c'}
*    => result = 32
* </pre>
* </li>
* <li><pre>
*    array = { 'd', 'b', 'c', 'd', 'e' }
*    prefix = { 'a', 'b', 'c'}
*    => result = 3
* </pre>
* </li>
* <li><pre>
*    array = { 'a', 'b', 'c', 'd', 'e' }
*    prefix = { 'd', 'b', 'c'}
*    => result = -3
* </pre>
* </li>
* <li><pre>
*    array = { 'a', 'a', 'c', 'd', 'e' }
*    prefix = { 'a', 'e', 'c'}
*    => result = -4
* </pre>
* </li>
* </ol>
* </p>
*
* @@param array the given array
* @@param prefix the given prefix
* @@return the result of the comparison (>=0 if array>prefix)
* @@throws nullpointerexception if either array or prefix is null
*/
public static final int comparewith(char[] array, char[] prefix) {
int arraylength = array.length;
int prefixlength = prefix.length;
int min = math.min(arraylength, prefixlength);
int i = 0;
while (min-- != 0) {
char c1 = array[i];
char c2 = prefix[i++];
if (c1 != c2)
return c1 - c2;
}
if (prefixlength == i)
return 0;
return -1;	// array is shorter than prefix (e.g. array:'ab' < prefix:'abc').
}

/**
* answers the concatenation of the two arrays. it answers null if the two arrays are null.
* if the first array is null, then the second array is returned.
* if the second array is null, then the first array is returned.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    first = null
*    second = { 'a' }
*    => result = { ' a' }
* </pre>
* </li>
* <li><pre>
*    first = { ' a' }
*    second = null
*    => result = { ' a' }
* </pre>
* </li>
* <li><pre>
*    first = { ' a' }
*    second = { ' b' }
*    => result = { ' a' , ' b' }
* </pre>
* </li>
* </ol>
*
* @@param first the first array to concatenate
* @@param second the second array to concatenate
* @@return the concatenation of the two arrays, or null if the two arrays are null.
*/
public static final char[] concat(char[] first, char[] second) {
if (first == null)
return second;
if (second == null)
return first;

int length1 = first.length;
int length2 = second.length;
char[] result = new char[length1 + length2];
system.arraycopy(first, 0, result, 0, length1);
system.arraycopy(second, 0, result, length1, length2);
return result;
}

/**
* answers the concatenation of the three arrays. it answers null if the three arrays are null.
* if first is null, it answers the concatenation of second and third.
* if second is null, it answers the concatenation of first and third.
* if third is null, it answers the concatenation of first and second.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    first = null
*    second = { 'a' }
*    third = { 'b' }
*    => result = { ' a', 'b' }
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = null
*    third = { 'b' }
*    => result = { ' a', 'b' }
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = { 'b' }
*    third = null
*    => result = { ' a', 'b' }
* </pre>
* </li>
* <li><pre>
*    first = null
*    second = null
*    third = null
*    => result = null
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = { 'b' }
*    third = { 'c' }
*    => result = { 'a', 'b', 'c' }
* </pre>
* </li>
* </ol>
*
* @@param first the first array to concatenate
* @@param second the second array to concatenate
* @@param third the third array to concatenate
*
* @@return the concatenation of the three arrays, or null if the three arrays are null.
*/
public static final char[] concat(
char[] first,
char[] second,
char[] third) {
if (first == null)
return concat(second, third);
if (second == null)
return concat(first, third);
if (third == null)
return concat(first, second);

int length1 = first.length;
int length2 = second.length;
int length3 = third.length;
char[] result = new char[length1 + length2 + length3];
system.arraycopy(first, 0, result, 0, length1);
system.arraycopy(second, 0, result, length1, length2);
system.arraycopy(third, 0, result, length1 + length2, length3);
return result;
}

/**
* answers the concatenation of the two arrays inserting the separator character between the two arrays.
* it answers null if the two arrays are null.
* if the first array is null, then the second array is returned.
* if the second array is null, then the first array is returned.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    first = null
*    second = { 'a' }
*    separator = '/'
*    => result = { ' a' }
* </pre>
* </li>
* <li><pre>
*    first = { ' a' }
*    second = null
*    separator = '/'
*    => result = { ' a' }
* </pre>
* </li>
* <li><pre>
*    first = { ' a' }
*    second = { ' b' }
*    separator = '/'
*    => result = { ' a' , '/', 'b' }
* </pre>
* </li>
* </ol>
*
* @@param first the first array to concatenate
* @@param second the second array to concatenate
* @@param separator the character to insert
* @@return the concatenation of the two arrays inserting the separator character
* between the two arrays , or null if the two arrays are null.
*/
public static final char[] concat(
char[] first,
char[] second,
char separator) {
if (first == null)
return second;
if (second == null)
return first;

int length1 = first.length;
if (length1 == 0)
return second;
int length2 = second.length;
if (length2 == 0)
return first;

char[] result = new char[length1 + length2 + 1];
system.arraycopy(first, 0, result, 0, length1);
result[length1] = separator;
system.arraycopy(second, 0, result, length1 + 1, length2);
return result;
}

/**
* answers the concatenation of the three arrays inserting the sep1 character between the
* first two arrays and sep2 between the last two.
* it answers null if the three arrays are null.
* if the first array is null, then it answers the concatenation of second and third inserting
* the sep2 character between them.
* if the second array is null, then it answers the concatenation of first and third inserting
* the sep1 character between them.
* if the third array is null, then it answers the concatenation of first and second inserting
* the sep1 character between them.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    first = null
*    sep1 = '/'
*    second = { 'a' }
*    sep2 = ':'
*    third = { 'b' }
*    => result = { ' a' , ':', 'b' }
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    sep1 = '/'
*    second = null
*    sep2 = ':'
*    third = { 'b' }
*    => result = { ' a' , '/', 'b' }
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    sep1 = '/'
*    second = { 'b' }
*    sep2 = ':'
*    third = null
*    => result = { ' a' , '/', 'b' }
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    sep1 = '/'
*    second = { 'b' }
*    sep2 = ':'
*    third = { 'c' }
*    => result = { ' a' , '/', 'b' , ':', 'c' }
* </pre>
* </li>
* </ol>
*
* @@param first the first array to concatenate
* @@param sep1 the character to insert
* @@param second the second array to concatenate
* @@param sep2 the character to insert
* @@param third the second array to concatenate
* @@return the concatenation of the three arrays inserting the sep1 character between the
* two arrays and sep2 between the last two.
*/
public static final char[] concat(
char[] first,
char sep1,
char[] second,
char sep2,
char[] third) {
if (first == null)
return concat(second, third, sep2);
if (second == null)
return concat(first, third, sep1);
if (third == null)
return concat(first, second, sep1);

int length1 = first.length;
int length2 = second.length;
int length3 = third.length;
char[] result = new char[length1 + length2 + length3 + 2];
system.arraycopy(first, 0, result, 0, length1);
result[length1] = sep1;
system.arraycopy(second, 0, result, length1 + 1, length2);
result[length1 + length2 + 1] = sep2;
system.arraycopy(third, 0, result, length1 + length2 + 2, length3);
return result;
}

/**
* answers a new array with prepending the prefix character and appending the suffix
* character at the end of the array. if array is null, it answers a new array containing the
* prefix and the suffix characters.
* <br>
* <br>
* for example:<br>
* <ol>
* <li><pre>
*    prefix = 'a'
*    array = { 'b' }
*    suffix = 'c'
*    => result = { 'a', 'b' , 'c' }
* </pre>
* </li>
* <li><pre>
*    prefix = 'a'
*    array = null
*    suffix = 'c'
*    => result = { 'a', 'c' }
* </pre></li>
* </ol>
*
* @@param prefix the prefix character
* @@param array the array that is concatenated with the prefix and suffix characters
* @@param suffix the suffix character
* @@return the new array
*/
public static final char[] concat(char prefix, char[] array, char suffix) {
if (array == null)
return new char[] { prefix, suffix };

int length = array.length;
char[] result = new char[length + 2];
result[0] = prefix;
system.arraycopy(array, 0, result, 1, length);
result[length + 1] = suffix;
return result;
}

/**
* answers the concatenation of the given array parts using the given separator between each
* part and prepending the given name at the beginning.
* <br>
* <br>
* for example:<br>
* <ol>
* <li><pre>
*    name = { 'c' }
*    array = { { 'a' }, { 'b' } }
*    separator = '.'
*    => result = { 'a', '.', 'b' , '.', 'c' }
* </pre>
* </li>
* <li><pre>
*    name = null
*    array = { { 'a' }, { 'b' } }
*    separator = '.'
*    => result = { 'a', '.', 'b' }
* </pre></li>
* <li><pre>
*    name = { ' c' }
*    array = null
*    separator = '.'
*    => result = { 'c' }
* </pre></li>
* </ol>
*
* @@param name the given name
* @@param array the given array
* @@param separator the given separator
* @@return the concatenation of the given array parts using the given separator between each
* part and prepending the given name at the beginning
*/
public static final char[] concatwith(
char[] name,
char[][] array,
char separator) {
int namelength = name == null ? 0 : name.length;
if (namelength == 0)
return concatwith(array, separator);

int length = array == null ? 0 : array.length;
if (length == 0)
return name;

int size = namelength;
int index = length;
while (--index >= 0)
if (array[index].length > 0)
size += array[index].length + 1;
char[] result = new char[size];
index = size;
for (int i = length - 1; i >= 0; i--) {
int sublength = array[i].length;
if (sublength > 0) {
index -= sublength;
system.arraycopy(array[i], 0, result, index, sublength);
result[--index] = separator;
}
}
system.arraycopy(name, 0, result, 0, namelength);
return result;
}

/**
* answers the concatenation of the given array parts using the given separator between each
* part and appending the given name at the end.
* <br>
* <br>
* for example:<br>
* <ol>
* <li><pre>
*    name = { 'c' }
*    array = { { 'a' }, { 'b' } }
*    separator = '.'
*    => result = { 'a', '.', 'b' , '.', 'c' }
* </pre>
* </li>
* <li><pre>
*    name = null
*    array = { { 'a' }, { 'b' } }
*    separator = '.'
*    => result = { 'a', '.', 'b' }
* </pre></li>
* <li><pre>
*    name = { ' c' }
*    array = null
*    separator = '.'
*    => result = { 'c' }
* </pre></li>
* </ol>
*
* @@param array the given array
* @@param name the given name
* @@param separator the given separator
* @@return the concatenation of the given array parts using the given separator between each
* part and appending the given name at the end
*/
public static final char[] concatwith(
char[][] array,
char[] name,
char separator) {
int namelength = name == null ? 0 : name.length;
if (namelength == 0)
return concatwith(array, separator);

int length = array == null ? 0 : array.length;
if (length == 0)
return name;

int size = namelength;
int index = length;
while (--index >= 0)
if (array[index].length > 0)
size += array[index].length + 1;
char[] result = new char[size];
index = 0;
for (int i = 0; i < length; i++) {
int sublength = array[i].length;
if (sublength > 0) {
system.arraycopy(array[i], 0, result, index, sublength);
index += sublength;
result[index++] = separator;
}
}
system.arraycopy(name, 0, result, index, namelength);
return result;
}

/**
* answers the concatenation of the given array parts using the given separator between each part.
* <br>
* <br>
* for example:<br>
* <ol>
* <li><pre>
*    array = { { 'a' }, { 'b' } }
*    separator = '.'
*    => result = { 'a', '.', 'b' }
* </pre>
* </li>
* <li><pre>
*    array = null
*    separator = '.'
*    => result = { }
* </pre></li>
* </ol>
*
* @@param array the given array
* @@param separator the given separator
* @@return the concatenation of the given array parts using the given separator between each part
*/
public static final char[] concatwith(char[][] array, char separator) {
int length = array == null ? 0 : array.length;
if (length == 0)
return charoperation.no_char;

int size = length - 1;
int index = length;
while (--index >= 0) {
if (array[index].length == 0)
size--;
else
size += array[index].length;
}
if (size <= 0)
return charoperation.no_char;
char[] result = new char[size];
index = length;
while (--index >= 0) {
length = array[index].length;
if (length > 0) {
system.arraycopy(
array[index],
0,
result,
(size -= length),
length);
if (--size >= 0)
result[size] = separator;
}
}
return result;
}

/**
* answers true if the array contains an occurrence of character, false otherwise.
*
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    character = 'c'
*    array = { { ' a' }, { ' b' } }
*    result => false
* </pre>
* </li>
* <li><pre>
*    character = 'a'
*    array = { { ' a' }, { ' b' } }
*    result => true
* </pre>
* </li>
* </ol>
*
* @@param character the character to search
* @@param array the array in which the search is done
* @@return true if the array contains an occurrence of character, false otherwise.
* @@throws nullpointerexception if array is null.
*/
public static final boolean contains(char character, char[][] array) {
for (int i = array.length; --i >= 0;) {
char[] subarray = array[i];
for (int j = subarray.length; --j >= 0;)
if (subarray[j] == character)
return true;
}
return false;
}

/**
* answers true if the array contains an occurrence of character, false otherwise.
*
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    character = 'c'
*    array = { ' b'  }
*    result => false
* </pre>
* </li>
* <li><pre>
*    character = 'a'
*    array = { ' a' , ' b' }
*    result => true
* </pre>
* </li>
* </ol>
*
* @@param character the character to search
* @@param array the array in which the search is done
* @@return true if the array contains an occurrence of character, false otherwise.
* @@throws nullpointerexception if array is null.
*/
public static final boolean contains(char character, char[] array) {
for (int i = array.length; --i >= 0;)
if (array[i] == character)
return true;
return false;
}

/**
* answers true if the array contains an occurrence of one of the characters, false otherwise.
*
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    characters = { 'c', 'd' }
*    array = { 'a', ' b'  }
*    result => false
* </pre>
* </li>
* <li><pre>
*    characters = { 'c', 'd' }
*    array = { 'a', ' b', 'c'  }
*    result => true
* </pre>
* </li>
* </ol>
*
* @@param characters the characters to search
* @@param array the array in which the search is done
* @@return true if the array contains an occurrence of one of the characters, false otherwise.
* @@throws nullpointerexception if array is null.
* @@since 3.1
*/
public static final boolean contains(char[] characters, char[] array) {
for (int i = array.length; --i >= 0;)
for (int j = characters.length; --j >= 0;)
if (array[i] == characters[j])
return true;
return false;
}

/**
* answers a deep copy of the tocopy array.
*
* @@param tocopy the array to copy
* @@return a deep copy of the tocopy array.
*/

public static final char[][] deepcopy(char[][] tocopy) {
int tocopylength = tocopy.length;
char[][] result = new char[tocopylength][];
for (int i = 0; i < tocopylength; i++) {
char[] toelement = tocopy[i];
int toelementlength = toelement.length;
char[] resultelement = new char[toelementlength];
system.arraycopy(toelement, 0, resultelement, 0, toelementlength);
result[i] = resultelement;
}
return result;
}

/**
* return true if array ends with the sequence of characters contained in tobefound,
* otherwise false.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    array = { 'a', 'b', 'c', 'd' }
*    tobefound = { 'b', 'c' }
*    result => false
* </pre>
* </li>
* <li><pre>
*    array = { 'a', 'b', 'c' }
*    tobefound = { 'b', 'c' }
*    result => true
* </pre>
* </li>
* </ol>
*
* @@param array the array to check
* @@param tobefound the array to find
* @@return true if array ends with the sequence of characters contained in tobefound,
* otherwise false.
* @@throws nullpointerexception if array is null or tobefound is null
*/
public static final boolean endswith(char[] array, char[] tobefound) {
int i = tobefound.length;
int j = array.length - i;

if (j < 0)
return false;
while (--i >= 0)
if (tobefound[i] != array[i + j])
return false;
return true;
}

/**
* answers true if the two arrays are identical character by character, otherwise false.
* the equality is case sensitive.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    first = null
*    second = null
*    result => true
* </pre>
* </li>
* <li><pre>
*    first = { { } }
*    second = null
*    result => false
* </pre>
* </li>
* <li><pre>
*    first = { { 'a' } }
*    second = { { 'a' } }
*    result => true
* </pre>
* </li>
* <li><pre>
*    first = { { 'a' } }
*    second = { { 'a' } }
*    result => false
* </pre>
* </li>
* </ol>
* @@param first the first array
* @@param second the second array
* @@return true if the two arrays are identical character by character, otherwise false
*/
public static final boolean equals(char[][] first, char[][] second) {
if (first == second)
return true;
if (first == null || second == null)
return false;
if (first.length != second.length)
return false;

for (int i = first.length; --i >= 0;)
if (!equals(first[i], second[i]))
return false;
return true;
}

/**
* if iscasesensite is true, answers true if the two arrays are identical character
* by character, otherwise false.
* if it is false, answers true if the two arrays are identical character by
* character without checking the case, otherwise false.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    first = null
*    second = null
*    iscasesensitive = true
*    result => true
* </pre>
* </li>
* <li><pre>
*    first = { { } }
*    second = null
*    iscasesensitive = true
*    result => false
* </pre>
* </li>
* <li><pre>
*    first = { { 'a' } }
*    second = { { 'a' } }
*    iscasesensitive = true
*    result => false
* </pre>
* </li>
* <li><pre>
*    first = { { 'a' } }
*    second = { { 'a' } }
*    iscasesensitive = false
*    result => true
* </pre>
* </li>
* </ol>
*
* @@param first the first array
* @@param second the second array
* @@param iscasesensitive check whether or not the equality should be case sensitive
* @@return true if the two arrays are identical character by character according to the value
* of iscasesensitive, otherwise false
*/
public static final boolean equals(
char[][] first,
char[][] second,
boolean iscasesensitive) {

if (iscasesensitive) {
return equals(first, second);
}
if (first == second)
return true;
if (first == null || second == null)
return false;
if (first.length != second.length)
return false;

for (int i = first.length; --i >= 0;)
if (!equals(first[i], second[i], false))
return false;
return true;
}

/**
* answers true if the two arrays are identical character by character, otherwise false.
* the equality is case sensitive.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    first = null
*    second = null
*    result => true
* </pre>
* </li>
* <li><pre>
*    first = { }
*    second = null
*    result => false
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = { 'a' }
*    result => true
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = { 'a' }
*    result => false
* </pre>
* </li>
* </ol>
* @@param first the first array
* @@param second the second array
* @@return true if the two arrays are identical character by character, otherwise false
*/
public static final boolean equals(char[] first, char[] second) {
if (first == second)
return true;
if (first == null || second == null)
return false;
if (first.length != second.length)
return false;

for (int i = first.length; --i >= 0;)
if (first[i] != second[i])
return false;
return true;
}

/**
* answers true if the first array is identical character by character to a portion of the second array
* delimited from position secondstart (inclusive) to secondend(exclusive), otherwise false.
* the equality is case sensitive.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    first = null
*    second = null
*    secondstart = 0
*    secondend = 0
*    result => true
* </pre>
* </li>
* <li><pre>
*    first = { }
*    second = null
*    secondstart = 0
*    secondend = 0
*    result => false
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = { 'a' }
*    secondstart = 0
*    secondend = 1
*    result => true
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = { 'a' }
*    secondstart = 0
*    secondend = 1
*    result => false
* </pre>
* </li>
* </ol>
* @@param first the first array
* @@param second the second array
* @@param secondstart inclusive start position in the second array to compare
* @@param secondend exclusive end position in the second array to compare
* @@return true if the first array is identical character by character to fragment of second array ranging from secondstart to secondend-1, otherwise false
* @@since 3.0
*/
public static final boolean equals(char[] first, char[] second, int secondstart, int secondend) {
return equals(first, second, secondstart, secondend, true);
}
/**
* <p>answers true if the first array is identical character by character to a portion of the second array
* delimited from position secondstart (inclusive) to secondend(exclusive), otherwise false. the equality could be either
* case sensitive or case insensitive according to the value of the <code>iscasesensitive</code> parameter.
* </p>
* <p>for example:</p>
* <ol>
* <li><pre>
*    first = null
*    second = null
*    secondstart = 0
*    secondend = 0
*    iscasesensitive = false
*    result => true
* </pre>
* </li>
* <li><pre>
*    first = { }
*    second = null
*    secondstart = 0
*    secondend = 0
*    iscasesensitive = false
*    result => false
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = { 'a' }
*    secondstart = 0
*    secondend = 1
*    iscasesensitive = true
*    result => true
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = { 'a' }
*    secondstart = 0
*    secondend = 1
*    iscasesensitive = true
*    result => false
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = { 'a' }
*    secondstart = 0
*    secondend = 1
*    iscasesensitive = false
*    result => true
* </pre>
* </li>
* </ol>
* @@param first the first array
* @@param second the second array
* @@param secondstart inclusive start position in the second array to compare
* @@param secondend exclusive end position in the second array to compare
* @@param iscasesensitive check whether or not the equality should be case sensitive
* @@return true if the first array is identical character by character to fragment of second array ranging from secondstart to secondend-1, otherwise false
* @@since 3.2
*/
public static final boolean equals(char[] first, char[] second, int secondstart, int secondend, boolean iscasesensitive) {
if (first == second)
return true;
if (first == null || second == null)
return false;
if (first.length != secondend - secondstart)
return false;
if (iscasesensitive) {
for (int i = first.length; --i >= 0;)
if (first[i] != second[i+secondstart])
return false;
} else {
for (int i = first.length; --i >= 0;)
if (scannerhelper.tolowercase(first[i]) != scannerhelper.tolowercase(second[i+secondstart]))
return false;
}
return true;
}

/**
* if iscasesensite is true, answers true if the two arrays are identical character
* by character, otherwise false.
* if it is false, answers true if the two arrays are identical character by
* character without checking the case, otherwise false.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    first = null
*    second = null
*    iscasesensitive = true
*    result => true
* </pre>
* </li>
* <li><pre>
*    first = { }
*    second = null
*    iscasesensitive = true
*    result => false
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = { 'a' }
*    iscasesensitive = true
*    result => false
* </pre>
* </li>
* <li><pre>
*    first = { 'a' }
*    second = { 'a' }
*    iscasesensitive = false
*    result => true
* </pre>
* </li>
* </ol>
*
* @@param first the first array
* @@param second the second array
* @@param iscasesensitive check whether or not the equality should be case sensitive
* @@return true if the two arrays are identical character by character according to the value
* of iscasesensitive, otherwise false
*/
public static final boolean equals(
char[] first,
char[] second,
boolean iscasesensitive) {

if (iscasesensitive) {
return equals(first, second);
}
if (first == second)
return true;
if (first == null || second == null)
return false;
if (first.length != second.length)
return false;

for (int i = first.length; --i >= 0;)
if (scannerhelper.tolowercase(first[i])
!= scannerhelper.tolowercase(second[i]))
return false;
return true;
}

/**
* if iscasesensite is true, the equality is case sensitive, otherwise it is case insensitive.
*
* answers true if the name contains the fragment at the starting index startindex, otherwise false.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    fragment = { 'b', 'c' , 'd' }
*    name = { 'a', 'b', 'c' , 'd' }
*    startindex = 1
*    iscasesensitive = true
*    result => true
* </pre>
* </li>
* <li><pre>
*    fragment = { 'b', 'c' , 'd' }
*    name = { 'a', 'b', 'c' , 'd' }
*    startindex = 1
*    iscasesensitive = true
*    result => false
* </pre>
* </li>
* <li><pre>
*    fragment = { 'b', 'c' , 'd' }
*    name = { 'a', 'b', 'c' , 'd' }
*    startindex = 0
*    iscasesensitive = false
*    result => false
* </pre>
* </li>
* <li><pre>
*    fragment = { 'b', 'c' , 'd' }
*    name = { 'a', 'b'}
*    startindex = 0
*    iscasesensitive = true
*    result => false
* </pre>
* </li>
* </ol>
*
* @@param fragment the fragment to check
* @@param name the array to check
* @@param startindex the starting index
* @@param iscasesensitive check whether or not the equality should be case sensitive
* @@return true if the name contains the fragment at the starting index startindex according to the
* value of iscasesensitive, otherwise false.
* @@throws nullpointerexception if fragment or name is null.
*/
public static final boolean fragmentequals(
char[] fragment,
char[] name,
int startindex,
boolean iscasesensitive) {

int max = fragment.length;
if (name.length < max + startindex)
return false;
if (iscasesensitive) {
for (int i = max;
--i >= 0;
) // assumes the prefix is not larger than the name
if (fragment[i] != name[i + startindex])
return false;
return true;
}
for (int i = max;
--i >= 0;
) // assumes the prefix is not larger than the name
if (scannerhelper.tolowercase(fragment[i])
!= scannerhelper.tolowercase(name[i + startindex]))
return false;
return true;
}

/**
* answers a hashcode for the array
*
* @@param array the array for which a hashcode is required
* @@return the hashcode
* @@throws nullpointerexception if array is null
*/
public static final int hashcode(char[] array) {
int length = array.length;
int hash = length == 0 ? 31 : array[0];
if (length < 8) {
for (int i = length; --i > 0;)
hash = (hash * 31) + array[i];
} else {
// 8 characters is enough to compute a decent hash code, don't waste time examining every character
for (int i = length - 1, last = i > 16 ? i - 16 : 0; i > last; i -= 2)
hash = (hash * 31) + array[i];
}
return hash & 0x7fffffff;
}

/**
* answers true if c is a whitespace according to the jls (&#92;u000a, &#92;u000c, &#92;u000d, &#92;u0009), otherwise false.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    c = ' '
*    result => true
* </pre>
* </li>
* <li><pre>
*    c = '&#92;u3000'
*    result => false
* </pre>
* </li>
* </ol>
*
* @@param c the character to check
* @@return true if c is a whitespace according to the jls, otherwise false.
*/
public static boolean iswhitespace(char c) {
return c < scannerhelper.max_obvious && ((scannerhelper.obvious_ident_char_natures[c] & scannerhelper.c_jls_space) != 0);
}

/**
* answers the first index in the array for which the corresponding character is
* equal to tobefound. answers -1 if no occurrence of this character is found.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    tobefound = 'c'
*    array = { ' a', 'b', 'c', 'd' }
*    result => 2
* </pre>
* </li>
* <li><pre>
*    tobefound = 'e'
*    array = { ' a', 'b', 'c', 'd' }
*    result => -1
* </pre>
* </li>
* </ol>
*
* @@param tobefound the character to search
* @@param array the array to be searched
* @@return the first index in the array for which the corresponding character is
* equal to tobefound, -1 otherwise
* @@throws nullpointerexception if array is null
*/
public static final int indexof(char tobefound, char[] array) {
return indexof(tobefound, array, 0);
}

/**
* answers the first index in the array for which the tobefound array is a matching
* subarray following the case rule. answers -1 if no match is found.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    tobefound = { 'c' }
*    array = { ' a', 'b', 'c', 'd' }
*    result => 2
* </pre>
* </li>
* <li><pre>
*    tobefound = { 'e' }
*    array = { ' a', 'b', 'c', 'd' }
*    result => -1
* </pre>
* </li>
* </ol>
*
* @@param tobefound the subarray to search
* @@param array the array to be searched
* @@param iscasesensitive flag to know if the matching should be case sensitive
* @@return the first index in the array for which the tobefound array is a matching
* subarray following the case rule, -1 otherwise
* @@throws nullpointerexception if array is null or tobefound is null
* @@since 3.2
*/
public static final int indexof(char[] tobefound, char[] array, boolean iscasesensitive) {
return indexof(tobefound, array, iscasesensitive, 0);
}

/**
* answers the first index in the array for which the tobefound array is a matching
* subarray following the case rule starting at the index start. answers -1 if no match is found.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    tobefound = { 'c' }
*    array = { ' a', 'b', 'c', 'd' }
*    result => 2
* </pre>
* </li>
* <li><pre>
*    tobefound = { 'e' }
*    array = { ' a', 'b', 'c', 'd' }
*    result => -1
* </pre>
* </li>
* </ol>
*
* @@param tobefound the subarray to search
* @@param array the array to be searched
* @@param iscasesensitive flag to know if the matching should be case sensitive
* @@param start the starting index
* @@return the first index in the array for which the tobefound array is a matching
* subarray following the case rule starting at the index start, -1 otherwise
* @@throws nullpointerexception if array is null or tobefound is null
* @@since 3.2
*/
public static final int indexof(final char[] tobefound, final char[] array, final boolean iscasesensitive, final int start) {
return indexof(tobefound, array, iscasesensitive, start, array.length);
}

/**
* answers the first index in the array for which the tobefound array is a matching
* subarray following the case rule starting at the index start. answers -1 if no match is found.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    tobefound = { 'c' }
*    array = { ' a', 'b', 'c', 'd' }
*    result => 2
* </pre>
* </li>
* <li><pre>
*    tobefound = { 'e' }
*    array = { ' a', 'b', 'c', 'd' }
*    result => -1
* </pre>
* </li>
* </ol>
*
* @@param tobefound the subarray to search
* @@param array the array to be searched
* @@param iscasesensitive flag to know if the matching should be case sensitive
* @@param start the starting index (inclusive)
* @@param end the end index (exclusive)
* @@return the first index in the array for which the tobefound array is a matching
* subarray following the case rule starting at the index start, -1 otherwise
* @@throws nullpointerexception if array is null or tobefound is null
* @@since 3.2
*/
public static final int indexof(final char[] tobefound, final char[] array, final boolean iscasesensitive, final int start, final int end) {
final int arraylength = end;
final int tobefoundlength = tobefound.length;
if (tobefoundlength > arraylength) return -1;
if (tobefoundlength == 0) return 0;
if (tobefoundlength == arraylength) {
if (iscasesensitive) {
for (int i = start; i < arraylength; i++) {
if (array[i] != tobefound[i]) return -1;
}
return 0;
} else {
for (int i = start; i < arraylength; i++) {
if (scannerhelper.tolowercase(array[i]) != scannerhelper.tolowercase(tobefound[i])) return -1;
}
return 0;
}
}
if (iscasesensitive) {
arrayloop: for (int i = start, max = arraylength - tobefoundlength + 1; i < max; i++) {
if (array[i] == tobefound[0]) {
for (int j = 1; j < tobefoundlength; j++) {
if (array[i + j] != tobefound[j]) continue arrayloop;
}
return i;
}
}
} else {
arrayloop: for (int i = start, max = arraylength - tobefoundlength + 1; i < max; i++) {
if (scannerhelper.tolowercase(array[i]) == scannerhelper.tolowercase(tobefound[0])) {
for (int j = 1; j < tobefoundlength; j++) {
if (scannerhelper.tolowercase(array[i + j]) != scannerhelper.tolowercase(tobefound[j])) continue arrayloop;
}
return i;
}
}
}
return -1;
}

/**
* answers the first index in the array for which the corresponding character is
* equal to tobefound starting the search at index start.
* answers -1 if no occurrence of this character is found.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    tobefound = 'c'
*    array = { ' a', 'b', 'c', 'd' }
*    start = 2
*    result => 2
* </pre>
* </li>
* <li><pre>
*    tobefound = 'c'
*    array = { ' a', 'b', 'c', 'd' }
*    start = 3
*    result => -1
* </pre>
* </li>
* <li><pre>
*    tobefound = 'e'
*    array = { ' a', 'b', 'c', 'd' }
*    start = 1
*    result => -1
* </pre>
* </li>
* </ol>
*
* @@param tobefound the character to search
* @@param array the array to be searched
* @@param start the starting index
* @@return the first index in the array for which the corresponding character is
* equal to tobefound, -1 otherwise
* @@throws nullpointerexception if array is null
* @@throws arrayindexoutofboundsexception if  start is lower than 0
*/
public static final int indexof(char tobefound, char[] array, int start) {
for (int i = start; i < array.length; i++)
if (tobefound == array[i])
return i;
return -1;
}

/**
* answers the first index in the array for which the corresponding character is
* equal to tobefound starting the search at index start and before the ending index.
* answers -1 if no occurrence of this character is found.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    tobefound = 'c'
*    array = { ' a', 'b', 'c', 'd' }
*    start = 2
*    result => 2
* </pre>
* </li>
* <li><pre>
*    tobefound = 'c'
*    array = { ' a', 'b', 'c', 'd' }
*    start = 3
*    result => -1
* </pre>
* </li>
* <li><pre>
*    tobefound = 'e'
*    array = { ' a', 'b', 'c', 'd' }
*    start = 1
*    result => -1
* </pre>
* </li>
* </ol>
*
* @@param tobefound the character to search
* @@param array the array to be searched
* @@param start the starting index (inclusive)
* @@param end the ending index (exclusive)
* @@return the first index in the array for which the corresponding character is
* equal to tobefound, -1 otherwise
* @@throws nullpointerexception if array is null
* @@throws arrayindexoutofboundsexception if  start is lower than 0 or ending greater than array length
* @@since 3.2
*/
public static final int indexof(char tobefound, char[] array, int start, int end) {
for (int i = start; i < end; i++)
if (tobefound == array[i])
return i;
return -1;
}

/**
* answers the last index in the array for which the corresponding character is
* equal to tobefound starting from the end of the array.
* answers -1 if no occurrence of this character is found.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    tobefound = 'c'
*    array = { ' a', 'b', 'c', 'd' , 'c', 'e' }
*    result => 4
* </pre>
* </li>
* <li><pre>
*    tobefound = 'e'
*    array = { ' a', 'b', 'c', 'd' }
*    result => -1
* </pre>
* </li>
* </ol>
*
* @@param tobefound the character to search
* @@param array the array to be searched
* @@return the last index in the array for which the corresponding character is
* equal to tobefound starting from the end of the array, -1 otherwise
* @@throws nullpointerexception if array is null
*/
public static final int lastindexof(char tobefound, char[] array) {
for (int i = array.length; --i >= 0;)
if (tobefound == array[i])
return i;
return -1;
}

/**
* answers the last index in the array for which the corresponding character is
* equal to tobefound stopping at the index startindex.
* answers -1 if no occurrence of this character is found.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    tobefound = 'c'
*    array = { ' a', 'b', 'c', 'd' }
*    startindex = 2
*    result => 2
* </pre>
* </li>
* <li><pre>
*    tobefound = 'c'
*    array = { ' a', 'b', 'c', 'd', 'e' }
*    startindex = 3
*    result => -1
* </pre>
* </li>
* <li><pre>
*    tobefound = 'e'
*    array = { ' a', 'b', 'c', 'd' }
*    startindex = 0
*    result => -1
* </pre>
* </li>
* </ol>
*
* @@param tobefound the character to search
* @@param array the array to be searched
* @@param startindex the stopping index
* @@return the last index in the array for which the corresponding character is
* equal to tobefound stopping at the index startindex, -1 otherwise
* @@throws nullpointerexception if array is null
* @@throws arrayindexoutofboundsexception if startindex is lower than 0
*/
public static final int lastindexof(
char tobefound,
char[] array,
int startindex) {
for (int i = array.length; --i >= startindex;)
if (tobefound == array[i])
return i;
return -1;
}

/**
* answers the last index in the array for which the corresponding character is
* equal to tobefound starting from endindex to startindex.
* answers -1 if no occurrence of this character is found.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    tobefound = 'c'
*    array = { ' a', 'b', 'c', 'd' }
*    startindex = 2
*    endindex = 2
*    result => 2
* </pre>
* </li>
* <li><pre>
*    tobefound = 'c'
*    array = { ' a', 'b', 'c', 'd', 'e' }
*    startindex = 3
*    endindex = 4
*    result => -1
* </pre>
* </li>
* <li><pre>
*    tobefound = 'e'
*    array = { ' a', 'b', 'c', 'd' }
*    startindex = 0
*    endindex = 3
*    result => -1
* </pre>
* </li>
* </ol>
*
* @@param tobefound the character to search
* @@param array the array to be searched
* @@param startindex the stopping index
* @@param endindex the starting index
* @@return the last index in the array for which the corresponding character is
* equal to tobefound starting from endindex to startindex, -1 otherwise
* @@throws nullpointerexception if array is null
* @@throws arrayindexoutofboundsexception if endindex is greater or equals to array length or starting is lower than 0
*/
public static final int lastindexof(
char tobefound,
char[] array,
int startindex,
int endindex) {
for (int i = endindex; --i >= startindex;)
if (tobefound == array[i])
return i;
return -1;
}

/**
* answers the last portion of a name given a separator.
* <br>
* <br>
* for example,
* <pre>
* 	lastsegment("java.lang.object".tochararray(),'.') --> object
* </pre>
*
* @@param array the array
* @@param separator the given separator
* @@return the last portion of a name given a separator
* @@throws nullpointerexception if array is null
*/
final static public char[] lastsegment(char[] array, char separator) {
int pos = lastindexof(separator, array);
if (pos < 0)
return array;
return subarray(array, pos + 1, array.length);
}

/**
* answers true if the pattern matches the given name, false otherwise. this char[] pattern matching
* accepts wild-cards '*' and '?'.
*
* when not case sensitive, the pattern is assumed to already be lowercased, the
* name will be lowercased character per character as comparing.
* if name is null, the answer is false.
* if pattern is null, the answer is true if name is not null.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    pattern = { '?', 'b', '*' }
*    name = { 'a', 'b', 'c' , 'd' }
*    iscasesensitive = true
*    result => true
* </pre>
* </li>
* <li><pre>
*    pattern = { '?', 'b', '?' }
*    name = { 'a', 'b', 'c' , 'd' }
*    iscasesensitive = true
*    result => false
* </pre>
* </li>
* <li><pre>
*    pattern = { 'b', '*' }
*    name = { 'a', 'b', 'c' , 'd' }
*    iscasesensitive = true
*    result => false
* </pre>
* </li>
* </ol>
*
* @@param pattern the given pattern
* @@param name the given name
* @@param iscasesensitive flag to know whether or not the matching should be case sensitive
* @@return true if the pattern matches the given name, false otherwise
*/
public static final boolean match(
char[] pattern,
char[] name,
boolean iscasesensitive) {

if (name == null)
return false; // null name cannot match
if (pattern == null)
return true; // null pattern is equivalent to '*'

return match(
pattern,
0,
pattern.length,
name,
0,
name.length,
iscasesensitive);
}

/**
* answers true if a sub-pattern matches the subpart of the given name, false otherwise.
* char[] pattern matching, accepting wild-cards '*' and '?'. can match only subset of name/pattern.
* end positions are non-inclusive.
* the subpattern is defined by the patternstart and pattternend positions.
* when not case sensitive, the pattern is assumed to already be lowercased, the
* name will be lowercased character per character as comparing.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    pattern = { '?', 'b', '*' }
*    patternstart = 1
*    patternend = 3
*    name = { 'a', 'b', 'c' , 'd' }
*    namestart = 1
*    nameend = 4
*    iscasesensitive = true
*    result => true
* </pre>
* </li>
* <li><pre>
*    pattern = { '?', 'b', '*' }
*    patternstart = 1
*    patternend = 2
*    name = { 'a', 'b', 'c' , 'd' }
*    namestart = 1
*    nameend = 2
*    iscasesensitive = true
*    result => false
* </pre>
* </li>
* </ol>
*
* @@param pattern the given pattern
* @@param patternstart the given pattern start
* @@param patternend the given pattern end
* @@param name the given name
* @@param namestart the given name start
* @@param nameend the given name end
* @@param iscasesensitive flag to know if the matching should be case sensitive
* @@return true if a sub-pattern matches the subpart of the given name, false otherwise
*/
public static final boolean match(
char[] pattern,
int patternstart,
int patternend,
char[] name,
int namestart,
int nameend,
boolean iscasesensitive) {

if (name == null)
return false; // null name cannot match
if (pattern == null)
return true; // null pattern is equivalent to '*'
int ipattern = patternstart;
int iname = namestart;

if (patternend < 0)
patternend = pattern.length;
if (nameend < 0)
nameend = name.length;

/* check first segment */
char patternchar = 0;
while ((ipattern < patternend)
&& (patternchar = pattern[ipattern]) != '*') {
if (iname == nameend)
return false;
if (patternchar
!= (iscasesensitive
? name[iname]
: scannerhelper.tolowercase(name[iname]))
&& patternchar != '?') {
return false;
}
iname++;
ipattern++;
}
/* check sequence of star+segment */
int segmentstart;
if (patternchar == '*') {
segmentstart = ++ipattern; // skip star
} else {
segmentstart = 0; // force iname check
}
int prefixstart = iname;
checksegment : while (iname < nameend) {
if (ipattern == patternend) {
ipattern = segmentstart; // mismatch - restart current segment
iname = ++prefixstart;
continue checksegment;
}
/* segment is ending */
if ((patternchar = pattern[ipattern]) == '*') {
segmentstart = ++ipattern; // skip start
if (segmentstart == patternend) {
return true;
}
prefixstart = iname;
continue checksegment;
}
/* check current name character */
if ((iscasesensitive ? name[iname] : scannerhelper.tolowercase(name[iname]))
!= patternchar
&& patternchar != '?') {
ipattern = segmentstart; // mismatch - restart current segment
iname = ++prefixstart;
continue checksegment;
}
iname++;
ipattern++;
}

return (segmentstart == patternend)
|| (iname == nameend && ipattern == patternend)
|| (ipattern == patternend - 1 && pattern[ipattern] == '*');
}

/**
* answers true if the pattern matches the filepath using the pathsepatator, false otherwise.
*
* path char[] pattern matching, accepting wild-cards '**', '*' and '?' (using ant directory tasks
* conventions, also see "http://jakarta.apache.org/ant/manual/dirtasks.html#defaultexcludes").
* path pattern matching is enhancing regular pattern matching in supporting extra rule where '**' represent
* any folder combination.
* special rule:
* - foo\  is equivalent to foo\**
* when not case sensitive, the pattern is assumed to already be lowercased, the
* name will be lowercased character per character as comparing.
*
* @@param pattern the given pattern
* @@param filepath the given path
* @@param iscasesensitive to find out whether or not the matching should be case sensitive
* @@param pathseparator the given path separator
* @@return true if the pattern matches the filepath using the pathsepatator, false otherwise
*/
public static final boolean pathmatch(
char[] pattern,
char[] filepath,
boolean iscasesensitive,
char pathseparator) {

if (filepath == null)
return false; // null name cannot match
if (pattern == null)
return true; // null pattern is equivalent to '*'

// offsets inside pattern
int psegmentstart = pattern[0] == pathseparator ? 1 : 0;
int plength = pattern.length;
int psegmentend = charoperation.indexof(pathseparator, pattern, psegmentstart+1);
if (psegmentend < 0) psegmentend = plength;

// special case: pattern foo\ is equivalent to foo\**
boolean freetrailingdoublestar = pattern[plength - 1] == pathseparator;

// offsets inside filepath
int fsegmentstart, flength = filepath.length;
if (filepath[0] != pathseparator){
fsegmentstart = 0;
} else {
fsegmentstart = 1;
}
if (fsegmentstart != psegmentstart) {
return false; // both must start with a separator or none.
}
int fsegmentend = charoperation.indexof(pathseparator, filepath, fsegmentstart+1);
if (fsegmentend < 0) fsegmentend = flength;

// first segments
while (psegmentstart < plength
&& !(psegmentend == plength && freetrailingdoublestar
|| (psegmentend == psegmentstart + 2
&& pattern[psegmentstart] == '*'
&& pattern[psegmentstart + 1] == '*'))) {

if (fsegmentstart >= flength)
return false;
if (!charoperation
.match(
pattern,
psegmentstart,
psegmentend,
filepath,
fsegmentstart,
fsegmentend,
iscasesensitive)) {
return false;
}

// jump to next segment
psegmentend =
charoperation.indexof(
pathseparator,
pattern,
psegmentstart = psegmentend + 1);
// skip separator
if (psegmentend < 0)
psegmentend = plength;

fsegmentend =
charoperation.indexof(
pathseparator,
filepath,
fsegmentstart = fsegmentend + 1);
// skip separator
if (fsegmentend < 0) fsegmentend = flength;
}

/* check sequence of doublestar+segment */
int psegmentrestart;
if ((psegmentstart >= plength && freetrailingdoublestar)
|| (psegmentend == psegmentstart + 2
&& pattern[psegmentstart] == '*'
&& pattern[psegmentstart + 1] == '*')) {
psegmentend =
charoperation.indexof(
pathseparator,
pattern,
psegmentstart = psegmentend + 1);
// skip separator
if (psegmentend < 0) psegmentend = plength;
psegmentrestart = psegmentstart;
} else {
if (psegmentstart >= plength) return fsegmentstart >= flength; // true if filepath is done too.
psegmentrestart = 0; // force fsegmentstart check
}
int fsegmentrestart = fsegmentstart;
checksegment : while (fsegmentstart < flength) {

if (psegmentstart >= plength) {
if (freetrailingdoublestar) return true;
// mismatch - restart current path segment
psegmentend =
charoperation.indexof(pathseparator, pattern, psegmentstart = psegmentrestart);
if (psegmentend < 0) psegmentend = plength;

fsegmentrestart =
charoperation.indexof(pathseparator, filepath, fsegmentrestart + 1);
// skip separator
if (fsegmentrestart < 0) {
fsegmentrestart = flength;
} else {
fsegmentrestart++;
}
fsegmentend =
charoperation.indexof(pathseparator, filepath, fsegmentstart = fsegmentrestart);
if (fsegmentend < 0) fsegmentend = flength;
continue checksegment;
}

/* path segment is ending */
if (psegmentend == psegmentstart + 2
&& pattern[psegmentstart] == '*'
&& pattern[psegmentstart + 1] == '*') {
psegmentend =
charoperation.indexof(pathseparator, pattern, psegmentstart = psegmentend + 1);
// skip separator
if (psegmentend < 0) psegmentend = plength;
psegmentrestart = psegmentstart;
fsegmentrestart = fsegmentstart;
if (psegmentstart >= plength) return true;
continue checksegment;
}
/* chech current path segment */
if (!charoperation.match(
pattern,
psegmentstart,
psegmentend,
filepath,
fsegmentstart,
fsegmentend,
iscasesensitive)) {
// mismatch - restart current path segment
psegmentend =
charoperation.indexof(pathseparator, pattern, psegmentstart = psegmentrestart);
if (psegmentend < 0) psegmentend = plength;

fsegmentrestart =
charoperation.indexof(pathseparator, filepath, fsegmentrestart + 1);
// skip separator
if (fsegmentrestart < 0) {
fsegmentrestart = flength;
} else {
fsegmentrestart++;
}
fsegmentend =
charoperation.indexof(pathseparator, filepath, fsegmentstart = fsegmentrestart);
if (fsegmentend < 0) fsegmentend = flength;
continue checksegment;
}
// jump to next segment
psegmentend =
charoperation.indexof(
pathseparator,
pattern,
psegmentstart = psegmentend + 1);
// skip separator
if (psegmentend < 0)
psegmentend = plength;

fsegmentend =
charoperation.indexof(
pathseparator,
filepath,
fsegmentstart = fsegmentend + 1);
// skip separator
if (fsegmentend < 0)
fsegmentend = flength;
}

return (psegmentrestart >= psegmentend)
|| (fsegmentstart >= flength && psegmentstart >= plength)
|| (psegmentstart == plength - 2
&& pattern[psegmentstart] == '*'
&& pattern[psegmentstart + 1] == '*')
|| (psegmentstart == plength && freetrailingdoublestar);
}

/**
* answers the number of occurrences of the given character in the given array, 0 if any.
*
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    tobefound = 'b'
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    result => 3
* </pre>
* </li>
* <li><pre>
*    tobefound = 'c'
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    result => 0
* </pre>
* </li>
* </ol>
*
* @@param tobefound the given character
* @@param array the given array
* @@return the number of occurrences of the given character in the given array, 0 if any
* @@throws nullpointerexception if array is null
*/
public static final int occurencesof(char tobefound, char[] array) {
int count = 0;
for (int i = 0; i < array.length; i++)
if (tobefound == array[i])
count++;
return count;
}

/**
* answers the number of occurrences of the given character in the given array starting
* at the given index, 0 if any.
*
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    tobefound = 'b'
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    start = 2
*    result => 2
* </pre>
* </li>
* <li><pre>
*    tobefound = 'c'
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    start = 0
*    result => 0
* </pre>
* </li>
* </ol>
*
* @@param tobefound the given character
* @@param array the given array
* @@param start the given index
* @@return the number of occurrences of the given character in the given array, 0 if any
* @@throws nullpointerexception if array is null
* @@throws arrayindexoutofboundsexception if start is lower than 0
*/
public static final int occurencesof(
char tobefound,
char[] array,
int start) {
int count = 0;
for (int i = start; i < array.length; i++)
if (tobefound == array[i])
count++;
return count;
}
/**
* return the int value represented by the designated subpart of array. the
* calculation of the result for single-digit positive integers is optimized in
* time.
* @@param array the array within which the int value is to be parsed
* @@param start first character of the int value in array
* @@param length length of the int value in array
* @@return the int value of a subpart of array
* @@throws numberformatexception if the designated subpart of array does not
*         parse to an int
* @@since 3.4
*/
public static final int parseint(char[] array, int start, int length) throws numberformatexception {
if (length == 1) {
int result = array[start] - '0';
if (result < 0 || result > 9) {
throw new numberformatexception("invalid digit"); //$non-nls-1$
}
return result;
} else {
return integer.parseint(new string(array, start, length));
}
}
/**
* answers true if the given name starts with the given prefix, false otherwise.
* the comparison is case sensitive.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    prefix = { 'a' , 'b' }
*    name = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    result => true
* </pre>
* </li>
* <li><pre>
*    prefix = { 'a' , 'c' }
*    name = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    result => false
* </pre>
* </li>
* </ol>
*
* @@param prefix the given prefix
* @@param name the given name
* @@return true if the given name starts with the given prefix, false otherwise
* @@throws nullpointerexception if the given name is null or if the given prefix is null
*/
public static final boolean prefixequals(char[] prefix, char[] name) {

int max = prefix.length;
if (name.length < max)
return false;
for (int i = max;
--i >= 0;
) // assumes the prefix is not larger than the name
if (prefix[i] != name[i])
return false;
return true;
}

/**
* answers true if the given name starts with the given prefix, false otherwise.
* iscasesensitive is used to find out whether or not the comparison should be case sensitive.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    prefix = { 'a' , 'b' }
*    name = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    iscasesensitive = false
*    result => true
* </pre>
* </li>
* <li><pre>
*    prefix = { 'a' , 'b' }
*    name = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    iscasesensitive = true
*    result => false
* </pre>
* </li>
* </ol>
*
* @@param prefix the given prefix
* @@param name the given name
* @@param iscasesensitive to find out whether or not the comparison should be case sensitive
* @@return true if the given name starts with the given prefix, false otherwise
* @@throws nullpointerexception if the given name is null or if the given prefix is null
*/
public static final boolean prefixequals(
char[] prefix,
char[] name,
boolean iscasesensitive) {

int max = prefix.length;
if (name.length < max)
return false;
if (iscasesensitive) {
for (int i = max;
--i >= 0;
) // assumes the prefix is not larger than the name
if (prefix[i] != name[i])
return false;
return true;
}

for (int i = max;
--i >= 0;
) // assumes the prefix is not larger than the name
if (scannerhelper.tolowercase(prefix[i])
!= scannerhelper.tolowercase(name[i]))
return false;
return true;
}

/**
* answers a new array removing a given character. answers the given array if there is
* no occurrence of the character to remove.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    array = { 'a' , 'b', 'b', 'c', 'b', 'a' }
*    toberemoved = 'b'
*    return { 'a' , 'c', 'a' }
* </pre>
* </li>
* <li><pre>
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    toberemoved = 'c'
*    return array
* </pre>
* </li>
* </ol>
*
* @@param array the given array
* @@param toberemoved the character to be removed
* @@return a new array removing given character
* @@since 3.2
*/
public static final char[] remove(char[] array, char toberemoved) {

if (array == null) return null;
int length = array.length;
if (length == 0) return array;
char[] result = null;
int count = 0;
for (int i = 0; i < length; i++) {
char c = array[i];
if (c == toberemoved) {
if (result == null) {
result = new char[length];
system.arraycopy(array, 0, result, 0, i);
count = i;
}
} else if (result != null) {
result[count++] = c;
}
}
if (result == null) return array;
system.arraycopy(result, 0, result = new char[count], 0, count);
return result;
}

/**
* replace all occurrence of the character to be replaced with the replacement character in the
* given array.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    tobereplaced = 'b'
*    replacementchar = 'a'
*    result => no returned value, but array is now equals to { 'a' , 'a', 'a', 'a', 'a', 'a' }
* </pre>
* </li>
* <li><pre>
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    tobereplaced = 'c'
*    replacementchar = 'a'
*    result => no returned value, but array is now equals to { 'a' , 'b', 'b', 'a', 'b', 'a' }
* </pre>
* </li>
* </ol>
*
* @@param array the given array
* @@param tobereplaced the character to be replaced
* @@param replacementchar the replacement character
* @@throws nullpointerexception if the given array is null
*/
public static final void replace(
char[] array,
char tobereplaced,
char replacementchar) {
if (tobereplaced != replacementchar) {
for (int i = 0, max = array.length; i < max; i++) {
if (array[i] == tobereplaced)
array[i] = replacementchar;
}
}
}

/**
* replace all occurrences of characters to be replaced with the replacement character in the
* given array.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    array = { 'a' , 'b', 'b', 'c', 'a', 'b', 'c', 'a' }
*    tobereplaced = { 'b', 'c' }
*    replacementchar = 'a'
*    result => no returned value, but array is now equals to { 'a' , 'a', 'a', 'a', 'a', 'a', 'a', 'a' }
* </pre>
* </li>
* </ol>
*
* @@param array the given array
* @@param tobereplaced characters to be replaced
* @@param replacementchar the replacement character
* @@throws nullpointerexception if arrays are null.
* @@since 3.1
*/
public static final void replace(char[] array, char[] tobereplaced, char replacementchar) {
replace(array, tobereplaced, replacementchar, 0, array.length);
}

/**
* replace all occurrences of characters to be replaced with the replacement character in the
* given array from the start position (inclusive) to the end position (exclusive).
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    array = { 'a' , 'b', 'b', 'c', 'a', 'b', 'c', 'a' }
*    tobereplaced = { 'b', 'c' }
*    replacementchar = 'a'
*    start = 4
*    end = 8
*    result => no returned value, but array is now equals to { 'a' , 'b', 'b', 'c', 'a', 'a', 'a', 'a' }
* </pre>
* </li>
* </ol>
*
* @@param array the given array
* @@param tobereplaced characters to be replaced
* @@param replacementchar the replacement character
* @@param start the given start position (inclusive)
* @@param end  the given end position (exclusive)
* @@throws nullpointerexception if arrays are null.
* @@since 3.2
*/
public static final void replace(char[] array, char[] tobereplaced, char replacementchar, int start, int end) {
for (int i = end; --i >= start;)
for (int j = tobereplaced.length; --j >= 0;)
if (array[i] == tobereplaced[j])
array[i] = replacementchar;
}
/**
* answers a new array of characters with substitutions. no side-effect is operated on the original
* array, in case no substitution happened, then the result is the same as the
* original one.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    tobereplaced = { 'b' }
*    replacementchar = { 'a', 'a' }
*    result => { 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a' }
* </pre>
* </li>
* <li><pre>
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    tobereplaced = { 'c' }
*    replacementchar = { 'a' }
*    result => { 'a' , 'b', 'b', 'a', 'b', 'a' }
* </pre>
* </li>
* </ol>
*
* @@param array the given array
* @@param tobereplaced characters to be replaced
* @@param replacementchars the replacement characters
* @@return a new array of characters with substitutions or the given array if none
* @@throws nullpointerexception if the given array is null
*/
public static final char[] replace(
char[] array,
char[] tobereplaced,
char[] replacementchars) {

int max = array.length;
int replacedlength = tobereplaced.length;
int replacementlength = replacementchars.length;

int[] starts = new int[5];
int occurrencecount = 0;

if (!equals(tobereplaced, replacementchars)) {

next : for (int i = 0; i < max;) {
int index = indexof(tobereplaced, array, true, i);
if (index == -1) {
i++;
continue next;
}
if (occurrencecount == starts.length) {
system.arraycopy(
starts,
0,
starts = new int[occurrencecount * 2],
0,
occurrencecount);
}
starts[occurrencecount++] = index;
i = index + replacedlength;
}
}
if (occurrencecount == 0)
return array;
char[] result =
new char[max
+ occurrencecount * (replacementlength - replacedlength)];
int instart = 0, outstart = 0;
for (int i = 0; i < occurrencecount; i++) {
int offset = starts[i] - instart;
system.arraycopy(array, instart, result, outstart, offset);
instart += offset;
outstart += offset;
system.arraycopy(
replacementchars,
0,
result,
outstart,
replacementlength);
instart += replacedlength;
outstart += replacementlength;
}
system.arraycopy(array, instart, result, outstart, max - instart);
return result;
}

/**
* replace all occurrence of the character to be replaced with the replacement character
* in a copy of the given array. returns the given array if no occurrences of the character
* to be replaced are found.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    tobereplaced = 'b'
*    replacementchar = 'a'
*    result => a new array that is equals to { 'a' , 'a', 'a', 'a', 'a', 'a' }
* </pre>
* </li>
* <li><pre>
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    tobereplaced = 'c'
*    replacementchar = 'a'
*    result => the original array that remains unchanged.
* </pre>
* </li>
* </ol>
*
* @@param array the given array
* @@param tobereplaced the character to be replaced
* @@param replacementchar the replacement character
* @@throws nullpointerexception if the given array is null
* @@since 3.1
*/
public static final char[] replaceoncopy(
char[] array,
char tobereplaced,
char replacementchar) {

char[] result = null;
for (int i = 0, length = array.length; i < length; i++) {
char c = array[i];
if (c == tobereplaced) {
if (result == null) {
result = new char[length];
system.arraycopy(array, 0, result, 0, i);
}
result[i] = replacementchar;
} else if (result != null) {
result[i] = c;
}
}
if (result == null) return array;
return result;
}

/**
* return a new array which is the split of the given array using the given divider and trimming each subarray to remove
* whitespaces equals to ' '.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    divider = 'b'
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    result => { { 'a' }, {  }, { 'a' }, { 'a' } }
* </pre>
* </li>
* <li><pre>
*    divider = 'c'
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    result => { { 'a', 'b', 'b', 'a', 'b', 'a' } }
* </pre>
* </li>
* <li><pre>
*    divider = 'b'
*    array = { 'a' , ' ', 'b', 'b', 'a', 'b', 'a' }
*    result => { { 'a' }, {  }, { 'a' }, { 'a' } }
* </pre>
* </li>
* <li><pre>
*    divider = 'c'
*    array = { ' ', ' ', 'a' , 'b', 'b', 'a', 'b', 'a', ' ' }
*    result => { { 'a', 'b', 'b', 'a', 'b', 'a' } }
* </pre>
* </li>
* </ol>
*
* @@param divider the given divider
* @@param array the given array
* @@return a new array which is the split of the given array using the given divider and trimming each subarray to remove
* whitespaces equals to ' '
*/
public static final char[][] splitandtrimon(char divider, char[] array) {
int length = array == null ? 0 : array.length;
if (length == 0)
return no_char_char;

int wordcount = 1;
for (int i = 0; i < length; i++)
if (array[i] == divider)
wordcount++;
char[][] split = new char[wordcount][];
int last = 0, currentword = 0;
for (int i = 0; i < length; i++) {
if (array[i] == divider) {
int start = last, end = i - 1;
while (start < i && array[start] == ' ')
start++;
while (end > start && array[end] == ' ')
end--;
split[currentword] = new char[end - start + 1];
system.arraycopy(
array,
start,
split[currentword++],
0,
end - start + 1);
last = i + 1;
}
}
int start = last, end = length - 1;
while (start < length && array[start] == ' ')
start++;
while (end > start && array[end] == ' ')
end--;
split[currentword] = new char[end - start + 1];
system.arraycopy(
array,
start,
split[currentword++],
0,
end - start + 1);
return split;
}

/**
* return a new array which is the split of the given array using the given divider.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    divider = 'b'
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    result => { { 'a' }, {  }, { 'a' }, { 'a' } }
* </pre>
* </li>
* <li><pre>
*    divider = 'c'
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    result => { { 'a', 'b', 'b', 'a', 'b', 'a' } }
* </pre>
* </li>
* <li><pre>
*    divider = 'c'
*    array = { ' ', ' ', 'a' , 'b', 'b', 'a', 'b', 'a', ' ' }
*    result => { { ' ', 'a', 'b', 'b', 'a', 'b', 'a', ' ' } }
* </pre>
* </li>
* </ol>
*
* @@param divider the given divider
* @@param array the given array
* @@return a new array which is the split of the given array using the given divider
*/
public static final char[][] spliton(char divider, char[] array) {
int length = array == null ? 0 : array.length;
if (length == 0)
return no_char_char;

int wordcount = 1;
for (int i = 0; i < length; i++)
if (array[i] == divider)
wordcount++;
char[][] split = new char[wordcount][];
int last = 0, currentword = 0;
for (int i = 0; i < length; i++) {
if (array[i] == divider) {
split[currentword] = new char[i - last];
system.arraycopy(
array,
last,
split[currentword++],
0,
i - last);
last = i + 1;
}
}
split[currentword] = new char[length - last];
system.arraycopy(array, last, split[currentword], 0, length - last);
return split;
}

/**
* return a new array which is the split of the given array using the given divider. the given end
* is exclusive and the given start is inclusive.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    divider = 'b'
*    array = { 'a' , 'b', 'b', 'a', 'b', 'a' }
*    start = 2
*    end = 5
*    result => { {  }, { 'a' }, {  } }
* </pre>
* </li>
* </ol>
*
* @@param divider the given divider
* @@param array the given array
* @@param start the given starting index
* @@param end the given ending index
* @@return a new array which is the split of the given array using the given divider
* @@throws arrayindexoutofboundsexception if start is lower than 0 or end is greater than the array length
*/
public static final char[][] spliton(
char divider,
char[] array,
int start,
int end) {
int length = array == null ? 0 : array.length;
if (length == 0 || start > end)
return no_char_char;

int wordcount = 1;
for (int i = start; i < end; i++)
if (array[i] == divider)
wordcount++;
char[][] split = new char[wordcount][];
int last = start, currentword = 0;
for (int i = start; i < end; i++) {
if (array[i] == divider) {
split[currentword] = new char[i - last];
system.arraycopy(
array,
last,
split[currentword++],
0,
i - last);
last = i + 1;
}
}
split[currentword] = new char[end - last];
system.arraycopy(array, last, split[currentword], 0, end - last);
return split;
}

/**
* answers a new array which is a copy of the given array starting at the given start and
* ending at the given end. the given start is inclusive and the given end is exclusive.
* answers null if start is greater than end, if start is lower than 0 or if end is greater
* than the length of the given array. if end  equals -1, it is converted to the array length.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    array = { { 'a' } , { 'b' } }
*    start = 0
*    end = 1
*    result => { { 'a' } }
* </pre>
* </li>
* <li><pre>
*    array = { { 'a' } , { 'b' } }
*    start = 0
*    end = -1
*    result => { { 'a' }, { 'b' } }
* </pre>
* </li>
* </ol>
*
* @@param array the given array
* @@param start the given starting index
* @@param end the given ending index
* @@return a new array which is a copy of the given array starting at the given start and
* ending at the given end
* @@throws nullpointerexception if the given array is null
*/
public static final char[][] subarray(char[][] array, int start, int end) {
if (end == -1)
end = array.length;
if (start > end)
return null;
if (start < 0)
return null;
if (end > array.length)
return null;

char[][] result = new char[end - start][];
system.arraycopy(array, start, result, 0, end - start);
return result;
}

/**
* answers a new array which is a copy of the given array starting at the given start and
* ending at the given end. the given start is inclusive and the given end is exclusive.
* answers null if start is greater than end, if start is lower than 0 or if end is greater
* than the length of the given array. if end  equals -1, it is converted to the array length.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    array = { 'a' , 'b' }
*    start = 0
*    end = 1
*    result => { 'a' }
* </pre>
* </li>
* <li><pre>
*    array = { 'a', 'b' }
*    start = 0
*    end = -1
*    result => { 'a' , 'b' }
* </pre>
* </li>
* </ol>
*
* @@param array the given array
* @@param start the given starting index
* @@param end the given ending index
* @@return a new array which is a copy of the given array starting at the given start and
* ending at the given end
* @@throws nullpointerexception if the given array is null
*/
public static final char[] subarray(char[] array, int start, int end) {
if (end == -1)
end = array.length;
if (start > end)
return null;
if (start < 0)
return null;
if (end > array.length)
return null;

char[] result = new char[end - start];
system.arraycopy(array, start, result, 0, end - start);
return result;
}

/**
* answers the result of a char[] conversion to lowercase. answers null if the given chars array is null.
* <br>
* note: if no conversion was necessary, then answers back the argument one.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    chars = { 'a' , 'b' }
*    result => { 'a' , 'b' }
* </pre>
* </li>
* <li><pre>
*    array = { 'a', 'b' }
*    result => { 'a' , 'b' }
* </pre>
* </li>
* </ol>
*
* @@param chars the chars to convert
* @@return the result of a char[] conversion to lowercase
*/
final static public char[] tolowercase(char[] chars) {
if (chars == null)
return null;
int length = chars.length;
char[] lowerchars = null;
for (int i = 0; i < length; i++) {
char c = chars[i];
char lc = scannerhelper.tolowercase(c);
if ((c != lc) || (lowerchars != null)) {
if (lowerchars == null) {
system.arraycopy(
chars,
0,
lowerchars = new char[length],
0,
i);
}
lowerchars[i] = lc;
}
}
return lowerchars == null ? chars : lowerchars;
}

/**
* answers the result of a char[] conversion to uppercase. answers null if the given chars array is null.
* <br>
* note: if no conversion was necessary, then answers back the argument one.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    chars = { 'a' , 'b' }
*    result => { 'a' , 'b' }
* </pre>
* </li>
* <li><pre>
*    array = { 'a', 'b' }
*    result => { 'a' , 'b' }
* </pre>
* </li>
* </ol>
*
* @@param chars the chars to convert
* @@return the result of a char[] conversion to uppercase
*
* @@since 3.5
*/
final static public char[] touppercase(char[] chars) {
if (chars == null)
return null;
int length = chars.length;
char[] upperchars = null;
for (int i = 0; i < length; i++) {
char c = chars[i];
char lc = scannerhelper.touppercase(c);
if ((c != lc) || (upperchars != null)) {
if (upperchars == null) {
system.arraycopy(
chars,
0,
upperchars = new char[length],
0,
i);
}
upperchars[i] = lc;
}
}
return upperchars == null ? chars : upperchars;
}

/**
* answers a new array removing leading and trailing spaces (' '). answers the given array if there is no
* space characters to remove.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    chars = { ' ', 'a' , 'b', ' ',  ' ' }
*    result => { 'a' , 'b' }
* </pre>
* </li>
* <li><pre>
*    array = { 'a', 'b' }
*    result => { 'a' , 'b' }
* </pre>
* </li>
* </ol>
*
* @@param chars the given array
* @@return a new array removing leading and trailing spaces (' ')
*/
final static public char[] trim(char[] chars) {

if (chars == null)
return null;

int start = 0, length = chars.length, end = length - 1;
while (start < length && chars[start] == ' ') {
start++;
}
while (end > start && chars[end] == ' ') {
end--;
}
if (start != 0 || end != length - 1) {
return subarray(chars, start, end + 1);
}
return chars;
}

/**
* answers a string which is the concatenation of the given array using the '.' as a separator.
* <br>
* <br>
* for example:
* <ol>
* <li><pre>
*    array = { { 'a' } , { 'b' } }
*    result => "a.b"
* </pre>
* </li>
* <li><pre>
*    array = { { ' ',  'a' } , { 'b' } }
*    result => " a.b"
* </pre>
* </li>
* </ol>
*
* @@param array the given array
* @@return a string which is the concatenation of the given array using the '.' as a separator
*/
final static public string tostring(char[][] array) {
char[] result = concatwith(array, '.');
return new string(result);
}

/**
* answers an array of strings from the given array of char array.
*
* @@param array the given array
* @@return an array of strings
* @@since 3.0
*/
final static public string[] tostrings(char[][] array) {
if (array == null) return no_strings;
int length = array.length;
if (length == 0) return no_strings;
string[] result = new string[length];
for (int i = 0; i < length; i++)
result[i] = new string(array[i]);
return result;
}
}
