/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.ast.branchstatement;
import org.eclipse.jdt.internal.compiler.ast.dostatement;
import org.eclipse.jdt.internal.compiler.ast.forstatement;
import org.eclipse.jdt.internal.compiler.ast.labeledstatement;
import org.eclipse.jdt.internal.compiler.ast.switchstatement;
import org.eclipse.jdt.internal.compiler.ast.whilestatement;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;

public class resetstateforcodegenerationvisitor
extends astvisitor {

public boolean visit(switchstatement statement, blockscope scope) {
statement.resetstateforcodegeneration();
return true;
}

public boolean visit(forstatement forstatement, blockscope scope) {
forstatement.resetstateforcodegeneration();
return true;
}

public boolean visit(whilestatement whilestatement, blockscope scope) {
whilestatement.resetstateforcodegeneration();
return true;
}

public boolean visit(labeledstatement labeledstatement, blockscope scope) {
labeledstatement.resetstateforcodegeneration();
return true;
}

public boolean visit(dostatement dostatement, blockscope scope) {
dostatement.resetstateforcodegeneration();
return true;
}

public boolean visit(branchstatement branchstatement, blockscope scope) {
branchstatement.resetstateforcodegeneration();
return true;
}

public boolean visit(trystatement trystatement, blockscope scope) {
trystatement.resetstateforcodegeneration();
return true;
}

public boolean visit(synchronizedstatement synchronizedstatement, blockscope scope) {
synchronizedstatement.resetstateforcodegeneration();
return true;
}
}

