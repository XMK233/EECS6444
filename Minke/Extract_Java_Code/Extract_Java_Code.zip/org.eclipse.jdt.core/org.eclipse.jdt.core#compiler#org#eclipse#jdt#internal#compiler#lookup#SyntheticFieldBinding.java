/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.impl.constant;

public class syntheticfieldbinding extends fieldbinding {

public int index;

public syntheticfieldbinding(char[] name, typebinding type, int modifiers, referencebinding declaringclass, constant constant, int index) {
super(name, type, modifiers, declaringclass, constant);
this.index = index;
this.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
}
}
