/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce an allocation expression containing the cursor.
* if the allocation expression is not qualified, the enclosinginstance field
* is null.
* e.g.
*
*	class x {
*    void foo() {
*      new bar(1, 2, [cursor]
*    }
*  }
*
*	---> class x {
*         void foo() {
*           <completeonallocationexpression:new bar(1, 2)>
*         }
*       }
*
* the source range is always of length 0.
* the arguments of the allocation expression are all the arguments defined
* before the cursor.
*/

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class completiononqualifiedallocationexpression extends qualifiedallocationexpression {
public typebinding resolvetype(blockscope scope) {
if (this.arguments != null) {
int argslength = this.arguments.length;
for (int a = argslength; --a >= 0;)
this.arguments[a].resolvetype(scope);
}

if (this.enclosinginstance != null) {
typebinding enclosingtype = this.enclosinginstance.resolvetype(scope);
if (enclosingtype == null || !(enclosingtype instanceof referencebinding)) {
throw new completionnodefound();
}
this.resolvedtype = ((singletypereference) this.type).resolvetypeenclosing(scope, (referencebinding) enclosingtype);
if (!(this.resolvedtype instanceof referencebinding))
throw new completionnodefound(); // no need to continue if its an array or base type
if (this.resolvedtype.isinterface()) // handle the anonymous class definition case
this.resolvedtype = scope.getjavalangobject();
} else {
this.resolvedtype = this.type.resolvetype(scope, true /* check bounds*/);
if (!(this.resolvedtype instanceof referencebinding))
throw new completionnodefound(); // no need to continue if its an array or base type
}

throw new completionnodefound(this, this.resolvedtype, scope);
}
public stringbuffer printexpression(int indent, stringbuffer output) {
if (this.enclosinginstance == null)
output.append("<completeonallocationexpression:" );  //$non-nls-1$
else
output.append("<completeonqualifiedallocationexpression:");  //$non-nls-1$
return super.printexpression(indent, output).append('>');
}
}
