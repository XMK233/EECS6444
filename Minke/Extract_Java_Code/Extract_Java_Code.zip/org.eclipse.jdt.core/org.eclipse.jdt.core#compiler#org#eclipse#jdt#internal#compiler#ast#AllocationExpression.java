/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     stephan herrmann - contribution for bug 236385
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class allocationexpression extends expression implements invocationsite {

public typereference type;
public expression[] arguments;
public methodbinding binding;							// exact binding resulting from lookup
methodbinding syntheticaccessor;						// synthetic accessor for inner-emulation
public typereference[] typearguments;
public typebinding[] generictypearguments;
public fielddeclaration enumconstant; // for enum constant initializations

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
// check captured variables are initialized in current context (26134)
checkcapturedlocalinitializationifnecessary((referencebinding)this.binding.declaringclass.erasure(), currentscope, flowinfo);

// process arguments
if (this.arguments != null) {
for (int i = 0, count = this.arguments.length; i < count; i++) {
flowinfo =
this.arguments[i]
.analysecode(currentscope, flowcontext, flowinfo)
.unconditionalinits();
}
}
// record some dependency information for exception types
referencebinding[] thrownexceptions;
if (((thrownexceptions = this.binding.thrownexceptions).length) != 0) {
if ((this.bits & astnode.unchecked) != 0 && this.generictypearguments == null) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=277643, align with javac on jls 15.12.2.6
thrownexceptions = currentscope.environment().converttorawtypes(this.binding.thrownexceptions, true, true);
}
// check exception handling
flowcontext.checkexceptionhandlers(
thrownexceptions,
this,
flowinfo.unconditionalcopy(),
currentscope);
}
manageenclosinginstanceaccessifnecessary(currentscope, flowinfo);
managesyntheticaccessifnecessary(currentscope, flowinfo);

return flowinfo;
}

public void checkcapturedlocalinitializationifnecessary(referencebinding checkedtype, blockscope currentscope, flowinfo flowinfo) {
if (((checkedtype.tagbits & ( tagbits.anonymoustypemask|tagbits.localtypemask)) == tagbits.localtypemask)
&& !currentscope.isdefinedintype(checkedtype)) { // only check external allocations
nestedtypebinding nestedtype = (nestedtypebinding) checkedtype;
syntheticargumentbinding[] syntheticarguments = nestedtype.syntheticouterlocalvariables();
if (syntheticarguments != null)
for (int i = 0, count = syntheticarguments.length; i < count; i++){
syntheticargumentbinding syntheticargument = syntheticarguments[i];
localvariablebinding targetlocal;
if ((targetlocal = syntheticargument.actualouterlocalvariable) == null) continue;
if (targetlocal.declaration != null && !flowinfo.isdefinitelyassigned(targetlocal)){
currentscope.problemreporter().uninitializedlocalvariable(targetlocal, this);
}
}
}
}

public expression enclosinginstance() {
return null;
}

public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
if (!valuerequired)
currentscope.problemreporter().unusedobjectallocation(this);

int pc = codestream.position;
methodbinding codegenbinding = this.binding.original();
referencebinding allocatedtype = codegenbinding.declaringclass;

codestream.new_(allocatedtype);
boolean isunboxing = (this.implicitconversion & typeids.unboxing) != 0;
if (valuerequired || isunboxing) {
codestream.dup();
}
// better highlight for allocation: display the type individually
if (this.type != null) { // null for enum constant body
codestream.recordpositionsfrom(pc, this.type.sourcestart);
} else {
// push enum constant name and ordinal
codestream.ldc(string.valueof(this.enumconstant.name));
codestream.generateinlinedvalue(this.enumconstant.binding.id);
}

// handling innerclass instance allocation - enclosing instance arguments
if (allocatedtype.isnestedtype()) {
codestream.generatesyntheticenclosinginstancevalues(
currentscope,
allocatedtype,
enclosinginstance(),
this);
}
// generate the arguments for constructor
generatearguments(this.binding, this.arguments, currentscope, codestream);
// handling innerclass instance allocation - outer local arguments
if (allocatedtype.isnestedtype()) {
codestream.generatesyntheticouterargumentvalues(
currentscope,
allocatedtype,
this);
}
// invoke constructor
if (this.syntheticaccessor == null) {
codestream.invoke(opcodes.opc_invokespecial, codegenbinding, null /* default declaringclass */);
} else {
// synthetic accessor got some extra arguments appended to its signature, which need values
for (int i = 0,
max = this.syntheticaccessor.parameters.length - codegenbinding.parameters.length;
i < max;
i++) {
codestream.aconst_null();
}
codestream.invoke(opcodes.opc_invokespecial, this.syntheticaccessor, null /* default declaringclass */);
}
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else if (isunboxing) {
// conversion only generated if unboxing
codestream.generateimplicitconversion(this.implicitconversion);
switch (postconversiontype(currentscope).id) {
case t_long :
case t_double :
codestream.pop2();
break;
default :
codestream.pop();
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#generictypearguments()
*/
public typebinding[] generictypearguments() {
return this.generictypearguments;
}

public boolean issuperaccess() {
return false;
}

public boolean istypeaccess() {
return true;
}

/* inner emulation consists in either recording a dependency
* link only, or performing one level of propagation.
*
* dependency mechanism is used whenever dealing with source target
* types, since by the time we reach them, we might not yet know their
* exact need.
*/
public void manageenclosinginstanceaccessifnecessary(blockscope currentscope, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) != 0) return;
referencebinding allocatedtypeerasure = (referencebinding) this.binding.declaringclass.erasure();

// perform some emulation work in case there is some and we are inside a local type only
if (allocatedtypeerasure.isnestedtype()
&& currentscope.enclosingsourcetype().islocaltype()) {

if (allocatedtypeerasure.islocaltype()) {
((localtypebinding) allocatedtypeerasure).addinneremulationdependent(currentscope, false);
// request cascade of accesses
} else {
// locally propagate, since we already now the desired shape for sure
currentscope.propagateinneremulation(allocatedtypeerasure, false);
// request cascade of accesses
}
}
}

public void managesyntheticaccessifnecessary(blockscope currentscope, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) != 0) return;
// if constructor from parameterized type got found, use the original constructor at codegen time
methodbinding codegenbinding = this.binding.original();

referencebinding declaringclass;
if (codegenbinding.isprivate() && currentscope.enclosingsourcetype() != (declaringclass = codegenbinding.declaringclass)) {

// from 1.4 on, local type constructor can lose their private flag to ease emulation
if ((declaringclass.tagbits & tagbits.islocaltype) != 0 && currentscope.compileroptions().compliancelevel >= classfileconstants.jdk1_4) {
// constructor will not be dumped as private, no emulation required thus
codegenbinding.tagbits |= tagbits.clearprivatemodifier;
} else {
this.syntheticaccessor = ((sourcetypebinding) declaringclass).addsyntheticmethod(codegenbinding, issuperaccess());
currentscope.problemreporter().needtoemulatemethodaccess(codegenbinding, this);
}
}
}

public stringbuffer printexpression(int indent, stringbuffer output) {
if (this.type != null) { // type null for enum constant initializations
output.append("new "); //$non-nls-1$
}
if (this.typearguments != null) {
output.append('<');
int max = this.typearguments.length - 1;
for (int j = 0; j < max; j++) {
this.typearguments[j].print(0, output);
output.append(", ");//$non-nls-1$
}
this.typearguments[max].print(0, output);
output.append('>');
}
if (this.type != null) { // type null for enum constant initializations
this.type.printexpression(0, output);
}
output.append('(');
if (this.arguments != null) {
for (int i = 0; i < this.arguments.length; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.arguments[i].printexpression(0, output);
}
}
return output.append(')');
}

public typebinding resolvetype(blockscope scope) {
// propagate the type checking to the arguments, and check if the constructor is defined.
this.constant = constant.notaconstant;
if (this.type == null) {
// initialization of an enum constant
this.resolvedtype = scope.enclosingreceivertype();
} else {
this.resolvedtype = this.type.resolvetype(scope, true /* check bounds*/);
checkparameterizedallocation: {
if (this.type instanceof parameterizedqualifiedtypereference) { // disallow new x<string>.y<integer>()
referencebinding currenttype = (referencebinding)this.resolvedtype;
if (currenttype == null) return currenttype;
do {
// isstatic() is answering true for toplevel types
if ((currenttype.modifiers & classfileconstants.accstatic) != 0) break checkparameterizedallocation;
if (currenttype.israwtype()) break checkparameterizedallocation;
} while ((currenttype = currenttype.enclosingtype())!= null);
parameterizedqualifiedtypereference qref = (parameterizedqualifiedtypereference) this.type;
for (int i = qref.typearguments.length - 2; i >= 0; i--) {
if (qref.typearguments[i] != null) {
scope.problemreporter().illegalqualifiedparameterizedtypeallocation(this.type, this.resolvedtype);
break;
}
}
}
}
}
// will check for null after args are resolved

// resolve type arguments (for generic constructor call)
if (this.typearguments != null) {
int length = this.typearguments.length;
boolean arghaserror = scope.compileroptions().sourcelevel < classfileconstants.jdk1_5;
this.generictypearguments = new typebinding[length];
for (int i = 0; i < length; i++) {
typereference typereference = this.typearguments[i];
if ((this.generictypearguments[i] = typereference.resolvetype(scope, true /* check bounds*/)) == null) {
arghaserror = true;
}
if (arghaserror && typereference instanceof wildcard) {
scope.problemreporter().illegalusageofwildcard(typereference);
}
}
if (arghaserror) {
if (this.arguments != null) { // still attempt to resolve arguments
for (int i = 0, max = this.arguments.length; i < max; i++) {
this.arguments[i].resolvetype(scope);
}
}
return null;
}
}

// buffering the arguments' types
boolean argscontaincast = false;
typebinding[] argumenttypes = binding.no_parameters;
if (this.arguments != null) {
boolean arghaserror = false;
int length = this.arguments.length;
argumenttypes = new typebinding[length];
for (int i = 0; i < length; i++) {
expression argument = this.arguments[i];
if (argument instanceof castexpression) {
argument.bits |= disableunnecessarycastcheck; // will check later on
argscontaincast = true;
}
if ((argumenttypes[i] = argument.resolvetype(scope)) == null) {
arghaserror = true;
}
}
if (arghaserror) {
if (this.resolvedtype instanceof referencebinding) {
// record a best guess, for clients who need hint about possible contructor match
typebinding[] pseudoargs = new typebinding[length];
for (int i = length; --i >= 0;) {
pseudoargs[i] = argumenttypes[i] == null ? typebinding.null : argumenttypes[i]; // replace args with errors with null type
}
this.binding = scope.findmethod((referencebinding) this.resolvedtype, typeconstants.init, pseudoargs, this);
if (this.binding != null && !this.binding.isvalidbinding()) {
methodbinding closestmatch = ((problemmethodbinding)this.binding).closestmatch;
// record the closest match, for clients who may still need hint about possible method match
if (closestmatch != null) {
if (closestmatch.original().typevariables != binding.no_type_variables) { // generic method
// shouldn't return generic method outside its context, rather convert it to raw method (175409)
closestmatch = scope.environment().createparameterizedgenericmethod(closestmatch.original(), (rawtypebinding)null);
}
this.binding = closestmatch;
methodbinding closestmatchoriginal = closestmatch.original();
if (closestmatchoriginal.isorenclosedbyprivatetype() && !scope.isdefinedinmethod(closestmatchoriginal)) {
// ignore cases where method is used from within inside itself (e.g. direct recursions)
closestmatchoriginal.modifiers |= extracompilermodifiers.acclocallyused;
}
}
}
}
return this.resolvedtype;
}
}
if (this.resolvedtype == null || !this.resolvedtype.isvalidbinding()) {
return null;
}

// null type denotes fake allocation for enum constant inits
if (this.type != null && !this.resolvedtype.canbeinstantiated()) {
scope.problemreporter().cannotinstantiate(this.type, this.resolvedtype);
return this.resolvedtype;
}
referencebinding allocationtype = (referencebinding) this.resolvedtype;
if (!(this.binding = scope.getconstructor(allocationtype, argumenttypes, this)).isvalidbinding()) {
if (this.binding.declaringclass == null) {
this.binding.declaringclass = allocationtype;
}
if (this.type != null && !this.type.resolvedtype.isvalidbinding()) {
return null;
}
scope.problemreporter().invalidconstructor(this, this.binding);
return this.resolvedtype;
}
if ((this.binding.tagbits & tagbits.hasmissingtype) != 0) {
scope.problemreporter().missingtypeinconstructor(this, this.binding);
}
if (ismethodusedeprecated(this.binding, scope, true))
scope.problemreporter().deprecatedmethod(this.binding, this);
if (checkinvocationarguments(scope, null, allocationtype, this.binding, this.arguments, argumenttypes, argscontaincast, this)) {
this.bits |= astnode.unchecked;
}
if (this.typearguments != null && this.binding.original().typevariables == binding.no_type_variables) {
scope.problemreporter().unnecessarytypeargumentsformethodinvocation(this.binding, this.generictypearguments, this.typearguments);
}
return allocationtype;
}

public void setactualreceivertype(referencebinding receivertype) {
// ignored
}

public void setdepth(int i) {
// ignored
}

public void setfieldindex(int i) {
// ignored
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.typearguments != null) {
for (int i = 0, typeargumentslength = this.typearguments.length; i < typeargumentslength; i++) {
this.typearguments[i].traverse(visitor, scope);
}
}
if (this.type != null) { // enum constant scenario
this.type.traverse(visitor, scope);
}
if (this.arguments != null) {
for (int i = 0, argumentslength = this.arguments.length; i < argumentslength; i++)
this.arguments[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
