/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;

public class unresolvedreferencebinding extends referencebinding {

referencebinding resolvedtype;
typebinding[] wrappers;

unresolvedreferencebinding(char[][] compoundname, packagebinding packagebinding) {
this.compoundname = compoundname;
this.sourcename = compoundname[compoundname.length - 1]; // reasonable guess
this.fpackage = packagebinding;
this.wrappers = null;
}
void addwrapper(typebinding wrapper, lookupenvironment environment) {
if (this.resolvedtype != null) {
// the type reference b<b<t>.m> means a signature of <t:ljava/lang/object;>lb<lb<tt;>.m;>;
// when the parameterizedtype for unresolved b is created with args b<t>.m, the unresolved b is resolved before the wrapper is added
wrapper.swapunresolved(this, this.resolvedtype, environment);
return;
}
if (this.wrappers == null) {
this.wrappers = new typebinding[] {wrapper};
} else {
int length = this.wrappers.length;
system.arraycopy(this.wrappers, 0, this.wrappers = new typebinding[length + 1], 0, length);
this.wrappers[length] = wrapper;
}
}
public string debugname() {
return tostring();
}
referencebinding resolve(lookupenvironment environment, boolean convertgenerictorawtype) {
referencebinding targettype = this.resolvedtype;
if (targettype == null) {
targettype = this.fpackage.gettype0(this.compoundname[this.compoundname.length - 1]);
if (targettype == this) {
targettype = environment.askfortype(this.compoundname);
}
if (targettype == null || targettype == this) { // could not resolve any better, error was already reported against it
// report the missing class file first - only if not resolving a previously missing type
if ((this.tagbits & tagbits.hasmissingtype) == 0) {
environment.problemreporter.isclasspathcorrect(
this.compoundname,
environment.unitbeingcompleted,
environment.missingclassfilelocation);
}
// create a proxy for the missing binarytype
targettype = environment.createmissingtype(null, this.compoundname);
}
setresolvedtype(targettype, environment);
}
if (convertgenerictorawtype) {
targettype = (referencebinding) environment.convertunresolvedbinarytorawtype(targettype);
}
return targettype;
}
void setresolvedtype(referencebinding targettype, lookupenvironment environment) {
if (this.resolvedtype == targettype) return; // already resolved

// targettype may be a source or binary type
this.resolvedtype = targettype;
// must ensure to update any other type bindings that can contain the resolved type
// otherwise we could create 2 : 1 for this unresolved type & 1 for the resolved type
if (this.wrappers != null)
for (int i = 0, l = this.wrappers.length; i < l; i++)
this.wrappers[i].swapunresolved(this, targettype, environment);
environment.updatecaches(this, targettype);
}
public string tostring() {
return "unresolved type " + ((this.compoundname != null) ? charoperation.tostring(this.compoundname) : "unnamed"); //$non-nls-1$ //$non-nls-2$
}
}
