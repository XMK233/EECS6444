/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class implicitdoctypereference extends typereference {

public char[] token;

public implicitdoctypereference(char[] name, int pos) {
super();
this.token = name;
this.sourcestart = pos;
this.sourceend = pos;
}
/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.typereference#copydims(int)
*/
public typereference copydims(int dim) {
return null;
}
/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.typereference#gettypebinding(org.eclipse.jdt.internal.compiler.lookup.scope)
*/
protected typebinding gettypebinding(scope scope) {
this.constant = notaconstant;
return this.resolvedtype = scope.enclosingsourcetype();
}
/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.typereference#gettypename()
*/
public char[][] gettypename() {
if (this.token != null) {
char[][] tokens = { this.token };
return tokens;
}
return null;
}
public boolean isthis() {
return true;
}
/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.typereference#traverse(org.eclipse.jdt.internal.compiler.astvisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(astvisitor visitor, blockscope classscope) {
// do nothing
}
/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.typereference#traverse(org.eclipse.jdt.internal.compiler.astvisitor, org.eclipse.jdt.internal.compiler.lookup.classscope)
*/
public void traverse(astvisitor visitor, classscope classscope) {
// do nothing
}
/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.expression#printexpression(int, java.lang.stringbuffer)
*/
public stringbuffer printexpression(int indent, stringbuffer output) {
return new stringbuffer();
}
}
