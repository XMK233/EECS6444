/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

/**
* node representing a javadoc comment including code selection.
*/
public class selectionjavadoc extends javadoc {

expression selectednode;

public selectionjavadoc(int sourcestart, int sourceend) {
super(sourcestart, sourceend);
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.javadoc#print(int, java.lang.stringbuffer)
*/
public stringbuffer print(int indent, stringbuffer output) {
super.print(indent, output);
if (this.selectednode != null) {
string selectedstring = null;
if (this.selectednode instanceof javadocfieldreference) {
javadocfieldreference fieldref = (javadocfieldreference) this.selectednode;
if (fieldref.methodbinding != null) {
selectedstring = "<selectonmethod:"; //$non-nls-1$
} else {
selectedstring = "<selectonfield:"; //$non-nls-1$
}
} else if (this.selectednode instanceof javadocmessagesend) {
selectedstring = "<selectonmethod:"; //$non-nls-1$
} else if (this.selectednode instanceof javadocallocationexpression) {
selectedstring = "<selectonconstructor:"; //$non-nls-1$
} else if (this.selectednode instanceof javadocsinglenamereference) {
selectedstring = "<selectonlocalvariable:"; //$non-nls-1$
} else if (this.selectednode instanceof javadocsingletypereference) {
javadocsingletypereference typeref = (javadocsingletypereference) this.selectednode;
if (typeref.packagebinding == null) {
selectedstring = "<selectontype:"; //$non-nls-1$
}
} else if (this.selectednode instanceof javadocqualifiedtypereference) {
javadocqualifiedtypereference typeref = (javadocqualifiedtypereference) this.selectednode;
if (typeref.packagebinding == null) {
selectedstring = "<selectontype:"; //$non-nls-1$
}
} else {
selectedstring = "<selectontype:"; //$non-nls-1$
}
int pos = output.length()-3;
output.replace(pos-2,pos, selectedstring+this.selectednode+'>');
}
return output;
}

/**
* resolve selected node if not null and throw exception to let clients know
* that it has been found.
*
* @@throws selectionnodefound
*/
private void internalresolve(scope scope) {
if (this.selectednode != null) {
switch (scope.kind) {
case scope.class_scope:
this.selectednode.resolvetype((classscope)scope);
break;
case scope.method_scope:
this.selectednode.resolvetype((methodscope)scope);
break;
}
binding binding = null;
if (this.selectednode instanceof javadocfieldreference) {
javadocfieldreference fieldref = (javadocfieldreference) this.selectednode;
binding = fieldref.binding;
if (binding == null && fieldref.methodbinding != null) {
binding = fieldref.methodbinding;
}
} else if (this.selectednode instanceof javadocmessagesend) {
binding = ((javadocmessagesend) this.selectednode).binding;
} else if (this.selectednode instanceof javadocallocationexpression) {
binding = ((javadocallocationexpression) this.selectednode).binding;
} else if (this.selectednode instanceof javadocsinglenamereference) {
binding = ((javadocsinglenamereference) this.selectednode).binding;
} else if (this.selectednode instanceof javadocsingletypereference) {
javadocsingletypereference typeref = (javadocsingletypereference) this.selectednode;
if (typeref.packagebinding == null) {
binding = typeref.resolvedtype;
}
} else if (this.selectednode instanceof javadocqualifiedtypereference) {
javadocqualifiedtypereference typeref = (javadocqualifiedtypereference) this.selectednode;
if (typeref.packagebinding == null) {
binding = typeref.resolvedtype;
}
} else {
binding = this.selectednode.resolvedtype;
}
throw new selectionnodefound(binding);
}
}

/**
* resolve selected node if not null and throw exception to let clients know
* that it has been found.
*
* @@throws selectionnodefound
*/
public void resolve(classscope scope) {
internalresolve(scope);
}

/**
* resolve selected node if not null and throw exception to let clients know
* that it has been found.
*
* @@throws selectionnodefound
*/
public void resolve(methodscope scope) {
internalresolve(scope);
}

}
