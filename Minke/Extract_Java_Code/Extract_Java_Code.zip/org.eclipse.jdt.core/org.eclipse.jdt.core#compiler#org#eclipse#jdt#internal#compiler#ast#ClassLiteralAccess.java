/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class classliteralaccess extends expression {

public typereference type;
public typebinding targettype;
fieldbinding syntheticfield;

public classliteralaccess(int sourceend, typereference type) {
this.type = type;
type.bits |= ignorerawtypecheck; // no need to worry about raw type usage
this.sourcestart = type.sourcestart;
this.sourceend = sourceend;
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {

// if reachable, request the addition of a synthetic field for caching the class descriptor
sourcetypebinding sourcetype = currentscope.outermostclassscope().enclosingsourcetype();
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=22334
if (!sourcetype.isinterface()
&& !this.targettype.isbasetype()
&& currentscope.compileroptions().sourcelevel < classfileconstants.jdk1_5) {
this.syntheticfield = sourcetype.addsyntheticfieldforclassliteral(this.targettype, currentscope);
}
return flowinfo;
}

/**
* messagesenddotclass code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(
blockscope currentscope,
codestream codestream,
boolean valuerequired) {
int pc = codestream.position;

// in interface case, no caching occurs, since cannot make a cache field for interface
if (valuerequired) {
codestream.generateclassliteralaccessfortype(this.type.resolvedtype, this.syntheticfield);
codestream.generateimplicitconversion(this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public stringbuffer printexpression(int indent, stringbuffer output) {

return this.type.print(0, output).append(".class"); //$non-nls-1$
}

public typebinding resolvetype(blockscope scope) {

this.constant = constant.notaconstant;
if ((this.targettype = this.type.resolvetype(scope, true /* check bounds*/)) == null)
return null;

if (this.targettype.isarraytype()) {
arraybinding arraybinding = (arraybinding) this.targettype;
typebinding leafcomponenttype = arraybinding.leafcomponenttype;
if (leafcomponenttype == typebinding.void) {
scope.problemreporter().cannotallocatevoidarray(this);
return null;
} else if (leafcomponenttype.istypevariable()) {
scope.problemreporter().illegalclassliteralfortypevariable((typevariablebinding)leafcomponenttype, this);
}
} else if (this.targettype.istypevariable()) {
scope.problemreporter().illegalclassliteralfortypevariable((typevariablebinding)this.targettype, this);
}
referencebinding classtype = scope.getjavalangclass();
if (classtype.isgenerictype()) {
// integer.class --> class<integer>, perform boxing of base types (int.class --> class<integer>)
typebinding boxedtype = null;
if (this.targettype.id == t_void) {
boxedtype = scope.environment().getresolvedtype(java_lang_void, scope);
} else {
boxedtype = scope.boxing(this.targettype);
}
this.resolvedtype = scope.environment().createparameterizedtype(classtype, new typebinding[]{ boxedtype }, null/*not a member*/);
} else {
this.resolvedtype = classtype;
}
return this.resolvedtype;
}

public void traverse(
astvisitor visitor,
blockscope blockscope) {

if (visitor.visit(this, blockscope)) {
this.type.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}
}
