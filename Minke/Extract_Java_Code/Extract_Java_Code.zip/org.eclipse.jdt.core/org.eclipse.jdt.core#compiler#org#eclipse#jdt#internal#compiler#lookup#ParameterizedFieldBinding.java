/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.constant;

/**
* binding denoting a field after type substitution got performed.
* on parameterized type bindings, all fields got substituted, regardless whether
* their signature did involve generics or not, so as to get the proper declaringclass for
* these fields.
*/
public class parameterizedfieldbinding extends fieldbinding {

public fieldbinding originalfield;

public parameterizedfieldbinding(parameterizedtypebinding parameterizeddeclaringclass, fieldbinding originalfield) {
super (
originalfield.name,
(originalfield.modifiers & classfileconstants.accenum) != 0
? parameterizeddeclaringclass // enum constant get paramtype as its type
: (originalfield.modifiers & classfileconstants.accstatic) != 0
? originalfield.type // no subst for static field
: scope.substitute(parameterizeddeclaringclass, originalfield.type),
originalfield.modifiers,
parameterizeddeclaringclass,
null);
this.originalfield = originalfield;
this.tagbits = originalfield.tagbits;
this.id = originalfield.id;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.variablebinding#constant()
*/
public constant constant() {
return this.originalfield.constant();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.fieldbinding#original()
*/
public fieldbinding original() {
return this.originalfield.original();
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.variablebinding#constant()
*/
public void setconstant(constant constant) {
this.originalfield.setconstant(constant);
}
}
