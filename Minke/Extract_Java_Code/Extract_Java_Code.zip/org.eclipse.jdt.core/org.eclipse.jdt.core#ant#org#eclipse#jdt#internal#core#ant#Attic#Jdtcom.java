package org.eclipse.jdt.internal.core.ant;

/*
* (c) copyright ibm corp. 2000, 2001.
* all rights reserved.
*/

import java.util.*;
import java.io.*;

import org.apache.tools.ant.*;
import org.apache.tools.ant.taskdefs.*;
import org.apache.tools.ant.types.*;
import org.eclipse.jdt.internal.compiler.batch.main;
import org.eclipse.jdt.internal.core.ant.*;

public class jdtcom extends matchingtask {
private path src;
private path classpath;
private file dest;

private stringbuffer arguments;

public jdtcom(){
arguments = new stringbuffer();
}

public void execute() throws buildexception {
if(src == null)
throw new buildexception(util.bind("jdtcom.source")); //$non-nls-1$
if(dest == null)
throw new buildexception(util.bind("jdtcom.destination")); //$non-nls-1$

arguments.append(" -d "); //$non-nls-1$
arguments.append(dest.getabsolutepath());

if(classpath != null){
arguments.append(" -classpath "); //$non-nls-1$
string[] classpathlist = classpath.list();
for(int i = 0 ; i < classpathlist.length ; i++){
file pathelement = project.resolvefile(classpathlist[i]);
if(!pathelement.exists())
throw new buildexception(util.bind("jdtcom.classpath",pathelement.getabsolutepath())); //$non-nls-1$
if(i != 0)
arguments.append(";"); //$non-nls-1$
arguments.append(pathelement);
}
}

string[] srclist = src.list();
for(int i = 0 ; i < srclist.length ; i++){
file file = project.resolvefile(srclist[i]);
if(!file.exists())
throw new buildexception(util.bind("jdtcom.sourcepath",file.getabsolutepath())); //$non-nls-1$
if(!file.isdirectory())
throw new buildexception(util.bind("jdtcom.sourcedir",file.getabsolutepath())); //$non-nls-1$
directoryscanner ds = getdirectoryscanner(file);
string[] files = ds.getincludedfiles();
for(int j =  0; j < files.length ; j++){
if(files[j].endswith(".java")){ //$non-nls-1$
arguments.append(" "); //$non-nls-1$
arguments.append(new file(file,files[j]).getabsolutepath());
}
}
}

try {
main.compile(arguments.tostring(),new antprintwriter(this));
}
catch(exception e){
throw new buildexception("jdtcom",e); //$non-nls-1$
}
log("finish"); //$non-nls-1$
}

public void setproceedonerror(boolean proceed){
if(proceed)
arguments.append(" -proceedonerror"); //$non-nls-1$
}

public void settime(boolean time){
if(time)
arguments.append(" -time"); //$non-nls-1$
}

public void setversion(boolean version){
if(version)
arguments.append(" -version"); //$non-nls-1$
}

public void setnoimporterror(boolean noimporterror){
if(noimporterror)
arguments.append(" -noimporterror"); //$non-nls-1$
}

public void setverbose(boolean verbose){
if(verbose)
arguments.append(" -verbose"); //$non-nls-1$
}

public void setpreservealllocals(boolean preservealllocals){
if(preservealllocals)
arguments.append(" -preservealllocals"); //$non-nls-1$
}

public void settarget(string target){
if (!target.equals("1.1") && !target.equals("1.2")) //$non-nls-2$ //$non-nls-1$
throw new buildexception(util.bind("jdtcom.target")); //$non-nls-1$
arguments.append(" -target "); //$non-nls-1$
arguments.append(target);
}

public void setlog(file log){
try {
new printwriter(new fileoutputstream(log.getabsolutepath(), false));
} catch(ioexception e){
throw new buildexception(util.bind("jdtcom.log",log.getabsolutepath())); //$non-nls-1$
}
arguments.append(" -log "); //$non-nls-1$
arguments.append(log.getabsolutepath());
}

public void setrepeat(int repeat){
if(repeat < 0)
throw new buildexception(util.bind("jdtcom.repeat")); //$non-nls-1$
arguments.append(" -repeat "); //$non-nls-1$
arguments.append(string.valueof(repeat));
}

public void setwarning(string warning){
if(warning.equals("no")){ //$non-nls-1$
arguments.append(" -nowarn"); //$non-nls-1$
}
else{
stringtokenizer tokenizer = new stringtokenizer(warning, ",");			 //$non-nls-1$
while (tokenizer.hasmoretokens()) {
string token = tokenizer.nexttoken();
if (!token.equals("constructorname") && //$non-nls-1$
!token.equals("packagedefaultmethod") && //$non-nls-1$
!token.equals("maskedcatchblocks") && //$non-nls-1$
!token.equals("deprecation") && //$non-nls-1$
!token.equals("unusedlocals") && //$non-nls-1$
!token.equals("unusedarguments") && //$non-nls-1$
!token.equals("syntheticaccess") && //$non-nls-1$
!token.equals("nls")) //$non-nls-1$
throw new buildexception(util.bind("jdtcom.warning")); //$non-nls-1$
}
arguments.append(" -warn:"+warning); //$non-nls-1$
}
}

public void setdebug(string debug){
if(debug.equals("no")){ //$non-nls-1$
arguments.append(" -g:none"); //$non-nls-1$
}
else if (debug.equals("all")){ //$non-nls-1$
arguments.append(" -g"); //$non-nls-1$
}
else{
stringtokenizer tokenizer = new stringtokenizer(debug, ","); //$non-nls-1$
while (tokenizer.hasmoretokens()) {
string token = tokenizer.nexttoken();
if (!token.equals("vars") && !token.equals("lines") && !token.equals("source")) //$non-nls-1$ //$non-nls-3$ //$non-nls-2$
throw new buildexception(util.bind("jdtcom.debug")); //$non-nls-1$
}
arguments.append(" -g:"+debug); //$non-nls-1$
}
}

public void setdestdir(file dest){
this.dest = dest;
}

public void setclasspath(path path){
if (classpath == null) {
classpath = path;
}
classpath.append(path);
}

public path createclasspath() {
if (classpath == null) {
classpath = new path(project);
}
return classpath.createpath();
}

public void setsrcdir(path path){
if (src == null) {
src = path;
}
src.append(path);
}

public path createsrc() {
if (src == null) {
src = new path(project);
}
return src.createpath();
}
}

