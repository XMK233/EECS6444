/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class ifstatement extends statement {

//this class represents the case of only one statement in
//either else and/or then branches.

public expression condition;
public statement thenstatement;
public statement elsestatement;

// for local variables table attributes
int theninitstateindex = -1;
int elseinitstateindex = -1;
int mergedinitstateindex = -1;

public ifstatement(expression condition, statement thenstatement, int sourcestart, int sourceend) {
this.condition = condition;
this.thenstatement = thenstatement;
// remember useful empty statement
if (thenstatement instanceof emptystatement) thenstatement.bits |= isusefulemptystatement;
this.sourcestart = sourcestart;
this.sourceend = sourceend;
}

public ifstatement(expression condition, statement thenstatement, statement elsestatement, int sourcestart, int sourceend) {
this.condition = condition;
this.thenstatement = thenstatement;
// remember useful empty statement
if (thenstatement instanceof emptystatement) thenstatement.bits |= isusefulemptystatement;
this.elsestatement = elsestatement;
if (elsestatement instanceof ifstatement) elsestatement.bits |= iselseifstatement;
if (elsestatement instanceof emptystatement) elsestatement.bits |= isusefulemptystatement;
this.sourcestart = sourcestart;
this.sourceend = sourceend;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
// process the condition
flowinfo conditionflowinfo = this.condition.analysecode(currentscope, flowcontext, flowinfo);
int initialcomplaintlevel = (flowinfo.reachmode() & flowinfo.unreachable) != 0 ? statement.complained_fake_reachable : statement.not_complained;

constant cst = this.condition.optimizedbooleanconstant();
boolean isconditionoptimizedtrue = cst != constant.notaconstant && cst.booleanvalue() == true;
boolean isconditionoptimizedfalse = cst != constant.notaconstant && cst.booleanvalue() == false;

// process the then part
flowinfo thenflowinfo = conditionflowinfo.safeinitswhentrue();
if (isconditionoptimizedfalse) {
thenflowinfo.setreachmode(flowinfo.unreachable);
}
flowinfo elseflowinfo = conditionflowinfo.initswhenfalse();
if (isconditionoptimizedtrue) {
elseflowinfo.setreachmode(flowinfo.unreachable);
}
if (((flowinfo.tagbits & flowinfo.unreachable) == 0) &&
((thenflowinfo.tagbits & flowinfo.unreachable) != 0)) {
// mark then block as unreachable
// no need if the whole if-else construct itself lies in unreachable code
this.bits |= astnode.isthenstatementunreachable;
} else if (((flowinfo.tagbits & flowinfo.unreachable) == 0) &&
((elseflowinfo.tagbits & flowinfo.unreachable) != 0)) {
// mark else block as unreachable
// no need if the whole if-else construct itself lies in unreachable code
this.bits |= astnode.iselsestatementunreachable;
}
if (this.thenstatement != null) {
// save info for code gen
this.theninitstateindex = currentscope.methodscope().recordinitializationstates(thenflowinfo);
if (isconditionoptimizedfalse || ((this.bits & astnode.isthenstatementunreachable) != 0)) {
if (!isknowdeadcodepattern(this.condition) || currentscope.compileroptions().reportdeadcodeintrivialifstatement) {
this.thenstatement.complainifunreachable(thenflowinfo, currentscope, initialcomplaintlevel);
} else {
// its a known coding pattern which should be tolerated by dead code analysis
// according to isknowdeadcodepattern()
this.bits &= ~astnode.isthenstatementunreachable;
}
}
thenflowinfo = this.thenstatement.analysecode(currentscope, flowcontext, thenflowinfo);
}
// code gen: optimizing the jump around the else part
if ((thenflowinfo.tagbits & flowinfo.unreachable) != 0) {
this.bits |= astnode.thenexit;
}

// process the else part
if (this.elsestatement != null) {
// signal else clause unnecessarily nested, tolerate else-if code pattern
if (thenflowinfo == flowinfo.dead_end
&& (this.bits & iselseifstatement) == 0 	// else of an else-if
&& !(this.elsestatement instanceof ifstatement)) {
currentscope.problemreporter().unnecessaryelse(this.elsestatement);
}
// save info for code gen
this.elseinitstateindex = currentscope.methodscope().recordinitializationstates(elseflowinfo);
if (isconditionoptimizedtrue || ((this.bits & astnode.iselsestatementunreachable) != 0)) {
if (!isknowdeadcodepattern(this.condition) || currentscope.compileroptions().reportdeadcodeintrivialifstatement) {
this.elsestatement.complainifunreachable(elseflowinfo, currentscope, initialcomplaintlevel);
} else {
// its a known coding pattern which should be tolerated by dead code analysis
// according to isknowdeadcodepattern()
this.bits &= ~astnode.iselsestatementunreachable;
}
}
elseflowinfo = this.elsestatement.analysecode(currentscope, flowcontext, elseflowinfo);
}
// merge then & else initializations
flowinfo mergedinfo = flowinfo.mergedoptimizedbranchesifelse(
thenflowinfo,
isconditionoptimizedtrue,
elseflowinfo,
isconditionoptimizedfalse,
true /*if(true){ return; }  fake-reachable(); */,
flowinfo);
this.mergedinitstateindex = currentscope.methodscope().recordinitializationstates(mergedinfo);
return mergedinfo;
}

/**
* if code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & isreachable) == 0) {
return;
}
int pc = codestream.position;
branchlabel endiflabel = new branchlabel(codestream);

// optimizing the then/else part code gen
constant cst;
boolean hasthenpart =
!(((cst = this.condition.optimizedbooleanconstant()) != constant.notaconstant
&& cst.booleanvalue() == false)
|| this.thenstatement == null
|| this.thenstatement.isemptyblock());
boolean haselsepart =
!((cst != constant.notaconstant && cst.booleanvalue() == true)
|| this.elsestatement == null
|| this.elsestatement.isemptyblock());
if (hasthenpart) {
branchlabel falselabel = null;
// generate boolean condition only if needed
if (((this.bits & astnode.iselsestatementunreachable) != 0) ||
(cst != constant.notaconstant && cst.booleanvalue() == true)) {
// no need to generate if condition statement when we know that only the then action
// will be executed
this.condition.generatecode(currentscope, codestream, false);
} else {
this.condition.generateoptimizedboolean(
currentscope,
codestream,
null,
haselsepart ? (falselabel = new branchlabel(codestream)) : endiflabel,
true/*cst == constant.notaconstant*/);
}
// may loose some local variable initializations : affecting the local variable attributes
if (this.theninitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.theninitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.theninitstateindex);
}
// generate then statement
this.thenstatement.generatecode(currentscope, codestream);
// jump around the else statement
if (haselsepart) {
if ((this.bits & astnode.thenexit) == 0) {
this.thenstatement.branchchainto(endiflabel);
int position = codestream.position;
codestream.goto_(endiflabel);
//goto is tagged as part of the thenaction block
codestream.updatelastrecordedendpc((this.thenstatement instanceof block) ? ((block) this.thenstatement).scope : currentscope, position);
// generate else statement
}
// may loose some local variable initializations : affecting the local variable attributes
if (this.elseinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(
currentscope,
this.elseinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.elseinitstateindex);
}
if (falselabel != null) falselabel.place();
this.elsestatement.generatecode(currentscope, codestream);
}
} else if (haselsepart) {
// generate boolean condition only if needed
if (((this.bits & astnode.isthenstatementunreachable) != 0) ||
(cst != constant.notaconstant && cst.booleanvalue() == false)) {
// no need to generate if condition statement when we know that only the else action
// will be executed
this.condition.generatecode(currentscope, codestream, false);
} else {
this.condition.generateoptimizedboolean(
currentscope,
codestream,
endiflabel,
null,
true/*cst == constant.notaconstant*/);
}
// generate else statement
// may loose some local variable initializations : affecting the local variable attributes
if (this.elseinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(
currentscope,
this.elseinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.elseinitstateindex);
}
this.elsestatement.generatecode(currentscope, codestream);
} else {
// generate condition side-effects
this.condition.generatecode(currentscope, codestream, false);
codestream.recordpositionsfrom(pc, this.sourcestart);
}
// may loose some local variable initializations : affecting the local variable attributes
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(
currentscope,
this.mergedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
endiflabel.place();
codestream.recordpositionsfrom(pc, this.sourcestart);
}



public stringbuffer printstatement(int indent, stringbuffer output) {
printindent(indent, output).append("if ("); //$non-nls-1$
this.condition.printexpression(0, output).append(")\n");	//$non-nls-1$
this.thenstatement.printstatement(indent + 2, output);
if (this.elsestatement != null) {
output.append('\n');
printindent(indent, output);
output.append("else\n"); //$non-nls-1$
this.elsestatement.printstatement(indent + 2, output);
}
return output;
}

public void resolve(blockscope scope) {
typebinding type = this.condition.resolvetypeexpecting(scope, typebinding.boolean);
this.condition.computeconversion(scope, type, type);
if (this.thenstatement != null)
this.thenstatement.resolve(scope);
if (this.elsestatement != null)
this.elsestatement.resolve(scope);
}

public void traverse(astvisitor visitor, blockscope blockscope) {
if (visitor.visit(this, blockscope)) {
this.condition.traverse(visitor, blockscope);
if (this.thenstatement != null)
this.thenstatement.traverse(visitor, blockscope);
if (this.elsestatement != null)
this.elsestatement.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}
}
