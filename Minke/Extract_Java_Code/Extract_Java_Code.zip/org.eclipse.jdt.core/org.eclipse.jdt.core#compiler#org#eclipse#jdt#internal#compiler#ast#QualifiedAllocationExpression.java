/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.codegen.opcodes;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.extracompilermodifiers;
import org.eclipse.jdt.internal.compiler.lookup.localtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.problemmethodbinding;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.problemreferencebinding;
import org.eclipse.jdt.internal.compiler.lookup.rawtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeconstants;
import org.eclipse.jdt.internal.compiler.lookup.typeids;

/**
* variation on allocation, where can optionally be specified any of:
* - leading enclosing instance
* - trailing anonymous type
* - generic type arguments for generic constructor invocation
*/
public class qualifiedallocationexpression extends allocationexpression {

//qualification may be on both side
public expression enclosinginstance;
public typedeclaration anonymoustype;

public qualifiedallocationexpression() {
// for subtypes
}

public qualifiedallocationexpression(typedeclaration anonymoustype) {
this.anonymoustype = anonymoustype;
anonymoustype.allocation = this;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
// analyse the enclosing instance
if (this.enclosinginstance != null) {
flowinfo = this.enclosinginstance.analysecode(currentscope, flowcontext, flowinfo);
}

// check captured variables are initialized in current context (26134)
checkcapturedlocalinitializationifnecessary(
(referencebinding)(this.anonymoustype == null
? this.binding.declaringclass.erasure()
: this.binding.declaringclass.superclass().erasure()),
currentscope,
flowinfo);

// process arguments
if (this.arguments != null) {
for (int i = 0, count = this.arguments.length; i < count; i++) {
flowinfo = this.arguments[i].analysecode(currentscope, flowcontext, flowinfo);
}
}

// analyse the anonymous nested type
if (this.anonymoustype != null) {
flowinfo = this.anonymoustype.analysecode(currentscope, flowcontext, flowinfo);
}

// record some dependency information for exception types
referencebinding[] thrownexceptions;
if (((thrownexceptions = this.binding.thrownexceptions).length) != 0) {
if ((this.bits & astnode.unchecked) != 0 && this.generictypearguments == null) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=277643, align with javac on jls 15.12.2.6
thrownexceptions = currentscope.environment().converttorawtypes(this.binding.thrownexceptions, true, true);
}
// check exception handling
flowcontext.checkexceptionhandlers(
thrownexceptions,
this,
flowinfo.unconditionalcopy(),
currentscope);
}
manageenclosinginstanceaccessifnecessary(currentscope, flowinfo);
managesyntheticaccessifnecessary(currentscope, flowinfo);
return flowinfo;
}

public expression enclosinginstance() {

return this.enclosinginstance;
}

public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
if (!valuerequired)
currentscope.problemreporter().unusedobjectallocation(this);
int pc = codestream.position;
methodbinding codegenbinding = this.binding.original();
referencebinding allocatedtype = codegenbinding.declaringclass;
codestream.new_(allocatedtype);
boolean isunboxing = (this.implicitconversion & typeids.unboxing) != 0;
if (valuerequired || isunboxing) {
codestream.dup();
}
// better highlight for allocation: display the type individually
if (this.type != null) { // null for enum constant body
codestream.recordpositionsfrom(pc, this.type.sourcestart);
} else {
// push enum constant name and ordinal
codestream.ldc(string.valueof(this.enumconstant.name));
codestream.generateinlinedvalue(this.enumconstant.binding.id);
}
// handling innerclass instance allocation - enclosing instance arguments
if (allocatedtype.isnestedtype()) {
codestream.generatesyntheticenclosinginstancevalues(
currentscope,
allocatedtype,
enclosinginstance(),
this);
}
// generate the arguments for constructor
generatearguments(this.binding, this.arguments, currentscope, codestream);
// handling innerclass instance allocation - outer local arguments
if (allocatedtype.isnestedtype()) {
codestream.generatesyntheticouterargumentvalues(
currentscope,
allocatedtype,
this);
}

// invoke constructor
if (this.syntheticaccessor == null) {
codestream.invoke(opcodes.opc_invokespecial, codegenbinding, null /* default declaringclass */);
} else {
// synthetic accessor got some extra arguments appended to its signature, which need values
for (int i = 0,
max = this.syntheticaccessor.parameters.length - codegenbinding.parameters.length;
i < max;
i++) {
codestream.aconst_null();
}
codestream.invoke(opcodes.opc_invokespecial, this.syntheticaccessor, null /* default declaringclass */);
}
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else if (isunboxing) {
// conversion only generated if unboxing
codestream.generateimplicitconversion(this.implicitconversion);
switch (postconversiontype(currentscope).id) {
case t_long :
case t_double :
codestream.pop2();
break;
default :
codestream.pop();
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);

if (this.anonymoustype != null) {
this.anonymoustype.generatecode(currentscope, codestream);
}
}

public boolean issuperaccess() {

// necessary to lookup super constructor of anonymous type
return this.anonymoustype != null;
}

/* inner emulation consists in either recording a dependency
* link only, or performing one level of propagation.
*
* dependency mechanism is used whenever dealing with source target
* types, since by the time we reach them, we might not yet know their
* exact need.
*/
public void manageenclosinginstanceaccessifnecessary(blockscope currentscope, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0)	{
referencebinding allocatedtypeerasure = (referencebinding) this.binding.declaringclass.erasure();

// perform some extra emulation work in case there is some and we are inside a local type only
if (allocatedtypeerasure.isnestedtype()
&& currentscope.enclosingsourcetype().islocaltype()) {

if (allocatedtypeerasure.islocaltype()) {
((localtypebinding) allocatedtypeerasure).addinneremulationdependent(currentscope, this.enclosinginstance != null);
} else {
// locally propagate, since we already now the desired shape for sure
currentscope.propagateinneremulation(allocatedtypeerasure, this.enclosinginstance != null);
}
}
}
}

public stringbuffer printexpression(int indent, stringbuffer output) {
if (this.enclosinginstance != null)
this.enclosinginstance.printexpression(0, output).append('.');
super.printexpression(0, output);
if (this.anonymoustype != null) {
this.anonymoustype.print(indent, output);
}
return output;
}

public typebinding resolvetype(blockscope scope) {
// added for code assist...cannot occur with 'normal' code
if (this.anonymoustype == null && this.enclosinginstance == null) {
return super.resolvetype(scope);
}

// propagate the type checking to the arguments, and checks if the constructor is defined.
// classinstancecreationexpression ::= primary '.' 'new' simplename '(' argumentlistopt ')' classbodyopt
// classinstancecreationexpression ::= name '.' 'new' simplename '(' argumentlistopt ')' classbodyopt

this.constant = constant.notaconstant;
typebinding enclosinginstancetype = null;
typebinding receivertype = null;
boolean haserror = false;
boolean enclosinginstancecontainscast = false;
boolean argscontaincast = false;

if (this.enclosinginstance != null) {
if (this.enclosinginstance instanceof castexpression) {
this.enclosinginstance.bits |= astnode.disableunnecessarycastcheck; // will check later on
enclosinginstancecontainscast = true;
}
if ((enclosinginstancetype = this.enclosinginstance.resolvetype(scope)) == null){
haserror = true;
} else if (enclosinginstancetype.isbasetype() || enclosinginstancetype.isarraytype()) {
scope.problemreporter().illegalprimitiveorarraytypeforenclosinginstance(
enclosinginstancetype,
this.enclosinginstance);
haserror = true;
} else if (this.type instanceof qualifiedtypereference) {
scope.problemreporter().illegalusageofqualifiedtypereference((qualifiedtypereference)this.type);
haserror = true;
} else {
receivertype = ((singletypereference) this.type).resolvetypeenclosing(scope, (referencebinding) enclosinginstancetype);
if (receivertype != null && enclosinginstancecontainscast) {
castexpression.checkneedforenclosinginstancecast(scope, this.enclosinginstance, enclosinginstancetype, receivertype);
}
}
} else {
if (this.type == null) {
// initialization of an enum constant
receivertype = scope.enclosingsourcetype();
} else {
receivertype = this.type.resolvetype(scope, true /* check bounds*/);
checkparameterizedallocation: {
if (receivertype == null || !receivertype.isvalidbinding()) break checkparameterizedallocation;
if (this.type instanceof parameterizedqualifiedtypereference) { // disallow new x<string>.y<integer>()
referencebinding currenttype = (referencebinding)receivertype;
do {
// isstatic() is answering true for toplevel types
if ((currenttype.modifiers & classfileconstants.accstatic) != 0) break checkparameterizedallocation;
if (currenttype.israwtype()) break checkparameterizedallocation;
} while ((currenttype = currenttype.enclosingtype())!= null);
parameterizedqualifiedtypereference qref = (parameterizedqualifiedtypereference) this.type;
for (int i = qref.typearguments.length - 2; i >= 0; i--) {
if (qref.typearguments[i] != null) {
scope.problemreporter().illegalqualifiedparameterizedtypeallocation(this.type, receivertype);
break;
}
}
}
}
}
}
if (receivertype == null || !receivertype.isvalidbinding()) {
haserror = true;
}

// resolve type arguments (for generic constructor call)
if (this.typearguments != null) {
int length = this.typearguments.length;
boolean arghaserror = scope.compileroptions().sourcelevel < classfileconstants.jdk1_5;
this.generictypearguments = new typebinding[length];
for (int i = 0; i < length; i++) {
typereference typereference = this.typearguments[i];
if ((this.generictypearguments[i] = typereference.resolvetype(scope, true /* check bounds*/)) == null) {
arghaserror = true;
}
if (arghaserror && typereference instanceof wildcard) {
scope.problemreporter().illegalusageofwildcard(typereference);
}
}
if (arghaserror) {
if (this.arguments != null) { // still attempt to resolve arguments
for (int i = 0, max = this.arguments.length; i < max; i++) {
this.arguments[i].resolvetype(scope);
}
}
return null;
}
}

// will check for null after args are resolved
typebinding[] argumenttypes = binding.no_parameters;
if (this.arguments != null) {
int length = this.arguments.length;
argumenttypes = new typebinding[length];
for (int i = 0; i < length; i++) {
expression argument = this.arguments[i];
if (argument instanceof castexpression) {
argument.bits |= astnode.disableunnecessarycastcheck; // will check later on
argscontaincast = true;
}
if ((argumenttypes[i] = argument.resolvetype(scope)) == null){
haserror = true;
}
}
}

// limit of fault-tolerance
if (haserror) {
if (receivertype instanceof referencebinding) {
referencebinding referencereceiver = (referencebinding) receivertype;
if (receivertype.isvalidbinding()) {
// record a best guess, for clients who need hint about possible contructor match
int length = this.arguments  == null ? 0 : this.arguments.length;
typebinding[] pseudoargs = new typebinding[length];
for (int i = length; --i >= 0;) {
pseudoargs[i] = argumenttypes[i] == null ? typebinding.null : argumenttypes[i]; // replace args with errors with null type
}
this.binding = scope.findmethod(referencereceiver, typeconstants.init, pseudoargs, this);
if (this.binding != null && !this.binding.isvalidbinding()) {
methodbinding closestmatch = ((problemmethodbinding)this.binding).closestmatch;
// record the closest match, for clients who may still need hint about possible method match
if (closestmatch != null) {
if (closestmatch.original().typevariables != binding.no_type_variables) { // generic method
// shouldn't return generic method outside its context, rather convert it to raw method (175409)
closestmatch = scope.environment().createparameterizedgenericmethod(closestmatch.original(), (rawtypebinding)null);
}
this.binding = closestmatch;
methodbinding closestmatchoriginal = closestmatch.original();
if (closestmatchoriginal.isorenclosedbyprivatetype() && !scope.isdefinedinmethod(closestmatchoriginal)) {
// ignore cases where method is used from within inside itself (e.g. direct recursions)
closestmatchoriginal.modifiers |= extracompilermodifiers.acclocallyused;
}
}
}
}
if (this.anonymoustype != null) {
// insert anonymous type in scope (see https://bugs.eclipse.org/bugs/show_bug.cgi?id=210070)
scope.addanonymoustype(this.anonymoustype, referencereceiver);
this.anonymoustype.resolve(scope);
return this.resolvedtype = this.anonymoustype.binding;
}
}
return this.resolvedtype = receivertype;
}
if (this.anonymoustype == null) {
// qualified allocation with no anonymous type
if (!receivertype.canbeinstantiated()) {
scope.problemreporter().cannotinstantiate(this.type, receivertype);
return this.resolvedtype = receivertype;
}
referencebinding allocationtype = (referencebinding) receivertype;
if ((this.binding = scope.getconstructor(allocationtype, argumenttypes, this)).isvalidbinding()) {
if (ismethodusedeprecated(this.binding, scope, true)) {
scope.problemreporter().deprecatedmethod(this.binding, this);
}
if (checkinvocationarguments(scope, null, allocationtype, this.binding, this.arguments, argumenttypes, argscontaincast, this)) {
this.bits |= astnode.unchecked;
}
if (this.typearguments != null && this.binding.original().typevariables == binding.no_type_variables) {
scope.problemreporter().unnecessarytypeargumentsformethodinvocation(this.binding, this.generictypearguments, this.typearguments);
}
} else {
if (this.binding.declaringclass == null) {
this.binding.declaringclass = allocationtype;
}
if (this.type != null && !this.type.resolvedtype.isvalidbinding()) {
// problem already got signaled on type reference, do not report secondary problem
return null;
}
scope.problemreporter().invalidconstructor(this, this.binding);
return this.resolvedtype = receivertype;
}
if ((this.binding.tagbits & tagbits.hasmissingtype) != 0) {
scope.problemreporter().missingtypeinconstructor(this, this.binding);
}
// the enclosing instance must be compatible with the innermost enclosing type
referencebinding expectedtype = this.binding.declaringclass.enclosingtype();
if (expectedtype != enclosinginstancetype) // must call before computeconversion() and typemismatcherror()
scope.compilationunitscope().recordtypeconversion(expectedtype, enclosinginstancetype);
if (enclosinginstancetype.iscompatiblewith(expectedtype) || scope.isboxingcompatiblewith(enclosinginstancetype, expectedtype)) {
this.enclosinginstance.computeconversion(scope, expectedtype, enclosinginstancetype);
return this.resolvedtype = receivertype;
}
scope.problemreporter().typemismatcherror(enclosinginstancetype, expectedtype, this.enclosinginstance, null);
return this.resolvedtype = receivertype;
}
referencebinding supertype = (referencebinding) receivertype;
if (supertype.istypevariable()) {
supertype = new problemreferencebinding(new char[][]{supertype.sourcename()}, supertype, problemreasons.illegalsupertypevariable);
scope.problemreporter().invalidtype(this, supertype);
return null;
} else if (this.type != null && supertype.isenum()) { // tolerate enum constant body
scope.problemreporter().cannotinstantiate(this.type, supertype);
return this.resolvedtype = supertype;
}
// anonymous type scenario
// an anonymous class inherits from java.lang.object when declared "after" an interface
referencebinding anonymoussuperclass = supertype.isinterface() ? scope.getjavalangobject() : supertype;
// insert anonymous type in scope
scope.addanonymoustype(this.anonymoustype, supertype);
this.anonymoustype.resolve(scope);

// find anonymous super constructor
this.resolvedtype = this.anonymoustype.binding; // 1.2 change
if ((this.resolvedtype.tagbits & tagbits.hierarchyhasproblems) != 0) {
return null; // stop secondary errors
}
methodbinding inheritedbinding = scope.getconstructor(anonymoussuperclass, argumenttypes, this);
if (!inheritedbinding.isvalidbinding()) {
if (inheritedbinding.declaringclass == null) {
inheritedbinding.declaringclass = anonymoussuperclass;
}
if (this.type != null && !this.type.resolvedtype.isvalidbinding()) {
// problem already got signaled on type reference, do not report secondary problem
return null;
}
scope.problemreporter().invalidconstructor(this, inheritedbinding);
return this.resolvedtype;
}
if ((inheritedbinding.tagbits & tagbits.hasmissingtype) != 0) {
scope.problemreporter().missingtypeinconstructor(this, inheritedbinding);
}
if (this.enclosinginstance != null) {
referencebinding targetenclosing = inheritedbinding.declaringclass.enclosingtype();
if (targetenclosing == null) {
scope.problemreporter().unnecessaryenclosinginstancespecification(this.enclosinginstance, supertype);
return this.resolvedtype;
} else if (!enclosinginstancetype.iscompatiblewith(targetenclosing) && !scope.isboxingcompatiblewith(enclosinginstancetype, targetenclosing)) {
scope.problemreporter().typemismatcherror(enclosinginstancetype, targetenclosing, this.enclosinginstance, null);
return this.resolvedtype;
}
this.enclosinginstance.computeconversion(scope, targetenclosing, enclosinginstancetype);
}
if (this.arguments != null) {
if (checkinvocationarguments(scope, null, anonymoussuperclass, inheritedbinding, this.arguments, argumenttypes, argscontaincast, this)) {
this.bits |= astnode.unchecked;
}
}
if (this.typearguments != null && inheritedbinding.original().typevariables == binding.no_type_variables) {
scope.problemreporter().unnecessarytypeargumentsformethodinvocation(inheritedbinding, this.generictypearguments, this.typearguments);
}
// update the anonymous inner class : superclass, interface
this.binding = this.anonymoustype.createdefaultconstructorwithbinding(inheritedbinding, 	(this.bits & astnode.unchecked) != 0 && this.generictypearguments == null);
return this.resolvedtype;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.enclosinginstance != null)
this.enclosinginstance.traverse(visitor, scope);
if (this.typearguments != null) {
for (int i = 0, typeargumentslength = this.typearguments.length; i < typeargumentslength; i++) {
this.typearguments[i].traverse(visitor, scope);
}
}
if (this.type != null) // case of enum constant
this.type.traverse(visitor, scope);
if (this.arguments != null) {
int argumentslength = this.arguments.length;
for (int i = 0; i < argumentslength; i++)
this.arguments[i].traverse(visitor, scope);
}
if (this.anonymoustype != null)
this.anonymoustype.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
