/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

/*
* parser able to build specific completion parse nodes, given a cursorlocation.
*
* cursor location denotes the position of the last character behind which completion
* got requested:
*  -1 means completion at the very beginning of the source
*	0  means completion behind the first character
*  n  means completion behind the n-th character
*/

import org.eclipse.jdt.internal.compiler.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.env.*;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.codeassist.impl.*;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.parser.*;
import org.eclipse.jdt.internal.compiler.problem.*;
import org.eclipse.jdt.internal.compiler.util.util;

public class selectionparser extends assistparser {
// owner
protected static final int selection_parser = 1024;
protected static final int selection_or_assist_parser = assist_parser + selection_parser;

// kind : all values known by selectionparser are between 1025 and 1549
protected static final int k_between_case_and_colon = selection_parser + 1; // whether we are inside a block
protected static final int k_inside_return_statement = selection_parser + 2; // whether we are between the keyword 'return' and the end of a return statement
protected static final int k_cast_statement = selection_parser + 3; // whether we are between ')' and the end of a cast statement


public astnode assistnodeparent; // the parent node of assist node

/* public fields */

public int selectionstart, selectionend;

public static final char[] super = "super".tochararray(); //$non-nls-1$
public static final char[] this = "this".tochararray(); //$non-nls-1$

public selectionparser(problemreporter problemreporter) {
super(problemreporter);
this.javadocparser.checkdoccomment = true;
}
public char[] assistidentifier(){
return ((selectionscanner)this.scanner).selectionidentifier;
}
protected void attachorphancompletionnode(){
if (this.isorphancompletionnode){
astnode orphan = this.assistnode;
this.isorphancompletionnode = false;


/* if in context of a type, then persists the identifier into a fake field return type */
if (this.currentelement instanceof recoveredtype){
recoveredtype recoveredtype = (recoveredtype)this.currentelement;
/* filter out cases where scanner is still inside type header */
if (recoveredtype.foundopeningbrace) {
/* generate a pseudo field with a completion on type reference */
if (orphan instanceof typereference){
this.currentelement = this.currentelement.add(new selectiononfieldtype((typereference)orphan), 0);
return;
}
}
}

if (orphan instanceof expression) {
buildmorecompletioncontext((expression)orphan);
} else {
statement statement = (statement) orphan;
this.currentelement = this.currentelement.add(statement, 0);
}
this.currenttoken = 0; // given we are not on an eof, we do not want side effects caused by looked-ahead token
}
}
private void buildmorecompletioncontext(expression expression) {
astnode parentnode = null;

int kind = topknownelementkind(selection_or_assist_parser);
if(kind != 0) {
int info = topknownelementinfo(selection_or_assist_parser);
nextelement : switch (kind) {
case k_between_case_and_colon :
if(this.expressionptr > 0) {
switchstatement switchstatement = new switchstatement();
switchstatement.expression = this.expressionstack[this.expressionptr - 1];
if(this.astlengthptr > -1 && this.astptr > -1) {
int length = this.astlengthstack[this.astlengthptr];
int newastptr = this.astptr - length;
astnode firstnode = this.aststack[newastptr + 1];
if(length != 0 && firstnode.sourcestart > switchstatement.expression.sourceend) {
switchstatement.statements = new statement[length + 1];
system.arraycopy(
this.aststack,
newastptr + 1,
switchstatement.statements,
0,
length);
}
}
casestatement casestatement = new casestatement(expression, expression.sourcestart, expression.sourceend);
if(switchstatement.statements == null) {
switchstatement.statements = new statement[]{casestatement};
} else {
switchstatement.statements[switchstatement.statements.length - 1] = casestatement;
}
parentnode = switchstatement;
this.assistnodeparent = parentnode;
}
break nextelement;
case k_inside_return_statement :
if(info == this.bracketdepth) {
returnstatement returnstatement = new returnstatement(expression, expression.sourcestart, expression.sourceend);
parentnode = returnstatement;
this.assistnodeparent = parentnode;
}
break nextelement;
case k_cast_statement :
expression casttype;
if(this.expressionptr > 0
&& ((casttype = this.expressionstack[this.expressionptr-1]) instanceof typereference)) {
castexpression cast = new castexpression(expression, casttype);
cast.sourcestart = casttype.sourcestart;
cast.sourceend= expression.sourceend;
parentnode = cast;
this.assistnodeparent = parentnode;
}
break nextelement;
}
}
if(parentnode != null) {
this.currentelement = this.currentelement.add((statement)parentnode, 0);
} else {
this.currentelement = this.currentelement.add((statement)wrapwithexplicitconstructorcallifneeded(expression), 0);
if(this.lastcheckpoint < expression.sourceend) {
this.lastcheckpoint = expression.sourceend + 1;
}
}
}
private boolean checkrecoveredtype() {
if (this.currentelement instanceof recoveredtype){
/* check if current awaiting identifier is the completion identifier */
if (this.indexofassistidentifier() < 0) return false;

if ((this.lasterrorendposition >= this.selectionstart)
&& (this.lasterrorendposition <= this.selectionend+1)){
return false;
}
recoveredtype recoveredtype = (recoveredtype)this.currentelement;
/* filter out cases where scanner is still inside type header */
if (recoveredtype.foundopeningbrace) {
this.assistnode = this.gettypereference(0);
this.lastcheckpoint = this.assistnode.sourceend + 1;
this.isorphancompletionnode = true;
return true;
}
}
return false;
}
protected void classinstancecreation(boolean hasclassbody) {

// classinstancecreationexpression ::= 'new' classtype '(' argumentlistopt ')' classbodyopt

// classbodyopt produces a null item on the aststak if it produces no class body
// an empty class body produces a 0 on the length stack.....


if ((this.astlengthstack[this.astlengthptr] == 1)
&& (this.aststack[this.astptr] == null)) {


int index;
if ((index = this.indexofassistidentifier()) < 0) {
super.classinstancecreation(hasclassbody);
return;
} else if(this.identifierlengthptr > -1 &&
(this.identifierlengthstack[this.identifierlengthptr] - 1) != index) {
super.classinstancecreation(hasclassbody);
return;
}
qualifiedallocationexpression alloc;
this.astptr--;
this.astlengthptr--;
alloc = new selectiononqualifiedallocationexpression();
alloc.sourceend = this.endposition; //the position has been stored explicitly

int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
alloc.arguments = new expression[length],
0,
length);
}
// trick to avoid creating a selection on type reference
char [] oldident = assistidentifier();
setassistidentifier(null);
alloc.type = gettypereference(0);

setassistidentifier(oldident);

//the default constructor with the correct number of argument
//will be created and added by the tc (see createsinternalconstructorwithbinding)
alloc.sourcestart = this.intstack[this.intptr--];
pushonexpressionstack(alloc);

this.assistnode = alloc;
this.lastcheckpoint = alloc.sourceend + 1;
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}
this.isorphancompletionnode = true;
} else {
super.classinstancecreation(hasclassbody);
}
}
protected void consumearraycreationexpressionwithoutinitializer() {
// arraycreationwithoutarrayinitializer ::= 'new' primitivetype dimwithorwithoutexprs
// arraycreationwithoutarrayinitializer ::= 'new' classorinterfacetype dimwithorwithoutexprs

super.consumearraycreationexpressionwithoutinitializer();

arrayallocationexpression alloc = (arrayallocationexpression)this.expressionstack[this.expressionptr];
if (alloc.type == this.assistnode){
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}
this.isorphancompletionnode = true;
}
}
protected void consumearraycreationexpressionwithinitializer() {
// arraycreationwitharrayinitializer ::= 'new' classorinterfacetype dimwithorwithoutexprs arrayinitializer

super.consumearraycreationexpressionwithinitializer();

arrayallocationexpression alloc = (arrayallocationexpression)this.expressionstack[this.expressionptr];
if (alloc.type == this.assistnode){
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}
this.isorphancompletionnode = true;
}
}
protected void consumecastexpressionll1() {
popelement(k_cast_statement);
super.consumecastexpressionll1();
}
protected void consumecastexpressionwithgenericsarray() {
popelement(k_cast_statement);
super.consumecastexpressionwithgenericsarray();
}
protected void consumecastexpressionwithnamearray() {
popelement(k_cast_statement);
super.consumecastexpressionwithnamearray();
}
protected void consumecastexpressionwithprimitivetype() {
popelement(k_cast_statement);
super.consumecastexpressionwithprimitivetype();
}
protected void consumecastexpressionwithqualifiedgenericsarray() {
popelement(k_cast_statement);
super.consumecastexpressionwithqualifiedgenericsarray();
}
protected void consumeclassinstancecreationexpressionqualifiedwithtypearguments() {
// classinstancecreationexpression ::= primary '.' 'new' typearguments simplename '(' argumentlistopt ')' classbodyopt
// classinstancecreationexpression ::= classinstancecreationexpressionname 'new' typearguments simplename '(' argumentlistopt ')' classbodyopt

qualifiedallocationexpression alloc;
int length;
if (((length = this.astlengthstack[this.astlengthptr]) == 1) && (this.aststack[this.astptr] == null)) {

if (this.indexofassistidentifier() < 0) {
super.consumeclassinstancecreationexpressionqualifiedwithtypearguments();
return;
}

//no classbody
this.astptr--;
this.astlengthptr--;
alloc = new selectiononqualifiedallocationexpression();
alloc.sourceend = this.endposition; //the position has been stored explicitly

if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
alloc.arguments = new expression[length],
0,
length);
}

// trick to avoid creating a selection on type reference
char [] oldident = assistidentifier();
setassistidentifier(null);
alloc.type = gettypereference(0);

setassistidentifier(oldident);

length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, alloc.typearguments = new typereference[length], 0, length);
this.intptr--; // remove the position of the '<'

//the default constructor with the correct number of argument
//will be created and added by the tc (see createsinternalconstructorwithbinding)
alloc.sourcestart = this.intstack[this.intptr--];
pushonexpressionstack(alloc);

this.assistnode = alloc;
this.lastcheckpoint = alloc.sourceend + 1;
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}
this.isorphancompletionnode = true;
} else {
super.consumeclassinstancecreationexpressionqualifiedwithtypearguments();
}

this.expressionlengthptr--;
qualifiedallocationexpression qae =
(qualifiedallocationexpression) this.expressionstack[this.expressionptr--];
qae.enclosinginstance = this.expressionstack[this.expressionptr];
this.expressionstack[this.expressionptr] = qae;
qae.sourcestart = qae.enclosinginstance.sourcestart;
}
protected void consumeclassinstancecreationexpressionwithtypearguments() {
// classinstancecreationexpression ::= 'new' typearguments classtype '(' argumentlistopt ')' classbodyopt
allocationexpression alloc;
int length;
if (((length = this.astlengthstack[this.astlengthptr]) == 1)
&& (this.aststack[this.astptr] == null)) {

if (this.indexofassistidentifier() < 0) {
super.consumeclassinstancecreationexpressionwithtypearguments();
return;
}

//no classbody
this.astptr--;
this.astlengthptr--;
alloc = new selectiononqualifiedallocationexpression();
alloc.sourceend = this.endposition; //the position has been stored explicitly

if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
alloc.arguments = new expression[length],
0,
length);
}

// trick to avoid creating a selection on type reference
char [] oldident = assistidentifier();
setassistidentifier(null);
alloc.type = gettypereference(0);

setassistidentifier(oldident);

length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, alloc.typearguments = new typereference[length], 0, length);
this.intptr--; // remove the position of the '<'

//the default constructor with the correct number of argument
//will be created and added by the tc (see createsinternalconstructorwithbinding)
alloc.sourcestart = this.intstack[this.intptr--];
pushonexpressionstack(alloc);

this.assistnode = alloc;
this.lastcheckpoint = alloc.sourceend + 1;
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}
this.isorphancompletionnode = true;
} else {
super.consumeclassinstancecreationexpressionwithtypearguments();
}
}
protected void consumeenteranonymousclassbody(boolean qualified) {
// enteranonymousclassbody ::= $empty

if (this.indexofassistidentifier() < 0) {
super.consumeenteranonymousclassbody(qualified);
return;
}

// trick to avoid creating a selection on type reference
char [] oldident = assistidentifier();
setassistidentifier(null);
typereference typereference = gettypereference(0);
setassistidentifier(oldident);

typedeclaration anonymoustype = new typedeclaration(this.compilationunit.compilationresult);
anonymoustype.name = charoperation.no_char;
anonymoustype.bits |= (astnode.isanonymoustype|astnode.islocaltype);
qualifiedallocationexpression alloc = new selectiononqualifiedallocationexpression(anonymoustype);
markenclosingmemberwithlocaltype();
pushonaststack(anonymoustype);

alloc.sourceend = this.rparenpos; //the position has been stored explicitly
int argumentlength;
if ((argumentlength = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= argumentlength;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
alloc.arguments = new expression[argumentlength],
0,
argumentlength);
}

if (qualified) {
this.expressionlengthptr--;
alloc.enclosinginstance = this.expressionstack[this.expressionptr--];
}

alloc.type = typereference;

anonymoustype.sourceend = alloc.sourceend;
//position at the type while it impacts the anonymous declaration
anonymoustype.sourcestart = anonymoustype.declarationsourcestart = alloc.type.sourcestart;
alloc.sourcestart = this.intstack[this.intptr--];
pushonexpressionstack(alloc);

this.assistnode = alloc;
this.lastcheckpoint = alloc.sourceend + 1;
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
this.currenttoken = 0; // opening brace already taken into account
this.hasreportederror = true;
}

anonymoustype.bodystart = this.scanner.currentposition;
this.listlength = 0; // will be updated when reading super-interfaces
// recovery
if (this.currentelement != null){
this.lastcheckpoint = anonymoustype.bodystart;
this.currentelement = this.currentelement.add(anonymoustype, 0);
this.currenttoken = 0; // opening brace already taken into account
this.lastignoredtoken = -1;
}
}
protected void consumeentervariable() {
// entervariable ::= $empty
// do nothing by default

super.consumeentervariable();

abstractvariabledeclaration variable = (abstractvariabledeclaration) this.aststack[this.astptr];
if (variable.type == this.assistnode){
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}
this.isorphancompletionnode = false; // already attached inside variable decl
}
}

protected void consumeexitvariablewithinitialization() {
super.consumeexitvariablewithinitialization();

// does not keep the initialization if selection is not inside
abstractvariabledeclaration variable = (abstractvariabledeclaration) this.aststack[this.astptr];
int start = variable.initialization.sourcestart;
int end =  variable.initialization.sourceend;
if ((this.selectionstart < start) &&  (this.selectionend < start) ||
(this.selectionstart > end) && (this.selectionend > end)) {
variable.initialization = null;
}

}

protected void consumefieldaccess(boolean issuperaccess) {
// fieldaccess ::= primary '.' 'identifier'
// fieldaccess ::= 'super' '.' 'identifier'

if (this.indexofassistidentifier() < 0) {
super.consumefieldaccess(issuperaccess);
return;
}
fieldreference fieldreference =
new selectiononfieldreference(
this.identifierstack[this.identifierptr],
this.identifierpositionstack[this.identifierptr--]);
this.identifierlengthptr--;
if (issuperaccess) { //considerates the fieldreferenceerence beginning at the 'super' ....
fieldreference.sourcestart = this.intstack[this.intptr--];
fieldreference.receiver = new superreference(fieldreference.sourcestart, this.endposition);
pushonexpressionstack(fieldreference);
} else { //optimize push/pop
if ((fieldreference.receiver = this.expressionstack[this.expressionptr]).isthis()) { //fieldreferenceerence begins at the this
fieldreference.sourcestart = fieldreference.receiver.sourcestart;
}
this.expressionstack[this.expressionptr] = fieldreference;
}
this.assistnode = fieldreference;
this.lastcheckpoint = fieldreference.sourceend + 1;
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}
this.isorphancompletionnode = true;
}
protected void consumeformalparameter(boolean isvarargs) {
if (this.indexofassistidentifier() < 0) {
super.consumeformalparameter(isvarargs);
if((!this.diet || this.dietint != 0) && this.astptr > -1) {
argument argument = (argument) this.aststack[this.astptr];
if(argument.type == this.assistnode) {
this.isorphancompletionnode = true;
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}
}
} else {
this.identifierlengthptr--;
char[] identifiername = this.identifierstack[this.identifierptr];
long namepositions = this.identifierpositionstack[this.identifierptr--];
int extendeddimensions = this.intstack[this.intptr--];
int endofellipsis = 0;
if (isvarargs) {
endofellipsis = this.intstack[this.intptr--];
}
int firstdimensions = this.intstack[this.intptr--];
final int typedimensions = firstdimensions + extendeddimensions;
typereference type = gettypereference(typedimensions);
if (isvarargs) {
type = copydims(type, typedimensions + 1);
if (extendeddimensions == 0) {
type.sourceend = endofellipsis;
}
type.bits |= astnode.isvarargs; // set isvarargs
}
int modifierpositions = this.intstack[this.intptr--];
this.intptr--;
argument arg =
new selectiononargumentname(
identifiername,
namepositions,
type,
this.intstack[this.intptr + 1] & ~classfileconstants.accdeprecated); // modifiers
arg.declarationsourcestart = modifierpositions;

// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
arg.annotations = new annotation[length],
0,
length);
}

pushonaststack(arg);

this.assistnode = arg;
this.lastcheckpoint = (int) namepositions;
this.isorphancompletionnode = true;

if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}

/* if incomplete method header, listlength counter will not have been reset,
indicating that some arguments are available on the stack */
this.listlength++;
}
}
protected void consumeinsidecastexpression() {
super.consumeinsidecastexpression();
pushonelementstack(k_cast_statement);
}
protected void consumeinsidecastexpressionll1() {
super.consumeinsidecastexpressionll1();
pushonelementstack(k_cast_statement);
}
protected void consumeinsidecastexpressionwithqualifiedgenerics() {
super.consumeinsidecastexpressionwithqualifiedgenerics();
pushonelementstack(k_cast_statement);
}
protected void consumeinstanceofexpression() {
if (indexofassistidentifier() < 0) {
super.consumeinstanceofexpression();
} else {
gettypereference(this.intstack[this.intptr--]);
this.isorphancompletionnode = true;
this.restartrecovery = true;
this.lastignoredtoken = -1;
}
}
protected void consumeinstanceofexpressionwithname() {
if (indexofassistidentifier() < 0) {
super.consumeinstanceofexpressionwithname();
} else {
gettypereference(this.intstack[this.intptr--]);
this.isorphancompletionnode = true;
this.restartrecovery = true;
this.lastignoredtoken = -1;
}
}
protected void consumelocalvariabledeclarationstatement() {
super.consumelocalvariabledeclarationstatement();

// force to restart in recovery mode if the declaration contains the selection
if (!this.diet) {
localdeclaration localdeclaration = (localdeclaration) this.aststack[this.astptr];
if ((this.selectionstart >= localdeclaration.sourcestart)
&&  (this.selectionend <= localdeclaration.sourceend)) {
this.restartrecovery	= true;
this.lastignoredtoken = -1;
}
}
}
protected void consumemarkerannotation() {
int index;

if ((index = this.indexofassistidentifier()) < 0) {
super.consumemarkerannotation();
return;
}

markerannotation markerannotation = null;
int length = this.identifierlengthstack[this.identifierlengthptr];
typereference typereference;

/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */

char[][] subset = identifiersubset(index);
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist on type reference */

if (index == 0) {
/* assist inside first identifier */
typereference = createsingleassisttypereference(
assistidentifier(),
positions[0]);
} else {
/* assist inside subsequent identifier */
typereference =	createqualifiedassisttypereference(
subset,
assistidentifier(),
positions);
}
this.assistnode = typereference;
this.lastcheckpoint = typereference.sourceend + 1;

markerannotation = new markerannotation(typereference, this.intstack[this.intptr--]);
markerannotation.declarationsourceend = markerannotation.sourceend;
pushonexpressionstack(markerannotation);
}
protected void consumemembervaluepair() {
if (this.indexofassistidentifier() < 0) {
super.consumemembervaluepair();
return;
}

char[] simplename = this.identifierstack[this.identifierptr];
long position = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;
int end = (int) position;
int start = (int) (position >>> 32);
expression value = this.expressionstack[this.expressionptr--];
this.expressionlengthptr--;
membervaluepair membervaluepair = new selectiononnameofmembervaluepair(simplename, start, end, value);
pushonaststack(membervaluepair);

this.assistnode = membervaluepair;
this.lastcheckpoint = membervaluepair.sourceend + 1;


}
protected void consumemethodinvocationname() {
// methodinvocation ::= name '(' argumentlistopt ')'

// when the name is only an identifier...we have a message send to "this" (implicit)

char[] selector = this.identifierstack[this.identifierptr];
int accessmode;
if(selector == assistidentifier()) {
if(charoperation.equals(selector, super)) {
accessmode = explicitconstructorcall.super;
} else if(charoperation.equals(selector, this)) {
accessmode = explicitconstructorcall.this;
} else {
super.consumemethodinvocationname();
return;
}
} else {
super.consumemethodinvocationname();
return;
}

final explicitconstructorcall constructorcall = new selectiononexplicitconstructorcall(accessmode);
constructorcall.sourceend = this.rparenpos;
constructorcall.sourcestart = (int) (this.identifierpositionstack[this.identifierptr] >>> 32);
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(this.expressionstack, this.expressionptr + 1, constructorcall.arguments = new expression[length], 0, length);
}

if (!this.diet){
pushonaststack(constructorcall);
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
} else {
pushonexpressionstack(new expression(){
public typebinding resolvetype(blockscope scope) {
constructorcall.resolve(scope);
return null;
}
public stringbuffer printexpression(int indent, stringbuffer output) {
return output;
}
});
}
this.assistnode = constructorcall;
this.lastcheckpoint = constructorcall.sourceend + 1;
this.isorphancompletionnode = true;
}
protected void consumemethodinvocationprimary() {
//optimize the push/pop
//methodinvocation ::= primary '.' 'identifier' '(' argumentlistopt ')'

char[] selector = this.identifierstack[this.identifierptr];
int accessmode;
if(selector == assistidentifier()) {
if(charoperation.equals(selector, super)) {
accessmode = explicitconstructorcall.super;
} else if(charoperation.equals(selector, this)) {
accessmode = explicitconstructorcall.this;
} else {
super.consumemethodinvocationprimary();
return;
}
} else {
super.consumemethodinvocationprimary();
return;
}

final explicitconstructorcall constructorcall = new selectiononexplicitconstructorcall(accessmode);
constructorcall.sourceend = this.rparenpos;
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(this.expressionstack, this.expressionptr + 1, constructorcall.arguments = new expression[length], 0, length);
}
constructorcall.qualification = this.expressionstack[this.expressionptr--];
constructorcall.sourcestart = constructorcall.qualification.sourcestart;

if (!this.diet){
pushonaststack(constructorcall);
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
} else {
pushonexpressionstack(new expression(){
public typebinding resolvetype(blockscope scope) {
constructorcall.resolve(scope);
return null;
}
public stringbuffer printexpression(int indent, stringbuffer output) {
return output;
}
});
}

this.assistnode = constructorcall;
this.lastcheckpoint = constructorcall.sourceend + 1;
this.isorphancompletionnode = true;
}
protected void consumenormalannotation() {
int index;

if ((index = this.indexofassistidentifier()) < 0) {
super.consumenormalannotation();
return;
}

normalannotation normalannotation = null;
int length = this.identifierlengthstack[this.identifierlengthptr];
typereference typereference;

/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */

char[][] subset = identifiersubset(index);
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist on type reference */

if (index == 0) {
/* assist inside first identifier */
typereference = createsingleassisttypereference(
assistidentifier(),
positions[0]);
} else {
/* assist inside subsequent identifier */
typereference =	createqualifiedassisttypereference(
subset,
assistidentifier(),
positions);
}
this.assistnode = typereference;
this.lastcheckpoint = typereference.sourceend + 1;

normalannotation = new normalannotation(typereference, this.intstack[this.intptr--]);
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
system.arraycopy(
this.aststack,
(this.astptr -= length) + 1,
normalannotation.membervaluepairs = new membervaluepair[length],
0,
length);
}
normalannotation.declarationsourceend = this.rparenpos;
pushonexpressionstack(normalannotation);
}
protected void consumesinglememberannotation() {
int index;

if ((index = this.indexofassistidentifier()) < 0) {
super.consumesinglememberannotation();
return;
}

singlememberannotation singlememberannotation = null;
int length = this.identifierlengthstack[this.identifierlengthptr];
typereference typereference;

/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */

char[][] subset = identifiersubset(index);
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist on type reference */

if (index == 0) {
/* assist inside first identifier */
typereference = createsingleassisttypereference(
assistidentifier(),
positions[0]);
} else {
/* assist inside subsequent identifier */
typereference =	createqualifiedassisttypereference(
subset,
assistidentifier(),
positions);
}
this.assistnode = typereference;
this.lastcheckpoint = typereference.sourceend + 1;

singlememberannotation = new singlememberannotation(typereference, this.intstack[this.intptr--]);
singlememberannotation.membervalue = this.expressionstack[this.expressionptr--];
this.expressionlengthptr--;
singlememberannotation.declarationsourceend = this.rparenpos;
pushonexpressionstack(singlememberannotation);
}
protected void consumestaticimportondemanddeclarationname() {
// typeimportondemanddeclarationname ::= 'import' 'static' name '.' '*'
/* push an importref build from the last name
stored in the identifier stack. */

int index;

/* no need to take action if not inside assist identifiers */
if ((index = indexofassistidentifier()) < 0) {
super.consumestaticimportondemanddeclarationname();
return;
}
/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */
int length = this.identifierlengthstack[this.identifierlengthptr];
char[][] subset = identifiersubset(index+1); // include the assistidentifier
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist node on import statement */
importreference reference = createassistimportreference(subset, positions, classfileconstants.accstatic);
reference.bits |= astnode.ondemand;
this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;

pushonaststack(reference);

if (this.currenttoken == tokennamesemicolon){
reference.declarationsourceend = this.scanner.currentposition - 1;
} else {
reference.declarationsourceend = (int) positions[length-1];
}
//endposition is just before the ;
reference.declarationsourcestart = this.intstack[this.intptr--];
// flush annotations defined prior to import statements
reference.declarationsourceend = flushcommentsdefinedpriorto(reference.declarationsourceend);

// recovery
if (this.currentelement != null){
this.lastcheckpoint = reference.declarationsourceend+1;
this.currentelement = this.currentelement.add(reference, 0);
this.lastignoredtoken = -1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumetoken(int token) {
super.consumetoken(token);

// if in a method or if in a field initializer
if (isinsidemethod() || isinsidefieldinitialization()) {
switch (token) {
case tokennamecase :
pushonelementstack(k_between_case_and_colon);
break;
case tokennamecolon:
if(topknownelementkind(selection_or_assist_parser) == k_between_case_and_colon) {
popelement(k_between_case_and_colon);
}
break;
case tokennamereturn:
pushonelementstack(k_inside_return_statement, this.bracketdepth);
break;
case tokennamesemicolon:
switch(topknownelementkind(selection_or_assist_parser)) {
case k_inside_return_statement :
if(topknownelementinfo(selection_or_assist_parser) == this.bracketdepth) {
popelement(k_inside_return_statement);
}
break;
}
break;
}
}
}
protected void consumetypeimportondemanddeclarationname() {
// typeimportondemanddeclarationname ::= 'import' name '.' '*'
/* push an importref build from the last name
stored in the identifier stack. */

int index;

/* no need to take action if not inside assist identifiers */
if ((index = indexofassistidentifier()) < 0) {
super.consumetypeimportondemanddeclarationname();
return;
}
/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */
int length = this.identifierlengthstack[this.identifierlengthptr];
char[][] subset = identifiersubset(index+1); // include the assistidentifier
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist node on import statement */
importreference reference = createassistimportreference(subset, positions, classfileconstants.accdefault);
reference.bits |= astnode.ondemand;
this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;

pushonaststack(reference);

if (this.currenttoken == tokennamesemicolon){
reference.declarationsourceend = this.scanner.currentposition - 1;
} else {
reference.declarationsourceend = (int) positions[length-1];
}
//endposition is just before the ;
reference.declarationsourcestart = this.intstack[this.intptr--];
// flush comments defined prior to import statements
reference.declarationsourceend = flushcommentsdefinedpriorto(reference.declarationsourceend);

// recovery
if (this.currentelement != null){
this.lastcheckpoint = reference.declarationsourceend+1;
this.currentelement = this.currentelement.add(reference, 0);
this.lastignoredtoken = -1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
public importreference createassistimportreference(char[][] tokens, long[] positions, int mod){
return new selectiononimportreference(tokens, positions, mod);
}
public importreference createassistpackagereference(char[][] tokens, long[] positions){
return new selectiononpackagereference(tokens, positions);
}
protected javadocparser createjavadocparser() {
return new selectionjavadocparser(this);
}
protected localdeclaration createlocaldeclaration(char[] assistname,int sourcestart,int sourceend) {
if (this.indexofassistidentifier() < 0) {
return super.createlocaldeclaration(assistname, sourcestart, sourceend);
} else {
selectiononlocalname local = new selectiononlocalname(assistname, sourcestart, sourceend);
this.assistnode = local;
this.lastcheckpoint = sourceend + 1;
return local;
}
}
public namereference createqualifiedassistnamereference(char[][] previousidentifiers, char[] assistname, long[] positions){
return new selectiononqualifiednamereference(
previousidentifiers,
assistname,
positions);
}
public typereference createqualifiedassisttypereference(char[][] previousidentifiers, char[] assistname, long[] positions){
return new selectiononqualifiedtypereference(
previousidentifiers,
assistname,
positions);
}
public typereference createparameterizedqualifiedassisttypereference(
char[][] tokens, typereference[][] typearguments, char[] assistname, typereference[] assisttypearguments, long[] positions) {
return new selectiononparameterizedqualifiedtypereference(tokens, assistname, typearguments, assisttypearguments, positions);

}
public namereference createsingleassistnamereference(char[] assistname, long position) {
return new selectiononsinglenamereference(assistname, position);
}
public typereference createsingleassisttypereference(char[] assistname, long position) {
return new selectiononsingletypereference(assistname, position);
}
public typereference createparameterizedsingleassisttypereference(typereference[] typearguments, char[] assistname, long position) {
return new selectiononparameterizedsingletypereference(assistname, typearguments, position);
}
public compilationunitdeclaration dietparse(icompilationunit sourceunit, compilationresult compilationresult, int start, int end) {

this.selectionstart = start;
this.selectionend = end;
selectionscanner selectionscanner = (selectionscanner)this.scanner;
selectionscanner.selectionidentifier = null;
selectionscanner.selectionstart = start;
selectionscanner.selectionend = end;
return this.dietparse(sourceunit, compilationresult);
}
protected namereference getunspecifiedreference() {
/* build a (unspecified) namereference which may be qualified*/

int completionindex;

/* no need to take action if not inside completed identifiers */
if ((completionindex = indexofassistidentifier()) < 0) {
return super.getunspecifiedreference();
}

int length = this.identifierlengthstack[this.identifierlengthptr];
if (charoperation.equals(assistidentifier(), super)){
reference reference;
if (completionindex > 0){ // qualified super
// discard 'super' from identifier stacks
this.identifierlengthstack[this.identifierlengthptr] = completionindex;
int ptr = this.identifierptr -= (length - completionindex);
pushongenericslengthstack(0);
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
reference =
new selectiononqualifiedsuperreference(
gettypereference(0),
(int)(this.identifierpositionstack[ptr+1] >>> 32),
(int) this.identifierpositionstack[ptr+1]);
} else { // standard super
this.identifierptr -= length;
this.identifierlengthptr--;
reference = new selectiononsuperreference((int)(this.identifierpositionstack[this.identifierptr+1] >>> 32), (int) this.identifierpositionstack[this.identifierptr+1]);
}
pushonaststack(reference);
this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;
if (!this.diet || this.dietint != 0){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}
this.isorphancompletionnode = true;
return new singlenamereference(charoperation.no_char, 0); // dummy reference
}
namereference namereference;
/* retrieve identifiers subset and whole positions, the completion node positions
should include the entire replaced source. */
char[][] subset = identifiersubset(completionindex);
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);
/* build specific completion on name reference */
if (completionindex == 0) {
/* completion inside first identifier */
namereference = createsingleassistnamereference(assistidentifier(), positions[0]);
} else {
/* completion inside subsequent identifier */
namereference = createqualifiedassistnamereference(subset, assistidentifier(), positions);
}
this.assistnode = namereference;
this.lastcheckpoint = namereference.sourceend + 1;
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}
this.isorphancompletionnode = true;
return namereference;
}
/*
* copy of code from superclass with the following change:
* in the case of qualified name reference if the cursor location is on the
* qualified name reference, then create a completiononqualifiednamereference
* instead.
*/
protected namereference getunspecifiedreferenceoptimized() {

int index = indexofassistidentifier();
namereference reference = super.getunspecifiedreferenceoptimized();

if (index >= 0){
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}
this.isorphancompletionnode = true;
}
return reference;
}
public void initializescanner(){
this.scanner = new selectionscanner(this.options.sourcelevel);
}
protected messagesend newmessagesend() {
// '(' argumentlistopt ')'
// the arguments are on the expression stack

char[] selector = this.identifierstack[this.identifierptr];
if (selector != assistidentifier()){
return super.newmessagesend();
}
messagesend messagesend = new selectiononmessagesend();
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
messagesend.arguments = new expression[length],
0,
length);
}
this.assistnode = messagesend;
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}

this.isorphancompletionnode = true;
return messagesend;
}
protected messagesend newmessagesendwithtypearguments() {
char[] selector = this.identifierstack[this.identifierptr];
if (selector != assistidentifier()){
return super.newmessagesendwithtypearguments();
}
messagesend messagesend = new selectiononmessagesend();
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
messagesend.arguments = new expression[length],
0,
length);
}
this.assistnode = messagesend;
if (!this.diet){
this.restartrecovery	= true;	// force to restart in recovery mode
this.lastignoredtoken = -1;
}

this.isorphancompletionnode = true;
return messagesend;
}
public compilationunitdeclaration parse(icompilationunit sourceunit, compilationresult compilationresult, int start, int end) {

if (end == -1) return super.parse(sourceunit, compilationresult, start, end);

this.selectionstart = start;
this.selectionend = end;
selectionscanner selectionscanner = (selectionscanner)this.scanner;
selectionscanner.selectionidentifier = null;
selectionscanner.selectionstart = start;
selectionscanner.selectionend = end;
return super.parse(sourceunit, compilationresult, -1, -1/*parse without reseting the scanner*/);
}
/*
* reset context so as to resume to regular parse loop
* if unable to reset for resuming, answers false.
*
* move checkpoint location, reset internal stacks and
* decide which grammar goal is activated.
*/
protected boolean resumeafterrecovery() {

/* if reached assist node inside method body, but still inside nested type,
should continue in diet mode until the end of the method body */
if (this.assistnode != null
&& !(this.referencecontext instanceof compilationunitdeclaration)){
this.currentelement.preserveenclosingblocks();
if (this.currentelement.enclosingtype() == null) {
if(!(this.currentelement instanceof recoveredtype)) {
resetstacks();
return false;
}

recoveredtype recoveredtype = (recoveredtype)this.currentelement;
if(recoveredtype.typedeclaration != null && recoveredtype.typedeclaration.allocation == this.assistnode){
resetstacks();
return false;
}
}
}
return super.resumeafterrecovery();
}

public void selectionidentifiercheck(){
if (checkrecoveredtype()) return;
}
public void setassistidentifier(char[] assistident){
((selectionscanner)this.scanner).selectionidentifier = assistident;
}
/*
* update recovery state based on current parser/scanner state
*/
protected void updaterecoverystate() {

/* expose parser state to recovery state */
this.currentelement.updatefromparserstate();

/* may be able to retrieve completionnode as an orphan, and then attach it */
selectionidentifiercheck();
attachorphancompletionnode();

// if an assist node has been found and a recovered element exists,
// mark enclosing blocks as to be preserved
if (this.assistnode != null && this.currentelement != null) {
this.currentelement.preserveenclosingblocks();
}

/* check and update recovered state based on current token,
this action is also performed when shifting token after recovery
got activated once.
*/
recoverytokencheck();
}

public  string tostring() {
string s = util.empty_string;
s = s + "elementkindstack : int[] = {"; //$non-nls-1$
for (int i = 0; i <= this.elementptr; i++) {
s = s + string.valueof(this.elementkindstack[i]) + ","; //$non-nls-1$
}
s = s + "}\n"; //$non-nls-1$
s = s + "elementinfostack : int[] = {"; //$non-nls-1$
for (int i = 0; i <= this.elementptr; i++) {
s = s + string.valueof(this.elementinfostack[i]) + ","; //$non-nls-1$
}
s = s + "}\n"; //$non-nls-1$
return s + super.tostring();
}
}
