/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.invocationsite;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public abstract class abstractvariabledeclaration extends statement implements invocationsite {
public int declarationend;
/**
* for local declarations (outside of for statement initialization) and field declarations,
* the declarationsourceend covers multiple locals if any.
* for local declarations inside for statement initialization, this is not the case.
*/
public int declarationsourceend;
public int declarationsourcestart;
public int hiddenvariabledepth; // used to diagnose hiding scenarii
public expression initialization;
public int modifiers;
public int modifierssourcestart;
public annotation[] annotations;

public char[] name;

public typereference type;

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
return flowinfo;
}

public static final int field = 1;
public static final int initializer = 2;
public static final int enum_constant = 3;
public static final int local_variable = 4;
public static final int parameter = 5;
public static final int type_parameter = 6;


/**
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#generictypearguments()
*/
public typebinding[] generictypearguments() {
return null;
}

/**
* returns the constant kind of this variable declaration
*/
public abstract int getkind();

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#issuperaccess()
*/
public boolean issuperaccess() {
return false;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#istypeaccess()
*/
public boolean istypeaccess() {
return false;
}

public stringbuffer printstatement(int indent, stringbuffer output) {
printasexpression(indent, output);
switch(getkind()) {
case enum_constant:
return output.append(',');
default:
return output.append(';');
}
}

public stringbuffer printasexpression(int indent, stringbuffer output) {
printindent(indent, output);
printmodifiers(this.modifiers, output);
if (this.annotations != null) printannotations(this.annotations, output);

if (this.type != null) {
this.type.print(0, output).append(' ');
}
output.append(this.name);
switch(getkind()) {
case enum_constant:
if (this.initialization != null) {
this.initialization.printexpression(indent, output);
}
break;
default:
if (this.initialization != null) {
output.append(" = "); //$non-nls-1$
this.initialization.printexpression(indent, output);
}
}
return output;
}

public void resolve(blockscope scope) {
// do nothing by default (redefined for local variables)
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#setactualreceivertype(org.eclipse.jdt.internal.compiler.lookup.referencebinding)
*/
public void setactualreceivertype(referencebinding receivertype) {
// do nothing by default
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#setdepth(int)
*/
public void setdepth(int depth) {

this.hiddenvariabledepth = depth;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#setfieldindex(int)
*/
public void setfieldindex(int depth) {
// do nothing by default
}
}
