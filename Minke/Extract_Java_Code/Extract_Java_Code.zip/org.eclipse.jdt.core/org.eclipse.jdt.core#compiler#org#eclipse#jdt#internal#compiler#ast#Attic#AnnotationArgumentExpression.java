/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.env.iconstants;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;


public class annotationargumentexpression extends expression {
public char[] token;
public argument argument;

public annotationargumentexpression(char[] name, int startpos, int endpos, typereference typeref) {
this.token = name;
this.sourcestart = startpos;
this.sourceend = endpos;
long pos = (((long) startpos) << 32) + endpos;
this.argument = new argument(name, pos, typeref, iconstants.accdefault);
this.bits |= insideannotation;
}

private typebinding commonresolvetype(scope scope) {
constant = notaconstant;
if (this.resolvedtype != null) { // is a shared type reference which was already resolved
if (!this.resolvedtype.isvalidbinding()) {
return null; // already reported error
}
}
else {
if (this.argument != null) {
typereference typeref = this.argument.type;
if (typeref != null) {
this.resolvedtype = typeref.gettypebinding(scope);
if (!this.resolvedtype.isvalidbinding()) {
scope.problemreporter().invalidtype(typeref, this.resolvedtype);
return null;
}
if (istypeusedeprecated(this.resolvedtype, scope)) {
scope.problemreporter().deprecatedtype(this.resolvedtype, typeref);
return null;
}
return this.resolvedtype;
}
}
}
return null;
}

public stringbuffer printexpression(int indent, stringbuffer output) {
if (argument == null) {
if (token != null) {
output.append(token);
}
}
else {
argument.print(indent, output);
}
return output;
}

public void resolve(blockscope scope) {
if (argument != null) {
argument.resolve(scope);
}
}

public typebinding resolvetype(blockscope scope) {
return commonresolvetype(scope);
}

public typebinding resolvetype(classscope scope) {
return commonresolvetype(scope);
}

/* (non-javadoc)
* redefine to capture annotation specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(iabstractsyntaxtreevisitor visitor, blockscope blockscope) {
if (visitor.visit(this, blockscope)) {
if (this.argument != null) {
argument.traverse(visitor, blockscope);
}
}
visitor.endvisit(this, blockscope);
}
}
