/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

/*
* scanner aware of a selection range. if finding an identifier which source range is exactly
* the same, then will record it so that the parser can make use of it.
*
* source positions are zero-based and inclusive.
*/
import org.eclipse.jdt.internal.compiler.parser.scanner;

public class selectionscanner extends scanner {

public char[] selectionidentifier;
public int selectionstart, selectionend;
/*
* truncate the current identifier if it is containing the cursor location. since completion is performed
* on an identifier prefix.
*
*/

public selectionscanner(long sourcelevel) {
super(false /*comment*/, false /*whitespace*/, false /*nls*/, sourcelevel, null /*tasktags*/, null/*taskpriorities*/, true/*taskcasesensitive*/);
}

public char[] getcurrentidentifiersource() {

if (this.selectionidentifier == null){
if (this.selectionstart == this.startposition && this.selectionend == this.currentposition-1){
if (this.withoutunicodeptr != 0){			// check unicode scenario
system.arraycopy(this.withoutunicodebuffer, 1, this.selectionidentifier = new char[this.withoutunicodeptr], 0, this.withoutunicodeptr);
} else {
int length = this.currentposition - this.startposition;
// no char[] sharing around completionidentifier, we want it to be unique so as to use identity checks
system.arraycopy(this.source, this.startposition, (this.selectionidentifier = new char[length]), 0, length);
}
return this.selectionidentifier;
}
}
return super.getcurrentidentifiersource();
}
/*
* in case we actually read a keyword which corresponds to the selected
* range, we pretend we read an identifier.
*/
public int scanidentifierorkeyword() {

int id = super.scanidentifierorkeyword();

// convert completed keyword into an identifier
if (id != tokennameidentifier
&& this.startposition == this.selectionstart
&& this.currentposition == this.selectionend+1){
return tokennameidentifier;
}
return id;
}
}
