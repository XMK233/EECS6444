/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser;

/*an interface that contains static declarations for some basic information
about the parser such as the number of rules in the grammar, the starting state, etc...*/
public interface parserbasicinformation {

int error_symbol = 110,
max_name_length = 41,
num_states = 970,

nt_offset = 110,
scope_ubound = 133,
scope_size = 134,
la_state_offset = 12741,
max_la = 1,
num_rules = 703,
num_terminals = 110,
num_non_terminals = 313,
num_symbols = 423,
start_state = 942,
eoft_symbol = 68,
eolt_symbol = 68,
accept_action = 12740,
error_action = 12741;
}
