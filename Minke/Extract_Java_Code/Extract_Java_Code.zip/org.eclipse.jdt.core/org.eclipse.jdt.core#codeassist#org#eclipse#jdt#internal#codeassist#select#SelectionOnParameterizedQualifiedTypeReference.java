/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.parameterizedqualifiedtypereference;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class selectiononparameterizedqualifiedtypereference extends parameterizedqualifiedtypereference {
public selectiononparameterizedqualifiedtypereference(char[][] previousidentifiers, char[] selectionidentifier, typereference[][] typearguments, typereference[] assisttypearguments, long[] positions) {
super(
charoperation.arrayconcat(previousidentifiers, selectionidentifier),
typearguments,
0,
positions);
int length =  this.typearguments.length;
system.arraycopy(this.typearguments, 0, this.typearguments = new typereference[length + 1][], 0, length);
this.typearguments[length] = assisttypearguments;
}

public typebinding resolvetype(blockscope scope, boolean checkbounds) {
super.resolvetype(scope, checkbounds);
//// removed unnecessary code to solve bug 94653
//if(this.resolvedtype != null && this.resolvedtype.israwtype()) {
//	parameterizedtypebinding parameterizedtypebinding = scope.createparameterizedtype(((rawtypebinding)this.resolvedtype).type, new typebinding[0], this.resolvedtype.enclosingtype());
//	throw new selectionnodefound(parameterizedtypebinding);
//}
throw new selectionnodefound(this.resolvedtype);
}

public typebinding resolvetype(classscope scope) {
super.resolvetype(scope);
//// removed unnecessary code to solve bug 94653
//if(this.resolvedtype != null && this.resolvedtype.israwtype()) {
//	parameterizedtypebinding parameterizedtypebinding = scope.createparameterizedtype(((rawtypebinding)this.resolvedtype).type, new typebinding[0], this.resolvedtype.enclosingtype());
//	throw new selectionnodefound(parameterizedtypebinding);
//}
throw new selectionnodefound(this.resolvedtype);
}

public stringbuffer printexpression(int indent, stringbuffer output) {
output.append("<selectontype:");//$non-nls-1$
int length = this.tokens.length;
for (int i = 0; i < length; i++) {
if(i != 0) {
output.append('.');
}
output.append(this.tokens[i]);
typereference[] typeargument = this.typearguments[i];
if (typeargument != null) {
output.append('<');
int max = typeargument.length - 1;
for (int j = 0; j < max; j++) {
typeargument[j].print(0, output);
output.append(", ");//$non-nls-1$
}
typeargument[max].print(0, output);
output.append('>');
}

}
output.append('>');
return output;
}
}
