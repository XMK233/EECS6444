/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class synchronizedstatement extends subroutinestatement {

public expression expression;
public block block;
public blockscope scope;
public localvariablebinding synchrovariable;
static final char[] secretlocaldeclarationname = " syncvalue".tochararray(); //$non-nls-1$

// for local variables table attributes
int presynchronizedinitstateindex = -1;
int mergedsynchronizedinitstateindex = -1;

public synchronizedstatement(
expression expression,
block statement,
int s,
int e) {

this.expression = expression;
this.block = statement;
this.sourceend = e;
this.sourcestart = s;
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {

this.presynchronizedinitstateindex =
currentscope.methodscope().recordinitializationstates(flowinfo);
// todo (philippe) shouldn't it be protected by a check whether reachable statement ?

// mark the synthetic variable as being used
this.synchrovariable.useflag = localvariablebinding.used;

// simple propagation to subnodes
flowinfo =
this.block.analysecode(
this.scope,
new insidesubroutineflowcontext(flowcontext, this),
this.expression.analysecode(this.scope, flowcontext, flowinfo));

this.mergedsynchronizedinitstateindex =
currentscope.methodscope().recordinitializationstates(flowinfo);

// optimizing code gen
if ((flowinfo.tagbits & flowinfo.unreachable) != 0) {
this.bits |= astnode.blockexit;
}

return flowinfo;
}

public boolean issubroutineescaping() {
return false;
}

/**
* synchronized statement code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & isreachable) == 0) {
return;
}
// in case the labels needs to be reinitialized
// when the code generation is restarted in wide mode
this.anyexceptionlabel = null;

int pc = codestream.position;

// generate the synchronization expression
this.expression.generatecode(this.scope, codestream, true);
if (this.block.isemptyblock()) {
switch(this.synchrovariable.type.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2();
break;
default :
codestream.dup();
break;
}
// only take the lock
codestream.monitorenter();
codestream.monitorexit();
if (this.scope != currentscope) {
codestream.exituserscope(this.scope);
}
} else {
// enter the monitor
codestream.store(this.synchrovariable, true);
codestream.addvariable(this.synchrovariable);
codestream.monitorenter();

// generate  the body of the synchronized block
enteranyexceptionhandler(codestream);
this.block.generatecode(this.scope, codestream);
if (this.scope != currentscope) {
// close all locals defined in the synchronized block except the secret local
codestream.exituserscope(this.scope, this.synchrovariable);
}

branchlabel endlabel = new branchlabel(codestream);
if ((this.bits & astnode.blockexit) == 0) {
codestream.load(this.synchrovariable);
codestream.monitorexit();
exitanyexceptionhandler();
codestream.goto_(endlabel);
enteranyexceptionhandler(codestream);
}
// generate the body of the exception handler
codestream.pushexceptiononstack(this.scope.getjavalangthrowable());
if (this.presynchronizedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.presynchronizedinitstateindex);
}
placeallanyexceptionhandler();
codestream.load(this.synchrovariable);
codestream.monitorexit();
exitanyexceptionhandler();
codestream.athrow();
// may loose some local variable initializations : affecting the local variable attributes
if (this.mergedsynchronizedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedsynchronizedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedsynchronizedinitstateindex);
}
if (this.scope != currentscope) {
codestream.removevariable(this.synchrovariable);
}
if ((this.bits & astnode.blockexit) == 0) {
endlabel.place();
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* @@see subroutinestatement#generatesubroutineinvocation(blockscope, codestream, object, int, localvariablebinding)
*/
public boolean generatesubroutineinvocation(blockscope currentscope, codestream codestream, object targetlocation, int stateindex, localvariablebinding secretlocal) {
codestream.load(this.synchrovariable);
codestream.monitorexit();
exitanyexceptionhandler();
return false;
}

public void resolve(blockscope upperscope) {
// special scope for secret locals optimization.
this.scope = new blockscope(upperscope);
typebinding type = this.expression.resolvetype(this.scope);
if (type == null)
return;
switch (type.id) {
case t_boolean :
case t_char :
case t_float :
case t_double :
case t_byte :
case t_short :
case t_int :
case t_long :
this.scope.problemreporter().invalidtypetosynchronize(this.expression, type);
break;
case t_void :
this.scope.problemreporter().illegalvoidexpression(this.expression);
break;
case t_null :
this.scope.problemreporter().invalidnulltosynchronize(this.expression);
break;
}
//continue even on errors in order to have the tc done into the statements
this.synchrovariable = new localvariablebinding(secretlocaldeclarationname, type, classfileconstants.accdefault, false);
this.scope.addlocalvariable(this.synchrovariable);
this.synchrovariable.setconstant(constant.notaconstant); // not inlinable
this.expression.computeconversion(this.scope, type, type);
this.block.resolveusing(this.scope);
}

public stringbuffer printstatement(int indent, stringbuffer output) {
printindent(indent, output);
output.append("synchronized ("); //$non-nls-1$
this.expression.printexpression(0, output).append(')');
output.append('\n');
return this.block.printstatement(indent + 1, output);
}

public void traverse(astvisitor visitor, blockscope blockscope) {
if (visitor.visit(this, blockscope)) {
this.expression.traverse(visitor, this.scope);
this.block.traverse(visitor, this.scope);
}
visitor.endvisit(this, blockscope);
}
}
