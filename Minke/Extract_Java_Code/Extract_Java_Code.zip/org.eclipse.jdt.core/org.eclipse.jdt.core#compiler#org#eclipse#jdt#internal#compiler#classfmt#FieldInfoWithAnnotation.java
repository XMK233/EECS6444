/*******************************************************************************
* copyright (c) 2005, 2009 bea systems, inc.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*    tyeung@@bea.com - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

public final class fieldinfowithannotation extends fieldinfo {
private annotationinfo[] annotations;

fieldinfowithannotation(fieldinfo info, annotationinfo[] annos) {
super(info.reference, info.constantpooloffsets, info.structoffset);
this.accessflags = info.accessflags;
this.attributebytes = info.attributebytes;
this.constant = info.constant;
this.constantpooloffsets = info.constantpooloffsets;
this.descriptor = info.descriptor;
this.name = info.name;
this.signature = info.signature;
this.signatureutf8offset = info.signatureutf8offset;
this.tagbits = info.tagbits;
this.wrappedconstantvalue = info.wrappedconstantvalue;
this.annotations = annos;
}
public org.eclipse.jdt.internal.compiler.env.ibinaryannotation[] getannotations() {
return this.annotations;
}
protected void initialize() {
for (int i = 0, max = this.annotations.length; i < max; i++)
this.annotations[i].initialize();
super.initialize();
}
protected void reset() {
if (this.annotations != null)
for (int i = 0, max = this.annotations.length; i < max; i++)
this.annotations[i].reset();
super.reset();
}
public string tostring() {
stringbuffer buffer = new stringbuffer(getclass().getname());
if (this.annotations != null) {
buffer.append('\n');
for (int i = 0; i < this.annotations.length; i++) {
buffer.append(this.annotations[i]);
buffer.append('\n');
}
}
tostringcontent(buffer);
return buffer.tostring();
}
}
