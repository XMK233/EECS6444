package org.eclipse.jdt.internal.compiler;
/*
* (c) copyright ibm corp. 2000, 2001.
* all rights reserved.
*/

import org.eclipse.jdt.internal.compiler.*;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;

public interface iproblem {

// problem categories
final int typerelated = 0x01000000;
final int fieldrelated = 0x02000000;
final int methodrelated = 0x04000000;
final int constructorrelated = 0x08000000;
final int importrelated = 0x10000000;
final int internal = 0x20000000;
final int ignorecategoriesmask = 0xffffff;
final int unclassifiedproblem = 0;

// types
final int objecthasnosuperclass = typerelated + 1;
final int undefinedtype = typerelated + 2;
final int notvisibletype = typerelated + 3;
final int ambiguoustype = typerelated + 4;
final int usingdeprecatedtype = typerelated + 5;
final int internaltypenameprovided = typerelated + 6;

// type compatibilities
final int incompatibletypesinequalityoperator = typerelated + 15;
final int incompatibletypesinconditionaloperator = typerelated + 16;
final int typemismatch = typerelated + 17;

// inner classes
final int missingenclosinginstanceforconstructorcall = typerelated + 20;
final int missingenclosinginstance = typerelated + 21;
final int incorrectenclosinginstancereference = typerelated + 22;
final int illegalenclosinginstancespecification = typerelated + 23;
final int cannotdefinestaticinitializerinlocaltype = internal + 24;
final int outerlocalmustbefinal = internal + 25;
final int cannotdefineinterfaceinlocaltype = internal + 26;
final int illegalprimitiveorarraytypeforenclosinginstance = typerelated + 27;
final int anonymousclasscannotextendfinalclass = typerelated + 29;

// variables
final int undefinedname = 50;
final int uninitializedlocalvariable = internal + 51;
final int variabletypecannotbevoid = internal + 52;
final int variabletypecannotbevoidarray = internal + 53;
final int cannotallocatevoidarray = internal + 54;
// local variables
final int redefinedlocal = internal + 55;
final int redefinedargument = internal + 56;
final int duplicatefinallocalinitialization = internal + 57;
// final local variables
final int finalouterlocalassignment = internal + 60;
final int localvariableisneverused = internal + 61;
final int argumentisneverused = internal + 62;
final int bytecodeexceeds64klimit = internal + 63;
final int bytecodeexceeds64klimitforclinit = internal + 64;
final int toomanyargumentslots = internal + 65;
final int toomanylocalvariableslots = internal + 66;

// fields
final int undefinedfield = fieldrelated + 70;
final int notvisiblefield = fieldrelated + 71;
final int ambiguousfield = fieldrelated + 72;
final int usingdeprecatedfield = fieldrelated + 73;
final int nonstaticfieldfromstaticinvocation = fieldrelated + 74;
final int referencetoforwardfield = fieldrelated + internal + 75;

// blank final fields
final int finalfieldassignment = fieldrelated + 80;
final int uninitializedblankfinalfield = fieldrelated + 81;
final int duplicateblankfinalfieldinitialization = fieldrelated + 82;

// methods
final int undefinedmethod = methodrelated + 100;
final int notvisiblemethod = methodrelated + 101;
final int ambiguousmethod = methodrelated + 102;
final int usingdeprecatedmethod = methodrelated + 103;
final int directinvocationofabstractmethod = methodrelated + 104;
final int voidmethodreturnsvalue = methodrelated + 105;
final int methodreturnsvoid = methodrelated + 106;
final int methodrequiresbody = internal + methodrelated + 107;
final int shouldreturnvalue = internal + methodrelated + 108;
final int methodbutwithconstructorname = methodrelated + 110;
final int missingreturntype = typerelated + 111;
final int bodyfornativemethod = internal + methodrelated + 112;
final int bodyforabstractmethod = internal + methodrelated + 113;
final int nomessagesendonbasetype = methodrelated + 114;
final int parametermismatch = methodrelated + 115;
final int nomessagesendonarraytype = methodrelated + 116;

// constructors
final int undefinedconstructor = constructorrelated + 130;
final int notvisibleconstructor = constructorrelated + 131;
final int ambiguousconstructor = constructorrelated + 132;
final int usingdeprecatedconstructor = constructorrelated + 133;
// explicit constructor calls
final int instancefieldduringconstructorinvocation = constructorrelated + 135;
final int instancemethodduringconstructorinvocation = constructorrelated + 136;
final int recursiveconstructorinvocation = constructorrelated + 137;
final int thissuperduringconstructorinvocation = constructorrelated + 138;

// expressions
final int arrayreferencerequired = internal + 150;
final int noimplicitstringconversionforchararrayexpression = internal + 151;
// constant expressions
final int stringconstantisexceedingutf8limit = internal + 152;
final int nonconstantexpression = 153;
final int numericvalueoutofrange = internal + 154;
// cast expressions
final int illegalcast = typerelated + 156;
// allocations
final int invalidclassinstantiation = typerelated + 157;
final int cannotdefinedimensionexpressionswithinit = internal + 158;
final int mustdefineeitherdimensionexpressionsorinitializer = internal + 159;
// operators
final int invalidoperator = internal + 160;
// statements
final int codecannotbereached = internal + 161;
final int cannotreturnininitializer = internal + 162;
final int initializermustcompletenormally = internal + 163;

// assert
final int invalidvoidexpression = internal + 164;
// try
final int maskedcatch = typerelated + 165;
final int duplicatedefaultcase = 166;
final int unreachablecatch = typerelated + methodrelated + 167;
final int unhandledexception = typerelated + 168;
// switch
final int incorrectswitchtype = typerelated + 169;
final int duplicatecase = fieldrelated + 170;
// labelled
final int duplicatelabel = internal + 171;
final int invalidbreak = internal + 172;
final int invalidcontinue = internal + 173;
final int undefinedlabel = internal + 174;
//synchronized
final int invalidtypetosynchronized = internal + 175;
final int invalidnulltosynchronized = internal + 176;
// throw
final int cannotthrownull = internal + 177;

// inner emulation
final int needtoemulatefieldreadaccess = fieldrelated + 190;
final int needtoemulatefieldwriteaccess = fieldrelated + 191;
final int needtoemulatemethodaccess = methodrelated + 192;
final int needtoemulateconstructoraccess = methodrelated + 193;

//inherited name hides enclosing name (sort of ambiguous)
final int inheritedmethodhidesenclosingname = methodrelated + 195;
final int inheritedfieldhidesenclosingname = fieldrelated + 196;
final int inheritedtypehidesenclosingname = typerelated + 197;

// miscellaneous
final int thisinstaticcontext = internal + 200;
final int staticmethodrequested = internal + methodrelated + 201;
final int illegaldimension = internal + 202;
final int invalidtypeexpression = internal + 203;
final int parsingerror = internal + 204;
final int parsingerrornosuggestion = internal + 205;
final int invalidunaryexpression = internal + 206;

// syntax errors
final int interfacecannothaveconstructors = internal + 207;
final int arrayconstantsonlyinarrayinitializers = internal + 208;
final int parsingerroronkeyword = internal + 209;
final int parsingerroronkeywordnosuggestion = internal + 210;

final int unmatchedbracket = internal + 220;
final int nofieldonbasetype = fieldrelated + 221;
final int invalidexpressionasstatement = internal + 222;

// scanner errors
final int endofsource = internal + 250;
final int invalidhexa = internal + 251;
final int invalidoctal = internal + 252;
final int invalidcharacterconstant = internal + 253;
final int invalidescape = internal + 254;
final int invalidinput = internal + 255;
final int invalidunicodeescape = internal + 256;
final int invalidfloat = internal + 257;
final int nullsourcestring = internal + 258;
final int unterminatedstring = internal + 259;
final int unterminatedcomment = internal + 260;

// type related problems
final int interfacecannothaveinitializers = typerelated + 300;
final int duplicatemodifierfortype = typerelated + 301;
final int illegalmodifierforclass = typerelated + 302;
final int illegalmodifierforinterface = typerelated + 303;
final int illegalmodifierformemberclass = typerelated + 304;
final int illegalmodifierformemberinterface = typerelated + 305;
final int illegalmodifierforlocalclass = typerelated + 306;

final int illegalmodifiercombinationfinalabstractforclass = typerelated + 308;
final int illegalvisibilitymodifierforinterfacemembertype = typerelated + 309;
final int illegalvisibilitymodifiercombinationformembertype = typerelated + 310;
final int illegalstaticmodifierformembertype = typerelated + 311;
final int superclassmustbeaclass = typerelated + 312;
final int classextendfinalclass = typerelated + 313;
final int duplicatesuperinterface = typerelated + 314;
final int superinterfacemustbeaninterface = typerelated + 315;
final int hierarchycircularityselfreference = typerelated + 316;
final int hierarchycircularity = typerelated + 317;
final int hidingenclosingtype = typerelated + 318;
final int duplicatenestedtype = typerelated + 319;
final int cannotthrowtype = typerelated + 320;
final int packagecollideswithtype = typerelated + 321;
final int typecollideswithpackage = typerelated + 322;
final int duplicatetypes = typerelated + 323;
final int isclasspathcorrect = typerelated + 324;
final int publicclassmustmatchfilename = typerelated + 325;
final int mustspecifypackage = 326;
final int hierarchyhasproblems = typerelated + 327;
final int packageisnotexpectedpackage = 328;

// final int invalidsuperclassbase = typerelated + 329; // reserved to 334 included
final int superclassnotfound =  typerelated + 329 + problemreasons.notfound; // typerelated + 330
final int superclassnotvisible =  typerelated + 329 + problemreasons.notvisible; // typerelated + 331
final int superclassambiguous =  typerelated + 329 + problemreasons.ambiguous; // typerelated + 332
final int superclassinternalnameprovided =  typerelated + 329 + problemreasons.internalnameprovided; // typerelated + 333
final int superclassinheritednamehidesenclosingname =  typerelated + 329 + problemreasons.inheritednamehidesenclosingname; // typerelated + 334

// final int invalidinterfacebase = typerelated + 334; // reserved to 339 included
final int interfacenotfound =  typerelated + 334 + problemreasons.notfound; // typerelated + 335
final int interfacenotvisible =  typerelated + 334 + problemreasons.notvisible; // typerelated + 336
final int interfaceambiguous =  typerelated + 334 + problemreasons.ambiguous; // typerelated + 337
final int interfaceinternalnameprovided =  typerelated + 334 + problemreasons.internalnameprovided; // typerelated + 338
final int interfaceinheritednamehidesenclosingname =  typerelated + 334 + problemreasons.inheritednamehidesenclosingname; // typerelated + 339

// field related problems
final int duplicatefield = fieldrelated + 340;
final int duplicatemodifierforfield = fieldrelated + 341;
final int illegalmodifierforfield = fieldrelated + 342;
final int illegalmodifierforinterfacefield = fieldrelated + 343;
final int illegalvisibilitymodifiercombinationforfield = fieldrelated + 344;
final int illegalmodifiercombinationfinalvolatileforfield = fieldrelated + 345;
final int unexpectedstaticmodifierforfield = fieldrelated + 346;

// final int fieldtypeproblembase = fieldrelated + 349; //reserved to 354
final int fieldtypenotfound =  fieldrelated + 349 + problemreasons.notfound; // fieldrelated + 350
final int fieldtypenotvisible =  fieldrelated + 349 + problemreasons.notvisible; // fieldrelated + 351
final int fieldtypeambiguous =  fieldrelated + 349 + problemreasons.ambiguous; // fieldrelated + 352
final int fieldtypeinternalnameprovided =  fieldrelated + 349 + problemreasons.internalnameprovided; // fieldrelated + 353
final int fieldtypeinheritednamehidesenclosingname =  fieldrelated + 349 + problemreasons.inheritednamehidesenclosingname; // fieldrelated + 354

// method related problems
final int duplicatemethod = methodrelated + 355;
final int illegalmodifierforargument = methodrelated + 356;
final int duplicatemodifierformethod = methodrelated + 357;
final int illegalmodifierformethod = methodrelated + 358;
final int illegalmodifierforinterfacemethod = methodrelated + 359;
final int illegalvisibilitymodifiercombinationformethod = methodrelated + 360;
final int unexpectedstaticmodifierformethod = methodrelated + 361;
final int illegalabstractmodifiercombinationformethod = methodrelated + 362;
final int abstractmethodinabstractclass = methodrelated + 363;
final int argumenttypecannotbevoid = methodrelated + 364;
final int argumenttypecannotbevoidarray = methodrelated + 365;
final int returntypecannotbevoidarray = methodrelated + 366;
final int nativemethodscannotbestrictfp = methodrelated + 367;

//	final int argumentproblembase = methodrelated + 369; // reserved to 374 included.
final int argumenttypenotfound =  methodrelated + 369 + problemreasons.notfound; // methodrelated + 370
final int argumenttypenotvisible =  methodrelated + 369 + problemreasons.notvisible; // methodrelated + 371
final int argumenttypeambiguous =  methodrelated + 369 + problemreasons.ambiguous; // methodrelated + 372
final int argumenttypeinternalnameprovided =  methodrelated + 369 + problemreasons.internalnameprovided; // methodrelated + 373
final int argumenttypeinheritednamehidesenclosingname =  methodrelated + 369 + problemreasons.inheritednamehidesenclosingname; // methodrelated + 374

//	final int exceptiontypeproblembase = methodrelated + 374; // reserved to 379 included.
final int exceptiontypenotfound =  methodrelated + 374 + problemreasons.notfound; // methodrelated + 375
final int exceptiontypenotvisible =  methodrelated + 374 + problemreasons.notvisible; // methodrelated + 376
final int exceptiontypeambiguous =  methodrelated + 374 + problemreasons.ambiguous; // methodrelated + 377
final int exceptiontypeinternalnameprovided =  methodrelated + 374 + problemreasons.internalnameprovided; // methodrelated + 378
final int exceptiontypeinheritednamehidesenclosingname =  methodrelated + 374 + problemreasons.inheritednamehidesenclosingname; // methodrelated + 379

//	final int returntypeproblembase = methodrelated + 379;
final int returntypenotfound =  methodrelated + 379 + problemreasons.notfound; // methodrelated + 380
final int returntypenotvisible =  methodrelated + 379 + problemreasons.notvisible; // methodrelated + 381
final int returntypeambiguous =  methodrelated + 379 + problemreasons.ambiguous; // methodrelated + 382
final int returntypeinternalnameprovided =  methodrelated + 379 + problemreasons.internalnameprovided; // methodrelated + 383
final int returntypeinheritednamehidesenclosingname =  methodrelated + 379 + problemreasons.inheritednamehidesenclosingname; // methodrelated + 384

// import related problems
final int conflictingimport = importrelated + 385;
final int duplicateimport = importrelated + 386;
final int cannotimportpackage = importrelated + 387;

//	final int importproblembase = importrelated + 389;
final int importnotfound =  importrelated + 389 + problemreasons.notfound; // importrelated + 390
final int importnotvisible =  importrelated + 389 + problemreasons.notvisible; // importrelated + 391
final int importambiguous =  importrelated + 389 + problemreasons.ambiguous; // importrelated + 392
final int importinternalnameprovided =  importrelated + 389 + problemreasons.internalnameprovided; // importrelated + 393
final int importinheritednamehidesenclosingname =  importrelated + 389 + problemreasons.inheritednamehidesenclosingname; // importrelated + 394

// local variable related problems
final int duplicatemodifierforvariable = methodrelated + 395;
final int illegalmodifierforvariable = methodrelated + 396;

// method verifier problems
final int abstractmethodmustbeimplemented = methodrelated + 400;
final int finalmethodcannotbeoverridden = methodrelated + 401;
final int incompatibleexceptioninthrowsclause = methodrelated + 402;
final int incompatibleexceptionininheritedmethodthrowsclause = methodrelated + 403;
final int incompatiblereturntype = methodrelated + 404;
final int inheritedmethodreducesvisibility = methodrelated + 405;
final int cannotoverrideastaticmethodwithaninstancemethod = methodrelated + 406;
final int cannothideaninstancemethodwithastaticmethod = methodrelated + 407;
final int staticinheritedmethodconflicts = methodrelated + 408;
final int methodreducesvisibility = methodrelated + 409;
final int overridingnonvisiblemethod = methodrelated + 410;
final int abstractmethodcannotbeoverridden = methodrelated + 411;
final int overridingdeprecatedmethod = methodrelated + 412;

// code snippet support
final int codesnippetmissingclass = internal + 420;
final int codesnippetmissingmethod = internal + 421;
final int nonexternalizedstringliteral = internal + 261;
final int cannotusesuperincodesnippet = internal + 422;

//constant pool
final int toomanyconstantsinconstantpool = internal + 430;

// 1.4 features
// assertion warning
final int useassertasanidentifier = internal + 440;


final int error = 1; // when bit is set: problem is error, if not it is a warning

/**
* answer back the original arguments recorded into the problem.
*/
string[] getarguments();

/**
*
* @@return int
*/
int getid();

/**
* answer a localized, human-readable message string which describes the problem.
*/
string getmessage();
/**
* answer the file name in which the problem was found.
*/
char[] getoriginatingfilename();

/**
* answer the end position of the problem (inclusive), or -1 if unknown.
*/
int getsourceend();

/**
* answer the line number in source where the problem begins.
*/
int getsourcelinenumber();

/**
* answer the start position of the problem (inclusive), or -1 if unknown.
*/
int getsourcestart();

/**
* helper method: checks the severity to see if the error bit is set.
*/
boolean iserror();

/**
* helper method: checks the severity to see if the error bit is not set.
*/
boolean iswarning();

/**
* set the end position of the problem (inclusive), or -1 if unknown.
*
* used for shifting problem positions.
*/
void setsourceend(int sourceend);

/**
* set the line number in source where the problem begins.
*/
void setsourcelinenumber(int linenumber);

/**
* set the start position of the problem (inclusive), or -1 if unknown.
*
* used for shifting problem positions.
*/
void setsourcestart(int sourcestart);
}
