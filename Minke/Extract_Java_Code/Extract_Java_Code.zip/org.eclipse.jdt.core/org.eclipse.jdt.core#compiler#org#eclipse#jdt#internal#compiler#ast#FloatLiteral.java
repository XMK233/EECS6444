/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.impl.floatconstant;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.util.floatutil;

public class floatliteral extends numberliteral {

float value;

public floatliteral(char[] token, int s, int e) {
super(token, s, e);
}

public void computeconstant() {
float computedvalue;
try {
computedvalue = float.valueof(string.valueof(this.source));
} catch (numberformatexception e) {
// hex floating point literal
// being rejected by 1.4 libraries where float.valueof(...) doesn't handle hex decimal floats
try {
float v = floatutil.valueofhexfloatliteral(this.source);
if (v == float.positive_infinity) {
// error: the number is too large to represent
return;
}
if (float.isnan(v)) {
// error: the number is too small to represent
return;
}
this.value = v;
this.constant = floatconstant.fromvalue(v);
} catch (numberformatexception e1) {
// if the computation of the constant fails
}
return;
}
final float floatvalue = computedvalue.floatvalue();
if (floatvalue > float.max_value) {
// error: the number is too large to represent
return;
}
if (floatvalue < float.min_value) {
// see 1f6iguu
// a true 0 only has '0' and '.' in mantissa
// 1.0e-5000d is non-zero, but underflows to 0
boolean ishexadecimal = false;
label : for (int i = 0; i < this.source.length; i++) { //it is welled formated so just test against '0' and potential . d d
switch (this.source[i]) {
case '0' :
case '.' :
break;
case 'x' :
case 'x' :
ishexadecimal = true;
break;
case 'e' :
case 'e' :
case 'f' :
case 'f' :
case 'd' :
case 'd' :
if (ishexadecimal) {
return;
}
// starting the exponent - mantissa is all zero
// no exponent - mantissa is all zero
break label;
case 'p' :
case 'p' :
break label;
default :
// error: the number is too small to represent
return;
}
}
}
this.value = floatvalue;
this.constant = floatconstant.fromvalue(this.value);
}

/**
* code generation for float literal
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
if (valuerequired) {
codestream.generateconstant(this.constant, this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public typebinding literaltype(blockscope scope) {
return typebinding.float;
}

public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
