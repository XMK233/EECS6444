/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

public class integercache {
public int keytable[];
public int valuetable[];
int elementsize;
int threshold;
/**
* constructs a new, empty hashtable. a default capacity and
* load factor is used. note that the hashtable will automatically
* grow when it gets full.
*/
public integercache() {
this(13);
}
/**
* constructs a new, empty hashtable with the specified initial
* capacity.
* @@param initialcapacity int
*  the initial number of buckets
*/
public integercache(int initialcapacity) {
this.elementsize = 0;
this.threshold = (int) (initialcapacity * 0.66);
this.keytable = new int[initialcapacity];
this.valuetable = new int[initialcapacity];
}
/**
* clears the hash table so that it has no more elements in it.
*/
public void clear() {
for (int i = this.keytable.length; --i >= 0;) {
this.keytable[i] = 0;
this.valuetable[i] = 0;
}
this.elementsize = 0;
}
/** returns true if the collection contains an element for the key.
*
* @@param key <code>double</code> the key that we are looking for
* @@return boolean
*/
public boolean containskey(int key) {
int index = hash(key), length = this.keytable.length;
while ((this.keytable[index] != 0) || ((this.keytable[index] == 0) &&(this.valuetable[index] != 0))) {
if (this.keytable[index] == key)
return true;
if (++index == length) {
index = 0;
}
}
return false;
}
/**
* return a hashcode for the value of the key parameter.
* @@param key int
* @@return int the hash code corresponding to the key value
*/
public int hash(int key) {
return (key & 0x7fffffff) % this.keytable.length;
}
/**
* puts the specified element into the hashtable, using the specified
* key.  the element may be retrieved by doing a get() with the same key.
*
* @@param key <code>int</code> the specified key in the hashtable
* @@param value <code>int</code> the specified element
* @@return int value
*/
public int put(int key, int value) {
int index = hash(key), length = this.keytable.length;
while ((this.keytable[index] != 0) || ((this.keytable[index] == 0) && (this.valuetable[index] != 0))) {
if (this.keytable[index] == key)
return this.valuetable[index] = value;
if (++index == length) {
index = 0;
}
}
this.keytable[index] = key;
this.valuetable[index] = value;

// assumes the threshold is never equal to the size of the table
if (++this.elementsize > this.threshold) {
rehash();
}
return value;
}
/**
* puts the specified element into the hashtable if absent, using the specified
* key.  the element may be retrieved by doing a get() with the same key.
*
* @@param key <code>int</code> the specified key in the hashtable
* @@param value <code>int</code> the specified element
* @@return int value
*/
public int putifabsent(int key, int value) {
int index = hash(key), length = this.keytable.length;
while ((this.keytable[index] != 0) || ((this.keytable[index] == 0) && (this.valuetable[index] != 0))) {
if (this.keytable[index] == key)
return this.valuetable[index];
if (++index == length) {
index = 0;
}
}
this.keytable[index] = key;
this.valuetable[index] = value;

// assumes the threshold is never equal to the size of the table
if (++this.elementsize > this.threshold) {
rehash();
}
return -value; // negative when added, assumes value is > 0
}
/**
* rehashes the content of the table into a bigger table.
* this method is called automatically when the hashtable's
* size exceeds the threshold.
*/
private void rehash() {
integercache newhashtable = new integercache(this.keytable.length * 2);
for (int i = this.keytable.length; --i >= 0;) {
int key = this.keytable[i];
int value = this.valuetable[i];
if ((key != 0) || ((key == 0) && (value != 0))) {
newhashtable.put(key, value);
}
}
this.keytable = newhashtable.keytable;
this.valuetable = newhashtable.valuetable;
this.threshold = newhashtable.threshold;
}
/**
* returns the number of elements contained in the hashtable.
*
* @@return <code>int</code> the size of the table
*/
public int size() {
return this.elementsize;
}
/**
* converts to a rather lengthy string.
*
* @@return string the ascii representation of the receiver
*/
public string tostring() {
int max = size();
stringbuffer buf = new stringbuffer();
buf.append("{"); //$non-nls-1$
for (int i = 0; i < max; ++i) {
if ((this.keytable[i] != 0) || ((this.keytable[i] == 0) && (this.valuetable[i] != 0))) {
buf.append(this.keytable[i]).append("->").append(this.valuetable[i]); //$non-nls-1$
}
if (i < max) {
buf.append(", "); //$non-nls-1$
}
}
buf.append("}"); //$non-nls-1$
return buf.tostring();
}
}
