/*******************************************************************************
* copyright (c) 2005, 2006 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.ast.branchstatement;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;

public class completiononbrankstatementlabel extends branchstatement {
public static final int break = 1;
public static final int continue = 2;

private int kind;
public char[][] possiblelabels;

public completiononbrankstatementlabel(int kind, char[] l, int s, int e, char[][] possiblelabels) {
super(l, s, e);
this.kind = kind;
this.possiblelabels = possiblelabels;
}

public flowinfo analysecode(blockscope currentscope,
flowcontext flowcontext, flowinfo flowinfo) {
// is never called
return null;
}

public void resolve(blockscope scope) {
throw new completionnodefound(this, scope);
}
public stringbuffer printstatement(int indent, stringbuffer output) {
printindent(indent, output);
if(this.kind == continue) {
output.append("continue "); //$non-nls-1$
} else {
output.append("break "); //$non-nls-1$
}
output.append("<completeonlabel:"); //$non-nls-1$
output.append(this.label);
return output.append(">;"); //$non-nls-1$
}

}
