/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.flow.exceptionhandlingflowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.flow.initializationflowcontext;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.extracompilermodifiers;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeconstants;
import org.eclipse.jdt.internal.compiler.parser.parser;
import org.eclipse.jdt.internal.compiler.problem.abortmethod;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;

public class methoddeclaration extends abstractmethoddeclaration {

public typereference returntype;
public typeparameter[] typeparameters;

/**
* methoddeclaration constructor comment.
*/
public methoddeclaration(compilationresult compilationresult) {
super(compilationresult);
}

public void analysecode(classscope classscope, initializationflowcontext initializationcontext, flowinfo flowinfo) {
// starting of the code analysis for methods
if (this.ignorefurtherinvestigation)
return;
try {
if (this.binding == null)
return;

if (!this.binding.isused() && !this.binding.isabstract()) {
if (this.binding.isprivate()
|| (((this.binding.modifiers & (extracompilermodifiers.accoverriding|extracompilermodifiers.accimplementing)) == 0)
&& this.binding.isorenclosedbyprivatetype())) {
if (!classscope.referencecompilationunit().compilationresult.hassyntaxerror) {
this.scope.problemreporter().unusedprivatemethod(this);
}
}
}

// skip enum implicit methods
if (this.binding.declaringclass.isenum() && (this.selector == typeconstants.values || this.selector == typeconstants.valueof))
return;

// may be in a non necessary <clinit> for innerclass with static final constant fields
if (this.binding.isabstract() || this.binding.isnative())
return;

exceptionhandlingflowcontext methodcontext =
new exceptionhandlingflowcontext(
initializationcontext,
this,
this.binding.thrownexceptions,
null,
this.scope,
flowinfo.dead_end);

// tag parameters as being set
if (this.arguments != null) {
for (int i = 0, count = this.arguments.length; i < count; i++) {
flowinfo.markasdefinitelyassigned(this.arguments[i].binding);
}
}
// propagate to statements
if (this.statements != null) {
int complaintlevel = (flowinfo.reachmode() & flowinfo.unreachable) == 0 ? statement.not_complained : statement.complained_fake_reachable;
for (int i = 0, count = this.statements.length; i < count; i++) {
statement stat = this.statements[i];
if ((complaintlevel = stat.complainifunreachable(flowinfo, this.scope, complaintlevel)) < statement.complained_unreachable) {
flowinfo = stat.analysecode(this.scope, methodcontext, flowinfo);
}
}
}
// check for missing returning path
typebinding returntypebinding = this.binding.returntype;
if ((returntypebinding == typebinding.void) || isabstract()) {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0) {
this.bits |= astnode.needfreereturn;
}
} else {
if (flowinfo != flowinfo.dead_end) {
this.scope.problemreporter().shouldreturn(returntypebinding, this);
}
}
// check unreachable catch blocks
methodcontext.complainifunusedexceptionhandlers(this);
// check unused parameters
this.scope.checkunusedparameters(this.binding);
} catch (abortmethod e) {
this.ignorefurtherinvestigation = true;
}
}

public boolean ismethod() {
return true;
}

public void parsestatements(parser parser, compilationunitdeclaration unit) {
//fill up the method body with statement
parser.parse(this, unit);
}

public stringbuffer printreturntype(int indent, stringbuffer output) {
if (this.returntype == null) return output;
return this.returntype.printexpression(0, output).append(' ');
}

public void resolvestatements() {
// ========= abort on fatal error =============
if (this.returntype != null && this.binding != null) {
this.returntype.resolvedtype = this.binding.returntype;
// record the return type binding
}
// check if method with constructor name
if (charoperation.equals(this.scope.enclosingsourcetype().sourcename, this.selector)) {
this.scope.problemreporter().methodwithconstructorname(this);
}

if (this.typeparameters != null) {
for (int i = 0, length = this.typeparameters.length; i < length; i++) {
this.typeparameters[i].resolve(this.scope);
}
}

// check @@override annotation
final compileroptions compileroptions = this.scope.compileroptions();
checkoverride: {
if (this.binding == null) break checkoverride;
long compliancelevel = compileroptions.compliancelevel;
if (compliancelevel < classfileconstants.jdk1_5) break checkoverride;
int bindingmodifiers = this.binding.modifiers;
boolean hasoverrideannotation = (this.binding.tagbits & tagbits.annotationoverride) != 0;
boolean hasunresolvedarguments = (this.binding.tagbits & tagbits.hasunresolvedarguments) != 0;
if (hasoverrideannotation  && !hasunresolvedarguments) {
// no static method is considered overriding
if ((bindingmodifiers & (classfileconstants.accstatic|extracompilermodifiers.accoverriding)) == extracompilermodifiers.accoverriding)
break checkoverride;
//	in 1.5, strictly for overriding superclass method
//	in 1.6 and above, also tolerate implementing interface method
if (compliancelevel >= classfileconstants.jdk1_6
&& ((bindingmodifiers & (classfileconstants.accstatic|extracompilermodifiers.accimplementing)) == extracompilermodifiers.accimplementing))
break checkoverride;
// claims to override, and doesn't actually do so
this.scope.problemreporter().methodmustoverride(this, compliancelevel);
} else {
//in case of  a concrete class method, we have to check if it overrides(in 1.5 and above) or implements a method(1.6 and above).
//also check if the method has a signature that is override-equivalent to that of any public method declared in object.
if (!this.binding.declaringclass.isinterface()){
if((bindingmodifiers & (classfileconstants.accstatic|extracompilermodifiers.accoverriding)) == extracompilermodifiers.accoverriding) {
this.scope.problemreporter().missingoverrideannotation(this);
} else {
if(compliancelevel >= classfileconstants.jdk1_6
&& compileroptions.reportmissingoverrideannotationforinterfacemethodimplementation
&& this.binding.isimplementing()) {
// actually overrides, but did not claim to do so
this.scope.problemreporter().missingoverrideannotationforinterfacemethodimplementation(this);
}

}
}
else {	//for 1.6 and above only
//in case of a interface class method, we have to check if it overrides a method (isimplementing returns true in case it overrides)
//also check if the method has a signature that is override-equivalent to that of any public method declared in object.
if(compliancelevel >= classfileconstants.jdk1_6
&& compileroptions.reportmissingoverrideannotationforinterfacemethodimplementation
&& (((bindingmodifiers & (classfileconstants.accstatic|extracompilermodifiers.accoverriding)) == extracompilermodifiers.accoverriding) || this.binding.isimplementing())){
// actually overrides, but did not claim to do so
this.scope.problemreporter().missingoverrideannotationforinterfacemethodimplementation(this);
}
}
}
}

// by grammatical construction, interface methods are always abstract
switch (typedeclaration.kind(this.scope.referencetype().modifiers)) {
case typedeclaration.enum_decl :
if (this.selector == typeconstants.values) break;
if (this.selector == typeconstants.valueof) break;
//$fall-through$
case typedeclaration.class_decl :
// if a method has an semicolon body and is not declared as abstract==>error
// native methods may have a semicolon body
if ((this.modifiers & extracompilermodifiers.accsemicolonbody) != 0) {
if ((this.modifiers & classfileconstants.accnative) == 0)
if ((this.modifiers & classfileconstants.accabstract) == 0)
this.scope.problemreporter().methodneedbody(this);
} else {
// the method has a body --> abstract native modifiers are forbiden
if (((this.modifiers & classfileconstants.accnative) != 0) || ((this.modifiers & classfileconstants.accabstract) != 0))
this.scope.problemreporter().methodneedingnobody(this);
}
}
super.resolvestatements();

// tagbits.overridingmethodwithsupercall is set during the resolvestatements() call
if (compileroptions.getseverity(compileroptions.overridingmethodwithoutsuperinvocation) != problemseverities.ignore) {
if (this.binding != null) {
int bindingmodifiers = this.binding.modifiers;
if ((bindingmodifiers & (extracompilermodifiers.accoverriding|extracompilermodifiers.accimplementing)) == extracompilermodifiers.accoverriding
&& (this.bits & astnode.overridingmethodwithsupercall) == 0) {
this.scope.problemreporter().overridesmethodwithoutsuperinvocation(this.binding);
}
}
}
}

public void traverse(
astvisitor visitor,
classscope classscope) {

if (visitor.visit(this, classscope)) {
if (this.javadoc != null) {
this.javadoc.traverse(visitor, this.scope);
}
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, this.scope);
}
if (this.typeparameters != null) {
int typeparameterslength = this.typeparameters.length;
for (int i = 0; i < typeparameterslength; i++) {
this.typeparameters[i].traverse(visitor, this.scope);
}
}
if (this.returntype != null)
this.returntype.traverse(visitor, this.scope);
if (this.arguments != null) {
int argumentlength = this.arguments.length;
for (int i = 0; i < argumentlength; i++)
this.arguments[i].traverse(visitor, this.scope);
}
if (this.thrownexceptions != null) {
int thrownexceptionslength = this.thrownexceptions.length;
for (int i = 0; i < thrownexceptionslength; i++)
this.thrownexceptions[i].traverse(visitor, this.scope);
}
if (this.statements != null) {
int statementslength = this.statements.length;
for (int i = 0; i < statementslength; i++)
this.statements[i].traverse(visitor, this.scope);
}
}
visitor.endvisit(this, classscope);
}
public typeparameter[] typeparameters() {
return this.typeparameters;
}
}
