/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.invalidinputexception;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;

/**
* parser specialized for decoding javadoc annotations
*/
public class annotationparser {

// recognized tags
public static final char[] tag_deprecated = "deprecated".tochararray(); //$non-nls-1$
public static final char[] tag_param = "param".tochararray(); //$non-nls-1$
public static final char[] tag_return = "return".tochararray(); //$non-nls-1$
public static final char[] tag_throws = "throws".tochararray(); //$non-nls-1$
public static final char[] tag_exception = "exception".tochararray(); //$non-nls-1$
public static final char[] tag_see = "see".tochararray(); //$non-nls-1$

// tags expected positions
public final static int ordered_tags_number = 3;
public final static int param_tag_expected_order = 0;
public final static int throws_tag_expected_order = 1;
public final static int see_tag_expected_order = 2;

// public fields
public annotation annotation;
public boolean checkannotation;
public scanner scanner;

// private fields
private int currenttokentype = -1;
private parser sourceparser;
private int index, tagsourcestart, tagsourceend, lineend;
private char[] source;

// identifier stack
protected int identifierptr;
protected char[][] identifierstack;
protected int identifierlengthptr;
protected int[] identifierlengthstack;
protected long[] identifierpositionstack;
// ast stack
protected static int aststackincrement = 10;
protected int astptr;
protected astnode[] aststack;
protected int astlengthptr;
protected int[] astlengthstack;

annotationparser(parser sourceparser) {
this.sourceparser = sourceparser;
this.checkannotation = this.sourceparser.options.getseverity(compileroptions.invalidannotation) != problemseverities.ignore;
this.scanner = new scanner(false, false, false, classfileconstants.jdk1_3, null, null);
this.identifierstack = new char[10][];
this.identifierpositionstack = new long[10];
this.identifierlengthstack = new int[20];
this.aststack = new astnode[20];
this.astlengthstack = new int[30];
}

/* (non-javadoc)
* returns true if tag @@deprecated is present in annotation.
*
* if annotation checking is enabled, will also construct an annotation node, which will be stored into parser.annotation
* slot for being consumed later on.
*/
public boolean checkdeprecation(int annotationstart, int annotationend) {

boolean founddeprecated = false;
try {
this.source = this.sourceparser.scanner.source;
if (this.checkannotation) {
this.annotation = new annotation(annotationstart, annotationend);
this.astlengthptr = -1;
this.astptr = -1;
this.currenttokentype = -1;
} else {
this.annotation = null;
}

int firstlinenumber = this.sourceparser.scanner.getlinenumber(annotationstart);
int lastlinenumber = this.sourceparser.scanner.getlinenumber(annotationend);

// scan line per line, since tags must be at beginning of lines only
nextline : for (int line = firstlinenumber; line <= lastlinenumber; line++) {
int linestart = line == firstlinenumber
? annotationstart + 3 // skip leading /**
: this.sourceparser.scanner.getlinestart(line);
this.index = linestart;
this.lineend = line == lastlinenumber
? annotationend - 2 // remove trailing */
: this.sourceparser.scanner.getlineend(line);
while (this.index < this.lineend) {
char nextcharacter = readchar(); // consider unicodes
switch (nextcharacter) {
case '@@' :
if (!this.checkannotation) {
if ((readchar() == 'd') &&
(readchar() == 'e') &&
(readchar() == 'p') &&
(readchar() == 'r') &&
(readchar() == 'e') &&
(readchar() == 'c') &&
(readchar() == 'a') &&
(readchar() == 't') &&
(readchar() == 'e') &&
(readchar() == 'd')) {
// ensure the tag is properly ended: either followed by a space, a tab, line end or asterisk.
nextcharacter = readchar();
if (character.iswhitespace(nextcharacter) || nextcharacter == '*') {
founddeprecated = true;
break nextline; // done
}
}
continue nextline;
}
this.scanner.resetto(this.index, this.lineend);
this.currenttokentype = -1; // flush token cache at line begin
try {
int tk = readtokenandconsume();
this.tagsourcestart = this.scanner.getcurrenttokenstartposition();
this.tagsourceend = this.scanner.getcurrenttokenendposition();
switch (tk) {
case terminaltokens.tokennameidentifier :
char[] tag = this.scanner.getcurrentidentifiersource();
if (charoperation.equals(tag, tag_deprecated)) {
founddeprecated = true;
} else if (charoperation.equals(tag, tag_param)) {
parseparam();
} else if (charoperation.equals(tag, tag_exception)) {
parsethrows();
} else if (charoperation.equals(tag, tag_see)) {
parsesee();
}
break;
case terminaltokens.tokennamereturn :
parsereturn();
break;
case terminaltokens.tokennamethrows :
parsethrows();
break;
}
} catch (invalidinputexception e) {
consumetoken();
}
continue nextline;
case '*' :
break;
default :
if (!charoperation.iswhitespace(nextcharacter)) {
continue nextline;
}
}
}
}
} finally {
if (this.checkannotation) {
updateannotation();
}
this.source = null; // release source as soon as finished
}
return founddeprecated;
}

private void consumetoken() {
this.currenttokentype = -1; // flush token cache
}

private int getendposition() {
if (this.scanner.getcurrenttokenendposition() >= this.lineend) {
return this.lineend - 1;
} else {
return this.scanner.getcurrenttokenendposition();
}
}

/*
* parse argument in @@see tag method reference
*/
private annotationmessagesend parsearguments(typereference receiver) throws invalidinputexception {

int modulo = 0; // should be 2 for (type,type,...) or 3 for (type arg,type arg,...)
int itoken = 0;
char[] argname = null;
int ptr = astptr;
int lptr = astlengthptr;

// parse arguments declaration if method reference
nextarg : while (this.index < this.scanner.eofposition) {

// read argument type reference
typereference typeref;
try {
typeref = parsequalifiedname(false);
} catch (invalidinputexception e) {
break nextarg;
}
boolean firstarg = modulo == 0;
if (firstarg) { // verify position
if (itoken != 0)
break nextarg;
} else if ((itoken % modulo) != 0) {
break nextarg;
}
if (typeref == null) {
if (firstarg && this.currenttokentype == terminaltokens.tokennamerparen) {
annotationmessagesend msg = new annotationmessagesend(identifierstack[0], identifierpositionstack[0]);
msg.receiver = receiver;
return msg;
}
break nextarg;
}
int argstart = typeref.sourcestart;
int argend = typeref.sourceend;
itoken++;

// read possible array declaration
int dim = 0;
if (readtoken() == terminaltokens.tokennamelbracket) {
while (readtoken() == terminaltokens.tokennamelbracket) {
consumetoken();
if (readtoken() != terminaltokens.tokennamerbracket) {
break nextarg;
}
consumetoken();
dim++;
}
long pos = ((long) typeref.sourcestart) << 32 + typeref.sourceend;
if (typeref instanceof annotationsingletypereference) {
annotationsingletypereference singleref = (annotationsingletypereference) typeref;
typeref = new annotationarraysingletypereference(singleref.token, dim, pos);
} else {
annotationqualifiedtypereference qualifref = (annotationqualifiedtypereference) typeref;
typeref = new annotationarrayqualifiedtypereference(qualifref, dim);
}
}

// read argument name
if (readtoken() == terminaltokens.tokennameidentifier) {
consumetoken();
if (firstarg) { // verify position
if (itoken != 1)
break nextarg;
} else if ((itoken % modulo) != 1) {
break nextarg;
}
if (argname == null) { // verify that all arguments name are declared
if (!firstarg) {
break nextarg;
}
}
argname = this.scanner.getcurrentidentifiersource();
argend = this.scanner.getcurrenttokenendposition();
itoken++;
} else if (argname != null) { // verify that no argument name is declared
break nextarg;
}

// verify token position
if (firstarg) {
modulo = itoken + 1;
} else {
if ((itoken % modulo) != (modulo - 1)) {
break nextarg;
}
}

// read separator or end arguments declaration
int token = readtoken();
char[] name = argname == null ? new char[0] : argname;
if (token == terminaltokens.tokennamecomma) {
annotationargumentexpression expr = new annotationargumentexpression(name, argstart, argend, typeref);
pushonaststack(expr, firstarg);
consumetoken();
itoken++;
} else if (token == terminaltokens.tokennamerparen) {
annotationargumentexpression expr = new annotationargumentexpression(name, argstart, argend, typeref);
pushonaststack(expr, firstarg);
int size = astlengthstack[astlengthptr--];
annotationargumentexpression[] arguments = new annotationargumentexpression[size];
for (int i = (size - 1); i >= 0; i--) {
arguments[i] = (annotationargumentexpression) aststack[astptr--];
}
annotationmessagesend msg = new annotationmessagesend(identifierstack[0], identifierpositionstack[0], arguments);
msg.receiver = receiver;
return msg;
} else {
break nextarg;
}
}

// invalid input: reset ast stacks pointers
consumetoken();
if (itoken > 0) {
this.astptr = ptr;
this.astlengthptr = lptr;
}
throw new invalidinputexception();
}

/*
* parse an url link reference in @@see tag
*/
private boolean parsehref() throws invalidinputexception {
int start = this.scanner.getcurrenttokenstartposition();
//int end = this.scanner.getcurrenttokenendposition();
if (readtokenandconsume() == terminaltokens.tokennameidentifier) {
//end = this.index-1;
if (charoperation.equals(this.scanner.getcurrentidentifiersource(), new char[]{'a'}, false)
&& readtokenandconsume() == terminaltokens.tokennameidentifier) {
//end = this.index - 1;
try {
if (charoperation.equals(this.scanner.getcurrentidentifiersource(), new char[]{'h', 'r', 'e', 'f'}, false) &&
readtokenandconsume() == terminaltokens.tokennameequal &&
readtokenandconsume() == terminaltokens.tokennamestringliteral &&
readtokenandconsume() == terminaltokens.tokennamegreater) {
while (readtokenandconsume() != terminaltokens.tokennameless) {
if (this.scanner.currentposition >= this.lineend) {
this.sourceparser.problemreporter().annotationinvalidseeurlreference(start, this.lineend - 1);
return false;
}
}
if (readtokenandconsume() == terminaltokens.tokennamedivide	&&
readtokenandconsume() == terminaltokens.tokennameidentifier) {
//end = this.index - 1;
if (charoperation.equals(this.scanner.getcurrentidentifiersource(), new char[]{'a'}, false)	&&
readtokenandconsume() == terminaltokens.tokennamegreater) {
// valid href
return true;
}
}
}
} catch (invalidinputexception ex) {
// place to change end position for error report
//end = getendposition();
}
}
}
this.sourceparser.problemreporter().annotationinvalidseeurlreference(start, this.lineend - 1);
return false;
}

/*
* parse a method reference in @@see tag
*/
private expression parsemember(typereference receiver) throws invalidinputexception {
this.identifierptr = -1;
this.identifierlengthptr = -1;
int start = this.scanner.getcurrenttokenstartposition();
if (readtokenandconsume() == terminaltokens.tokennameidentifier) {
pushidentifier(true);
if (readtokenandconsume() == terminaltokens.tokennamelparen) {
start = this.scanner.currentposition;
annotationmessagesend msg = null;
try {
msg = parsearguments(receiver);
msg.tagsourcestart = this.tagsourcestart;
msg.tagsourceend = this.tagsourceend;
} catch (invalidinputexception e) {
int end = this.scanner.getcurrenttokenendposition() < this.lineend ?
this.scanner.getcurrenttokenendposition() :
this.scanner.getcurrenttokenstartposition();
end = end < this.lineend ? end : (this.lineend - 1);
this.sourceparser.problemreporter()	.annotationinvalidseereferenceargs(start, end);
}
return msg;
}
annotationfieldreference field = new annotationfieldreference(identifierstack[0], identifierpositionstack[0]);
field.receiver = receiver;
field.tagsourcestart = this.tagsourcestart;
field.tagsourceend = this.tagsourceend;
return field;
}
this.sourceparser.problemreporter().annotationinvalidseereference(start, getendposition());
return null;
}

/*
* parse @@param tag declaration
*/
private void parseparam() {

// store current token state
int start = this.tagsourcestart;
int end = this.tagsourceend;

try {
// push identifier next
int token = readtokenandconsume();
switch (token) {
case terminaltokens.tokennameidentifier :
annotationsinglenamereference argument = new annotationsinglenamereference(this.scanner.getcurrentidentifiersource(),
this.scanner.getcurrenttokenstartposition(),
this.scanner.getcurrenttokenendposition());
argument.tagsourcestart = this.tagsourcestart;
argument.tagsourceend = this.tagsourceend;
pushparamname(argument);
return;
case terminaltokens.tokennameeof :
//end = scanner.eofposition-2;
break;
default :
start = scanner.getcurrenttokenstartposition();
end = scanner.getcurrenttokenendposition();
break;
}
} catch (invalidinputexception e) {
end = getendposition();
}

// report problem
this.sourceparser.problemreporter().annotationmissingparamname(start, end);
consumetoken();
}

/*
* parse a qualified name and built a type reference if the syntax is valid.
*/
private typereference parsequalifiedname(boolean reset) throws invalidinputexception {

// reset identifier stack if requested
if (reset) {
this.identifierptr = -1;
this.identifierlengthptr = -1;
}

// scan tokens
nexttoken : for (int itoken = 0; ; itoken++) {
int token = readtoken();
switch (token) {
case terminaltokens.tokennameidentifier :
if (((itoken % 2) > 0)) { // identifiers must be odd tokens
break nexttoken;
}
pushidentifier(itoken == 0);
consumetoken();
break;

case terminaltokens.tokennamedot :
if ((itoken % 2) == 0) { // dots must be even tokens
throw new invalidinputexception();
}
consumetoken();
break;

case terminaltokens.tokennamevoid :
case terminaltokens.tokennameboolean :
case terminaltokens.tokennamebyte :
case terminaltokens.tokennamechar :
case terminaltokens.tokennamedouble :
case terminaltokens.tokennamefloat :
case terminaltokens.tokennameint :
case terminaltokens.tokennamelong :
case terminaltokens.tokennameshort :
if (itoken > 0) {
throw new invalidinputexception();
}
pushidentifier(true);
consumetoken();
break nexttoken;

default :
if (itoken == 0) {
return null;
}
if ((itoken % 2) == 0) { // dots must be followed by an identifier
throw new invalidinputexception();
}
break nexttoken;
}
}

// build type reference from read tokens
typereference typeref = null;
int size = this.identifierlengthstack[this.identifierlengthptr--];
if (size == 1) { // single type ref
typeref = new annotationsingletypereference(
identifierstack[this.identifierptr],
identifierpositionstack[this.identifierptr],
this.tagsourcestart,
this.tagsourceend);
} else if (size > 1) { // qualified type ref
char[][] tokens = new char[size][];
system.arraycopy(this.identifierstack, this.identifierptr - size + 1, tokens, 0, size);
long[] positions = new long[size];
system.arraycopy(this.identifierpositionstack, this.identifierptr - size + 1, positions, 0, size);
typeref = new annotationqualifiedtypereference(tokens, positions, this.tagsourcestart, this.tagsourceend);
}
this.identifierptr -= size;
return typeref;
}

/*
* parse a reference in @@see tag
*/
private expression parsereference() throws invalidinputexception {
typereference typeref = null;
nexttoken : while (this.index < this.scanner.eofposition) {
int token = readtoken();
switch (token) {
case terminaltokens.tokennamestringliteral :
// @@see "string"
int start = this.scanner.getcurrenttokenstartposition();
if (typeref == null) {
consumetoken();
try {
if (readtoken() == terminaltokens.tokennameeof) {
return null;
}
} catch (invalidinputexception e) {// do nothing as we want to underline from the beginning of the string
}
}
this.sourceparser.problemreporter().annotationinvalidseereference(start, this.lineend - 1);
return null;
case terminaltokens.tokennameless :
// @@see "<a href="url#value">label</a>
consumetoken();
start = this.scanner.getcurrenttokenstartposition();
if (parsehref()) {
if (typeref == null) {
consumetoken();
try {
if (readtoken() == terminaltokens.tokennameeof) {
return null;
}
} catch (invalidinputexception e) {// do nothing as we want to underline from the beginning of the href
}
}
this.sourceparser.problemreporter().annotationinvalidseereference(start, this.lineend - 1);
}
return null;
case terminaltokens.tokennameerror :
consumetoken();
if (this.scanner.currentcharacter == '#') { // @@see ...#member
return parsemember(typeref);
}
break nexttoken;
case terminaltokens.tokennameidentifier :
if (typeref == null) {
typeref = parsequalifiedname(true);
break;
}
default :
break nexttoken;
}
}
if (typeref == null) {
this.sourceparser.problemreporter().annotationmissingseereference(this.tagsourcestart, this.tagsourceend);
}
return typeref;
}

/*
* parse @@return tag declaration
*/
private void parsereturn() {
if (this.annotation.returnstatement == null) {
this.annotation.returnstatement = new annotationreturnstatement(scanner.getcurrenttokenstartposition(),
scanner.getcurrenttokenendposition(),
scanner.getrawtokensourceend());
} else {
this.sourceparser.problemreporter().annotationinvalidreturntag(
scanner.getcurrenttokenstartposition(),
scanner.getcurrenttokenendposition(),
false);
}
}

/*
* parse @@see tag declaration
*/
private void parsesee() {
int start = this.scanner.currentposition;
try {
expression msgref = parsereference();
if (msgref != null) {
pushseeref(msgref);
}
} catch (invalidinputexception ex) {
this.sourceparser.problemreporter().annotationinvalidseereference(start, getendposition());
} finally {
consumetoken();
}
}

/*
* parse @@throws tag declaration
*/
private void parsethrows() {
int start = this.scanner.currentposition;
try {
typereference typeref = parsequalifiedname(true);
if (typeref == null) {
this.sourceparser.problemreporter().annotationmissingthrowsclassname(this.tagsourcestart, this.tagsourceend);
} else {
pushthrowname(typeref);
}
} catch (invalidinputexception ex) {
this.sourceparser.problemreporter().annotationinvalidthrowsclass(start, getendposition());
} finally {
consumetoken();
}
}

/*
* push the consumetoken on the identifier stack. increase the total number of identifier in the stack.
*/
private void pushidentifier(boolean newlength) {

try {
this.identifierstack[++this.identifierptr] = this.scanner.getcurrentidentifiersource();
this.identifierpositionstack[this.identifierptr] = (((long) this.scanner.startposition) << 32)
+ (this.scanner.currentposition - 1);
} catch (indexoutofboundsexception e) {
//---stack reallaocation (identifierptr is correct)---
int oldstacklength = this.identifierstack.length;
char[][] oldstack = this.identifierstack;
this.identifierstack = new char[oldstacklength + 10][];
system.arraycopy(oldstack, 0, this.identifierstack, 0, oldstacklength);
this.identifierstack[this.identifierptr] = this.scanner.getcurrenttokensource();
// identifier position stack
long[] oldpos = this.identifierpositionstack;
this.identifierpositionstack = new long[oldstacklength + 10];
system.arraycopy(oldpos, 0, this.identifierpositionstack, 0, oldstacklength);
this.identifierpositionstack[this.identifierptr] = (((long) this.scanner.startposition) << 32)
+ (this.scanner.currentposition - 1);
}

if (newlength) {
try {
this.identifierlengthstack[++this.identifierlengthptr] = 1;
} catch (indexoutofboundsexception e) {
/* ---stack reallocation (identifierlengthptr is correct)--- */
int oldstacklength = this.identifierlengthstack.length;
int oldstack[] = this.identifierlengthstack;
this.identifierlengthstack = new int[oldstacklength + 10];
system.arraycopy(oldstack, 0, this.identifierlengthstack, 0, oldstacklength);
this.identifierlengthstack[this.identifierlengthptr] = 1;
}
} else {
this.identifierlengthstack[this.identifierlengthptr]++;
}
}

/*
* add a new obj on top of the ast stack.
* if new length is required, then add also a new length in length stack.
*/
private void pushonaststack(astnode node, boolean newlength) {

if (node == null) {
this.astlengthstack[++this.astlengthptr] = 0;
return;
}

try {
this.aststack[++this.astptr] = node;
} catch (indexoutofboundsexception e) {
int oldstacklength = this.aststack.length;
astnode[] oldstack = this.aststack;
this.aststack = new astnode[oldstacklength + aststackincrement];
system.arraycopy(oldstack, 0, this.aststack, 0, oldstacklength);
this.astptr = oldstacklength;
this.aststack[this.astptr] = node;
}

if (newlength) {
try {
this.astlengthstack[++this.astlengthptr] = 1;
} catch (indexoutofboundsexception e) {
int oldstacklength = this.astlengthstack.length;
int[] oldpos = this.astlengthstack;
this.astlengthstack = new int[oldstacklength + aststackincrement];
system.arraycopy(oldpos, 0, this.astlengthstack, 0, oldstacklength);
this.astlengthstack[this.astlengthptr] = 1;
}
} else {
this.astlengthstack[this.astlengthptr]++;
}
}

/*
* push a param name in ast node stack.
*/
private void pushparamname(annotationsinglenamereference arg) {
if (this.astlengthptr == -1) { // first push
pushonaststack(arg, true);
} else {
// verify that no @@throws has been declared before
for (int i=throws_tag_expected_order; i<=this.astlengthptr; i+=ordered_tags_number) {
if (this.astlengthstack[i] != 0) {
this.sourceparser.problemreporter().annotationunexpectedtag(arg.tagsourcestart, arg.tagsourceend);
return;
}
}
switch (this.astlengthptr % ordered_tags_number) {
case param_tag_expected_order :
// previous push was a @@param tag => push another param name
pushonaststack(arg, false);
break;
case see_tag_expected_order :
// previous push was a @@see tag => push new param name
pushonaststack(arg, true);
break;
}
}
}

/*
* push a reference statement in ast node stack.
*/
private void pushseeref(statement statement) {
if (this.astlengthptr == -1) { // first push
pushonaststack(null, true);
pushonaststack(null, true);
pushonaststack(statement, true);
} else {
switch (this.astlengthptr % ordered_tags_number) {
case param_tag_expected_order :
// previous push was a @@param tag => push empty @@throws tag and new @@see tag
pushonaststack(null, true);
pushonaststack(statement, true);
break;
case throws_tag_expected_order :
// previous push was a @@throws tag => push new @@see tag
pushonaststack(statement, true);
break;
case see_tag_expected_order :
// previous push was a @@see tag => push another @@see tag
pushonaststack(statement, false);
break;
}
}
}

private void pushthrowname(typereference typeref) {
if (this.astlengthptr == -1) { // first push
pushonaststack(null, true);
pushonaststack(typeref, true);
} else {
switch (this.astlengthptr % ordered_tags_number) {
case param_tag_expected_order :
// previous push was a @@param tag => push new @@throws tag
pushonaststack(typeref, true);
break;
case throws_tag_expected_order :
// previous push was a @@throws tag => push another @@throws tag
pushonaststack(typeref, false);
break;
case see_tag_expected_order :
// previous push was a @@see tag => push empty @@param and new @@throws tags
pushonaststack(null, true);
pushonaststack(typeref, true);
break;
}
}
}

private char readchar() {

char c = this.source[this.index++];
if (c == '\\') {
int c1, c2, c3, c4;
this.index++;
while (this.source[this.index] == 'u')
this.index++;
if (!(((c1 = character.getnumericvalue(this.source[this.index++])) > 15 || c1 < 0)
|| ((c2 = character.getnumericvalue(this.source[this.index++])) > 15 || c2 < 0)
|| ((c3 = character.getnumericvalue(this.source[this.index++])) > 15 || c3 < 0) || ((c4 = character.getnumericvalue(this.source[this.index++])) > 15 || c4 < 0))) {
c = (char) (((c1 * 16 + c2) * 16 + c3) * 16 + c4);
}
}
return c;
}

/*
* read token only if previous was consumed
*/
private int readtoken() throws invalidinputexception {
if (this.currenttokentype < 0) {
this.currenttokentype = this.scanner.getnexttoken();
this.index = this.scanner.currentposition;
}
return this.currenttokentype;
}

private int readtokenandconsume() throws invalidinputexception {
int token = readtoken();
consumetoken();
return token;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append("check annotation: ").append(this.checkannotation).append("\n");	//$non-nls-1$ //$non-nls-2$
buffer.append("annotation: ").append(this.annotation).append("\n");	//$non-nls-1$ //$non-nls-2$
return buffer.tostring();
}
/*
* fill annotation fields with information in ast nodes stack.
*/
private void updateannotation() {
if (this.astlengthptr == -1) {
return;
}

// initialize arrays
int[] sizes = new int[ordered_tags_number];
for (int i=0; i<=this.astlengthptr; i++) {
sizes[i%ordered_tags_number] += this.astlengthstack[i];
}
this.annotation.references = new expression[sizes[see_tag_expected_order]];
this.annotation.thrownexceptions = new typereference[sizes[throws_tag_expected_order]];
this.annotation.parameters = new annotationsinglenamereference[sizes[param_tag_expected_order]];

// store nodes in arrays
while (this.astlengthptr >= 0) {
int ptr = this.astlengthptr % ordered_tags_number;
// starting with the stack top, so get references (eg. expression) coming from @@see declarations
if (ptr == see_tag_expected_order) {
int size = this.astlengthstack[this.astlengthptr--];
for (int i=0; i<size; i++) {
this.annotation.references[--sizes[ptr]] = (expression) this.aststack[astptr--];
}
}

// then continuing with class names (eg. typereference) coming from @@throw/@@exception declarations
else if (ptr == throws_tag_expected_order) {
int size = this.astlengthstack[this.astlengthptr--];
for (int i=0; i<size; i++) {
this.annotation.thrownexceptions[--sizes[ptr]] = (typereference) this.aststack[astptr--];
}
}

// finally, finishing with parameters nales (ie. argument) coming from @@param declaration
else if (ptr == param_tag_expected_order) {
int size = this.astlengthstack[this.astlengthptr--];
for (int i=0; i<size; i++) {
this.annotation.parameters[--sizes[ptr]] = (annotationsinglenamereference) this.aststack[astptr--];
}
}
}
}
}@


1.18
log
@45669
