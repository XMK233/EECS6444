/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.messagesend;

/**
* binding denoting a generic method after type parameter substitutions got performed.
* on parameterized type bindings, all methods got substituted, regardless whether
* their signature did involve generics or not, so as to get the proper declaringclass for
* these methods.
*/
public class parameterizedgenericmethodbinding extends parameterizedmethodbinding implements substitution {

public typebinding[] typearguments;
private lookupenvironment environment;
public boolean inferredreturntype;
public boolean wasinferred; // only set to true for instances resulting from method invocation inferrence
public boolean israw; // set to true for method behaving as raw for substitution purpose
private methodbinding tiebreakmethod;

/**
* perform inference of generic method type parameters and/or expected type
*/
public static methodbinding computecompatiblemethod(methodbinding originalmethod, typebinding[] arguments, scope scope, invocationsite invocationsite) {
parameterizedgenericmethodbinding methodsubstitute;
typevariablebinding[] typevariables = originalmethod.typevariables;
typebinding[] substitutes = invocationsite.generictypearguments();
typebinding[] uncheckedarguments = null;
computesubstitutes: {
if (substitutes != null) {
// explicit type arguments got supplied
if (substitutes.length != typevariables.length) {
// incompatible due to wrong arity
return new problemmethodbinding(originalmethod, originalmethod.selector, substitutes, problemreasons.typeparameteraritymismatch);
}
methodsubstitute = scope.environment().createparameterizedgenericmethod(originalmethod, substitutes);
break computesubstitutes;
}
// perform type argument inference (15.12.2.7)
// initializes the map of substitutes (var --> type[][]{ equal, extends, super}
typebinding[] parameters = originalmethod.parameters;
inferencecontext inferencecontext = new inferencecontext(originalmethod);
methodsubstitute = inferfromargumenttypes(scope, originalmethod, arguments, parameters, inferencecontext);
if (methodsubstitute == null)
return null;

// substitutes may hold null to denote unresolved vars, but null arguments got replaced with respective original variable in param method
// 15.12.2.8 - inferring unresolved type arguments
if (inferencecontext.hasunresolvedtypeargument()) {
if (inferencecontext.isunchecked) { // only remember unchecked status post 15.12.2.7
int length = inferencecontext.substitutes.length;
system.arraycopy(inferencecontext.substitutes, 0, uncheckedarguments = new typebinding[length], 0, length);
}
if (methodsubstitute.returntype != typebinding.void) {
typebinding expectedtype = null;
// if message invocation has expected type
if (invocationsite instanceof messagesend) {
messagesend message = (messagesend) invocationsite;
expectedtype = message.expectedtype;
}
if (expectedtype != null) {
// record it was explicit from context, as opposed to assumed by default (see below)
inferencecontext.hasexplicitexpectedtype = true;
} else {
expectedtype = scope.getjavalangobject(); // assume object by default
}
inferencecontext.expectedtype = expectedtype;
}
methodsubstitute = methodsubstitute.inferfromexpectedtype(scope, inferencecontext);
if (methodsubstitute == null)
return null;
}
}

// bounds check
for (int i = 0, length = typevariables.length; i < length; i++) {
typevariablebinding typevariable = typevariables[i];
typebinding substitute = methodsubstitute.typearguments[i];
if (uncheckedarguments != null && uncheckedarguments[i] == null) continue; // only bound check if inferred through 15.12.2.6
switch (typevariable.boundcheck(methodsubstitute, substitute)) {
case typeconstants.mismatch :
// incompatible due to bound check
int arglength = arguments.length;
typebinding[] augmentedarguments = new typebinding[arglength + 2]; // append offending substitute and typevariable
system.arraycopy(arguments, 0, augmentedarguments, 0, arglength);
augmentedarguments[arglength] = substitute;
augmentedarguments[arglength+1] = typevariable;
return new problemmethodbinding(methodsubstitute, originalmethod.selector, augmentedarguments, problemreasons.parameterboundmismatch);
case typeconstants.unchecked :
// tolerate unchecked bounds
methodsubstitute.tagbits |= tagbits.hasuncheckedtypeargumentforboundcheck;
break;
}
}
// check presence of unchecked argument conversion a posteriori (15.12.2.6)
return methodsubstitute;
}

/**
* collect argument type mapping, handling varargs
*/
private static parameterizedgenericmethodbinding inferfromargumenttypes(scope scope, methodbinding originalmethod, typebinding[] arguments, typebinding[] parameters, inferencecontext inferencecontext) {
if (originalmethod.isvarargs()) {
int paramlength = parameters.length;
int minarglength = paramlength - 1;
int arglength = arguments.length;
// process mandatory arguments
for (int i = 0; i < minarglength; i++) {
parameters[i].collectsubstitutes(scope, arguments[i], inferencecontext, typeconstants.constraint_extends);
if (inferencecontext.status == inferencecontext.failed) return null; // impossible substitution
}
// process optional arguments
if (minarglength < arglength) {
typebinding varargtype = parameters[minarglength]; // last arg type - as is ?
typebinding lastargument = arguments[minarglength];
checkvarargdimension: {
if (paramlength == arglength) {
if (lastargument == typebinding.null) break checkvarargdimension;
switch (lastargument.dimensions()) {
case 0 :
break; // will remove one dim
case 1 :
if (!lastargument.leafcomponenttype().isbasetype()) break checkvarargdimension;
break; // will remove one dim
default :
break checkvarargdimension;
}
}
// eliminate one array dimension
varargtype = ((arraybinding)varargtype).elementstype();
}
for (int i = minarglength; i < arglength; i++) {
varargtype.collectsubstitutes(scope, arguments[i], inferencecontext, typeconstants.constraint_extends);
if (inferencecontext.status == inferencecontext.failed) return null; // impossible substitution
}
}
} else {
int paramlength = parameters.length;
for (int i = 0; i < paramlength; i++) {
parameters[i].collectsubstitutes(scope, arguments[i], inferencecontext, typeconstants.constraint_extends);
if (inferencecontext.status == inferencecontext.failed) return null; // impossible substitution
}
}
typevariablebinding[] originalvariables = originalmethod.typevariables;
if (!resolvesubstituteconstraints(scope, originalvariables , inferencecontext, false/*ignore ti<:uk*/))
return null; // impossible substitution

// apply inferred variable substitutions - replacing unresolved variable with original ones in param method
typebinding[] inferredsustitutes = inferencecontext.substitutes;
typebinding[] actualsubstitutes = inferredsustitutes;
for (int i = 0, varlength = originalvariables.length; i < varlength; i++) {
if (inferredsustitutes[i] == null) {
if (actualsubstitutes == inferredsustitutes) {
system.arraycopy(inferredsustitutes, 0, actualsubstitutes = new typebinding[varlength], 0, i); // clone to replace null with original variable in param method
}
actualsubstitutes[i] = originalvariables[i];
} else if (actualsubstitutes != inferredsustitutes) {
actualsubstitutes[i] = inferredsustitutes[i];
}
}
parameterizedgenericmethodbinding parammethod = scope.environment().createparameterizedgenericmethod(originalmethod, actualsubstitutes);
return parammethod;
}

private static boolean resolvesubstituteconstraints(scope scope, typevariablebinding[] typevariables, inferencecontext inferencecontext, boolean considerextendsconstraints) {
typebinding[] substitutes = inferencecontext.substitutes;
int varlength = typevariables.length;
// check tj=u constraints
nexttypeparameter:
for (int i = 0; i < varlength; i++) {
typevariablebinding current = typevariables[i];
typebinding substitute = substitutes[i];
if (substitute != null) continue nexttypeparameter; // already inferred previously
typebinding [] equalsubstitutes = inferencecontext.getsubstitutes(current, typeconstants.constraint_equal);
if (equalsubstitutes != null) {
nextconstraint:
for (int j = 0, equallength = equalsubstitutes.length; j < equallength; j++) {
typebinding equalsubstitute = equalsubstitutes[j];
if (equalsubstitute == null) continue nextconstraint;
if (equalsubstitute == current) {
// try to find a better different match if any in subsequent equal candidates
for (int k = j+1; k < equallength; k++) {
equalsubstitute = equalsubstitutes[k];
if (equalsubstitute != current && equalsubstitute != null) {
substitutes[i] = equalsubstitute;
continue nexttypeparameter;
}
}
substitutes[i] = current;
continue nexttypeparameter;
}
//							if (equalsubstitute.istypevariable()) {
//								typevariablebinding variable = (typevariablebinding) equalsubstitute;
//								// substituted by a variable of the same method, ignore
//								if (variable.rank < varlength && typevariables[variable.rank] == variable) {
//									// todo (philippe) rewrite all other constraints to use current instead.
//									continue nextconstraint;
//								}
//							}
substitutes[i] = equalsubstitute;
continue nexttypeparameter; // pick first match, applicability check will rule out invalid scenario where others were present
}
}
}
if (inferencecontext.hasunresolvedtypeargument()) {
// check tj>:u constraints
nexttypeparameter:
for (int i = 0; i < varlength; i++) {
typevariablebinding current = typevariables[i];
typebinding substitute = substitutes[i];
if (substitute != null) continue nexttypeparameter; // already inferred previously
typebinding [] bounds = inferencecontext.getsubstitutes(current, typeconstants.constraint_super);
if (bounds == null) continue nexttypeparameter;
typebinding mostspecificsubstitute = scope.lowerupperbound(bounds);
if (mostspecificsubstitute == null) {
return false; // incompatible
}
if (mostspecificsubstitute != typebinding.void) {
substitutes[i] = mostspecificsubstitute;
}
}
}
if (considerextendsconstraints && inferencecontext.hasunresolvedtypeargument()) {
// check tj<:u constraints
nexttypeparameter:
for (int i = 0; i < varlength; i++) {
typevariablebinding current = typevariables[i];
typebinding substitute = substitutes[i];
if (substitute != null) continue nexttypeparameter; // already inferred previously
typebinding [] bounds = inferencecontext.getsubstitutes(current, typeconstants.constraint_extends);
if (bounds == null) continue nexttypeparameter;
typebinding[] glb = scope.greaterlowerbound(bounds);
typebinding mostspecificsubstitute = null;
if (glb != null) mostspecificsubstitute = glb[0]; // todo (philippe) need to improve
//typebinding mostspecificsubstitute = scope.greaterlowerbound(bounds);
if (mostspecificsubstitute != null) {
substitutes[i] = mostspecificsubstitute;
}
}
}
return true;
}

/**
* create raw generic method for raw type (double substitution from type vars with raw type arguments, and erasure of method variables)
* only invoked for non-static generic methods of raw type
*/
public parameterizedgenericmethodbinding(methodbinding originalmethod, rawtypebinding rawtype, lookupenvironment environment) {
typevariablebinding[] originalvariables = originalmethod.typevariables;
int length = originalvariables.length;
typebinding[] rawarguments = new typebinding[length];
for (int i = 0; i < length; i++) {
rawarguments[i] =  environment.converttorawtype(originalvariables[i].erasure(), false /*do not force conversion of enclosing types*/);
}
this.israw = true;
this.tagbits = originalmethod.tagbits;
this.environment = environment;
this.modifiers = originalmethod.modifiers;
this.selector = originalmethod.selector;
this.declaringclass = rawtype == null ? originalmethod.declaringclass : rawtype;
this.typevariables = binding.no_type_variables;
this.typearguments = rawarguments;
this.originalmethod = originalmethod;
boolean ignorerawtypesubstitution = rawtype == null || originalmethod.isstatic();
this.parameters = scope.substitute(this, ignorerawtypesubstitution
? originalmethod.parameters // no substitution if original was static
: scope.substitute(rawtype, originalmethod.parameters));
this.thrownexceptions = scope.substitute(this, 	ignorerawtypesubstitution
? originalmethod.thrownexceptions // no substitution if original was static
: scope.substitute(rawtype, originalmethod.thrownexceptions));
// error case where exception type variable would have been substituted by a non-reference type (207573)
if (this.thrownexceptions == null) this.thrownexceptions = binding.no_exceptions;
this.returntype = scope.substitute(this, ignorerawtypesubstitution
? originalmethod.returntype // no substitution if original was static
: scope.substitute(rawtype, originalmethod.returntype));
this.wasinferred = false; // not resulting from method invocation inferrence
}

/**
* create method of parameterized type, substituting original parameters with type arguments.
*/
public parameterizedgenericmethodbinding(methodbinding originalmethod, typebinding[] typearguments, lookupenvironment environment) {
this.environment = environment;
this.modifiers = originalmethod.modifiers;
this.selector = originalmethod.selector;
this.declaringclass = originalmethod.declaringclass;
this.typevariables = binding.no_type_variables;
this.typearguments = typearguments;
this.israw = false;
this.tagbits = originalmethod.tagbits;
this.originalmethod = originalmethod;
this.parameters = scope.substitute(this, originalmethod.parameters);
// error case where exception type variable would have been substituted by a non-reference type (207573)
this.returntype = scope.substitute(this, originalmethod.returntype);
this.thrownexceptions = scope.substitute(this, originalmethod.thrownexceptions);
if (this.thrownexceptions == null) this.thrownexceptions = binding.no_exceptions;
checkmissingtype: {
if ((this.tagbits & tagbits.hasmissingtype) != 0)
break checkmissingtype;
if ((this.returntype.tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
for (int i = 0, max = this.parameters.length; i < max; i++) {
if ((this.parameters[i].tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
}
for (int i = 0, max = this.thrownexceptions.length; i < max; i++) {
if ((this.thrownexceptions[i].tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
}
}
this.wasinferred = true;// resulting from method invocation inferrence
}

/*
* parameterizeddeclaringuniquekey dot selector originalmethodgenericsignature percent typearguments
* p.x<u> { <t> void bar(t t, u u) { new x<string>().bar(this, "") } } --> lp/x<ljava/lang/string;>;.bar<t:ljava/lang/object;>(tt;ljava/lang/string;)v%<lp/x;>
*/
public char[] computeuniquekey(boolean isleaf) {
stringbuffer buffer = new stringbuffer();
buffer.append(this.originalmethod.computeuniquekey(false/*not a leaf*/));
buffer.append('%');
buffer.append('<');
if (!this.israw) {
int length = this.typearguments.length;
for (int i = 0; i < length; i++) {
typebinding typeargument = this.typearguments[i];
buffer.append(typeargument.computeuniquekey(false/*not a leaf*/));
}
}
buffer.append('>');
int resultlength = buffer.length();
char[] result = new char[resultlength];
buffer.getchars(0, resultlength, result, 0);
return result;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.substitution#environment()
*/
public lookupenvironment environment() {
return this.environment;
}
/**
* returns true if some parameters got substituted.
* note: generic method invocation delegates to its declaring method (could be a parameterized one)
*/
public boolean hassubstitutedparameters() {
// generic parameterized method can represent either an invocation or a raw generic method
if (this.wasinferred)
return this.originalmethod.hassubstitutedparameters();
return super.hassubstitutedparameters();
}
/**
* returns true if the return type got substituted.
* note: generic method invocation delegates to its declaring method (could be a parameterized one)
*/
public boolean hassubstitutedreturntype() {
if (this.inferredreturntype)
return this.originalmethod.hassubstitutedreturntype();
return super.hassubstitutedreturntype();
}
/**
* given some type expectation, and type variable bounds, perform some inference.
* returns true if still had unresolved type variable at the end of the operation
*/
private parameterizedgenericmethodbinding inferfromexpectedtype(scope scope, inferencecontext inferencecontext) {
typevariablebinding[] originalvariables = this.originalmethod.typevariables; // immediate parent (could be a parameterized method)
int varlength = originalvariables.length;
// infer from expected return type
if (inferencecontext.expectedtype != null) {
this.returntype.collectsubstitutes(scope, inferencecontext.expectedtype, inferencecontext, typeconstants.constraint_super);
if (inferencecontext.status == inferencecontext.failed) return null; // impossible substitution
}
// infer from bounds of type parameters
for (int i = 0; i < varlength; i++) {
typevariablebinding originalvariable = originalvariables[i];
typebinding argument = this.typearguments[i];
boolean argalreadyinferred = argument != originalvariable;
if (originalvariable.firstbound == originalvariable.superclass) {
typebinding substitutedbound = scope.substitute(this, originalvariable.superclass);
argument.collectsubstitutes(scope, substitutedbound, inferencecontext, typeconstants.constraint_super);
if (inferencecontext.status == inferencecontext.failed) return null; // impossible substitution
// jls 15.12.2.8 claims reverse inference shouldn't occur, however it improves inference
// e.g. given: <e extends object, s extends collection<e>> s test1(s param)
//                   invocation: test1(new vector<string>())    will infer: s=vector<string>  and with code below: e=string
if (argalreadyinferred) {
substitutedbound.collectsubstitutes(scope, argument, inferencecontext, typeconstants.constraint_extends);
if (inferencecontext.status == inferencecontext.failed) return null; // impossible substitution
}
}
for (int j = 0, max = originalvariable.superinterfaces.length; j < max; j++) {
typebinding substitutedbound = scope.substitute(this, originalvariable.superinterfaces[j]);
argument.collectsubstitutes(scope, substitutedbound, inferencecontext, typeconstants.constraint_super);
if (inferencecontext.status == inferencecontext.failed) return null; // impossible substitution
// jls 15.12.2.8 claims reverse inference shouldn't occur, however it improves inference
if (argalreadyinferred) {
substitutedbound.collectsubstitutes(scope, argument, inferencecontext, typeconstants.constraint_extends);
if (inferencecontext.status == inferencecontext.failed) return null; // impossible substitution
}
}
}
if (!resolvesubstituteconstraints(scope, originalvariables, inferencecontext, true/*consider ti<:uk*/))
return null; // incompatible
// this.typearguments = substitutes; - no op since side effects got performed during #resolvesubstituteconstraints
for (int i = 0; i < varlength; i++) {
typebinding substitute = inferencecontext.substitutes[i];
if (substitute != null) {
this.typearguments[i] = inferencecontext.substitutes[i];
} else {
// remaining unresolved variable are considered to be object (or their bound actually)
this.typearguments[i] = originalvariables[i].upperbound();
}
}
// may still need an extra substitution at the end (see https://bugs.eclipse.org/bugs/show_bug.cgi?id=121369)
// to properly substitute a remaining unresolved variable which also appear in a formal bound
this.typearguments = scope.substitute(this, this.typearguments);

// adjust method types to reflect latest inference
typebinding oldreturntype = this.returntype;
this.returntype = scope.substitute(this, this.returntype);
this.inferredreturntype = inferencecontext.hasexplicitexpectedtype && this.returntype != oldreturntype;
this.parameters = scope.substitute(this, this.parameters);
this.thrownexceptions = scope.substitute(this, this.thrownexceptions);
// error case where exception type variable would have been substituted by a non-reference type (207573)
if (this.thrownexceptions == null) this.thrownexceptions = binding.no_exceptions;
checkmissingtype: {
if ((this.tagbits & tagbits.hasmissingtype) != 0)
break checkmissingtype;
if ((this.returntype.tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
for (int i = 0, max = this.parameters.length; i < max; i++) {
if ((this.parameters[i].tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
}
for (int i = 0, max = this.thrownexceptions.length; i < max; i++) {
if ((this.thrownexceptions[i].tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
}
}
return this;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.substitution#israwsubstitution()
*/
public boolean israwsubstitution() {
return this.israw;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.substitution#substitute(org.eclipse.jdt.internal.compiler.lookup.typevariablebinding)
*/
public typebinding substitute(typevariablebinding originalvariable) {
typevariablebinding[] variables = this.originalmethod.typevariables;
int length = variables.length;
// check this variable can be substituted given parameterized type
if (originalvariable.rank < length && variables[originalvariable.rank] == originalvariable) {
return this.typearguments[originalvariable.rank];
}
return originalvariable;
}
/**
* @@see org.eclipse.jdt.internal.compiler.lookup.methodbinding#tiebreakmethod()
*/
public methodbinding tiebreakmethod() {
if (this.tiebreakmethod == null)
this.tiebreakmethod = this.originalmethod.asrawmethod(this.environment);
return this.tiebreakmethod;
}
}@


1.67
log
@head - 262209
