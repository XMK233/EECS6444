/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.util.hashtableofpackage;
import org.eclipse.jdt.internal.compiler.util.hashtableoftype;

public class packagebinding extends binding implements typeconstants {
public long tagbits = 0; // see values in the interface tagbits below

public char[][] compoundname;
packagebinding parent;
public lookupenvironment environment;
hashtableoftype knowntypes;
hashtableofpackage knownpackages;
protected packagebinding() {
// for creating problem package
}
public packagebinding(char[] toplevelpackagename, lookupenvironment environment) {
this(new char[][] {toplevelpackagename}, null, environment);
}
/* create the default package.
*/
public packagebinding(char[][] compoundname, packagebinding parent, lookupenvironment environment) {
this.compoundname = compoundname;
this.parent = parent;
this.environment = environment;
this.knowntypes = null; // initialized if used... class counts can be very large 300-600
this.knownpackages = new hashtableofpackage(3); // sub-package counts are typically 0-3
}

public packagebinding(lookupenvironment environment) {
this(charoperation.no_char_char, null, environment);
}
private void addnotfoundpackage(char[] simplename) {
this.knownpackages.put(simplename, lookupenvironment.thenotfoundpackage);
}
private void addnotfoundtype(char[] simplename) {
if (this.knowntypes == null)
this.knowntypes = new hashtableoftype(25);
this.knowntypes.put(simplename, lookupenvironment.thenotfoundtype);
}
void addpackage(packagebinding element) {
if ((element.tagbits & tagbits.hasmissingtype) == 0) clearmissingtagbit();
this.knownpackages.put(element.compoundname[element.compoundname.length - 1], element);
}
void addtype(referencebinding element) {
if ((element.tagbits & tagbits.hasmissingtype) == 0) clearmissingtagbit();
if (this.knowntypes == null)
this.knowntypes = new hashtableoftype(25);
this.knowntypes.put(element.compoundname[element.compoundname.length - 1], element);
}

void clearmissingtagbit() {
packagebinding current = this;
do {
current.tagbits &= ~tagbits.hasmissingtype;
} while ((current = current.parent) != null);
}
/*
* slash separated name
* org.eclipse.jdt.core --> org/eclipse/jdt/core
*/
public char[] computeuniquekey(boolean isleaf) {
return charoperation.concatwith(this.compoundname, '/');
}
private packagebinding findpackage(char[] name) {
if (!this.environment.ispackage(this.compoundname, name))
return null;

char[][] subpkgcompoundname = charoperation.arrayconcat(this.compoundname, name);
packagebinding subpackagebinding = new packagebinding(subpkgcompoundname, this, this.environment);
addpackage(subpackagebinding);
return subpackagebinding;
}
/* answer the subpackage named name; ask the oracle for the package if its not in the cache.
* answer null if it could not be resolved.
*
* note: this should only be used when we know there is not a type with the same name.
*/
packagebinding getpackage(char[] name) {
packagebinding binding = getpackage0(name);
if (binding != null) {
if (binding == lookupenvironment.thenotfoundpackage)
return null;
else
return binding;
}
if ((binding = findpackage(name)) != null)
return binding;

// not found so remember a problem package binding in the cache for future lookups
addnotfoundpackage(name);
return null;
}
/* answer the subpackage named name if it exists in the cache.
* answer thenotfoundpackage if it could not be resolved the first time
* it was looked up, otherwise answer null.
*
* note: senders must convert thenotfoundpackage into a real problem
* package if its to returned.
*/

packagebinding getpackage0(char[] name) {
return this.knownpackages.get(name);
}
/* answer the type named name; ask the oracle for the type if its not in the cache.
* answer a notvisible problem type if the type is not visible from the invocationpackage.
* answer null if it could not be resolved.
*
* note: this should only be used by source types/scopes which know there is not a
* package with the same name.
*/

referencebinding gettype(char[] name) {
referencebinding referencebinding = gettype0(name);
if (referencebinding == null) {
if ((referencebinding = this.environment.askfortype(this, name)) == null) {
// not found so remember a problem type binding in the cache for future lookups
addnotfoundtype(name);
return null;
}
}

if (referencebinding == lookupenvironment.thenotfoundtype)
return null;

referencebinding = (referencebinding) binarytypebinding.resolvetype(referencebinding, this.environment, false /* no raw conversion for now */);
if (referencebinding.isnestedtype())
return new problemreferencebinding(new char[][]{ name }, referencebinding, problemreasons.internalnameprovided);
return referencebinding;
}
/* answer the type named name if it exists in the cache.
* answer thenotfoundtype if it could not be resolved the first time
* it was looked up, otherwise answer null.
*
* note: senders must convert thenotfoundtype into a real problem
* reference type if its to returned.
*/

referencebinding gettype0(char[] name) {
if (this.knowntypes == null)
return null;
return this.knowntypes.get(name);
}
/* answer the package or type named name; ask the oracle if it is not in the cache.
* answer null if it could not be resolved.
*
* when collisions exist between a type name & a package name, answer the type.
* treat the package as if it does not exist... a problem was already reported when the type was defined.
*
* note: no visibility checks are performed.
* this should only be used by source types/scopes.
*/

public binding gettypeorpackage(char[] name) {
referencebinding referencebinding = gettype0(name);
if (referencebinding != null && referencebinding != lookupenvironment.thenotfoundtype) {
referencebinding = (referencebinding) binarytypebinding.resolvetype(referencebinding, this.environment, false /* no raw conversion for now */);
if (referencebinding.isnestedtype()) {
return new problemreferencebinding(new char[][]{name}, referencebinding, problemreasons.internalnameprovided);
}
if ((referencebinding.tagbits & tagbits.hasmissingtype) == 0) {
return referencebinding;
}
// referencebinding is a missingtype, will return it if no package is found
}

packagebinding packagebinding = getpackage0(name);
if (packagebinding != null && packagebinding != lookupenvironment.thenotfoundpackage) {
return packagebinding;
}
if (referencebinding == null) { // have not looked for it before
if ((referencebinding = this.environment.askfortype(this, name)) != null) {
if (referencebinding.isnestedtype()) {
return new problemreferencebinding(new char[][]{name}, referencebinding, problemreasons.internalnameprovided);
}
return referencebinding;
}

// since name could not be found, add a problem binding
// to the collections so it will be reported as an error next time.
addnotfoundtype(name);
}

if (packagebinding == null) { // have not looked for it before
if ((packagebinding = findpackage(name)) != null) {
return packagebinding;
}
if (referencebinding != null && referencebinding != lookupenvironment.thenotfoundtype) {
return referencebinding; // found cached missing type - check if package conflict
}
addnotfoundpackage(name);
}

return null;
}
public final boolean isviewedasdeprecated() {
if ((this.tagbits & tagbits.deprecatedannotationresolved) == 0) {
this.tagbits |= tagbits.deprecatedannotationresolved;
if (this.compoundname != charoperation.no_char_char) {
referencebinding packageinfo = this.gettype(typeconstants.package_info_name);
if (packageinfo != null) {
packageinfo.initializedeprecatedannotationtagbits();
this.tagbits |= packageinfo.tagbits & tagbits.allstandardannotationsmask;
}
}
}
return (this.tagbits & tagbits.annotationdeprecated) != 0;
}
/* api
* answer the receiver's binding type from binding.bindingid.
*/
public final int kind() {
return binding.package;
}

public int problemid() {
if ((this.tagbits & tagbits.hasmissingtype) != 0)
return problemreasons.notfound;
return problemreasons.noerror;
}

public char[] readablename() /*java.lang*/ {
return charoperation.concatwith(this.compoundname, '.');
}
public string tostring() {
string str;
if (this.compoundname == charoperation.no_char_char) {
str = "the default package"; //$non-nls-1$
} else {
str = "package " + ((this.compoundname != null) ? charoperation.tostring(this.compoundname) : "unnamed"); //$non-nls-1$ //$non-nls-2$
}
if ((this.tagbits & tagbits.hasmissingtype) != 0) {
str += "[missing]"; //$non-nls-1$
}
return str;
}
}
