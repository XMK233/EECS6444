/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class arrayinitializer extends expression {

public expression[] expressions;
public arraybinding binding; //the type of the { , , , }

/**
* arrayinitializer constructor comment.
*/
public arrayinitializer() {

super();
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {

if (this.expressions != null) {
for (int i = 0, max = this.expressions.length; i < max; i++) {
flowinfo = this.expressions[i].analysecode(currentscope, flowcontext, flowinfo).unconditionalinits();
}
}
return flowinfo;
}

/**
* code generation for a array initializer
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {

// flatten the values and compute the dimensions, by iterating in depth into nested array initializers
int pc = codestream.position;
int expressionlength = (this.expressions == null) ? 0: this.expressions.length;
codestream.generateinlinedvalue(expressionlength);
codestream.newarray(this.binding);
if (this.expressions != null) {
// binding is an arraytype, so i can just deal with the dimension
int elementstypeid = this.binding.dimensions > 1 ? -1 : this.binding.leafcomponenttype.id;
for (int i = 0; i < expressionlength; i++) {
expression expr;
if ((expr = this.expressions[i]).constant != constant.notaconstant) {
switch (elementstypeid) { // filter out initializations to default values
case t_int :
case t_short :
case t_byte :
case t_char :
case t_long :
if (expr.constant.longvalue() != 0) {
codestream.dup();
codestream.generateinlinedvalue(i);
expr.generatecode(currentscope, codestream, true);
codestream.arrayatput(elementstypeid, false);
}
break;
case t_float :
case t_double :
double constantvalue = expr.constant.doublevalue();
if (constantvalue == -0.0 || constantvalue != 0) {
codestream.dup();
codestream.generateinlinedvalue(i);
expr.generatecode(currentscope, codestream, true);
codestream.arrayatput(elementstypeid, false);
}
break;
case t_boolean :
if (expr.constant.booleanvalue() != false) {
codestream.dup();
codestream.generateinlinedvalue(i);
expr.generatecode(currentscope, codestream, true);
codestream.arrayatput(elementstypeid, false);
}
break;
default :
if (!(expr instanceof nullliteral)) {
codestream.dup();
codestream.generateinlinedvalue(i);
expr.generatecode(currentscope, codestream, true);
codestream.arrayatput(elementstypeid, false);
}
}
} else if (!(expr instanceof nullliteral)) {
codestream.dup();
codestream.generateinlinedvalue(i);
expr.generatecode(currentscope, codestream, true);
codestream.arrayatput(elementstypeid, false);
}
}
}
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else {
codestream.pop();
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public stringbuffer printexpression(int indent, stringbuffer output) {

output.append('{');
if (this.expressions != null) {
int j = 20 ;
for (int i = 0 ; i < this.expressions.length ; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.expressions[i].printexpression(0, output);
j -- ;
if (j == 0) {
output.append('\n');
printindent(indent+1, output);
j = 20;
}
}
}
return output.append('}');
}

public typebinding resolvetypeexpecting(blockscope scope, typebinding expectedtype) {
// array initializers can only occur on the right hand side of an assignment
// expression, therefore the expected type contains the valid information
// concerning the type that must be enforced by the elements of the array initializer.

// this method is recursive... (the test on isarraytype is the stop case)

this.constant = constant.notaconstant;

if (expectedtype instanceof arraybinding) {
// allow new list<?>[5]
if ((this.bits & isannotationdefaultvalue) == 0) { // annotation default value need only to be commensurate jls9.7
// allow new list<?>[5] - only check for generic array when no initializer, since also checked inside initializer resolution
typebinding leafcomponenttype = expectedtype.leafcomponenttype();
if (!leafcomponenttype.isreifiable()) {
scope.problemreporter().illegalgenericarray(leafcomponenttype, this);
}
}
this.resolvedtype = this.binding = (arraybinding) expectedtype;
if (this.expressions == null)
return this.binding;
typebinding elementtype = this.binding.elementstype();
for (int i = 0, length = this.expressions.length; i < length; i++) {
expression expression = this.expressions[i];
expression.setexpectedtype(elementtype);
typebinding expressiontype = expression instanceof arrayinitializer
? expression.resolvetypeexpecting(scope, elementtype)
: expression.resolvetype(scope);
if (expressiontype == null)
continue;

// compile-time conversion required?
if (elementtype != expressiontype) // must call before computeconversion() and typemismatcherror()
scope.compilationunitscope().recordtypeconversion(elementtype, expressiontype);

if (expression.isconstantvalueoftypeassignabletotype(expressiontype, elementtype)
|| expressiontype.iscompatiblewith(elementtype)) {
expression.computeconversion(scope, elementtype, expressiontype);
} else if (isboxingcompatible(expressiontype, elementtype, expression, scope)) {
expression.computeconversion(scope, elementtype, expressiontype);
} else {
scope.problemreporter().typemismatcherror(expressiontype, elementtype, expression, null);
}
}
return this.binding;
}

// infer initializer type for error reporting based on first element
typebinding leafelementtype = null;
int dim = 1;
if (this.expressions == null) {
leafelementtype = scope.getjavalangobject();
} else {
expression expression = this.expressions[0];
while(expression != null && expression instanceof arrayinitializer) {
dim++;
expression[] subexprs = ((arrayinitializer) expression).expressions;
if (subexprs == null){
leafelementtype = scope.getjavalangobject();
expression = null;
break;
}
expression = ((arrayinitializer) expression).expressions[0];
}
if (expression != null) {
leafelementtype = expression.resolvetype(scope);
}
// fault-tolerance - resolve other expressions as well
for (int i = 1, length = this.expressions.length; i < length; i++) {
expression = this.expressions[i];
if (expression != null) {
expression.resolvetype(scope)	;
}
}		}
if (leafelementtype != null) {
this.resolvedtype = scope.createarraytype(leafelementtype, dim);
if (expectedtype != null)
scope.problemreporter().typemismatcherror(this.resolvedtype, expectedtype, this, null);
}
return null;
}

public void traverse(astvisitor visitor, blockscope scope) {

if (visitor.visit(this, scope)) {
if (this.expressions != null) {
int expressionslength = this.expressions.length;
for (int i = 0; i < expressionslength; i++)
this.expressions[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
