/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

import org.eclipse.jdt.core.compiler.*;
import org.eclipse.jdt.internal.compiler.env.*;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.*;
import org.eclipse.jdt.internal.compiler.problem.*;
import org.eclipse.jdt.internal.compiler.util.*;

import java.io.*;
import java.util.*;

public class compiler implements ityperequestor, problemseverities {
public parser parser;
public icompilerrequestor requestor;
public compileroptions options;
public problemreporter problemreporter;
protected printwriter out; // output for messages that are not sent to problemreporter
public compilerstats stats;
public compilationprogress progress;
public int remainingiterations = 1;

// management of unit to be processed
//public compilationunitresult currentcompilationunitresult;
public compilationunitdeclaration[] unitstoprocess;
public int totalunits; // (totalunits-1) gives the last unit in unittoprocess

// name lookup
public lookupenvironment lookupenvironment;

// once stabilized, these should return to a final field
public static boolean debug = false;
public int parsethreshold = -1;

public abstractannotationprocessormanager annotationprocessormanager;
public int annotationprocessorstartindex = 0;
public referencebinding[] referencebindings;
public boolean usesinglethread = true; // by default the compiler will not use worker threads to read/process/write

// number of initial units parsed at once (-1: none)

/*
* static requestor reserved to listening compilation results in debug mode,
* so as for example to monitor compiler activity independantly from a particular
* builder implementation. it is reset at the end of compilation, and should not
* persist any information after having been reset.
*/
public static idebugrequestor debugrequestor = null;

/**
* answer a new compiler using the given name environment and compiler options.
* the environment and options will be in effect for the lifetime of the compiler.
* when the compiler is run, compilation results are sent to the given requestor.
*
*  @@param environment org.eclipse.jdt.internal.compiler.api.env.inameenvironment
*      environment used by the compiler in order to resolve type and package
*      names. the name environment implements the actual connection of the compiler
*      to the outside world (e.g. in batch mode the name environment is performing
*      pure file accesses, reuse previous build state or connection to repositories).
*      note: the name environment is responsible for implementing the actual classpath
*            rules.
*
*  @@param policy org.eclipse.jdt.internal.compiler.api.problem.ierrorhandlingpolicy
*      configurable part for problem handling, allowing the compiler client to
*      specify the rules for handling problems (stop on first error or accumulate
*      them all) and at the same time perform some actions such as opening a dialog
*      in ui when compiling interactively.
*      @@see org.eclipse.jdt.internal.compiler.defaulterrorhandlingpolicies
*
*  @@param settings java.util.map
*      the settings that control the compiler behavior.
*
*  @@param requestor org.eclipse.jdt.internal.compiler.api.icompilerrequestor
*      component which will receive and persist all compilation results and is intended
*      to consume them as they are produced. typically, in a batch compiler, it is
*      responsible for writing out the actual .class files to the file system.
*      @@see org.eclipse.jdt.internal.compiler.compilationresult
*
*  @@param problemfactory org.eclipse.jdt.internal.compiler.api.problem.iproblemfactory
*      factory used inside the compiler to create problem descriptors. it allows the
*      compiler client to supply its own representation of compilation problems in
*      order to avoid object conversions. note that the factory is not supposed
*      to accumulate the created problems, the compiler will gather them all and hand
*      them back as part of the compilation unit result.
*
*  @@deprecated this constructor is kept to preserve 3.1 and 3.2m4 compatibility
*/
public compiler(
inameenvironment environment,
ierrorhandlingpolicy policy,
map settings,
final icompilerrequestor requestor,
iproblemfactory problemfactory) {
this(environment, policy, new compileroptions(settings), requestor, problemfactory, null /* printwriter */, null /* progress */);
}

/**
* answer a new compiler using the given name environment and compiler options.
* the environment and options will be in effect for the lifetime of the compiler.
* when the compiler is run, compilation results are sent to the given requestor.
*
*  @@param environment org.eclipse.jdt.internal.compiler.api.env.inameenvironment
*      environment used by the compiler in order to resolve type and package
*      names. the name environment implements the actual connection of the compiler
*      to the outside world (e.g. in batch mode the name environment is performing
*      pure file accesses, reuse previous build state or connection to repositories).
*      note: the name environment is responsible for implementing the actual classpath
*            rules.
*
*  @@param policy org.eclipse.jdt.internal.compiler.api.problem.ierrorhandlingpolicy
*      configurable part for problem handling, allowing the compiler client to
*      specify the rules for handling problems (stop on first error or accumulate
*      them all) and at the same time perform some actions such as opening a dialog
*      in ui when compiling interactively.
*      @@see org.eclipse.jdt.internal.compiler.defaulterrorhandlingpolicies
*
*  @@param settings java.util.map
*      the settings that control the compiler behavior.
*
*  @@param requestor org.eclipse.jdt.internal.compiler.api.icompilerrequestor
*      component which will receive and persist all compilation results and is intended
*      to consume them as they are produced. typically, in a batch compiler, it is
*      responsible for writing out the actual .class files to the file system.
*      @@see org.eclipse.jdt.internal.compiler.compilationresult
*
*  @@param problemfactory org.eclipse.jdt.internal.compiler.api.problem.iproblemfactory
*      factory used inside the compiler to create problem descriptors. it allows the
*      compiler client to supply its own representation of compilation problems in
*      order to avoid object conversions. note that the factory is not supposed
*      to accumulate the created problems, the compiler will gather them all and hand
*      them back as part of the compilation unit result.
*
*  @@param parseliteralexpressionsasconstants <code>boolean</code>
*		this parameter is used to optimize the literals or leave them as they are in the source.
* 		if you put true, "hello" + " world" will be converted to "hello world".
*
*  @@deprecated this constructor is kept to preserve 3.1 and 3.2m4 compatibility
*/
public compiler(
inameenvironment environment,
ierrorhandlingpolicy policy,
map settings,
final icompilerrequestor requestor,
iproblemfactory problemfactory,
boolean parseliteralexpressionsasconstants) {
this(environment, policy, new compileroptions(settings, parseliteralexpressionsasconstants), requestor, problemfactory, null /* printwriter */, null /* progress */);
}

/**
* answer a new compiler using the given name environment and compiler options.
* the environment and options will be in effect for the lifetime of the compiler.
* when the compiler is run, compilation results are sent to the given requestor.
*
*  @@param environment org.eclipse.jdt.internal.compiler.api.env.inameenvironment
*      environment used by the compiler in order to resolve type and package
*      names. the name environment implements the actual connection of the compiler
*      to the outside world (e.g. in batch mode the name environment is performing
*      pure file accesses, reuse previous build state or connection to repositories).
*      note: the name environment is responsible for implementing the actual classpath
*            rules.
*
*  @@param policy org.eclipse.jdt.internal.compiler.api.problem.ierrorhandlingpolicy
*      configurable part for problem handling, allowing the compiler client to
*      specify the rules for handling problems (stop on first error or accumulate
*      them all) and at the same time perform some actions such as opening a dialog
*      in ui when compiling interactively.
*      @@see org.eclipse.jdt.internal.compiler.defaulterrorhandlingpolicies
*
*  @@param options org.eclipse.jdt.internal.compiler.impl.compileroptions
*      the options that control the compiler behavior.
*
*  @@param requestor org.eclipse.jdt.internal.compiler.api.icompilerrequestor
*      component which will receive and persist all compilation results and is intended
*      to consume them as they are produced. typically, in a batch compiler, it is
*      responsible for writing out the actual .class files to the file system.
*      @@see org.eclipse.jdt.internal.compiler.compilationresult
*
*  @@param problemfactory org.eclipse.jdt.internal.compiler.api.problem.iproblemfactory
*      factory used inside the compiler to create problem descriptors. it allows the
*      compiler client to supply its own representation of compilation problems in
*      order to avoid object conversions. note that the factory is not supposed
*      to accumulate the created problems, the compiler will gather them all and hand
*      them back as part of the compilation unit result.
*/
public compiler(
inameenvironment environment,
ierrorhandlingpolicy policy,
compileroptions options,
final icompilerrequestor requestor,
iproblemfactory problemfactory) {
this(environment, policy, options, requestor, problemfactory, null /* printwriter */, null /* progress */);
}

/**
* answer a new compiler using the given name environment and compiler options.
* the environment and options will be in effect for the lifetime of the compiler.
* when the compiler is run, compilation results are sent to the given requestor.
*
*  @@param environment org.eclipse.jdt.internal.compiler.api.env.inameenvironment
*      environment used by the compiler in order to resolve type and package
*      names. the name environment implements the actual connection of the compiler
*      to the outside world (e.g. in batch mode the name environment is performing
*      pure file accesses, reuse previous build state or connection to repositories).
*      note: the name environment is responsible for implementing the actual classpath
*            rules.
*
*  @@param policy org.eclipse.jdt.internal.compiler.api.problem.ierrorhandlingpolicy
*      configurable part for problem handling, allowing the compiler client to
*      specify the rules for handling problems (stop on first error or accumulate
*      them all) and at the same time perform some actions such as opening a dialog
*      in ui when compiling interactively.
*      @@see org.eclipse.jdt.internal.compiler.defaulterrorhandlingpolicies
*
*  @@param options org.eclipse.jdt.internal.compiler.impl.compileroptions
*      the options that control the compiler behavior.
*
*  @@param requestor org.eclipse.jdt.internal.compiler.api.icompilerrequestor
*      component which will receive and persist all compilation results and is intended
*      to consume them as they are produced. typically, in a batch compiler, it is
*      responsible for writing out the actual .class files to the file system.
*      @@see org.eclipse.jdt.internal.compiler.compilationresult
*
*  @@param problemfactory org.eclipse.jdt.internal.compiler.api.problem.iproblemfactory
*      factory used inside the compiler to create problem descriptors. it allows the
*      compiler client to supply its own representation of compilation problems in
*      order to avoid object conversions. note that the factory is not supposed
*      to accumulate the created problems, the compiler will gather them all and hand
*      them back as part of the compilation unit result.
* @@deprecated
*/
public compiler(
inameenvironment environment,
ierrorhandlingpolicy policy,
compileroptions options,
final icompilerrequestor requestor,
iproblemfactory problemfactory,
printwriter out) {
this(environment, policy, options, requestor, problemfactory, out, null /* progress */);
}

public compiler(
inameenvironment environment,
ierrorhandlingpolicy policy,
compileroptions options,
final icompilerrequestor requestor,
iproblemfactory problemfactory,
printwriter out,
compilationprogress progress) {

this.options = options;
this.progress = progress;

// wrap requestor in debugrequestor if one is specified
if(debugrequestor == null) {
this.requestor = requestor;
} else {
this.requestor = new icompilerrequestor(){
public void acceptresult(compilationresult result){
if (debugrequestor.isactive()){
debugrequestor.acceptdebugresult(result);
}
requestor.acceptresult(result);
}
};
}
this.problemreporter = new problemreporter(policy, this.options, problemfactory);
this.lookupenvironment = new lookupenvironment(this, this.options, this.problemreporter, environment);
this.out = out == null ? new printwriter(system.out, true) : out;
this.stats = new compilerstats();
initializeparser();
}

/**
* add an additional binary type
*/
public void accept(ibinarytype binarytype, packagebinding packagebinding, accessrestriction accessrestriction) {
if (this.options.verbose) {
this.out.println(
messages.bind(messages.compilation_loadbinary, new string(binarytype.getname())));
//			new exception("trace binary").printstacktrace(system.out);
//		    system.out.println();
}
this.lookupenvironment.createbinarytypefrom(binarytype, packagebinding, accessrestriction);
}

/**
* add an additional compilation unit into the loop
*  ->  build compilation unit declarations, their bindings and record their results.
*/
public void accept(icompilationunit sourceunit, accessrestriction accessrestriction) {
// switch the current policy and compilation result for this unit to the requested one.
compilationresult unitresult =
new compilationresult(sourceunit, this.totalunits, this.totalunits, this.options.maxproblemsperunit);
unitresult.checksecondarytypes = true;
try {
if (this.options.verbose) {
string count = string.valueof(this.totalunits + 1);
this.out.println(
messages.bind(messages.compilation_request,
new string[] {
count,
count,
new string(sourceunit.getfilename())
}));
}
// diet parsing for large collection of unit
compilationunitdeclaration parsedunit;
if (this.totalunits < this.parsethreshold) {
parsedunit = this.parser.parse(sourceunit, unitresult);
} else {
parsedunit = this.parser.dietparse(sourceunit, unitresult);
}
parsedunit.bits |= astnode.isimplicitunit;
// initial type binding creation
this.lookupenvironment.buildtypebindings(parsedunit, accessrestriction);
addcompilationunit(sourceunit, parsedunit);

// binding resolution
this.lookupenvironment.completetypebindings(parsedunit);
} catch (abortcompilationunit e) {
// at this point, currentcompilationunitresult may not be sourceunit, but some other
// one requested further along to resolve sourceunit.
if (unitresult.compilationunit == sourceunit) { // only report once
this.requestor.acceptresult(unitresult.tagasaccepted());
} else {
throw e; // want to abort enclosing request to compile
}
}
}

/**
* add additional source types
*/
public void accept(isourcetype[] sourcetypes, packagebinding packagebinding, accessrestriction accessrestriction) {
this.problemreporter.abortduetointernalerror(
messages.bind(messages.abort_againstsourcemodel, new string[] { string.valueof(sourcetypes[0].getname()), string.valueof(sourcetypes[0].getfilename()) }));
}

protected synchronized void addcompilationunit(
icompilationunit sourceunit,
compilationunitdeclaration parsedunit) {

// append the unit to the list of ones to process later on
int size = this.unitstoprocess.length;
if (this.totalunits == size)
// when growing reposition units starting at position 0
system.arraycopy(
this.unitstoprocess,
0,
(this.unitstoprocess = new compilationunitdeclaration[size * 2]),
0,
this.totalunits);
this.unitstoprocess[this.totalunits++] = parsedunit;
}

/**
* add the initial set of compilation units into the loop
*  ->  build compilation unit declarations, their bindings and record their results.
*/
protected void begintocompile(icompilationunit[] sourceunits) {
int maxunits = sourceunits.length;
this.totalunits = 0;
this.unitstoprocess = new compilationunitdeclaration[maxunits];

internalbegintocompile(sourceunits, maxunits);
}

/**
* checks whether the compilation has been canceled and reports the given progress to the compiler progress.
*/
protected void reportprogress(string taskdecription) {
if (this.progress != null) {
if (this.progress.iscanceled()) {
// only abortcompilation can stop the compiler cleanly.
// we check cancellation again following the call to compile.
throw new abortcompilation(true, null);
}
this.progress.settaskname(taskdecription);
}
}

/**
* checks whether the compilation has been canceled and reports the given work increment to the compiler progress.
*/
protected void reportworked(int workincrement, int currentunitindex) {
if (this.progress != null) {
if (this.progress.iscanceled()) {
// only abortcompilation can stop the compiler cleanly.
// we check cancellation again following the call to compile.
throw new abortcompilation(true, null);
}
this.progress.worked(workincrement, (this.totalunits* this.remainingiterations) - currentunitindex - 1);
}
}

/**
* general api
* -> compile each of supplied files
* -> recompile any required types for which we have an incomplete principle structure
*/
public void compile(icompilationunit[] sourceunits) {
this.stats.starttime = system.currenttimemillis();
compilationunitdeclaration unit = null;
processtaskmanager processingtask = null;
try {
// build and record parsed units
reportprogress(messages.compilation_beginningtocompile);

if (this.annotationprocessormanager == null) {
begintocompile(sourceunits);
} else {
icompilationunit[] originalunits = (icompilationunit[]) sourceunits.clone(); // remember source units in case a source type collision occurs
try {
begintocompile(sourceunits);

processannotations();
if (!this.options.generateclassfiles) {
// -proc:only was set on the command line
return;
}
} catch (sourcetypecollisionexception e) {
reset();
// a generated type was referenced before it was created
// the compiler either created a missingtype or found a binarytype for it
// so add the processor's generated files & start over,
// but remember to only pass the generated files to the annotation processor
int originallength = originalunits.length;
int newprocessedlength = e.newannotationprocessorunits.length;
icompilationunit[] combinedunits = new icompilationunit[originallength + newprocessedlength];
system.arraycopy(originalunits, 0, combinedunits, 0, originallength);
system.arraycopy(e.newannotationprocessorunits, 0, combinedunits, originallength, newprocessedlength);
this.annotationprocessorstartindex  = originallength;
compile(combinedunits);
return;
}
}

if (this.usesinglethread) {
// process all units (some more could be injected in the loop by the lookup environment)
for (int i = 0; i < this.totalunits; i++) {
unit = this.unitstoprocess[i];
reportprogress(messages.bind(messages.compilation_processing, new string(unit.getfilename())));
try {
if (this.options.verbose)
this.out.println(
messages.bind(messages.compilation_process,
new string[] {
string.valueof(i + 1),
string.valueof(this.totalunits),
new string(this.unitstoprocess[i].getfilename())
}));
process(unit, i);
} finally {
// cleanup compilation unit result
unit.cleanup();
}
this.unitstoprocess[i] = null; // release reference to processed unit declaration

reportworked(1, i);
this.stats.linecount += unit.compilationresult.lineseparatorpositions.length;
long acceptstart = system.currenttimemillis();
this.requestor.acceptresult(unit.compilationresult.tagasaccepted());
this.stats.generatetime += system.currenttimemillis() - acceptstart; // record accept time as part of generation
if (this.options.verbose)
this.out.println(
messages.bind(messages.compilation_done,
new string[] {
string.valueof(i + 1),
string.valueof(this.totalunits),
new string(unit.getfilename())
}));
}
} else {
processingtask = new processtaskmanager(this);
int acceptedcount = 0;
// process all units (some more could be injected in the loop by the lookup environment)
// the processtask can continue to process units until its fixed sized cache is full then it must wait
// for this this thread to accept the units as they appear (it only waits if no units are available)
while (true) {
try {
unit = processingtask.removenextunit(); // waits if no units are in the processed queue
} catch (error e) {
unit = processingtask.unittoprocess;
throw e;
} catch (runtimeexception e) {
unit = processingtask.unittoprocess;
throw e;
}
if (unit == null) break;
reportworked(1, acceptedcount++);
this.stats.linecount += unit.compilationresult.lineseparatorpositions.length;
this.requestor.acceptresult(unit.compilationresult.tagasaccepted());
if (this.options.verbose)
this.out.println(
messages.bind(messages.compilation_done,
new string[] {
string.valueof(acceptedcount),
string.valueof(this.totalunits),
new string(unit.getfilename())
}));
}
}
} catch (abortcompilation e) {
this.handleinternalexception(e, unit);
} catch (error e) {
this.handleinternalexception(e, unit, null);
throw e; // rethrow
} catch (runtimeexception e) {
this.handleinternalexception(e, unit, null);
throw e; // rethrow
} finally {
if (processingtask != null) {
processingtask.shutdown();
processingtask = null;
}
reset();
this.annotationprocessorstartindex  = 0;
this.stats.endtime = system.currenttimemillis();
}
if (this.options.verbose) {
if (this.totalunits > 1) {
this.out.println(
messages.bind(messages.compilation_units, string.valueof(this.totalunits)));
} else {
this.out.println(
messages.bind(messages.compilation_unit, string.valueof(this.totalunits)));
}
}
}

public synchronized compilationunitdeclaration getunittoprocess(int next) {
if (next < this.totalunits) {
compilationunitdeclaration unit = this.unitstoprocess[next];
this.unitstoprocess[next] = null; // release reference to processed unit declaration
return unit;
}
return null;
}

public void setbinarytypes(referencebinding[] binarytypes) {
this.referencebindings = binarytypes;
}
/*
* compiler crash recovery in case of unexpected runtime exceptions
*/
protected void handleinternalexception(
throwable internalexception,
compilationunitdeclaration unit,
compilationresult result) {

if (result == null && unit != null) {
result = unit.compilationresult; // current unit being processed ?
}
// lookup environment may be in middle of connecting types
if (result == null && this.lookupenvironment.unitbeingcompleted != null) {
result = this.lookupenvironment.unitbeingcompleted.compilationresult;
}
if (result == null) {
synchronized (this) {
if (this.unitstoprocess != null && this.totalunits > 0)
result = this.unitstoprocess[this.totalunits - 1].compilationresult;
}
}
// last unit in begintocompile ?

boolean needtoprint = true;
if (result != null) {
/* create and record a compilation problem */
// only keep leading portion of the trace
string[] pbarguments = new string[] {
messages.bind(messages.compilation_internalerror, util.getexceptionsummary(internalexception)),
};

result
.record(
this.problemreporter
.createproblem(
result.getfilename(),
iproblem.unclassified,
pbarguments,
pbarguments,
error, // severity
0, // source start
0, // source end
0, // line number
0),// column number
unit);

/* hand back the compilation result */
if (!result.hasbeenaccepted) {
this.requestor.acceptresult(result.tagasaccepted());
needtoprint = false;
}
}
if (needtoprint) {
/* dump a stack trace to the console */
internalexception.printstacktrace();
}
}

/*
* compiler recovery in case of internal abortcompilation event
*/
protected void handleinternalexception(
abortcompilation abortexception,
compilationunitdeclaration unit) {

/* special treatment for silentabort: silently cancelling the compilation process */
if (abortexception.issilent) {
if (abortexception.silentexception == null) {
return;
}
throw abortexception.silentexception;
}

/* uncomment following line to see where the abort came from */
// abortexception.printstacktrace();

// exception may tell which compilation result it is related, and which problem caused it
compilationresult result = abortexception.compilationresult;
if (result == null && unit != null) {
result = unit.compilationresult; // current unit being processed ?
}
// lookup environment may be in middle of connecting types
if (result == null && this.lookupenvironment.unitbeingcompleted != null) {
result = this.lookupenvironment.unitbeingcompleted.compilationresult;
}
if (result == null) {
synchronized (this) {
if (this.unitstoprocess != null && this.totalunits > 0)
result = this.unitstoprocess[this.totalunits - 1].compilationresult;
}
}
// last unit in begintocompile ?
if (result != null && !result.hasbeenaccepted) {
/* distant problem which could not be reported back there? */
if (abortexception.problem != null) {
recorddistantproblem: {
categorizedproblem distantproblem = abortexception.problem;
categorizedproblem[] knownproblems = result.problems;
for (int i = 0; i < result.problemcount; i++) {
if (knownproblems[i] == distantproblem) { // already recorded
break recorddistantproblem;
}
}
if (distantproblem instanceof defaultproblem) { // fixup filename todo (philippe) should improve api to make this official
((defaultproblem) distantproblem).setoriginatingfilename(result.getfilename());
}
result.record(distantproblem, unit);
}
} else {
/* distant internal exception which could not be reported back there */
if (abortexception.exception != null) {
this.handleinternalexception(abortexception.exception, null, result);
return;
}
}
/* hand back the compilation result */
if (!result.hasbeenaccepted) {
this.requestor.acceptresult(result.tagasaccepted());
}
} else {
abortexception.printstacktrace();
}
}

public void initializeparser() {

this.parser = new parser(this.problemreporter, this.options.parseliteralexpressionsasconstants);
}

/**
* add the initial set of compilation units into the loop
*  ->  build compilation unit declarations, their bindings and record their results.
*/
protected void internalbegintocompile(icompilationunit[] sourceunits, int maxunits) {
if (!this.usesinglethread && maxunits >= readmanager.threshold)
this.parser.readmanager = new readmanager(sourceunits, maxunits);

// switch the current policy and compilation result for this unit to the requested one.
for (int i = 0; i < maxunits; i++) {
try {
if (this.options.verbose) {
this.out.println(
messages.bind(messages.compilation_request,
new string[] {
string.valueof(i + 1),
string.valueof(maxunits),
new string(sourceunits[i].getfilename())
}));
}
// diet parsing for large collection of units
compilationunitdeclaration parsedunit;
compilationresult unitresult =
new compilationresult(sourceunits[i], i, maxunits, this.options.maxproblemsperunit);
long parsestart = system.currenttimemillis();
if (this.totalunits < this.parsethreshold) {
parsedunit = this.parser.parse(sourceunits[i], unitresult);
} else {
parsedunit = this.parser.dietparse(sourceunits[i], unitresult);
}
long resolvestart = system.currenttimemillis();
this.stats.parsetime += resolvestart - parsestart;
// initial type binding creation
this.lookupenvironment.buildtypebindings(parsedunit, null /*no access restriction*/);
this.stats.resolvetime += system.currenttimemillis() - resolvestart;
addcompilationunit(sourceunits[i], parsedunit);
importreference currentpackage = parsedunit.currentpackage;
if (currentpackage != null) {
unitresult.recordpackagename(currentpackage.tokens);
}
//} catch (abortcompilationunit e) {
//	requestor.acceptresult(unitresult.tagasaccepted());
} finally {
sourceunits[i] = null; // no longer hold onto the unit
}
}
if (this.parser.readmanager != null) {
this.parser.readmanager.shutdown();
this.parser.readmanager = null;
}
// binding resolution
this.lookupenvironment.completetypebindings();
}

/**
* process a compilation unit already parsed and build.
*/
public void process(compilationunitdeclaration unit, int i) {
this.lookupenvironment.unitbeingcompleted = unit;
long parsestart = system.currenttimemillis();

this.parser.getmethodbodies(unit);

long resolvestart = system.currenttimemillis();
this.stats.parsetime += resolvestart - parsestart;

// fault in fields & methods
if (unit.scope != null)
unit.scope.faultintypes();

// verify inherited methods
if (unit.scope != null)
unit.scope.verifymethods(this.lookupenvironment.methodverifier());

// type checking
unit.resolve();

long analyzestart = system.currenttimemillis();
this.stats.resolvetime += analyzestart - resolvestart;

//no need of analysis or generation of code if statements are not required
if (!this.options.ignoremethodbodies) unit.analysecode(); // flow analysis

long generatestart = system.currenttimemillis();
this.stats.analyzetime += generatestart - analyzestart;

if (!this.options.ignoremethodbodies) unit.generatecode(); // code generation

// reference info
if (this.options.producereferenceinfo && unit.scope != null)
unit.scope.storedependencyinfo();

// finalize problems (suppresswarnings)
unit.finalizeproblems();

this.stats.generatetime += system.currenttimemillis() - generatestart;

// refresh the total number of units known at this stage
unit.compilationresult.totalunitsknown = this.totalunits;

this.lookupenvironment.unitbeingcompleted = null;
}

protected void processannotations() {
int newunitsize = 0;
int newclassfilessize = 0;
int bottom = this.annotationprocessorstartindex;
int top = this.totalunits;
referencebinding[] binarytypebindingstemp = this.referencebindings;
if (top == 0 && binarytypebindingstemp == null) return;
this.referencebindings = null;
do {
// extract units to process
int length = top - bottom;
compilationunitdeclaration[] currentunits = new compilationunitdeclaration[length];
int index = 0;
for (int i = bottom; i < top; i++) {
compilationunitdeclaration currentunit = this.unitstoprocess[i];
if ((currentunit.bits & astnode.isimplicitunit) == 0) {
currentunits[index++] = currentunit;
}
}
if (index != length) {
system.arraycopy(currentunits, 0, (currentunits = new compilationunitdeclaration[index]), 0, index);
}
this.annotationprocessormanager.processannotations(currentunits, binarytypebindingstemp, false);
icompilationunit[] newunits = this.annotationprocessormanager.getnewunits();
newunitsize = newunits.length;
referencebinding[] newclassfiles = this.annotationprocessormanager.getnewclassfiles();
binarytypebindingstemp = newclassfiles;
newclassfilessize = newclassfiles.length;
if (newunitsize != 0) {
icompilationunit[] newprocessedunits = (icompilationunit[]) newunits.clone(); // remember new units in case a source type collision occurs
try {
this.lookupenvironment.isprocessingannotations = true;
internalbegintocompile(newunits, newunitsize);
} catch (sourcetypecollisionexception e) {
e.newannotationprocessorunits = newprocessedunits;
throw e;
} finally {
this.lookupenvironment.isprocessingannotations = false;
this.annotationprocessormanager.reset();
}
bottom = top;
top = this.totalunits; // last unit added
} else {
bottom = top;
this.annotationprocessormanager.reset();
}
} while (newunitsize != 0 || newclassfilessize != 0);
// one more loop to create possible resources
// this loop cannot create any java source files
this.annotationprocessormanager.processannotations(null, null, true);
// todo we might want to check if this loop created new units
}

public void reset() {
this.lookupenvironment.reset();
this.parser.scanner.source = null;
this.unitstoprocess = null;
if (debugrequestor != null) debugrequestor.reset();
this.problemreporter.reset();
}

/**
* internal api used to resolve a given compilation unit. can run a subset of the compilation process
*/
public compilationunitdeclaration resolve(
compilationunitdeclaration unit,
icompilationunit sourceunit,
boolean verifymethods,
boolean analyzecode,
boolean generatecode) {

try {
if (unit == null) {
// build and record parsed units
this.parsethreshold = 0; // will request a full parse
begintocompile(new icompilationunit[] { sourceunit });
// process all units (some more could be injected in the loop by the lookup environment)
unit = this.unitstoprocess[0];
} else {
// initial type binding creation
this.lookupenvironment.buildtypebindings(unit, null /*no access restriction*/);

// binding resolution
this.lookupenvironment.completetypebindings();
}
this.lookupenvironment.unitbeingcompleted = unit;
this.parser.getmethodbodies(unit);
if (unit.scope != null) {
// fault in fields & methods
unit.scope.faultintypes();
if (unit.scope != null && verifymethods) {
// http://dev.eclipse.org/bugs/show_bug.cgi?id=23117
// verify inherited methods
unit.scope.verifymethods(this.lookupenvironment.methodverifier());
}
// type checking
unit.resolve();

// flow analysis
if (analyzecode) unit.analysecode();

// code generation
if (generatecode) unit.generatecode();

// finalize problems (suppresswarnings)
unit.finalizeproblems();
}
if (this.unitstoprocess != null) this.unitstoprocess[0] = null; // release reference to processed unit declaration
this.requestor.acceptresult(unit.compilationresult.tagasaccepted());
return unit;
} catch (abortcompilation e) {
this.handleinternalexception(e, unit);
return unit == null ? this.unitstoprocess[0] : unit;
} catch (error e) {
this.handleinternalexception(e, unit, null);
throw e; // rethrow
} catch (runtimeexception e) {
this.handleinternalexception(e, unit, null);
throw e; // rethrow
} finally {
// leave this.lookupenvironment.unitbeingcompleted set to the unit, until another unit is resolved
// other calls to dom can cause classpath errors to be detected, resulting in abortcompilation exceptions

// no reset is performed there anymore since,
// within the codeassist (or related tools),
// the compiler may be called *after* a call
// to this resolve(...) method. and such a call
// needs to have a compiler with a non-empty
// environment.
// this.reset();
}
}
/**
* internal api used to resolve a given compilation unit. can run a subset of the compilation process
*/
public compilationunitdeclaration resolve(
icompilationunit sourceunit,
boolean verifymethods,
boolean analyzecode,
boolean generatecode) {

return resolve(
null,
sourceunit,
verifymethods,
analyzecode,
generatecode);
}
}
