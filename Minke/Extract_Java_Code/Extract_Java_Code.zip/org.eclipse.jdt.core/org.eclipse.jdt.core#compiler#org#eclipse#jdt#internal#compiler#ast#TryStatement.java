/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class trystatement extends subroutinestatement {

private final static char[] secret_return_address_name = " returnaddress".tochararray(); //$non-nls-1$
private final static char[] secret_any_handler_name = " anyexceptionhandler".tochararray(); //$non-nls-1$
private final static char[] secret_return_value_name = " returnvalue".tochararray(); //$non-nls-1$

public block tryblock;
public block[] catchblocks;

public argument[] catcharguments;

// should rename into subroutinecomplete to be set to false by default

public block finallyblock;
blockscope scope;

public unconditionalflowinfo subroutineinits;
referencebinding[] caughtexceptiontypes;
boolean[] catchexits;

branchlabel subroutinestartlabel;
public localvariablebinding anyexceptionvariable,
returnaddressvariable,
secretreturnvalue;

exceptionlabel[] declaredexceptionlabels; // only set while generating code

// for inlining/optimizing jsr instructions
private object[] reusablejsrtargets;
private branchlabel[] reusablejsrsequencestartlabels;
private int[] reusablejsrstateindexes;
private int reusablejsrtargetscount = 0;

private final static int no_finally = 0;										// no finally block
private final static int finally_subroutine = 1; 					// finally is generated as a subroutine (using jsr/ret bytecodes)
private final static int finally_does_not_complete = 2;		// non returning finally is optimized with only one instance of finally block
private final static int finally_inline = 3;								// finally block must be inlined since cannot use jsr/ret bytecodes >1.5

// for local variables table attributes
int mergedinitstateindex = -1;
int pretryinitstateindex = -1;
int naturalexitmergeinitstateindex = -1;
int[] catchexitinitstateindexes;

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {

// consider the try block and catch block so as to compute the intersection of initializations and
// the minimum exit relative depth amongst all of them. then consider the subroutine, and append its
// initialization to the try/catch ones, if the subroutine completes normally. if the subroutine does not
// complete, then only keep this result for the rest of the analysis

// process the finally block (subroutine) - create a context for the subroutine

this.pretryinitstateindex =
currentscope.methodscope().recordinitializationstates(flowinfo);

if (this.anyexceptionvariable != null) {
this.anyexceptionvariable.useflag = localvariablebinding.used;
}
if (this.returnaddressvariable != null) { // todo (philippe) if subroutine is escaping, unused
this.returnaddressvariable.useflag = localvariablebinding.used;
}
if (this.subroutinestartlabel == null) {
// no finally block -- this is a simplified copy of the else part
// process the try block in a context handling the local exceptions.
exceptionhandlingflowcontext handlingcontext =
new exceptionhandlingflowcontext(
flowcontext,
this,
this.caughtexceptiontypes,
null,
this.scope,
flowinfo.unconditionalinits());
handlingcontext.initsonfinally =
new nullinforegistry(flowinfo.unconditionalinits());
// only try blocks initialize that member - may consider creating a
// separate class if needed

flowinfo tryinfo;
if (this.tryblock.isemptyblock()) {
tryinfo = flowinfo;
} else {
tryinfo = this.tryblock.analysecode(currentscope, handlingcontext, flowinfo.copy());
if ((tryinfo.tagbits & flowinfo.unreachable) != 0)
this.bits |= astnode.istryblockexiting;
}

// check unreachable catch blocks
handlingcontext.complainifunusedexceptionhandlers(this.scope, this);

// process the catch blocks - computing the minimal exit depth amongst try/catch
if (this.catcharguments != null) {
int catchcount;
this.catchexits = new boolean[catchcount = this.catchblocks.length];
this.catchexitinitstateindexes = new int[catchcount];
for (int i = 0; i < catchcount; i++) {
// keep track of the inits that could potentially have led to this exception handler (for final assignments diagnosis)
flowinfo catchinfo;
if (this.caughtexceptiontypes[i].isuncheckedexception(true)) {
catchinfo =
handlingcontext.initsonfinally.mitigatenullinfoof(
flowinfo.unconditionalcopy().
addpotentialinitializationsfrom(
handlingcontext.initsonexception(
this.caughtexceptiontypes[i])).
addpotentialinitializationsfrom(tryinfo).
addpotentialinitializationsfrom(
handlingcontext.initsonreturn));
} else {
catchinfo =
flowinfo.unconditionalcopy().
addpotentialinitializationsfrom(
handlingcontext.initsonexception(
this.caughtexceptiontypes[i]))
.addpotentialinitializationsfrom(tryinfo.unconditionalcopy())
.addpotentialinitializationsfrom(
handlingcontext.initsonreturn.
nullinfolessunconditionalcopy());
}

// catch var is always set
localvariablebinding catcharg = this.catcharguments[i].binding;
catchinfo.markasdefinitelyassigned(catcharg);
catchinfo.markasdefinitelynonnull(catcharg);
/*
"if we are about to consider an unchecked exception handler, potential inits may have occured inside
the try block that need to be detected , e.g.
try { x = 1; throwsomething();} catch(exception e){ x = 2} "
"(uncheckedexceptiontypes notnil and: [uncheckedexceptiontypes at: index])
iftrue: [catchinits addpotentialinitializationsfrom: tryinits]."
*/
if (this.tryblock.statements == null) {
catchinfo.setreachmode(flowinfo.unreachable);
}
catchinfo =
this.catchblocks[i].analysecode(
currentscope,
flowcontext,
catchinfo);
this.catchexitinitstateindexes[i] = currentscope.methodscope().recordinitializationstates(catchinfo);
this.catchexits[i] =
(catchinfo.tagbits & flowinfo.unreachable) != 0;
tryinfo = tryinfo.mergedwith(catchinfo.unconditionalinits());
}
}
this.mergedinitstateindex =
currentscope.methodscope().recordinitializationstates(tryinfo);

// chain up null info registry
if (flowcontext.initsonfinally != null) {
flowcontext.initsonfinally.add(handlingcontext.initsonfinally);
}

return tryinfo;
} else {
insidesubroutineflowcontext insidesubcontext;
finallyflowcontext finallycontext;
unconditionalflowinfo subinfo;
// analyse finally block first
insidesubcontext = new insidesubroutineflowcontext(flowcontext, this);

subinfo =
this.finallyblock
.analysecode(
currentscope,
finallycontext = new finallyflowcontext(flowcontext, this.finallyblock),
flowinfo.nullinfolessunconditionalcopy())
.unconditionalinits();
if (subinfo == flowinfo.dead_end) {
this.bits |= astnode.issubroutineescaping;
this.scope.problemreporter().finallymustcompletenormally(this.finallyblock);
}
this.subroutineinits = subinfo;
// process the try block in a context handling the local exceptions.
exceptionhandlingflowcontext handlingcontext =
new exceptionhandlingflowcontext(
insidesubcontext,
this,
this.caughtexceptiontypes,
null,
this.scope,
flowinfo.unconditionalinits());
handlingcontext.initsonfinally =
new nullinforegistry(flowinfo.unconditionalinits());
// only try blocks initialize that member - may consider creating a
// separate class if needed

flowinfo tryinfo;
if (this.tryblock.isemptyblock()) {
tryinfo = flowinfo;
} else {
tryinfo = this.tryblock.analysecode(currentscope, handlingcontext, flowinfo.copy());
if ((tryinfo.tagbits & flowinfo.unreachable) != 0)
this.bits |= astnode.istryblockexiting;
}

// check unreachable catch blocks
handlingcontext.complainifunusedexceptionhandlers(this.scope, this);

// process the catch blocks - computing the minimal exit depth amongst try/catch
if (this.catcharguments != null) {
int catchcount;
this.catchexits = new boolean[catchcount = this.catchblocks.length];
this.catchexitinitstateindexes = new int[catchcount];
for (int i = 0; i < catchcount; i++) {
// keep track of the inits that could potentially have led to this exception handler (for final assignments diagnosis)
flowinfo catchinfo;
if (this.caughtexceptiontypes[i].isuncheckedexception(true)) {
catchinfo =
handlingcontext.initsonfinally.mitigatenullinfoof(
flowinfo.unconditionalcopy().
addpotentialinitializationsfrom(
handlingcontext.initsonexception(
this.caughtexceptiontypes[i])).
addpotentialinitializationsfrom(tryinfo).
addpotentialinitializationsfrom(
handlingcontext.initsonreturn));
}else {
catchinfo =
flowinfo.unconditionalcopy()
.addpotentialinitializationsfrom(
handlingcontext.initsonexception(
this.caughtexceptiontypes[i]))
.addpotentialinitializationsfrom(tryinfo.unconditionalcopy())
.addpotentialinitializationsfrom(
handlingcontext.initsonreturn.
nullinfolessunconditionalcopy());
}

// catch var is always set
localvariablebinding catcharg = this.catcharguments[i].binding;
catchinfo.markasdefinitelyassigned(catcharg);
catchinfo.markasdefinitelynonnull(catcharg);
/*
"if we are about to consider an unchecked exception handler, potential inits may have occured inside
the try block that need to be detected , e.g.
try { x = 1; throwsomething();} catch(exception e){ x = 2} "
"(uncheckedexceptiontypes notnil and: [uncheckedexceptiontypes at: index])
iftrue: [catchinits addpotentialinitializationsfrom: tryinits]."
*/
if (this.tryblock.statements == null) {
catchinfo.setreachmode(flowinfo.unreachable);
}
catchinfo =
this.catchblocks[i].analysecode(
currentscope,
insidesubcontext,
catchinfo);
this.catchexitinitstateindexes[i] = currentscope.methodscope().recordinitializationstates(catchinfo);
this.catchexits[i] =
(catchinfo.tagbits & flowinfo.unreachable) != 0;
tryinfo = tryinfo.mergedwith(catchinfo.unconditionalinits());
}
}
// we also need to check potential multiple assignments of final variables inside the finally block
// need to include potential inits from returns inside the try/catch parts - 1gk2aof
finallycontext.complainondeferredchecks(
handlingcontext.initsonfinally.mitigatenullinfoof(
(tryinfo.tagbits & flowinfo.unreachable) == 0 ?
flowinfo.unconditionalcopy().
addpotentialinitializationsfrom(tryinfo).
// lighten the influence of the try block, which may have
// exited at any point
addpotentialinitializationsfrom(insidesubcontext.initsonreturn) :
insidesubcontext.initsonreturn),
currentscope);

// chain up null info registry
if (flowcontext.initsonfinally != null) {
flowcontext.initsonfinally.add(handlingcontext.initsonfinally);
}

this.naturalexitmergeinitstateindex =
currentscope.methodscope().recordinitializationstates(tryinfo);
if (subinfo == flowinfo.dead_end) {
this.mergedinitstateindex =
currentscope.methodscope().recordinitializationstates(subinfo);
return subinfo;
} else {
flowinfo mergedinfo = tryinfo.addinitializationsfrom(subinfo);
this.mergedinitstateindex =
currentscope.methodscope().recordinitializationstates(mergedinfo);
return mergedinfo;
}
}
}

public exceptionlabel enteranyexceptionhandler(codestream codestream) {
if (this.subroutinestartlabel == null)
return null;
return super.enteranyexceptionhandler(codestream);
}

public void enterdeclaredexceptionhandlers(codestream codestream) {
for (int i = 0, length = this.declaredexceptionlabels == null ? 0 : this.declaredexceptionlabels.length; i < length; i++) {
this.declaredexceptionlabels[i].placestart();
}
}

public void exitanyexceptionhandler() {
if (this.subroutinestartlabel == null)
return;
super.exitanyexceptionhandler();
}

public void exitdeclaredexceptionhandlers(codestream codestream) {
for (int i = 0, length = this.declaredexceptionlabels == null ? 0 : this.declaredexceptionlabels.length; i < length; i++) {
this.declaredexceptionlabels[i].placeend();
}
}

private int finallymode() {
if (this.subroutinestartlabel == null) {
return no_finally;
} else if (issubroutineescaping()) {
return finally_does_not_complete;
} else if (this.scope.compileroptions().inlinejsrbytecode) {
return finally_inline;
} else {
return finally_subroutine;
}
}
/**
* try statement code generation with or without jsr bytecode use
*	post 1.5 target level, cannot use jsr bytecode, must instead inline finally block
* returnaddress is only allocated if jsr is allowed
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & astnode.isreachable) == 0) {
return;
}
boolean isstackmapframecodestream = codestream instanceof stackmapframecodestream;
// in case the labels needs to be reinitialized
// when the code generation is restarted in wide mode
this.anyexceptionlabel = null;
this.reusablejsrtargets = null;
this.reusablejsrsequencestartlabels = null;
this.reusablejsrtargetscount = 0;

int pc = codestream.position;
int finallymode = finallymode();

boolean requiresnaturalexit = false;
// preparing exception labels
int maxcatches = this.catcharguments == null ? 0 : this.catcharguments.length;
exceptionlabel[] exceptionlabels;
if (maxcatches > 0) {
exceptionlabels = new exceptionlabel[maxcatches];
for (int i = 0; i < maxcatches; i++) {
exceptionlabel exceptionlabel = new exceptionlabel(codestream, this.catcharguments[i].binding.type);
exceptionlabel.placestart();
exceptionlabels[i] = exceptionlabel;
}
} else {
exceptionlabels = null;
}
if (this.subroutinestartlabel != null) {
this.subroutinestartlabel.initialize(codestream);
enteranyexceptionhandler(codestream);
}
// generate the try block
try {
this.declaredexceptionlabels = exceptionlabels;
this.tryblock.generatecode(this.scope, codestream);
} finally {
this.declaredexceptionlabels = null;
}
boolean tryblockhassomecode = codestream.position != pc;
// flag telling if some bytecodes were issued inside the try block

// place end positions of user-defined exception labels
if (tryblockhassomecode) {
// natural exit may require subroutine invocation (if finally != null)
branchlabel naturalexitlabel = new branchlabel(codestream);
branchlabel postcatchesfinallylabel = null;
for (int i = 0; i < maxcatches; i++) {
exceptionlabels[i].placeend();
}
if ((this.bits & astnode.istryblockexiting) == 0) {
int position = codestream.position;
switch(finallymode) {
case finally_subroutine :
case finally_inline :
requiresnaturalexit = true;
if (this.naturalexitmergeinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
}
codestream.goto_(naturalexitlabel);
break;
case no_finally :
if (this.naturalexitmergeinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
}
codestream.goto_(naturalexitlabel);
break;
case finally_does_not_complete :
codestream.goto_(this.subroutinestartlabel);
break;
}
codestream.updatelastrecordedendpc(this.tryblock.scope, position);
//goto is tagged as part of the try block
}
/* generate sequence of handler, all starting by storing the tos (exception
thrown) into their own catch variables, the one specified in the source
that must denote the handled exception.
*/
exitanyexceptionhandler();
if (this.catcharguments != null) {
postcatchesfinallylabel = new branchlabel(codestream);

for (int i = 0; i < maxcatches; i++) {
/*
* this should not happen. for consistency purpose, if the exception label is never used
* we also don't generate the corresponding catch block, otherwise we have some
* unreachable bytecodes
*/
if (exceptionlabels[i].count == 0) continue;
enteranyexceptionhandler(codestream);
// may loose some local variable initializations : affecting the local variable attributes
if (this.pretryinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.pretryinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.pretryinitstateindex);
}
codestream.pushexceptiononstack(exceptionlabels[i].exceptiontype);
exceptionlabels[i].place();
// optimizing the case where the exception variable is not actually used
localvariablebinding catchvar;
int varpc = codestream.position;
if ((catchvar = this.catcharguments[i].binding).resolvedposition != -1) {
codestream.store(catchvar, false);
catchvar.recordinitializationstartpc(codestream.position);
codestream.addvisiblelocalvariable(catchvar);
} else {
codestream.pop();
}
codestream.recordpositionsfrom(varpc, this.catcharguments[i].sourcestart);
// keep track of the pcs at diverging point for computing the local attribute
// since not passing the catchscope, the block generation will exituserscope(catchscope)
this.catchblocks[i].generatecode(this.scope, codestream);
exitanyexceptionhandler();
if (!this.catchexits[i]) {
switch(finallymode) {
case finally_inline :
// inlined finally here can see all merged variables
if (isstackmapframecodestream) {
((stackmapframecodestream) codestream).pushstateindex(this.naturalexitmergeinitstateindex);
}
if (this.catchexitinitstateindexes[i] != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.catchexitinitstateindexes[i]);
codestream.adddefinitelyassignedvariables(currentscope, this.catchexitinitstateindexes[i]);
}
// entire sequence for finally is associated to finally block
this.finallyblock.generatecode(this.scope, codestream);
codestream.goto_(postcatchesfinallylabel);
if (isstackmapframecodestream) {
((stackmapframecodestream) codestream).popstateindex();
}
break;
case finally_subroutine :
requiresnaturalexit = true;
//$fall-through$
case no_finally :
if (this.naturalexitmergeinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
}
codestream.goto_(naturalexitlabel);
break;
case finally_does_not_complete :
codestream.goto_(this.subroutinestartlabel);
break;
}
}
}
}
// extra handler for trailing natural exit (will be fixed up later on when natural exit is generated below)
exceptionlabel naturalexitexceptionhandler = requiresnaturalexit && (finallymode == finally_subroutine)
? new exceptionlabel(codestream, null)
: null;

// addition of a special handler so as to ensure that any uncaught exception (or exception thrown
// inside catch blocks) will run the finally block
int finallysequencestartpc = codestream.position;
if (this.subroutinestartlabel != null && this.anyexceptionlabel.count != 0) {
codestream.pushexceptiononstack(this.scope.getjavalangthrowable());
if (this.pretryinitstateindex != -1) {
// reset initialization state, as for a normal catch block
codestream.removenotdefinitelyassignedvariables(currentscope, this.pretryinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.pretryinitstateindex);
}
placeallanyexceptionhandler();
if (naturalexitexceptionhandler != null) naturalexitexceptionhandler.place();

switch(finallymode) {
case finally_subroutine :
// any exception handler
codestream.store(this.anyexceptionvariable, false);
codestream.jsr(this.subroutinestartlabel);
codestream.recordpositionsfrom(finallysequencestartpc, this.finallyblock.sourcestart);
int position = codestream.position;
codestream.throwanyexception(this.anyexceptionvariable);
codestream.recordpositionsfrom(position, this.finallyblock.sourceend);
// subroutine
this.subroutinestartlabel.place();
codestream.pushexceptiononstack(this.scope.getjavalangthrowable());
position = codestream.position;
codestream.store(this.returnaddressvariable, false);
codestream.recordpositionsfrom(position, this.finallyblock.sourcestart);
this.finallyblock.generatecode(this.scope, codestream);
position = codestream.position;
codestream.ret(this.returnaddressvariable.resolvedposition);
codestream.recordpositionsfrom(
position,
this.finallyblock.sourceend);
// the ret bytecode is part of the subroutine
break;
case finally_inline :
// any exception handler
codestream.store(this.anyexceptionvariable, false);
codestream.addvariable(this.anyexceptionvariable);
codestream.recordpositionsfrom(finallysequencestartpc, this.finallyblock.sourcestart);
// subroutine
this.finallyblock.generatecode(currentscope, codestream);
position = codestream.position;
codestream.throwanyexception(this.anyexceptionvariable);
codestream.removevariable(this.anyexceptionvariable);
if (this.pretryinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.pretryinitstateindex);
}
this.subroutinestartlabel.place();
codestream.recordpositionsfrom(position, this.finallyblock.sourceend);
break;
case finally_does_not_complete :
// any exception handler
codestream.pop();
this.subroutinestartlabel.place();
codestream.recordpositionsfrom(finallysequencestartpc, this.finallyblock.sourcestart);
// subroutine
this.finallyblock.generatecode(this.scope, codestream);
break;
}

// will naturally fall into subsequent code after subroutine invocation
if (requiresnaturalexit) {
switch(finallymode) {
case finally_subroutine :
naturalexitlabel.place();
int position = codestream.position;
naturalexitexceptionhandler.placestart();
codestream.jsr(this.subroutinestartlabel);
naturalexitexceptionhandler.placeend();
codestream.recordpositionsfrom(
position,
this.finallyblock.sourceend);
break;
case finally_inline :
// inlined finally here can see all merged variables
if (isstackmapframecodestream) {
((stackmapframecodestream) codestream).pushstateindex(this.naturalexitmergeinitstateindex);
}
if (this.naturalexitmergeinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
}
naturalexitlabel.place();
// entire sequence for finally is associated to finally block
this.finallyblock.generatecode(this.scope, codestream);
if (postcatchesfinallylabel != null) {
position = codestream.position;
// entire sequence for finally is associated to finally block
codestream.goto_(postcatchesfinallylabel);
codestream.recordpositionsfrom(
position,
this.finallyblock.sourceend);
}
if (isstackmapframecodestream) {
((stackmapframecodestream) codestream).popstateindex();
}
break;
case finally_does_not_complete :
break;
default :
naturalexitlabel.place();
break;
}
}
if (postcatchesfinallylabel != null) {
postcatchesfinallylabel.place();
}
} else {
// no subroutine, simply position end label (natural exit == end)
naturalexitlabel.place();
}
} else {
// try block had no effect, only generate the body of the finally block if any
if (this.subroutinestartlabel != null) {
this.finallyblock.generatecode(this.scope, codestream);
}
}
// may loose some local variable initializations : affecting the local variable attributes
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* @@see subroutinestatement#generatesubroutineinvocation(blockscope, codestream, object, int, localvariablebinding)
*/
public boolean generatesubroutineinvocation(blockscope currentscope, codestream codestream, object targetlocation, int stateindex, localvariablebinding secretlocal) {

boolean isstackmapframecodestream = codestream instanceof stackmapframecodestream;
int finallymode = finallymode();
switch(finallymode) {
case finally_does_not_complete :
codestream.goto_(this.subroutinestartlabel);
return true;

case no_finally :
exitdeclaredexceptionhandlers(codestream);
return false;
}
// optimize subroutine invocation sequences, using the targetlocation (if any)
if (targetlocation != null) {
boolean reusetargetlocation = true;
if (this.reusablejsrtargetscount > 0) {
nextreusabletarget: for (int i = 0, count = this.reusablejsrtargetscount; i < count; i++) {
object reusablejsrtarget = this.reusablejsrtargets[i];
differenttarget: {
if (targetlocation == reusablejsrtarget)
break differenttarget;
if (targetlocation instanceof constant
&& reusablejsrtarget instanceof constant
&& ((constant)targetlocation).hassamevalue((constant) reusablejsrtarget)) {
break differenttarget;
}
// cannot reuse current target
continue nextreusabletarget;
}
// current target has been used in the past, simply branch to its label
if ((this.reusablejsrstateindexes[i] != stateindex) && finallymode == finally_inline) {
reusetargetlocation = false;
break nextreusabletarget;
} else {
codestream.goto_(this.reusablejsrsequencestartlabels[i]);
return true;
}
}
} else {
this.reusablejsrtargets = new object[3];
this.reusablejsrsequencestartlabels = new branchlabel[3];
this.reusablejsrstateindexes = new int[3];
}
if (reusetargetlocation) {
if (this.reusablejsrtargetscount == this.reusablejsrtargets.length) {
system.arraycopy(this.reusablejsrtargets, 0, this.reusablejsrtargets = new object[2*this.reusablejsrtargetscount], 0, this.reusablejsrtargetscount);
system.arraycopy(this.reusablejsrsequencestartlabels, 0, this.reusablejsrsequencestartlabels = new branchlabel[2*this.reusablejsrtargetscount], 0, this.reusablejsrtargetscount);
system.arraycopy(this.reusablejsrstateindexes, 0, this.reusablejsrstateindexes = new int[2*this.reusablejsrtargetscount], 0, this.reusablejsrtargetscount);
}
this.reusablejsrtargets[this.reusablejsrtargetscount] = targetlocation;
branchlabel reusablejsrsequencestartlabel = new branchlabel(codestream);
reusablejsrsequencestartlabel.place();
this.reusablejsrstateindexes[this.reusablejsrtargetscount] = stateindex;
this.reusablejsrsequencestartlabels[this.reusablejsrtargetscount++] = reusablejsrsequencestartlabel;
}
}
if (finallymode == finally_inline) {
if (isstackmapframecodestream) {
((stackmapframecodestream) codestream).pushstateindex(stateindex);
if (this.naturalexitmergeinitstateindex != -1 || stateindex != -1) {
// reset initialization state, as for a normal catch block
codestream.removenotdefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
}
} else {
if (this.naturalexitmergeinitstateindex != -1) {
// reset initialization state, as for a normal catch block
codestream.removenotdefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.naturalexitmergeinitstateindex);
}
}
if (secretlocal != null) {
codestream.addvariable(secretlocal);
}
// cannot use jsr bytecode, then simply inline the subroutine
// inside try block, ensure to deactivate all catch block exception handlers while inlining finally block
exitanyexceptionhandler();
exitdeclaredexceptionhandlers(codestream);
this.finallyblock.generatecode(currentscope, codestream);
if (isstackmapframecodestream) {
((stackmapframecodestream) codestream).popstateindex();
}
} else {
// classic subroutine invocation, distinguish case of non-returning subroutine
codestream.jsr(this.subroutinestartlabel);
exitanyexceptionhandler();
exitdeclaredexceptionhandlers(codestream);
}
return false;
}
public boolean issubroutineescaping() {
return (this.bits & astnode.issubroutineescaping) != 0;
}

public stringbuffer printstatement(int indent, stringbuffer output) {
printindent(indent, output).append("try \n"); //$non-nls-1$
this.tryblock.printstatement(indent + 1, output);

//catches
if (this.catchblocks != null)
for (int i = 0; i < this.catchblocks.length; i++) {
output.append('\n');
printindent(indent, output).append("catch ("); //$non-nls-1$
this.catcharguments[i].print(0, output).append(") "); //$non-nls-1$
this.catchblocks[i].printstatement(indent + 1, output);
}
//finally
if (this.finallyblock != null) {
output.append('\n');
printindent(indent, output).append("finally\n"); //$non-nls-1$
this.finallyblock.printstatement(indent + 1, output);
}
return output;
}

public void resolve(blockscope upperscope) {
// special scope for secret locals optimization.
this.scope = new blockscope(upperscope);

blockscope tryscope = new blockscope(this.scope);
blockscope finallyscope = null;

if (this.finallyblock != null) {
if (this.finallyblock.isemptyblock()) {
if ((this.finallyblock.bits & astnode.undocumentedemptyblock) != 0) {
this.scope.problemreporter().undocumentedemptyblock(this.finallyblock.sourcestart, this.finallyblock.sourceend);
}
} else {
finallyscope = new blockscope(this.scope, false); // don't add it yet to parent scope

// provision for returning and forcing the finally block to run
methodscope methodscope = this.scope.methodscope();

// the type does not matter as long as it is not a base type
if (!upperscope.compileroptions().inlinejsrbytecode) {
this.returnaddressvariable =
new localvariablebinding(trystatement.secret_return_address_name, upperscope.getjavalangobject(), classfileconstants.accdefault, false);
finallyscope.addlocalvariable(this.returnaddressvariable);
this.returnaddressvariable.setconstant(constant.notaconstant); // not inlinable
}
this.subroutinestartlabel = new branchlabel();

this.anyexceptionvariable =
new localvariablebinding(trystatement.secret_any_handler_name, this.scope.getjavalangthrowable(), classfileconstants.accdefault, false);
finallyscope.addlocalvariable(this.anyexceptionvariable);
this.anyexceptionvariable.setconstant(constant.notaconstant); // not inlinable

if (!methodscope.isinsideinitializer()) {
methodbinding methodbinding =
((abstractmethoddeclaration) methodscope.referencecontext).binding;
if (methodbinding != null) {
typebinding methodreturntype = methodbinding.returntype;
if (methodreturntype.id != typeids.t_void) {
this.secretreturnvalue =
new localvariablebinding(
trystatement.secret_return_value_name,
methodreturntype,
classfileconstants.accdefault,
false);
finallyscope.addlocalvariable(this.secretreturnvalue);
this.secretreturnvalue.setconstant(constant.notaconstant); // not inlinable
}
}
}
this.finallyblock.resolveusing(finallyscope);
// force the finally scope to have variable positions shifted after its try scope and catch ones
finallyscope.shiftscopes = new blockscope[this.catcharguments == null ? 1 : this.catcharguments.length+1];
finallyscope.shiftscopes[0] = tryscope;
}
}
this.tryblock.resolveusing(tryscope);

// arguments type are checked against javalangthrowable in resolveforcatch(..)
if (this.catchblocks != null) {
int length = this.catcharguments.length;
typebinding[] argumenttypes = new typebinding[length];
boolean catchhaserror = false;
for (int i = 0; i < length; i++) {
blockscope catchscope = new blockscope(this.scope);
if (finallyscope != null){
finallyscope.shiftscopes[i+1] = catchscope;
}
// side effect on catchscope in resolveforcatch(..)
if ((argumenttypes[i] = this.catcharguments[i].resolveforcatch(catchscope)) == null) {
catchhaserror = true;
}
this.catchblocks[i].resolveusing(catchscope);
}
if (catchhaserror) {
return;
}
// verify that the catch clause are ordered in the right way:
// more specialized first.
this.caughtexceptiontypes = new referencebinding[length];
for (int i = 0; i < length; i++) {
this.caughtexceptiontypes[i] = (referencebinding) argumenttypes[i];
for (int j = 0; j < i; j++) {
if (this.caughtexceptiontypes[i].iscompatiblewith(argumenttypes[j])) {
this.scope.problemreporter().wrongsequenceofexceptiontypeserror(this, this.caughtexceptiontypes[i], i, argumenttypes[j]);
}
}
}
} else {
this.caughtexceptiontypes = new referencebinding[0];
}

if (finallyscope != null){
// add finallyscope as last subscope, so it can be shifted behind try/catch subscopes.
// the shifting is necessary to achieve no overlay in between the finally scope and its
// sibling in term of local variable positions.
this.scope.addsubscope(finallyscope);
}
}

public void traverse(astvisitor visitor, blockscope blockscope) {
if (visitor.visit(this, blockscope)) {
this.tryblock.traverse(visitor, this.scope);
if (this.catcharguments != null) {
for (int i = 0, max = this.catchblocks.length; i < max; i++) {
this.catcharguments[i].traverse(visitor, this.scope);
this.catchblocks[i].traverse(visitor, this.scope);
}
}
if (this.finallyblock != null)
this.finallyblock.traverse(visitor, this.scope);
}
visitor.endvisit(this, blockscope);
}
}
