/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/**
* thrown whenever cursor location is not inside a consistent token
* for example: inside a string, number, unicode, comments etc...
*/
public class invalidcursorlocation extends runtimeexception {

public string irritant;

/* possible irritants */
public static final string no_completion_inside_unicode = "no completion inside unicode"; //$non-nls-1$
public static final string no_completion_inside_comment = "no completion inside comment";      //$non-nls-1$
public static final string no_completion_inside_string = "no completion inside string";        //$non-nls-1$
public static final string no_completion_inside_number = "no completion inside number";        //$non-nls-1$

private static final long serialversionuid = -3443160725735779590l; // backward compatible

public invalidcursorlocation(string irritant){
this.irritant = irritant;
}
}
