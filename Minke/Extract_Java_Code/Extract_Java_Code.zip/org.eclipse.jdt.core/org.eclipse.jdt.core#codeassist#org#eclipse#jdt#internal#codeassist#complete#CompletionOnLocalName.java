/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.localdeclaration;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;


public class completiononlocalname extends localdeclaration {
private static final char[] fakenamesuffix = " ".tochararray(); //$non-nls-1$
public char[] realname;

public completiononlocalname(char[] name, int sourcestart, int sourceend){

super(charoperation.concat(name, fakenamesuffix), sourcestart, sourceend);
this.realname = name;
}

public void resolve(blockscope scope) {

super.resolve(scope);
throw new completionnodefound(this, scope);
}

public stringbuffer printasexpression(int indent, stringbuffer output) {
printindent(indent, output);
output.append("<completeonlocalname:"); //$non-nls-1$
if (this.type != null)  this.type.print(0, output).append(' ');
output.append(this.realname);
if (this.initialization != null) {
output.append(" = "); //$non-nls-1$
this.initialization.printexpression(0, output);
}
return output.append('>');
}

public stringbuffer printstatement(int indent, stringbuffer output) {
printasexpression(indent, output);
return output.append(';');
}
}

