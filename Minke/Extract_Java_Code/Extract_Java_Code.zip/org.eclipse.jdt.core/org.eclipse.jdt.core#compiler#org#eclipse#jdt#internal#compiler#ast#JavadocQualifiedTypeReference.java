/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.packagebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;


public class javadocqualifiedtypereference extends qualifiedtypereference {

public int tagsourcestart, tagsourceend;
public packagebinding packagebinding;

public javadocqualifiedtypereference(char[][] sources, long[] pos, int tagstart, int tagend) {
super(sources, pos);
this.tagsourcestart = tagstart;
this.tagsourceend = tagend;
this.bits |= astnode.insidejavadoc;
}

/*
* we need to modify resolving behavior to handle package references
*/
private typebinding internalresolvetype(scope scope, boolean checkbounds) {
// handle the error here
this.constant = constant.notaconstant;
if (this.resolvedtype != null) // is a shared type reference which was already resolved
return this.resolvedtype.isvalidbinding() ? this.resolvedtype : this.resolvedtype.closestmatch(); // already reported error

typebinding type = this.resolvedtype = gettypebinding(scope);
// end resolution when gettypebinding(scope) returns null. this may happen in
// certain circumstances, typically when an illegal access is done on a type
// variable (see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=204749)
if (type == null) return null;
if (!type.isvalidbinding()) {
binding binding = scope.gettypeorpackage(this.tokens);
if (binding instanceof packagebinding) {
this.packagebinding = (packagebinding) binding;
// valid package references are allowed in javadoc (https://bugs.eclipse.org/bugs/show_bug.cgi?id=281609)
} else {
reportinvalidtype(scope);
}
return null;
}
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=209936
// raw convert all enclosing types when dealing with javadoc references
if (type.isgenerictype() || type.isparameterizedtype()) {
this.resolvedtype = scope.environment().converttorawtype(type, true /*force the conversion of enclosing types*/);
}
return this.resolvedtype;
}
protected void reportdeprecatedtype(typebinding type, scope scope) {
scope.problemreporter().javadocdeprecatedtype(type, this, scope.getdeclarationmodifiers());
}

protected void reportdeprecatedtype(typebinding type, scope scope, int index) {
scope.problemreporter().javadocdeprecatedtype(type, this, scope.getdeclarationmodifiers(), index);
}

protected void reportinvalidtype(scope scope) {
scope.problemreporter().javadocinvalidtype(this, this.resolvedtype, scope.getdeclarationmodifiers());
}
public typebinding resolvetype(blockscope blockscope, boolean checkbounds) {
return internalresolvetype(blockscope, checkbounds);
}

public typebinding resolvetype(classscope classscope) {
return internalresolvetype(classscope, false);
}

/* (non-javadoc)
* redefine to capture javadoc specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.astvisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
