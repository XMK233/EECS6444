/*******************************************************************************
* copyright (c) 2000, 2006 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

public class updatedmethodbinding extends methodbinding {

public typebinding updateddeclaringclass;

public updatedmethodbinding(typebinding updateddeclaringclass, int modifiers, char[] selector, typebinding returntype, typebinding[] args, referencebinding[] exceptions, referencebinding declaringclass) {
super(modifiers, selector, returntype, args, exceptions, declaringclass);
this.updateddeclaringclass = updateddeclaringclass;
}

public typebinding constantpooldeclaringclass() {
return this.updateddeclaringclass;
}
}
