/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

/*
* encapsulates aspects related to type variable substitution
*/
public interface substitution {

/**
* returns the type substitute for a given type variable, or itself
* if no substitution got performed.
*/
typebinding substitute(typevariablebinding typevariable);

/**
* returns the lookup environment
*/
lookupenvironment environment();

/**
* returns true for raw substitution
*/
boolean israwsubstitution();
}
