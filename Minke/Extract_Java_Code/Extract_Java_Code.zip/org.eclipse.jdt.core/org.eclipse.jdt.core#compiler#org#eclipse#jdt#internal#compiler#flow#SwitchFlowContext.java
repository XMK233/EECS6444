/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.codegen.branchlabel;

/**
* reflects the context of code analysis, keeping track of enclosing
*	try statements, exception handlers, etc...
*/
public class switchflowcontext extends flowcontext {

public branchlabel breaklabel;
public unconditionalflowinfo initsonbreak = flowinfo.dead_end;

public switchflowcontext(flowcontext parent, astnode associatednode, branchlabel breaklabel) {
super(parent, associatednode);
this.breaklabel = breaklabel;
}

public branchlabel breaklabel() {
return this.breaklabel;
}

public string individualtostring() {
stringbuffer buffer = new stringbuffer("switch flow context"); //$non-nls-1$
buffer.append("[initsonbreak -").append(this.initsonbreak.tostring()).append(']'); //$non-nls-1$
return buffer.tostring();
}

public boolean isbreakable() {
return true;
}

public void recordbreakfrom(flowinfo flowinfo) {
if ((this.initsonbreak.tagbits & flowinfo.unreachable) == 0) {
this.initsonbreak = this.initsonbreak.mergedwith(flowinfo.unconditionalinits());
}
else {
this.initsonbreak = flowinfo.unconditionalcopy();
}
}
}
