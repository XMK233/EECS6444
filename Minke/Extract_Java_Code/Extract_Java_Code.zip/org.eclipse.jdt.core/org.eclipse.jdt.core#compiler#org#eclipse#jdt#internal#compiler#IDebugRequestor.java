/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

public interface idebugrequestor {

/*
* debug callback method allowing to take into account a new compilation result.
* any side-effect performed on the actual result might interfere with the
* original compiler requestor, and should be prohibited.
*/
void acceptdebugresult(compilationresult result);

/*
* answers true when in active mode
*/
boolean isactive();

/*
* activate debug callbacks
*/
void activate();

/*
* deactivate debug callbacks
*/
void deactivate();

/*
* reset debug requestor after compilation has finished
*/
void reset();
}

