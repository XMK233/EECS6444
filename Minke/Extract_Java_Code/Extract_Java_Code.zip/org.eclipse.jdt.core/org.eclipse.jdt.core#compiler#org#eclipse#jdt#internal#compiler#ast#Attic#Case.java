/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class case extends statement {

public expression constantexpression;
public caselabel targetlabel;
public case(int sourcestart, expression constantexpression) {
this.constantexpression = constantexpression;
this.sourceend = constantexpression.sourceend;
this.sourcestart = sourcestart;
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {

if (constantexpression.constant == notaconstant)
currentscope.problemreporter().caseexpressionmustbeconstant(constantexpression);

this.constantexpression.analysecode(currentscope, flowcontext, flowinfo);
return flowinfo;
}

/**
* case code generation
*
*/
public void generatecode(blockscope currentscope, codestream codestream) {

if ((bits & isreachablemask) == 0) {
return;
}
int pc = codestream.position;
targetlabel.place();
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* no-op : should use resolvecase(...) instead.
*/
public void resolve(blockscope scope) {
}

public constant resolvecase(
blockscope scope,
typebinding switchtype,
switchstatement switchstatement) {

// add into the collection of cases of the associated switch statement
switchstatement.cases[switchstatement.casecount++] = this;
typebinding casetype = constantexpression.resolvetype(scope);
if (casetype == null || switchtype == null)
return null;
if (constantexpression.isconstantvalueoftypeassignabletotype(casetype, switchtype))
return constantexpression.constant;
if (casetype.iscompatiblewith(switchtype))
return constantexpression.constant;
scope.problemreporter().typemismatcherroractualtypeexpectedtype(
constantexpression,
casetype,
switchtype);
return null;
}

public string tostring(int tab) {

string s = tabstring(tab);
s = s + "case " + constantexpression.tostringexpression() + " : "; //$non-nls-1$ //$non-nls-2$
return s;
}

public void traverse(
iabstractsyntaxtreevisitor visitor,
blockscope blockscope) {

if (visitor.visit(this, blockscope)) {
constantexpression.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}
}
