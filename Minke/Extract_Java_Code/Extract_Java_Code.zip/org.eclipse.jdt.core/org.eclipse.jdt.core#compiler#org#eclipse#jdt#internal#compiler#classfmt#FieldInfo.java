/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.codegen.attributenamesconstants;
import org.eclipse.jdt.internal.compiler.env.ibinaryannotation;
import org.eclipse.jdt.internal.compiler.env.ibinaryfield;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.util.util;

public class fieldinfo extends classfilestruct implements ibinaryfield, comparable {
protected int accessflags;
protected int attributebytes;
protected constant constant;
protected char[] descriptor;
protected char[] name;
protected char[] signature;
protected int signatureutf8offset;
protected long tagbits;
protected object wrappedconstantvalue;

public static fieldinfo createfield(byte classfilebytes[], int offsets[], int offset) {
fieldinfo fieldinfo = new fieldinfo(classfilebytes, offsets, offset);
annotationinfo[] annotations = fieldinfo.readattributes();
if (annotations == null)
return fieldinfo;
return new fieldinfowithannotation(fieldinfo, annotations);
}

/**
* @@param classfilebytes byte[]
* @@param offsets int[]
* @@param offset int
*/
protected fieldinfo (byte classfilebytes[], int offsets[], int offset) {
super(classfilebytes, offsets, offset);
this.accessflags = -1;
this.signatureutf8offset = -1;
}
private annotationinfo[] decodeannotations(int offset, boolean runtimevisible) {
int numberofannotations = u2at(offset + 6);
if (numberofannotations > 0) {
int readoffset = offset + 8;
annotationinfo[] newinfos = null;
int newinfocount = 0;
for (int i = 0; i < numberofannotations; i++) {
// with the last parameter being 'false', the data structure will not be flushed out
annotationinfo newinfo = new annotationinfo(this.reference, this.constantpooloffsets,
readoffset + this.structoffset, runtimevisible, false);
readoffset += newinfo.readoffset;
long standardtagbits = newinfo.standardannotationtagbits;
if (standardtagbits != 0) {
this.tagbits |= standardtagbits;
} else {
if (newinfos == null)
newinfos = new annotationinfo[numberofannotations - i];
newinfos[newinfocount++] = newinfo;
}
}
if (newinfos != null) {
if (newinfocount != newinfos.length)
system.arraycopy(newinfos, 0, newinfos = new annotationinfo[newinfocount], 0, newinfocount);
return newinfos;
}
}
return null; // nothing to record
}
public int compareto(object o) {
return new string(getname()).compareto(new string(((fieldinfo) o).getname()));
}
public boolean equals(object o) {
if (!(o instanceof fieldinfo)) {
return false;
}
return charoperation.equals(getname(), ((fieldinfo) o).getname());
}
public int hashcode() {
return charoperation.hashcode(getname());
}
/**
* return the constant of the field.
* return org.eclipse.jdt.internal.compiler.impl.constant.notaconstant if there is none.
* @@return org.eclipse.jdt.internal.compiler.impl.constant
*/
public constant getconstant() {
if (this.constant == null) {
// read constant
readconstantattribute();
}
return this.constant;
}
public char[] getgenericsignature() {
if (this.signatureutf8offset != -1) {
if (this.signature == null) {
// decode the signature
this.signature = utf8at(this.signatureutf8offset + 3, u2at(this.signatureutf8offset + 1));
}
return this.signature;
}
return null;
}
/**
* answer an int whose bits are set according the access constants
* defined by the vm spec.
* set the accdeprecated and accsynthetic bits if necessary
* @@return int
*/
public int getmodifiers() {
if (this.accessflags == -1) {
// compute the accessflag. don't forget the deprecated attribute
this.accessflags = u2at(0);
readmodifierrelatedattributes();
}
return this.accessflags;
}
/**
* answer the name of the field.
* @@return char[]
*/
public char[] getname() {
if (this.name == null) {
// read the name
int utf8offset = this.constantpooloffsets[u2at(2)] - this.structoffset;
this.name = utf8at(utf8offset + 3, u2at(utf8offset + 1));
}
return this.name;
}
public long gettagbits() {
return this.tagbits;
}
/**
* answer the resolved name of the receiver's type in the
* class file format as specified in section 4.3.2 of the java 2 vm spec.
*
* for example:
*   - java.lang.string is ljava/lang/string;
*   - an int is i
*   - a 2 dimensional array of strings is [[ljava/lang/string;
*   - an array of floats is [f
* @@return char[]
*/
public char[] gettypename() {
if (this.descriptor == null) {
// read the signature
int utf8offset = this.constantpooloffsets[u2at(4)] - this.structoffset;
this.descriptor = utf8at(utf8offset + 3, u2at(utf8offset + 1));
}
return this.descriptor;
}
/**
* @@return the annotations or null if there is none.
*/
public ibinaryannotation[] getannotations() {
return null;
}
/**
* return a wrapper that contains the constant of the field.
* @@return java.lang.object
*/
public object getwrappedconstantvalue() {

if (this.wrappedconstantvalue == null) {
if (hasconstant()) {
constant fieldconstant = getconstant();
switch (fieldconstant.typeid()) {
case typeids.t_int :
this.wrappedconstantvalue = new integer(fieldconstant.intvalue());
break;
case typeids.t_byte :
this.wrappedconstantvalue = new byte(fieldconstant.bytevalue());
break;
case typeids.t_short :
this.wrappedconstantvalue = new short(fieldconstant.shortvalue());
break;
case typeids.t_char :
this.wrappedconstantvalue = new character(fieldconstant.charvalue());
break;
case typeids.t_float :
this.wrappedconstantvalue = new float(fieldconstant.floatvalue());
break;
case typeids.t_double :
this.wrappedconstantvalue = new double(fieldconstant.doublevalue());
break;
case typeids.t_boolean :
this.wrappedconstantvalue = util.toboolean(fieldconstant.booleanvalue());
break;
case typeids.t_long :
this.wrappedconstantvalue = new long(fieldconstant.longvalue());
break;
case typeids.t_javalangstring :
this.wrappedconstantvalue = fieldconstant.stringvalue();
}
}
}
return this.wrappedconstantvalue;
}
/**
* return true if the field has a constant value attribute, false otherwise.
* @@return boolean
*/
public boolean hasconstant() {
return getconstant() != constant.notaconstant;
}
/**
* this method is used to fully initialize the contents of the receiver. all methodinfos, fields infos
* will be therefore fully initialized and we can get rid of the bytes.
*/
protected void initialize() {
getmodifiers();
getname();
getconstant();
gettypename();
getgenericsignature();
reset();
}
/**
* return true if the field is a synthetic field, false otherwise.
* @@return boolean
*/
public boolean issynthetic() {
return (getmodifiers() & classfileconstants.accsynthetic) != 0;
}
private annotationinfo[] readattributes() {
int attributescount = u2at(6);
int readoffset = 8;
annotationinfo[] annotations = null;
for (int i = 0; i < attributescount; i++) {
// check the name of each attribute
int utf8offset = this.constantpooloffsets[u2at(readoffset)] - this.structoffset;
char[] attributename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
if (attributename.length > 0) {
switch(attributename[0]) {
case 's' :
if (charoperation.equals(attributenamesconstants.signaturename, attributename))
this.signatureutf8offset = this.constantpooloffsets[u2at(readoffset + 6)] - this.structoffset;
break;
case 'r' :
annotationinfo[] decodedannotations = null;
if (charoperation.equals(attributename, attributenamesconstants.runtimevisibleannotationsname)) {
decodedannotations = decodeannotations(readoffset, true);
} else if (charoperation.equals(attributename, attributenamesconstants.runtimeinvisibleannotationsname)) {
decodedannotations = decodeannotations(readoffset, false);
}
if (decodedannotations != null) {
if (annotations == null) {
annotations = decodedannotations;
} else {
int length = annotations.length;
annotationinfo[] combined = new annotationinfo[length + decodedannotations.length];
system.arraycopy(annotations, 0, combined, 0, length);
system.arraycopy(decodedannotations, 0, combined, length, decodedannotations.length);
annotations = combined;
}
}
}
}
readoffset += (6 + u4at(readoffset + 2));
}
this.attributebytes = readoffset;
return annotations;
}
private void readconstantattribute() {
int attributescount = u2at(6);
int readoffset = 8;
boolean isconstant = false;
for (int i = 0; i < attributescount; i++) {
int utf8offset = this.constantpooloffsets[u2at(readoffset)] - this.structoffset;
char[] attributename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
if (charoperation
.equals(attributename, attributenamesconstants.constantvaluename)) {
isconstant = true;
// read the right constant
int relativeoffset = this.constantpooloffsets[u2at(readoffset + 6)] - this.structoffset;
switch (u1at(relativeoffset)) {
case classfileconstants.integertag :
char[] sign = gettypename();
if (sign.length == 1) {
switch (sign[0]) {
case 'z' : // boolean constant
this.constant = booleanconstant.fromvalue(i4at(relativeoffset + 1) == 1);
break;
case 'i' : // integer constant
this.constant = intconstant.fromvalue(i4at(relativeoffset + 1));
break;
case 'c' : // char constant
this.constant = charconstant.fromvalue((char) i4at(relativeoffset + 1));
break;
case 'b' : // byte constant
this.constant = byteconstant.fromvalue((byte) i4at(relativeoffset + 1));
break;
case 's' : // short constant
this.constant = shortconstant.fromvalue((short) i4at(relativeoffset + 1));
break;
default:
this.constant = constant.notaconstant;
}
} else {
this.constant = constant.notaconstant;
}
break;
case classfileconstants.floattag :
this.constant = floatconstant.fromvalue(floatat(relativeoffset + 1));
break;
case classfileconstants.doubletag :
this.constant = doubleconstant.fromvalue(doubleat(relativeoffset + 1));
break;
case classfileconstants.longtag :
this.constant = longconstant.fromvalue(i8at(relativeoffset + 1));
break;
case classfileconstants.stringtag :
utf8offset = this.constantpooloffsets[u2at(relativeoffset + 1)] - this.structoffset;
this.constant =
stringconstant.fromvalue(
string.valueof(utf8at(utf8offset + 3, u2at(utf8offset + 1))));
break;
}
}
readoffset += (6 + u4at(readoffset + 2));
}
if (!isconstant) {
this.constant = constant.notaconstant;
}
}
private void readmodifierrelatedattributes() {
int attributescount = u2at(6);
int readoffset = 8;
for (int i = 0; i < attributescount; i++) {
int utf8offset = this.constantpooloffsets[u2at(readoffset)] - this.structoffset;
char[] attributename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
// test added for obfuscated .class file. see 79772
if (attributename.length != 0) {
switch(attributename[0]) {
case 'd' :
if (charoperation.equals(attributename, attributenamesconstants.deprecatedname))
this.accessflags |= classfileconstants.accdeprecated;
break;
case 's' :
if (charoperation.equals(attributename, attributenamesconstants.syntheticname))
this.accessflags |= classfileconstants.accsynthetic;
break;
}
}
readoffset += (6 + u4at(readoffset + 2));
}
}
/**
* answer the size of the receiver in bytes.
*
* @@return int
*/
public int sizeinbytes() {
return this.attributebytes;
}
public void throwformatexception() throws classformatexception {
throw new classformatexception(classformatexception.errbadfieldinfo);
}
public string tostring() {
stringbuffer buffer = new stringbuffer(getclass().getname());
tostringcontent(buffer);
return buffer.tostring();
}
protected void tostringcontent(stringbuffer buffer) {
int modifiers = getmodifiers();
buffer
.append('{')
.append(
((modifiers & classfileconstants.accdeprecated) != 0 ? "deprecated " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0001) == 1 ? "public " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0002) == 0x0002 ? "private " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0004) == 0x0004 ? "protected " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0008) == 0x000008 ? "static " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0010) == 0x0010 ? "final " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0040) == 0x0040 ? "volatile " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0080) == 0x0080 ? "transient " : util.empty_string)) //$non-nls-1$
.append(gettypename())
.append(' ')
.append(getname())
.append(' ')
.append(getconstant())
.append('}')
.tostring();
}
}
