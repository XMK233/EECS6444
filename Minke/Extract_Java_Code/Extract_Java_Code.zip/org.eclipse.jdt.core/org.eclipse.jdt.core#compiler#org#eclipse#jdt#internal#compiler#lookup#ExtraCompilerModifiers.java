/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;

// todo (philippe) these should be moved to tagbits
public interface extracompilermodifiers { // modifier constant
// those constants are depending upon classfileconstants (relying that classfiles only use the 16 lower bits)
final int accjustflag = 0xffff;// 16 lower bits

// bit17 - free
// bit18 - use by classfileconstants.accannotationdefault
final int accrestrictedaccess = astnode.bit19;
final int accfromclassfile = astnode.bit20;
final int accdefaultabstract = astnode.bit20;
// bit21 - use by classfileconstants.accdeprecated
final int accdeprecatedimplicitly = astnode.bit22; // record whether deprecated itself or contained by a deprecated type
final int accalternatemodifierproblem = astnode.bit23;
final int accmodifierproblem = astnode.bit24;
final int accsemicolonbody = astnode.bit25;
final int accunresolved = astnode.bit26;
final int accblankfinal = astnode.bit27; // for blank final variables
final int accisdefaultconstructor = astnode.bit27; // for default constructor
final int acclocallyused = astnode.bit28; // used to diagnose unused private/local members
final int accvisibilitymask = classfileconstants.accpublic | classfileconstants.accprotected | classfileconstants.accprivate;

final int accoverriding = astnode.bit29; // record fact a method overrides another one
final int accimplementing = astnode.bit30; // record fact a method implements another one (it is concrete and overrides an abstract one)
final int accgenericsignature = astnode.bit31; // record fact a type/method/field involves generics in its signature (and need special signature attr)
}
