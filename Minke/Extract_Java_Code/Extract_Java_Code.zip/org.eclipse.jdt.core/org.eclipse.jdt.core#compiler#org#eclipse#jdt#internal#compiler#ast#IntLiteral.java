/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.scannerhelper;

public class intliteral extends numberliteral {

public int value;

public static final intliteral one = new intliteral(new char[]{'1'},0,0,1);//used for ++ and --

public intliteral(char[] token, int s, int e) {
super(token, s,e);
}

public intliteral(char[] token, int s,int e, int value) {
this(token, s,e);
this.value = value;
}

public intliteral(int intvalue) {
//special optimized constructor : the cst is the argument
//value that should not be used
//	tokens = null ;
//	sourcestart = 0;
//	sourceend = 0;
super(null,0,0);
this.constant = intconstant.fromvalue(intvalue);
this.value = intvalue;
}

public void computeconstant() {
//a special constant is use for the potential integer.max_value+1
//which is legal if used with a - as prefix....cool....
//notice that integer.min_value  == -2147483648
long max = integer.max_value;
if (this == one) {
this.constant = intconstant.fromvalue(1);
return ;
}
int length = this.source.length;
long computedvalue = 0l;
if (this.source[0] == '0') {
max = 0xffffffffl ; //a long in order to be positive !
if (length == 1) {
this.constant = intconstant.fromvalue(0); return ;
}
final int shift,radix;
int j ;
if ((this.source[1] == 'x') || (this.source[1] == 'x')) {
shift = 4 ; j = 2; radix = 16;
} else {
shift = 3 ; j = 1; radix = 8;
}
while (this.source[j]=='0')	 {
j++; //jump over redondant zero
if (j == length) {
//watch for 000000000000000000
this.constant = intconstant.fromvalue(this.value = (int)computedvalue);
return;
}
}
while (j<length) {
int digitvalue ;
if ((digitvalue = scannerhelper.digit(this.source[j++],radix))	< 0 ) {
return; /*constant stays null*/
}
computedvalue = (computedvalue<<shift) | digitvalue ;
if (computedvalue > max) return; /*constant stays null*/
}
} else {
//-----------regular case : radix = 10-----------
for (int i = 0 ; i < length;i++) {
int digitvalue ;
if ((digitvalue = scannerhelper.digit(this.source[i],10))	< 0 ) {
return; /*constant stays null*/
}
computedvalue = 10*computedvalue + digitvalue;
if (computedvalue > max) return /*constant stays null*/ ;
}
}
this.constant = intconstant.fromvalue(this.value = (int)computedvalue);

}

/**
* code generation for int literal
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
if (valuerequired) {
codestream.generateconstant(this.constant, this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public typebinding literaltype(blockscope scope) {
return typebinding.int;
}

public final boolean mayrepresentmin_value(){
//a special autorized int literral is 2147483648
//which is one over the limit. this special case
//only is used in combinaison with - to denote
//the minimal value of int -2147483648
return ((this.source.length == 10) &&
(this.source[0] == '2') &&
(this.source[1] == '1') &&
(this.source[2] == '4') &&
(this.source[3] == '7') &&
(this.source[4] == '4') &&
(this.source[5] == '8') &&
(this.source[6] == '3') &&
(this.source[7] == '6') &&
(this.source[8] == '4') &&
(this.source[9] == '8') &&
(((this.bits & astnode.parenthesizedmask) >> astnode.parenthesizedshift) == 0));
}

public stringbuffer printexpression(int indent, stringbuffer output){
if (this.source == null) {
/* special optimized intliteral that are created by the compiler */
return output.append(string.valueof(this.value));
}
return super.printexpression(indent, output);
}

public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
