/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.iproblem;

/**
* definition of a set of access rules used to flag forbidden references to non api code.
*/
public class accessruleset {

private accessrule[] accessrules;
public byte classpathentrytype; // one of accessrestriction#command_line, library, project
public string classpathentryname;

/**
* make a new set of access rules.
* @@param accessrules the access rules to be contained by the new set
* @@param classpathentrytype one of {@@link accessrestriction#command_line},
*        {@@link accessrestriction#library}, {@@link accessrestriction#project}
*        that tells the access restrictions how to render the classpath entry
* @@param classpathentryname a user-readable name for the classpath entry
*/
public accessruleset(accessrule[] accessrules, byte classpathentrytype, string classpathentryname) {
this.accessrules = accessrules;
this.classpathentrytype = classpathentrytype;
this.classpathentryname = classpathentryname;
}

/**
* @@see java.lang.object#equals(java.lang.object)
*/
public boolean equals(object object) {
if (this == object)
return true;
if (!(object instanceof accessruleset))
return false;
accessruleset otherruleset = (accessruleset) object;
if (this.classpathentrytype != otherruleset.classpathentrytype ||
this.classpathentryname == null && otherruleset.classpathentryname != null ||
! this.classpathentryname.equals(otherruleset.classpathentryname)) {
return false;
}
int ruleslength = this.accessrules.length;
if (ruleslength != otherruleset.accessrules.length) return false;
for (int i = 0; i < ruleslength; i++)
if (!this.accessrules[i].equals(otherruleset.accessrules[i]))
return false;
return true;
}

public accessrule[] getaccessrules() {
return this.accessrules;
}

/**
* select the first access rule which is violated when accessing a given type,
* or null if no 'non accessible' access rule applies.
* @@param targettypefilepath the target type file path, formed as:
* "org/eclipse/jdt/core/javacore"
* @@return the first access restriction that applies if any, null else
*/
public accessrestriction getviolatedrestriction(char[] targettypefilepath) {
for (int i = 0, length = this.accessrules.length; i < length; i++) {
accessrule accessrule = this.accessrules[i];
if (charoperation.pathmatch(accessrule.pattern, targettypefilepath,
true/*case sensitive*/, '/')) {
switch (accessrule.getproblemid()) {
case iproblem.forbiddenreference:
case iproblem.discouragedreference:
return new accessrestriction(accessrule, this.classpathentrytype, this.classpathentryname);
default:
return null;
}
}
}
return null;
}

public int hashcode() {
final int prime = 31;
int result = 1;
result = prime * result + hashcode(this.accessrules);
result = prime * result + ((this.classpathentryname == null) ? 0 : this.classpathentryname.hashcode());
result = prime * result + this.classpathentrytype;
return result;
}

private int hashcode(accessrule[] rules) {
final int prime = 31;
if (rules == null)
return 0;
int result = 1;
for (int i = 0, length = rules.length; i < length; i++) {
result = prime * result + (rules[i] == null ? 0 : rules[i].hashcode());
}
return result;
}

public string tostring() {
return tostring(true/*wrap lines*/);
}

public string tostring(boolean wrap) {
stringbuffer buffer = new stringbuffer(200);
buffer.append("accessruleset {"); //$non-nls-1$
if (wrap)
buffer.append('\n');
for (int i = 0, length = this.accessrules.length; i < length; i++) {
if (wrap)
buffer.append('\t');
accessrule accessrule = this.accessrules[i];
buffer.append(accessrule);
if (wrap)
buffer.append('\n');
else if (i < length-1)
buffer.append(", "); //$non-nls-1$
}
buffer.append("} [classpath entry: "); //$non-nls-1$
buffer.append(this.classpathentryname);
buffer.append("]"); //$non-nls-1$
return buffer.tostring();
}

}
