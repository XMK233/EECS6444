/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;

/**
* node to represent wildcard
*/
public class wildcard extends singletypereference {

public static final int unbound = 0;
public static final int extends = 1;
public static final int super = 2;

public typereference bound;
public int kind;

public wildcard(int kind) {
super(wildcard_name, 0);
this.kind = kind;
}

public char [][] getparameterizedtypename() {
switch (this.kind) {
case wildcard.unbound :
return new char[][] { wildcard_name };
case wildcard.extends :
return new char[][] { charoperation.concat(wildcard_name, wildcard_extends, charoperation.concatwith(this.bound.getparameterizedtypename(), '.')) };
default: // super
return new char[][] { charoperation.concat(wildcard_name, wildcard_super, charoperation.concatwith(this.bound.getparameterizedtypename(), '.')) };
}
}

public char [][] gettypename() {
switch (this.kind) {
case wildcard.unbound :
return new char[][] { wildcard_name };
case wildcard.extends :
return new char[][] { charoperation.concat(wildcard_name, wildcard_extends, charoperation.concatwith(this.bound.gettypename(), '.')) };
default: // super
return new char[][] { charoperation.concat(wildcard_name, wildcard_super, charoperation.concatwith(this.bound.gettypename(), '.')) };
}
}

private typebinding internalresolvetype(scope scope, referencebinding generictype, int rank) {
typebinding boundtype = null;
if (this.bound != null) {
boundtype = scope.kind == scope.class_scope
? this.bound.resolvetype((classscope)scope)
: this.bound.resolvetype((blockscope)scope, true /* check bounds*/);

if (boundtype == null) {
return null;
}
}
wildcardbinding wildcard = scope.environment().createwildcard(generictype, rank, boundtype, null /*no extra bound*/, this.kind);
return this.resolvedtype = wildcard;
}

public stringbuffer printexpression(int indent, stringbuffer output){
switch (this.kind) {
case wildcard.unbound :
output.append(wildcard_name);
break;
case wildcard.extends :
output.append(wildcard_name).append(wildcard_extends);
this.bound.printexpression(0, output);
break;
default: // super
output.append(wildcard_name).append(wildcard_super);
this.bound.printexpression(0, output);
break;
}
return output;
}

// only invoked for improving resilience when unable to bind generic type from parameterized reference
public typebinding resolvetype(blockscope scope, boolean checkbounds) {
if (this.bound != null) {
this.bound.resolvetype(scope, checkbounds);
}
return null;
}
// only invoked for improving resilience when unable to bind generic type from parameterized reference
public typebinding resolvetype(classscope scope) {
if (this.bound != null) {
this.bound.resolvetype(scope);
}
return null;
}
public typebinding resolvetypeargument(blockscope blockscope, referencebinding generictype, int rank) {
return internalresolvetype(blockscope, generictype, rank);
}

public typebinding resolvetypeargument(classscope classscope, referencebinding generictype, int rank) {
return internalresolvetype(classscope, generictype, rank);
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.bound != null) {
this.bound.traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {
if (visitor.visit(this, scope)) {
if (this.bound != null) {
this.bound.traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
