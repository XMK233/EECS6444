/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce an access to a member (field reference or message send)
* containing the completion identifier.
* e.g.
*
*	class x {
*    void foo() {
*      bar().fred[cursor]
*    }
*  }
*
*	---> class x {
*         void foo() {
*           <completeonmemberaccess:bar().fred>
*         }
*       }
*
* the source range of the completion node denotes the source range
* which should be replaced by the completion.
*/

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class completiononmemberaccess extends fieldreference {

public boolean isinsideannotation;

public completiononmemberaccess(char[] source, long pos, boolean isinsideannotation) {

super(source, pos);
this.isinsideannotation = isinsideannotation;
}

public stringbuffer printexpression(int indent, stringbuffer output) {

output.append("<completeonmemberaccess:"); //$non-nls-1$
return super.printexpression(0, output).append('>');
}

public typebinding resolvetype(blockscope scope) {

this.actualreceivertype = this.receiver.resolvetype(scope);

if ((this.actualreceivertype == null || !this.actualreceivertype.isvalidbinding()) && this.receiver instanceof messagesend) {
messagesend messagesend = (messagesend) this.receiver;
if(messagesend.receiver instanceof thisreference) {
expression[] arguments = messagesend.arguments;
int length = arguments == null ? 0 : arguments.length;
typebinding[] argbindings = new typebinding[length];
for (int i = 0; i < length; i++) {
argbindings[i] = arguments[i].resolvedtype;
if(argbindings[i] == null || !argbindings[i].isvalidbinding()) {
throw new completionnodefound();
}
}

problemmethodbinding problemmethodbinding = new problemmethodbinding(messagesend.selector, argbindings, problemreasons.notfound);
throw new completionnodefound(this, problemmethodbinding, scope);
}
}

if (this.actualreceivertype == null || this.actualreceivertype.isbasetype() || !this.actualreceivertype.isvalidbinding())
throw new completionnodefound();
else
throw new completionnodefound(this, this.actualreceivertype, scope);
// array types are passed along to find the length field
}
}
