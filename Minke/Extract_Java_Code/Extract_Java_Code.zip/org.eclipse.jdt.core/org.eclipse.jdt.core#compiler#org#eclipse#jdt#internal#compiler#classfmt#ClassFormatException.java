/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;
import java.io.printstream;
import java.io.printwriter;
public class classformatexception extends exception {

public static final int errbadmagic = 1;
public static final int errbadminorversion = 2;
public static final int errbadmajorversion = 3;
public static final int errbadconstantclass = 4;
public static final int errbadconstantstring = 5;
public static final int errbadconstantnameandtype = 6;
public static final int errbadconstantfieldref = 7;
public static final int errbadconstantmethodref = 8;
public static final int errbadconstantinterfacemethodref = 9;
public static final int errbadconstantpoolindex = 10;
public static final int errbadsuperclassname = 11;
public static final int errinterfacecannotbefinal = 12;
public static final int errinterfacemustbeabstract = 13;
public static final int errbadmodifiers = 14;
public static final int errclasscannotbeabstractfinal = 15;
public static final int errbadclassname = 16;
public static final int errbadfieldinfo = 17;
public static final int errbadmethodinfo = 17;
public static final int erremptyconstantpool = 18;
public static final int errmalformedutf8 = 19;
public static final int errunknownconstanttag = 20;
public static final int errtruncatedinput = 21;
public static final int errmethodmustbeabstract = 22;
public static final int errmalformedattribute = 23;
public static final int errbadinterface = 24;
public static final int errinterfacemustsubclassobject = 25;
public static final int errincorrectinterfacemethods = 26;
public static final int errinvalidmethodname = 27;
public static final int errinvalidmethodsignature = 28;

private static final long serialversionuid = 6667458511042774540l; // backward compatible

private int errorcode;
private int bufferposition;
private runtimeexception nestedexception;
private char[] filename;

public classformatexception(runtimeexception e, char[] filename) {
this.nestedexception = e;
this.filename = filename;
}
public classformatexception(int code) {
this.errorcode = code;
}
public classformatexception(int code, int bufpos) {
this.errorcode = code;
this.bufferposition = bufpos;
}
/**
* @@return int
*/
public int geterrorcode() {
return this.errorcode;
}
/**
* @@return int
*/
public int getbufferposition() {
return this.bufferposition;
}
/**
* returns the underlying <code>throwable</code> that caused the failure.
*
* @@return the wrappered <code>throwable</code>, or <code>null</code>
*         if the direct case of the failure was at the java model layer
*/
public throwable getexception() {
return this.nestedexception;
}
public void printstacktrace() {
printstacktrace(system.err);
}
/**
* prints this exception's stack trace to the given print stream.
*
* @@param output
*            the print stream
* @@since 3.0
*/
public void printstacktrace(printstream output) {
synchronized (output) {
super.printstacktrace(output);
throwable throwable = getexception();
if (throwable != null) {
if (this.filename != null) {
output.print("caused in "); //$non-nls-1$
output.print(this.filename);
output.print(" by: "); //$non-nls-1$
} else {
output.print("caused by: "); //$non-nls-1$
}
throwable.printstacktrace(output);
}
}
}
/**
* prints this exception's stack trace to the given print writer.
*
* @@param output
*            the print writer
* @@since 3.0
*/
public void printstacktrace(printwriter output) {
synchronized (output) {
super.printstacktrace(output);
throwable throwable = getexception();
if (throwable != null) {
if (this.filename != null) {
output.print("caused in "); //$non-nls-1$
output.print(this.filename);
output.print(" by: "); //$non-nls-1$
} else {
output.print("caused by: "); //$non-nls-1$
}
throwable.printstacktrace(output);
}
}
}
}
