/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

/**
* a compilation result consists of all information returned by the compiler for
* a single compiled compilation source unit.  this includes:
* <ul>
* <li> the compilation unit that was compiled
* <li> for each type produced by compiling the compilation unit, its binary and optionally its principal structure
* <li> any problems (errors or warnings) produced
* <li> dependency info
* </ul>
*
* the principle structure and binary may be null if the compiler could not produce them.
* if neither could be produced, there is no corresponding entry for the type.
*
* the dependency info includes type references such as supertypes, field types, method
* parameter and return types, local variable types, types of intermediate expressions, etc.
* it also includes the namespaces (packages) in which names were looked up.
* it does <em>not</em> include finer grained dependencies such as information about
* specific fields and methods which were referenced, but does contain their
* declaring types and any other types used to locate such fields or methods.
*/
import java.util.arrays;
import java.util.comparator;
import java.util.hashmap;
import java.util.hashset;
import java.util.hashtable;
import java.util.iterator;
import java.util.map;
import java.util.set;

import org.eclipse.jdt.core.compiler.categorizedproblem;
import org.eclipse.jdt.core.compiler.iproblem;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.env.icompilationunit;
import org.eclipse.jdt.internal.compiler.impl.referencecontext;
import org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding;
import org.eclipse.jdt.internal.compiler.parser.recoveryscannerdata;
import org.eclipse.jdt.internal.compiler.util.util;

public class compilationresult {

public categorizedproblem problems[];
public categorizedproblem tasks[];
public int problemcount;
public int taskcount;
public icompilationunit compilationunit;
public map problemsmap;
public set firsterrors;
private int maxproblemperunit;
public char[][][] qualifiedreferences;
public char[][] simplenamereferences;
public char[][] rootreferences;
public boolean hasannotations = false;
public int lineseparatorpositions[];
public recoveryscannerdata recoveryscannerdata;
public map compiledtypes = new hashtable(11);
public int unitindex, totalunitsknown;
public boolean hasbeenaccepted = false;
public char[] filename;
public boolean hasinconsistenttoplevelhierarchies = false; // record the fact some toplevel types have inconsistent hierarchies
public boolean hassyntaxerror = false;
public char[][] packagename;
public boolean checksecondarytypes = false; // check for secondary types which were created after the initial buildtypebindings call

private static final int[] empty_line_ends = util.empty_int_array;
private static final comparator problem_comparator = new comparator() {
public int compare(object o1, object o2) {
return ((categorizedproblem) o1).getsourcestart() - ((categorizedproblem) o2).getsourcestart();
}
};

public compilationresult(char[] filename, int unitindex, int totalunitsknown, int maxproblemperunit){
this.filename = filename;
this.unitindex = unitindex;
this.totalunitsknown = totalunitsknown;
this.maxproblemperunit = maxproblemperunit;
}

public compilationresult(icompilationunit compilationunit, int unitindex, int totalunitsknown, int maxproblemperunit){
this.filename = compilationunit.getfilename();
this.compilationunit = compilationunit;
this.unitindex = unitindex;
this.totalunitsknown = totalunitsknown;
this.maxproblemperunit = maxproblemperunit;
}

private int computepriority(categorizedproblem problem){
final int p_static = 10000;
final int p_outside_method = 40000;
final int p_first_error = 20000;
final int p_error = 100000;

int priority = 10000 - problem.getsourcelinenumber(); // early problems first
if (priority < 0) priority = 0;
if (problem.iserror()){
priority += p_error;
}
referencecontext context = this.problemsmap == null ? null : (referencecontext) this.problemsmap.get(problem);
if (context != null){
if (context instanceof abstractmethoddeclaration){
abstractmethoddeclaration method = (abstractmethoddeclaration) context;
if (method.isstatic()) {
priority += p_static;
}
} else {
priority += p_outside_method;
}
if (this.firsterrors.contains(problem)){ // if context is null, firsterrors is null too
priority += p_first_error;
}
} else {
priority += p_outside_method;
}
return priority;
}

public categorizedproblem[] getallproblems() {
categorizedproblem[] onlyproblems = getproblems();
int onlyproblemcount = onlyproblems != null ? onlyproblems.length : 0;
categorizedproblem[] onlytasks = gettasks();
int onlytaskcount = onlytasks != null ? onlytasks.length : 0;
if (onlytaskcount == 0) {
return onlyproblems;
}
if (onlyproblemcount == 0) {
return onlytasks;
}
int totalnumberofproblem = onlyproblemcount + onlytaskcount;
categorizedproblem[] allproblems = new categorizedproblem[totalnumberofproblem];
int allproblemindex = 0;
int taskindex = 0;
int problemindex = 0;
while (taskindex + problemindex < totalnumberofproblem) {
categorizedproblem nexttask = null;
categorizedproblem nextproblem = null;
if (taskindex < onlytaskcount) {
nexttask = onlytasks[taskindex];
}
if (problemindex < onlyproblemcount) {
nextproblem = onlyproblems[problemindex];
}
// select the next problem
categorizedproblem currentproblem = null;
if (nextproblem != null) {
if (nexttask != null) {
if (nextproblem.getsourcestart() < nexttask.getsourcestart()) {
currentproblem = nextproblem;
problemindex++;
} else {
currentproblem = nexttask;
taskindex++;
}
} else {
currentproblem = nextproblem;
problemindex++;
}
} else {
if (nexttask != null) {
currentproblem = nexttask;
taskindex++;
}
}
allproblems[allproblemindex++] = currentproblem;
}
return allproblems;
}

public classfile[] getclassfiles() {
classfile[] classfiles = new classfile[this.compiledtypes.size()];
this.compiledtypes.values().toarray(classfiles);
return classfiles;
}

/**
* answer the initial compilation unit corresponding to the present compilation result
*/
public icompilationunit getcompilationunit(){
return this.compilationunit;
}

/**
* answer the errors encountered during compilation.
*/
public categorizedproblem[] geterrors() {
categorizedproblem[] reportedproblems = getproblems();
int errorcount = 0;
for (int i = 0; i < this.problemcount; i++) {
if (reportedproblems[i].iserror()) errorcount++;
}
if (errorcount == this.problemcount) return reportedproblems;
categorizedproblem[] errors = new categorizedproblem[errorcount];
int index = 0;
for (int i = 0; i < this.problemcount; i++) {
if (reportedproblems[i].iserror()) errors[index++] = reportedproblems[i];
}
return errors;
}


/**
* answer the initial file name
*/
public char[] getfilename(){
return this.filename;
}

public int[] getlineseparatorpositions() {
return this.lineseparatorpositions == null ? compilationresult.empty_line_ends : this.lineseparatorpositions;
}

/**
* answer the problems (errors and warnings) encountered during compilation.
*
* this is not a compiler internal api - it has side-effects !
* it is intended to be used only once all problems have been detected,
* and makes sure the problems slot as the exact size of the number of
* problems.
*/
public categorizedproblem[] getproblems() {
// re-adjust the size of the problems if necessary.
if (this.problems != null) {
if (this.problemcount != this.problems.length) {
system.arraycopy(this.problems, 0, (this.problems = new categorizedproblem[this.problemcount]), 0, this.problemcount);
}

if (this.maxproblemperunit > 0 && this.problemcount > this.maxproblemperunit){
quickprioritize(this.problems, 0, this.problemcount - 1);
this.problemcount = this.maxproblemperunit;
system.arraycopy(this.problems, 0, (this.problems = new categorizedproblem[this.problemcount]), 0, this.problemcount);
}

// stable sort problems per source positions.
arrays.sort(this.problems, 0, this.problems.length, compilationresult.problem_comparator);
//quicksort(problems, 0, problems.length-1);
}
return this.problems;
}

/**
* answer the tasks (to-do, ...) encountered during compilation.
*
* this is not a compiler internal api - it has side-effects !
* it is intended to be used only once all problems have been detected,
* and makes sure the problems slot as the exact size of the number of
* problems.
*/
public categorizedproblem[] gettasks() {
// re-adjust the size of the tasks if necessary.
if (this.tasks != null) {

if (this.taskcount != this.tasks.length) {
system.arraycopy(this.tasks, 0, (this.tasks = new categorizedproblem[this.taskcount]), 0, this.taskcount);
}
// stable sort problems per source positions.
arrays.sort(this.tasks, 0, this.tasks.length, compilationresult.problem_comparator);
//quicksort(tasks, 0, tasks.length-1);
}
return this.tasks;
}

public boolean haserrors() {
if (this.problems != null)
for (int i = 0; i < this.problemcount; i++) {
if (this.problems[i].iserror())
return true;
}
return false;
}

public boolean hasproblems() {
return this.problemcount != 0;
}

public boolean hastasks() {
return this.taskcount != 0;
}

public boolean haswarnings() {
if (this.problems != null)
for (int i = 0; i < this.problemcount; i++) {
if (this.problems[i].iswarning())
return true;
}
return false;
}

private void quickprioritize(categorizedproblem[] problemlist, int left, int right) {
if (left >= right) return;
// sort the problems by their priority... starting with the highest priority
int original_left = left;
int original_right = right;
int mid = computepriority(problemlist[left + (right - left) / 2]);
do {
while (computepriority(problemlist[right]) < mid)
right--;
while (mid < computepriority(problemlist[left]))
left++;
if (left <= right) {
categorizedproblem tmp = problemlist[left];
problemlist[left] = problemlist[right];
problemlist[right] = tmp;
left++;
right--;
}
} while (left <= right);
if (original_left < right)
quickprioritize(problemlist, original_left, right);
if (left < original_right)
quickprioritize(problemlist, left, original_right);
}

/*
* record the compilation unit result's package name
*/
public void recordpackagename(char[][] packname) {
this.packagename = packname;
}

public void record(categorizedproblem newproblem, referencecontext referencecontext) {
//new exception("verbose problem reporting").printstacktrace();
if(newproblem.getid() == iproblem.task) {
recordtask(newproblem);
return;
}
if (this.problemcount == 0) {
this.problems = new categorizedproblem[5];
} else if (this.problemcount == this.problems.length) {
system.arraycopy(this.problems, 0, (this.problems = new categorizedproblem[this.problemcount * 2]), 0, this.problemcount);
}
this.problems[this.problemcount++] = newproblem;
if (referencecontext != null){
if (this.problemsmap == null) this.problemsmap = new hashmap(5);
if (this.firsterrors == null) this.firsterrors = new hashset(5);
if (newproblem.iserror() && !referencecontext.haserrors()) this.firsterrors.add(newproblem);
this.problemsmap.put(newproblem, referencecontext);
}
if ((newproblem.getid() & iproblem.syntax) != 0 && newproblem.iserror())
this.hassyntaxerror = true;
}

/**
* for now, remember the compiled type using its compound name.
*/
public void record(char[] typename, classfile classfile) {
sourcetypebinding sourcetype = classfile.referencebinding;
if (!sourcetype.islocaltype() && sourcetype.ishierarchyinconsistent()) {
this.hasinconsistenttoplevelhierarchies = true;
}
this.compiledtypes.put(typename, classfile);
}

private void recordtask(categorizedproblem newproblem) {
if (this.taskcount == 0) {
this.tasks = new categorizedproblem[5];
} else if (this.taskcount == this.tasks.length) {
system.arraycopy(this.tasks, 0, (this.tasks = new categorizedproblem[this.taskcount * 2]), 0, this.taskcount);
}
this.tasks[this.taskcount++] = newproblem;
}

public compilationresult tagasaccepted(){
this.hasbeenaccepted = true;
this.problemsmap = null; // flush
this.firsterrors = null; // flush
return this;
}

public string tostring(){
stringbuffer buffer = new stringbuffer();
if (this.filename != null){
buffer.append("filename : ").append(this.filename).append('\n'); //$non-nls-1$
}
if (this.compiledtypes != null){
buffer.append("compiled type(s)	\n");  //$non-nls-1$
iterator keys = this.compiledtypes.keyset().iterator();
while (keys.hasnext()) {
char[] typename = (char[]) keys.next();
buffer.append("\t - ").append(typename).append('\n');   //$non-nls-1$

}
} else {
buffer.append("no compiled type\n");  //$non-nls-1$
}
if (this.problems != null){
buffer.append(this.problemcount).append(" problem(s) detected \n"); //$non-nls-1$
for (int i = 0; i < this.problemcount; i++){
buffer.append("\t - ").append(this.problems[i]).append('\n'); //$non-nls-1$
}
} else {
buffer.append("no problem\n"); //$non-nls-1$
}
return buffer.tostring();
}
}
