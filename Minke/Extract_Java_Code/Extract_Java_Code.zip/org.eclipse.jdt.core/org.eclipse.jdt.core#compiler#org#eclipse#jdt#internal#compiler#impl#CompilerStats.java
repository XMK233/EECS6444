/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.impl;

public class compilerstats implements comparable {

// overall
public long starttime;
public long endtime;
public long linecount;

// compile phases
public long parsetime;
public long resolvetime;
public long analyzetime;
public long generatetime;

/**
* returns the total elapsed time (between start and end)
* @@return the time spent between start and end
*/
public long elapsedtime() {
return this.endtime - this.starttime;
}

/**
* @@see java.lang.comparable#compareto(java.lang.object)
*/
public int compareto(object o) {
compilerstats otherstats = (compilerstats) o;
long time1 = elapsedtime();
long time2 = otherstats.elapsedtime();
return time1 < time2 ? -1 : (time1 == time2 ? 0 : 1);
}
}
