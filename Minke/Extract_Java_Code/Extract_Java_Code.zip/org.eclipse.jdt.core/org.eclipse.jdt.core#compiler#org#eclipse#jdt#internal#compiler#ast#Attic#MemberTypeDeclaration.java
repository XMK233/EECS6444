/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.problem.aborttype;

public class membertypedeclaration extends innertypedeclaration {
public typedeclaration enclosingtype;

public membertypedeclaration(compilationresult compilationresult){
super(compilationresult);
}
/**
*	iteration for a member innertype
*
*/
public void traverse(iabstractsyntaxtreevisitor visitor, classscope classscope) {
if (ignorefurtherinvestigation)
return;
try {
if (visitor.visit(this, classscope)) {
if (superclass != null)
superclass.traverse(visitor, scope);
if (superinterfaces != null) {
int superinterfacelength = superinterfaces.length;
for (int i = 0; i < superinterfacelength; i++)
superinterfaces[i].traverse(visitor, scope);
}
if (membertypes != null) {
int membertypeslength = membertypes.length;
for (int i = 0; i < membertypeslength; i++)
membertypes[i].traverse(visitor, scope);
}
if (fields != null) {
int fieldslength = fields.length;
for (int i = 0; i < fieldslength; i++) {
fielddeclaration field;
if ((field = fields[i]).isstatic()) {
field.traverse(visitor, staticinitializerscope);
} else {
field.traverse(visitor, initializerscope);
}
}
}
if (methods != null) {
int methodslength = methods.length;
for (int i = 0; i < methodslength; i++)
methods[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, classscope);
} catch (aborttype e) {
// silent abort
}
}
}
