/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

// clinit methods (synthetics too?) can be returned from ibinarytype>>getmethods()
// but do not have to be... the compiler will ignore them when building the binding.
// the synthetic argument of a member type's constructor (i.e. the first arg of a non-static
// member type) is also ignored by the compiler, but in this case it must be included
// in the constructor's signature.

public interface ibinarymethod extends igenericmethod {

/**
* answer the runtime visible and invisible annotations for this method or null if none.
*/
ibinaryannotation[] getannotations();

/**
* return {@@link classsignature} for a class {@@link java.lang.class}.
* return {@@link org.eclipse.jdt.internal.compiler.impl.constant} for compile-time constant of primitive type, as well as string literals.
* return {@@link enumconstantsignature} if value is an enum constant.
* return {@@link ibinaryannotation} for annotation type.
* return {@@link object}[] for array type.
*
* @@return default value of this annotation method
*/
object getdefaultvalue();

/**
* answer the resolved names of the exception types in the
* class file format as specified in section 4.2 of the java 2 vm spec
* or null if the array is empty.
*
* for example, java.lang.string is java/lang/string.
*/
char[][] getexceptiontypenames();

/**
* answer the receiver's signature which describes the parameter &
* return types as specified in section 4.4.4 of the java 2 vm spec.
*/
char[] getgenericsignature();

/**
* answer the receiver's method descriptor which describes the parameter &
* return types as specified in section 4.4.3 of the java 2 vm spec.
*
* for example:
*   - int foo(string) is (ljava/lang/string;)i
*   - object[] foo(int) is (i)[ljava/lang/object;
*/
char[] getmethoddescriptor();

/**
* answer the annotations on the <code>index</code>th parameter or null if none
* @@param index the index of the parameter of interest
*/
ibinaryannotation[] getparameterannotations(int index);

/**
* answer the name of the method.
*
* for a constructor, answer <init> & <clinit> for a clinit method.
*/
char[] getselector();

/**
* answer the tagbits set according to the bits for annotations.
*/
long gettagbits();

/**
* answer whether the receiver represents a class initializer method.
*/
boolean isclinit();
}
