/*******************************************************************************
* copyright (c) 2006, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     bea - patch for bug 172743
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

import java.io.printwriter;

import org.eclipse.jdt.internal.compiler.ast.compilationunitdeclaration;
import org.eclipse.jdt.internal.compiler.env.icompilationunit;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;

public abstract class abstractannotationprocessormanager {
/**
* configure the receiver using the given batch compiler and the given options.
* the parameter batchcompiler is expected to be an instance of the batch compiler. this method is
* only used for the batch mode. for the ide mode, please see {@@link #configurefromplatform(compiler, object, object)}.
*
* @@param batchcompiler the given batch compiler object
* @@param options the given options
*/
public abstract void configure(object batchcompiler, string[] options);

/**
* configure the receiver using the given compiler, the given compilationunitlocator and
* the given java project.
*
* @@param compiler the given compiler
* @@param compilationunitlocator the given compilation unit locator
* @@param javaproject the given java project
*/
public abstract void configurefromplatform(compiler compiler, object compilationunitlocator, object javaproject);

/**
* set the print writer for the standard output.
*
* @@param out the given print writer for output
*/
public abstract void setout(printwriter out);

/**
* set the print writer for the standard error.
*
* @@param err the given print writer for error
*/
public abstract void seterr(printwriter err);

/**
* return the new units created in the last round.
*
* @@return the new units created in the last round
*/
public abstract icompilationunit[] getnewunits();

/**
* return the new binary bindings created in the last round.
*
* @@return the new binary bindings created in the last round
*/
public abstract referencebinding[] getnewclassfiles();

/**
* returns the deleted units.
* @@return the deleted units
*/
public abstract icompilationunit[] getdeletedunits();

/**
* reinitialize the receiver
*/
public abstract void reset();

/**
* run a new annotation processing round on the given values.
*
* @@param units the given source type
* @@param referencebindings the given binary types
* @@param islastround flag to notify the last round
*/
public abstract void processannotations(compilationunitdeclaration[] units, referencebinding[] referencebindings, boolean islastround);

/**
* set the processors for annotation processing.
*
* @@param processors the given processors
*/
public abstract void setprocessors(object[] processors);
}
