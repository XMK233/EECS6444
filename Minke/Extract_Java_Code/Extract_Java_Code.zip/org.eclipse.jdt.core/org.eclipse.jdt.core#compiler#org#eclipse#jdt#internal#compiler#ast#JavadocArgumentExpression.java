/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class javadocargumentexpression extends expression {
public char[] token;
public argument argument;

public javadocargumentexpression(char[] name, int startpos, int endpos, typereference typeref) {
this.token = name;
this.sourcestart = startpos;
this.sourceend = endpos;
long pos = (((long) startpos) << 32) + endpos;
this.argument = new argument(name, pos, typeref, classfileconstants.accdefault);
this.bits |= insidejavadoc;
}

/*
* resolves type on a block or class scope.
*/
private typebinding internalresolvetype(scope scope) {
this.constant = constant.notaconstant;
if (this.resolvedtype != null) // is a shared type reference which was already resolved
return this.resolvedtype.isvalidbinding() ? this.resolvedtype : null; // already reported error

if (this.argument != null) {
typereference typeref = this.argument.type;
if (typeref != null) {
this.resolvedtype = typeref.gettypebinding(scope);
typeref.resolvedtype = this.resolvedtype;
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=195374
// reproduce javadoc 1.3.1 / 1.4.2 behavior
if (typeref instanceof singletypereference &&
this.resolvedtype.leafcomponenttype().enclosingtype() != null &&
scope.compileroptions().compliancelevel <= classfileconstants.jdk1_4) {
scope.problemreporter().javadocinvalidmembertypequalification(this.sourcestart, this.sourceend, scope.getdeclarationmodifiers());
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=228648
// do not return now but report unresolved reference as expected depending on compliance settings
} else if (typeref instanceof qualifiedtypereference) {
typebinding enclosingtype = this.resolvedtype.leafcomponenttype().enclosingtype();
if (enclosingtype != null) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=233187
// inner type references should be fully qualified
int compoundlength = 2;
while ((enclosingtype = enclosingtype.enclosingtype()) != null) compoundlength++;
int typenamelength = typeref.gettypename().length;
if (typenamelength != compoundlength && typenamelength != (compoundlength+this.resolvedtype.getpackage().compoundname.length)) {
scope.problemreporter().javadocinvalidmembertypequalification(typeref.sourcestart, typeref.sourceend, scope.getdeclarationmodifiers());
}
}
}
if (!this.resolvedtype.isvalidbinding()) {
scope.problemreporter().javadocinvalidtype(typeref, this.resolvedtype, scope.getdeclarationmodifiers());
return null;
}
if (istypeusedeprecated(this.resolvedtype, scope)) {
scope.problemreporter().javadocdeprecatedtype(this.resolvedtype, typeref, scope.getdeclarationmodifiers());
}
return this.resolvedtype = scope.environment().converttorawtype(this.resolvedtype,  true /*force the conversion of enclosing types*/);
}
}
return null;
}

public stringbuffer printexpression(int indent, stringbuffer output) {
if (this.argument == null) {
if (this.token != null) {
output.append(this.token);
}
}
else {
this.argument.print(indent, output);
}
return output;
}

public void resolve(blockscope scope) {
if (this.argument != null) {
this.argument.resolve(scope);
}
}

public typebinding resolvetype(blockscope scope) {
return internalresolvetype(scope);
}

public typebinding resolvetype(classscope scope) {
return internalresolvetype(scope);
}

/* (non-javadoc)
* redefine to capture javadoc specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.astvisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(astvisitor visitor, blockscope blockscope) {
if (visitor.visit(this, blockscope)) {
if (this.argument != null) {
this.argument.traverse(visitor, blockscope);
}
}
visitor.endvisit(this, blockscope);
}
public void traverse(astvisitor visitor, classscope blockscope) {
if (visitor.visit(this, blockscope)) {
if (this.argument != null) {
this.argument.traverse(visitor, blockscope);
}
}
visitor.endvisit(this, blockscope);
}
}
