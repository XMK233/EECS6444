/*******************************************************************************
* copyright (c) 2000, 2006 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

public interface ibinarynestedtype {
/**
* answer the resolved name of the enclosing type in the
* class file format as specified in section 4.2 of the java 2 vm spec.
*
* for example, java.lang.string is java/lang/string.
*/

char[] getenclosingtypename();
/**
* answer an int whose bits are set according the access constants
* defined by the vm spec.
*/

// we have added accdeprecated & accsynthetic.

int getmodifiers();
/**
* answer the resolved name of the member type in the
* class file format as specified in section 4.2 of the java 2 vm spec.
*
* for example, p1.p2.a.m is p1/p2/a$m.
*/

char[] getname();
}
