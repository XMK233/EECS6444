/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.impl;

public interface keywords {
int count = 41;

char[] abstract = "abstract".tochararray(); //$non-nls-1$
char[] assert = "assert".tochararray(); //$non-nls-1$
char[] break = "break".tochararray(); //$non-nls-1$
char[] case = "case".tochararray(); //$non-nls-1$
char[] catch = "catch".tochararray(); //$non-nls-1$
char[] class = "class".tochararray(); //$non-nls-1$
char[] continue = "continue".tochararray(); //$non-nls-1$
char[] default = "default".tochararray(); //$non-nls-1$
char[] do = "do".tochararray(); //$non-nls-1$
char[] else = "else".tochararray(); //$non-nls-1$
char[] enum = "enum".tochararray(); //$non-nls-1$
char[] extends = "extends".tochararray(); //$non-nls-1$
char[] final = "final".tochararray(); //$non-nls-1$
char[] finally = "finally".tochararray(); //$non-nls-1$
char[] for = "for".tochararray(); //$non-nls-1$
char[] if = "if".tochararray(); //$non-nls-1$
char[] implements = "implements".tochararray(); //$non-nls-1$
char[] import = "import".tochararray(); //$non-nls-1$
char[] instanceof = "instanceof".tochararray(); //$non-nls-1$
char[] interface = "interface".tochararray(); //$non-nls-1$
char[] native = "native".tochararray(); //$non-nls-1$
char[] new = "new".tochararray(); //$non-nls-1$
char[] package = "package".tochararray(); //$non-nls-1$
char[] private = "private".tochararray(); //$non-nls-1$
char[] protected = "protected".tochararray(); //$non-nls-1$
char[] public = "public".tochararray(); //$non-nls-1$
char[] return = "return".tochararray(); //$non-nls-1$
char[] static = "static".tochararray(); //$non-nls-1$
char[] strictfp = "strictfp".tochararray(); //$non-nls-1$
char[] super = "super".tochararray(); //$non-nls-1$
char[] switch = "switch".tochararray(); //$non-nls-1$
char[] synchronized = "synchronized".tochararray(); //$non-nls-1$
char[] this = "this".tochararray(); //$non-nls-1$
char[] throw = "throw".tochararray(); //$non-nls-1$
char[] throws = "throws".tochararray(); //$non-nls-1$
char[] transient = "transient".tochararray(); //$non-nls-1$
char[] try = "try".tochararray(); //$non-nls-1$
char[] volatile = "volatile".tochararray(); //$non-nls-1$
char[] while = "while".tochararray(); //$non-nls-1$
char[] true = "true".tochararray(); //$non-nls-1$
char[] false = "false".tochararray(); //$non-nls-1$
char[] null = "null".tochararray(); //$non-nls-1$
}
