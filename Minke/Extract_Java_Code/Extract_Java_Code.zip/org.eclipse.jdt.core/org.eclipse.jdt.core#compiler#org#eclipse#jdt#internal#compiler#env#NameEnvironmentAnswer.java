/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

public class nameenvironmentanswer {

// only one of the three can be set
ibinarytype binarytype;
icompilationunit compilationunit;
isourcetype[] sourcetypes;
accessrestriction accessrestriction;

public nameenvironmentanswer(ibinarytype binarytype, accessrestriction accessrestriction) {
this.binarytype = binarytype;
this.accessrestriction = accessrestriction;
}

public nameenvironmentanswer(icompilationunit compilationunit, accessrestriction accessrestriction) {
this.compilationunit = compilationunit;
this.accessrestriction = accessrestriction;
}

public nameenvironmentanswer(isourcetype[] sourcetypes, accessrestriction accessrestriction) {
this.sourcetypes = sourcetypes;
this.accessrestriction = accessrestriction;
}
/**
* returns the associated access restriction, or null if none.
*/
public accessrestriction getaccessrestriction() {
return this.accessrestriction;
}
/**
* answer the resolved binary form for the type or null if the
* receiver represents a compilation unit or source type.
*/
public ibinarytype getbinarytype() {
return this.binarytype;
}

/**
* answer the compilation unit or null if the
* receiver represents a binary or source type.
*/
public icompilationunit getcompilationunit() {
return this.compilationunit;
}

/**
* answer the unresolved source forms for the type or null if the
* receiver represents a compilation unit or binary type.
*
* multiple source forms can be answered in case the originating compilation unit did contain
* several type at once. then the first type is guaranteed to be the requested type.
*/
public isourcetype[] getsourcetypes() {
return this.sourcetypes;
}

/**
* answer whether the receiver contains the resolved binary form of the type.
*/
public boolean isbinarytype() {
return this.binarytype != null;
}

/**
* answer whether the receiver contains the compilation unit which defines the type.
*/
public boolean iscompilationunit() {
return this.compilationunit != null;
}

/**
* answer whether the receiver contains the unresolved source form of the type.
*/
public boolean issourcetype() {
return this.sourcetypes != null;
}

public boolean ignoreifbetter() {
return this.accessrestriction != null && this.accessrestriction.ignoreifbetter();
}

/*
* returns whether this answer is better than the other awswer.
* (accessible is better than discouraged, which is better than
* non-accessible)
*/
public boolean isbetter(nameenvironmentanswer otheranswer) {
if (otheranswer == null) return true;
if (this.accessrestriction == null) return true;
return otheranswer.accessrestriction != null
&& this.accessrestriction.getproblemid() < otheranswer.accessrestriction.getproblemid();
}
}
