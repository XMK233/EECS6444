/*******************************************************************************
* copyright (c) 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.impl;

import java.util.map;

import org.eclipse.core.runtime.iprogressmonitor;
import org.eclipse.jdt.core.javamodelexception;
import org.eclipse.jdt.internal.core.annotation;
import org.eclipse.jdt.internal.core.javaelement;

public class assistannotation extends annotation {
private map infocache;
public assistannotation(javaelement parent, string name, map infocache) {
super(parent, name);
this.infocache = infocache;
}

public object getelementinfo(iprogressmonitor monitor) throws javamodelexception {
return this.infocache.get(this);
}
}
