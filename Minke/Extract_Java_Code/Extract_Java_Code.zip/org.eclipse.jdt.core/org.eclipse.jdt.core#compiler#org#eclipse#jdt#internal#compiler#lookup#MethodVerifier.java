/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     benjamin muskalla - contribution for bug 239066
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;
import org.eclipse.jdt.internal.compiler.util.hashtableofobject;
import org.eclipse.jdt.internal.compiler.util.simpleset;

public class methodverifier {
sourcetypebinding type;
hashtableofobject inheritedmethods;
hashtableofobject currentmethods;
lookupenvironment environment;
private boolean allowcompatiblereturntypes;
/*
binding creation is responsible for reporting all problems with types:
- all modifier problems (duplicates & multiple visibility modifiers + incompatible combinations - abstract/final)
- plus invalid modifiers given the context (the verifier did not do this before)
- qualified name collisions between a type and a package (types in default packages are excluded)
- all type hierarchy problems:
- cycles in the superclass or superinterface hierarchy
- an ambiguous, invisible or missing superclass or superinterface
- extending a final class
- extending an interface instead of a class
- implementing a class instead of an interface
- implementing the same interface more than once (i.e. duplicate interfaces)
- with nested types:
- shadowing an enclosing type's source name
- defining a static class or interface inside a non-static nested class
- defining an interface as a local type (local types can only be classes)
*/
methodverifier(lookupenvironment environment) {
this.type = null;  // initialized with the public method verify(sourcetypebinding)
this.inheritedmethods = null;
this.currentmethods = null;
this.environment = environment;
this.allowcompatiblereturntypes =
environment.globaloptions.compliancelevel >= classfileconstants.jdk1_5
&& environment.globaloptions.sourcelevel < classfileconstants.jdk1_5;
}
boolean aremethodscompatible(methodbinding one, methodbinding two) {
return isparametersubsignature(one, two) && arereturntypescompatible(one, two);
}
boolean areparametersequal(methodbinding one, methodbinding two) {
typebinding[] oneargs = one.parameters;
typebinding[] twoargs = two.parameters;
if (oneargs == twoargs) return true;

int length = oneargs.length;
if (length != twoargs.length) return false;

for (int i = 0; i < length; i++)
if (!aretypesequal(oneargs[i], twoargs[i])) return false;
return true;
}
boolean arereturntypescompatible(methodbinding one, methodbinding two) {
if (one.returntype == two.returntype) return true;

if (aretypesequal(one.returntype, two.returntype)) return true;

// when sourcelevel < 1.5 but compliance >= 1.5, allow return types in binaries to be compatible instead of just equal
if (this.allowcompatiblereturntypes &&
one.declaringclass instanceof binarytypebinding &&
two.declaringclass instanceof binarytypebinding) {
return arereturntypescompatible0(one, two);
}
return false;
}
boolean arereturntypescompatible0(methodbinding one, methodbinding two) {
// short is compatible with int, but as far as covariance is concerned, its not
if (one.returntype.isbasetype()) return false;

if (!one.declaringclass.isinterface() && one.declaringclass.id == typeids.t_javalangobject)
return two.returntype.iscompatiblewith(one.returntype); // interface methods inherit from object

return one.returntype.iscompatiblewith(two.returntype);
}
boolean aretypesequal(typebinding one, typebinding two) {
if (one == two) return true;

// its possible that an unresolvedreferencebinding can be compared to its resolved type
// when they're both unresolvedreferencebindings then they must be identical like all other types
// all wrappers of unresolvedreferencebindings are converted as soon as the type is resolved
// so its not possible to have 2 arrays where one is unresolvedx[] and the other is x[]
if (one instanceof unresolvedreferencebinding)
return ((unresolvedreferencebinding) one).resolvedtype == two;
if (two instanceof unresolvedreferencebinding)
return ((unresolvedreferencebinding) two).resolvedtype == one;
return false; // all other type bindings are identical
}
boolean canskipinheritedmethods() {
if (this.type.superclass() != null && this.type.superclass().isabstract())
return false;
return this.type.superinterfaces() == binding.no_superinterfaces;
}
boolean canskipinheritedmethods(methodbinding one, methodbinding two) {
return two == null // already know one is not null
|| one.declaringclass == two.declaringclass;
}
void checkabstractmethod(methodbinding abstractmethod) {
if (mustimplementabstractmethod(abstractmethod.declaringclass)) {
typedeclaration typedeclaration = this.type.scope.referencecontext;
if (typedeclaration != null) {
methoddeclaration missingabstractmethod = typedeclaration.addmissingabstractmethodfor(abstractmethod);
missingabstractmethod.scope.problemreporter().abstractmethodmustbeimplemented(this.type, abstractmethod);
} else {
problemreporter().abstractmethodmustbeimplemented(this.type, abstractmethod);
}
}
}
void checkagainstinheritedmethods(methodbinding currentmethod, methodbinding[] methods, int length, methodbinding[] allinheritedmethods) {
if (this.type.isannotationtype()) { // annotation cannot override any method
problemreporter().annotationcannotoverridemethod(currentmethod, methods[length - 1]);
return; // do not repoort against subsequent inherited methods
}
compileroptions options = this.type.scope.compileroptions();
// need to find the overridden methods to avoid blaming this type for issues which are already reported against a supertype
// but cannot ignore an overridden inherited method completely when it comes to checking for bridge methods
int[] overriddeninheritedmethods = length > 1 ? findoverriddeninheritedmethods(methods, length) : null;
nextmethod : for (int i = length; --i >= 0;) {
methodbinding inheritedmethod = methods[i];
if (overriddeninheritedmethods == null || overriddeninheritedmethods[i] == 0) {
if (currentmethod.isstatic() != inheritedmethod.isstatic()) {  // cannot override a static method or hide an instance method
problemreporter(currentmethod).staticandinstanceconflict(currentmethod, inheritedmethod);
continue nextmethod;
}

// want to tag currentmethod even if return types are not equal
if (inheritedmethod.isabstract()) {
if (inheritedmethod.declaringclass.isinterface()) {
currentmethod.modifiers |= extracompilermodifiers.accimplementing;
} else {
currentmethod.modifiers |= extracompilermodifiers.accimplementing | extracompilermodifiers.accoverriding;
}
//			with the above change an abstract method is tagged as implementing the inherited abstract method
//			if (!currentmethod.isabstract() && inheritedmethod.isabstract()) {
//				if ((currentmethod.modifiers & compilermodifiers.accoverriding) == 0)
//					currentmethod.modifiers |= compilermodifiers.accimplementing;
} else if (inheritedmethod.ispublic() || !this.type.isinterface()) {
// interface i { @@override object clone(); } does not override object#clone()
currentmethod.modifiers |= extracompilermodifiers.accoverriding;
}

if (!arereturntypescompatible(currentmethod, inheritedmethod)
&& (currentmethod.returntype.tagbits & tagbits.hasmissingtype) == 0) {
if (reportincompatiblereturntypeerror(currentmethod, inheritedmethod))
continue nextmethod;
}

if (currentmethod.thrownexceptions != binding.no_exceptions)
checkexceptions(currentmethod, inheritedmethod);
if (inheritedmethod.isfinal())
problemreporter(currentmethod).finalmethodcannotbeoverridden(currentmethod, inheritedmethod);
if (!isasvisible(currentmethod, inheritedmethod))
problemreporter(currentmethod).visibilityconflict(currentmethod, inheritedmethod);
if(inheritedmethod.issynchronized() && !currentmethod.issynchronized()) {
problemreporter(currentmethod).missingsynchronizedoninheritedmethod(currentmethod, inheritedmethod);
}
if (options.reportdeprecationwhenoverridingdeprecatedmethod && inheritedmethod.isviewedasdeprecated()) {
if (!currentmethod.isviewedasdeprecated() || options.reportdeprecationinsidedeprecatedcode) {
// check against the other inherited methods to see if they hide this inheritedmethod
referencebinding declaringclass = inheritedmethod.declaringclass;
if (declaringclass.isinterface())
for (int j = length; --j >= 0;)
if (i != j && methods[j].declaringclass.implementsinterface(declaringclass, false))
continue nextmethod;

problemreporter(currentmethod).overridesdeprecatedmethod(currentmethod, inheritedmethod);
}
}
}
checkforbridgemethod(currentmethod, inheritedmethod, allinheritedmethods);
}
}

void checkconcreteinheritedmethod(methodbinding concretemethod, methodbinding[] abstractmethods) {
// remember that interfaces can only define public instance methods
if (concretemethod.isstatic())
// cannot inherit a static method which is specified as an instance method by an interface
problemreporter().staticinheritedmethodconflicts(this.type, concretemethod, abstractmethods);
if (!concretemethod.ispublic()) {
int index = 0, length = abstractmethods.length;
if (concretemethod.isprotected()) {
for (; index < length; index++)
if (abstractmethods[index].ispublic()) break;
} else if (concretemethod.isdefault()) {
for (; index < length; index++)
if (!abstractmethods[index].isdefault()) break;
}
if (index < length)
problemreporter().inheritedmethodreducesvisibility(this.type, concretemethod, abstractmethods);
}
if (concretemethod.thrownexceptions != binding.no_exceptions)
for (int i = abstractmethods.length; --i >= 0;)
checkexceptions(concretemethod, abstractmethods[i]);

// a subclass inheriting this method and putting it up as the implementation to meet its own
// obligations should qualify as a use.
if (concretemethod.isorenclosedbyprivatetype())
concretemethod.original().modifiers |= extracompilermodifiers.acclocallyused;
}

/*
"8.4.4"
verify that newexceptions are all included in inheritedexceptions.
assumes all exceptions are valid and throwable.
unchecked exceptions (compatible with runtime & error) are ignored (see the spec on pg. 203).
*/
void checkexceptions(methodbinding newmethod, methodbinding inheritedmethod) {
referencebinding[] newexceptions = resolvedexceptiontypesfor(newmethod);
referencebinding[] inheritedexceptions = resolvedexceptiontypesfor(inheritedmethod);
for (int i = newexceptions.length; --i >= 0;) {
referencebinding newexception = newexceptions[i];
int j = inheritedexceptions.length;
while (--j > -1 && !issameclassorsubclassof(newexception, inheritedexceptions[j])){/*empty*/}
if (j == -1)
if (!newexception.isuncheckedexception(false)
&& (newexception.tagbits & tagbits.hasmissingtype) == 0) {
problemreporter(newmethod).incompatibleexceptioninthrowsclause(this.type, newmethod, inheritedmethod, newexception);
}
}
}

void checkforbridgemethod(methodbinding currentmethod, methodbinding inheritedmethod, methodbinding[] allinheritedmethods) {
// no op before 1.5
}

void checkformissinghashcodemethod() {
methodbinding[] choices = this.type.getmethods(typeconstants.equals);
boolean overridesequals = false;
for (int i = choices.length; !overridesequals && --i >= 0;)
overridesequals = choices[i].parameters.length == 1 && choices[i].parameters[0].id == typeids.t_javalangobject;
if (overridesequals) {
methodbinding hashcodemethod = this.type.getexactmethod(typeconstants.hashcode, binding.no_parameters, null);
if (hashcodemethod != null && hashcodemethod.declaringclass.id == typeids.t_javalangobject)
this.problemreporter().shouldimplementhashcode(this.type);
}
}

void checkforredundantsuperinterfaces(referencebinding superclass, referencebinding[] superinterfaces) {
if (superinterfaces == binding.no_superinterfaces) return;

simpleset interfacestocheck = new simpleset(superinterfaces.length);
next : for (int i = 0, l = superinterfaces.length; i < l; i++) {
referencebinding tocheck = superinterfaces[i];
for (int j = 0; j < l; j++) {
if (i != j && tocheck.implementsinterface(superinterfaces[j], true)) {
typereference[] refs = this.type.scope.referencecontext.superinterfaces;
for (int r = 0, rl = refs.length; r < rl; r++) {
if (refs[r].resolvedtype == tocheck) {
problemreporter().redundantsuperinterface(this.type, refs[j], superinterfaces[j], tocheck);
continue next;
}
}
}
}
interfacestocheck.add(tocheck);
}

referencebinding[] itsinterfaces = null;
simpleset inheritedinterfaces = new simpleset(5);
referencebinding supertype = superclass;
while (supertype != null && supertype.isvalidbinding()) {
if ((itsinterfaces = supertype.superinterfaces()) != binding.no_superinterfaces) {
for (int i = 0, l = itsinterfaces.length; i < l; i++) {
referencebinding inheritedinterface = itsinterfaces[i];
if (!inheritedinterfaces.includes(inheritedinterface) && inheritedinterface.isvalidbinding()) {
if (interfacestocheck.includes(inheritedinterface)) {
typereference[] refs = this.type.scope.referencecontext.superinterfaces;
for (int r = 0, rl = refs.length; r < rl; r++) {
if (refs[r].resolvedtype == inheritedinterface) {
problemreporter().redundantsuperinterface(this.type, refs[r], inheritedinterface, supertype);
break;
}
}
} else {
inheritedinterfaces.add(inheritedinterface);
}
}
}
}
supertype = supertype.superclass();
}

int nextposition = inheritedinterfaces.elementsize;
if (nextposition == 0) return;
referencebinding[] interfacestovisit = new referencebinding[nextposition];
inheritedinterfaces.asarray(interfacestovisit);
for (int i = 0; i < nextposition; i++) {
supertype = interfacestovisit[i];
if ((itsinterfaces = supertype.superinterfaces()) != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
for (int a = 0; a < itslength; a++) {
referencebinding inheritedinterface = itsinterfaces[a];
if (!inheritedinterfaces.includes(inheritedinterface) && inheritedinterface.isvalidbinding()) {
if (interfacestocheck.includes(inheritedinterface)) {
typereference[] refs = this.type.scope.referencecontext.superinterfaces;
for (int r = 0, rl = refs.length; r < rl; r++) {
if (refs[r].resolvedtype == inheritedinterface) {
problemreporter().redundantsuperinterface(this.type, refs[r], inheritedinterface, supertype);
break;
}
}
} else {
inheritedinterfaces.add(inheritedinterface);
interfacestovisit[nextposition++] = inheritedinterface;
}
}
}
}
}
}

void checkinheritedmethods(methodbinding[] methods, int length) {
/*
1. find concrete method
2. if it doesn't exist then find first inherited abstract method whose return type is compatible with all others
if no such method exists then report incompatible return type error
otherwise report abstract method must be implemented
3. if concrete method exists, check to see if its return type is compatible with all others
if it is then check concrete method against abstract methods
if its not, then find most specific abstract method & report abstract method must be implemented since concrete method is insufficient
if no most specific return type abstract method exists, then report incompatible return type with all inherited methods
*/

methodbinding concretemethod = this.type.isinterface() || methods[0].isabstract() ? null : methods[0];
if (concretemethod == null) {
methodbinding bestabstractmethod = length == 1 ? methods[0] : findbestinheritedabstractmethod(methods, length);
boolean nomatch = bestabstractmethod == null;
if (nomatch)
bestabstractmethod = methods[0];
if (mustimplementabstractmethod(bestabstractmethod.declaringclass)) {
typedeclaration typedeclaration = this.type.scope.referencecontext;
methodbinding superclassabstractmethod = methods[0];
if (superclassabstractmethod == bestabstractmethod || superclassabstractmethod.declaringclass.isinterface()) {
if (typedeclaration != null) {
methoddeclaration missingabstractmethod = typedeclaration.addmissingabstractmethodfor(bestabstractmethod);
missingabstractmethod.scope.problemreporter().abstractmethodmustbeimplemented(this.type, bestabstractmethod);
} else {
problemreporter().abstractmethodmustbeimplemented(this.type, bestabstractmethod);
}
} else {
if (typedeclaration != null) {
methoddeclaration missingabstractmethod = typedeclaration.addmissingabstractmethodfor(bestabstractmethod);
missingabstractmethod.scope.problemreporter().abstractmethodmustbeimplemented(this.type, bestabstractmethod, superclassabstractmethod);
} else {
problemreporter().abstractmethodmustbeimplemented(this.type, bestabstractmethod, superclassabstractmethod);
}
}
} else if (nomatch) {
problemreporter().inheritedmethodshaveincompatiblereturntypes(this.type, methods, length);
}
return;
}
if (length < 2) return; // nothing else to check

int index = length;
while (--index > 0 && checkinheritedreturntypes(concretemethod, methods[index])) {/*empty*/}
if (index > 0) {
// concretemethod is not the best match
methodbinding bestabstractmethod = findbestinheritedabstractmethod(methods, length);
if (bestabstractmethod == null)
problemreporter().inheritedmethodshaveincompatiblereturntypes(this.type, methods, length);
else // can only happen in >= 1.5 since return types must be equal prior to 1.5
problemreporter().abstractmethodmustbeimplemented(this.type, bestabstractmethod, concretemethod);
return;
}

methodbinding[] abstractmethods = new methodbinding[length - 1];
index = 0;
for (int i = 0; i < length; i++)
if (methods[i].isabstract())
abstractmethods[index++] = methods[i];
if (index == 0) return; // can happen with methods that contain 'equal' missing types, see bug 257384
if (index < abstractmethods.length)
system.arraycopy(abstractmethods, 0, abstractmethods = new methodbinding[index], 0, index);
checkconcreteinheritedmethod(concretemethod, abstractmethods);
}

boolean checkinheritedreturntypes(methodbinding method, methodbinding othermethod) {
if (arereturntypescompatible(method, othermethod)) return true;

if (!this.type.isinterface())
if (method.declaringclass.isclass() || !this.type.implementsinterface(method.declaringclass, false))
if (othermethod.declaringclass.isclass() || !this.type.implementsinterface(othermethod.declaringclass, false))
return true; // do not complain since the superclass already got blamed

return false;
}

/*
for each inherited method identifier (message pattern - vm signature minus the return type)
if current method exists
if current's vm signature does not match an inherited signature then complain
else compare current's exceptions & visibility against each inherited method
else
if inherited methods = 1
if inherited is abstract && type is not an interface or abstract, complain
else
if vm signatures do not match complain
else
find the concrete implementation amongst the abstract methods (can only be 1)
if one exists then
it must be a public instance method
compare concrete's exceptions against each abstract method
else
complain about missing implementation only if type is not an interface or abstract
*/
void checkmethods() {
boolean mustimplementabstractmethods = mustimplementabstractmethods();
boolean skipinheritedmethods = mustimplementabstractmethods && canskipinheritedmethods(); // have a single concrete superclass so only check overridden methods
boolean isorenclosedbyprivatetype = this.type.isorenclosedbyprivatetype();
char[][] methodselectors = this.inheritedmethods.keytable;
nextselector : for (int s = methodselectors.length; --s >= 0;) {
if (methodselectors[s] == null) continue nextselector;

methodbinding[] current = (methodbinding[]) this.currentmethods.get(methodselectors[s]);
methodbinding[] inherited = (methodbinding[]) this.inheritedmethods.valuetable[s];

// https://bugs.eclipse.org/bugs/show_bug.cgi?id=296660, if current type is exposed,
// inherited methods of super classes are too. current != null case handled below.
if (current == null && !isorenclosedbyprivatetype) {
int length = inherited.length;
for (int i = 0; i < length; i++){
inherited[i].original().modifiers |= extracompilermodifiers.acclocallyused;
}
}

if (current == null && skipinheritedmethods)
continue nextselector;

if (inherited.length == 1 && current == null) { // handle the common case
if (mustimplementabstractmethods && inherited[0].isabstract())
checkabstractmethod(inherited[0]);
continue nextselector;
}

int index = -1;
methodbinding[] matchinginherited = new methodbinding[inherited.length];
if (current != null) {
for (int i = 0, length1 = current.length; i < length1; i++) {
methodbinding currentmethod = current[i];
for (int j = 0, length2 = inherited.length; j < length2; j++) {
methodbinding inheritedmethod = computesubstitutemethod(inherited[j], currentmethod);
if (inheritedmethod != null) {
if (isparametersubsignature(currentmethod, inheritedmethod)) {
matchinginherited[++index] = inheritedmethod;
inherited[j] = null; // do not want to find it again
}
}
}
if (index >= 0) {
checkagainstinheritedmethods(currentmethod, matchinginherited, index + 1, inherited); // pass in the length of matching
while (index >= 0) matchinginherited[index--] = null; // clear the contents of the matching methods
}
}
}

for (int i = 0, length = inherited.length; i < length; i++) {
methodbinding inheritedmethod = inherited[i];
if (inheritedmethod == null) continue;
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=296660, if current type is exposed,
// inherited methods of super classes are too. current == null case handled already.
if (!isorenclosedbyprivatetype && current != null) {
inheritedmethod.original().modifiers |= extracompilermodifiers.acclocallyused;
}
matchinginherited[++index] = inheritedmethod;
for (int j = i + 1; j < length; j++) {
methodbinding otherinheritedmethod = inherited[j];
if (canskipinheritedmethods(inheritedmethod, otherinheritedmethod))
continue;
otherinheritedmethod = computesubstitutemethod(otherinheritedmethod, inheritedmethod);
if (otherinheritedmethod != null) {
if (isparametersubsignature(inheritedmethod, otherinheritedmethod)) {
matchinginherited[++index] = otherinheritedmethod;
inherited[j] = null; // do not want to find it again
}
}
}
if (index == -1) continue;
if (index > 0)
checkinheritedmethods(matchinginherited, index + 1); // pass in the length of matching
else if (mustimplementabstractmethods && matchinginherited[0].isabstract())
checkabstractmethod(matchinginherited[0]);
while (index >= 0) matchinginherited[index--] = null; // clear the contents of the matching methods
}
}
}

void checkpackageprivateabstractmethod(methodbinding abstractmethod) {
// check that the inherited abstract method (package private visibility) is implemented within the same package
packagebinding necessarypackage = abstractmethod.declaringclass.fpackage;
if (necessarypackage == this.type.fpackage) return; // not a problem

referencebinding supertype = this.type.superclass();
char[] selector = abstractmethod.selector;
do {
if (!supertype.isvalidbinding()) return;
if (!supertype.isabstract()) return; // closer non abstract super type will be flagged instead

if (necessarypackage == supertype.fpackage) {
methodbinding[] methods = supertype.getmethods(selector);
nextmethod : for (int m = methods.length; --m >= 0;) {
methodbinding method = methods[m];
if (method.isprivate() || method.isconstructor() || method.isdefaultabstract())
continue nextmethod;
if (aremethodscompatible(method, abstractmethod))
return; // found concrete implementation of abstract method in same package
}
}
} while ((supertype = supertype.superclass()) != abstractmethod.declaringclass);

// non visible abstract methods cannot be overridden so the type must be defined abstract
problemreporter().abstractmethodcannotbeoverridden(this.type, abstractmethod);
}

void computeinheritedmethods() {
referencebinding superclass = this.type.isinterface()
? this.type.scope.getjavalangobject() // check interface methods against object
: this.type.superclass(); // class or enum
computeinheritedmethods(superclass, this.type.superinterfaces());
checkforredundantsuperinterfaces(superclass, this.type.superinterfaces());
}

/*
binding creation is responsible for reporting:
- all modifier problems (duplicates & multiple visibility modifiers + incompatible combinations)
- plus invalid modifiers given the context... examples:
- interface methods can only be public
- abstract methods can only be defined by abstract classes
- collisions... 2 methods with identical vmselectors
- multiple methods with the same message pattern but different return types
- ambiguous, invisible or missing return/argument/exception types
- check the type of any array is not void
- check that each exception type is throwable or a subclass of it
*/
void computeinheritedmethods(referencebinding superclass, referencebinding[] superinterfaces) {
// only want to remember inheritedmethods that can have an impact on the current type
// if an inheritedmethod has been 'replaced' by a supertype's method then skip it, however
// see usage of canoverridingmethoddifferinerasure below.
this.inheritedmethods = new hashtableofobject(51); // maps method selectors to an array of methods... must search to match paramaters & return type
referencebinding[] interfacestovisit = null;
int nextposition = 0;
referencebinding[] itsinterfaces = superinterfaces;
if (itsinterfaces != binding.no_superinterfaces) {
nextposition = itsinterfaces.length;
interfacestovisit = itsinterfaces;
}

referencebinding supertype = superclass;
hashtableofobject nonvisibledefaultmethods = new hashtableofobject(3); // maps method selectors to an array of methods

while (supertype != null && supertype.isvalidbinding()) {
// we used to only include superinterfaces if immediate superclasses are abstract
// but that is problematic. see https://bugs.eclipse.org/bugs/show_bug.cgi?id=302358
if ((itsinterfaces = supertype.superinterfaces()) != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}

methodbinding[] methods = supertype.unresolvedmethods();
nextmethod : for (int m = methods.length; --m >= 0;) {
methodbinding inheritedmethod = methods[m];
if (inheritedmethod.isprivate() || inheritedmethod.isconstructor() || inheritedmethod.isdefaultabstract())
continue nextmethod;
methodbinding[] existingmethods = (methodbinding[]) this.inheritedmethods.get(inheritedmethod.selector);
if (existingmethods != null) {
existing : for (int i = 0, length = existingmethods.length; i < length; i++) {
methodbinding existingmethod = existingmethods[i];
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=302358, skip inherited method only if any overriding version
// in a subclass is guaranteed to have the same erasure as an existing method.
if (existingmethod.declaringclass != inheritedmethod.declaringclass && aremethodscompatible(existingmethod, inheritedmethod) && !canoverridingmethoddifferinerasure(existingmethod, inheritedmethod)) {
if (inheritedmethod.isdefault()) {
if (inheritedmethod.isabstract()) {
checkpackageprivateabstractmethod(inheritedmethod);
} else if (existingmethod.declaringclass.fpackage != inheritedmethod.declaringclass.fpackage) {
if (this.type.fpackage == inheritedmethod.declaringclass.fpackage && !arereturntypescompatible(inheritedmethod, existingmethod))
continue existing; // may need to record incompatible return type
}
}
continue nextmethod;
}
}
}

if (!inheritedmethod.isdefault() || inheritedmethod.declaringclass.fpackage == this.type.fpackage) {
if (existingmethods == null) {
existingmethods = new methodbinding[] {inheritedmethod};
} else {
int length = existingmethods.length;
system.arraycopy(existingmethods, 0, existingmethods = new methodbinding[length + 1], 0, length);
existingmethods[length] = inheritedmethod;
}
this.inheritedmethods.put(inheritedmethod.selector, existingmethods);
} else {
methodbinding[] nonvisible = (methodbinding[]) nonvisibledefaultmethods.get(inheritedmethod.selector);
if (nonvisible != null)
for (int i = 0, l = nonvisible.length; i < l; i++)
if (aremethodscompatible(nonvisible[i], inheritedmethod))
continue nextmethod;
if (nonvisible == null) {
nonvisible = new methodbinding[] {inheritedmethod};
} else {
int length = nonvisible.length;
system.arraycopy(nonvisible, 0, nonvisible = new methodbinding[length + 1], 0, length);
nonvisible[length] = inheritedmethod;
}
nonvisibledefaultmethods.put(inheritedmethod.selector, nonvisible);

if (inheritedmethod.isabstract() && !this.type.isabstract()) // non visible abstract methods cannot be overridden so the type must be defined abstract
problemreporter().abstractmethodcannotbeoverridden(this.type, inheritedmethod);

methodbinding[] current = (methodbinding[]) this.currentmethods.get(inheritedmethod.selector);
if (current != null && !inheritedmethod.isstatic()) { // non visible methods cannot be overridden so a warning is issued
foundmatch : for (int i = 0, length = current.length; i < length; i++) {
if (!current[i].isstatic() && aremethodscompatible(current[i], inheritedmethod)) {
problemreporter().overridespackagedefaultmethod(current[i], inheritedmethod);
break foundmatch;
}
}
}
}
}
supertype = supertype.superclass();
}
if (nextposition == 0) return;

simpleset skip = findsuperinterfacecollisions(superclass, superinterfaces);
for (int i = 0; i < nextposition; i++) {
supertype = interfacestovisit[i];
if (supertype.isvalidbinding()) {
if (skip != null && skip.includes(supertype)) continue;
if ((itsinterfaces = supertype.superinterfaces()) != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}

methodbinding[] methods = supertype.unresolvedmethods();
nextmethod : for (int m = methods.length; --m >= 0;) { // interface methods are all abstract public
methodbinding inheritedmethod = methods[m];
methodbinding[] existingmethods = (methodbinding[]) this.inheritedmethods.get(inheritedmethod.selector);
if (existingmethods == null) {
existingmethods = new methodbinding[] {inheritedmethod};
} else {
int length = existingmethods.length;
// look to see if any of the existingmethods implement this inheritedmethod
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=302358, skip inherited method only if any overriding version
// in a subclass is guaranteed to have the same erasure as an existing method.
for (int e = 0; e < length; e++)
if (isinterfacemethodimplemented(inheritedmethod, existingmethods[e], supertype) && !canoverridingmethoddifferinerasure(existingmethods[e], inheritedmethod))
continue nextmethod; // skip interface method with the same signature if visible to its declaringclass
system.arraycopy(existingmethods, 0, existingmethods = new methodbinding[length + 1], 0, length);
existingmethods[length] = inheritedmethod;
}
this.inheritedmethods.put(inheritedmethod.selector, existingmethods);
}
}
}
}

// given `overridingmethod' which overrides `inheritedmethod' answer whether some subclass method that
// differs in erasure from overridingmethod could override `inheritedmethod'
protected boolean canoverridingmethoddifferinerasure(methodbinding overridingmethod, methodbinding inheritedmethod) {
return false;   // the case for <= 1.4  (cannot differ)
}
void computemethods() {
methodbinding[] methods = this.type.methods();
int size = methods.length;
this.currentmethods = new hashtableofobject(size == 0 ? 1 : size); // maps method selectors to an array of methods... must search to match paramaters & return type
for (int m = size; --m >= 0;) {
methodbinding method = methods[m];
if (!(method.isconstructor() || method.isdefaultabstract())) { // keep all methods which are not constructors or default abstract
methodbinding[] existingmethods = (methodbinding[]) this.currentmethods.get(method.selector);
if (existingmethods == null)
existingmethods = new methodbinding[1];
else
system.arraycopy(existingmethods, 0,
(existingmethods = new methodbinding[existingmethods.length + 1]), 0, existingmethods.length - 1);
existingmethods[existingmethods.length - 1] = method;
this.currentmethods.put(method.selector, existingmethods);
}
}
}

methodbinding computesubstitutemethod(methodbinding inheritedmethod, methodbinding currentmethod) {
if (inheritedmethod == null) return null;
if (currentmethod.parameters.length != inheritedmethod.parameters.length) return null; // no match
return inheritedmethod;
}

boolean couldmethodoverride(methodbinding method, methodbinding inheritedmethod) {
if (!org.eclipse.jdt.core.compiler.charoperation.equals(method.selector, inheritedmethod.selector))
return false;
if (method == inheritedmethod || method.isstatic() || inheritedmethod.isstatic())
return false;
if (inheritedmethod.isprivate())
return false;
if (inheritedmethod.isdefault() && method.declaringclass.getpackage() != inheritedmethod.declaringclass.getpackage())
return false;
if (!method.ispublic()) { // inheritedmethod is either public or protected & method is less than public
if (inheritedmethod.ispublic())
return false;
if (inheritedmethod.isprotected() && !method.isprotected())
return false;
}
return true;
}

// answer whether the method overrides the inheritedmethod
// check the necessary visibility rules & inheritance from the inheritedmethod's declaringclass
// see ismethodsubsignature() for parameter comparisons
public boolean doesmethodoverride(methodbinding method, methodbinding inheritedmethod) {
if (!couldmethodoverride(method, inheritedmethod))
return false;

inheritedmethod = inheritedmethod.original();
typebinding match = method.declaringclass.findsupertypeoriginatingfrom(inheritedmethod.declaringclass);
if (!(match instanceof referencebinding))
return false; // method's declaringclass does not inherit from inheritedmethod's

return isparametersubsignature(method, inheritedmethod);
}

simpleset findsuperinterfacecollisions(referencebinding superclass, referencebinding[] superinterfaces) {
return null; // noop in 1.4
}

methodbinding findbestinheritedabstractmethod(methodbinding[] methods, int length) {
findmethod : for (int i = 0; i < length; i++) {
methodbinding method = methods[i];
if (!method.isabstract()) continue findmethod;
for (int j = 0; j < length; j++) {
if (i == j) continue;
if (!checkinheritedreturntypes(method, methods[j])) {
if (this.type.isinterface() && methods[j].declaringclass.id == typeids.t_javalangobject)
return method; // do not complain since the super interface already got blamed
continue findmethod;
}
}
return method;
}
return null;
}

int[] findoverriddeninheritedmethods(methodbinding[] methods, int length) {
// note assumes length > 1
// inherited methods are added as we walk up the superclass hierarchy, then each superinterface
// so method[1] from a class can not override method[0], but methods from superinterfaces can
// since superinterfaces can be added from different superclasses or other superinterfaces
int[] toskip = null;
int i = 0;
referencebinding declaringclass = methods[i].declaringclass;
if (!declaringclass.isinterface()) {
// in the first pass, skip overridden methods from superclasses
// only keep methods from the closest superclass, all others from higher superclasses can be skipped
// note: methods were added in order by walking up the superclass hierarchy
referencebinding declaringclass2 = methods[++i].declaringclass;
while (declaringclass == declaringclass2) {
if (++i == length) return null;
declaringclass2 = methods[i].declaringclass;
}
if (!declaringclass2.isinterface()) {
// skip all methods from different superclasses
if (declaringclass.fpackage != declaringclass2.fpackage && methods[i].isdefault()) return null;
toskip = new int[length];
do {
toskip[i] = -1;
if (++i == length) return toskip;
declaringclass2 = methods[i].declaringclass;
} while (!declaringclass2.isinterface());
}
}
// in the second pass, skip overridden methods from superinterfaces
// note: superinterfaces can appear in 'random' order
nextmethod : for (; i < length; i++) {
if (toskip != null && toskip[i] == -1) continue nextmethod;
declaringclass = methods[i].declaringclass;
for (int j = i + 1; j < length; j++) {
if (toskip != null && toskip[j] == -1) continue;
referencebinding declaringclass2 = methods[j].declaringclass;
if (declaringclass == declaringclass2) continue;
if (declaringclass.implementsinterface(declaringclass2, true)) {
if (toskip == null)
toskip = new int[length];
toskip[j] = -1;
} else if (declaringclass2.implementsinterface(declaringclass, true)) {
if (toskip == null)
toskip = new int[length];
toskip[i] = -1;
continue nextmethod;
}
}
}
return toskip;
}

boolean isasvisible(methodbinding newmethod, methodbinding inheritedmethod) {
if (inheritedmethod.modifiers == newmethod.modifiers) return true;

if (newmethod.ispublic()) return true;		// covers everything
if (inheritedmethod.ispublic()) return false;

if (newmethod.isprotected()) return true;
if (inheritedmethod.isprotected()) return false;

return !newmethod.isprivate();		// the inheritedmethod cannot be private since it would not be visible
}

boolean isinterfacemethodimplemented(methodbinding inheritedmethod, methodbinding existingmethod, referencebinding supertype) {
// skip interface method with the same signature if visible to its declaringclass
return areparametersequal(existingmethod, inheritedmethod) && existingmethod.declaringclass.implementsinterface(supertype, true);
}

public boolean ismethodsubsignature(methodbinding method, methodbinding inheritedmethod) {
return org.eclipse.jdt.core.compiler.charoperation.equals(method.selector, inheritedmethod.selector)
&& isparametersubsignature(method, inheritedmethod);
}

boolean isparametersubsignature(methodbinding method, methodbinding inheritedmethod) {
return areparametersequal(method, inheritedmethod);
}

boolean issameclassorsubclassof(referencebinding testclass, referencebinding superclass) {
do {
if (testclass == superclass) return true;
} while ((testclass = testclass.superclass()) != null);
return false;
}

boolean mustimplementabstractmethod(referencebinding declaringclass) {
// if the type's superclass is an abstract class, then all abstract methods must be implemented
// otherwise, skip it if the type's superclass must implement any of the inherited methods
if (!mustimplementabstractmethods()) return false;
referencebinding superclass = this.type.superclass();
if (declaringclass.isclass()) {
while (superclass.isabstract() && superclass != declaringclass)
superclass = superclass.superclass(); // find the first concrete superclass or the abstract declaringclass
} else {
if (this.type.implementsinterface(declaringclass, false))
if (!superclass.implementsinterface(declaringclass, true)) // only if a superclass does not also implement the interface
return true;
while (superclass.isabstract() && !superclass.implementsinterface(declaringclass, false))
superclass = superclass.superclass(); // find the first concrete superclass or the superclass which implements the interface
}
return superclass.isabstract();		// if it is a concrete class then we have already reported problem against it
}

boolean mustimplementabstractmethods() {
return !this.type.isinterface() && !this.type.isabstract();
}

problemreporter problemreporter() {
return this.type.scope.problemreporter();
}

problemreporter problemreporter(methodbinding currentmethod) {
problemreporter reporter = problemreporter();
if (currentmethod.declaringclass == this.type && currentmethod.sourcemethod() != null)	// only report against the currentmethod if its implemented by the type
reporter.referencecontext = currentmethod.sourcemethod();
return reporter;
}

/**
* return true and report an incompatiblereturntype error if currentmethod's
* return type is strictly incompatible with inheritedmethod's, else return
* false and report an unchecked conversion warning. do not call when
* arereturntypescompatible(currentmethod, inheritedmethod) returns true.
* @@param currentmethod the (potentially) inheriting method
* @@param inheritedmethod the inherited method
* @@return true if currentmethod's return type is strictly incompatible with
*         inheritedmethod's
*/
boolean reportincompatiblereturntypeerror(methodbinding currentmethod, methodbinding inheritedmethod) {
problemreporter(currentmethod).incompatiblereturntype(currentmethod, inheritedmethod);
return true;
}

referencebinding[] resolvedexceptiontypesfor(methodbinding method) {
referencebinding[] exceptions = method.thrownexceptions;
if ((method.modifiers & extracompilermodifiers.accunresolved) == 0)
return exceptions;

if (!(method.declaringclass instanceof binarytypebinding))
return binding.no_exceptions; // safety check

for (int i = exceptions.length; --i >= 0;)
exceptions[i] = (referencebinding) binarytypebinding.resolvetype(exceptions[i], this.environment, true /* raw conversion */);
return exceptions;
}

void verify() {
computemethods();
computeinheritedmethods();
checkmethods();
if (this.type.isclass())
checkformissinghashcodemethod();
}

void verify(sourcetypebinding sometype) {
if (this.type == null) {
try {
this.type = sometype;
verify();
} finally {
this.type = null;
}
} else {
this.environment.newmethodverifier().verify(sometype);
}
}

public string tostring() {
stringbuffer buffer = new stringbuffer(10);
buffer.append("methodverifier for type: "); //$non-nls-1$
buffer.append(this.type.readablename());
buffer.append('\n');
buffer.append("\t-inherited methods: "); //$non-nls-1$
buffer.append(this.inheritedmethods);
return buffer.tostring();
}
}
