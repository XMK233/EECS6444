/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce a type reference containing the completion identifier as part
* of a qualified name.
* e.g.
*
*	class x extends java.lang.obj[cursor]
*
*	---> class x extends <completeontype:java.lang.obj>
*
* the source range of the completion node denotes the source range
* which should be replaced by the completion.
*/

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class completiononqualifiedtypereference extends qualifiedtypereference {
public static final int k_type = 0;
public static final int k_class = 1;
public static final int k_interface = 2;
public static final int k_exception = 3;

private int kind = k_type;
public char[] completionidentifier;

public boolean isconstructortype;

public completiononqualifiedtypereference(char[][] previousidentifiers, char[] completionidentifier, long[] positions) {
this(previousidentifiers, completionidentifier, positions, k_type);
}
public completiononqualifiedtypereference(char[][] previousidentifiers, char[] completionidentifier, long[] positions, int kind) {
super(previousidentifiers, positions);
this.completionidentifier = completionidentifier;
this.kind = kind;
}
public void abouttoresolve(scope scope) {
gettypebinding(scope);
}
/*
* no expansion of the completion reference into an array one
*/
public typereference copydims(int dim){
return this;
}
protected typebinding gettypebinding(scope scope) {
// it can be a package, type or member type
binding binding = scope.parent.gettypeorpackage(this.tokens); // step up from the classscope
if (!binding.isvalidbinding()) {
scope.problemreporter().invalidtype(this, (typebinding) binding);

if (binding.problemid() == problemreasons.notfound) {
throw new completionnodefound(this, binding, scope);
}

throw new completionnodefound();
}

throw new completionnodefound(this, binding, scope);
}
public boolean isclass(){
return this.kind == k_class;
}

public boolean isinterface(){
return this.kind == k_interface;
}

public boolean isexception(){
return this.kind == k_exception;
}

public boolean issupertype(){
return this.kind == k_class || this.kind == k_interface;
}
public void setkind(int kind) {
this.kind = kind;
}
public stringbuffer printexpression(int indent, stringbuffer output) {
switch (this.kind) {
case k_class :
output.append("<completeonclass:");//$non-nls-1$
break;
case k_interface :
output.append("<completeoninterface:");//$non-nls-1$
break;
case k_exception :
output.append("<completeonexception:");//$non-nls-1$
break;
default :
output.append("<completeontype:");//$non-nls-1$
break;
}
for (int i = 0; i < this.tokens.length; i++) {
output.append(this.tokens[i]);
output.append('.');
}
output.append(this.completionidentifier).append('>');
return output;
}
}
