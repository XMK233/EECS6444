/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public abstract class statement extends astnode {

/**
* answers true if the if is identified as a known coding pattern which
* should be tolerated by dead code analysis.
* e.g. if (debug) print(); // no complaint
* only invoked when overall condition is known to be optimizeable into false/true.
*/
protected static boolean isknowdeadcodepattern(expression expression) {
// if (!debug) print(); - tolerated
if (expression instanceof unaryexpression) {
expression = ((unaryexpression) expression).expression;
}
// if (debug) print(); - tolerated
if (expression instanceof reference) return true;

//		if (expression instanceof binaryexpression) {
//			binaryexpression binary = (binaryexpression) expression;
//			switch ((binary.bits & astnode.operatormask) >> astnode.operatorshift/* operator */) {
//				case operatorids.and_and :
//				case operatorids.or_or :
//					break;
//				default:
//					// if (debug_level > 0) print(); - tolerated
//					if ((binary.left instanceof reference) && binary.right.constant != constant.notaconstant)
//						return true;
//					// if (0 < debug_level) print(); - tolerated
//					if ((binary.right instanceof reference) && binary.left.constant != constant.notaconstant)
//						return true;
//			}
//		}
return false;
}
public abstract flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo);

public static final int not_complained = 0;
public static final int complained_fake_reachable = 1;
public static final int complained_unreachable = 2;

/**
* internal use only.
* this is used to redirect inter-statements jumps.
*/
public void branchchainto(branchlabel label) {
// do nothing by default
}

// report an error if necessary (if even more unreachable than previously reported
// complaintlevel = 0 if was reachable up until now, 1 if fake reachable (deadcode), 2 if fatal unreachable (error)
public int complainifunreachable(flowinfo flowinfo, blockscope scope, int previouscomplaintlevel) {
if ((flowinfo.reachmode() & flowinfo.unreachable) != 0) {
this.bits &= ~astnode.isreachable;
if (flowinfo == flowinfo.dead_end) {
if (previouscomplaintlevel < complained_unreachable) {
scope.problemreporter().unreachablecode(this);
}
return complained_unreachable;
} else {
if (previouscomplaintlevel < complained_fake_reachable) {
scope.problemreporter().fakereachable(this);
}
return complained_fake_reachable;
}
}
return previouscomplaintlevel;
}

/**
* generate invocation arguments, considering varargs methods
*/
public void generatearguments(methodbinding binding, expression[] arguments, blockscope currentscope, codestream codestream) {
if (binding.isvarargs()) {
// 5 possibilities exist for a call to the vararg method foo(int i, int ... value) :
//      foo(1), foo(1, null), foo(1, 2), foo(1, 2, 3, 4) & foo(1, new int[] {1, 2})
typebinding[] params = binding.parameters;
int paramlength = params.length;
int varargindex = paramlength - 1;
for (int i = 0; i < varargindex; i++) {
arguments[i].generatecode(currentscope, codestream, true);
}

arraybinding varargstype = (arraybinding) params[varargindex]; // parametertype has to be an array type
arraybinding codegenvarargstype = (arraybinding) binding.parameters[varargindex].erasure();
int elementstypeid = varargstype.elementstype().id;
int arglength = arguments == null ? 0 : arguments.length;

if (arglength > paramlength) {
// right number but not directly compatible or too many arguments - wrap extra into array
// called with (arglength - lastindex) elements : foo(1, 2) or foo(1, 2, 3, 4)
// need to gen elements into an array, then gen each remaining element into created array
codestream.generateinlinedvalue(arglength - varargindex);
codestream.newarray(codegenvarargstype); // create a mono-dimensional array
for (int i = varargindex; i < arglength; i++) {
codestream.dup();
codestream.generateinlinedvalue(i - varargindex);
arguments[i].generatecode(currentscope, codestream, true);
codestream.arrayatput(elementstypeid, false);
}
} else if (arglength == paramlength) {
// right number of arguments - could be inexact - pass argument as is
typebinding lasttype = arguments[varargindex].resolvedtype;
if (lasttype == typebinding.null
|| (varargstype.dimensions() == lasttype.dimensions()
&& lasttype.iscompatiblewith(varargstype))) {
// foo(1, new int[]{2, 3}) or foo(1, null) --> last arg is passed as-is
arguments[varargindex].generatecode(currentscope, codestream, true);
} else {
// right number but not directly compatible or too many arguments - wrap extra into array
// need to gen elements into an array, then gen each remaining element into created array
codestream.generateinlinedvalue(1);
codestream.newarray(codegenvarargstype); // create a mono-dimensional array
codestream.dup();
codestream.generateinlinedvalue(0);
arguments[varargindex].generatecode(currentscope, codestream, true);
codestream.arrayatput(elementstypeid, false);
}
} else { // not enough arguments - pass extra empty array
// scenario: foo(1) --> foo(1, new int[0])
// generate code for an empty array of parametertype
codestream.generateinlinedvalue(0);
codestream.newarray(codegenvarargstype); // create a mono-dimensional array
}
} else if (arguments != null) { // standard generation for method arguments
for (int i = 0, max = arguments.length; i < max; i++)
arguments[i].generatecode(currentscope, codestream, true);
}
}

public abstract void generatecode(blockscope currentscope, codestream codestream);

protected boolean isboxingcompatible(typebinding expressiontype, typebinding targettype, expression expression, scope scope) {
if (scope.isboxingcompatiblewith(expressiontype, targettype))
return true;

return expressiontype.isbasetype()  // narrowing then boxing ?
&& !targettype.isbasetype()
&& !targettype.istypevariable()
&& scope.compileroptions().sourcelevel >= org.eclipse.jdt.internal.compiler.classfmt.classfileconstants.jdk1_5 // autoboxing
&& expression.isconstantvalueoftypeassignabletotype(expressiontype, scope.environment().computeboxingtype(targettype));
}

public boolean isemptyblock() {
return false;
}

public boolean isvalidjavastatement() {
//the use of this method should be avoid in most cases
//and is here mostly for documentation purpose.....
//while the parser is responsible for creating
//welled formed expression statement, which results
//in the fact that java-non-semantic-expression-used-as-statement
//should not be parsed...thus not being built.
//it sounds like the java grammar as help the compiler job in removing
//-by construction- some statement that would have no effect....
//(for example all expression that may do side-effects are valid statement
// -this is an approximative idea.....-)

return true;
}

public stringbuffer print(int indent, stringbuffer output) {
return printstatement(indent, output);
}

public abstract stringbuffer printstatement(int indent, stringbuffer output);

public abstract void resolve(blockscope scope);

/**
* returns case constant associated to this statement (notaconstant if none)
*/
public constant resolvecase(blockscope scope, typebinding testtype, switchstatement switchstatement) {
// statement within a switch that are not case are treated as normal statement....
resolve(scope);
return constant.notaconstant;
}
}
