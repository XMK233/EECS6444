/*******************************************************************************
* copyright (c) 2000, 2006 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

/**
* generic option description, which can be modified independently from the
* component it belongs to.
*
* @@deprecated backport 1.0 internal functionality
*/

import java.util.locale;
import java.util.missingresourceexception;
import java.util.nosuchelementexception;
import java.util.resourcebundle;
import java.util.stringtokenizer;

import org.eclipse.jdt.core.compiler.charoperation;

public class configurableoption {
private string componentname;
private string optionname;
private int id;

private string category;
private string name;
private string description;
private int currentvalueindex;
private string[] possiblevalues;

// special value for <possiblevalues> indicating that
// the <currentvalueindex> is the actual value
public final static string[] nodiscretevalue = {};
/**
* internal use only
*
* initialize an instance of this class according to a specific locale
*
* @@param loc java.util.locale
*/
public configurableoption(
string componentname,
string optionname,
locale loc,
int currentvalueindex) {

this.componentname = componentname;
this.optionname = optionname;
this.currentvalueindex = currentvalueindex;

resourcebundle resource = null;
try {
string location = componentname.substring(0, componentname.lastindexof('.'));
resource = resourcebundle.getbundle(location + ".options", loc); //$non-nls-1$
} catch (missingresourceexception e) {
this.category = "missing ressources entries for" + componentname + " options"; //$non-nls-1$ //$non-nls-2$
this.name = "missing ressources entries for"+ componentname + " options"; //$non-nls-1$ //$non-nls-2$
this.description = "missing ressources entries for" + componentname + " options"; //$non-nls-1$ //$non-nls-2$
this.possiblevalues = charoperation.no_strings;
this.id = -1;
}
if (resource == null) return;
try {
this.id = integer.parseint(resource.getstring(optionname + ".number")); //$non-nls-1$
} catch (missingresourceexception e) {
this.id = -1;
} catch (numberformatexception e) {
this.id = -1;
}
try {
this.category = resource.getstring(optionname + ".category"); //$non-nls-1$
} catch (missingresourceexception e) {
this.category = "missing ressources entries for" + componentname + " options"; //$non-nls-1$ //$non-nls-2$
}
try {
this.name = resource.getstring(optionname + ".name"); //$non-nls-1$
} catch (missingresourceexception e) {
this.name = "missing ressources entries for"+ componentname + " options"; //$non-nls-1$ //$non-nls-2$
}
try {
stringtokenizer tokenizer = new stringtokenizer(resource.getstring(optionname + ".possiblevalues"), "|"); //$non-nls-1$ //$non-nls-2$
int numberofvalues = integer.parseint(tokenizer.nexttoken());
if(numberofvalues == -1){
this.possiblevalues = nodiscretevalue;
} else {
this.possiblevalues = new string[numberofvalues];
int index = 0;
while (tokenizer.hasmoretokens()) {
this.possiblevalues[index] = tokenizer.nexttoken();
index++;
}
}
} catch (missingresourceexception e) {
this.possiblevalues = charoperation.no_strings;
} catch (nosuchelementexception e) {
this.possiblevalues = charoperation.no_strings;
} catch (numberformatexception e) {
this.possiblevalues = charoperation.no_strings;
}
try {
this.description = resource.getstring(optionname + ".description");  //$non-nls-1$
} catch (missingresourceexception e) {
this.description = "missing ressources entries for"+ componentname + " options"; //$non-nls-1$ //$non-nls-2$
}
}
/**
* return a string that represents the localized category of the receiver.
* @@return java.lang.string
*/
public string getcategory() {
return this.category;
}
/**
* return a string that identifies the component owner (typically the qualified
*	type name of the class which it corresponds to).
*
* e.g. "org.eclipse.jdt.internal.compiler.api.compiler"
*
* @@return java.lang.string
*/
public string getcomponentname() {
return this.componentname;
}
/**
* answer the index (in possiblevalues array) of the current setting for this
* particular option.
*
* in case the set of possiblevalues is nodiscretevalue, then this index is the
* actual value (e.g. max line lenght set to 80).
*
* @@return int
*/
public int getcurrentvalueindex() {
return this.currentvalueindex;
}
/**
* return an string that represents the localized description of the receiver.
*
* @@return java.lang.string
*/
public string getdescription() {
return this.description;
}
/**
* internal id which allows the configurable component to identify this particular option.
*
* @@return int
*/
public int getid() {
return this.id;
}
/**
* return a string that represents the localized name of the receiver.
* @@return java.lang.string
*/
public string getname() {
return this.name;
}
/**
* return an array of string that represents the localized possible values of the receiver.
* @@return java.lang.string[]
*/
public string[] getpossiblevalues() {
return this.possiblevalues;
}
/**
* change the index (in possiblevalues array) of the current setting for this
* particular option.
*
* in case the set of possiblevalues is nodiscretevalue, then this index is the
* actual value (e.g. max line lenght set to 80).
*/
public void setvalueindex(int newindex) {
this.currentvalueindex = newindex;
}
public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append("configurable option for "); //$non-nls-1$
buffer.append(this.componentname).append("\n"); //$non-nls-1$
buffer.append("- category:			").append(this.category).append("\n"); //$non-nls-1$ //$non-nls-2$
buffer.append("- name:				").append(this.name).append("\n"); //$non-nls-1$ //$non-nls-2$
/* display current value */
buffer.append("- current value:	"); //$non-nls-1$
if (this.possiblevalues == nodiscretevalue){
buffer.append(this.currentvalueindex);
} else {
buffer.append(this.possiblevalues[this.currentvalueindex]);
}
buffer.append("\n"); //$non-nls-1$

/* display possible values */
if (this.possiblevalues != nodiscretevalue){
buffer.append("- possible values:	["); //$non-nls-1$
for (int i = 0, max = this.possiblevalues.length; i < max; i++) {
if (i != 0)
buffer.append(", "); //$non-nls-1$
buffer.append(this.possiblevalues[i]);
}
buffer.append("]\n"); //$non-nls-1$
buffer.append("- curr. val. index:	").append(this.currentvalueindex).append("\n"); //$non-nls-1$ //$non-nls-2$
}
buffer.append("- description:		").append(this.description).append("\n"); //$non-nls-1$ //$non-nls-2$
return buffer.tostring();
}
/**
* gets the optionname.
* @@return returns a string
*/
public string getoptionname() {
return this.optionname;
}
}
