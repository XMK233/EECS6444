/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.constant;

public class fieldbinding extends variablebinding {
public referencebinding declaringclass;
protected fieldbinding() {
super(null, null, 0, null);
// for creating problem field
}
public fieldbinding(char[] name, typebinding type, int modifiers, referencebinding declaringclass, constant constant) {
super(name, type, modifiers, constant);
this.declaringclass = declaringclass;
}
// special api used to change field declaring class for runtime visibility check
public fieldbinding(fieldbinding initialfieldbinding, referencebinding declaringclass) {
super(initialfieldbinding.name, initialfieldbinding.type, initialfieldbinding.modifiers, initialfieldbinding.constant());
this.declaringclass = declaringclass;
this.id = initialfieldbinding.id;
setannotations(initialfieldbinding.getannotations());
}
/* api
* answer the receiver's binding type from binding.bindingid.
*/
public fieldbinding(fielddeclaration field, typebinding type, int modifiers, referencebinding declaringclass) {
this(field.name, type, modifiers, declaringclass, null);
field.binding = this; // record binding in declaration
}

public final boolean canbeseenby(packagebinding invocationpackage) {
if (ispublic()) return true;
if (isprivate()) return false;

// isprotected() or isdefault()
return invocationpackage == this.declaringclass.getpackage();
}
/* answer true if the receiver is visible to the type provided by the scope.
* invocationsite implements issuperaccess() to provide additional information
* if the receiver is protected.
*
* note: cannot invoke this method with a compilation unit scope.
*/

public final boolean canbeseenby(typebinding receivertype, invocationsite invocationsite, scope scope) {
if (ispublic()) return true;

sourcetypebinding invocationtype = scope.enclosingsourcetype();
if (invocationtype == this.declaringclass && invocationtype == receivertype) return true;

if (invocationtype == null) // static import call
return !isprivate() && scope.getcurrentpackage() == this.declaringclass.fpackage;

if (isprotected()) {
// answer true if the invocationtype is the declaringclass or they are in the same package
// or the invocationtype is a subclass of the declaringclass
//    and the receivertype is the invocationtype or its subclass
//    or the method is a static method accessed directly through a type
//    or previous assertions are true for one of the enclosing type
if (invocationtype == this.declaringclass) return true;
if (invocationtype.fpackage == this.declaringclass.fpackage) return true;

referencebinding currenttype = invocationtype;
int depth = 0;
referencebinding receivererasure = (referencebinding)receivertype.erasure();
referencebinding declaringerasure = (referencebinding) this.declaringclass.erasure();
do {
if (currenttype.findsupertypeoriginatingfrom(declaringerasure) != null) {
if (invocationsite.issuperaccess())
return true;
// receivertype can be an array binding in one case... see if you can change it
if (receivertype instanceof arraybinding)
return false;
if (isstatic()) {
if (depth > 0) invocationsite.setdepth(depth);
return true; // see 1fmepdl - return invocationsite.istypeaccess();
}
if (currenttype == receivererasure || receivererasure.findsupertypeoriginatingfrom(currenttype) != null) {
if (depth > 0) invocationsite.setdepth(depth);
return true;
}
}
depth++;
currenttype = currenttype.enclosingtype();
} while (currenttype != null);
return false;
}

if (isprivate()) {
// answer true if the receivertype is the declaringclass
// and the invocationtype and the declaringclass have a common enclosingtype
receivercheck: {
if (receivertype != this.declaringclass) {
// special tolerance for type variable direct bounds
if (receivertype.istypevariable() && ((typevariablebinding) receivertype).iserasureboundto(this.declaringclass.erasure()))
break receivercheck;
return false;
}
}

if (invocationtype != this.declaringclass) {
referencebinding outerinvocationtype = invocationtype;
referencebinding temp = outerinvocationtype.enclosingtype();
while (temp != null) {
outerinvocationtype = temp;
temp = temp.enclosingtype();
}

referencebinding outerdeclaringclass = (referencebinding) this.declaringclass.erasure();
temp = outerdeclaringclass.enclosingtype();
while (temp != null) {
outerdeclaringclass = temp;
temp = temp.enclosingtype();
}
if (outerinvocationtype != outerdeclaringclass) return false;
}
return true;
}

// isdefault()
packagebinding declaringpackage = this.declaringclass.fpackage;
if (invocationtype.fpackage != declaringpackage) return false;

// receivertype can be an array binding in one case... see if you can change it
if (receivertype instanceof arraybinding)
return false;
typebinding originaldeclaringclass = this.declaringclass.original();
referencebinding currenttype = (referencebinding) receivertype;
do {
if (currenttype.iscapture()) { // https://bugs.eclipse.org/bugs/show_bug.cgi?id=285002
if (originaldeclaringclass == currenttype.erasure().original()) return true;
} else {
if (originaldeclaringclass == currenttype.original()) return true;
}
packagebinding currentpackage = currenttype.fpackage;
// package could be null for wildcards/intersection types, ignore and recurse in superclass
if (currentpackage != null && currentpackage != declaringpackage) return false;
} while ((currenttype = currenttype.superclass()) != null);
return false;
}

/*
* declaringuniquekey dot fieldname ) returntypeuniquekey
* p.x { x<t> x} --> lp/x;.x)p/x<tt;>;
*/
public char[] computeuniquekey(boolean isleaf) {
// declaring key
char[] declaringkey =
this.declaringclass == null /*case of length field for an array*/
? charoperation.no_char
: this.declaringclass.computeuniquekey(false/*not a leaf*/);
int declaringlength = declaringkey.length;

// name
int namelength = this.name.length;

// return type
char[] returntypekey = this.type == null ? new char[] {'v'} : this.type.computeuniquekey(false/*not a leaf*/);
int returntypelength = returntypekey.length;

char[] uniquekey = new char[declaringlength + 1 + namelength + 1 + returntypelength];
int index = 0;
system.arraycopy(declaringkey, 0, uniquekey, index, declaringlength);
index += declaringlength;
uniquekey[index++] = '.';
system.arraycopy(this.name, 0, uniquekey, index, namelength);
index += namelength;
uniquekey[index++] = ')';
system.arraycopy(returntypekey, 0, uniquekey, index, returntypelength);
return uniquekey;
}
public constant constant() {
constant fieldconstant = this.constant;
if (fieldconstant == null) {
if (isfinal()) {
//the field has not been yet type checked.
//it also means that the field is not coming from a class that
//has already been compiled. it can only be from a class within
//compilation units to process. thus the field is not from a binarytypebinbing
fieldbinding originalfield = original();
if (originalfield.declaringclass instanceof sourcetypebinding) {
sourcetypebinding sourcetype = (sourcetypebinding) originalfield.declaringclass;
if (sourcetype.scope != null) {
typedeclaration typedecl = sourcetype.scope.referencecontext;
fielddeclaration fielddecl = typedecl.declarationof(originalfield);
methodscope initscope = originalfield.isstatic() ? typedecl.staticinitializerscope : typedecl.initializerscope;
boolean old = initscope.insidetypeannotation;
try {
initscope.insidetypeannotation = false;
fielddecl.resolve(initscope); //side effect on binding
} finally {
initscope.insidetypeannotation = old;
}
fieldconstant = originalfield.constant == null ? constant.notaconstant : originalfield.constant;
} else {
fieldconstant = constant.notaconstant; // shouldn't occur per construction (paranoid null check)
}
} else {
fieldconstant = constant.notaconstant; // shouldn't occur per construction (paranoid null check)
}
} else {
fieldconstant = constant.notaconstant;
}
this.constant = fieldconstant;
}
return fieldconstant;
}

/**
* x<t> t   -->  lx<tt;>;
*/
public char[] genericsignature() {
if ((this.modifiers & extracompilermodifiers.accgenericsignature) == 0) return null;
return this.type.generictypesignature();
}
public final int getaccessflags() {
return this.modifiers & extracompilermodifiers.accjustflag;
}

public annotationbinding[] getannotations() {
fieldbinding originalfield = original();
referencebinding declaringclassbinding = originalfield.declaringclass;
if (declaringclassbinding == null) {
return binding.no_annotations;
}
return declaringclassbinding.retrieveannotations(originalfield);
}

/**
* compute the tagbits for standard annotations. for source types, these could require
* lazily resolving corresponding annotation nodes, in case of forward references.
* @@see org.eclipse.jdt.internal.compiler.lookup.binding#getannotationtagbits()
*/
public long getannotationtagbits() {
fieldbinding originalfield = original();
if ((originalfield.tagbits & tagbits.annotationresolved) == 0 && originalfield.declaringclass instanceof sourcetypebinding) {
classscope scope = ((sourcetypebinding) originalfield.declaringclass).scope;
if (scope == null) { // synthetic fields do not have a scope nor any annotations
this.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
return 0;
}
typedeclaration typedecl = scope.referencecontext;
fielddeclaration fielddecl = typedecl.declarationof(originalfield);
if (fielddecl != null) {
methodscope initializationscope = isstatic() ? typedecl.staticinitializerscope : typedecl.initializerscope;
fieldbinding previousfield = initializationscope.initializedfield;
int previousfieldid = initializationscope.lastvisiblefieldid;
try {
initializationscope.initializedfield = originalfield;
initializationscope.lastvisiblefieldid = originalfield.id;
astnode.resolveannotations(initializationscope, fielddecl.annotations, originalfield);
} finally {
initializationscope.initializedfield = previousfield;
initializationscope.lastvisiblefieldid = previousfieldid;
}
}
}
return originalfield.tagbits;
}

public final boolean isdefault() {
return !ispublic() && !isprotected() && !isprivate();
}
/* answer true if the receiver is a deprecated field
*/

/* answer true if the receiver has default visibility
*/

public final boolean isdeprecated() {
return (this.modifiers & classfileconstants.accdeprecated) != 0;
}
/* answer true if the receiver has private visibility
*/

public final boolean isprivate() {
return (this.modifiers & classfileconstants.accprivate) != 0;
}
/* answer true if the receiver has private visibility or is enclosed by a class that does.
*/

public final boolean isorenclosedbyprivatetype() {
if ((this.modifiers & classfileconstants.accprivate) != 0)
return true;
return this.declaringclass != null && this.declaringclass.isorenclosedbyprivatetype();
}
/* answer true if the receiver has private visibility and is used locally
*/

public final boolean isprotected() {
return (this.modifiers & classfileconstants.accprotected) != 0;
}
/* answer true if the receiver has public visibility
*/

public final boolean ispublic() {
return (this.modifiers & classfileconstants.accpublic) != 0;
}
/* answer true if the receiver is a static field
*/

public final boolean isstatic() {
return (this.modifiers & classfileconstants.accstatic) != 0;
}
/* answer true if the receiver is not defined in the source of the declaringclass
*/

public final boolean issynthetic() {
return (this.modifiers & classfileconstants.accsynthetic) != 0;
}
/* answer true if the receiver is a transient field
*/

public final boolean istransient() {
return (this.modifiers & classfileconstants.acctransient) != 0;
}
/* answer true if the receiver's declaring type is deprecated (or any of its enclosing types)
*/

public final boolean isused() {
return (this.modifiers & extracompilermodifiers.acclocallyused) != 0;
}
/* answer true if the receiver has protected visibility
*/

public final boolean isviewedasdeprecated() {
return (this.modifiers & (classfileconstants.accdeprecated | extracompilermodifiers.accdeprecatedimplicitly)) != 0;
}
/* answer true if the receiver is a volatile field
*/

public final boolean isvolatile() {
return (this.modifiers & classfileconstants.accvolatile) != 0;
}

public final int kind() {
return field;
}
/* answer true if the receiver is visible to the invocationpackage.
*/
/**
* returns the original field (as opposed to parameterized instances)
*/
public fieldbinding original() {
return this;
}
public void setannotations(annotationbinding[] annotations) {
this.declaringclass.storeannotations(this, annotations);
}
public fielddeclaration sourcefield() {
sourcetypebinding sourcetype;
try {
sourcetype = (sourcetypebinding) this.declaringclass;
} catch (classcastexception e) {
return null;
}

fielddeclaration[] fields = sourcetype.scope.referencecontext.fields;
if (fields != null) {
for (int i = fields.length; --i >= 0;)
if (this == fields[i].binding)
return fields[i];
}
return null;
}
}
