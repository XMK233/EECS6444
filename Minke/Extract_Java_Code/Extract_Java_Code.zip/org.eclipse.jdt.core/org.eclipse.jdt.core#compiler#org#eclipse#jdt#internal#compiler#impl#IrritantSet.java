/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/

package org.eclipse.jdt.internal.compiler.impl;

import org.eclipse.jdt.internal.compiler.ast.astnode;

/**
* represent a set of irritant flags. irritants are organized in up to 8 group
* of 29, allowing for a maximum of 232 distinct irritants.
*/
public class irritantset {

// reserve two high bits for selecting the right bit pattern
public final static int group_mask = astnode.bit32 | astnode.bit31 | astnode.bit30;
public final static int group_shift = 29;
public final static int group_max = 3; // can be increased up to 8

// group prefix for irritants
public final static int group0 = 0 << group_shift;
public final static int group1 = 1 << group_shift;
public final static int group2 = 2 << group_shift;
// reveal subsequent groups as needed
// public final static int group3 = 3 << group_shift;
// public final static int group4 = 4 << group_shift;
// public final static int group5 = 5 << group_shift;
// public final static int group6 = 6 << group_shift;
// public final static int group7 = 7 << group_shift;

// predefine sets of irritants matching warning tokens
public static final irritantset all = new irritantset(0xffffffff & ~group_mask);
public static final irritantset boxing = new irritantset(compileroptions.autoboxing);
public static final irritantset cast = new irritantset(compileroptions.unnecessarytypecheck);
public static final irritantset deprecation = new irritantset(compileroptions.usingdeprecatedapi);
public static final irritantset dep_ann = new irritantset(compileroptions.missingdeprecatedannotation);
public static final irritantset fallthrough = new irritantset(compileroptions.fallthroughcase);
public static final irritantset finally = new irritantset(compileroptions.finallyblocknotcompleting);
public static final irritantset hiding = new irritantset(compileroptions.maskedcatchblock);
public static final irritantset incomplete_switch = new irritantset(compileroptions.incompleteenumswitch);
public static final irritantset nls = new irritantset(compileroptions.nonexternalizedstring);
public static final irritantset null = new irritantset(compileroptions.nullreference);
public static final irritantset raw = new irritantset(compileroptions.rawtypereference);
public static final irritantset restriction = new irritantset(compileroptions.forbiddenreference);
public static final irritantset serial = new irritantset(compileroptions.missingserialversion);
public static final irritantset static_access = new irritantset(compileroptions.indirectstaticaccess);
public static final irritantset synthetic_access = new irritantset(compileroptions.accessemulation);
public static final irritantset super = new irritantset(compileroptions.overridingmethodwithoutsuperinvocation);
public static final irritantset unused = new irritantset(compileroptions.unusedlocalvariable);
public static final irritantset unchecked = new irritantset(compileroptions.uncheckedtypeoperation);
public static final irritantset unqualified_field_access = new irritantset(compileroptions.unqualifiedfieldaccess);

public static final irritantset compiler_default_errors = new irritantset(0); // no optional error by default
public static final irritantset compiler_default_warnings = new irritantset(0); // see static initializer below
static {
compiler_default_warnings
// group-0 warnings enabled by default
.set(
compileroptions.methodwithconstructorname
| compileroptions.overriddenpackagedefaultmethod
| compileroptions.usingdeprecatedapi
| compileroptions.maskedcatchblock
| compileroptions.unusedlocalvariable
| compileroptions.noimplicitstringconversion
| compileroptions.assertusedasanidentifier
| compileroptions.unusedimport
| compileroptions.nonstaticaccesstostatic
| compileroptions.noeffectassignment
| compileroptions.incompatiblenoninheritedinterfacemethod
| compileroptions.unusedprivatemember
| compileroptions.finallyblocknotcompleting)
// group-1 warnings enabled by default
.set(
compileroptions.uncheckedtypeoperation
| compileroptions.finalparameterbound
| compileroptions.missingserialversion
| compileroptions.enumusedasanidentifier
| compileroptions.forbiddenreference
| compileroptions.varargsargumentneedcast
| compileroptions.nullreference
| compileroptions.annotationsuperinterface
| compileroptions.typehiding
| compileroptions.discouragedreference
| compileroptions.unhandledwarningtoken
| compileroptions.rawtypereference
| compileroptions.unusedlabel
| compileroptions.unusedtypearguments
| compileroptions.unusedwarningtoken
| compileroptions.comparingidentical)
// group-2 warnings enabled by default
.set(
compileroptions.deadcode
|compileroptions.tasks);

all.setall();
hiding
.set(compileroptions.fieldhiding)
.set(compileroptions.localvariablehiding)
.set(compileroptions.typehiding);
null
.set(compileroptions.potentialnullreference)
.set(compileroptions.redundantnullcheck);
restriction.set(compileroptions.discouragedreference);
static_access.set(compileroptions.nonstaticaccesstostatic);
unused
.set(compileroptions.unusedargument)
.set(compileroptions.unusedprivatemember)
.set(compileroptions.unuseddeclaredthrownexception)
.set(compileroptions.unusedlabel)
.set(compileroptions.unusedimport)
.set(compileroptions.unusedtypearguments)
.set(compileroptions.redundantsuperinterface)
.set(compileroptions.deadcode)
.set(compileroptions.unusedobjectallocation);
string suppressrawwhenunchecked = system.getproperty("suppressrawwhenunchecked"); //$non-nls-1$
if (suppressrawwhenunchecked != null && "true".equalsignorecase(suppressrawwhenunchecked)) { //$non-nls-1$
unchecked.set(compileroptions.rawtypereference);
}
}

// internal state
private int[] bits = new int[group_max];

/**
* constructor with initial irritant set
*/
public irritantset(int singlegroupirritants) {
initialize(singlegroupirritants);
}

/**
* constructor with initial irritant set
*/
public irritantset(irritantset other) {
initialize(other);
}

public boolean areallset() {
for (int i = 0; i < group_max; i++) {
if (this.bits[i] != (0xffffffff & ~group_mask))
return false;
}
return true;
}

public irritantset clear(int singlegroupirritants) {
int group = (singlegroupirritants & group_mask) >> group_shift;
this.bits[group] &= ~singlegroupirritants;
return this;
}

public irritantset clearall() {
for (int i = 0; i < group_max; i++) {
this.bits[i] = 0;
}
return this;
}

/**
* initialize a set of irritants in one group
*
* @@param singlegroupirritants
*/
public void initialize(int singlegroupirritants) {
if (singlegroupirritants == 0)
return;
int group = (singlegroupirritants & group_mask) >> group_shift;
this.bits[group] = singlegroupirritants & ~group_mask; // erase group information
}

public void initialize(irritantset other) {
if (other == null)
return;
system.arraycopy(other.bits, 0, this.bits = new int[group_max], 0, group_max);
}

/**
* returns true if any of the irritants in given other set is positionned in receiver
* @@param other
*/
public boolean isanyset(irritantset other) {
if (other == null)
return false;
for (int i = 0; i < group_max; i++) {
if ((this.bits[i] & other.bits[i]) != 0)
return true;
}
return false;
}

/**
* returns true if all of the irritants in the given irritant set are set in receiver
* @@param irritantset the given irritant set
*/
public boolean hassameirritants(irritantset irritantset) {
if (irritantset == null)
return false;
for (int i = 0; i < group_max; i++) {
if (this.bits[i] != irritantset.bits[i])
return false;
}
return true;
}

public boolean isset(int singlegroupirritants) {
int group = (singlegroupirritants & group_mask) >> group_shift;
return (this.bits[group] & singlegroupirritants) != 0;
}

public irritantset set(int singlegroupirritants) {
int group = (singlegroupirritants & group_mask) >> group_shift;
this.bits[group] |= (singlegroupirritants & ~group_mask); // erase the group bits
return this;
}

/**
* return updated irritantset or null if it was a no-op
*
* @@param other
*/
public irritantset set(irritantset other) {
if (other == null)
return this;
boolean wasnoop = true;
for (int i = 0; i < group_max; i++) {
int otherirritant = other.bits[i] & ~group_mask; // erase the
// group
// bits
if ((this.bits[i] & otherirritant) != otherirritant) {
wasnoop = false;
this.bits[i] |= otherirritant;
}
}
return wasnoop ? null : this;
}

public irritantset setall() {
for (int i = 0; i < group_max; i++) {
this.bits[i] |= 0xffffffff & ~group_mask; // erase the group
// bits;
}
return this;
}
}
