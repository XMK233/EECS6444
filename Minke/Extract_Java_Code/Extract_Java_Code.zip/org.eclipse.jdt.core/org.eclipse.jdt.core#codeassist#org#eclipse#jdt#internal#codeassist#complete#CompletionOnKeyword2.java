/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.ast.importreference;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;

public class completiononkeyword2 extends importreference implements completiononkeyword {
private char[] token;
private char[][] possiblekeywords;
public completiononkeyword2(char[] token, long pos, char[][] possiblekeywords) {
super(new char[][]{token}, new long[]{pos}, false, classfileconstants.accdefault);
this.token = token;
this.possiblekeywords = possiblekeywords;
}
public boolean cancompleteemptytoken() {
return false;
}
public char[] gettoken() {
return this.token;
}
public char[][] getpossiblekeywords() {
return this.possiblekeywords;
}
public stringbuffer print(int indent, stringbuffer output, boolean withondemand) {

return printindent(indent, output).append("<completeonkeyword:").append(this.token).append('>'); //$non-nls-1$
}
}
