/*******************************************************************************
* copyright (c) 2005, 2007 bea systems, inc.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*    tyeung@@bea.com - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

import org.eclipse.jdt.internal.compiler.env.ibinaryannotation;

public class methodinfowithannotations extends methodinfo {
protected annotationinfo[] annotations;

methodinfowithannotations(methodinfo methodinfo, annotationinfo[] annotations) {
super(methodinfo.reference, methodinfo.constantpooloffsets, methodinfo.structoffset);
this.annotations = annotations;

this.accessflags = methodinfo.accessflags;
this.attributebytes = methodinfo.attributebytes;
this.descriptor = methodinfo.descriptor;
this.exceptionnames = methodinfo.exceptionnames;
this.name = methodinfo.name;
this.signature = methodinfo.signature;
this.signatureutf8offset = methodinfo.signatureutf8offset;
this.tagbits = methodinfo.tagbits;
}
public ibinaryannotation[] getannotations() {
return this.annotations;
}
protected void initialize() {
for (int i = 0, l = this.annotations == null ? 0 : this.annotations.length; i < l; i++)
if (this.annotations[i] != null)
this.annotations[i].initialize();
super.initialize();
}
protected void reset() {
for (int i = 0, l = this.annotations == null ? 0 : this.annotations.length; i < l; i++)
if (this.annotations[i] != null)
this.annotations[i].reset();
super.reset();
}
protected void tostringcontent(stringbuffer buffer) {
super.tostringcontent(buffer);
for (int i = 0, l = this.annotations == null ? 0 : this.annotations.length; i < l; i++) {
buffer.append(this.annotations[i]);
buffer.append('\n');
}
}
}
