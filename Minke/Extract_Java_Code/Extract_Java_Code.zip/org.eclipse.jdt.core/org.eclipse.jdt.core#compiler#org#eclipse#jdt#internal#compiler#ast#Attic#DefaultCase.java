/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class defaultcase extends statement {

public caselabel targetlabel;
/**
* defautcase constructor comment.
*/
public defaultcase(int sourceend, int sourcestart) {

this.sourcestart = sourcestart;
this.sourceend = sourceend;
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {

return flowinfo;
}

/**
* default case code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {

if ((bits & isreachablemask) == 0) {
return;
}
int pc = codestream.position;
targetlabel.place();
codestream.recordpositionsfrom(pc, this.sourcestart);

}
/**
* no-op : should use resolvecase(...) instead.
*/
public void resolve(blockscope scope) {
}

public constant resolvecase(
blockscope scope,
typebinding testtype,
switchstatement switchstatement) {

// remember the default case into the associated switch statement
if (switchstatement.defaultcase != null)
scope.problemreporter().duplicatedefaultcase(this);

// on error the last default will be the selected one .... (why not) ....
switchstatement.defaultcase = this;
resolve(scope);
return null;
}

public string tostring(int tab) {

string s = tabstring(tab);
s = s + "default : "; //$non-nls-1$
return s;
}

public void traverse(
iabstractsyntaxtreevisitor visitor,
blockscope blockscope) {

visitor.visit(this, blockscope);
visitor.endvisit(this, blockscope);
}
}
