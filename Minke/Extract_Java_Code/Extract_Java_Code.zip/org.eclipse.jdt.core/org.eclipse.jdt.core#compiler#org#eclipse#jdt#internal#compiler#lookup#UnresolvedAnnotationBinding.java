/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

public class unresolvedannotationbinding extends annotationbinding {
private lookupenvironment env;
private boolean typeunresolved = true;

unresolvedannotationbinding(referencebinding type, elementvaluepair[] pairs, lookupenvironment env) {
super(type, pairs);
this.env = env;
}

public referencebinding getannotationtype() {
if (this.typeunresolved) { // the type is resolved when requested
this.type = (referencebinding) binarytypebinding.resolvetype(this.type, this.env, false /* no raw conversion for now */);
// annotation type are never parameterized
this.typeunresolved = false;
}
return this.type;
}

public elementvaluepair[] getelementvaluepairs() {
if (this.env != null) {
if (this.typeunresolved) {
getannotationtype(); // resolve the annotation type
}
// resolve method binding and value type (if unresolved) for each pair
for (int i = this.pairs.length; --i >= 0;) {
elementvaluepair pair = this.pairs[i];
methodbinding[] methods = this.type.getmethods(pair.getname());
// there should be exactly one since the type is an annotation type.
if (methods != null && methods.length == 1) {
pair.setmethodbinding(methods[0]);
} // else silently leave a null there
object value = pair.getvalue();
if (value instanceof unresolvedreferencebinding) {
pair.setvalue(((unresolvedreferencebinding) value).
resolve(this.env, false));
// no parameterized types in annotation values
} // do nothing for unresolvedannotationbinding-s, since their
// content is only accessed through get* methods
}
this.env = null;
}
return this.pairs;
}
}
