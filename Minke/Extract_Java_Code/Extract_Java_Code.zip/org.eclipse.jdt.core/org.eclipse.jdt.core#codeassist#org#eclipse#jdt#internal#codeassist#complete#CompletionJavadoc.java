/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

/**
* node representing a javadoc comment including code selection.
*/
public class completionjavadoc extends javadoc {

expression completionnode;

public completionjavadoc(int sourcestart, int sourceend) {
super(sourcestart, sourceend);
}

/**
* @@return returns the completionnode.
*/
public expression getcompletionnode() {
return this.completionnode;
}

/**
* resolve selected node if not null and throw exception to let clients know
* that it has been found.
*
* @@throws completionnodefound
*/
private void internalresolve(scope scope) {
if (this.completionnode != null) {
if (this.completionnode instanceof completiononjavadoctag) {
((completiononjavadoctag)this.completionnode).filterpossibletags(scope);
} else {
boolean resolve = true;
if (this.completionnode instanceof completiononjavadocparamnamereference) {
resolve = ((completiononjavadocparamnamereference)this.completionnode).token != null;
} else if (this.completionnode instanceof completiononjavadoctypeparamreference) {
resolve = ((completiononjavadoctypeparamreference)this.completionnode).token != null;
}
if (resolve) {
switch (scope.kind) {
case scope.class_scope:
this.completionnode.resolvetype((classscope)scope);
break;
case scope.method_scope:
this.completionnode.resolvetype((methodscope) scope);
break;
}
}
if (this.completionnode instanceof completiononjavadocparamnamereference) {
completiononjavadocparamnamereference paramnamereference = (completiononjavadocparamnamereference) this.completionnode;
if (scope.kind == scope.method_scope) {
paramnamereference.missingparams = missingparamtags(paramnamereference.binding, (methodscope)scope);
}
if (paramnamereference.token == null || paramnamereference.token.length == 0) {
paramnamereference.missingtypeparams = missingtypeparametertags(paramnamereference.binding, scope);
}
} else if (this.completionnode instanceof completiononjavadoctypeparamreference) {
completiononjavadoctypeparamreference typeparamreference = (completiononjavadoctypeparamreference) this.completionnode;
typeparamreference.missingparams = missingtypeparametertags(typeparamreference.resolvedtype, scope);
}
}
binding qualifiedbinding = null;
if (this.completionnode instanceof completiononjavadocqualifiedtypereference) {
completiononjavadocqualifiedtypereference typeref = (completiononjavadocqualifiedtypereference) this.completionnode;
if (typeref.packagebinding == null) {
qualifiedbinding = typeref.resolvedtype;
} else {
qualifiedbinding = typeref.packagebinding;
}
} else if (this.completionnode instanceof completiononjavadocmessagesend) {
completiononjavadocmessagesend msg = (completiononjavadocmessagesend) this.completionnode;
if (!msg.receiver.isthis()) qualifiedbinding = msg.receiver.resolvedtype;
} else if (this.completionnode instanceof completiononjavadocallocationexpression) {
completiononjavadocallocationexpression alloc = (completiononjavadocallocationexpression) this.completionnode;
qualifiedbinding = alloc.type.resolvedtype;
}
throw new completionnodefound(this.completionnode, qualifiedbinding, scope);
}
}

/*
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#print(int, java.lang.stringbuffer)
*/
public stringbuffer print(int indent, stringbuffer output) {
printindent(indent, output).append("/**\n"); //$non-nls-1$
boolean nodeprinted = false;
if (this.paramreferences != null) {
for (int i = 0, length = this.paramreferences.length; i < length; i++) {
printindent(indent, output).append(" * @@param "); //$non-nls-1$
this.paramreferences[i].print(indent, output).append('\n');
if (!nodeprinted && this.completionnode != null) {
nodeprinted =  this.completionnode == this.paramreferences[i];
}
}
}
if (this.paramtypeparameters != null) {
for (int i = 0, length = this.paramtypeparameters.length; i < length; i++) {
printindent(indent, output).append(" * @@param <"); //$non-nls-1$
this.paramtypeparameters[i].print(indent, output).append(">\n"); //$non-nls-1$
if (!nodeprinted && this.completionnode != null) {
nodeprinted =  this.completionnode == this.paramtypeparameters[i];
}
}
}
if (this.returnstatement != null) {
printindent(indent, output).append(" * @@"); //$non-nls-1$
this.returnstatement.print(indent, output).append('\n');
}
if (this.exceptionreferences != null) {
for (int i = 0, length = this.exceptionreferences.length; i < length; i++) {
printindent(indent, output).append(" * @@throws "); //$non-nls-1$
this.exceptionreferences[i].print(indent, output).append('\n');
if (!nodeprinted && this.completionnode != null) {
nodeprinted =  this.completionnode == this.exceptionreferences[i];
}
}
}
if (this.seereferences != null) {
for (int i = 0, length = this.seereferences.length; i < length; i++) {
printindent(indent, output).append(" * @@see "); //$non-nls-1$
this.seereferences[i].print(indent, output).append('\n');
if (!nodeprinted && this.completionnode != null) {
nodeprinted =  this.completionnode == this.seereferences[i];
}
}
}
if (!nodeprinted && this.completionnode != null) {
printindent(indent, output).append(" * "); //$non-nls-1$
this.completionnode.print(indent, output).append('\n');
}
printindent(indent, output).append(" */\n"); //$non-nls-1$
return output;
}

/**
* resolve completion node if not null and throw exception to let clients know
* that it has been found.
*
* @@throws completionnodefound
*/
public void resolve(classscope scope) {
super.resolve(scope);
internalresolve(scope);
}

/**
* resolve completion node if not null and throw exception to let clients know
* that it has been found.
*
* @@throws completionnodefound
*/
public void resolve(compilationunitscope scope) {
internalresolve(scope);
}

/**
* resolve completion node if not null and throw exception to let clients know
* that it has been found.
*
* @@throws completionnodefound
*/
public void resolve(methodscope scope) {
super.resolve(scope);
internalresolve(scope);
}

/*
* look for missing method @@param tags
*/
private char[][] missingparamtags(binding paramnamerefbinding, methodscope methscope) {

// verify if there's some possible param tag
abstractmethoddeclaration md = methscope.referencemethod();
int paramtagssize = this.paramreferences == null ? 0 : this.paramreferences.length;
if (md == null) return null;
int argumentssize = md.arguments == null ? 0 : md.arguments.length;
if (argumentssize == 0) return null;

// store all method arguments if there's no @@param in javadoc
if (paramtagssize == 0) {
char[][] missingparams = new char[argumentssize][];
for (int i = 0; i < argumentssize; i++) {
missingparams[i] = md.arguments[i].name;
}
return missingparams;
}

// look for missing arguments
char[][] missingparams = new char[argumentssize][];
int size = 0;
for (int i = 0; i < argumentssize; i++) {
argument arg = md.arguments[i];
boolean found = false;
int paramnamerefcount = 0;
for (int j = 0; j < paramtagssize && !found; j++) {
javadocsinglenamereference param = this.paramreferences[j];
if (arg.binding == param.binding) {
if (param.binding == paramnamerefbinding) { // do not count first occurence of param name reference
paramnamerefcount++;
found = paramnamerefcount > 1;
} else {
found = true;
}
}
}
if (!found) {
missingparams[size++] = arg.name;
}
}
if (size > 0) {
if (size != argumentssize) {
system.arraycopy(missingparams, 0, missingparams = new char[size][], 0, size);
}
return missingparams;
}
return null;
}

/*
* look for missing type parameters @@param tags
*/
private char[][] missingtypeparametertags(binding paramnamerefbinding, scope scope) {
int paramtypeparamlength = this.paramtypeparameters == null ? 0 : this.paramtypeparameters.length;

// verify if there's any type parameter to tag
typeparameter[] parameters =  null;
typevariablebinding[] typevariables = null;
switch (scope.kind) {
case scope.method_scope:
abstractmethoddeclaration methoddeclaration = ((methodscope)scope).referencemethod();
if (methoddeclaration == null) return null;
parameters = methoddeclaration.typeparameters();
typevariables = methoddeclaration.binding.typevariables;
break;
case scope.class_scope:
typedeclaration typedeclaration = ((classscope) scope).referencecontext;
parameters = typedeclaration.typeparameters;
typevariables = typedeclaration.binding.typevariables;
break;
}
if (typevariables == null || typevariables.length == 0) return null;

// store all type parameters if there's no @@param in javadoc
if (parameters != null) {
int typeparameterslength = parameters.length;
if (paramtypeparamlength == 0) {
char[][] missingparams = new char[typeparameterslength][];
for (int i = 0; i < typeparameterslength; i++) {
missingparams[i] = parameters[i].name;
}
return missingparams;
}

// look for missing type parameter
char[][] missingparams = new char[typeparameterslength][];
int size = 0;
for (int i = 0; i < typeparameterslength; i++) {
typeparameter parameter = parameters[i];
boolean found = false;
int paramnamerefcount = 0;
for (int j = 0; j < paramtypeparamlength && !found; j++) {
if (parameter.binding == this.paramtypeparameters[j].resolvedtype) {
if (parameter.binding == paramnamerefbinding) { // do not count first occurence of param nmae reference
paramnamerefcount++;
found = paramnamerefcount > 1;
} else {
found = true;
}
}
}
if (!found) {
missingparams[size++] = parameter.name;
}
}
if (size > 0) {
if (size != typeparameterslength) {
system.arraycopy(missingparams, 0, missingparams = new char[size][], 0, size);
}
return missingparams;
}
}
return null;
}
}
