/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfile;
import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.codegen.branchlabel;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.codegen.constantpool;
import org.eclipse.jdt.internal.compiler.codegen.opcodes;
import org.eclipse.jdt.internal.compiler.flow.exceptionhandlingflowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.flow.initializationflowcontext;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeconstants;
import org.eclipse.jdt.internal.compiler.parser.parser;
import org.eclipse.jdt.internal.compiler.problem.abortmethod;

public class clinit extends abstractmethoddeclaration {

private fieldbinding assertionsyntheticfieldbinding = null;
private fieldbinding classliteralsyntheticfield = null;

public clinit(compilationresult compilationresult) {
super(compilationresult);
this.modifiers = 0;
this.selector = typeconstants.clinit;
}

public void analysecode(
classscope classscope,
initializationflowcontext staticinitializerflowcontext,
flowinfo flowinfo) {

if (this.ignorefurtherinvestigation)
return;
try {
exceptionhandlingflowcontext clinitcontext =
new exceptionhandlingflowcontext(
staticinitializerflowcontext.parent,
this,
binding.no_exceptions,
staticinitializerflowcontext,
this.scope,
flowinfo.dead_end);

// check for missing returning path
if ((flowinfo.tagbits & flowinfo.unreachable) == 0) {
this.bits |= astnode.needfreereturn;
}

// check missing blank final field initializations
flowinfo = flowinfo.mergedwith(staticinitializerflowcontext.initsonreturn);
fieldbinding[] fields = this.scope.enclosingsourcetype().fields();
for (int i = 0, count = fields.length; i < count; i++) {
fieldbinding field;
if ((field = fields[i]).isstatic()
&& field.isfinal()
&& (!flowinfo.isdefinitelyassigned(fields[i]))) {
this.scope.problemreporter().uninitializedblankfinalfield(
field,
this.scope.referencetype().declarationof(field.original()));
// can complain against the field decl, since only one <clinit>
}
}
// check static initializers thrown exceptions
staticinitializerflowcontext.checkinitializerexceptions(
this.scope,
clinitcontext,
flowinfo);
} catch (abortmethod e) {
this.ignorefurtherinvestigation = true;
}
}

/**
* bytecode generation for a <clinit> method
*
* @@param classscope org.eclipse.jdt.internal.compiler.lookup.classscope
* @@param classfile org.eclipse.jdt.internal.compiler.codegen.classfile
*/
public void generatecode(classscope classscope, classfile classfile) {

int clinitoffset = 0;
if (this.ignorefurtherinvestigation) {
// should never have to add any <clinit> problem method
return;
}
try {
clinitoffset = classfile.contentsoffset;
this.generatecode(classscope, classfile, clinitoffset);
} catch (abortmethod e) {
// should never occur
// the clinit referencecontext is the type declaration
// all clinit problems will be reported against the type: aborttype instead of abortmethod
// reset the contentsoffset to the value before generating the clinit code
// decrement the number of method info as well.
// this is done in the addproblemmethod and addproblemconstructor for other
// cases.
if (e.compilationresult == codestream.restart_in_wide_mode) {
// a branch target required a goto_w, restart code gen in wide mode.
try {
classfile.contentsoffset = clinitoffset;
classfile.methodcount--;
classfile.codestream.resetinwidemode(); // request wide mode
this.generatecode(classscope, classfile, clinitoffset);
// restart method generation
} catch (abortmethod e2) {
classfile.contentsoffset = clinitoffset;
classfile.methodcount--;
}
} else {
// produce a problem method accounting for this fatal error
classfile.contentsoffset = clinitoffset;
classfile.methodcount--;
}
}
}

/**
* bytecode generation for a <clinit> method
*
* @@param classscope org.eclipse.jdt.internal.compiler.lookup.classscope
* @@param classfile org.eclipse.jdt.internal.compiler.codegen.classfile
*/
private void generatecode(
classscope classscope,
classfile classfile,
int clinitoffset) {

constantpool constantpool = classfile.constantpool;
int constantpooloffset = constantpool.currentoffset;
int constantpoolindex = constantpool.currentindex;
classfile.generatemethodinfoheaderforclinit();
int codeattributeoffset = classfile.contentsoffset;
classfile.generatecodeattributeheader();
codestream codestream = classfile.codestream;
resolve(classscope);

codestream.reset(this, classfile);
typedeclaration declaringtype = classscope.referencecontext;

// initialize local positions - including initializer scope.
methodscope staticinitializerscope = declaringtype.staticinitializerscope;
staticinitializerscope.computelocalvariablepositions(0, codestream);

// 1.4 feature
// this has to be done before any other initialization
if (this.assertionsyntheticfieldbinding != null) {
// generate code related to the activation of assertion for this class
codestream.generateclassliteralaccessfortype(
classscope.outermostclassscope().enclosingsourcetype(),
this.classliteralsyntheticfield);
codestream.invokejavalangclassdesiredassertionstatus();
branchlabel falselabel = new branchlabel(codestream);
codestream.ifne(falselabel);
codestream.iconst_1();
branchlabel jumplabel = new branchlabel(codestream);
codestream.decrstacksize(1);
codestream.goto_(jumplabel);
falselabel.place();
codestream.iconst_0();
jumplabel.place();
codestream.fieldaccess(opcodes.opc_putstatic, this.assertionsyntheticfieldbinding, null /* default declaringclass */);
}
// generate static fields/initializers/enum constants
final fielddeclaration[] fielddeclarations = declaringtype.fields;
blockscope lastinitializerscope = null;
if (typedeclaration.kind(declaringtype.modifiers) == typedeclaration.enum_decl) {
int enumcount = 0;
int remainingfieldcount = 0;
if (fielddeclarations != null) {
for (int i = 0, max = fielddeclarations.length; i < max; i++) {
fielddeclaration fielddecl = fielddeclarations[i];
if (fielddecl.isstatic()) {
if (fielddecl.getkind() == abstractvariabledeclaration.enum_constant) {
fielddecl.generatecode(staticinitializerscope, codestream);
enumcount++;
} else {
remainingfieldcount++;
}
}
}
}
// enum need to initialize $values synthetic cache of enum constants
// $values := new <enumtype>[<enumcount>]
codestream.generateinlinedvalue(enumcount);
codestream.anewarray(declaringtype.binding);
if (enumcount > 0) {
if (fielddeclarations != null) {
for (int i = 0, max = fielddeclarations.length; i < max; i++) {
fielddeclaration fielddecl = fielddeclarations[i];
// $values[i] = <enum-constant-i>
if (fielddecl.getkind() == abstractvariabledeclaration.enum_constant) {
codestream.dup();
codestream.generateinlinedvalue(fielddecl.binding.id);
codestream.fieldaccess(opcodes.opc_getstatic, fielddecl.binding, null /* default declaringclass */);
codestream.aastore();
}
}
}
}
codestream.fieldaccess(opcodes.opc_putstatic, declaringtype.enumvaluessyntheticfield, null /* default declaringclass */);
if (remainingfieldcount != 0) {
// if fields that are not enum constants need to be generated (static initializer/static field)
for (int i = 0, max = fielddeclarations.length; i < max; i++) {
fielddeclaration fielddecl = fielddeclarations[i];
switch (fielddecl.getkind()) {
case abstractvariabledeclaration.enum_constant :
break;
case abstractvariabledeclaration.initializer :
if (!fielddecl.isstatic())
break;
lastinitializerscope = ((initializer) fielddecl).block.scope;
fielddecl.generatecode(staticinitializerscope, codestream);
break;
case abstractvariabledeclaration.field :
if (!fielddecl.binding.isstatic())
break;
lastinitializerscope = null;
fielddecl.generatecode(staticinitializerscope, codestream);
break;
}
}
}
} else {
if (fielddeclarations != null) {
for (int i = 0, max = fielddeclarations.length; i < max; i++) {
fielddeclaration fielddecl = fielddeclarations[i];
switch (fielddecl.getkind()) {
case abstractvariabledeclaration.initializer :
if (!fielddecl.isstatic())
break;
lastinitializerscope = ((initializer) fielddecl).block.scope;
fielddecl.generatecode(staticinitializerscope, codestream);
break;
case abstractvariabledeclaration.field :
if (!fielddecl.binding.isstatic())
break;
lastinitializerscope = null;
fielddecl.generatecode(staticinitializerscope, codestream);
break;
}
}
}
}

if (codestream.position == 0) {
// do not need to output a clinit if no bytecodes
// so we reset the offset inside the byte array contents.
classfile.contentsoffset = clinitoffset;
// like we don't addd a method we need to undo the increment on the method count
classfile.methodcount--;
// reset the constant pool to its state before the clinit
constantpool.resetforclinit(constantpoolindex, constantpooloffset);
} else {
if ((this.bits & astnode.needfreereturn) != 0) {
int before = codestream.position;
codestream.return_();
if (lastinitializerscope != null) {
// expand the last initializer variables to include the trailing return
codestream.updatelastrecordedendpc(lastinitializerscope, before);
}
}
// record the end of the clinit: point to the declaration of the class
codestream.recordpositionsfrom(0, declaringtype.sourcestart);
try {
classfile.completecodeattributeforclinit(codeattributeoffset);
} catch(negativearraysizeexception e) {
throw new abortmethod(this.scope.referencecompilationunit().compilationresult, null);
}
}
}

public boolean isclinit() {

return true;
}

public boolean isinitializationmethod() {

return true;
}

public boolean isstatic() {

return true;
}

public void parsestatements(parser parser, compilationunitdeclaration unit) {
//the clinit is filled by hand ....
}

public stringbuffer print(int tab, stringbuffer output) {

printindent(tab, output).append("<clinit>()"); //$non-nls-1$
printbody(tab + 1, output);
return output;
}

public void resolve(classscope classscope) {

this.scope = new methodscope(classscope, classscope.referencecontext, true);
}

public void traverse(
astvisitor visitor,
classscope classscope) {

visitor.visit(this, classscope);
visitor.endvisit(this, classscope);
}

public void setassertionsupport(fieldbinding assertionsyntheticfieldbinding, boolean needclassliteralfield) {

this.assertionsyntheticfieldbinding = assertionsyntheticfieldbinding;

// we need to add the field right now, because the field infos are generated before the methods
if (needclassliteralfield) {
sourcetypebinding sourcetype =
this.scope.outermostclassscope().enclosingsourcetype();
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=22334
if (!sourcetype.isinterface() && !sourcetype.isbasetype()) {
this.classliteralsyntheticfield = sourcetype.addsyntheticfieldforclassliteral(sourcetype, this.scope);
}
}
}

}
