/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.impl;

public class byteconstant extends constant {

private byte value;

public static constant fromvalue(byte value) {
return new byteconstant(value);
}

private byteconstant(byte value) {
this.value = value;
}

public byte bytevalue() {
return this.value;
}

public char charvalue() {
return (char) this.value;
}

public double doublevalue() {
return this.value; // implicit cast to return type
}

public float floatvalue() {
return this.value; // implicit cast to return type
}

public int intvalue() {
return this.value; // implicit cast to return type
}

public long longvalue() {
return this.value; // implicit cast to return type
}

public short shortvalue() {
return this.value; // implicit cast to return type
}

public string stringvalue() {
// spec 15.17.11
return string.valueof(this.value);
}

public string tostring() {
return "(byte)" + this.value; //$non-nls-1$
}

public int typeid() {
return t_byte;
}
}
