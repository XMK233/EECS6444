/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

/**
* pseudo method binding used to wrapper a real method, and expose less exceptions than original.
* for other protocols, it should delegate to original method
*/
public class mostspecificexceptionmethodbinding  extends methodbinding {

private methodbinding originalmethod;

public mostspecificexceptionmethodbinding (methodbinding originalmethod, referencebinding[] mostspecificexceptions) {
super(
originalmethod.modifiers,
originalmethod.selector,
originalmethod.returntype,
originalmethod.parameters,
mostspecificexceptions,
originalmethod.declaringclass);
this.originalmethod = originalmethod;
}

public methodbinding original() {
return this.originalmethod.original();
}
}
