/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     tom tromey - patch for readtable(string) as described in http://bugs.eclipse.org/bugs/show_bug.cgi?id=32196
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser;

import java.io.*;
import java.util.arraylist;
import java.util.collections;
import java.util.iterator;
import java.util.list;
import java.util.locale;
import java.util.missingresourceexception;
import java.util.resourcebundle;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.invalidinputexception;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.env.icompilationunit;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.referencecontext;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.extracompilermodifiers;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.parser.diagnose.diagnoseparser;
import org.eclipse.jdt.internal.compiler.problem.abortcompilation;
import org.eclipse.jdt.internal.compiler.problem.abortcompilationunit;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;
import org.eclipse.jdt.internal.compiler.util.messages;
import org.eclipse.jdt.internal.compiler.util.util;

public class parser implements  parserbasicinformation, terminaltokens, operatorids, typeids {

protected static final int this_call = explicitconstructorcall.this;
protected static final int super_call = explicitconstructorcall.super;
public static final char[] fall_through_tag = "$fall-through$".tochararray(); //$non-nls-1$

public static char asb[] = null;
public static char asr[] = null;
//ast stack
protected final static int aststackincrement = 100;
public static char base_action[] = null;
public static final int bracketkinds = 3;

public static short check_table[] = null;
public static final int curlybracket = 2;
private static final boolean debug = false;
private static final boolean debug_automaton = false;
private static final string eof_token = "$eof" ; //$non-nls-1$
private static final string error_token = "$error" ; //$non-nls-1$
//expression stack
protected final static int expressionstackincrement = 100;

protected final static int genericsstackincrement = 10;

private final static string fileprefix = "parser"; //$non-nls-1$
public static char in_symb[] = null;
private static final string invalid_character = "invalid character" ; //$non-nls-1$
public static char lhs[] =  null;

public static string name[] = null;
public static char nasb[] = null;
public static char nasr[] = null;
public static char non_terminal_index[] = null;
private final static string readable_names_file = "readablenames"; //$non-nls-1$
private final static string readable_names_file_name =
"org.eclipse.jdt.internal.compiler.parser." + readable_names_file; //$non-nls-1$
public static string readablename[] = null;

public static byte rhs[] = null;

public static int[] reverse_index = null;
public static char[] recovery_templates_index = null;
public static char[] recovery_templates = null;
public static char[] statements_recovery_filter = null;

public static long rules_compliance[] =  null;

public static final int roundbracket = 0;

public static byte scope_la[] = null;
public static char scope_lhs[] = null;

public static char scope_prefix[] = null;
public static char scope_rhs[] = null;
public static char scope_state[] = null;

public static char scope_state_set[] = null;
public static char scope_suffix[] = null;
public static final int squarebracket = 1;

//internal data for the automat
protected final static int stackincrement = 255;

public static char term_action[] = null;
public static byte term_check[] = null;

public static char terminal_index[] = null;

private static final string unexpected_eof = "unexpected end of file" ; //$non-nls-1$
public static boolean verbose_recovery = false;

static {
try{
inittables();
} catch(java.io.ioexception ex){
throw new exceptionininitializererror(ex.getmessage());
}
}
public static int asi(int state) {

return asb[original_state(state)];
}
public final static short base_check(int i) {
return check_table[i - (num_rules + 1)];
}
private final static void buildfile(string filename, list listtodump) {
bufferedwriter writer = null;
try {
writer = new bufferedwriter(new filewriter(filename));
for (iterator iterator = listtodump.iterator(); iterator.hasnext(); ) {
writer.write(string.valueof(iterator.next()));
}
writer.flush();
} catch(ioexception e) {
// ignore
} finally {
if (writer != null) {
try {
writer.close();
} catch (ioexception e1) {
// ignore
}
}
}
system.out.println(filename + " creation complete"); //$non-nls-1$
}
private static void buildfileforcompliance(
string file,
int length,
string[] tokens) {

byte[] result = new byte[length * 8];

for (int i = 0; i < tokens.length; i = i + 3) {
if("2".equals(tokens[i])) { //$non-nls-1$
int index = integer.parseint(tokens[i + 1]);
string token = tokens[i + 2].trim();
long compliance = 0;
if("1.4".equals(token)) { //$non-nls-1$
compliance = classfileconstants.jdk1_4;
} else if("1.5".equals(token)) { //$non-nls-1$
compliance = classfileconstants.jdk1_5;
} else if("recovery".equals(token)) { //$non-nls-1$
compliance = classfileconstants.jdk_deferred;
}

int j = index * 8;
result[j] = 	(byte)(compliance >>> 56);
result[j + 1] = (byte)(compliance >>> 48);
result[j + 2] = (byte)(compliance >>> 40);
result[j + 3] = (byte)(compliance >>> 32);
result[j + 4] = (byte)(compliance >>> 24);
result[j + 5] = (byte)(compliance >>> 16);
result[j + 6] = (byte)(compliance >>> 8);
result[j + 7] = (byte)(compliance);
}
}

buildfilefortable(file, result);
}
private final static string[] buildfileforname(string filename, string contents) {
string[] result = new string[contents.length()];
result[0] = null;
int resultcount = 1;

stringbuffer buffer = new stringbuffer();

int start = contents.indexof("name[]"); //$non-nls-1$
start = contents.indexof('\"', start);
int end = contents.indexof("};", start); //$non-nls-1$

contents = contents.substring(start, end);

boolean addlineseparator = false;
int tokenstart = -1;
stringbuffer currenttoken = new stringbuffer();
for (int i = 0; i < contents.length(); i++) {
char c = contents.charat(i);
if(c == '\"') {
if(tokenstart == -1) {
tokenstart = i + 1;
} else {
if(addlineseparator) {
buffer.append('\n');
result[resultcount++] = currenttoken.tostring();
currenttoken = new stringbuffer();
}
string token = contents.substring(tokenstart, i);
if(token.equals(error_token)){
token = invalid_character;
} else if(token.equals(eof_token)) {
token = unexpected_eof;
}
buffer.append(token);
currenttoken.append(token);
addlineseparator = true;
tokenstart = -1;
}
}
if(tokenstart == -1 && c == '+'){
addlineseparator = false;
}
}
if(currenttoken.length() > 0) {
result[resultcount++] = currenttoken.tostring();
}

buildfilefortable(filename, buffer.tostring().tochararray());

system.arraycopy(result, 0, result = new string[resultcount], 0, resultcount);
return result;
}
private static void buildfileforreadablename(
string file,
char[] newlhs,
char[] newnonterminalindex,
string[] newname,
string[] tokens) {

arraylist entries = new arraylist();

boolean[] alreadyadded = new boolean[newname.length];

for (int i = 0; i < tokens.length; i = i + 3) {
if("1".equals(tokens[i])) { //$non-nls-1$
int index = newnonterminalindex[newlhs[integer.parseint(tokens[i + 1])]];
stringbuffer buffer = new stringbuffer();
if(!alreadyadded[index]) {
alreadyadded[index] = true;
buffer.append(newname[index]);
buffer.append('=');
buffer.append(tokens[i+2].trim());
buffer.append('\n');
entries.add(string.valueof(buffer));
}
}
}
int i = 1;
while(!invalid_character.equals(newname[i])) i++;
i++;
for (; i < alreadyadded.length; i++) {
if(!alreadyadded[i]) {
system.out.println(newname[i] + " has no readable name"); //$non-nls-1$
}
}
collections.sort(entries);
buildfile(file, entries);
}
private final static void buildfilefortable(string filename, byte[] bytes) {
java.io.fileoutputstream stream = null;
try {
stream = new java.io.fileoutputstream(filename);
stream.write(bytes);
} catch(ioexception e) {
// ignore
} finally {
if (stream != null) {
try {
stream.close();
} catch (ioexception e) {
// ignore
}
}
}
system.out.println(filename + " creation complete"); //$non-nls-1$
}
private final static void buildfilefortable(string filename, char[] chars) {
byte[] bytes = new byte[chars.length * 2];
for (int i = 0; i < chars.length; i++) {
bytes[2 * i] = (byte) (chars[i] >>> 8);
bytes[2 * i + 1] = (byte) (chars[i] & 0xff);
}

java.io.fileoutputstream stream = null;
try {
stream = new java.io.fileoutputstream(filename);
stream.write(bytes);
} catch(ioexception e) {
// ignore
} finally {
if (stream != null) {
try {
stream.close();
} catch (ioexception e) {
// ignore
}
}
}
system.out.println(filename + " creation complete"); //$non-nls-1$
}
private final static byte[] buildfileofbytefor(string filename, string tag, string[] tokens) {

//transform the string tokens into chars before dumping then into file

int i = 0;
//read upto the tag
while (!tokens[i++].equals(tag)){/*empty*/}
//read upto the }

byte[] bytes = new byte[tokens.length]; //can't be bigger
int ic = 0;
string token;
while (!(token = tokens[i++]).equals("}")) { //$non-nls-1$
int c = integer.parseint(token);
bytes[ic++] = (byte) c;
}

//resize
system.arraycopy(bytes, 0, bytes = new byte[ic], 0, ic);

buildfilefortable(filename, bytes);
return bytes;
}
private final static char[] buildfileofintfor(string filename, string tag, string[] tokens) {

//transform the string tokens into chars before dumping then into file

int i = 0;
//read upto the tag
while (!tokens[i++].equals(tag)){/*empty*/}
//read upto the }

char[] chars = new char[tokens.length]; //can't be bigger
int ic = 0;
string token;
while (!(token = tokens[i++]).equals("}")) { //$non-nls-1$
int c = integer.parseint(token);
chars[ic++] = (char) c;
}

//resize
system.arraycopy(chars, 0, chars = new char[ic], 0, ic);

buildfilefortable(filename, chars);
return chars;
}
private final static void buildfileofshortfor(string filename, string tag, string[] tokens) {

//transform the string tokens into chars before dumping then into file

int i = 0;
//read upto the tag
while (!tokens[i++].equals(tag)){/*empty*/}
//read upto the }

char[] chars = new char[tokens.length]; //can't be bigger
int ic = 0;
string token;
while (!(token = tokens[i++]).equals("}")) { //$non-nls-1$
int c = integer.parseint(token);
chars[ic++] = (char) (c + 32768);
}

//resize
system.arraycopy(chars, 0, chars = new char[ic], 0, ic);

buildfilefortable(filename, chars);
}
private static void buildfilesforrecoverytemplates(
string indexfilename,
string templatesfilename,
char[] newterminalindex,
char[] newnonterminalindex,
string[] newname,
char[] newlhs,
string[] tokens) {

int[] newreverse = computereversetable(newterminalindex, newnonterminalindex, newname);

char[] newrecoveytemplatesindex = new char[newnonterminalindex.length];
char[] newrecoveytemplates = new char[newnonterminalindex.length];
int newrecoveytemplatesptr = 0;

for (int i = 0; i < tokens.length; i = i + 3) {
if("3".equals(tokens[i])) { //$non-nls-1$
int length = newrecoveytemplates.length;
if(length == newrecoveytemplatesptr + 1) {
system.arraycopy(newrecoveytemplates, 0, newrecoveytemplates = new char[length * 2], 0, length);
}
newrecoveytemplates[newrecoveytemplatesptr++] = 0;

int index = newlhs[integer.parseint(tokens[i + 1])];

newrecoveytemplatesindex[index] = (char)newrecoveytemplatesptr;

string token = tokens[i + 2].trim();
java.util.stringtokenizer st = new java.util.stringtokenizer(token, " ");  //$non-nls-1$
string[] terminalnames = new string[st.counttokens()];
int t = 0;
while (st.hasmoretokens()) {
terminalnames[t++] = st.nexttoken();
}

for (int j = 0; j < terminalnames.length; j++) {
int symbol = getsymbol(terminalnames[j], newname, newreverse);
if(symbol > -1) {
length = newrecoveytemplates.length;
if(length == newrecoveytemplatesptr + 1) {
system.arraycopy(newrecoveytemplates, 0, newrecoveytemplates = new char[length * 2], 0, length);
}
newrecoveytemplates[newrecoveytemplatesptr++] = (char)symbol;
}
}
}
}
newrecoveytemplates[newrecoveytemplatesptr++] = 0;
system.arraycopy(newrecoveytemplates, 0, newrecoveytemplates = new char[newrecoveytemplatesptr], 0, newrecoveytemplatesptr);

buildfilefortable(indexfilename, newrecoveytemplatesindex);
buildfilefortable(templatesfilename, newrecoveytemplates);
}
private static void buildfilesforstatementsrecoveryfilter(
string filename,
char[] newnonterminalindex,
char[] newlhs,
string[] tokens) {

char[] newstatementsrecoveryfilter = new char[newnonterminalindex.length];

for (int i = 0; i < tokens.length; i = i + 3) {
if("4".equals(tokens[i])) { //$non-nls-1$
int index = newlhs[integer.parseint(tokens[i + 1])];

newstatementsrecoveryfilter[index] = 1;
}
}
buildfilefortable(filename, newstatementsrecoveryfilter);
}
public final static void buildfilesfromlpg(string datafilename, string datafilename2) {

//run this method to generate parser*.rsc files

//build from the lpg javadcl.java files that represents the parser tables
//lhs check_table asb asr symbol_index

//[org.eclipse.jdt.internal.compiler.parser.parser.buildfilesfromlpg("d:/leapfrog/grammar/javadcl.java")]
char[] contents = charoperation.no_char;
try {
contents = util.getfilecharcontent(new file(datafilename), null);
} catch (ioexception ex) {
system.out.println(messages.parser_incorrectpath);
return;
}
java.util.stringtokenizer st =
new java.util.stringtokenizer(new string(contents), " \t\n\r[]={,;");  //$non-nls-1$
string[] tokens = new string[st.counttokens()];
int j = 0;
while (st.hasmoretokens()) {
tokens[j++] = st.nexttoken();
}
final string prefix = fileprefix;
int i = 0;

char[] newlhs = buildfileofintfor(prefix + (++i) + ".rsc", "lhs", tokens); //$non-nls-1$ //$non-nls-2$
buildfileofshortfor(prefix + (++i) + ".rsc", "check_table", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofintfor(prefix + (++i) + ".rsc", "asb", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofintfor(prefix + (++i) + ".rsc", "asr", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofintfor(prefix + (++i) + ".rsc", "nasb", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofintfor(prefix + (++i) + ".rsc", "nasr", tokens); //$non-nls-2$ //$non-nls-1$
char[] newterminalindex = buildfileofintfor(prefix + (++i) + ".rsc", "terminal_index", tokens); //$non-nls-2$ //$non-nls-1$
char[] newnonterminalindex = buildfileofintfor(prefix + (++i) + ".rsc", "non_terminal_index", tokens); //$non-nls-1$ //$non-nls-2$
buildfileofintfor(prefix + (++i) + ".rsc", "term_action", tokens); //$non-nls-2$ //$non-nls-1$

buildfileofintfor(prefix + (++i) + ".rsc", "scope_prefix", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofintfor(prefix + (++i) + ".rsc", "scope_suffix", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofintfor(prefix + (++i) + ".rsc", "scope_lhs", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofintfor(prefix + (++i) + ".rsc", "scope_state_set", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofintfor(prefix + (++i) + ".rsc", "scope_rhs", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofintfor(prefix + (++i) + ".rsc", "scope_state", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofintfor(prefix + (++i) + ".rsc", "in_symb", tokens); //$non-nls-2$ //$non-nls-1$

byte[] newrhs = buildfileofbytefor(prefix + (++i) + ".rsc", "rhs", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofbytefor(prefix + (++i) + ".rsc", "term_check", tokens); //$non-nls-2$ //$non-nls-1$
buildfileofbytefor(prefix + (++i) + ".rsc", "scope_la", tokens); //$non-nls-2$ //$non-nls-1$

string[] newname = buildfileforname(prefix + (++i) + ".rsc", new string(contents)); //$non-nls-1$

contents = charoperation.no_char;
try {
contents = util.getfilecharcontent(new file(datafilename2), null);
} catch (ioexception ex) {
system.out.println(messages.parser_incorrectpath);
return;
}
st = new java.util.stringtokenizer(new string(contents), "\t\n\r#");  //$non-nls-1$
tokens = new string[st.counttokens()];
j = 0;
while (st.hasmoretokens()) {
tokens[j++] = st.nexttoken();
}

buildfileforcompliance(prefix + (++i) + ".rsc", newrhs.length, tokens);//$non-nls-1$
buildfileforreadablename(readable_names_file+".properties", newlhs, newnonterminalindex, newname, tokens);//$non-nls-1$

buildfilesforrecoverytemplates(
prefix + (++i) + ".rsc", //$non-nls-1$
prefix + (++i) + ".rsc", //$non-nls-1$
newterminalindex,
newnonterminalindex,
newname,
newlhs,
tokens);

buildfilesforstatementsrecoveryfilter(
prefix + (++i) + ".rsc", //$non-nls-1$
newnonterminalindex,
newlhs,
tokens);


system.out.println(messages.parser_movefiles);
}
protected static int[] computereversetable(char[] newterminalindex, char[] newnonterminalindex, string[] newname) {
int[] newreversetable = new int[newname.length];
for (int j = 0; j < newname.length; j++) {
found : {
for (int k = 0; k < newterminalindex.length; k++) {
if(newterminalindex[k] == j) {
newreversetable[j] = k;
break found;
}
}
for (int k = 0; k < newnonterminalindex.length; k++) {
if(newnonterminalindex[k] == j) {
newreversetable[j] = -k;
break found;
}
}
}
}
return newreversetable;
}

private static int getsymbol(string terminalname, string[] newname, int[] newreverse) {
for (int j = 0; j < newname.length; j++) {
if(terminalname.equals(newname[j])) {
return newreverse[j];
}
}
return -1;
}
public static int in_symbol(int state) {
return in_symb[original_state(state)];
}
public final static void inittables() throws java.io.ioexception {

final string prefix = fileprefix;
int i = 0;
lhs = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
char[] chars = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
check_table = new short[chars.length];
for (int c = chars.length; c-- > 0;) {
check_table[c] = (short) (chars[c] - 32768);
}
asb = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
asr = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
nasb = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
nasr = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
terminal_index = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
non_terminal_index = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
term_action = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$

scope_prefix = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
scope_suffix = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
scope_lhs = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
scope_state_set = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
scope_rhs = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
scope_state = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
in_symb = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$

rhs = readbytetable(prefix + (++i) + ".rsc"); //$non-nls-1$
term_check = readbytetable(prefix + (++i) + ".rsc"); //$non-nls-1$
scope_la = readbytetable(prefix + (++i) + ".rsc"); //$non-nls-1$

name = readnametable(prefix + (++i) + ".rsc"); //$non-nls-1$

rules_compliance = readlongtable(prefix + (++i) + ".rsc"); //$non-nls-1$

readablename = readreadablenametable(readable_names_file_name);

reverse_index = computereversetable(terminal_index, non_terminal_index, name);

recovery_templates_index = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$
recovery_templates = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$

statements_recovery_filter = readtable(prefix + (++i) + ".rsc"); //$non-nls-1$

base_action = lhs;
}
public static int nasi(int state) {
return nasb[original_state(state)];
}
public static int ntaction(int state, int sym) {
return base_action[state + sym];
}
protected static int original_state(int state) {
return -base_check(state);
}

protected static byte[] readbytetable(string filename) throws java.io.ioexception {

//files are located at parser.class directory

inputstream stream = parser.class.getresourceasstream(filename);
if (stream == null) {
throw new java.io.ioexception(messages.bind(messages.parser_missingfile, filename));
}
byte[] bytes = null;
try {
stream = new bufferedinputstream(stream);
bytes = util.getinputstreamasbytearray(stream, -1);
} finally {
try {
stream.close();
} catch (ioexception e) {
// ignore
}
}
return bytes;
}
protected static long[] readlongtable(string filename) throws java.io.ioexception {

//files are located at parser.class directory

inputstream stream = parser.class.getresourceasstream(filename);
if (stream == null) {
throw new java.io.ioexception(messages.bind(messages.parser_missingfile, filename));
}
byte[] bytes = null;
try {
stream = new bufferedinputstream(stream);
bytes = util.getinputstreamasbytearray(stream, -1);
} finally {
try {
stream.close();
} catch (ioexception e) {
// ignore
}
}

//minimal integrity check (even size expected)
int length = bytes.length;
if (length % 8 != 0)
throw new java.io.ioexception(messages.bind(messages.parser_corruptedfile, filename));

// convert bytes into longs
long[] longs = new long[length / 8];
int i = 0;
int longindex = 0;

while (true) {
longs[longindex++] =
(((long) (bytes[i++] & 0xff)) << 56)
+ (((long) (bytes[i++] & 0xff)) << 48)
+ (((long) (bytes[i++] & 0xff)) << 40)
+ (((long) (bytes[i++] & 0xff)) << 32)
+ (((long) (bytes[i++] & 0xff)) << 24)
+ (((long) (bytes[i++] & 0xff)) << 16)
+ (((long) (bytes[i++] & 0xff)) << 8)
+ (bytes[i++] & 0xff);

if (i == length)
break;
}
return longs;
}

protected static string[] readnametable(string filename) throws java.io.ioexception {
char[] contents = readtable(filename);
char[][] nameaschar = charoperation.spliton('\n', contents);

string[] result = new string[nameaschar.length + 1];
result[0] = null;
for (int i = 0; i < nameaschar.length; i++) {
result[i + 1] = new string(nameaschar[i]);
}

return result;
}
protected static string[] readreadablenametable(string filename) {
string[] result = new string[name.length];

resourcebundle bundle;
try {
bundle = resourcebundle.getbundle(filename, locale.getdefault());
} catch(missingresourceexception e) {
system.out.println("missing resource : " + filename.replace('.', '/') + ".properties for locale " + locale.getdefault()); //$non-nls-1$//$non-nls-2$
throw e;
}
for (int i = 0; i < nt_offset + 1; i++) {
result[i] = name[i];
}
for (int i = nt_offset; i < name.length; i++) {
try {
string n = bundle.getstring(name[i]);
if(n != null && n.length() > 0) {
result[i] = n;
} else {
result[i] = name[i];
}
} catch(missingresourceexception e) {
result[i] = name[i];
}
}
return result;
}
protected static char[] readtable(string filename) throws java.io.ioexception {

//files are located at parser.class directory

inputstream stream = parser.class.getresourceasstream(filename);
if (stream == null) {
throw new java.io.ioexception(messages.bind(messages.parser_missingfile, filename));
}
byte[] bytes = null;
try {
stream = new bufferedinputstream(stream);
bytes = util.getinputstreamasbytearray(stream, -1);
} finally {
try {
stream.close();
} catch (ioexception e) {
// ignore
}
}

//minimal integrity check (even size expected)
int length = bytes.length;
if ((length & 1) != 0)
throw new java.io.ioexception(messages.bind(messages.parser_corruptedfile, filename));

// convert bytes into chars
char[] chars = new char[length / 2];
int i = 0;
int charindex = 0;

while (true) {
chars[charindex++] = (char) (((bytes[i++] & 0xff) << 8) + (bytes[i++] & 0xff));
if (i == length)
break;
}
return chars;
}
public static int taction(int state, int sym) {
return term_action[term_check[base_action[state]+sym] == sym ? base_action[state] + sym : base_action[state]];
}
protected int astlengthptr;

protected int[] astlengthstack;
protected int astptr;
protected astnode[] aststack = new astnode[aststackincrement];
public compilationunitdeclaration compilationunit; /*the result from parse()*/

protected recoveredelement currentelement;
public int currenttoken;
protected boolean diet = false; //tells the scanner to jump over some parts of the code/expressions like method bodies
protected int dietint = 0; // if > 0 force the none-diet-parsing mode (even if diet if requested) [field parsing with anonymous inner classes...]
protected int endposition; //accurate only when used ! (the start position is pushed into intstack while the end the current one)
protected int endstatementposition;
protected int expressionlengthptr;
protected int[] expressionlengthstack;
protected int expressionptr;
protected expression[] expressionstack = new expression[expressionstackincrement];
public int firsttoken ; // handle for multiple parsing goals
// generics management
protected int genericsidentifierslengthptr;
protected int[] genericsidentifierslengthstack = new int[genericsstackincrement];
protected int genericslengthptr;
protected int[] genericslengthstack = new int[genericsstackincrement];
protected int genericsptr;
protected astnode[] genericsstack = new astnode[genericsstackincrement];
protected boolean haserror;
protected boolean hasreportederror;
//identifiers stacks
protected int identifierlengthptr;
protected int[] identifierlengthstack;
protected long[] identifierpositionstack;
protected int identifierptr;
protected char[][] identifierstack;
protected boolean ignorenextopeningbrace;

//positions , dimensions , .... (int stacks)
protected int intptr;

protected int[] intstack;
public int lastact ; //handle for multiple parsing goals
//error recovery management
protected int lastcheckpoint;
protected int lasterrorendposition;
protected int lasterrorendpositionbeforerecovery = -1;
protected int lastignoredtoken, nextignoredtoken;

protected int listlength; // for recovering some incomplete list (interfaces, throws or parameters)

protected int listtypeparameterlength; // for recovering some incomplete list (type parameters)
protected int lparenpos,rparenpos; //accurate only when used !
protected int modifiers;
protected int modifierssourcestart;
protected int[] nestedmethod; //the ptr is nestedtype

protected int nestedtype, dimensions;
astnode [] noastnodes = new astnode[aststackincrement];

expression [] noexpressions = new expression[expressionstackincrement];
//modifiers dimensions nestedtype etc.......
protected boolean optimizestringliterals =true;
protected compileroptions options;

protected problemreporter problemreporter;

protected int rbracestart, rbraceend, rbracesuccessorstart; //accurate only when used !
protected int realblockptr;
protected int[] realblockstack;
protected int recoveredstaticinitializerstart;
public referencecontext referencecontext;
public boolean reportonlyonesyntaxerror = false;
public boolean reportsyntaxerrorisrequired = true;
protected boolean restartrecovery;
protected boolean annotationrecoveryactivated = true;
protected int lastposistion;
// statement recovery
public boolean methodrecoveryactivated = false;
protected boolean statementrecoveryactivated = false;
protected typedeclaration[] recoveredtypes;
protected int recoveredtypeptr;
protected int nexttypestart;
protected typedeclaration pendingrecoveredtype;
public recoveryscanner recoveryscanner;
//scanner token
public scanner scanner;
protected int[] stack = new int[stackincrement];
protected int statestacktop;
protected int synchronizedblocksourcestart;

protected int[] variablescounter;

protected boolean checkexternalizestrings;

protected boolean recordstringliterals;
// javadoc
public javadoc javadoc;
public javadocparser javadocparser;
// used for recovery
protected int lastjavadocend;
public org.eclipse.jdt.internal.compiler.readmanager readmanager;

public parser(problemreporter problemreporter, boolean optimizestringliterals) {

this.problemreporter = problemreporter;
this.options = problemreporter.options;
this.optimizestringliterals = optimizestringliterals;
initializescanner();
this.astlengthstack = new int[50];
this.expressionlengthstack = new int[30];
this.intstack = new int[50];
this.identifierstack = new char[30][];
this.identifierlengthstack = new int[30];
this.nestedmethod = new int[30];
this.realblockstack = new int[30];
this.identifierpositionstack = new long[30];
this.variablescounter = new int[30];

// javadoc support
this.javadocparser = createjavadocparser();
}
protected void annotationrecoverycheckpoint(int start, int end) {
if(this.lastcheckpoint < end) {
this.lastcheckpoint = end + 1;
}
}
public void arrayinitializer(int length) {
//length is the size of the array initializer
//expressionptr points on the last elt of the arrayinitializer,
// in other words, it has not been decremented yet.

arrayinitializer ai = new arrayinitializer();
if (length != 0) {
this.expressionptr -= length;
system.arraycopy(this.expressionstack, this.expressionptr + 1, ai.expressions = new expression[length], 0, length);
}
pushonexpressionstack(ai);
//positionning
ai.sourceend = this.endstatementposition;
ai.sourcestart = this.intstack[this.intptr--];
}
protected void blockreal() {
// see consumelocalvariabledeclarationstatement in case of change: duplicated code
// increment the amount of declared variables for this block
this.realblockstack[this.realblockptr]++;
}
/*
* build initial recovery state.
* recovery state is inferred from the current state of the parser (reduced node stack).
*/
public recoveredelement buildinitialrecoverystate(){

/* initialize recovery by retrieving available reduced nodes
* also rebuild bracket balance
*/
this.lastcheckpoint = 0;
this.lasterrorendpositionbeforerecovery = this.scanner.currentposition;

recoveredelement element = null;
if (this.referencecontext instanceof compilationunitdeclaration){
element = new recoveredunit(this.compilationunit, 0, this);

/* ignore current stack state, since restarting from the beginnning
since could not trust simple brace count */
// restart recovery from scratch
this.compilationunit.currentpackage = null;
this.compilationunit.imports = null;
this.compilationunit.types = null;
this.currenttoken = 0;
this.listlength = 0;
this.listtypeparameterlength = 0;
this.endposition = 0;
this.endstatementposition = 0;
return element;
} else {
if (this.referencecontext instanceof abstractmethoddeclaration){
element = new recoveredmethod((abstractmethoddeclaration) this.referencecontext, null, 0, this);
this.lastcheckpoint = ((abstractmethoddeclaration) this.referencecontext).bodystart;
if(this.statementrecoveryactivated) {
element = element.add(new block(0), 0);
}
} else {
/* initializer bodies are parsed in the context of the type declaration, we must thus search it inside */
if (this.referencecontext instanceof typedeclaration){
typedeclaration type = (typedeclaration) this.referencecontext;
for (int i = 0; i < type.fields.length; i++){
fielddeclaration field = type.fields[i];
if (field != null
&& field.getkind() == abstractvariabledeclaration.initializer
&& ((initializer) field).block != null
&& field.declarationsourcestart <= this.scanner.initialposition
&& this.scanner.initialposition <= field.declarationsourceend
&& this.scanner.eofposition <= field.declarationsourceend+1){
element = new recoveredinitializer(field, null, 1, this);
this.lastcheckpoint = field.declarationsourcestart;
break;
}
}
}
}
}

if (element == null) return element;

for(int i = 0; i <= this.astptr; i++){
astnode node = this.aststack[i];
if (node instanceof abstractmethoddeclaration){
abstractmethoddeclaration method = (abstractmethoddeclaration) node;
if (method.declarationsourceend == 0){
element = element.add(method, 0);
this.lastcheckpoint = method.bodystart;
} else {
element = element.add(method, 0);
this.lastcheckpoint = method.declarationsourceend + 1;
}
continue;
}
if (node instanceof initializer){
initializer initializer = (initializer) node;
// ignore initializer with no block
if (initializer.block == null) continue;
if (initializer.declarationsourceend == 0){
element = element.add(initializer, 1);
this.lastcheckpoint = initializer.sourcestart;
} else {
element = element.add(initializer, 0);
this.lastcheckpoint = initializer.declarationsourceend + 1;
}
continue;
}
if (node instanceof fielddeclaration){
fielddeclaration field = (fielddeclaration) node;
if (field.declarationsourceend == 0){
element = element.add(field, 0);
if (field.initialization == null){
this.lastcheckpoint = field.sourceend + 1;
} else {
this.lastcheckpoint = field.initialization.sourceend + 1;
}
} else {
element = element.add(field, 0);
this.lastcheckpoint = field.declarationsourceend + 1;
}
continue;
}
if (node instanceof typedeclaration){
typedeclaration type = (typedeclaration) node;
if (type.declarationsourceend == 0){
element = element.add(type, 0);
this.lastcheckpoint = type.bodystart;
} else {
element = element.add(type, 0);
this.lastcheckpoint = type.declarationsourceend + 1;
}
continue;
}
if (node instanceof importreference){
importreference importref = (importreference) node;
element = element.add(importref, 0);
this.lastcheckpoint = importref.declarationsourceend + 1;
}
if(this.statementrecoveryactivated) {
if(node instanceof block) {
block block = (block) node;
element = element.add(block, 0);
this.lastcheckpoint = block.sourceend + 1;
} else if(node instanceof localdeclaration) {
localdeclaration statement = (localdeclaration) node;
element = element.add(statement, 0);
this.lastcheckpoint = statement.sourceend + 1;
} else if(node instanceof expression) {
if(node instanceof assignment ||
node instanceof prefixexpression ||
node instanceof postfixexpression ||
node instanceof messagesend ||
node instanceof allocationexpression) {
// recover only specific expressions
expression statement = (expression) node;
element = element.add(statement, 0);
if(statement.statementend != -1) {
this.lastcheckpoint = statement.statementend + 1;
} else {
this.lastcheckpoint = statement.sourceend + 1;
}
}
} else if(node instanceof statement) {
statement statement = (statement) node;
element = element.add(statement, 0);
this.lastcheckpoint = statement.sourceend + 1;
}
}
}

if (this.statementrecoveryactivated) {
if (this.pendingrecoveredtype != null &&
this.scanner.startposition - 1 <= this.pendingrecoveredtype.declarationsourceend) {
// add the pending type to the ast if this type isn't already added in the ast.
element = element.add(this.pendingrecoveredtype, 0);
this.lastcheckpoint = this.pendingrecoveredtype.declarationsourceend + 1;
this.pendingrecoveredtype = null;
}
}
return element;
}

protected void checkandsetmodifiers(int flag){
/*modify the current modifiers buffer.
when the startposition of the modifiers is 0
it means that the modifier being parsed is the first
of a list of several modifiers. the startposition
is zeroed when a copy of modifiers-buffer is push
onto the this.aststack. */

if ((this.modifiers & flag) != 0){ // duplicate modifier
this.modifiers |= extracompilermodifiers.accalternatemodifierproblem;
}
this.modifiers |= flag;

if (this.modifierssourcestart < 0) this.modifierssourcestart = this.scanner.startposition;

if (this.currentelement != null && this.annotationrecoveryactivated) {
this.currentelement.addmodifier(flag, this.modifierssourcestart);
}
}
public void checkcomment() {

// discard obsolete comments while inside methods or fields initializer (see bug 74369)
if (!(this.diet && this.dietint==0) && this.scanner.commentptr >= 0) {
flushcommentsdefinedpriorto(this.endstatementposition);
}

int lastcomment = this.scanner.commentptr;

if (this.modifierssourcestart >= 0) {
// eliminate comments located after modifiersourcestart if positionned
while (lastcomment >= 0) {
int commentsourcestart = this.scanner.commentstarts[lastcomment];
if (commentsourcestart < 0) commentsourcestart = -commentsourcestart;
if (commentsourcestart <= this.modifierssourcestart) break;
lastcomment--;
}
}
if (lastcomment >= 0) {
// consider all remaining leading comments to be part of current declaration
this.modifierssourcestart = this.scanner.commentstarts[0];
if (this.modifierssourcestart < 0) this.modifierssourcestart = -this.modifierssourcestart;

// check deprecation in last comment if javadoc (can be followed by non-javadoc comments which are simply ignored)
while (lastcomment >= 0 && this.scanner.commentstops[lastcomment] < 0) lastcomment--; // non javadoc comment have negative end positions
if (lastcomment >= 0 && this.javadocparser != null) {
int commentend = this.scanner.commentstops[lastcomment] - 1; //stop is one over,
// do not report problem before last parsed comment while recovering code...
if (this.javadocparser.shouldreportproblems) {
this.javadocparser.reportproblems = this.currentelement == null || commentend > this.lastjavadocend;
} else {
this.javadocparser.reportproblems = false;
}
if (this.javadocparser.checkdeprecation(lastcomment)) {
checkandsetmodifiers(classfileconstants.accdeprecated);
}
this.javadoc = this.javadocparser.doccomment;	// null if check javadoc is not activated
if (this.currentelement == null) this.lastjavadocend = commentend;
}
}
}
protected void checknonnlsafterbodyend(int declarationend){
if(this.scanner.currentposition - 1 <= declarationend) {
this.scanner.eofposition = declarationend < integer.max_value ? declarationend + 1 : declarationend;
try {
while(this.scanner.getnexttoken() != tokennameeof){/*empty*/}
} catch (invalidinputexception e) {
// nothing to do
}
}
}
protected void classinstancecreation(boolean isqualified) {
// classinstancecreationexpression ::= 'new' classtype '(' argumentlistopt ')' classbodyopt

// classbodyopt produces a null item on the aststak if it produces no class body
// an empty class body produces a 0 on the length stack.....

allocationexpression alloc;
int length;
if (((length = this.astlengthstack[this.astlengthptr--]) == 1)
&& (this.aststack[this.astptr] == null)) {
//no classbody
this.astptr--;
if (isqualified) {
alloc = new qualifiedallocationexpression();
} else {
alloc = new allocationexpression();
}
alloc.sourceend = this.endposition; //the position has been stored explicitly

if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
alloc.arguments = new expression[length],
0,
length);
}
alloc.type = gettypereference(0);

//the default constructor with the correct number of argument
//will be created and added by the tc (see createsinternalconstructorwithbinding)
alloc.sourcestart = this.intstack[this.intptr--];
pushonexpressionstack(alloc);
} else {
dispatchdeclarationinto(length);
typedeclaration anonymoustypedeclaration = (typedeclaration)this.aststack[this.astptr];
anonymoustypedeclaration.declarationsourceend = this.endstatementposition;
anonymoustypedeclaration.bodyend = this.endstatementposition;
if (anonymoustypedeclaration.allocation != null) {
anonymoustypedeclaration.allocation.sourceend = this.endstatementposition;
}
if (length == 0 && !containscomment(anonymoustypedeclaration.bodystart, anonymoustypedeclaration.bodyend)) {
anonymoustypedeclaration.bits |= astnode.undocumentedemptyblock;
}
this.astptr--;
this.astlengthptr--;
}
}
protected parameterizedqualifiedtypereference computequalifiedgenericsfromrightside(typereference rightside, int dim) {
int namesize = this.identifierlengthstack[this.identifierlengthptr];
int tokenssize = namesize;
if (rightside instanceof parameterizedsingletypereference) {
tokenssize ++;
} else if (rightside instanceof singletypereference) {
tokenssize ++;
} else if (rightside instanceof parameterizedqualifiedtypereference) {
tokenssize += ((qualifiedtypereference) rightside).tokens.length;
} else if (rightside instanceof qualifiedtypereference) {
tokenssize += ((qualifiedtypereference) rightside).tokens.length;
}
typereference[][] typearguments = new typereference[tokenssize][];
char[][] tokens = new char[tokenssize][];
long[] positions = new long[tokenssize];
if (rightside instanceof parameterizedsingletypereference) {
parameterizedsingletypereference singleparameterizedtypereference = (parameterizedsingletypereference) rightside;
tokens[namesize] = singleparameterizedtypereference.token;
positions[namesize] = (((long) singleparameterizedtypereference.sourcestart) << 32) + singleparameterizedtypereference.sourceend;
typearguments[namesize] = singleparameterizedtypereference.typearguments;
} else if (rightside instanceof singletypereference) {
singletypereference singletypereference = (singletypereference) rightside;
tokens[namesize] = singletypereference.token;
positions[namesize] = (((long) singletypereference.sourcestart) << 32) + singletypereference.sourceend;
} else if (rightside instanceof parameterizedqualifiedtypereference) {
parameterizedqualifiedtypereference parameterizedtypereference = (parameterizedqualifiedtypereference) rightside;
typereference[][] rightsidetypearguments = parameterizedtypereference.typearguments;
system.arraycopy(rightsidetypearguments, 0, typearguments, namesize, rightsidetypearguments.length);
char[][] rightsidetokens = parameterizedtypereference.tokens;
system.arraycopy(rightsidetokens, 0, tokens, namesize, rightsidetokens.length);
long[] rightsidepositions = parameterizedtypereference.sourcepositions;
system.arraycopy(rightsidepositions, 0, positions, namesize, rightsidepositions.length);
} else if (rightside instanceof qualifiedtypereference) {
qualifiedtypereference qualifiedtypereference = (qualifiedtypereference) rightside;
char[][] rightsidetokens = qualifiedtypereference.tokens;
system.arraycopy(rightsidetokens, 0, tokens, namesize, rightsidetokens.length);
long[] rightsidepositions = qualifiedtypereference.sourcepositions;
system.arraycopy(rightsidepositions, 0, positions, namesize, rightsidepositions.length);
}

int currenttypeargumentslength = this.genericslengthstack[this.genericslengthptr--];
typereference[] currenttypearguments = new typereference[currenttypeargumentslength];
this.genericsptr -= currenttypeargumentslength;
system.arraycopy(this.genericsstack, this.genericsptr + 1, currenttypearguments, 0, currenttypeargumentslength);

if (namesize == 1) {
tokens[0] = this.identifierstack[this.identifierptr];
positions[0] = this.identifierpositionstack[this.identifierptr--];
typearguments[0] = currenttypearguments;
} else {
this.identifierptr -= namesize;
system.arraycopy(this.identifierstack, this.identifierptr + 1, tokens, 0, namesize);
system.arraycopy(this.identifierpositionstack, this.identifierptr + 1, positions, 0, namesize);
typearguments[namesize - 1] = currenttypearguments;
}
this.identifierlengthptr--;
return new parameterizedqualifiedtypereference(tokens, typearguments, dim, positions);
}
protected void concatexpressionlists() {
this.expressionlengthstack[--this.expressionlengthptr]++;
}
protected void concatgenericslists() {
this.genericslengthstack[this.genericslengthptr - 1] += this.genericslengthstack[this.genericslengthptr--];
}
protected void concatnodelists() {
/*
* this is a case where you have two sublists into the this.aststack that you want
* to merge in one list. there is no action required on the this.aststack. the only
* thing you need to do is merge the two lengths specified on the aststacklength.
* the top two length are for example:
* ... p   n
* and you want to result in a list like:
* ... n+p
* this means that the p could be equals to 0 in case there is no astnode pushed
* on the this.aststack.
* look at the interfacememberdeclarations for an example.
*/

this.astlengthstack[this.astlengthptr - 1] += this.astlengthstack[this.astlengthptr--];
}
protected void consumeadditionalbound() {
pushongenericsstack(gettypereference(this.intstack[this.intptr--]));
}
protected void consumeadditionalbound1() {
// nothing to be done.
// the reference type1 is consumed by consumereferencetype1 method.
}
protected void consumeadditionalboundlist() {
concatgenericslists();
}
protected void consumeadditionalboundlist1() {
concatgenericslists();
}
protected void consumeallocationheader() {
// classinstancecreationexpression ::= 'new' classtype '(' argumentlistopt ')' classbodyopt

// classbodyopt produces a null item on the aststak if it produces no class body
// an empty class body produces a 0 on the length stack.....

if (this.currentelement == null){
return; // should never occur, this consumerule is only used in recovery mode
}
if (this.currenttoken == tokennamelbrace){
// beginning of an anonymous type
typedeclaration anonymoustype = new typedeclaration(this.compilationunit.compilationresult);
anonymoustype.name = charoperation.no_char;
anonymoustype.bits |= (astnode.isanonymoustype|astnode.islocaltype);
anonymoustype.sourcestart = this.intstack[this.intptr--];
anonymoustype.declarationsourcestart = anonymoustype.sourcestart;
anonymoustype.sourceend = this.rparenpos; // closing parenthesis
qualifiedallocationexpression alloc = new qualifiedallocationexpression(anonymoustype);
alloc.type = gettypereference(0);
alloc.sourcestart = anonymoustype.sourcestart;
alloc.sourceend = anonymoustype.sourceend ;
this.lastcheckpoint = anonymoustype.bodystart = this.scanner.currentposition;
this.currentelement = this.currentelement.add(anonymoustype, 0);
this.lastignoredtoken = -1;
this.currenttoken = 0; // opening brace already taken into account
return;
}
this.lastcheckpoint = this.scanner.startposition; // force to restart at this exact position
this.restartrecovery = true; // request to restart from here on
}
protected void consumeannotationasmodifier() {
expression expression = this.expressionstack[this.expressionptr];
int sourcestart = expression.sourcestart;
if (this.modifierssourcestart < 0) {
this.modifierssourcestart = sourcestart;
}
}
protected void consumeannotationname() {
if(this.currentelement != null) {
int start = this.intstack[this.intptr];
int end = (int) (this.identifierpositionstack[this.identifierptr] & 0x00000000ffffffffl);
annotationrecoverycheckpoint(start, end);

if (this.annotationrecoveryactivated) {
this.currentelement = this.currentelement.addannotationname(this.identifierptr, this.identifierlengthptr, start, 0);
}
}
this.recordstringliterals = false;
}
protected void consumeannotationtypedeclaration() {
int length;
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
//there are length declarations
//dispatch according to the type of the declarations
dispatchdeclarationinto(length);
}

typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];

//convert constructor that do not have the type's name into methods
typedecl.checkconstructors(this);

//always add <clinit> (will be remove at code gen time if empty)
if (this.scanner.containsassertkeyword) {
typedecl.bits |= astnode.containsassertion;
}
typedecl.addclinit();
typedecl.bodyend = this.endstatementposition;
if (length == 0 && !containscomment(typedecl.bodystart, typedecl.bodyend)) {
typedecl.bits |= astnode.undocumentedemptyblock;
}
typedecl.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);
}
protected void consumeannotationtypedeclarationheader() {
typedeclaration annotationtypedeclaration = (typedeclaration) this.aststack[this.astptr];
if (this.currenttoken == tokennamelbrace) {
annotationtypedeclaration.bodystart = this.scanner.currentposition;
}
if (this.currentelement != null) {
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
// flush the comments related to the annotation type header
this.scanner.commentptr = -1;
}
protected void consumeannotationtypedeclarationheadername() {
// consumeannotationtypedeclarationheader ::= modifiers '@@' pushmodifiers interface identifier
// consumeannotationtypedeclarationheader ::= '@@' pushmodifiers interface identifier
typedeclaration annotationtypedeclaration = new typedeclaration(this.compilationunit.compilationresult);
if (this.nestedmethod[this.nestedtype] == 0) {
if (this.nestedtype != 0) {
annotationtypedeclaration.bits |= astnode.ismembertype;
}
} else {
// record that the block has a declaration for local types
annotationtypedeclaration.bits |= astnode.islocaltype;
markenclosingmemberwithlocaltype();
blockreal();
}

//highlight the name of the type
long pos = this.identifierpositionstack[this.identifierptr];
annotationtypedeclaration.sourceend = (int) pos;
annotationtypedeclaration.sourcestart = (int) (pos >>> 32);
annotationtypedeclaration.name = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;

//compute the declaration source too
// 'interface' push two int positions: the beginning of the class token and its end.
// we want to keep the beginning position but get rid of the end position
// it is only used for the classliteralaccess positions.
this.intptr--; // remove the start position of the interface token
this.intptr--; // remove the end position of the interface token

annotationtypedeclaration.modifierssourcestart = this.intstack[this.intptr--];
annotationtypedeclaration.modifiers = this.intstack[this.intptr--] | classfileconstants.accannotation | classfileconstants.accinterface;
if (annotationtypedeclaration.modifierssourcestart >= 0) {
annotationtypedeclaration.declarationsourcestart = annotationtypedeclaration.modifierssourcestart;
this.intptr--; // remove the position of the '@@' token as we have modifiers
} else {
int atposition = this.intstack[this.intptr--];
// remove the position of the '@@' token as we don't have modifiers
annotationtypedeclaration.declarationsourcestart = atposition;
}

// store secondary info
if ((annotationtypedeclaration.bits & astnode.ismembertype) == 0 && (annotationtypedeclaration.bits & astnode.islocaltype) == 0) {
if (this.compilationunit != null && !charoperation.equals(annotationtypedeclaration.name, this.compilationunit.getmaintypename())) {
annotationtypedeclaration.bits |= astnode.issecondarytype;
}
}

// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
annotationtypedeclaration.annotations = new annotation[length],
0,
length);
}
annotationtypedeclaration.bodystart = annotationtypedeclaration.sourceend + 1;

// javadoc
annotationtypedeclaration.javadoc = this.javadoc;
this.javadoc = null;
pushonaststack(annotationtypedeclaration);
if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
problemreporter().invalidusageofannotationdeclarations(annotationtypedeclaration);
}

// recovery
if (this.currentelement != null){
this.lastcheckpoint = annotationtypedeclaration.bodystart;
this.currentelement = this.currentelement.add(annotationtypedeclaration, 0);
this.lastignoredtoken = -1;
}
}
protected void consumeannotationtypedeclarationheadernamewithtypeparameters() {
// consumeannotationtypedeclarationheader ::= modifiers '@@' pushmodifiers interface identifier typeparameters
// consumeannotationtypedeclarationheader ::= '@@' pushmodifiers interface identifier typeparameters
typedeclaration annotationtypedeclaration = new typedeclaration(this.compilationunit.compilationresult);
// consume type parameters
int length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, annotationtypedeclaration.typeparameters = new typeparameter[length], 0, length);

problemreporter().invalidusageoftypeparametersforannotationdeclaration(annotationtypedeclaration);

annotationtypedeclaration.bodystart = annotationtypedeclaration.typeparameters[length-1].declarationsourceend + 1;

//	annotationtypedeclaration.typeparameters = null;

this.listtypeparameterlength = 0;

if (this.nestedmethod[this.nestedtype] == 0) {
if (this.nestedtype != 0) {
annotationtypedeclaration.bits |= astnode.ismembertype;
}
} else {
// record that the block has a declaration for local types
annotationtypedeclaration.bits |= astnode.islocaltype;
markenclosingmemberwithlocaltype();
blockreal();
}

//highlight the name of the type
long pos = this.identifierpositionstack[this.identifierptr];
annotationtypedeclaration.sourceend = (int) pos;
annotationtypedeclaration.sourcestart = (int) (pos >>> 32);
annotationtypedeclaration.name = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;

//compute the declaration source too
// 'interface' push two int positions: the beginning of the class token and its end.
// we want to keep the beginning position but get rid of the end position
// it is only used for the classliteralaccess positions.
this.intptr--; // remove the start position of the interface token
this.intptr--; // remove the end position of the interface token

annotationtypedeclaration.modifierssourcestart = this.intstack[this.intptr--];
annotationtypedeclaration.modifiers = this.intstack[this.intptr--] | classfileconstants.accannotation | classfileconstants.accinterface;
if (annotationtypedeclaration.modifierssourcestart >= 0) {
annotationtypedeclaration.declarationsourcestart = annotationtypedeclaration.modifierssourcestart;
this.intptr--; // remove the position of the '@@' token as we have modifiers
} else {
int atposition = this.intstack[this.intptr--];
// remove the position of the '@@' token as we don't have modifiers
annotationtypedeclaration.declarationsourcestart = atposition;
}

// store secondary info
if ((annotationtypedeclaration.bits & astnode.ismembertype) == 0 && (annotationtypedeclaration.bits & astnode.islocaltype) == 0) {
if (this.compilationunit != null && !charoperation.equals(annotationtypedeclaration.name, this.compilationunit.getmaintypename())) {
annotationtypedeclaration.bits |= astnode.issecondarytype;
}
}

// consume annotations
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
annotationtypedeclaration.annotations = new annotation[length],
0,
length);
}
// javadoc
annotationtypedeclaration.javadoc = this.javadoc;
this.javadoc = null;
pushonaststack(annotationtypedeclaration);
if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
problemreporter().invalidusageofannotationdeclarations(annotationtypedeclaration);
}

// recovery
if (this.currentelement != null){
this.lastcheckpoint = annotationtypedeclaration.bodystart;
this.currentelement = this.currentelement.add(annotationtypedeclaration, 0);
this.lastignoredtoken = -1;
}
}
protected void consumeannotationtypememberdeclaration() {
// annotationtypememberdeclaration ::= annotationtypememberdeclarationheader annotationtypememberheaderextendeddims defaultvalueopt ';'
annotationmethoddeclaration annotationtypememberdeclaration = (annotationmethoddeclaration) this.aststack[this.astptr];
annotationtypememberdeclaration.modifiers |= extracompilermodifiers.accsemicolonbody;
// store the this.endposition (position just before the '}') in case there is
// a trailing comment behind the end of the method
int declarationendposition = flushcommentsdefinedpriorto(this.endstatementposition);
annotationtypememberdeclaration.bodystart = this.endstatementposition;
annotationtypememberdeclaration.bodyend = declarationendposition;
annotationtypememberdeclaration.declarationsourceend = declarationendposition;
}
protected void consumeannotationtypememberdeclarations() {
// annotationtypememberdeclarations ::= annotationtypememberdeclarations annotationtypememberdeclaration
concatnodelists();
}
protected void consumeannotationtypememberdeclarationsopt() {
this.nestedtype-- ;
}
protected void consumeargumentlist() {
// argumentlist ::= argumentlist ',' expression
concatexpressionlists();
}
protected void consumearguments() {
// arguments ::= '(' argumentlistopt ')'
// nothing to do, the expression stack is already updated
pushonintstack(this.rparenpos);
}
protected void consumearrayaccess(boolean unspecifiedreference) {
// arrayaccess ::= name '[' expression ']' ==> true
// arrayaccess ::= primarynonewarray '[' expression ']' ==> false


//optimize push/pop
expression exp;
if (unspecifiedreference) {
exp =
this.expressionstack[this.expressionptr] =
new arrayreference(
getunspecifiedreferenceoptimized(),
this.expressionstack[this.expressionptr]);
} else {
this.expressionptr--;
this.expressionlengthptr--;
exp =
this.expressionstack[this.expressionptr] =
new arrayreference(
this.expressionstack[this.expressionptr],
this.expressionstack[this.expressionptr + 1]);
}
exp.sourceend = this.endstatementposition;
}
protected void consumearraycreationexpressionwithinitializer() {
// arraycreationwitharrayinitializer ::= 'new' primitivetype dimwithorwithoutexprs arrayinitializer
// arraycreationwitharrayinitializer ::= 'new' classorinterfacetype dimwithorwithoutexprs arrayinitializer

int length;
arrayallocationexpression arrayallocation = new arrayallocationexpression();
this.expressionlengthptr -- ;
arrayallocation.initializer = (arrayinitializer) this.expressionstack[this.expressionptr--];

arrayallocation.type = gettypereference(0);
arrayallocation.type.bits |= astnode.ignorerawtypecheck; // no need to worry about raw type usage
length = (this.expressionlengthstack[this.expressionlengthptr--]);
this.expressionptr -= length ;
system.arraycopy(
this.expressionstack,
this.expressionptr+1,
arrayallocation.dimensions = new expression[length],
0,
length);
arrayallocation.sourcestart = this.intstack[this.intptr--];
if (arrayallocation.initializer == null) {
arrayallocation.sourceend = this.endstatementposition;
} else {
arrayallocation.sourceend = arrayallocation.initializer.sourceend ;
}
pushonexpressionstack(arrayallocation);
}
protected void consumearraycreationexpressionwithoutinitializer() {
// arraycreationwithoutarrayinitializer ::= 'new' classorinterfacetype dimwithorwithoutexprs
// arraycreationwithoutarrayinitializer ::= 'new' primitivetype dimwithorwithoutexprs

int length;
arrayallocationexpression arrayallocation = new arrayallocationexpression();
arrayallocation.type = gettypereference(0);
arrayallocation.type.bits |= astnode.ignorerawtypecheck; // no need to worry about raw type usage
length = (this.expressionlengthstack[this.expressionlengthptr--]);
this.expressionptr -= length ;
system.arraycopy(
this.expressionstack,
this.expressionptr+1,
arrayallocation.dimensions = new expression[length],
0,
length);
arrayallocation.sourcestart = this.intstack[this.intptr--];
if (arrayallocation.initializer == null) {
arrayallocation.sourceend = this.endstatementposition;
} else {
arrayallocation.sourceend = arrayallocation.initializer.sourceend ;
}
pushonexpressionstack(arrayallocation);
}
protected void consumearraycreationheader() {
// nothing to do
}
protected void consumearrayinitializer() {
// arrayinitializer ::= '{' variableinitializers '}'
// arrayinitializer ::= '{' variableinitializers , '}'

arrayinitializer(this.expressionlengthstack[this.expressionlengthptr--]);
}
protected void consumearraytypewithtypeargumentsname() {
this.genericsidentifierslengthstack[this.genericsidentifierslengthptr] += this.identifierlengthstack[this.identifierlengthptr];
pushongenericslengthstack(0); // handle type arguments
}
protected void consumeassertstatement() {
// assertstatement ::= 'assert' expression ':' expression ';'
this.expressionlengthptr-=2;
pushonaststack(new assertstatement(this.expressionstack[this.expressionptr--], this.expressionstack[this.expressionptr--], this.intstack[this.intptr--]));
}
protected void consumeassignment() {
// assignment ::= lefthandside assignmentoperator assignmentexpression
//optimize the push/pop

int op = this.intstack[this.intptr--] ; //<--the encoded operator

this.expressionptr -- ; this.expressionlengthptr -- ;
expression expression = this.expressionstack[this.expressionptr+1];
this.expressionstack[this.expressionptr] =
(op != equal ) ?
new compoundassignment(
this.expressionstack[this.expressionptr] ,
expression,
op,
expression.sourceend):
new assignment(
this.expressionstack[this.expressionptr] ,
expression,
expression.sourceend);

if (this.pendingrecoveredtype != null) {
// used only in statements recovery.
// this is not a real assignment but a placeholder for an existing anonymous type.
// the assignment must be replace by the anonymous type.
if (this.pendingrecoveredtype.allocation != null &&
this.scanner.startposition - 1 <= this.pendingrecoveredtype.declarationsourceend) {
this.expressionstack[this.expressionptr] = this.pendingrecoveredtype.allocation;
this.pendingrecoveredtype = null;
return;
}
this.pendingrecoveredtype = null;
}
}
protected void consumeassignmentoperator(int pos) {
// assignmentoperator ::= '='
// assignmentoperator ::= '*='
// assignmentoperator ::= '/='
// assignmentoperator ::= '%='
// assignmentoperator ::= '+='
// assignmentoperator ::= '-='
// assignmentoperator ::= '<<='
// assignmentoperator ::= '>>='
// assignmentoperator ::= '>>>='
// assignmentoperator ::= '&='
// assignmentoperator ::= '^='
// assignmentoperator ::= '|='

pushonintstack(pos);
}
protected void consumebinaryexpression(int op) {
// multiplicativeexpression ::= multiplicativeexpression '*' unaryexpression
// multiplicativeexpression ::= multiplicativeexpression '/' unaryexpression
// multiplicativeexpression ::= multiplicativeexpression '%' unaryexpression
// additiveexpression ::= additiveexpression '+' multiplicativeexpression
// additiveexpression ::= additiveexpression '-' multiplicativeexpression
// shiftexpression ::= shiftexpression '<<'  additiveexpression
// shiftexpression ::= shiftexpression '>>'  additiveexpression
// shiftexpression ::= shiftexpression '>>>' additiveexpression
// relationalexpression ::= relationalexpression '<'  shiftexpression
// relationalexpression ::= relationalexpression '>'  shiftexpression
// relationalexpression ::= relationalexpression '<=' shiftexpression
// relationalexpression ::= relationalexpression '>=' shiftexpression
// andexpression ::= andexpression '&' equalityexpression
// exclusiveorexpression ::= exclusiveorexpression '^' andexpression
// inclusiveorexpression ::= inclusiveorexpression '|' exclusiveorexpression
// conditionalandexpression ::= conditionalandexpression '&&' inclusiveorexpression
// conditionalorexpression ::= conditionalorexpression '||' conditionalandexpression

//optimize the push/pop

this.expressionptr--;
this.expressionlengthptr--;
expression expr1 = this.expressionstack[this.expressionptr];
expression expr2 = this.expressionstack[this.expressionptr + 1];
switch(op) {
case or_or :
this.expressionstack[this.expressionptr] =
new or_or_expression(
expr1,
expr2,
op);
break;
case and_and :
this.expressionstack[this.expressionptr] =
new and_and_expression(
expr1,
expr2,
op);
break;
case plus :
// look for "string1" + "string2"
if (this.optimizestringliterals) {
if (expr1 instanceof stringliteral) {
if (((expr1.bits & astnode.parenthesizedmask) >> astnode.parenthesizedshift) == 0) {
if (expr2 instanceof charliteral) { // string+char
this.expressionstack[this.expressionptr] =
((stringliteral) expr1).extendwith((charliteral) expr2);
} else if (expr2 instanceof stringliteral) { //string+string
this.expressionstack[this.expressionptr] =
((stringliteral) expr1).extendwith((stringliteral) expr2);
} else {
this.expressionstack[this.expressionptr] = new binaryexpression(expr1, expr2, plus);
}
} else {
this.expressionstack[this.expressionptr] = new binaryexpression(expr1, expr2, plus);
}
} else if (expr1 instanceof combinedbinaryexpression) {
combinedbinaryexpression cursor;
// left branch is comprised of plus bes
// cursor is shifted upwards, while needed bes are added
// on demand; past the aritymax-th
// consecutive be, a cbe is inserted that holds a
// full-fledged references table
if ((cursor = (combinedbinaryexpression)expr1).arity < cursor.aritymax) {
cursor.left = new binaryexpression(cursor);
cursor.arity++;
} else {
cursor.left = new combinedbinaryexpression(cursor);
cursor.arity = 0;
cursor.tunearitymax();
}
cursor.right = expr2;
cursor.sourceend = expr2.sourceend;
this.expressionstack[this.expressionptr] = cursor;
// be_instrumentation: neutralized in the released code
//					cursor.depthtracker = ((binaryexpression)cursor.left).
//						depthtracker + 1;
} else if (expr1 instanceof binaryexpression &&
// single out the a + b case, which is a be
// instead of a cbe (slightly more than a half of
// strings concatenation are one-deep binary
// expressions)
((expr1.bits & astnode.operatormask) >>
astnode.operatorshift) == operatorids.plus) {
this.expressionstack[this.expressionptr] =
new combinedbinaryexpression(expr1, expr2, plus, 1);
} else {
this.expressionstack[this.expressionptr] =
new binaryexpression(expr1, expr2, plus);
}
} else if (expr1 instanceof stringliteral) {
if (expr2 instanceof stringliteral
&& ((expr1.bits & astnode.parenthesizedmask) >> astnode.parenthesizedshift) == 0) {
// string + string
this.expressionstack[this.expressionptr] =
((stringliteral) expr1).extendswith((stringliteral) expr2);
} else {
// single out the a + b case
this.expressionstack[this.expressionptr] =
new binaryexpression(expr1, expr2, plus);
}
} else if (expr1 instanceof combinedbinaryexpression) {
combinedbinaryexpression cursor;
// shift cursor; create be/cbe as needed
if ((cursor = (combinedbinaryexpression)expr1).arity < cursor.aritymax) {
cursor.left = new binaryexpression(cursor);
// clear the bits on cursor
cursor.bits &= ~astnode.parenthesizedmask;
cursor.arity++;
} else {
cursor.left = new combinedbinaryexpression(cursor);
// clear the bits on cursor
cursor.bits &= ~astnode.parenthesizedmask;
cursor.arity = 0;
cursor.tunearitymax();
}
cursor.right = expr2;
cursor.sourceend = expr2.sourceend;
// be_instrumentation: neutralized in the released code
//					cursor.depthtracker = ((binaryexpression)cursor.left).
//						depthtracker + 1;
this.expressionstack[this.expressionptr] = cursor;
} else if (expr1 instanceof binaryexpression
&& ((expr1.bits & astnode.operatormask) >>
astnode.operatorshift) == operatorids.plus) {
// single out the a + b case
this.expressionstack[this.expressionptr] =
new combinedbinaryexpression(expr1, expr2, plus, 1);
} else {
this.expressionstack[this.expressionptr] =
new binaryexpression(expr1, expr2, plus);
}
break;
case less :
this.intptr--;
this.expressionstack[this.expressionptr] =
new binaryexpression(
expr1,
expr2,
op);
break;
default :
this.expressionstack[this.expressionptr] =
new binaryexpression(
expr1,
expr2,
op);
}
}
/**
* @@param op binary operator
*/
protected void consumebinaryexpressionwithname(int op) {
pushonexpressionstack(getunspecifiedreferenceoptimized());
this.expressionptr--;
this.expressionlengthptr--;
/*
if (op == or_or) {
this.expressionstack[this.expressionptr] =
new or_or_expression(
this.expressionstack[this.expressionptr + 1],
this.expressionstack[this.expressionptr],
op);
} else {
if (op == and_and) {
this.expressionstack[this.expressionptr] =
new and_and_expression(
this.expressionstack[this.expressionptr + 1],
this.expressionstack[this.expressionptr],
op);
} else {
// look for "string1" + "string2"
if ((op == plus) && this.optimizestringliterals) {
expression expr1, expr2;
expr1 = this.expressionstack[this.expressionptr + 1];
expr2 = this.expressionstack[this.expressionptr];
if (expr1 instanceof stringliteral) {
if (expr2 instanceof charliteral) { // string+char
this.expressionstack[this.expressionptr] =
((stringliteral) expr1).extendwith((charliteral) expr2);
} else if (expr2 instanceof stringliteral) { //string+string
this.expressionstack[this.expressionptr] =
((stringliteral) expr1).extendwith((stringliteral) expr2);
} else {
this.expressionstack[this.expressionptr] = new binaryexpression(expr1, expr2, plus);
}
} else {
this.expressionstack[this.expressionptr] = new binaryexpression(expr1, expr2, plus);
}
} else {
this.expressionstack[this.expressionptr] =
new binaryexpression(
this.expressionstack[this.expressionptr + 1],
this.expressionstack[this.expressionptr],
op);
}
}
}
*/
expression expr1 = this.expressionstack[this.expressionptr + 1];
expression expr2 = this.expressionstack[this.expressionptr];
// note: we do not attempt to promote binaryexpression-s to
//       indexedbinaryexpression-s here since expr1 always holds a name
switch(op) {
case or_or :
this.expressionstack[this.expressionptr] =
new or_or_expression(
expr1,
expr2,
op);
break;
case and_and :
this.expressionstack[this.expressionptr] =
new and_and_expression(
expr1,
expr2,
op);
break;
case plus :
// look for "string1" + "string2"
if (this.optimizestringliterals) {
if (expr1 instanceof stringliteral
&& ((expr1.bits & astnode.parenthesizedmask) >> astnode.parenthesizedshift) == 0) {
if (expr2 instanceof charliteral) { // string+char
this.expressionstack[this.expressionptr] =
((stringliteral) expr1).extendwith((charliteral) expr2);
} else if (expr2 instanceof stringliteral) { //string+string
this.expressionstack[this.expressionptr] =
((stringliteral) expr1).extendwith((stringliteral) expr2);
} else {
this.expressionstack[this.expressionptr] = new binaryexpression(expr1, expr2, plus);
}
} else {
this.expressionstack[this.expressionptr] = new binaryexpression(expr1, expr2, plus);
}
} else if (expr1 instanceof stringliteral) {
if (expr2 instanceof stringliteral
&& ((expr1.bits & astnode.parenthesizedmask) >> astnode.parenthesizedshift) == 0) {
// string + string
this.expressionstack[this.expressionptr] =
((stringliteral) expr1).extendswith((stringliteral) expr2);
} else {
this.expressionstack[this.expressionptr] =
new binaryexpression(
expr1,
expr2,
op);
}
} else {
this.expressionstack[this.expressionptr] =
new binaryexpression(
expr1,
expr2,
op);
}
break;
case less :
this.intptr--;
this.expressionstack[this.expressionptr] =
new binaryexpression(
expr1,
expr2,
op);
break;
default :
this.expressionstack[this.expressionptr] =
new binaryexpression(
expr1,
expr2,
op);
}
}
protected void consumeblock() {
// block ::= openblock '{' blockstatementsopt '}'
// simpler action for empty blocks

int statementslength = this.astlengthstack[this.astlengthptr--];
block block;
if (statementslength == 0) { // empty block
block = new block(0);
block.sourcestart = this.intstack[this.intptr--];
block.sourceend = this.endstatementposition;
// check whether this block at least contains some comment in it
if (!containscomment(block.sourcestart, block.sourceend)) {
block.bits |= astnode.undocumentedemptyblock;
}
this.realblockptr--; // still need to pop the block variable counter
} else {
block = new block(this.realblockstack[this.realblockptr--]);
this.astptr -= statementslength;
system.arraycopy(
this.aststack,
this.astptr + 1,
block.statements = new statement[statementslength],
0,
statementslength);
block.sourcestart = this.intstack[this.intptr--];
block.sourceend = this.endstatementposition;
}
pushonaststack(block);
}
protected void consumeblockstatements() {
// blockstatements ::= blockstatements blockstatement
concatnodelists();
}
protected void consumecaselabel() {
// switchlabel ::= 'case' constantexpression ':'
this.expressionlengthptr--;
expression expression = this.expressionstack[this.expressionptr--];
casestatement casestatement = new casestatement(expression, expression.sourceend, this.intstack[this.intptr--]);
// look for $fall-through$ tag in leading comment for case statement
if (hasleadingtagcomment(fall_through_tag, casestatement.sourcestart)) {
casestatement.bits |= astnode.documentedfallthrough;
}
pushonaststack(casestatement);
}
protected void consumecastexpressionll1() {
//castexpression ::= '(' expression ')' insidecastexpressionll1 unaryexpressionnotplusminus
// expression is used in order to make the grammar ll1

//optimize push/pop

expression cast,exp;
this.expressionptr--;
this.expressionstack[this.expressionptr] =
cast = new castexpression(
exp=this.expressionstack[this.expressionptr+1] ,
this.expressionstack[this.expressionptr]);
this.expressionlengthptr -- ;
updatesourceposition(cast);
cast.sourceend=exp.sourceend;
}
protected void consumecastexpressionwithgenericsarray() {
// castexpression ::= pushlparen name typearguments dims pushrparen insidecastexpression unaryexpressionnotplusminus

expression exp, cast, casttype;
int end = this.intstack[this.intptr--];

int dim = this.intstack[this.intptr--];
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);

this.expressionstack[this.expressionptr] = cast = new castexpression(exp = this.expressionstack[this.expressionptr], casttype = gettypereference(dim));
this.intptr--;
casttype.sourceend = end - 1;
casttype.sourcestart = (cast.sourcestart = this.intstack[this.intptr--]) + 1;
cast.sourceend = exp.sourceend;
}
protected void consumecastexpressionwithnamearray() {
// castexpression ::= pushlparen name dims pushrparen insidecastexpression unaryexpressionnotplusminus

expression exp, cast, casttype;
int end = this.intstack[this.intptr--];

// handle type arguments
pushongenericslengthstack(0);
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);

this.expressionstack[this.expressionptr] = cast = new castexpression(exp = this.expressionstack[this.expressionptr], casttype = gettypereference(this.intstack[this.intptr--]));
casttype.sourceend = end - 1;
casttype.sourcestart = (cast.sourcestart = this.intstack[this.intptr--]) + 1;
cast.sourceend = exp.sourceend;
}
protected void consumecastexpressionwithprimitivetype() {
// castexpression ::= pushlparen primitivetype dimsopt pushrparen insidecastexpression unaryexpression

//this.intstack : posofleftparen dim posofrightparen

//optimize the push/pop

expression exp, cast, casttype;
int end = this.intstack[this.intptr--];
this.expressionstack[this.expressionptr] = cast = new castexpression(exp = this.expressionstack[this.expressionptr], casttype = gettypereference(this.intstack[this.intptr--]));
casttype.sourceend = end - 1;
casttype.sourcestart = (cast.sourcestart = this.intstack[this.intptr--]) + 1;
cast.sourceend = exp.sourceend;
}
protected void consumecastexpressionwithqualifiedgenericsarray() {
// castexpression ::= pushlparen name onlytypearguments '.' classorinterfacetype dims pushrparen insidecastexpression unaryexpressionnotplusminus
expression exp, cast, casttype;
int end = this.intstack[this.intptr--];

int dim = this.intstack[this.intptr--];
typereference rightside = gettypereference(0);

parameterizedqualifiedtypereference qualifiedparameterizedtypereference = computequalifiedgenericsfromrightside(rightside, dim);
this.intptr--;
this.expressionstack[this.expressionptr] = cast = new castexpression(exp = this.expressionstack[this.expressionptr], casttype = qualifiedparameterizedtypereference);
casttype.sourceend = end - 1;
casttype.sourcestart = (cast.sourcestart = this.intstack[this.intptr--]) + 1;
cast.sourceend = exp.sourceend;
}
protected void consumecatches() {
// catches ::= catches catchclause
optimizedconcatnodelists();
}
protected void consumecatchheader() {
// catchdeclaration ::= 'catch' '(' formalparameter ')' '{'

if (this.currentelement == null){
return; // should never occur, this consumerule is only used in recovery mode
}
// current element should be a block due to the presence of the opening brace
if (!(this.currentelement instanceof recoveredblock)){
if(!(this.currentelement instanceof recoveredmethod)) {
return;
}
recoveredmethod rmethod = (recoveredmethod) this.currentelement;
if(!(rmethod.methodbody == null && rmethod.bracketbalance > 0)) {
return;
}
}

argument arg = (argument)this.aststack[this.astptr--];
// convert argument to local variable
localdeclaration localdeclaration = new localdeclaration(arg.name, arg.sourcestart, arg.sourceend);
localdeclaration.type = arg.type;
localdeclaration.declarationsourcestart = arg.declarationsourcestart;
localdeclaration.declarationsourceend = arg.declarationsourceend;

this.currentelement = this.currentelement.add(localdeclaration, 0);
this.lastcheckpoint = this.scanner.startposition; // force to restart at this exact position
this.restartrecovery = true; // request to restart from here on
this.lastignoredtoken = -1;
}
protected void consumeclassbodydeclaration() {
// classbodydeclaration ::= diet nestedmethod createinitializer block
//push an initializer
//optimize the push/pop
this.nestedmethod[this.nestedtype]--;
block block = (block) this.aststack[this.astptr--];
this.astlengthptr--;
if (this.diet) block.bits &= ~astnode.undocumentedemptyblock; // clear bit since was diet
initializer initializer = (initializer) this.aststack[this.astptr];
initializer.declarationsourcestart = initializer.sourcestart = block.sourcestart;
initializer.block = block;
this.intptr--; // pop sourcestart left on the stack by consumenestedmethod.
initializer.bodystart = this.intstack[this.intptr--];
this.realblockptr--; // pop the block variable counter left on the stack by consumenestedmethod
int javadoccommentstart = this.intstack[this.intptr--];
if (javadoccommentstart != -1) {
initializer.declarationsourcestart = javadoccommentstart;
initializer.javadoc = this.javadoc;
this.javadoc = null;
}
initializer.bodyend = this.endposition;
initializer.sourceend = this.endstatementposition;
initializer.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);
}
protected void consumeclassbodydeclarations() {
// classbodydeclarations ::= classbodydeclarations classbodydeclaration
concatnodelists();
}
protected void consumeclassbodydeclarationsopt() {
// classbodydeclarationsopt ::= nestedtype classbodydeclarations
this.nestedtype-- ;
}
protected void consumeclassbodyopt() {
// classbodyopt ::= $empty
pushonaststack(null);
this.endposition = this.rparenpos;
}
protected void consumeclassdeclaration() {
// classdeclaration ::= classheader classbody

int length;
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
//there are length declarations
//dispatch according to the type of the declarations
dispatchdeclarationinto(length);
}

typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];

//convert constructor that do not have the type's name into methods
boolean hasconstructor = typedecl.checkconstructors(this);

//add the default constructor when needed (interface don't have it)
if (!hasconstructor) {
switch(typedeclaration.kind(typedecl.modifiers)) {
case typedeclaration.class_decl :
case typedeclaration.enum_decl :
boolean insidefieldinitializer = false;
if (this.diet) {
for (int i = this.nestedtype; i > 0; i--){
if (this.variablescounter[i] > 0) {
insidefieldinitializer = true;
break;
}
}
}
typedecl.createdefaultconstructor(!this.diet || insidefieldinitializer, true);
}
}
//always add <clinit> (will be remove at code gen time if empty)
if (this.scanner.containsassertkeyword) {
typedecl.bits |= astnode.containsassertion;
}
typedecl.addclinit();
typedecl.bodyend = this.endstatementposition;
if (length == 0 && !containscomment(typedecl.bodystart, typedecl.bodyend)) {
typedecl.bits |= astnode.undocumentedemptyblock;
}

typedecl.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);
}
protected void consumeclassheader() {
// classheader ::= classheadername classheaderextendsopt classheaderimplementsopt

typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];
if (this.currenttoken == tokennamelbrace) {
typedecl.bodystart = this.scanner.currentposition;
}
if (this.currentelement != null) {
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
// flush the comments related to the class header
this.scanner.commentptr = -1;
}
protected void consumeclassheaderextends() {
// classheaderextends ::= 'extends' classtype
//superclass
typereference superclass = gettypereference(0);
// there is a class declaration on the top of stack
typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];
typedecl.superclass = superclass;
superclass.bits |= astnode.issupertype;
typedecl.bodystart = typedecl.superclass.sourceend + 1;
// recovery
if (this.currentelement != null){
this.lastcheckpoint = typedecl.bodystart;
}
}
protected void consumeclassheaderimplements() {
// classheaderimplements ::= 'implements' interfacetypelist
int length = this.astlengthstack[this.astlengthptr--];
//super interfaces
this.astptr -= length;
// there is a class declaration on the top of stack
typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];
system.arraycopy(
this.aststack,
this.astptr + 1,
typedecl.superinterfaces = new typereference[length],
0,
length);
for (int i = 0, max = typedecl.superinterfaces.length; i < max; i++) {
typedecl.superinterfaces[i].bits |= astnode.issupertype;
}
typedecl.bodystart = typedecl.superinterfaces[length-1].sourceend + 1;
this.listlength = 0; // reset after having read super-interfaces
// recovery
if (this.currentelement != null) { // is recovering
this.lastcheckpoint = typedecl.bodystart;
}
}
protected void consumeclassheadername1() {
// classheadername1 ::= modifiersopt 'class' 'identifier'
typedeclaration typedecl = new typedeclaration(this.compilationunit.compilationresult);
if (this.nestedmethod[this.nestedtype] == 0) {
if (this.nestedtype != 0) {
typedecl.bits |= astnode.ismembertype;
}
} else {
// record that the block has a declaration for local types
typedecl.bits |= astnode.islocaltype;
markenclosingmemberwithlocaltype();
blockreal();
}

//highlight the name of the type
long pos = this.identifierpositionstack[this.identifierptr];
typedecl.sourceend = (int) pos;
typedecl.sourcestart = (int) (pos >>> 32);
typedecl.name = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;

//compute the declaration source too
// 'class' and 'interface' push two int positions: the beginning of the class token and its end.
// we want to keep the beginning position but get rid of the end position
// it is only used for the classliteralaccess positions.
typedecl.declarationsourcestart = this.intstack[this.intptr--];
this.intptr--; // remove the end position of the class token

typedecl.modifierssourcestart = this.intstack[this.intptr--];
typedecl.modifiers = this.intstack[this.intptr--];
if (typedecl.modifierssourcestart >= 0) {
typedecl.declarationsourcestart = typedecl.modifierssourcestart;
}

// store secondary info
if ((typedecl.bits & astnode.ismembertype) == 0 && (typedecl.bits & astnode.islocaltype) == 0) {
if (this.compilationunit != null && !charoperation.equals(typedecl.name, this.compilationunit.getmaintypename())) {
typedecl.bits |= astnode.issecondarytype;
}
}

// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
typedecl.annotations = new annotation[length],
0,
length);
}
typedecl.bodystart = typedecl.sourceend + 1;
pushonaststack(typedecl);

this.listlength = 0; // will be updated when reading super-interfaces
// recovery
if (this.currentelement != null){
this.lastcheckpoint = typedecl.bodystart;
this.currentelement = this.currentelement.add(typedecl, 0);
this.lastignoredtoken = -1;
}
// javadoc
typedecl.javadoc = this.javadoc;
this.javadoc = null;
}
protected void consumeclassinstancecreationexpression() {
// classinstancecreationexpression ::= 'new' classtype '(' argumentlistopt ')' classbodyopt
classinstancecreation(false);
}
protected void consumeclassinstancecreationexpressionname() {
// classinstancecreationexpressionname ::= name '.'
pushonexpressionstack(getunspecifiedreferenceoptimized());
}
protected void consumeclassinstancecreationexpressionqualified() {
// classinstancecreationexpression ::= primary '.' 'new' simplename '(' argumentlistopt ')' classbodyopt
// classinstancecreationexpression ::= classinstancecreationexpressionname 'new' simplename '(' argumentlistopt ')' classbodyopt
classinstancecreation(true);

qualifiedallocationexpression qae =
(qualifiedallocationexpression) this.expressionstack[this.expressionptr];

if (qae.anonymoustype == null) {
this.expressionlengthptr--;
this.expressionptr--;
qae.enclosinginstance = this.expressionstack[this.expressionptr];
this.expressionstack[this.expressionptr] = qae;
}
qae.sourcestart = qae.enclosinginstance.sourcestart;
}
protected void consumeclassinstancecreationexpressionqualifiedwithtypearguments() {
// classinstancecreationexpression ::= primary '.' 'new' typearguments simplename '(' argumentlistopt ')' classbodyopt
// classinstancecreationexpression ::= classinstancecreationexpressionname 'new' typearguments simplename '(' argumentlistopt ')' classbodyopt

qualifiedallocationexpression alloc;
int length;
if (((length = this.astlengthstack[this.astlengthptr--]) == 1) && (this.aststack[this.astptr] == null)) {
//no classbody
this.astptr--;
alloc = new qualifiedallocationexpression();
alloc.sourceend = this.endposition; //the position has been stored explicitly

if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
alloc.arguments = new expression[length],
0,
length);
}
alloc.type = gettypereference(0);

length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, alloc.typearguments = new typereference[length], 0, length);
this.intptr--;

//the default constructor with the correct number of argument
//will be created and added by the tc (see createsinternalconstructorwithbinding)
alloc.sourcestart = this.intstack[this.intptr--];
pushonexpressionstack(alloc);
} else {
dispatchdeclarationinto(length);
typedeclaration anonymoustypedeclaration = (typedeclaration)this.aststack[this.astptr];
anonymoustypedeclaration.declarationsourceend = this.endstatementposition;
anonymoustypedeclaration.bodyend = this.endstatementposition;
if (length == 0 && !containscomment(anonymoustypedeclaration.bodystart, anonymoustypedeclaration.bodyend)) {
anonymoustypedeclaration.bits |= astnode.undocumentedemptyblock;
}
this.astptr--;
this.astlengthptr--;

qualifiedallocationexpression allocationexpression = anonymoustypedeclaration.allocation;
if (allocationexpression != null) {
allocationexpression.sourceend = this.endstatementposition;
// handle type arguments
length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, allocationexpression.typearguments = new typereference[length], 0, length);
allocationexpression.sourcestart = this.intstack[this.intptr--];
}
}

qualifiedallocationexpression qae =
(qualifiedallocationexpression) this.expressionstack[this.expressionptr];

if (qae.anonymoustype == null) {
this.expressionlengthptr--;
this.expressionptr--;
qae.enclosinginstance = this.expressionstack[this.expressionptr];
this.expressionstack[this.expressionptr] = qae;
}
qae.sourcestart = qae.enclosinginstance.sourcestart;
}
protected void consumeclassinstancecreationexpressionwithtypearguments() {
// classinstancecreationexpression ::= 'new' typearguments classtype '(' argumentlistopt ')' classbodyopt
allocationexpression alloc;
int length;
if (((length = this.astlengthstack[this.astlengthptr--]) == 1)
&& (this.aststack[this.astptr] == null)) {
//no classbody
this.astptr--;
alloc = new allocationexpression();
alloc.sourceend = this.endposition; //the position has been stored explicitly

if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
alloc.arguments = new expression[length],
0,
length);
}
alloc.type = gettypereference(0);

length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, alloc.typearguments = new typereference[length], 0, length);
this.intptr--;

//the default constructor with the correct number of argument
//will be created and added by the tc (see createsinternalconstructorwithbinding)
alloc.sourcestart = this.intstack[this.intptr--];
pushonexpressionstack(alloc);
} else {
dispatchdeclarationinto(length);
typedeclaration anonymoustypedeclaration = (typedeclaration)this.aststack[this.astptr];
anonymoustypedeclaration.declarationsourceend = this.endstatementposition;
anonymoustypedeclaration.bodyend = this.endstatementposition;
if (length == 0 && !containscomment(anonymoustypedeclaration.bodystart, anonymoustypedeclaration.bodyend)) {
anonymoustypedeclaration.bits |= astnode.undocumentedemptyblock;
}
this.astptr--;
this.astlengthptr--;

qualifiedallocationexpression allocationexpression = anonymoustypedeclaration.allocation;
if (allocationexpression != null) {
allocationexpression.sourceend = this.endstatementposition;
// handle type arguments
length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, allocationexpression.typearguments = new typereference[length], 0, length);
allocationexpression.sourcestart = this.intstack[this.intptr--];
}
}
}
protected void consumeclassorinterface() {
this.genericsidentifierslengthstack[this.genericsidentifierslengthptr] += this.identifierlengthstack[this.identifierlengthptr];
pushongenericslengthstack(0); // handle type arguments
}
protected void consumeclassorinterfacename() {
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0); // handle type arguments
}
protected void consumeclasstypeelt() {
// classtypeelt ::= classtype
pushonaststack(gettypereference(0));
/* if incomplete thrown exception list, this.listlength counter will not have been reset,
indicating that some items are available on the stack */
this.listlength++;
}
protected void consumeclasstypelist() {
// classtypelist ::= classtypelist ',' classtypeelt
optimizedconcatnodelists();
}
protected void consumecompilationunit() {
// compilationunit ::= entercompilationunit internalcompilationunit
// do nothing by default
}
protected void consumeconditionalexpression(int op) {
// conditionalexpression ::= conditionalorexpression '?' expression ':' conditionalexpression
//optimize the push/pop
this.intptr -= 2;//consume position of the question mark
this.expressionptr -= 2;
this.expressionlengthptr -= 2;
this.expressionstack[this.expressionptr] =
new conditionalexpression(
this.expressionstack[this.expressionptr],
this.expressionstack[this.expressionptr + 1],
this.expressionstack[this.expressionptr + 2]);
}
/**
* @@param op
*/
protected void consumeconditionalexpressionwithname(int op) {
// conditionalexpression ::= name '?' expression ':' conditionalexpression
this.intptr -= 2;//consume position of the question mark
pushonexpressionstack(getunspecifiedreferenceoptimized());
this.expressionptr -= 2;
this.expressionlengthptr -= 2;
this.expressionstack[this.expressionptr] =
new conditionalexpression(
this.expressionstack[this.expressionptr + 2],
this.expressionstack[this.expressionptr],
this.expressionstack[this.expressionptr + 1]);
}
protected void consumeconstructorblockstatements() {
// constructorbody ::= nestedmethod '{' explicitconstructorinvocation blockstatements '}'
concatnodelists(); // explictly add the first statement into the list of statements
}
protected void consumeconstructorbody() {
// constructorbody ::= nestedmethod  '{' blockstatementsopt '}'
// constructorbody ::= nestedmethod  '{' explicitconstructorinvocation '}'
this.nestedmethod[this.nestedtype] --;
}
protected void consumeconstructordeclaration() {
// constructordeclaration ::= constructorheader constructorbody

/*
this.aststack : methoddeclaration statements
this.identifierstack : name
==>
this.aststack : methoddeclaration
this.identifierstack :
*/

//must provide a default constructor call when needed

int length;

// pop the position of the {  (body of the method) pushed in block decl
this.intptr--;
this.intptr--;

//statements
this.realblockptr--;
explicitconstructorcall constructorcall = null;
statement[] statements = null;
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
this.astptr -= length;
if (!this.options.ignoremethodbodies) {
if (this.aststack[this.astptr + 1] instanceof explicitconstructorcall) {
//avoid a issomething that would only be used here but what is faster between two alternatives ?
system.arraycopy(
this.aststack,
this.astptr + 2,
statements = new statement[length - 1],
0,
length - 1);
constructorcall = (explicitconstructorcall) this.aststack[this.astptr + 1];
} else { //need to add explicitly the super();
system.arraycopy(
this.aststack,
this.astptr + 1,
statements = new statement[length],
0,
length);
constructorcall = superreference.implicitsuperconstructorcall();
}
}
} else {
boolean insidefieldinitializer = false;
if (this.diet) {
for (int i = this.nestedtype; i > 0; i--){
if (this.variablescounter[i] > 0) {
insidefieldinitializer = true;
break;
}
}
}

if (!this.diet || insidefieldinitializer){
// add it only in non-diet mode, if diet_bodies, then constructor call will be added elsewhere.
constructorcall = superreference.implicitsuperconstructorcall();
}
}

// now we know that the top of stack is a constructordeclaration
constructordeclaration cd = (constructordeclaration) this.aststack[this.astptr];
cd.constructorcall = constructorcall;
cd.statements = statements;

//highlight of the implicit call on the method name
if (constructorcall != null && cd.constructorcall.sourceend == 0) {
cd.constructorcall.sourceend = cd.sourceend;
cd.constructorcall.sourcestart = cd.sourcestart;
}

if (!(this.diet && this.dietint == 0)
&& statements == null
&& (constructorcall == null || constructorcall.isimplicitsuper())
&& !containscomment(cd.bodystart, this.endposition)) {
cd.bits |= astnode.undocumentedemptyblock;
}

//watch for } that could be given as a unicode ! ( u007d is '}' )
// store the this.endposition (position just before the '}') in case there is
// a trailing comment behind the end of the method
cd.bodyend = this.endposition;
cd.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);
}
protected void consumeconstructorheader() {
// constructorheader ::= constructorheadername methodheaderparameters methodheaderthrowsclauseopt

abstractmethoddeclaration method = (abstractmethoddeclaration)this.aststack[this.astptr];

if (this.currenttoken == tokennamelbrace){
method.bodystart = this.scanner.currentposition;
}
// recovery
if (this.currentelement != null){
if (this.currenttoken == tokennamesemicolon){ // for invalid constructors
method.modifiers |= extracompilermodifiers.accsemicolonbody;
method.declarationsourceend = this.scanner.currentposition-1;
method.bodyend = this.scanner.currentposition-1;
if (this.currentelement.parsetree() == method && this.currentelement.parent != null) {
this.currentelement = this.currentelement.parent;
}
}
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumeconstructorheadername() {

/* recovering - might be an empty message send */
if (this.currentelement != null){
if (this.lastignoredtoken == tokennamenew){ // was an allocation expression
this.lastcheckpoint = this.scanner.startposition; // force to restart at this exact position
this.restartrecovery = true;
return;
}
}

// constructorheadername ::=  modifiersopt 'identifier' '('
constructordeclaration cd = new constructordeclaration(this.compilationunit.compilationresult);

//name -- this is not really revelant but we do .....
cd.selector = this.identifierstack[this.identifierptr];
long selectorsource = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;

//modifiers
cd.declarationsourcestart = this.intstack[this.intptr--];
cd.modifiers = this.intstack[this.intptr--];
// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
cd.annotations = new annotation[length],
0,
length);
}
// javadoc
cd.javadoc = this.javadoc;
this.javadoc = null;

//highlight starts at the selector starts
cd.sourcestart = (int) (selectorsource >>> 32);
pushonaststack(cd);
cd.sourceend = this.lparenpos;
cd.bodystart = this.lparenpos+1;
this.listlength = 0; // initialize this.listlength before reading parameters/throws

// recovery
if (this.currentelement != null){
this.lastcheckpoint = cd.bodystart;
if ((this.currentelement instanceof recoveredtype && this.lastignoredtoken != tokennamedot)
|| cd.modifiers != 0){
this.currentelement = this.currentelement.add(cd, 0);
this.lastignoredtoken = -1;
}
}
}
protected void consumeconstructorheadernamewithtypeparameters() {

/* recovering - might be an empty message send */
if (this.currentelement != null){
if (this.lastignoredtoken == tokennamenew){ // was an allocation expression
this.lastcheckpoint = this.scanner.startposition; // force to restart at this exact position
this.restartrecovery = true;
return;
}
}

// constructorheadername ::=  modifiersopt typeparameters 'identifier' '('
constructordeclaration cd = new constructordeclaration(this.compilationunit.compilationresult);

//name -- this is not really revelant but we do .....
cd.selector = this.identifierstack[this.identifierptr];
long selectorsource = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;

// consume type parameters
int length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, cd.typeparameters = new typeparameter[length], 0, length);

//modifiers
cd.declarationsourcestart = this.intstack[this.intptr--];
cd.modifiers = this.intstack[this.intptr--];
// consume annotations
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
cd.annotations = new annotation[length],
0,
length);
}
// javadoc
cd.javadoc = this.javadoc;
this.javadoc = null;

//highlight starts at the selector starts
cd.sourcestart = (int) (selectorsource >>> 32);
pushonaststack(cd);
cd.sourceend = this.lparenpos;
cd.bodystart = this.lparenpos+1;
this.listlength = 0; // initialize this.listlength before reading parameters/throws

// recovery
if (this.currentelement != null){
this.lastcheckpoint = cd.bodystart;
if ((this.currentelement instanceof recoveredtype && this.lastignoredtoken != tokennamedot)
|| cd.modifiers != 0){
this.currentelement = this.currentelement.add(cd, 0);
this.lastignoredtoken = -1;
}
}
}
protected void consumecreateinitializer() {
pushonaststack(new initializer(null, 0));
}
protected void consumedefaultlabel() {
// switchlabel ::= 'default' ':'
casestatement defaultstatement = new casestatement(null, this.intstack[this.intptr--], this.intstack[this.intptr--]);
// look for $fall-through$ tag in leading comment for case statement
if (hasleadingtagcomment(fall_through_tag, defaultstatement.sourcestart)) {
defaultstatement.bits |= astnode.documentedfallthrough;
}
pushonaststack(defaultstatement);
}
protected void consumedefaultmodifiers() {
checkcomment(); // might update modifiers with accdeprecated
pushonintstack(this.modifiers); // modifiers
pushonintstack(
this.modifierssourcestart >= 0 ? this.modifierssourcestart : this.scanner.startposition);
resetmodifiers();
pushonexpressionstacklengthstack(0); // no annotation
}
protected void consumediet() {
// diet ::= $empty
checkcomment();
pushonintstack(this.modifierssourcestart); // push the start position of a javadoc comment if there is one
resetmodifiers();
jumpovermethodbody();
}
protected void consumedims() {
// dims ::= dimsloop
pushonintstack(this.dimensions);
this.dimensions = 0;
}
protected void consumedimwithorwithoutexpr() {
// dimwithorwithoutexpr ::= '[' ']'
pushonexpressionstack(null);

if(this.currentelement != null && this.currenttoken == tokennamelbrace) {
this.ignorenextopeningbrace = true;
this.currentelement.bracketbalance++;
}
}
protected void consumedimwithorwithoutexprs() {
// dimwithorwithoutexprs ::= dimwithorwithoutexprs dimwithorwithoutexpr
concatexpressionlists();
}
protected void consumeemptyannotationtypememberdeclarationsopt() {
// annotationtypememberdeclarationsopt ::= $empty
pushonastlengthstack(0);
}
protected void consumeemptyargumentlistopt() {
// argumentlistopt ::= $empty
pushonexpressionstacklengthstack(0);
}
protected void consumeemptyarguments() {
// argumentsopt ::= $empty
final fielddeclaration fielddeclaration = (fielddeclaration) this.aststack[this.astptr];
pushonintstack(fielddeclaration.sourceend);
pushonexpressionstacklengthstack(0);
}
protected void consumeemptyarrayinitializer() {
// arrayinitializer ::= '{' ,opt '}'
arrayinitializer(0);
}
protected void consumeemptyarrayinitializeropt() {
// arrayinitializeropt ::= $empty
pushonexpressionstacklengthstack(0);
}
protected void consumeemptyblockstatementsopt() {
// blockstatementsopt ::= $empty
pushonastlengthstack(0);
}
protected void consumeemptycatchesopt() {
// catchesopt ::= $empty
pushonastlengthstack(0);
}
protected void consumeemptyclassbodydeclarationsopt() {
// classbodydeclarationsopt ::= $empty
pushonastlengthstack(0);
}
protected void consumeemptydimsopt() {
// dimsopt ::= $empty
pushonintstack(0);
}
protected void consumeemptyenumdeclarations() {
// enumbodydeclarationsopt ::= $empty
pushonastlengthstack(0);
}
protected void consumeemptyexpression() {
// expressionopt ::= $empty
pushonexpressionstacklengthstack(0);
}
protected void consumeemptyforinitopt() {
// forinitopt ::= $empty
pushonastlengthstack(0);
}
protected void consumeemptyforupdateopt() {
// forupdateopt ::= $empty
pushonexpressionstacklengthstack(0);
}
protected void consumeemptyinterfacememberdeclarationsopt() {
// interfacememberdeclarationsopt ::= $empty
pushonastlengthstack(0);
}
protected void consumeemptyinternalcompilationunit() {
// internalcompilationunit ::= $empty
// nothing to do by default
if (this.compilationunit.ispackageinfo()) {
this.compilationunit.types = new typedeclaration[1];
this.compilationunit.createpackageinfotype();
}
}
protected void consumeemptymembervaluearrayinitializer() {
// membervaluearrayinitializer ::= '{' ',' '}'
// membervaluearrayinitializer ::= '{' '}'
arrayinitializer(0);
}
protected void consumeemptymembervaluepairsopt() {
// membervaluepairsopt ::= $empty
pushonastlengthstack(0);
}
protected void consumeemptymethodheaderdefaultvalue() {
// defaultvalueopt ::= $empty
abstractmethoddeclaration method = (abstractmethoddeclaration)this.aststack[this.astptr];
if(method.isannotationmethod()) { //'method' can be a methoddeclaration when recovery is started
pushonexpressionstacklengthstack(0);
}
this.recordstringliterals = true;
}
protected void consumeemptystatement() {
// emptystatement ::= ';'
char[] source = this.scanner.source;
if (source[this.endstatementposition] == ';') {
pushonaststack(new emptystatement(this.endstatementposition, this.endstatementposition));
} else {
if(source.length > 5) {
int c1 = 0, c2 = 0, c3 = 0, c4 = 0;
int pos = this.endstatementposition - 4;
while (source[pos] == 'u') {
pos--;
}
if (source[pos] == '\\' &&
!((c1 = scannerhelper.getnumericvalue(source[this.endstatementposition - 3])) > 15
|| c1 < 0
|| (c2 = scannerhelper.getnumericvalue(source[this.endstatementposition - 2])) > 15
|| c2 < 0
|| (c3 = scannerhelper.getnumericvalue(source[this.endstatementposition - 1])) > 15
|| c3 < 0
|| (c4 = scannerhelper.getnumericvalue(source[this.endstatementposition])) > 15
|| c4 < 0) &&
((char) (((c1 * 16 + c2) * 16 + c3) * 16 + c4)) == ';'){
// we have a unicode for the ';' (/u003b)
pushonaststack(new emptystatement(pos, this.endstatementposition));
return;
}
}
pushonaststack(new emptystatement(this.endposition + 1, this.endstatementposition));
}
}
protected void consumeemptyswitchblock() {
// switchblock ::= '{' '}'
pushonastlengthstack(0);
}
protected void consumeemptytypedeclaration() {
// classmemberdeclaration ::= ';'
// interfacememberdeclaration ::= ';'
// typedeclaration ::= ';'
pushonastlengthstack(0);
if(!this.statementrecoveryactivated) problemreporter().superfluoussemicolon(this.endposition+1, this.endstatementposition);
flushcommentsdefinedpriorto(this.endstatementposition);
}
protected void consumeenhancedforstatement() {
// enhancedforstatement ::= enhancedforstatementheader statement
// enhancedforstatementnoshortif ::= enhancedforstatementheader statementnoshortif

//statements
this.astlengthptr--;
statement statement = (statement) this.aststack[this.astptr--];

// foreach statement is on the ast stack
foreachstatement foreachstatement = (foreachstatement) this.aststack[this.astptr];
foreachstatement.action = statement;
// remember useful empty statement
if (statement instanceof emptystatement) statement.bits |= astnode.isusefulemptystatement;

foreachstatement.sourceend = this.endstatementposition;
}
protected void consumeenhancedforstatementheader(){
// enhancedforstatementheader ::= enhancedforstatementheaderinit ':' expression ')'
final foreachstatement statement = (foreachstatement) this.aststack[this.astptr];
//updates are on the expression stack
this.expressionlengthptr--;
final expression collection = this.expressionstack[this.expressionptr--];
statement.collection = collection;
statement.sourceend = this.rparenpos;

if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
problemreporter().invalidusageofforeachstatements(statement.elementvariable, collection);
}
}
protected void consumeenhancedforstatementheaderinit(boolean hasmodifiers) {
typereference type;

char[] identifiername = this.identifierstack[this.identifierptr];
long nameposition = this.identifierpositionstack[this.identifierptr];

localdeclaration localdeclaration = createlocaldeclaration(identifiername, (int) (nameposition >>> 32), (int) nameposition);
localdeclaration.declarationsourceend = localdeclaration.declarationend;

int extradims = this.intstack[this.intptr--];
this.identifierptr--;
this.identifierlengthptr--;
// remove fake modifiers/modifiers start
int declarationsourcestart = 0;
int modifiersvalue  = 0;
if (hasmodifiers) {
declarationsourcestart = this.intstack[this.intptr--];
modifiersvalue = this.intstack[this.intptr--];
} else {
this.intptr-=2;
}

type = gettypereference(this.intstack[this.intptr--] + extradims); // type dimension

// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--])!= 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
localdeclaration.annotations = new annotation[length],
0,
length);
}
if (hasmodifiers) {
localdeclaration.declarationsourcestart = declarationsourcestart;
localdeclaration.modifiers = modifiersvalue;
} else {
localdeclaration.declarationsourcestart = type.sourcestart;
}
localdeclaration.type = type;

foreachstatement iteratorforstatement =
new foreachstatement(
localdeclaration,
this.intstack[this.intptr--]);
pushonaststack(iteratorforstatement);

iteratorforstatement.sourceend = localdeclaration.declarationsourceend;
}
protected void consumeenteranonymousclassbody(boolean qualified) {
// enteranonymousclassbody ::= $empty
typereference typereference = gettypereference(0);

typedeclaration anonymoustype = new typedeclaration(this.compilationunit.compilationresult);
anonymoustype.name = charoperation.no_char;
anonymoustype.bits |= (astnode.isanonymoustype|astnode.islocaltype);
qualifiedallocationexpression alloc = new qualifiedallocationexpression(anonymoustype);
markenclosingmemberwithlocaltype();
pushonaststack(anonymoustype);

alloc.sourceend = this.rparenpos; //the position has been stored explicitly
int argumentlength;
if ((argumentlength = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= argumentlength;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
alloc.arguments = new expression[argumentlength],
0,
argumentlength);
}

if (qualified) {
this.expressionlengthptr--;
alloc.enclosinginstance = this.expressionstack[this.expressionptr--];
}

alloc.type = typereference;

anonymoustype.sourceend = alloc.sourceend;
//position at the type while it impacts the anonymous declaration
anonymoustype.sourcestart = anonymoustype.declarationsourcestart = alloc.type.sourcestart;
alloc.sourcestart = this.intstack[this.intptr--];
pushonexpressionstack(alloc);

anonymoustype.bodystart = this.scanner.currentposition;
this.listlength = 0; // will be updated when reading super-interfaces

// flush the comments related to the anonymous
this.scanner.commentptr = -1;

// recovery
if (this.currentelement != null){
this.lastcheckpoint = anonymoustype.bodystart;
this.currentelement = this.currentelement.add(anonymoustype, 0);
if (!(this.currentelement instanceof recoveredannotation)) {
this.currenttoken = 0; // opening brace already taken into account
} else {
this.ignorenextopeningbrace = true;
this.currentelement.bracketbalance++;
}
this.lastignoredtoken = -1;
}
}
protected void consumeentercompilationunit() {
// entercompilationunit ::= $empty
// do nothing by default
}
protected void consumeentermembervalue() {
// entermembervalue ::= $empty
if (this.currentelement != null && this.currentelement instanceof recoveredannotation) {
recoveredannotation recoveredannotation = (recoveredannotation)this.currentelement;
recoveredannotation.haspendingmembervaluename = true;
}
}
protected void consumeentermembervaluearrayinitializer() {
// entermembervaluearrayinitializer ::= $empty
if(this.currentelement != null) {
this.ignorenextopeningbrace = true;
this.currentelement.bracketbalance++;
}
}
protected void consumeentervariable() {
// entervariable ::= $empty
// do nothing by default

char[] identifiername = this.identifierstack[this.identifierptr];
long nameposition = this.identifierpositionstack[this.identifierptr];
int extendeddimension = this.intstack[this.intptr--];
abstractvariabledeclaration declaration;
// create the ast node
boolean islocaldeclaration = this.nestedmethod[this.nestedtype] != 0;
if (islocaldeclaration) {
// create the local variable declarations
declaration =
createlocaldeclaration(identifiername, (int) (nameposition >>> 32), (int) nameposition);
} else {
// create the field declaration
declaration =
createfielddeclaration(identifiername, (int) (nameposition >>> 32), (int) nameposition);
}

this.identifierptr--;
this.identifierlengthptr--;
typereference type;
int variableindex = this.variablescounter[this.nestedtype];
int typedim = 0;
if (variableindex == 0) {
// first variable of the declaration (fielddeclaration or localdeclaration)
if (islocaldeclaration) {
declaration.declarationsourcestart = this.intstack[this.intptr--];
declaration.modifiers = this.intstack[this.intptr--];
// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
declaration.annotations = new annotation[length],
0,
length);
}
type = gettypereference(typedim = this.intstack[this.intptr--]); // type dimension
if (declaration.declarationsourcestart == -1) {
// this is true if there is no modifiers for the local variable declaration
declaration.declarationsourcestart = type.sourcestart;
}
pushonaststack(type);
} else {
type = gettypereference(typedim = this.intstack[this.intptr--]); // type dimension
pushonaststack(type);
declaration.declarationsourcestart = this.intstack[this.intptr--];
declaration.modifiers = this.intstack[this.intptr--];
// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
declaration.annotations = new annotation[length],
0,
length);
}
// store javadoc only on first declaration as it is the same for all ones
fielddeclaration fielddeclaration = (fielddeclaration) declaration;
fielddeclaration.javadoc = this.javadoc;
}
this.javadoc = null;
} else {
type = (typereference) this.aststack[this.astptr - variableindex];
typedim = type.dimensions();
abstractvariabledeclaration previousvariable =
(abstractvariabledeclaration) this.aststack[this.astptr];
declaration.declarationsourcestart = previousvariable.declarationsourcestart;
declaration.modifiers = previousvariable.modifiers;
final annotation[] annotations = previousvariable.annotations;
if (annotations != null) {
final int annotationslength = annotations.length;
system.arraycopy(annotations, 0, declaration.annotations = new annotation[annotationslength], 0, annotationslength);
}
}

if (extendeddimension == 0) {
declaration.type = type;
} else {
int dimension = typedim + extendeddimension;
declaration.type = copydims(type, dimension);
}
this.variablescounter[this.nestedtype]++;
pushonaststack(declaration);
// recovery
if (this.currentelement != null) {
if (!(this.currentelement instanceof recoveredtype)
&& (this.currenttoken == tokennamedot
//|| declaration.modifiers != 0
|| (util.getlinenumber(declaration.type.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr)
!= util.getlinenumber((int) (nameposition >>> 32), this.scanner.lineends, 0, this.scanner.lineptr)))){
this.lastcheckpoint = (int) (nameposition >>> 32);
this.restartrecovery = true;
return;
}
if (islocaldeclaration){
localdeclaration localdecl = (localdeclaration) this.aststack[this.astptr];
this.lastcheckpoint = localdecl.sourceend + 1;
this.currentelement = this.currentelement.add(localdecl, 0);
} else {
fielddeclaration fielddecl = (fielddeclaration) this.aststack[this.astptr];
this.lastcheckpoint = fielddecl.sourceend + 1;
this.currentelement = this.currentelement.add(fielddecl, 0);
}
this.lastignoredtoken = -1;
}
}
protected void consumeenumbodynoconstants() {
// nothing to do
// the 0 on the astlengthstack has been pushed by enumbodydeclarationsopt
}
protected void consumeenumbodywithconstants() {
// merge the constants values with the class body
concatnodelists();
}
protected void consumeenumconstantheader() {
fielddeclaration enumconstant = (fielddeclaration) this.aststack[this.astptr];
boolean foundopeningbrace = this.currenttoken == tokennamelbrace;
if (foundopeningbrace){
// qualified allocation expression
typedeclaration anonymoustype = new typedeclaration(this.compilationunit.compilationresult);
anonymoustype.name = charoperation.no_char;
anonymoustype.bits |= (astnode.isanonymoustype|astnode.islocaltype);
final int start = this.scanner.startposition;
anonymoustype.declarationsourcestart = start;
anonymoustype.sourcestart = start;
anonymoustype.sourceend = start; // closing parenthesis
anonymoustype.modifiers = 0;
anonymoustype.bodystart = this.scanner.currentposition;
markenclosingmemberwithlocaltype();
consumenestedtype();
this.variablescounter[this.nestedtype]++;
pushonaststack(anonymoustype);
qualifiedallocationexpression allocationexpression = new qualifiedallocationexpression(anonymoustype);
allocationexpression.enumconstant = enumconstant;

// fill arguments if needed
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
allocationexpression.arguments = new expression[length],
0,
length);
}
enumconstant.initialization = allocationexpression;
} else {
allocationexpression allocationexpression = new allocationexpression();
allocationexpression.enumconstant = enumconstant;
// fill arguments if needed
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
allocationexpression.arguments = new expression[length],
0,
length);
}
enumconstant.initialization = allocationexpression;
}

// recovery
if (this.currentelement != null) {
if(foundopeningbrace) {
typedeclaration anonymoustype = (typedeclaration) this.aststack[this.astptr];
this.currentelement = this.currentelement.add(anonymoustype, 0);
this.lastcheckpoint = anonymoustype.bodystart;
this.lastignoredtoken = -1;
this.currenttoken = 0; // opening brace already taken into account
} else {
if(this.currenttoken == tokennamesemicolon) {
recoveredtype currenttype = currentrecoverytype();
if(currenttype != null) {
currenttype.insideenumconstantpart = false;
}
}
this.lastcheckpoint = this.scanner.startposition; // force to restart at this exact position
this.lastignoredtoken = -1;
this.restartrecovery = true;
}
}
}
protected void consumeenumconstantheadername() {
if (this.currentelement != null) {
if (!(this.currentelement instanceof recoveredtype
|| (this.currentelement instanceof recoveredfield && ((recoveredfield)this.currentelement).fielddeclaration.type == null))
|| (this.lastignoredtoken == tokennamedot)) {
this.lastcheckpoint = this.scanner.startposition;
this.restartrecovery = true;
return;
}
}
long nameposition = this.identifierpositionstack[this.identifierptr];
char[] constantname = this.identifierstack[this.identifierptr];
final int sourceend = (int) nameposition;
fielddeclaration enumconstant = createfielddeclaration(constantname, (int) (nameposition >>> 32), sourceend);
this.identifierptr--;
this.identifierlengthptr--;
enumconstant.modifierssourcestart = this.intstack[this.intptr--];
enumconstant.modifiers = this.intstack[this.intptr--];
enumconstant.declarationsourcestart = enumconstant.modifierssourcestart;

// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
enumconstant.annotations = new annotation[length],
0,
length);
}
pushonaststack(enumconstant);
if (this.currentelement != null){
this.lastcheckpoint = enumconstant.sourceend + 1;
this.currentelement = this.currentelement.add(enumconstant, 0);
}
// javadoc
enumconstant.javadoc = this.javadoc;
this.javadoc = null;
}
protected void consumeenumconstantnoclassbody() {
// set declarationend and declarationsourceend
int endofenumconstant = this.intstack[this.intptr--];
final fielddeclaration fielddeclaration = (fielddeclaration) this.aststack[this.astptr];
fielddeclaration.declarationend = endofenumconstant;
fielddeclaration.declarationsourceend = endofenumconstant;
}
protected void consumeenumconstants() {
concatnodelists();
}
protected void consumeenumconstantwithclassbody() {
dispatchdeclarationinto(this.astlengthstack[this.astlengthptr--]);
typedeclaration anonymoustype = (typedeclaration) this.aststack[this.astptr--]; // pop type
this.astlengthptr--;
anonymoustype.bodyend = this.endposition;
anonymoustype.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);
final fielddeclaration fielddeclaration = ((fielddeclaration) this.aststack[this.astptr]);
fielddeclaration.declarationend = this.endstatementposition;
fielddeclaration.declarationsourceend = anonymoustype.declarationsourceend;
this.intptr --; // remove end position of the arguments
this.variablescounter[this.nestedtype] = 0;
this.nestedtype--;
}
protected void consumeenumdeclaration() {
// enumdeclaration ::= enumheader classheaderimplementsopt enumbody
int length;
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
//there are length declarations
//dispatch according to the type of the declarations
dispatchdeclarationintoenumdeclaration(length);
}

typedeclaration enumdeclaration = (typedeclaration) this.aststack[this.astptr];

//convert constructor that do not have the type's name into methods
boolean hasconstructor = enumdeclaration.checkconstructors(this);

//add the default constructor when needed
if (!hasconstructor) {
boolean insidefieldinitializer = false;
if (this.diet) {
for (int i = this.nestedtype; i > 0; i--){
if (this.variablescounter[i] > 0) {
insidefieldinitializer = true;
break;
}
}
}
enumdeclaration.createdefaultconstructor(!this.diet || insidefieldinitializer, true);
}

//always add <clinit> (will be remove at code gen time if empty)
if (this.scanner.containsassertkeyword) {
enumdeclaration.bits |= astnode.containsassertion;
}
enumdeclaration.addclinit();
enumdeclaration.bodyend = this.endstatementposition;
if (length == 0 && !containscomment(enumdeclaration.bodystart, enumdeclaration.bodyend)) {
enumdeclaration.bits |= astnode.undocumentedemptyblock;
}

enumdeclaration.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);
}
protected void consumeenumdeclarations() {
// do nothing by default
}
protected void consumeenumheader() {
typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];
if (this.currenttoken == tokennamelbrace) {
typedecl.bodystart = this.scanner.currentposition;
}

if (this.currentelement != null) {
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}

// flush the comments related to the enum header
this.scanner.commentptr = -1;
}
protected void consumeenumheadername() {
// enumheadername ::= modifiersopt 'enum' identifier
typedeclaration enumdeclaration = new typedeclaration(this.compilationunit.compilationresult);
if (this.nestedmethod[this.nestedtype] == 0) {
if (this.nestedtype != 0) {
enumdeclaration.bits |= astnode.ismembertype;
}
} else {
// record that the block has a declaration for local types
//		markenclosingmemberwithlocaltype();
blockreal();
}
//highlight the name of the type
long pos = this.identifierpositionstack[this.identifierptr];
enumdeclaration.sourceend = (int) pos;
enumdeclaration.sourcestart = (int) (pos >>> 32);
enumdeclaration.name = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;

//compute the declaration source too
// 'class' and 'interface' push two int positions: the beginning of the class token and its end.
// we want to keep the beginning position but get rid of the end position
// it is only used for the classliteralaccess positions.
enumdeclaration.declarationsourcestart = this.intstack[this.intptr--];
this.intptr--; // remove the end position of the class token

enumdeclaration.modifierssourcestart = this.intstack[this.intptr--];
enumdeclaration.modifiers = this.intstack[this.intptr--] | classfileconstants.accenum;
if (enumdeclaration.modifierssourcestart >= 0) {
enumdeclaration.declarationsourcestart = enumdeclaration.modifierssourcestart;
}

// store secondary info
if ((enumdeclaration.bits & astnode.ismembertype) == 0 && (enumdeclaration.bits & astnode.islocaltype) == 0) {
if (this.compilationunit != null && !charoperation.equals(enumdeclaration.name, this.compilationunit.getmaintypename())) {
enumdeclaration.bits |= astnode.issecondarytype;
}
}

// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
enumdeclaration.annotations = new annotation[length],
0,
length);
}
//	if (this.currenttoken == tokennamelbrace) {
//		enumdeclaration.bodystart = this.scanner.currentposition;
//	}
enumdeclaration.bodystart = enumdeclaration.sourceend + 1;
pushonaststack(enumdeclaration);

this.listlength = 0; // will be updated when reading super-interfaces

if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
//todo this code will be never run while 'enum' is an identifier in 1.3 scanner
problemreporter().invalidusageofenumdeclarations(enumdeclaration);
}

// recovery
if (this.currentelement != null){
this.lastcheckpoint = enumdeclaration.bodystart;
this.currentelement = this.currentelement.add(enumdeclaration, 0);
this.lastignoredtoken = -1;
}
// javadoc
enumdeclaration.javadoc = this.javadoc;
this.javadoc = null;
}
protected void consumeenumheadernamewithtypeparameters() {
// enumheadernamewithtypeparameters ::= modifiersopt 'enum' identifier typeparameters
typedeclaration enumdeclaration = new typedeclaration(this.compilationunit.compilationresult);
// consume type parameters
int length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, enumdeclaration.typeparameters = new typeparameter[length], 0, length);

problemreporter().invalidusageoftypeparametersforenumdeclaration(enumdeclaration);

enumdeclaration.bodystart = enumdeclaration.typeparameters[length-1].declarationsourceend + 1;

//	enumdeclaration.typeparameters = null;

this.listtypeparameterlength = 0;

if (this.nestedmethod[this.nestedtype] == 0) {
if (this.nestedtype != 0) {
enumdeclaration.bits |= astnode.ismembertype;
}
} else {
// record that the block has a declaration for local types
//		markenclosingmemberwithlocaltype();
blockreal();
}
//highlight the name of the type
long pos = this.identifierpositionstack[this.identifierptr];
enumdeclaration.sourceend = (int) pos;
enumdeclaration.sourcestart = (int) (pos >>> 32);
enumdeclaration.name = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;

//compute the declaration source too
// 'class' and 'interface' push two int positions: the beginning of the class token and its end.
// we want to keep the beginning position but get rid of the end position
// it is only used for the classliteralaccess positions.
enumdeclaration.declarationsourcestart = this.intstack[this.intptr--];
this.intptr--; // remove the end position of the class token

enumdeclaration.modifierssourcestart = this.intstack[this.intptr--];
enumdeclaration.modifiers = this.intstack[this.intptr--] | classfileconstants.accenum;
if (enumdeclaration.modifierssourcestart >= 0) {
enumdeclaration.declarationsourcestart = enumdeclaration.modifierssourcestart;
}

// store secondary info
if ((enumdeclaration.bits & astnode.ismembertype) == 0 && (enumdeclaration.bits & astnode.islocaltype) == 0) {
if (this.compilationunit != null && !charoperation.equals(enumdeclaration.name, this.compilationunit.getmaintypename())) {
enumdeclaration.bits |= astnode.issecondarytype;
}
}

// consume annotations
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
enumdeclaration.annotations = new annotation[length],
0,
length);
}
//	if (this.currenttoken == tokennamelbrace) {
//		enumdeclaration.bodystart = this.scanner.currentposition;
//	}
enumdeclaration.bodystart = enumdeclaration.sourceend + 1;
pushonaststack(enumdeclaration);

this.listlength = 0; // will be updated when reading super-interfaces

if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
//todo this code will be never run while 'enum' is an identifier in 1.3 scanner
problemreporter().invalidusageofenumdeclarations(enumdeclaration);
}

// recovery
if (this.currentelement != null){
this.lastcheckpoint = enumdeclaration.bodystart;
this.currentelement = this.currentelement.add(enumdeclaration, 0);
this.lastignoredtoken = -1;
}
// javadoc
enumdeclaration.javadoc = this.javadoc;
this.javadoc = null;
}
protected void consumeequalityexpression(int op) {
// equalityexpression ::= equalityexpression '==' relationalexpression
// equalityexpression ::= equalityexpression '!=' relationalexpression

//optimize the push/pop

this.expressionptr--;
this.expressionlengthptr--;
this.expressionstack[this.expressionptr] =
new equalexpression(
this.expressionstack[this.expressionptr],
this.expressionstack[this.expressionptr + 1],
op);
}
/*
* @@param op
*/
protected void consumeequalityexpressionwithname(int op) {
// equalityexpression ::= name '==' relationalexpression
// equalityexpression ::= name '!=' relationalexpression
pushonexpressionstack(getunspecifiedreferenceoptimized());
this.expressionptr--;
this.expressionlengthptr--;
this.expressionstack[this.expressionptr] =
new equalexpression(
this.expressionstack[this.expressionptr + 1],
this.expressionstack[this.expressionptr],
op);
}
protected void consumeexitmembervalue() {
// exitmembervalue ::= $empty
if (this.currentelement != null && this.currentelement instanceof recoveredannotation) {
recoveredannotation recoveredannotation = (recoveredannotation)this.currentelement;
recoveredannotation.haspendingmembervaluename = false;
recoveredannotation.membervalupairequalend = -1;
}
}
protected void consumeexittryblock() {
//exittryblock ::= $empty
if(this.currentelement != null) {
this.restartrecovery = true;
}
}
protected void consumeexitvariablewithinitialization() {
// exitvariablewithinitialization ::= $empty
// do nothing by default
this.expressionlengthptr--;
abstractvariabledeclaration variabledecl = (abstractvariabledeclaration) this.aststack[this.astptr];
variabledecl.initialization = this.expressionstack[this.expressionptr--];
// we need to update the declarationsourceend of the local variable declaration to the
// source end position of the initialization expression
variabledecl.declarationsourceend = variabledecl.initialization.sourceend;
variabledecl.declarationend = variabledecl.initialization.sourceend;

recoveryexitfromvariable();
}
protected void consumeexitvariablewithoutinitialization() {
// exitvariablewithoutinitialization ::= $empty
// do nothing by default

abstractvariabledeclaration variabledecl = (abstractvariabledeclaration) this.aststack[this.astptr];
variabledecl.declarationsourceend = variabledecl.declarationend;
if(this.currentelement != null && this.currentelement instanceof recoveredfield) {
if(this.endstatementposition > variabledecl.sourceend) {
this.currentelement.updatesourceendifnecessary(this.endstatementposition);
}
}
recoveryexitfromvariable();
}
protected void consumeexplicitconstructorinvocation(int flag, int recflag) {

/* flag allows to distinguish 3 cases :
(0) :
explicitconstructorinvocation ::= 'this' '(' argumentlistopt ')' ';'
explicitconstructorinvocation ::= 'super' '(' argumentlistopt ')' ';'
(1) :
explicitconstructorinvocation ::= primary '.' 'super' '(' argumentlistopt ')' ';'
explicitconstructorinvocation ::= primary '.' 'this' '(' argumentlistopt ')' ';'
(2) :
explicitconstructorinvocation ::= name '.' 'super' '(' argumentlistopt ')' ';'
explicitconstructorinvocation ::= name '.' 'this' '(' argumentlistopt ')' ';'
*/
int startposition = this.intstack[this.intptr--];
explicitconstructorcall ecc = new explicitconstructorcall(recflag);
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(this.expressionstack, this.expressionptr + 1, ecc.arguments = new expression[length], 0, length);
}
switch (flag) {
case 0 :
ecc.sourcestart = startposition;
break;
case 1 :
this.expressionlengthptr--;
ecc.sourcestart = (ecc.qualification = this.expressionstack[this.expressionptr--]).sourcestart;
break;
case 2 :
ecc.sourcestart = (ecc.qualification = getunspecifiedreferenceoptimized()).sourcestart;
break;
}
pushonaststack(ecc);
ecc.sourceend = this.endstatementposition;
}
protected void consumeexplicitconstructorinvocationwithtypearguments(int flag, int recflag) {

/* flag allows to distinguish 3 cases :
(0) :
explicitconstructorinvocation ::= typearguments 'this' '(' argumentlistopt ')' ';'
explicitconstructorinvocation ::= typearguments 'super' '(' argumentlistopt ')' ';'
(1) :
explicitconstructorinvocation ::= primary '.' typearguments 'super' '(' argumentlistopt ')' ';'
explicitconstructorinvocation ::= primary '.' typearguments 'this' '(' argumentlistopt ')' ';'
(2) :
explicitconstructorinvocation ::= name '.' typearguments 'super' '(' argumentlistopt ')' ';'
explicitconstructorinvocation ::= name '.' typearguments 'this' '(' argumentlistopt ')' ';'
*/
int startposition = this.intstack[this.intptr--];
explicitconstructorcall ecc = new explicitconstructorcall(recflag);
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(this.expressionstack, this.expressionptr + 1, ecc.arguments = new expression[length], 0, length);
}
length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, ecc.typearguments = new typereference[length], 0, length);
ecc.typeargumentssourcestart = this.intstack[this.intptr--];

switch (flag) {
case 0 :
ecc.sourcestart = startposition;
break;
case 1 :
this.expressionlengthptr--;
ecc.sourcestart = (ecc.qualification = this.expressionstack[this.expressionptr--]).sourcestart;
break;
case 2 :
ecc.sourcestart = (ecc.qualification = getunspecifiedreferenceoptimized()).sourcestart;
break;
}

pushonaststack(ecc);
ecc.sourceend = this.endstatementposition;
}
protected void consumeexpressionstatement() {
// expressionstatement ::= statementexpression ';'
this.expressionlengthptr--;
expression expression = this.expressionstack[this.expressionptr--];
expression.statementend = this.endstatementposition;
pushonaststack(expression);
}
protected void consumefieldaccess(boolean issuperaccess) {
// fieldaccess ::= primary '.' 'identifier'
// fieldaccess ::= 'super' '.' 'identifier'

fieldreference fr =
new fieldreference(
this.identifierstack[this.identifierptr],
this.identifierpositionstack[this.identifierptr--]);
this.identifierlengthptr--;
if (issuperaccess) {
//considerates the fieldreference beginning at the 'super' ....
fr.sourcestart = this.intstack[this.intptr--];
fr.receiver = new superreference(fr.sourcestart, this.endposition);
pushonexpressionstack(fr);
} else {
//optimize push/pop
fr.receiver = this.expressionstack[this.expressionptr];
//fieldreference begins at the receiver
fr.sourcestart = fr.receiver.sourcestart;
this.expressionstack[this.expressionptr] = fr;
}
}
protected void consumefielddeclaration() {
// see consumelocalvariabledeclarationdefaultmodifier() in case of change: duplicated code
// fielddeclaration ::= modifiersopt type variabledeclarators ';'

/*
this.aststack :
this.expressionstack: expression expression ...... expression
this.identifierstack : type  identifier identifier ...... identifier
this.intstack : typedim      dim        dim               dim
==>
this.aststack : fielddeclaration fielddeclaration ...... fielddeclaration
this.expressionstack :
this.identifierstack :
this.intstack :

*/
int variabledeclaratorscounter = this.astlengthstack[this.astlengthptr];

for (int i = variabledeclaratorscounter - 1; i >= 0; i--) {
fielddeclaration fielddeclaration = (fielddeclaration) this.aststack[this.astptr - i];
fielddeclaration.declarationsourceend = this.endstatementposition;
fielddeclaration.declarationend = this.endstatementposition;	// semi-colon included
}

updatesourcedeclarationparts(variabledeclaratorscounter);
int endpos = flushcommentsdefinedpriorto(this.endstatementposition);
if (endpos != this.endstatementposition) {
for (int i = 0; i < variabledeclaratorscounter; i++) {
fielddeclaration fielddeclaration = (fielddeclaration) this.aststack[this.astptr - i];
fielddeclaration.declarationsourceend = endpos;
}
}
// update the this.aststack, this.astptr and this.astlengthstack
int startindex = this.astptr - this.variablescounter[this.nestedtype] + 1;
system.arraycopy(
this.aststack,
startindex,
this.aststack,
startindex - 1,
variabledeclaratorscounter);
this.astptr--; // remove the type reference
this.astlengthstack[--this.astlengthptr] = variabledeclaratorscounter;

// recovery
if (this.currentelement != null) {
this.lastcheckpoint = endpos + 1;
if (this.currentelement.parent != null && this.currentelement instanceof recoveredfield){
if (!(this.currentelement instanceof recoveredinitializer)) {
this.currentelement = this.currentelement.parent;
}
}
this.restartrecovery = true;
}
this.variablescounter[this.nestedtype] = 0;
}
protected void consumeforcenodiet() {
// forcenodiet ::= $empty
this.dietint++;
}
protected void consumeforinit() {
// forinit ::= statementexpressionlist
pushonastlengthstack(-1);
}
protected void consumeformalparameter(boolean isvarargs) {
// formalparameter ::= type variabledeclaratorid ==> false
// formalparameter ::= modifiers type variabledeclaratorid ==> true
/*
this.aststack :
this.identifierstack : type identifier
this.intstack : dim dim
==>
this.aststack : argument
this.identifierstack :
this.intstack :
*/

this.identifierlengthptr--;
char[] identifiername = this.identifierstack[this.identifierptr];
long namepositions = this.identifierpositionstack[this.identifierptr--];
int extendeddimensions = this.intstack[this.intptr--];
int endofellipsis = 0;
if (isvarargs) {
endofellipsis = this.intstack[this.intptr--];
}
int firstdimensions = this.intstack[this.intptr--];
final int typedimensions = firstdimensions + extendeddimensions;
typereference type = gettypereference(typedimensions);
if (isvarargs) {
type = copydims(type, typedimensions + 1);
if (extendeddimensions == 0) {
type.sourceend = endofellipsis;
}
type.bits |= astnode.isvarargs; // set isvarargs
}
int modifierpositions = this.intstack[this.intptr--];
this.intptr--;
argument arg =
new argument(
identifiername,
namepositions,
type,
this.intstack[this.intptr + 1] & ~classfileconstants.accdeprecated); // modifiers
arg.declarationsourcestart = modifierpositions;
// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
arg.annotations = new annotation[length],
0,
length);
}
pushonaststack(arg);

/* if incomplete method header, this.listlength counter will not have been reset,
indicating that some arguments are available on the stack */
this.listlength++;

if(isvarargs) {
if (!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
problemreporter().invalidusageofvarargs(arg);
} else if (!this.statementrecoveryactivated &&
extendeddimensions > 0) {
problemreporter().illegalextendeddimensions(arg);
}
}
}
protected void consumeformalparameterlist() {
// formalparameterlist ::= formalparameterlist ',' formalparameter
optimizedconcatnodelists();
}
protected void consumeformalparameterlistopt() {
// formalparameterlistopt ::= $empty
pushonastlengthstack(0);
}
protected void consumegenerictype() {
// nothing to do
// will be consume by a gettyperefence call
}
protected void consumegenerictypearraytype() {
// nothing to do
// will be consume by a gettyperefence call
}
protected void consumegenerictypenamearraytype() {
// nothing to do
// will be consume by a gettyperefence call
}
protected void consumeimportdeclaration() {
// singletypeimportdeclaration ::= singletypeimportdeclarationname ';'
importreference impt = (importreference) this.aststack[this.astptr];
// flush annotations defined prior to import statements
impt.declarationend = this.endstatementposition;
impt.declarationsourceend =
flushcommentsdefinedpriorto(impt.declarationsourceend);

// recovery
if (this.currentelement != null) {
this.lastcheckpoint = impt.declarationsourceend + 1;
this.currentelement = this.currentelement.add(impt, 0);
this.lastignoredtoken = -1;
this.restartrecovery = true;
// used to avoid branching back into the regular automaton
}
}
protected void consumeimportdeclarations() {
// importdeclarations ::= importdeclarations importdeclaration
optimizedconcatnodelists();
}
protected void consumeinsidecastexpression() {
// insidecastexpression ::= $empty
}
protected void consumeinsidecastexpressionll1() {
// insidecastexpressionll1 ::= $empty
pushongenericslengthstack(0); // handle type arguments
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushonexpressionstack(gettypereference(0));
}
protected void consumeinsidecastexpressionwithqualifiedgenerics() {
// insidecastexpressionwithqualifiedgenerics ::= $empty
}
protected void consumeinstanceofexpression() {
// relationalexpression ::= relationalexpression 'instanceof' referencetype
//optimize the push/pop

//by construction, no base type may be used in gettypereference
expression exp;
this.expressionstack[this.expressionptr] = exp =
new instanceofexpression(
this.expressionstack[this.expressionptr],
gettypereference(this.intstack[this.intptr--]));
if (exp.sourceend == 0) {
//array on base type....
exp.sourceend = this.scanner.startposition - 1;
}
//the scanner is on the next token already....
}
protected void consumeinstanceofexpressionwithname() {
// relationalexpression_notname ::= name instanceof referencetype
//optimize the push/pop

//by construction, no base type may be used in gettypereference
typereference reference = gettypereference(this.intstack[this.intptr--]);
pushonexpressionstack(getunspecifiedreferenceoptimized());
expression exp;
this.expressionstack[this.expressionptr] = exp =
new instanceofexpression(
this.expressionstack[this.expressionptr],
reference);
if (exp.sourceend == 0) {
//array on base type....
exp.sourceend = this.scanner.startposition - 1;
}
//the scanner is on the next token already....
}
protected void consumeinterfacedeclaration() {
// see consumeclassdeclaration in case of changes: duplicated code
// interfacedeclaration ::= interfaceheader interfacebody
int length;
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
//there are length declarations
//dispatch.....according to the type of the declarations
dispatchdeclarationinto(length);
}

typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];

//convert constructor that do not have the type's name into methods
typedecl.checkconstructors(this);

//always add <clinit> (will be remove at code gen time if empty)
if (this.scanner.containsassertkeyword) {
typedecl.bits |= astnode.containsassertion;
}
typedecl.addclinit();
typedecl.bodyend = this.endstatementposition;
if (length == 0 && !containscomment(typedecl.bodystart, typedecl.bodyend)) {
typedecl.bits |= astnode.undocumentedemptyblock;
}
typedecl.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);
}
protected void consumeinterfaceheader() {
// interfaceheader ::= interfaceheadername interfaceheaderextendsopt

typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];
if (this.currenttoken == tokennamelbrace){
typedecl.bodystart = this.scanner.currentposition;
}
if (this.currentelement != null){
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
// flush the comments related to the interface header
this.scanner.commentptr = -1;
}
protected void consumeinterfaceheaderextends() {
// interfaceheaderextends ::= 'extends' interfacetypelist
int length = this.astlengthstack[this.astlengthptr--];
//super interfaces
this.astptr -= length;
typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];
system.arraycopy(
this.aststack,
this.astptr + 1,
typedecl.superinterfaces = new typereference[length],
0,
length);
for (int i = 0, max = typedecl.superinterfaces.length; i < max; i++) {
typedecl.superinterfaces[i].bits |= astnode.issupertype;
}
typedecl.bodystart = typedecl.superinterfaces[length-1].sourceend + 1;
this.listlength = 0; // reset after having read super-interfaces
// recovery
if (this.currentelement != null) {
this.lastcheckpoint = typedecl.bodystart;
}
}
protected void consumeinterfaceheadername1() {
// interfaceheadername ::= modifiersopt 'interface' 'identifier'
typedeclaration typedecl = new typedeclaration(this.compilationunit.compilationresult);

if (this.nestedmethod[this.nestedtype] == 0) {
if (this.nestedtype != 0) {
typedecl.bits |= astnode.ismembertype;
}
} else {
// record that the block has a declaration for local types
typedecl.bits |= astnode.islocaltype;
markenclosingmemberwithlocaltype();
blockreal();
}

//highlight the name of the type
long pos = this.identifierpositionstack[this.identifierptr];
typedecl.sourceend = (int) pos;
typedecl.sourcestart = (int) (pos >>> 32);
typedecl.name = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;

//compute the declaration source too
// 'class' and 'interface' push two int positions: the beginning of the class token and its end.
// we want to keep the beginning position but get rid of the end position
// it is only used for the classliteralaccess positions.
typedecl.declarationsourcestart = this.intstack[this.intptr--];
this.intptr--; // remove the end position of the class token
typedecl.modifierssourcestart = this.intstack[this.intptr--];
typedecl.modifiers = this.intstack[this.intptr--] | classfileconstants.accinterface;
if (typedecl.modifierssourcestart >= 0) {
typedecl.declarationsourcestart = typedecl.modifierssourcestart;
}

// store secondary info
if ((typedecl.bits & astnode.ismembertype) == 0 && (typedecl.bits & astnode.islocaltype) == 0) {
if (this.compilationunit != null && !charoperation.equals(typedecl.name, this.compilationunit.getmaintypename())) {
typedecl.bits |= astnode.issecondarytype;
}
}

// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
typedecl.annotations = new annotation[length],
0,
length);
}
typedecl.bodystart = typedecl.sourceend + 1;
pushonaststack(typedecl);
this.listlength = 0; // will be updated when reading super-interfaces
// recovery
if (this.currentelement != null){ // is recovering
this.lastcheckpoint = typedecl.bodystart;
this.currentelement = this.currentelement.add(typedecl, 0);
this.lastignoredtoken = -1;
}
// javadoc
typedecl.javadoc = this.javadoc;
this.javadoc = null;
}
protected void consumeinterfacememberdeclarations() {
// interfacememberdeclarations ::= interfacememberdeclarations interfacememberdeclaration
concatnodelists();
}
protected void consumeinterfacememberdeclarationsopt() {
// interfacememberdeclarationsopt ::= nestedtype interfacememberdeclarations
this.nestedtype--;
}
protected void consumeinterfacetype() {
// interfacetype ::= classorinterfacetype
pushonaststack(gettypereference(0));
/* if incomplete type header, this.listlength counter will not have been reset,
indicating that some interfaces are available on the stack */
this.listlength++;
}
protected void consumeinterfacetypelist() {
// interfacetypelist ::= interfacetypelist ',' interfacetype
optimizedconcatnodelists();
}
protected void consumeinternalcompilationunit() {
// internalcompilationunit ::= packagedeclaration
// internalcompilationunit ::= packagedeclaration importdeclarations reduceimports
// internalcompilationunit ::= importdeclarations reduceimports
if (this.compilationunit.ispackageinfo()) {
this.compilationunit.types = new typedeclaration[1];
this.compilationunit.createpackageinfotype();
}
}
protected void consumeinternalcompilationunitwithtypes() {
// internalcompilationunit ::= packagedeclaration importdeclarations reduceimports typedeclarations
// internalcompilationunit ::= packagedeclaration typedeclarations
// internalcompilationunit ::= typedeclarations
// internalcompilationunit ::= importdeclarations reduceimports typedeclarations
// consume type declarations
int length;
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
if (this.compilationunit.ispackageinfo()) {
this.compilationunit.types = new typedeclaration[length + 1];
this.astptr -= length;
system.arraycopy(this.aststack, this.astptr + 1, this.compilationunit.types, 1, length);
this.compilationunit.createpackageinfotype();
} else {
this.compilationunit.types = new typedeclaration[length];
this.astptr -= length;
system.arraycopy(this.aststack, this.astptr + 1, this.compilationunit.types, 0, length);
}
}
}
protected void consumeinvalidannotationtypedeclaration() {
// blockstatement ::= annotationtypedeclaration
typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];
if(!this.statementrecoveryactivated) problemreporter().illegallocaltypedeclaration(typedecl);
// remove the ast node created in interface header
this.astptr--;
pushonastlengthstack(-1);
concatnodelists();
}
protected void consumeinvalidconstructordeclaration() {
// constructordeclaration ::= constructorheader ';'
// now we know that the top of stack is a constructordeclaration
constructordeclaration cd = (constructordeclaration) this.aststack[this.astptr];

cd.bodyend = this.endposition; // position just before the trailing semi-colon
cd.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);
// report the problem and continue the parsing - narrowing the problem onto the method

cd.modifiers |= extracompilermodifiers.accsemicolonbody; // remember semi-colon body
}
protected void consumeinvalidconstructordeclaration(boolean hasbody) {
// invalidconstructordeclaration ::= constructorheader constructorbody ==> true
// invalidconstructordeclaration ::= constructorheader ';' ==> false

/*
this.aststack : modifiers arguments throws statements
this.identifierstack : name
==>
this.aststack : methoddeclaration
this.identifierstack :
*/
if (hasbody) {
// pop the position of the {  (body of the method) pushed in block decl
this.intptr--;
}

//statements
if (hasbody) {
this.realblockptr--;
}

int length;
if (hasbody && ((length = this.astlengthstack[this.astlengthptr--]) != 0)) {
this.astptr -= length;
}
constructordeclaration constructordeclaration = (constructordeclaration) this.aststack[this.astptr];
constructordeclaration.bodyend = this.endstatementposition;
constructordeclaration.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);
if (!hasbody) {
constructordeclaration.modifiers |= extracompilermodifiers.accsemicolonbody;
}
}
protected void consumeinvalidenumdeclaration() {
// blockstatement ::= enumdeclaration
typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];
if(!this.statementrecoveryactivated) problemreporter().illegallocaltypedeclaration(typedecl);
// remove the ast node created in interface header
this.astptr--;
pushonastlengthstack(-1);
concatnodelists();
}
protected void consumeinvalidinterfacedeclaration() {
// blockstatement ::= invalidinterfacedeclaration
//interfacedeclaration ::= modifiersopt 'interface' 'identifier' extendsinterfacesopt interfaceheader interfacebody
typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];
if(!this.statementrecoveryactivated) problemreporter().illegallocaltypedeclaration(typedecl);
// remove the ast node created in interface header
this.astptr--;
pushonastlengthstack(-1);
concatnodelists();
}
protected void consumeinvalidmethoddeclaration() {
// interfacememberdeclaration ::= invalidmethoddeclaration

/*
this.aststack : modifiers arguments throws statements
this.identifierstack : type name
this.intstack : dim dim dim
==>
this.aststack : methoddeclaration
this.identifierstack :
this.intstack :
*/

// pop the position of the {  (body of the method) pushed in block decl
this.intptr--;
// retrieve end position of method declarator

//statements
this.realblockptr--;
int length;
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
this.astptr -= length;
}

//watch for } that could be given as a unicode ! ( u007d is '}' )
methoddeclaration md = (methoddeclaration) this.aststack[this.astptr];
md.bodyend = this.endposition;
md.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);

// report the problem and continue the parsing - narrowing the problem onto the method
if(!this.statementrecoveryactivated) problemreporter().abstractmethodneedingnobody(md);
}
protected void consumelabel() {
// do nothing
}
protected void consumeleftparen() {
// pushlparen ::= '('
pushonintstack(this.lparenpos);
}
protected void consumelocalvariabledeclaration() {
// localvariabledeclaration ::= modifiers type variabledeclarators ';'

/*
this.aststack :
this.expressionstack: expression expression ...... expression
this.identifierstack : type  identifier identifier ...... identifier
this.intstack : typedim      dim        dim               dim
==>
this.aststack : fielddeclaration fielddeclaration ...... fielddeclaration
this.expressionstack :
this.identifierstack :
this.intstack :

*/
int variabledeclaratorscounter = this.astlengthstack[this.astlengthptr];

// update the this.aststack, this.astptr and this.astlengthstack
int startindex = this.astptr - this.variablescounter[this.nestedtype] + 1;
system.arraycopy(
this.aststack,
startindex,
this.aststack,
startindex - 1,
variabledeclaratorscounter);
this.astptr--; // remove the type reference
this.astlengthstack[--this.astlengthptr] = variabledeclaratorscounter;
this.variablescounter[this.nestedtype] = 0;
}
protected void consumelocalvariabledeclarationstatement() {
// localvariabledeclarationstatement ::= localvariabledeclaration ';'
// see blockreal in case of change: duplicated code
// increment the amount of declared variables for this block
this.realblockstack[this.realblockptr]++;

// update source end to include the semi-colon
int variabledeclaratorscounter = this.astlengthstack[this.astlengthptr];
for (int i = variabledeclaratorscounter - 1; i >= 0; i--) {
localdeclaration localdeclaration = (localdeclaration) this.aststack[this.astptr - i];
localdeclaration.declarationsourceend = this.endstatementposition;
localdeclaration.declarationend = this.endstatementposition;	// semi-colon included
}

}
protected void consumemarkerannotation() {
// markerannotation ::= '@@' name
markerannotation markerannotation = null;

int oldindex = this.identifierptr;

typereference typereference = getannotationtype();
markerannotation = new markerannotation(typereference, this.intstack[this.intptr--]);
markerannotation.declarationsourceend = markerannotation.sourceend;
pushonexpressionstack(markerannotation);
if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
problemreporter().invalidusageofannotation(markerannotation);
}
this.recordstringliterals = true;

if (this.currentelement != null && this.currentelement instanceof recoveredannotation) {
this.currentelement = ((recoveredannotation)this.currentelement).addannotation(markerannotation, oldindex);
}
}
protected void consumemembervaluearrayinitializer() {
// membervaluearrayinitializer ::= '{' membervalues ',' '}'
// membervaluearrayinitializer ::= '{' membervalues '}'
arrayinitializer(this.expressionlengthstack[this.expressionlengthptr--]);
}
protected void consumemembervalueasname() {
pushonexpressionstack(getunspecifiedreferenceoptimized());
}
protected void consumemembervaluepair() {
// membervaluepair ::= simplename '=' membervalue
char[] simplename = this.identifierstack[this.identifierptr];
long position = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;
int end = (int) position;
int start = (int) (position >>> 32);
expression value = this.expressionstack[this.expressionptr--];
this.expressionlengthptr--;
membervaluepair membervaluepair = new membervaluepair(simplename, start, end, value);
pushonaststack(membervaluepair);

if (this.currentelement != null && this.currentelement instanceof recoveredannotation) {
recoveredannotation recoveredannotation = (recoveredannotation) this.currentelement;

recoveredannotation.setkind(recoveredannotation.normal);
}
}
protected void consumemembervaluepairs() {
// membervaluepairs ::= membervaluepairs ',' membervaluepair
concatnodelists();
}
protected void consumemembervalues() {
// membervalues ::= membervalues ',' membervalue
concatexpressionlists();
}
protected void consumemethodbody() {
// methodbody ::= nestedmethod '{' blockstatementsopt '}'
this.nestedmethod[this.nestedtype] --;
}
protected void consumemethoddeclaration(boolean isnotabstract) {
// methoddeclaration ::= methodheader methodbody
// abstractmethoddeclaration ::= methodheader ';'

/*
this.aststack : modifiers arguments throws statements
this.identifierstack : type name
this.intstack : dim dim dim
==>
this.aststack : methoddeclaration
this.identifierstack :
this.intstack :
*/

int length;
if (isnotabstract) {
// pop the position of the {  (body of the method) pushed in block decl
this.intptr--;
this.intptr--;
}

int explicitdeclarations = 0;
statement[] statements = null;
if (isnotabstract) {
//statements
explicitdeclarations = this.realblockstack[this.realblockptr--];
if (!this.options.ignoremethodbodies) {
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
system.arraycopy(
this.aststack,
(this.astptr -= length) + 1,
statements = new statement[length],
0,
length);
}
} else {
length = this.astlengthstack[this.astlengthptr--];
this.astptr -= length;
}
}

// now we know that we have a method declaration at the top of the ast stack
methoddeclaration md = (methoddeclaration) this.aststack[this.astptr];
md.statements = statements;
md.explicitdeclarations = explicitdeclarations;

// cannot be done in consumemethodheader because we have no idea whether or not there
// is a body when we reduce the method header
if (!isnotabstract) { //remember the fact that the method has a semicolon body
md.modifiers |= extracompilermodifiers.accsemicolonbody;
} else if (!(this.diet && this.dietint == 0) && statements == null && !containscomment(md.bodystart, this.endposition)) {
md.bits |= astnode.undocumentedemptyblock;
}
// store the this.endposition (position just before the '}') in case there is
// a trailing comment behind the end of the method
md.bodyend = this.endposition;
md.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);
}
protected void consumemethodheader() {
// methodheader ::= methodheadername methodheaderparameters methodheaderextendeddims throwsclauseopt
// annotationmethodheader ::= annotationmethodheadername formalparameterlistopt methodheaderrightparen methodheaderextendeddims annotationmethodheaderdefaultvalueopt
// recoverymethodheader ::= recoverymethodheadername formalparameterlistopt methodheaderrightparen methodheaderextendeddims annotationmethodheaderdefaultvalueopt
// recoverymethodheader ::= recoverymethodheadername formalparameterlistopt methodheaderrightparen methodheaderextendeddims methodheaderthrowsclause

// retrieve end position of method declarator
abstractmethoddeclaration method = (abstractmethoddeclaration)this.aststack[this.astptr];

if (this.currenttoken == tokennamelbrace){
method.bodystart = this.scanner.currentposition;
}
// recovery
if (this.currentelement != null){
//		if(method.isannotationmethod()) {
//			method.modifiers |= accsemicolonbody;
//			method.declarationsourceend = this.scanner.currentposition-1;
//			method.bodyend = this.scanner.currentposition-1;
//			this.currentelement = this.currentelement.parent;
//		} else
if (this.currenttoken == tokennamesemicolon /*&& !method.isannotationmethod()*/){
method.modifiers |= extracompilermodifiers.accsemicolonbody;
method.declarationsourceend = this.scanner.currentposition-1;
method.bodyend = this.scanner.currentposition-1;
if (this.currentelement.parsetree() == method && this.currentelement.parent != null) {
this.currentelement = this.currentelement.parent;
}
} else if(this.currenttoken == tokennamelbrace) {
if (this.currentelement instanceof recoveredmethod &&
((recoveredmethod)this.currentelement).methoddeclaration != method) {
this.ignorenextopeningbrace = true;
this.currentelement.bracketbalance++;
}
}
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumemethodheaderdefaultvalue() {
// methodheaderdefaultvalue ::= defaultvalue
methoddeclaration md = (methoddeclaration) this.aststack[this.astptr];


int length = this.expressionlengthstack[this.expressionlengthptr--];
if (length == 1) {
this.intptr--; // we get rid of the position of the default keyword
this.intptr--; // we get rid of the position of the default keyword
if(md.isannotationmethod()) {
((annotationmethoddeclaration)md).defaultvalue = this.expressionstack[this.expressionptr];
md.modifiers |=  classfileconstants.accannotationdefault;
}
this.expressionptr--;
this.recordstringliterals = true;
}

if(this.currentelement != null) {
if(md.isannotationmethod()) {
this.currentelement.updatesourceendifnecessary(((annotationmethoddeclaration)md).defaultvalue.sourceend);
}
}
}
protected void consumemethodheaderextendeddims() {
// methodheaderextendeddims ::= dimsopt
// now we update the returntype of the method
methoddeclaration md = (methoddeclaration) this.aststack[this.astptr];
int extendeddims = this.intstack[this.intptr--];
if(md.isannotationmethod()) {
((annotationmethoddeclaration)md).extendeddimensions = extendeddims;
}
if (extendeddims != 0) {
typereference returntype = md.returntype;
md.sourceend = this.endposition;
int dims = returntype.dimensions() + extendeddims;
md.returntype = copydims(returntype, dims);
if (this.currenttoken == tokennamelbrace){
md.bodystart = this.endposition + 1;
}
// recovery
if (this.currentelement != null){
this.lastcheckpoint = md.bodystart;
}
}
}
protected void consumemethodheadername(boolean isannotationmethod) {
// methodheadername ::= modifiersopt type 'identifier' '('
// annotationmethodheadername ::= modifiersopt type 'identifier' '('
// recoverymethodheadername ::= modifiersopt type 'identifier' '('
methoddeclaration md = null;
if(isannotationmethod) {
md = new annotationmethoddeclaration(this.compilationunit.compilationresult);
this.recordstringliterals = false;
} else {
md = new methoddeclaration(this.compilationunit.compilationresult);
}

//name
md.selector = this.identifierstack[this.identifierptr];
long selectorsource = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;
//type
md.returntype = gettypereference(this.intstack[this.intptr--]);
//modifiers
md.declarationsourcestart = this.intstack[this.intptr--];
md.modifiers = this.intstack[this.intptr--];
// consume annotations
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
md.annotations = new annotation[length],
0,
length);
}
// javadoc
md.javadoc = this.javadoc;
this.javadoc = null;

//highlight starts at selector start
md.sourcestart = (int) (selectorsource >>> 32);
pushonaststack(md);
md.sourceend = this.lparenpos;
md.bodystart = this.lparenpos+1;
this.listlength = 0; // initialize this.listlength before reading parameters/throws

// recovery
if (this.currentelement != null){
if (this.currentelement instanceof recoveredtype
//|| md.modifiers != 0
|| (util.getlinenumber(md.returntype.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr)
== util.getlinenumber(md.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr))){
this.lastcheckpoint = md.bodystart;
this.currentelement = this.currentelement.add(md, 0);
this.lastignoredtoken = -1;
} else {
this.lastcheckpoint = md.sourcestart;
this.restartrecovery = true;
}
}
}
protected void consumemethodheadernamewithtypeparameters(boolean isannotationmethod) {
// methodheadername ::= modifiersopt typeparameters type 'identifier' '('
// annotationmethodheadername ::= modifiersopt typeparameters type 'identifier' '('
// recoverymethodheadername ::= modifiersopt typeparameters type 'identifier' '('
methoddeclaration md = null;
if(isannotationmethod) {
md = new annotationmethoddeclaration(this.compilationunit.compilationresult);
this.recordstringliterals = false;
} else {
md = new methoddeclaration(this.compilationunit.compilationresult);
}

//name
md.selector = this.identifierstack[this.identifierptr];
long selectorsource = this.identifierpositionstack[this.identifierptr--];
this.identifierlengthptr--;
//type
md.returntype = gettypereference(this.intstack[this.intptr--]);

// consume type parameters
int length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, md.typeparameters = new typeparameter[length], 0, length);

//modifiers
md.declarationsourcestart = this.intstack[this.intptr--];
md.modifiers = this.intstack[this.intptr--];
// consume annotations
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
md.annotations = new annotation[length],
0,
length);
}
// javadoc
md.javadoc = this.javadoc;
this.javadoc = null;

//highlight starts at selector start
md.sourcestart = (int) (selectorsource >>> 32);
pushonaststack(md);
md.sourceend = this.lparenpos;
md.bodystart = this.lparenpos+1;
this.listlength = 0; // initialize this.listlength before reading parameters/throws

// recovery
if (this.currentelement != null){
boolean istype;
if ((istype = this.currentelement instanceof recoveredtype)
//|| md.modifiers != 0
|| (util.getlinenumber(md.returntype.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr)
== util.getlinenumber(md.sourcestart, this.scanner.lineends, 0, this.scanner.lineptr))){
if(istype) {
((recoveredtype) this.currentelement).pendingtypeparameters = null;
}
this.lastcheckpoint = md.bodystart;
this.currentelement = this.currentelement.add(md, 0);
this.lastignoredtoken = -1;
} else {
this.lastcheckpoint = md.sourcestart;
this.restartrecovery = true;
}
}
}
protected void consumemethodheaderrightparen() {
// methodheaderparameters ::= formalparameterlistopt ')'
int length = this.astlengthstack[this.astlengthptr--];
this.astptr -= length;
abstractmethoddeclaration md = (abstractmethoddeclaration) this.aststack[this.astptr];
md.sourceend = 	this.rparenpos;
//arguments
if (length != 0) {
system.arraycopy(
this.aststack,
this.astptr + 1,
md.arguments = new argument[length],
0,
length);
}
md.bodystart = this.rparenpos+1;
this.listlength = 0; // reset this.listlength after having read all parameters
// recovery
if (this.currentelement != null){
this.lastcheckpoint = md.bodystart;
if (this.currentelement.parsetree() == md) return;

// might not have been attached yet - in some constructor scenarii
if (md.isconstructor()){
if ((length != 0)
|| (this.currenttoken == tokennamelbrace)
|| (this.currenttoken == tokennamethrows)){
this.currentelement = this.currentelement.add(md, 0);
this.lastignoredtoken = -1;
}
}
}
}
protected void consumemethodheaderthrowsclause() {
// methodheaderthrowsclause ::= 'throws' classtypelist
int length = this.astlengthstack[this.astlengthptr--];
this.astptr -= length;
abstractmethoddeclaration md = (abstractmethoddeclaration) this.aststack[this.astptr];
system.arraycopy(
this.aststack,
this.astptr + 1,
md.thrownexceptions = new typereference[length],
0,
length);
md.sourceend = md.thrownexceptions[length-1].sourceend;
md.bodystart = md.thrownexceptions[length-1].sourceend + 1;
this.listlength = 0; // reset this.listlength after having read all thrown exceptions
// recovery
if (this.currentelement != null){
this.lastcheckpoint = md.bodystart;
}
}
protected void consumemethodinvocationname() {
// methodinvocation ::= name '(' argumentlistopt ')'

// when the name is only an identifier...we have a message send to "this" (implicit)

messagesend m = newmessagesend();
m.sourceend = this.rparenpos;
m.sourcestart =
(int) ((m.namesourceposition = this.identifierpositionstack[this.identifierptr]) >>> 32);
m.selector = this.identifierstack[this.identifierptr--];
if (this.identifierlengthstack[this.identifierlengthptr] == 1) {
m.receiver = thisreference.implicitthis();
this.identifierlengthptr--;
} else {
this.identifierlengthstack[this.identifierlengthptr]--;
m.receiver = getunspecifiedreference();
m.sourcestart = m.receiver.sourcestart;
}
pushonexpressionstack(m);
}
protected void consumemethodinvocationnamewithtypearguments() {
// methodinvocation ::= name '.' typearguments 'identifier' '(' argumentlistopt ')'

// when the name is only an identifier...we have a message send to "this" (implicit)

messagesend m = newmessagesendwithtypearguments();
m.sourceend = this.rparenpos;
m.sourcestart =
(int) ((m.namesourceposition = this.identifierpositionstack[this.identifierptr]) >>> 32);
m.selector = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;

// handle type arguments
int length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, m.typearguments = new typereference[length], 0, length);
this.intptr--;

m.receiver = getunspecifiedreference();
m.sourcestart = m.receiver.sourcestart;
pushonexpressionstack(m);
}
protected void consumemethodinvocationprimary() {
//optimize the push/pop
//methodinvocation ::= primary '.' 'identifier' '(' argumentlistopt ')'

messagesend m = newmessagesend();
m.sourcestart =
(int) ((m.namesourceposition = this.identifierpositionstack[this.identifierptr]) >>> 32);
m.selector = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;
m.receiver = this.expressionstack[this.expressionptr];
m.sourcestart = m.receiver.sourcestart;
m.sourceend = this.rparenpos;
this.expressionstack[this.expressionptr] = m;
}
protected void consumemethodinvocationprimarywithtypearguments() {
//optimize the push/pop
//methodinvocation ::= primary '.' typearguments 'identifier' '(' argumentlistopt ')'

messagesend m = newmessagesendwithtypearguments();
m.sourcestart =
(int) ((m.namesourceposition = this.identifierpositionstack[this.identifierptr]) >>> 32);
m.selector = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;

// handle type arguments
int length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, m.typearguments = new typereference[length], 0, length);
this.intptr--;

m.receiver = this.expressionstack[this.expressionptr];
m.sourcestart = m.receiver.sourcestart;
m.sourceend = this.rparenpos;
this.expressionstack[this.expressionptr] = m;
}
protected void consumemethodinvocationsuper() {
// methodinvocation ::= 'super' '.' 'identifier' '(' argumentlistopt ')'

messagesend m = newmessagesend();
m.sourcestart = this.intstack[this.intptr--]; // start position of the super keyword
m.sourceend = this.rparenpos;
m.namesourceposition = this.identifierpositionstack[this.identifierptr];
m.selector = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;
m.receiver = new superreference(m.sourcestart, this.endposition);
pushonexpressionstack(m);
}
protected void consumemethodinvocationsuperwithtypearguments() {
// methodinvocation ::= 'super' '.' typearguments 'identifier' '(' argumentlistopt ')'

messagesend m = newmessagesendwithtypearguments();
this.intptr--; // start position of the typearguments
m.sourceend = this.rparenpos;
m.namesourceposition = this.identifierpositionstack[this.identifierptr];
m.selector = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;

// handle type arguments
int length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, m.typearguments = new typereference[length], 0, length);
m.sourcestart = this.intstack[this.intptr--]; // start position of the super keyword

m.receiver = new superreference(m.sourcestart, this.endposition);
pushonexpressionstack(m);
}
protected void consumemodifiers() {
int savedmodifierssourcestart = this.modifierssourcestart;
checkcomment(); // might update modifiers with accdeprecated
pushonintstack(this.modifiers); // modifiers
if (this.modifierssourcestart >= savedmodifierssourcestart) {
this.modifierssourcestart = savedmodifierssourcestart;
}
pushonintstack(this.modifierssourcestart);
resetmodifiers();
}
protected void consumemodifiers2() {
this.expressionlengthstack[this.expressionlengthptr - 1] += this.expressionlengthstack[this.expressionlengthptr--];
}
protected void consumenamearraytype() {
pushongenericslengthstack(0); // handle type arguments
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
}
protected void consumenestedmethod() {
// nestedmethod ::= $empty
jumpovermethodbody();
this.nestedmethod[this.nestedtype] ++;
pushonintstack(this.scanner.currentposition);
consumeopenblock();
}
protected void consumenestedtype() {
// nestedtype ::= $empty
int length = this.nestedmethod.length;
if (++this.nestedtype >= length) {
system.arraycopy(
this.nestedmethod, 0,
this.nestedmethod = new int[length + 30], 0,
length);
// increase the size of the variablescounter as well. it has to be consistent with the size of the nestedmethod collection
system.arraycopy(
this.variablescounter, 0,
this.variablescounter = new int[length + 30], 0,
length);
}
this.nestedmethod[this.nestedtype] = 0;
this.variablescounter[this.nestedtype] = 0;
}
protected void consumenormalannotation() {
// normalannotation ::= '@@' name '(' membervaluepairsopt ')'
normalannotation normalannotation = null;

int oldindex = this.identifierptr;

typereference typereference = getannotationtype();
normalannotation = new normalannotation(typereference, this.intstack[this.intptr--]);
int length;
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
system.arraycopy(
this.aststack,
(this.astptr -= length) + 1,
normalannotation.membervaluepairs = new membervaluepair[length],
0,
length);
}
normalannotation.declarationsourceend = this.rparenpos;
pushonexpressionstack(normalannotation);

if(this.currentelement != null) {
annotationrecoverycheckpoint(normalannotation.sourcestart, normalannotation.declarationsourceend);

if (this.currentelement instanceof recoveredannotation) {
this.currentelement = ((recoveredannotation)this.currentelement).addannotation(normalannotation, oldindex);
}
}

if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
problemreporter().invalidusageofannotation(normalannotation);
}
this.recordstringliterals = true;
}
protected void consumeonedimloop() {
// onedimloop ::= '[' ']'
this.dimensions++;
}
protected void consumeonlysynchronized() {
// onlysynchronized ::= 'synchronized'
pushonintstack(this.synchronizedblocksourcestart);
resetmodifiers();
this.expressionlengthptr--;
}
protected void consumeonlytypearguments() {
if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
int length = this.genericslengthstack[this.genericslengthptr];
problemreporter().invalidusageoftypearguments(
(typereference)this.genericsstack[this.genericsptr - length + 1],
(typereference)this.genericsstack[this.genericsptr]);
}
}
protected void consumeonlytypeargumentsforcastexpression() {
// onlytypeargumentsforcastexpression ::= onlytypearguments
}
protected void consumeopenblock() {
// openblock ::= $empty

pushonintstack(this.scanner.startposition);
int stacklength = this.realblockstack.length;
if (++this.realblockptr >= stacklength) {
system.arraycopy(
this.realblockstack, 0,
this.realblockstack = new int[stacklength + stackincrement], 0,
stacklength);
}
this.realblockstack[this.realblockptr] = 0;
}
protected void consumepackagecomment() {
// get possible comment for syntax since 1.5
if(this.options.sourcelevel >= classfileconstants.jdk1_5) {
checkcomment();
resetmodifiers();
}
}
protected void consumepackagedeclaration() {
// packagedeclaration ::= 'package' name ';'
/* build an importref build from the last name
stored in the identifier stack. */

importreference impt = this.compilationunit.currentpackage;
this.compilationunit.javadoc = this.javadoc;
this.javadoc = null;
// flush comments defined prior to import statements
impt.declarationend = this.endstatementposition;
impt.declarationsourceend = flushcommentsdefinedpriorto(impt.declarationsourceend);
}
protected void consumepackagedeclarationname() {
// packagedeclarationname ::= 'package' name
/* build an importref build from the last name
stored in the identifier stack. */

importreference impt;
int length;
char[][] tokens =
new char[length = this.identifierlengthstack[this.identifierlengthptr--]][];
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(this.identifierstack, ++this.identifierptr, tokens, 0, length);
system.arraycopy(
this.identifierpositionstack,
this.identifierptr--,
positions,
0,
length);

impt = new importreference(tokens, positions, true, classfileconstants.accdefault);
this.compilationunit.currentpackage = impt;

if (this.currenttoken == tokennamesemicolon){
impt.declarationsourceend = this.scanner.currentposition - 1;
} else {
impt.declarationsourceend = impt.sourceend;
}
impt.declarationend = impt.declarationsourceend;
//this.endposition is just before the ;
impt.declarationsourcestart = this.intstack[this.intptr--];

// get possible comment source start
if(this.javadoc != null) {
impt.declarationsourcestart = this.javadoc.sourcestart;
}

// recovery
if (this.currentelement != null){
this.lastcheckpoint = impt.declarationsourceend+1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumepackagedeclarationnamewithmodifiers() {
// packagedeclarationname ::= modifiers 'package' name
/* build an importref build from the last name
stored in the identifier stack. */

importreference impt;
int length;
char[][] tokens =
new char[length = this.identifierlengthstack[this.identifierlengthptr--]][];
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(this.identifierstack, ++this.identifierptr, tokens, 0, length);
system.arraycopy(
this.identifierpositionstack,
this.identifierptr--,
positions,
0,
length);

int packagemodifierssourcestart = this.intstack[this.intptr--]; // we don't need the modifiers start
int packagemodifiers = this.intstack[this.intptr--];

impt = new importreference(tokens, positions, true, packagemodifiers);
this.compilationunit.currentpackage = impt;
// consume annotations
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
impt.annotations = new annotation[length],
0,
length);
impt.declarationsourcestart = packagemodifierssourcestart;
this.intptr--; // we don't need the position of the 'package keyword
} else {
impt.declarationsourcestart = this.intstack[this.intptr--];
// get possible comment source start
if (this.javadoc != null) {
impt.declarationsourcestart = this.javadoc.sourcestart;
}
}

if (this.currenttoken == tokennamesemicolon){
impt.declarationsourceend = this.scanner.currentposition - 1;
} else {
impt.declarationsourceend = impt.sourceend;
}
impt.declarationend = impt.declarationsourceend;

// recovery
if (this.currentelement != null){
this.lastcheckpoint = impt.declarationsourceend+1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumepostfixexpression() {
// postfixexpression ::= name
pushonexpressionstack(getunspecifiedreferenceoptimized());
}
protected void consumeprimarynonewarray() {
// primarynonewarray ::=  pushlparen expression pushrparen
final expression parenthesizedexpression = this.expressionstack[this.expressionptr];
updatesourceposition(parenthesizedexpression);
int numberofparenthesis = (parenthesizedexpression.bits & astnode.parenthesizedmask) >> astnode.parenthesizedshift;
parenthesizedexpression.bits &= ~astnode.parenthesizedmask;
parenthesizedexpression.bits |= (numberofparenthesis + 1) << astnode.parenthesizedshift;
}
protected void consumeprimarynonewarrayarraytype() {
// primarynonewarray ::= name dims '.' 'class'
this.intptr--; // remove the class start position

pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0);

pushonexpressionstack(
new classliteralaccess(this.intstack[this.intptr--], gettypereference(this.intstack[this.intptr--])));
}
protected void consumeprimarynonewarrayname() {
// primarynonewarray ::= name '.' 'class'
this.intptr--; // remove the class start position

// handle type arguments
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0);
typereference typereference = gettypereference(0);

pushonexpressionstack(
new classliteralaccess(this.intstack[this.intptr--], typereference));
}
protected void consumeprimarynonewarraynamesuper() {
// primarynonewarray ::= name '.' 'super'
// handle type arguments
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0);
typereference typereference = gettypereference(0);

pushonexpressionstack(
new qualifiedsuperreference(
typereference,
this.intstack[this.intptr--],
this.endposition));
}
protected void consumeprimarynonewarraynamethis() {
// primarynonewarray ::= name '.' 'this'
// handle type arguments
pushongenericsidentifierslengthstack(this.identifierlengthstack[this.identifierlengthptr]);
pushongenericslengthstack(0); // handle type arguments

typereference typereference = gettypereference(0);

pushonexpressionstack(
new qualifiedthisreference(
typereference,
this.intstack[this.intptr--],
this.endposition));
}
protected void consumeprimarynonewarrayprimitivearraytype() {
// primarynonewarray ::= primitivetype dims '.' 'class'
this.intptr--; // remove the class start position
pushonexpressionstack(
new classliteralaccess(this.intstack[this.intptr--], gettypereference(this.intstack[this.intptr--])));
}
protected void consumeprimarynonewarrayprimitivetype() {
// primarynonewarray ::= primitivetype '.' 'class'
this.intptr--; // remove the class start position
pushonexpressionstack(
new classliteralaccess(this.intstack[this.intptr--], gettypereference(0)));
}
protected void consumeprimarynonewarraythis() {
// primarynonewarray ::= 'this'
pushonexpressionstack(new thisreference(this.intstack[this.intptr--], this.endposition));
}
protected void consumeprimarynonewarraywithname() {
// primarynonewarray ::=  pushlparen expression pushrparen
pushonexpressionstack(getunspecifiedreferenceoptimized());
final expression parenthesizedexpression = this.expressionstack[this.expressionptr];
updatesourceposition(parenthesizedexpression);
int numberofparenthesis = (parenthesizedexpression.bits & astnode.parenthesizedmask) >> astnode.parenthesizedshift;
parenthesizedexpression.bits &= ~astnode.parenthesizedmask;
parenthesizedexpression.bits |= (numberofparenthesis + 1) << astnode.parenthesizedshift;
}
protected void consumeprimitivearraytype() {
// nothing to do
// will be consume by a gettyperefence call
}
protected void consumeprimitivetype() {
// type ::= primitivetype
pushonintstack(0);
}
protected void consumepushleftbrace() {
pushonintstack(this.endposition); // modifiers
}
protected void consumepushmodifiers() {
pushonintstack(this.modifiers); // modifiers
pushonintstack(this.modifierssourcestart);
resetmodifiers();
pushonexpressionstacklengthstack(0);
}
protected void consumepushmodifiersforheader() {
checkcomment(); // might update modifiers with accdeprecated
pushonintstack(this.modifiers); // modifiers
pushonintstack(this.modifierssourcestart);
resetmodifiers();
pushonexpressionstacklengthstack(0);
}
protected void consumepushposition() {
// for source managment purpose
// pushposition ::= $empty
pushonintstack(this.endposition);
}
protected void consumepushrealmodifiers() {
checkcomment(); // might update modifiers with accdeprecated
pushonintstack(this.modifiers); // modifiers
pushonintstack(this.modifierssourcestart);
resetmodifiers();
}
protected void consumequalifiedname() {
// qualifiedname ::= name '.' simplename
/*back from the recursive loop of qualifiedname.
updates identifier length into the length stack*/

this.identifierlengthstack[--this.identifierlengthptr]++;
}
protected void consumerecoverymethodheadername() {
// this method is call only inside recovery
boolean isannotationmethod = false;
if(this.currentelement instanceof recoveredtype) {
isannotationmethod = (((recoveredtype)this.currentelement).typedeclaration.modifiers & classfileconstants.accannotation) != 0;
} else {
recoveredtype recoveredtype = this.currentelement.enclosingtype();
if(recoveredtype != null) {
isannotationmethod = (recoveredtype.typedeclaration.modifiers & classfileconstants.accannotation) != 0;
}
}
consumemethodheadername(isannotationmethod);
}
protected void consumerecoverymethodheadernamewithtypeparameters() {
// this method is call only inside recovery
boolean isannotationmethod = false;
if(this.currentelement instanceof recoveredtype) {
isannotationmethod = (((recoveredtype)this.currentelement).typedeclaration.modifiers & classfileconstants.accannotation) != 0;
} else {
recoveredtype recoveredtype = this.currentelement.enclosingtype();
if(recoveredtype != null) {
isannotationmethod = (recoveredtype.typedeclaration.modifiers & classfileconstants.accannotation) != 0;
}
}
consumemethodheadernamewithtypeparameters(isannotationmethod);
}
protected void consumereduceimports() {
// consume imports
int length;
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
this.astptr -= length;
system.arraycopy(
this.aststack,
this.astptr + 1,
this.compilationunit.imports = new importreference[length],
0,
length);
}
}
protected void consumereferencetype() {
pushonintstack(0); // handle array type
}
protected void consumereferencetype1() {
pushongenericsstack(gettypereference(this.intstack[this.intptr--]));
}
protected void consumereferencetype2() {
pushongenericsstack(gettypereference(this.intstack[this.intptr--]));
}
protected void consumereferencetype3() {
pushongenericsstack(gettypereference(this.intstack[this.intptr--]));
}
protected void consumerestorediet() {
// restorediet ::= $empty
this.dietint--;
}
protected void consumerightparen() {
// pushrparen ::= ')'
pushonintstack(this.rparenpos);
}
// this method is part of an automatic generation : do not edit-modify
protected void consumerule(int act) {
switch ( act ) {
case 30 : if (debug) { system.out.println("type ::= primitivetype"); }  //$non-nls-1$
consumeprimitivetype();
break;

case 44 : if (debug) { system.out.println("referencetype ::= classorinterfacetype"); }  //$non-nls-1$
consumereferencetype();
break;

case 48 : if (debug) { system.out.println("classorinterface ::= name"); }  //$non-nls-1$
consumeclassorinterfacename();
break;

case 49 : if (debug) { system.out.println("classorinterface ::= generictype dot name"); }  //$non-nls-1$
consumeclassorinterface();
break;

case 50 : if (debug) { system.out.println("generictype ::= classorinterface typearguments"); }  //$non-nls-1$
consumegenerictype();
break;

case 51 : if (debug) { system.out.println("arraytypewithtypeargumentsname ::= generictype dot name"); }  //$non-nls-1$
consumearraytypewithtypeargumentsname();
break;

case 52 : if (debug) { system.out.println("arraytype ::= primitivetype dims"); }  //$non-nls-1$
consumeprimitivearraytype();
break;

case 53 : if (debug) { system.out.println("arraytype ::= name dims"); }  //$non-nls-1$
consumenamearraytype();
break;

case 54 : if (debug) { system.out.println("arraytype ::= arraytypewithtypeargumentsname dims"); }  //$non-nls-1$
consumegenerictypenamearraytype();
break;

case 55 : if (debug) { system.out.println("arraytype ::= generictype dims"); }  //$non-nls-1$
consumegenerictypearraytype();
break;

case 60 : if (debug) { system.out.println("qualifiedname ::= name dot simplename"); }  //$non-nls-1$
consumequalifiedname();
break;

case 61 : if (debug) { system.out.println("compilationunit ::= entercompilationunit..."); }  //$non-nls-1$
consumecompilationunit();
break;

case 62 : if (debug) { system.out.println("internalcompilationunit ::= packagedeclaration"); }  //$non-nls-1$
consumeinternalcompilationunit();
break;

case 63 : if (debug) { system.out.println("internalcompilationunit ::= packagedeclaration..."); }  //$non-nls-1$
consumeinternalcompilationunit();
break;

case 64 : if (debug) { system.out.println("internalcompilationunit ::= packagedeclaration..."); }  //$non-nls-1$
consumeinternalcompilationunitwithtypes();
break;

case 65 : if (debug) { system.out.println("internalcompilationunit ::= packagedeclaration..."); }  //$non-nls-1$
consumeinternalcompilationunitwithtypes();
break;

case 66 : if (debug) { system.out.println("internalcompilationunit ::= importdeclarations..."); }  //$non-nls-1$
consumeinternalcompilationunit();
break;

case 67 : if (debug) { system.out.println("internalcompilationunit ::= typedeclarations"); }  //$non-nls-1$
consumeinternalcompilationunitwithtypes();
break;

case 68 : if (debug) { system.out.println("internalcompilationunit ::= importdeclarations..."); }  //$non-nls-1$
consumeinternalcompilationunitwithtypes();
break;

case 69 : if (debug) { system.out.println("internalcompilationunit ::="); }  //$non-nls-1$
consumeemptyinternalcompilationunit();
break;

case 70 : if (debug) { system.out.println("reduceimports ::="); }  //$non-nls-1$
consumereduceimports();
break;

case 71 : if (debug) { system.out.println("entercompilationunit ::="); }  //$non-nls-1$
consumeentercompilationunit();
break;

case 87 : if (debug) { system.out.println("catchheader ::= catch lparen formalparameter rparen..."); }  //$non-nls-1$
consumecatchheader();
break;

case 89 : if (debug) { system.out.println("importdeclarations ::= importdeclarations..."); }  //$non-nls-1$
consumeimportdeclarations();
break;

case 91 : if (debug) { system.out.println("typedeclarations ::= typedeclarations typedeclaration"); }  //$non-nls-1$
consumetypedeclarations();
break;

case 92 : if (debug) { system.out.println("packagedeclaration ::= packagedeclarationname semicolon"); }  //$non-nls-1$
consumepackagedeclaration();
break;

case 93 : if (debug) { system.out.println("packagedeclarationname ::= modifiers package..."); }  //$non-nls-1$
consumepackagedeclarationnamewithmodifiers();
break;

case 94 : if (debug) { system.out.println("packagedeclarationname ::= packagecomment package name"); }  //$non-nls-1$
consumepackagedeclarationname();
break;

case 95 : if (debug) { system.out.println("packagecomment ::="); }  //$non-nls-1$
consumepackagecomment();
break;

case 100 : if (debug) { system.out.println("singletypeimportdeclaration ::=..."); }  //$non-nls-1$
consumeimportdeclaration();
break;

case 101 : if (debug) { system.out.println("singletypeimportdeclarationname ::= import name"); }  //$non-nls-1$
consumesingletypeimportdeclarationname();
break;

case 102 : if (debug) { system.out.println("typeimportondemanddeclaration ::=..."); }  //$non-nls-1$
consumeimportdeclaration();
break;

case 103 : if (debug) { system.out.println("typeimportondemanddeclarationname ::= import name dot..."); }  //$non-nls-1$
consumetypeimportondemanddeclarationname();
break;

case 106 : if (debug) { system.out.println("typedeclaration ::= semicolon"); }  //$non-nls-1$
consumeemptytypedeclaration();
break;

case 110 : if (debug) { system.out.println("modifiers ::= modifiers modifier"); }  //$non-nls-1$
consumemodifiers2();
break;

case 122 : if (debug) { system.out.println("modifier ::= annotation"); }  //$non-nls-1$
consumeannotationasmodifier();
break;

case 123 : if (debug) { system.out.println("classdeclaration ::= classheader classbody"); }  //$non-nls-1$
consumeclassdeclaration();
break;

case 124 : if (debug) { system.out.println("classheader ::= classheadername classheaderextendsopt..."); }  //$non-nls-1$
consumeclassheader();
break;

case 125 : if (debug) { system.out.println("classheadername ::= classheadername1 typeparameters"); }  //$non-nls-1$
consumetypeheadernamewithtypeparameters();
break;

case 127 : if (debug) { system.out.println("classheadername1 ::= modifiersopt class identifier"); }  //$non-nls-1$
consumeclassheadername1();
break;

case 128 : if (debug) { system.out.println("classheaderextends ::= extends classtype"); }  //$non-nls-1$
consumeclassheaderextends();
break;

case 129 : if (debug) { system.out.println("classheaderimplements ::= implements interfacetypelist"); }  //$non-nls-1$
consumeclassheaderimplements();
break;

case 131 : if (debug) { system.out.println("interfacetypelist ::= interfacetypelist comma..."); }  //$non-nls-1$
consumeinterfacetypelist();
break;

case 132 : if (debug) { system.out.println("interfacetype ::= classorinterfacetype"); }  //$non-nls-1$
consumeinterfacetype();
break;

case 135 : if (debug) { system.out.println("classbodydeclarations ::= classbodydeclarations..."); }  //$non-nls-1$
consumeclassbodydeclarations();
break;

case 139 : if (debug) { system.out.println("classbodydeclaration ::= diet nestedmethod..."); }  //$non-nls-1$
consumeclassbodydeclaration();
break;

case 140 : if (debug) { system.out.println("diet ::="); }  //$non-nls-1$
consumediet();
break;

case 141 : if (debug) { system.out.println("initializer ::= diet nestedmethod createinitializer..."); }  //$non-nls-1$
consumeclassbodydeclaration();
break;

case 142 : if (debug) { system.out.println("createinitializer ::="); }  //$non-nls-1$
consumecreateinitializer();
break;

case 149 : if (debug) { system.out.println("classmemberdeclaration ::= semicolon"); }  //$non-nls-1$
consumeemptytypedeclaration();
break;

case 152 : if (debug) { system.out.println("fielddeclaration ::= modifiersopt type..."); }  //$non-nls-1$
consumefielddeclaration();
break;

case 154 : if (debug) { system.out.println("variabledeclarators ::= variabledeclarators comma..."); }  //$non-nls-1$
consumevariabledeclarators();
break;

case 157 : if (debug) { system.out.println("entervariable ::="); }  //$non-nls-1$
consumeentervariable();
break;

case 158 : if (debug) { system.out.println("exitvariablewithinitialization ::="); }  //$non-nls-1$
consumeexitvariablewithinitialization();
break;

case 159 : if (debug) { system.out.println("exitvariablewithoutinitialization ::="); }  //$non-nls-1$
consumeexitvariablewithoutinitialization();
break;

case 160 : if (debug) { system.out.println("forcenodiet ::="); }  //$non-nls-1$
consumeforcenodiet();
break;

case 161 : if (debug) { system.out.println("restorediet ::="); }  //$non-nls-1$
consumerestorediet();
break;

case 166 : if (debug) { system.out.println("methoddeclaration ::= methodheader methodbody"); }  //$non-nls-1$
// set to true to consume a method with a body
consumemethoddeclaration(true);
break;

case 167 : if (debug) { system.out.println("abstractmethoddeclaration ::= methodheader semicolon"); }  //$non-nls-1$
// set to false to consume a method without body
consumemethoddeclaration(false);
break;

case 168 : if (debug) { system.out.println("methodheader ::= methodheadername formalparameterlistopt"); }  //$non-nls-1$
consumemethodheader();
break;

case 169 : if (debug) { system.out.println("methodheadername ::= modifiersopt typeparameters type..."); }  //$non-nls-1$
consumemethodheadernamewithtypeparameters(false);
break;

case 170 : if (debug) { system.out.println("methodheadername ::= modifiersopt type identifier lparen"); }  //$non-nls-1$
consumemethodheadername(false);
break;

case 171 : if (debug) { system.out.println("methodheaderrightparen ::= rparen"); }  //$non-nls-1$
consumemethodheaderrightparen();
break;

case 172 : if (debug) { system.out.println("methodheaderextendeddims ::= dimsopt"); }  //$non-nls-1$
consumemethodheaderextendeddims();
break;

case 173 : if (debug) { system.out.println("methodheaderthrowsclause ::= throws classtypelist"); }  //$non-nls-1$
consumemethodheaderthrowsclause();
break;

case 174 : if (debug) { system.out.println("constructorheader ::= constructorheadername..."); }  //$non-nls-1$
consumeconstructorheader();
break;

case 175 : if (debug) { system.out.println("constructorheadername ::= modifiersopt typeparameters..."); }  //$non-nls-1$
consumeconstructorheadernamewithtypeparameters();
break;

case 176 : if (debug) { system.out.println("constructorheadername ::= modifiersopt identifier lparen"); }  //$non-nls-1$
consumeconstructorheadername();
break;

case 178 : if (debug) { system.out.println("formalparameterlist ::= formalparameterlist comma..."); }  //$non-nls-1$
consumeformalparameterlist();
break;

case 179 : if (debug) { system.out.println("formalparameter ::= modifiersopt type..."); }  //$non-nls-1$
consumeformalparameter(false);
break;

case 180 : if (debug) { system.out.println("formalparameter ::= modifiersopt type ellipsis..."); }  //$non-nls-1$
consumeformalparameter(true);
break;

case 182 : if (debug) { system.out.println("classtypelist ::= classtypelist comma classtypeelt"); }  //$non-nls-1$
consumeclasstypelist();
break;

case 183 : if (debug) { system.out.println("classtypeelt ::= classtype"); }  //$non-nls-1$
consumeclasstypeelt();
break;

case 184 : if (debug) { system.out.println("methodbody ::= nestedmethod lbrace blockstatementsopt..."); }  //$non-nls-1$
consumemethodbody();
break;

case 185 : if (debug) { system.out.println("nestedmethod ::="); }  //$non-nls-1$
consumenestedmethod();
break;

case 186 : if (debug) { system.out.println("staticinitializer ::= staticonly block"); }  //$non-nls-1$
consumestaticinitializer();
break;

case 187 : if (debug) { system.out.println("staticonly ::= static"); }  //$non-nls-1$
consumestaticonly();
break;

case 188 : if (debug) { system.out.println("constructordeclaration ::= constructorheader methodbody"); }  //$non-nls-1$
consumeconstructordeclaration() ;
break;

case 189 : if (debug) { system.out.println("constructordeclaration ::= constructorheader semicolon"); }  //$non-nls-1$
consumeinvalidconstructordeclaration() ;
break;

case 190 : if (debug) { system.out.println("explicitconstructorinvocation ::= this lparen..."); }  //$non-nls-1$
consumeexplicitconstructorinvocation(0, this_call);
break;

case 191 : if (debug) { system.out.println("explicitconstructorinvocation ::= onlytypearguments this"); }  //$non-nls-1$
consumeexplicitconstructorinvocationwithtypearguments(0,this_call);
break;

case 192 : if (debug) { system.out.println("explicitconstructorinvocation ::= super lparen..."); }  //$non-nls-1$
consumeexplicitconstructorinvocation(0,super_call);
break;

case 193 : if (debug) { system.out.println("explicitconstructorinvocation ::= onlytypearguments..."); }  //$non-nls-1$
consumeexplicitconstructorinvocationwithtypearguments(0,super_call);
break;

case 194 : if (debug) { system.out.println("explicitconstructorinvocation ::= primary dot super..."); }  //$non-nls-1$
consumeexplicitconstructorinvocation(1, super_call);
break;

case 195 : if (debug) { system.out.println("explicitconstructorinvocation ::= primary dot..."); }  //$non-nls-1$
consumeexplicitconstructorinvocationwithtypearguments(1, super_call);
break;

case 196 : if (debug) { system.out.println("explicitconstructorinvocation ::= name dot super lparen"); }  //$non-nls-1$
consumeexplicitconstructorinvocation(2, super_call);
break;

case 197 : if (debug) { system.out.println("explicitconstructorinvocation ::= name dot..."); }  //$non-nls-1$
consumeexplicitconstructorinvocationwithtypearguments(2, super_call);
break;

case 198 : if (debug) { system.out.println("explicitconstructorinvocation ::= primary dot this..."); }  //$non-nls-1$
consumeexplicitconstructorinvocation(1, this_call);
break;

case 199 : if (debug) { system.out.println("explicitconstructorinvocation ::= primary dot..."); }  //$non-nls-1$
consumeexplicitconstructorinvocationwithtypearguments(1, this_call);
break;

case 200 : if (debug) { system.out.println("explicitconstructorinvocation ::= name dot this lparen"); }  //$non-nls-1$
consumeexplicitconstructorinvocation(2, this_call);
break;

case 201 : if (debug) { system.out.println("explicitconstructorinvocation ::= name dot..."); }  //$non-nls-1$
consumeexplicitconstructorinvocationwithtypearguments(2, this_call);
break;

case 202 : if (debug) { system.out.println("interfacedeclaration ::= interfaceheader interfacebody"); }  //$non-nls-1$
consumeinterfacedeclaration();
break;

case 203 : if (debug) { system.out.println("interfaceheader ::= interfaceheadername..."); }  //$non-nls-1$
consumeinterfaceheader();
break;

case 204 : if (debug) { system.out.println("interfaceheadername ::= interfaceheadername1..."); }  //$non-nls-1$
consumetypeheadernamewithtypeparameters();
break;

case 206 : if (debug) { system.out.println("interfaceheadername1 ::= modifiersopt interface..."); }  //$non-nls-1$
consumeinterfaceheadername1();
break;

case 207 : if (debug) { system.out.println("interfaceheaderextends ::= extends interfacetypelist"); }  //$non-nls-1$
consumeinterfaceheaderextends();
break;

case 210 : if (debug) { system.out.println("interfacememberdeclarations ::=..."); }  //$non-nls-1$
consumeinterfacememberdeclarations();
break;

case 211 : if (debug) { system.out.println("interfacememberdeclaration ::= semicolon"); }  //$non-nls-1$
consumeemptytypedeclaration();
break;

case 213 : if (debug) { system.out.println("interfacememberdeclaration ::= methodheader methodbody"); }  //$non-nls-1$
consumeinvalidmethoddeclaration();
break;

case 214 : if (debug) { system.out.println("invalidconstructordeclaration ::= constructorheader..."); }  //$non-nls-1$
consumeinvalidconstructordeclaration(true);
break;

case 215 : if (debug) { system.out.println("invalidconstructordeclaration ::= constructorheader..."); }  //$non-nls-1$
consumeinvalidconstructordeclaration(false);
break;

case 223 : if (debug) { system.out.println("pushleftbrace ::="); }  //$non-nls-1$
consumepushleftbrace();
break;

case 224 : if (debug) { system.out.println("arrayinitializer ::= lbrace pushleftbrace ,opt rbrace"); }  //$non-nls-1$
consumeemptyarrayinitializer();
break;

case 225 : if (debug) { system.out.println("arrayinitializer ::= lbrace pushleftbrace..."); }  //$non-nls-1$
consumearrayinitializer();
break;

case 226 : if (debug) { system.out.println("arrayinitializer ::= lbrace pushleftbrace..."); }  //$non-nls-1$
consumearrayinitializer();
break;

case 228 : if (debug) { system.out.println("variableinitializers ::= variableinitializers comma..."); }  //$non-nls-1$
consumevariableinitializers();
break;

case 229 : if (debug) { system.out.println("block ::= openblock lbrace blockstatementsopt rbrace"); }  //$non-nls-1$
consumeblock();
break;

case 230 : if (debug) { system.out.println("openblock ::="); }  //$non-nls-1$
consumeopenblock() ;
break;

case 232 : if (debug) { system.out.println("blockstatements ::= blockstatements blockstatement"); }  //$non-nls-1$
consumeblockstatements() ;
break;

case 236 : if (debug) { system.out.println("blockstatement ::= interfacedeclaration"); }  //$non-nls-1$
consumeinvalidinterfacedeclaration();
break;

case 237 : if (debug) { system.out.println("blockstatement ::= annotationtypedeclaration"); }  //$non-nls-1$
consumeinvalidannotationtypedeclaration();
break;

case 238 : if (debug) { system.out.println("blockstatement ::= enumdeclaration"); }  //$non-nls-1$
consumeinvalidenumdeclaration();
break;

case 239 : if (debug) { system.out.println("localvariabledeclarationstatement ::=..."); }  //$non-nls-1$
consumelocalvariabledeclarationstatement();
break;

case 240 : if (debug) { system.out.println("localvariabledeclaration ::= type pushmodifiers..."); }  //$non-nls-1$
consumelocalvariabledeclaration();
break;

case 241 : if (debug) { system.out.println("localvariabledeclaration ::= modifiers type..."); }  //$non-nls-1$
consumelocalvariabledeclaration();
break;

case 242 : if (debug) { system.out.println("pushmodifiers ::="); }  //$non-nls-1$
consumepushmodifiers();
break;

case 243 : if (debug) { system.out.println("pushmodifiersforheader ::="); }  //$non-nls-1$
consumepushmodifiersforheader();
break;

case 244 : if (debug) { system.out.println("pushrealmodifiers ::="); }  //$non-nls-1$
consumepushrealmodifiers();
break;

case 270 : if (debug) { system.out.println("emptystatement ::= semicolon"); }  //$non-nls-1$
consumeemptystatement();
break;

case 271 : if (debug) { system.out.println("labeledstatement ::= label colon statement"); }  //$non-nls-1$
consumestatementlabel() ;
break;

case 272 : if (debug) { system.out.println("labeledstatementnoshortif ::= label colon..."); }  //$non-nls-1$
consumestatementlabel() ;
break;

case 273 : if (debug) { system.out.println("label ::= identifier"); }  //$non-nls-1$
consumelabel() ;
break;

case 274 : if (debug) { system.out.println("expressionstatement ::= statementexpression semicolon"); }  //$non-nls-1$
consumeexpressionstatement();
break;

case 283 : if (debug) { system.out.println("ifthenstatement ::= if lparen expression rparen..."); }  //$non-nls-1$
consumestatementifnoelse();
break;

case 284 : if (debug) { system.out.println("ifthenelsestatement ::= if lparen expression rparen..."); }  //$non-nls-1$
consumestatementifwithelse();
break;

case 285 : if (debug) { system.out.println("ifthenelsestatementnoshortif ::= if lparen expression..."); }  //$non-nls-1$
consumestatementifwithelse();
break;

case 286 : if (debug) { system.out.println("switchstatement ::= switch lparen expression rparen..."); }  //$non-nls-1$
consumestatementswitch() ;
break;

case 287 : if (debug) { system.out.println("switchblock ::= lbrace rbrace"); }  //$non-nls-1$
consumeemptyswitchblock() ;
break;

case 290 : if (debug) { system.out.println("switchblock ::= lbrace switchblockstatements..."); }  //$non-nls-1$
consumeswitchblock() ;
break;

case 292 : if (debug) { system.out.println("switchblockstatements ::= switchblockstatements..."); }  //$non-nls-1$
consumeswitchblockstatements() ;
break;

case 293 : if (debug) { system.out.println("switchblockstatement ::= switchlabels blockstatements"); }  //$non-nls-1$
consumeswitchblockstatement() ;
break;

case 295 : if (debug) { system.out.println("switchlabels ::= switchlabels switchlabel"); }  //$non-nls-1$
consumeswitchlabels() ;
break;

case 296 : if (debug) { system.out.println("switchlabel ::= case constantexpression colon"); }  //$non-nls-1$
consumecaselabel();
break;

case 297 : if (debug) { system.out.println("switchlabel ::= default colon"); }  //$non-nls-1$
consumedefaultlabel();
break;

case 298 : if (debug) { system.out.println("whilestatement ::= while lparen expression rparen..."); }  //$non-nls-1$
consumestatementwhile() ;
break;

case 299 : if (debug) { system.out.println("whilestatementnoshortif ::= while lparen expression..."); }  //$non-nls-1$
consumestatementwhile() ;
break;

case 300 : if (debug) { system.out.println("dostatement ::= do statement while lparen expression..."); }  //$non-nls-1$
consumestatementdo() ;
break;

case 301 : if (debug) { system.out.println("forstatement ::= for lparen forinitopt semicolon..."); }  //$non-nls-1$
consumestatementfor() ;
break;

case 302 : if (debug) { system.out.println("forstatementnoshortif ::= for lparen forinitopt..."); }  //$non-nls-1$
consumestatementfor() ;
break;

case 303 : if (debug) { system.out.println("forinit ::= statementexpressionlist"); }  //$non-nls-1$
consumeforinit() ;
break;

case 307 : if (debug) { system.out.println("statementexpressionlist ::= statementexpressionlist..."); }  //$non-nls-1$
consumestatementexpressionlist() ;
break;

case 308 : if (debug) { system.out.println("assertstatement ::= assert expression semicolon"); }  //$non-nls-1$
consumesimpleassertstatement() ;
break;

case 309 : if (debug) { system.out.println("assertstatement ::= assert expression colon expression"); }  //$non-nls-1$
consumeassertstatement() ;
break;

case 310 : if (debug) { system.out.println("breakstatement ::= break semicolon"); }  //$non-nls-1$
consumestatementbreak() ;
break;

case 311 : if (debug) { system.out.println("breakstatement ::= break identifier semicolon"); }  //$non-nls-1$
consumestatementbreakwithlabel() ;
break;

case 312 : if (debug) { system.out.println("continuestatement ::= continue semicolon"); }  //$non-nls-1$
consumestatementcontinue() ;
break;

case 313 : if (debug) { system.out.println("continuestatement ::= continue identifier semicolon"); }  //$non-nls-1$
consumestatementcontinuewithlabel() ;
break;

case 314 : if (debug) { system.out.println("returnstatement ::= return expressionopt semicolon"); }  //$non-nls-1$
consumestatementreturn() ;
break;

case 315 : if (debug) { system.out.println("throwstatement ::= throw expression semicolon"); }  //$non-nls-1$
consumestatementthrow();
break;

case 316 : if (debug) { system.out.println("synchronizedstatement ::= onlysynchronized lparen..."); }  //$non-nls-1$
consumestatementsynchronized();
break;

case 317 : if (debug) { system.out.println("onlysynchronized ::= synchronized"); }  //$non-nls-1$
consumeonlysynchronized();
break;

case 318 : if (debug) { system.out.println("trystatement ::= try tryblock catches"); }  //$non-nls-1$
consumestatementtry(false);
break;

case 319 : if (debug) { system.out.println("trystatement ::= try tryblock catchesopt finally"); }  //$non-nls-1$
consumestatementtry(true);
break;

case 321 : if (debug) { system.out.println("exittryblock ::="); }  //$non-nls-1$
consumeexittryblock();
break;

case 323 : if (debug) { system.out.println("catches ::= catches catchclause"); }  //$non-nls-1$
consumecatches();
break;

case 324 : if (debug) { system.out.println("catchclause ::= catch lparen formalparameter rparen..."); }  //$non-nls-1$
consumestatementcatch() ;
break;

case 326 : if (debug) { system.out.println("pushlparen ::= lparen"); }  //$non-nls-1$
consumeleftparen();
break;

case 327 : if (debug) { system.out.println("pushrparen ::= rparen"); }  //$non-nls-1$
consumerightparen();
break;

case 332 : if (debug) { system.out.println("primarynonewarray ::= this"); }  //$non-nls-1$
consumeprimarynonewarraythis();
break;

case 333 : if (debug) { system.out.println("primarynonewarray ::= pushlparen expression_notname..."); }  //$non-nls-1$
consumeprimarynonewarray();
break;

case 334 : if (debug) { system.out.println("primarynonewarray ::= pushlparen name pushrparen"); }  //$non-nls-1$
consumeprimarynonewarraywithname();
break;

case 337 : if (debug) { system.out.println("primarynonewarray ::= name dot this"); }  //$non-nls-1$
consumeprimarynonewarraynamethis();
break;

case 338 : if (debug) { system.out.println("primarynonewarray ::= name dot super"); }  //$non-nls-1$
consumeprimarynonewarraynamesuper();
break;

case 339 : if (debug) { system.out.println("primarynonewarray ::= name dot class"); }  //$non-nls-1$
consumeprimarynonewarrayname();
break;

case 340 : if (debug) { system.out.println("primarynonewarray ::= name dims dot class"); }  //$non-nls-1$
consumeprimarynonewarrayarraytype();
break;

case 341 : if (debug) { system.out.println("primarynonewarray ::= primitivetype dims dot class"); }  //$non-nls-1$
consumeprimarynonewarrayprimitivearraytype();
break;

case 342 : if (debug) { system.out.println("primarynonewarray ::= primitivetype dot class"); }  //$non-nls-1$
consumeprimarynonewarrayprimitivetype();
break;

case 345 : if (debug) { system.out.println("allocationheader ::= new classtype lparen..."); }  //$non-nls-1$
consumeallocationheader();
break;

case 346 : if (debug) { system.out.println("classinstancecreationexpression ::= new..."); }  //$non-nls-1$
consumeclassinstancecreationexpressionwithtypearguments();
break;

case 347 : if (debug) { system.out.println("classinstancecreationexpression ::= new classtype lparen"); }  //$non-nls-1$
consumeclassinstancecreationexpression();
break;

case 348 : if (debug) { system.out.println("classinstancecreationexpression ::= primary dot new..."); }  //$non-nls-1$
consumeclassinstancecreationexpressionqualifiedwithtypearguments() ;
break;

case 349 : if (debug) { system.out.println("classinstancecreationexpression ::= primary dot new..."); }  //$non-nls-1$
consumeclassinstancecreationexpressionqualified() ;
break;

case 350 : if (debug) { system.out.println("classinstancecreationexpression ::=..."); }  //$non-nls-1$
consumeclassinstancecreationexpressionqualified() ;
break;

case 351 : if (debug) { system.out.println("classinstancecreationexpression ::=..."); }  //$non-nls-1$
consumeclassinstancecreationexpressionqualifiedwithtypearguments() ;
break;

case 352 : if (debug) { system.out.println("classinstancecreationexpressionname ::= name dot"); }  //$non-nls-1$
consumeclassinstancecreationexpressionname() ;
break;

case 353 : if (debug) { system.out.println("unqualifiedclassbodyopt ::="); }  //$non-nls-1$
consumeclassbodyopt();
break;

case 355 : if (debug) { system.out.println("unqualifiedenteranonymousclassbody ::="); }  //$non-nls-1$
consumeenteranonymousclassbody(false);
break;

case 356 : if (debug) { system.out.println("qualifiedclassbodyopt ::="); }  //$non-nls-1$
consumeclassbodyopt();
break;

case 358 : if (debug) { system.out.println("qualifiedenteranonymousclassbody ::="); }  //$non-nls-1$
consumeenteranonymousclassbody(true);
break;

case 360 : if (debug) { system.out.println("argumentlist ::= argumentlist comma expression"); }  //$non-nls-1$
consumeargumentlist();
break;

case 361 : if (debug) { system.out.println("arraycreationheader ::= new primitivetype..."); }  //$non-nls-1$
consumearraycreationheader();
break;

case 362 : if (debug) { system.out.println("arraycreationheader ::= new classorinterfacetype..."); }  //$non-nls-1$
consumearraycreationheader();
break;

case 363 : if (debug) { system.out.println("arraycreationwithoutarrayinitializer ::= new..."); }  //$non-nls-1$
consumearraycreationexpressionwithoutinitializer();
break;

case 364 : if (debug) { system.out.println("arraycreationwitharrayinitializer ::= new primitivetype"); }  //$non-nls-1$
consumearraycreationexpressionwithinitializer();
break;

case 365 : if (debug) { system.out.println("arraycreationwithoutarrayinitializer ::= new..."); }  //$non-nls-1$
consumearraycreationexpressionwithoutinitializer();
break;

case 366 : if (debug) { system.out.println("arraycreationwitharrayinitializer ::= new..."); }  //$non-nls-1$
consumearraycreationexpressionwithinitializer();
break;

case 368 : if (debug) { system.out.println("dimwithorwithoutexprs ::= dimwithorwithoutexprs..."); }  //$non-nls-1$
consumedimwithorwithoutexprs();
break;

case 370 : if (debug) { system.out.println("dimwithorwithoutexpr ::= lbracket rbracket"); }  //$non-nls-1$
consumedimwithorwithoutexpr();
break;

case 371 : if (debug) { system.out.println("dims ::= dimsloop"); }  //$non-nls-1$
consumedims();
break;

case 374 : if (debug) { system.out.println("onedimloop ::= lbracket rbracket"); }  //$non-nls-1$
consumeonedimloop();
break;

case 375 : if (debug) { system.out.println("fieldaccess ::= primary dot identifier"); }  //$non-nls-1$
consumefieldaccess(false);
break;

case 376 : if (debug) { system.out.println("fieldaccess ::= super dot identifier"); }  //$non-nls-1$
consumefieldaccess(true);
break;

case 377 : if (debug) { system.out.println("methodinvocation ::= name lparen argumentlistopt rparen"); }  //$non-nls-1$
consumemethodinvocationname();
break;

case 378 : if (debug) { system.out.println("methodinvocation ::= name dot onlytypearguments..."); }  //$non-nls-1$
consumemethodinvocationnamewithtypearguments();
break;

case 379 : if (debug) { system.out.println("methodinvocation ::= primary dot onlytypearguments..."); }  //$non-nls-1$
consumemethodinvocationprimarywithtypearguments();
break;

case 380 : if (debug) { system.out.println("methodinvocation ::= primary dot identifier lparen..."); }  //$non-nls-1$
consumemethodinvocationprimary();
break;

case 381 : if (debug) { system.out.println("methodinvocation ::= super dot onlytypearguments..."); }  //$non-nls-1$
consumemethodinvocationsuperwithtypearguments();
break;

case 382 : if (debug) { system.out.println("methodinvocation ::= super dot identifier lparen..."); }  //$non-nls-1$
consumemethodinvocationsuper();
break;

case 383 : if (debug) { system.out.println("arrayaccess ::= name lbracket expression rbracket"); }  //$non-nls-1$
consumearrayaccess(true);
break;

case 384 : if (debug) { system.out.println("arrayaccess ::= primarynonewarray lbracket expression..."); }  //$non-nls-1$
consumearrayaccess(false);
break;

case 385 : if (debug) { system.out.println("arrayaccess ::= arraycreationwitharrayinitializer..."); }  //$non-nls-1$
consumearrayaccess(false);
break;

case 387 : if (debug) { system.out.println("postfixexpression ::= name"); }  //$non-nls-1$
consumepostfixexpression();
break;

case 390 : if (debug) { system.out.println("postincrementexpression ::= postfixexpression plus_plus"); }  //$non-nls-1$
consumeunaryexpression(operatorids.plus,true);
break;

case 391 : if (debug) { system.out.println("postdecrementexpression ::= postfixexpression..."); }  //$non-nls-1$
consumeunaryexpression(operatorids.minus,true);
break;

case 392 : if (debug) { system.out.println("pushposition ::="); }  //$non-nls-1$
consumepushposition();
break;

case 395 : if (debug) { system.out.println("unaryexpression ::= plus pushposition unaryexpression"); }  //$non-nls-1$
consumeunaryexpression(operatorids.plus);
break;

case 396 : if (debug) { system.out.println("unaryexpression ::= minus pushposition unaryexpression"); }  //$non-nls-1$
consumeunaryexpression(operatorids.minus);
break;

case 398 : if (debug) { system.out.println("preincrementexpression ::= plus_plus pushposition..."); }  //$non-nls-1$
consumeunaryexpression(operatorids.plus,false);
break;

case 399 : if (debug) { system.out.println("predecrementexpression ::= minus_minus pushposition..."); }  //$non-nls-1$
consumeunaryexpression(operatorids.minus,false);
break;

case 401 : if (debug) { system.out.println("unaryexpressionnotplusminus ::= twiddle pushposition..."); }  //$non-nls-1$
consumeunaryexpression(operatorids.twiddle);
break;

case 402 : if (debug) { system.out.println("unaryexpressionnotplusminus ::= not pushposition..."); }  //$non-nls-1$
consumeunaryexpression(operatorids.not);
break;

case 404 : if (debug) { system.out.println("castexpression ::= pushlparen primitivetype dimsopt..."); }  //$non-nls-1$
consumecastexpressionwithprimitivetype();
break;

case 405 : if (debug) { system.out.println("castexpression ::= pushlparen name..."); }  //$non-nls-1$
consumecastexpressionwithgenericsarray();
break;

case 406 : if (debug) { system.out.println("castexpression ::= pushlparen name..."); }  //$non-nls-1$
consumecastexpressionwithqualifiedgenericsarray();
break;

case 407 : if (debug) { system.out.println("castexpression ::= pushlparen name pushrparen..."); }  //$non-nls-1$
consumecastexpressionll1();
break;

case 408 : if (debug) { system.out.println("castexpression ::= pushlparen name dims pushrparen..."); }  //$non-nls-1$
consumecastexpressionwithnamearray();
break;

case 409 : if (debug) { system.out.println("onlytypeargumentsforcastexpression ::= onlytypearguments"); }  //$non-nls-1$
consumeonlytypeargumentsforcastexpression();
break;

case 410 : if (debug) { system.out.println("insidecastexpression ::="); }  //$non-nls-1$
consumeinsidecastexpression();
break;

case 411 : if (debug) { system.out.println("insidecastexpressionll1 ::="); }  //$non-nls-1$
consumeinsidecastexpressionll1();
break;

case 412 : if (debug) { system.out.println("insidecastexpressionwithqualifiedgenerics ::="); }  //$non-nls-1$
consumeinsidecastexpressionwithqualifiedgenerics();
break;

case 414 : if (debug) { system.out.println("multiplicativeexpression ::= multiplicativeexpression..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.multiply);
break;

case 415 : if (debug) { system.out.println("multiplicativeexpression ::= multiplicativeexpression..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.divide);
break;

case 416 : if (debug) { system.out.println("multiplicativeexpression ::= multiplicativeexpression..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.remainder);
break;

case 418 : if (debug) { system.out.println("additiveexpression ::= additiveexpression plus..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.plus);
break;

case 419 : if (debug) { system.out.println("additiveexpression ::= additiveexpression minus..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.minus);
break;

case 421 : if (debug) { system.out.println("shiftexpression ::= shiftexpression left_shift..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.left_shift);
break;

case 422 : if (debug) { system.out.println("shiftexpression ::= shiftexpression right_shift..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.right_shift);
break;

case 423 : if (debug) { system.out.println("shiftexpression ::= shiftexpression unsigned_right_shift"); }  //$non-nls-1$
consumebinaryexpression(operatorids.unsigned_right_shift);
break;

case 425 : if (debug) { system.out.println("relationalexpression ::= relationalexpression less..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.less);
break;

case 426 : if (debug) { system.out.println("relationalexpression ::= relationalexpression greater..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.greater);
break;

case 427 : if (debug) { system.out.println("relationalexpression ::= relationalexpression less_equal"); }  //$non-nls-1$
consumebinaryexpression(operatorids.less_equal);
break;

case 428 : if (debug) { system.out.println("relationalexpression ::= relationalexpression..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.greater_equal);
break;

case 430 : if (debug) { system.out.println("instanceofexpression ::= instanceofexpression instanceof"); }  //$non-nls-1$
consumeinstanceofexpression();
break;

case 432 : if (debug) { system.out.println("equalityexpression ::= equalityexpression equal_equal..."); }  //$non-nls-1$
consumeequalityexpression(operatorids.equal_equal);
break;

case 433 : if (debug) { system.out.println("equalityexpression ::= equalityexpression not_equal..."); }  //$non-nls-1$
consumeequalityexpression(operatorids.not_equal);
break;

case 435 : if (debug) { system.out.println("andexpression ::= andexpression and equalityexpression"); }  //$non-nls-1$
consumebinaryexpression(operatorids.and);
break;

case 437 : if (debug) { system.out.println("exclusiveorexpression ::= exclusiveorexpression xor..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.xor);
break;

case 439 : if (debug) { system.out.println("inclusiveorexpression ::= inclusiveorexpression or..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.or);
break;

case 441 : if (debug) { system.out.println("conditionalandexpression ::= conditionalandexpression..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.and_and);
break;

case 443 : if (debug) { system.out.println("conditionalorexpression ::= conditionalorexpression..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.or_or);
break;

case 445 : if (debug) { system.out.println("conditionalexpression ::= conditionalorexpression..."); }  //$non-nls-1$
consumeconditionalexpression(operatorids.questioncolon) ;
break;

case 448 : if (debug) { system.out.println("assignment ::= postfixexpression assignmentoperator..."); }  //$non-nls-1$
consumeassignment();
break;

case 450 : if (debug) { system.out.println("assignment ::= invalidarrayinitializerassignement"); }  //$non-nls-1$
ignoreexpressionassignment();
break;

case 451 : if (debug) { system.out.println("assignmentoperator ::= equal"); }  //$non-nls-1$
consumeassignmentoperator(equal);
break;

case 452 : if (debug) { system.out.println("assignmentoperator ::= multiply_equal"); }  //$non-nls-1$
consumeassignmentoperator(multiply);
break;

case 453 : if (debug) { system.out.println("assignmentoperator ::= divide_equal"); }  //$non-nls-1$
consumeassignmentoperator(divide);
break;

case 454 : if (debug) { system.out.println("assignmentoperator ::= remainder_equal"); }  //$non-nls-1$
consumeassignmentoperator(remainder);
break;

case 455 : if (debug) { system.out.println("assignmentoperator ::= plus_equal"); }  //$non-nls-1$
consumeassignmentoperator(plus);
break;

case 456 : if (debug) { system.out.println("assignmentoperator ::= minus_equal"); }  //$non-nls-1$
consumeassignmentoperator(minus);
break;

case 457 : if (debug) { system.out.println("assignmentoperator ::= left_shift_equal"); }  //$non-nls-1$
consumeassignmentoperator(left_shift);
break;

case 458 : if (debug) { system.out.println("assignmentoperator ::= right_shift_equal"); }  //$non-nls-1$
consumeassignmentoperator(right_shift);
break;

case 459 : if (debug) { system.out.println("assignmentoperator ::= unsigned_right_shift_equal"); }  //$non-nls-1$
consumeassignmentoperator(unsigned_right_shift);
break;

case 460 : if (debug) { system.out.println("assignmentoperator ::= and_equal"); }  //$non-nls-1$
consumeassignmentoperator(and);
break;

case 461 : if (debug) { system.out.println("assignmentoperator ::= xor_equal"); }  //$non-nls-1$
consumeassignmentoperator(xor);
break;

case 462 : if (debug) { system.out.println("assignmentoperator ::= or_equal"); }  //$non-nls-1$
consumeassignmentoperator(or);
break;

case 466 : if (debug) { system.out.println("expressionopt ::="); }  //$non-nls-1$
consumeemptyexpression();
break;

case 471 : if (debug) { system.out.println("classbodydeclarationsopt ::="); }  //$non-nls-1$
consumeemptyclassbodydeclarationsopt();
break;

case 472 : if (debug) { system.out.println("classbodydeclarationsopt ::= nestedtype..."); }  //$non-nls-1$
consumeclassbodydeclarationsopt();
break;

case 473 : if (debug) { system.out.println("modifiersopt ::="); }  //$non-nls-1$
consumedefaultmodifiers();
break;

case 474 : if (debug) { system.out.println("modifiersopt ::= modifiers"); }  //$non-nls-1$
consumemodifiers();
break;

case 475 : if (debug) { system.out.println("blockstatementsopt ::="); }  //$non-nls-1$
consumeemptyblockstatementsopt();
break;

case 477 : if (debug) { system.out.println("dimsopt ::="); }  //$non-nls-1$
consumeemptydimsopt();
break;

case 479 : if (debug) { system.out.println("argumentlistopt ::="); }  //$non-nls-1$
consumeemptyargumentlistopt();
break;

case 483 : if (debug) { system.out.println("formalparameterlistopt ::="); }  //$non-nls-1$
consumeformalparameterlistopt();
break;

case 487 : if (debug) { system.out.println("interfacememberdeclarationsopt ::="); }  //$non-nls-1$
consumeemptyinterfacememberdeclarationsopt();
break;

case 488 : if (debug) { system.out.println("interfacememberdeclarationsopt ::= nestedtype..."); }  //$non-nls-1$
consumeinterfacememberdeclarationsopt();
break;

case 489 : if (debug) { system.out.println("nestedtype ::="); }  //$non-nls-1$
consumenestedtype();
break;

case 490 : if (debug) { system.out.println("forinitopt ::="); }  //$non-nls-1$
consumeemptyforinitopt();
break;

case 492 : if (debug) { system.out.println("forupdateopt ::="); }  //$non-nls-1$
consumeemptyforupdateopt();
break;

case 496 : if (debug) { system.out.println("catchesopt ::="); }  //$non-nls-1$
consumeemptycatchesopt();
break;

case 498 : if (debug) { system.out.println("enumdeclaration ::= enumheader enumbody"); }  //$non-nls-1$
consumeenumdeclaration();
break;

case 499 : if (debug) { system.out.println("enumheader ::= enumheadername classheaderimplementsopt"); }  //$non-nls-1$
consumeenumheader();
break;

case 500 : if (debug) { system.out.println("enumheadername ::= modifiersopt enum identifier"); }  //$non-nls-1$
consumeenumheadername();
break;

case 501 : if (debug) { system.out.println("enumheadername ::= modifiersopt enum identifier..."); }  //$non-nls-1$
consumeenumheadernamewithtypeparameters();
break;

case 502 : if (debug) { system.out.println("enumbody ::= lbrace enumbodydeclarationsopt rbrace"); }  //$non-nls-1$
consumeenumbodynoconstants();
break;

case 503 : if (debug) { system.out.println("enumbody ::= lbrace comma enumbodydeclarationsopt..."); }  //$non-nls-1$
consumeenumbodynoconstants();
break;

case 504 : if (debug) { system.out.println("enumbody ::= lbrace enumconstants comma..."); }  //$non-nls-1$
consumeenumbodywithconstants();
break;

case 505 : if (debug) { system.out.println("enumbody ::= lbrace enumconstants..."); }  //$non-nls-1$
consumeenumbodywithconstants();
break;

case 507 : if (debug) { system.out.println("enumconstants ::= enumconstants comma enumconstant"); }  //$non-nls-1$
consumeenumconstants();
break;

case 508 : if (debug) { system.out.println("enumconstantheadername ::= modifiersopt identifier"); }  //$non-nls-1$
consumeenumconstantheadername();
break;

case 509 : if (debug) { system.out.println("enumconstantheader ::= enumconstantheadername..."); }  //$non-nls-1$
consumeenumconstantheader();
break;

case 510 : if (debug) { system.out.println("enumconstant ::= enumconstantheader forcenodiet..."); }  //$non-nls-1$
consumeenumconstantwithclassbody();
break;

case 511 : if (debug) { system.out.println("enumconstant ::= enumconstantheader"); }  //$non-nls-1$
consumeenumconstantnoclassbody();
break;

case 512 : if (debug) { system.out.println("arguments ::= lparen argumentlistopt rparen"); }  //$non-nls-1$
consumearguments();
break;

case 513 : if (debug) { system.out.println("argumentsopt ::="); }  //$non-nls-1$
consumeemptyarguments();
break;

case 515 : if (debug) { system.out.println("enumdeclarations ::= semicolon classbodydeclarationsopt"); }  //$non-nls-1$
consumeenumdeclarations();
break;

case 516 : if (debug) { system.out.println("enumbodydeclarationsopt ::="); }  //$non-nls-1$
consumeemptyenumdeclarations();
break;

case 518 : if (debug) { system.out.println("enhancedforstatement ::= enhancedforstatementheader..."); }  //$non-nls-1$
consumeenhancedforstatement();
break;

case 519 : if (debug) { system.out.println("enhancedforstatementnoshortif ::=..."); }  //$non-nls-1$
consumeenhancedforstatement();
break;

case 520 : if (debug) { system.out.println("enhancedforstatementheaderinit ::= for lparen type..."); }  //$non-nls-1$
consumeenhancedforstatementheaderinit(false);
break;

case 521 : if (debug) { system.out.println("enhancedforstatementheaderinit ::= for lparen modifiers"); }  //$non-nls-1$
consumeenhancedforstatementheaderinit(true);
break;

case 522 : if (debug) { system.out.println("enhancedforstatementheader ::=..."); }  //$non-nls-1$
consumeenhancedforstatementheader();
break;

case 523 : if (debug) { system.out.println("singlestaticimportdeclaration ::=..."); }  //$non-nls-1$
consumeimportdeclaration();
break;

case 524 : if (debug) { system.out.println("singlestaticimportdeclarationname ::= import static name"); }  //$non-nls-1$
consumesinglestaticimportdeclarationname();
break;

case 525 : if (debug) { system.out.println("staticimportondemanddeclaration ::=..."); }  //$non-nls-1$
consumeimportdeclaration();
break;

case 526 : if (debug) { system.out.println("staticimportondemanddeclarationname ::= import static..."); }  //$non-nls-1$
consumestaticimportondemanddeclarationname();
break;

case 527 : if (debug) { system.out.println("typearguments ::= less typeargumentlist1"); }  //$non-nls-1$
consumetypearguments();
break;

case 528 : if (debug) { system.out.println("onlytypearguments ::= less typeargumentlist1"); }  //$non-nls-1$
consumeonlytypearguments();
break;

case 530 : if (debug) { system.out.println("typeargumentlist1 ::= typeargumentlist comma..."); }  //$non-nls-1$
consumetypeargumentlist1();
break;

case 532 : if (debug) { system.out.println("typeargumentlist ::= typeargumentlist comma typeargument"); }  //$non-nls-1$
consumetypeargumentlist();
break;

case 533 : if (debug) { system.out.println("typeargument ::= referencetype"); }  //$non-nls-1$
consumetypeargument();
break;

case 537 : if (debug) { system.out.println("referencetype1 ::= referencetype greater"); }  //$non-nls-1$
consumereferencetype1();
break;

case 538 : if (debug) { system.out.println("referencetype1 ::= classorinterface less..."); }  //$non-nls-1$
consumetypeargumentreferencetype1();
break;

case 540 : if (debug) { system.out.println("typeargumentlist2 ::= typeargumentlist comma..."); }  //$non-nls-1$
consumetypeargumentlist2();
break;

case 543 : if (debug) { system.out.println("referencetype2 ::= referencetype right_shift"); }  //$non-nls-1$
consumereferencetype2();
break;

case 544 : if (debug) { system.out.println("referencetype2 ::= classorinterface less..."); }  //$non-nls-1$
consumetypeargumentreferencetype2();
break;

case 546 : if (debug) { system.out.println("typeargumentlist3 ::= typeargumentlist comma..."); }  //$non-nls-1$
consumetypeargumentlist3();
break;

case 549 : if (debug) { system.out.println("referencetype3 ::= referencetype unsigned_right_shift"); }  //$non-nls-1$
consumereferencetype3();
break;

case 550 : if (debug) { system.out.println("wildcard ::= question"); }  //$non-nls-1$
consumewildcard();
break;

case 551 : if (debug) { system.out.println("wildcard ::= question wildcardbounds"); }  //$non-nls-1$
consumewildcardwithbounds();
break;

case 552 : if (debug) { system.out.println("wildcardbounds ::= extends referencetype"); }  //$non-nls-1$
consumewildcardboundsextends();
break;

case 553 : if (debug) { system.out.println("wildcardbounds ::= super referencetype"); }  //$non-nls-1$
consumewildcardboundssuper();
break;

case 554 : if (debug) { system.out.println("wildcard1 ::= question greater"); }  //$non-nls-1$
consumewildcard1();
break;

case 555 : if (debug) { system.out.println("wildcard1 ::= question wildcardbounds1"); }  //$non-nls-1$
consumewildcard1withbounds();
break;

case 556 : if (debug) { system.out.println("wildcardbounds1 ::= extends referencetype1"); }  //$non-nls-1$
consumewildcardbounds1extends();
break;

case 557 : if (debug) { system.out.println("wildcardbounds1 ::= super referencetype1"); }  //$non-nls-1$
consumewildcardbounds1super();
break;

case 558 : if (debug) { system.out.println("wildcard2 ::= question right_shift"); }  //$non-nls-1$
consumewildcard2();
break;

case 559 : if (debug) { system.out.println("wildcard2 ::= question wildcardbounds2"); }  //$non-nls-1$
consumewildcard2withbounds();
break;

case 560 : if (debug) { system.out.println("wildcardbounds2 ::= extends referencetype2"); }  //$non-nls-1$
consumewildcardbounds2extends();
break;

case 561 : if (debug) { system.out.println("wildcardbounds2 ::= super referencetype2"); }  //$non-nls-1$
consumewildcardbounds2super();
break;

case 562 : if (debug) { system.out.println("wildcard3 ::= question unsigned_right_shift"); }  //$non-nls-1$
consumewildcard3();
break;

case 563 : if (debug) { system.out.println("wildcard3 ::= question wildcardbounds3"); }  //$non-nls-1$
consumewildcard3withbounds();
break;

case 564 : if (debug) { system.out.println("wildcardbounds3 ::= extends referencetype3"); }  //$non-nls-1$
consumewildcardbounds3extends();
break;

case 565 : if (debug) { system.out.println("wildcardbounds3 ::= super referencetype3"); }  //$non-nls-1$
consumewildcardbounds3super();
break;

case 566 : if (debug) { system.out.println("typeparameterheader ::= identifier"); }  //$non-nls-1$
consumetypeparameterheader();
break;

case 567 : if (debug) { system.out.println("typeparameters ::= less typeparameterlist1"); }  //$non-nls-1$
consumetypeparameters();
break;

case 569 : if (debug) { system.out.println("typeparameterlist ::= typeparameterlist comma..."); }  //$non-nls-1$
consumetypeparameterlist();
break;

case 571 : if (debug) { system.out.println("typeparameter ::= typeparameterheader extends..."); }  //$non-nls-1$
consumetypeparameterwithextends();
break;

case 572 : if (debug) { system.out.println("typeparameter ::= typeparameterheader extends..."); }  //$non-nls-1$
consumetypeparameterwithextendsandbounds();
break;

case 574 : if (debug) { system.out.println("additionalboundlist ::= additionalboundlist..."); }  //$non-nls-1$
consumeadditionalboundlist();
break;

case 575 : if (debug) { system.out.println("additionalbound ::= and referencetype"); }  //$non-nls-1$
consumeadditionalbound();
break;

case 577 : if (debug) { system.out.println("typeparameterlist1 ::= typeparameterlist comma..."); }  //$non-nls-1$
consumetypeparameterlist1();
break;

case 578 : if (debug) { system.out.println("typeparameter1 ::= typeparameterheader greater"); }  //$non-nls-1$
consumetypeparameter1();
break;

case 579 : if (debug) { system.out.println("typeparameter1 ::= typeparameterheader extends..."); }  //$non-nls-1$
consumetypeparameter1withextends();
break;

case 580 : if (debug) { system.out.println("typeparameter1 ::= typeparameterheader extends..."); }  //$non-nls-1$
consumetypeparameter1withextendsandbounds();
break;

case 582 : if (debug) { system.out.println("additionalboundlist1 ::= additionalboundlist..."); }  //$non-nls-1$
consumeadditionalboundlist1();
break;

case 583 : if (debug) { system.out.println("additionalbound1 ::= and referencetype1"); }  //$non-nls-1$
consumeadditionalbound1();
break;

case 589 : if (debug) { system.out.println("unaryexpression_notname ::= plus pushposition..."); }  //$non-nls-1$
consumeunaryexpression(operatorids.plus);
break;

case 590 : if (debug) { system.out.println("unaryexpression_notname ::= minus pushposition..."); }  //$non-nls-1$
consumeunaryexpression(operatorids.minus);
break;

case 593 : if (debug) { system.out.println("unaryexpressionnotplusminus_notname ::= twiddle..."); }  //$non-nls-1$
consumeunaryexpression(operatorids.twiddle);
break;

case 594 : if (debug) { system.out.println("unaryexpressionnotplusminus_notname ::= not pushposition"); }  //$non-nls-1$
consumeunaryexpression(operatorids.not);
break;

case 597 : if (debug) { system.out.println("multiplicativeexpression_notname ::=..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.multiply);
break;

case 598 : if (debug) { system.out.println("multiplicativeexpression_notname ::= name multiply..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.multiply);
break;

case 599 : if (debug) { system.out.println("multiplicativeexpression_notname ::=..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.divide);
break;

case 600 : if (debug) { system.out.println("multiplicativeexpression_notname ::= name divide..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.divide);
break;

case 601 : if (debug) { system.out.println("multiplicativeexpression_notname ::=..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.remainder);
break;

case 602 : if (debug) { system.out.println("multiplicativeexpression_notname ::= name remainder..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.remainder);
break;

case 604 : if (debug) { system.out.println("additiveexpression_notname ::=..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.plus);
break;

case 605 : if (debug) { system.out.println("additiveexpression_notname ::= name plus..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.plus);
break;

case 606 : if (debug) { system.out.println("additiveexpression_notname ::=..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.minus);
break;

case 607 : if (debug) { system.out.println("additiveexpression_notname ::= name minus..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.minus);
break;

case 609 : if (debug) { system.out.println("shiftexpression_notname ::= shiftexpression_notname..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.left_shift);
break;

case 610 : if (debug) { system.out.println("shiftexpression_notname ::= name left_shift..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.left_shift);
break;

case 611 : if (debug) { system.out.println("shiftexpression_notname ::= shiftexpression_notname..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.right_shift);
break;

case 612 : if (debug) { system.out.println("shiftexpression_notname ::= name right_shift..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.right_shift);
break;

case 613 : if (debug) { system.out.println("shiftexpression_notname ::= shiftexpression_notname..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.unsigned_right_shift);
break;

case 614 : if (debug) { system.out.println("shiftexpression_notname ::= name unsigned_right_shift..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.unsigned_right_shift);
break;

case 616 : if (debug) { system.out.println("relationalexpression_notname ::= shiftexpression_notname"); }  //$non-nls-1$
consumebinaryexpression(operatorids.less);
break;

case 617 : if (debug) { system.out.println("relationalexpression_notname ::= name less..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.less);
break;

case 618 : if (debug) { system.out.println("relationalexpression_notname ::= shiftexpression_notname"); }  //$non-nls-1$
consumebinaryexpression(operatorids.greater);
break;

case 619 : if (debug) { system.out.println("relationalexpression_notname ::= name greater..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.greater);
break;

case 620 : if (debug) { system.out.println("relationalexpression_notname ::=..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.less_equal);
break;

case 621 : if (debug) { system.out.println("relationalexpression_notname ::= name less_equal..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.less_equal);
break;

case 622 : if (debug) { system.out.println("relationalexpression_notname ::=..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.greater_equal);
break;

case 623 : if (debug) { system.out.println("relationalexpression_notname ::= name greater_equal..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.greater_equal);
break;

case 625 : if (debug) { system.out.println("instanceofexpression_notname ::= name instanceof..."); }  //$non-nls-1$
consumeinstanceofexpressionwithname();
break;

case 626 : if (debug) { system.out.println("instanceofexpression_notname ::=..."); }  //$non-nls-1$
consumeinstanceofexpression();
break;

case 628 : if (debug) { system.out.println("equalityexpression_notname ::=..."); }  //$non-nls-1$
consumeequalityexpression(operatorids.equal_equal);
break;

case 629 : if (debug) { system.out.println("equalityexpression_notname ::= name equal_equal..."); }  //$non-nls-1$
consumeequalityexpressionwithname(operatorids.equal_equal);
break;

case 630 : if (debug) { system.out.println("equalityexpression_notname ::=..."); }  //$non-nls-1$
consumeequalityexpression(operatorids.not_equal);
break;

case 631 : if (debug) { system.out.println("equalityexpression_notname ::= name not_equal..."); }  //$non-nls-1$
consumeequalityexpressionwithname(operatorids.not_equal);
break;

case 633 : if (debug) { system.out.println("andexpression_notname ::= andexpression_notname and..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.and);
break;

case 634 : if (debug) { system.out.println("andexpression_notname ::= name and equalityexpression"); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.and);
break;

case 636 : if (debug) { system.out.println("exclusiveorexpression_notname ::=..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.xor);
break;

case 637 : if (debug) { system.out.println("exclusiveorexpression_notname ::= name xor andexpression"); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.xor);
break;

case 639 : if (debug) { system.out.println("inclusiveorexpression_notname ::=..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.or);
break;

case 640 : if (debug) { system.out.println("inclusiveorexpression_notname ::= name or..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.or);
break;

case 642 : if (debug) { system.out.println("conditionalandexpression_notname ::=..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.and_and);
break;

case 643 : if (debug) { system.out.println("conditionalandexpression_notname ::= name and_and..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.and_and);
break;

case 645 : if (debug) { system.out.println("conditionalorexpression_notname ::=..."); }  //$non-nls-1$
consumebinaryexpression(operatorids.or_or);
break;

case 646 : if (debug) { system.out.println("conditionalorexpression_notname ::= name or_or..."); }  //$non-nls-1$
consumebinaryexpressionwithname(operatorids.or_or);
break;

case 648 : if (debug) { system.out.println("conditionalexpression_notname ::=..."); }  //$non-nls-1$
consumeconditionalexpression(operatorids.questioncolon) ;
break;

case 649 : if (debug) { system.out.println("conditionalexpression_notname ::= name question..."); }  //$non-nls-1$
consumeconditionalexpressionwithname(operatorids.questioncolon) ;
break;

case 653 : if (debug) { system.out.println("annotationtypedeclarationheadername ::= modifiers at..."); }  //$non-nls-1$
consumeannotationtypedeclarationheadername() ;
break;

case 654 : if (debug) { system.out.println("annotationtypedeclarationheadername ::= modifiers at..."); }  //$non-nls-1$
consumeannotationtypedeclarationheadernamewithtypeparameters() ;
break;

case 655 : if (debug) { system.out.println("annotationtypedeclarationheadername ::= at..."); }  //$non-nls-1$
consumeannotationtypedeclarationheadernamewithtypeparameters() ;
break;

case 656 : if (debug) { system.out.println("annotationtypedeclarationheadername ::= at..."); }  //$non-nls-1$
consumeannotationtypedeclarationheadername() ;
break;

case 657 : if (debug) { system.out.println("annotationtypedeclarationheader ::=..."); }  //$non-nls-1$
consumeannotationtypedeclarationheader() ;
break;

case 658 : if (debug) { system.out.println("annotationtypedeclaration ::=..."); }  //$non-nls-1$
consumeannotationtypedeclaration() ;
break;

case 660 : if (debug) { system.out.println("annotationtypememberdeclarationsopt ::="); }  //$non-nls-1$
consumeemptyannotationtypememberdeclarationsopt() ;
break;

case 661 : if (debug) { system.out.println("annotationtypememberdeclarationsopt ::= nestedtype..."); }  //$non-nls-1$
consumeannotationtypememberdeclarationsopt() ;
break;

case 663 : if (debug) { system.out.println("annotationtypememberdeclarations ::=..."); }  //$non-nls-1$
consumeannotationtypememberdeclarations() ;
break;

case 664 : if (debug) { system.out.println("annotationmethodheadername ::= modifiersopt..."); }  //$non-nls-1$
consumemethodheadernamewithtypeparameters(true);
break;

case 665 : if (debug) { system.out.println("annotationmethodheadername ::= modifiersopt type..."); }  //$non-nls-1$
consumemethodheadername(true);
break;

case 666 : if (debug) { system.out.println("annotationmethodheaderdefaultvalueopt ::="); }  //$non-nls-1$
consumeemptymethodheaderdefaultvalue() ;
break;

case 667 : if (debug) { system.out.println("annotationmethodheaderdefaultvalueopt ::= defaultvalue"); }  //$non-nls-1$
consumemethodheaderdefaultvalue();
break;

case 668 : if (debug) { system.out.println("annotationmethodheader ::= annotationmethodheadername..."); }  //$non-nls-1$
consumemethodheader();
break;

case 669 : if (debug) { system.out.println("annotationtypememberdeclaration ::=..."); }  //$non-nls-1$
consumeannotationtypememberdeclaration() ;
break;

case 677 : if (debug) { system.out.println("annotationname ::= at name"); }  //$non-nls-1$
consumeannotationname() ;
break;

case 678 : if (debug) { system.out.println("normalannotation ::= annotationname lparen..."); }  //$non-nls-1$
consumenormalannotation() ;
break;

case 679 : if (debug) { system.out.println("membervaluepairsopt ::="); }  //$non-nls-1$
consumeemptymembervaluepairsopt() ;
break;

case 682 : if (debug) { system.out.println("membervaluepairs ::= membervaluepairs comma..."); }  //$non-nls-1$
consumemembervaluepairs() ;
break;

case 683 : if (debug) { system.out.println("membervaluepair ::= simplename equal entermembervalue..."); }  //$non-nls-1$
consumemembervaluepair() ;
break;

case 684 : if (debug) { system.out.println("entermembervalue ::="); }  //$non-nls-1$
consumeentermembervalue() ;
break;

case 685 : if (debug) { system.out.println("exitmembervalue ::="); }  //$non-nls-1$
consumeexitmembervalue() ;
break;

case 687 : if (debug) { system.out.println("membervalue ::= name"); }  //$non-nls-1$
consumemembervalueasname() ;
break;

case 690 : if (debug) { system.out.println("membervaluearrayinitializer ::=..."); }  //$non-nls-1$
consumemembervaluearrayinitializer() ;
break;

case 691 : if (debug) { system.out.println("membervaluearrayinitializer ::=..."); }  //$non-nls-1$
consumemembervaluearrayinitializer() ;
break;

case 692 : if (debug) { system.out.println("membervaluearrayinitializer ::=..."); }  //$non-nls-1$
consumeemptymembervaluearrayinitializer() ;
break;

case 693 : if (debug) { system.out.println("membervaluearrayinitializer ::=..."); }  //$non-nls-1$
consumeemptymembervaluearrayinitializer() ;
break;

case 694 : if (debug) { system.out.println("entermembervaluearrayinitializer ::="); }  //$non-nls-1$
consumeentermembervaluearrayinitializer() ;
break;

case 696 : if (debug) { system.out.println("membervalues ::= membervalues comma membervalue"); }  //$non-nls-1$
consumemembervalues() ;
break;

case 697 : if (debug) { system.out.println("markerannotation ::= annotationname"); }  //$non-nls-1$
consumemarkerannotation() ;
break;

case 698 : if (debug) { system.out.println("singlememberannotationmembervalue ::= membervalue"); }  //$non-nls-1$
consumesinglememberannotationmembervalue() ;
break;

case 699 : if (debug) { system.out.println("singlememberannotation ::= annotationname lparen..."); }  //$non-nls-1$
consumesinglememberannotation() ;
break;

case 700 : if (debug) { system.out.println("recoverymethodheadername ::= modifiersopt typeparameters"); }  //$non-nls-1$
consumerecoverymethodheadernamewithtypeparameters();
break;

case 701 : if (debug) { system.out.println("recoverymethodheadername ::= modifiersopt type..."); }  //$non-nls-1$
consumerecoverymethodheadername();
break;

case 702 : if (debug) { system.out.println("recoverymethodheader ::= recoverymethodheadername..."); }  //$non-nls-1$
consumemethodheader();
break;

case 703 : if (debug) { system.out.println("recoverymethodheader ::= recoverymethodheadername..."); }  //$non-nls-1$
consumemethodheader();
break;

}
}
protected void consumesimpleassertstatement() {
// assertstatement ::= 'assert' expression ';'
this.expressionlengthptr--;
pushonaststack(new assertstatement(this.expressionstack[this.expressionptr--], this.intstack[this.intptr--]));
}
protected void consumesinglememberannotation() {
// singlememberannotation ::= '@@' name '(' membervalue ')'
singlememberannotation singlememberannotation = null;

int oldindex = this.identifierptr;

typereference typereference = getannotationtype();
singlememberannotation = new singlememberannotation(typereference, this.intstack[this.intptr--]);
singlememberannotation.membervalue = this.expressionstack[this.expressionptr--];
this.expressionlengthptr--;
singlememberannotation.declarationsourceend = this.rparenpos;
pushonexpressionstack(singlememberannotation);


if(this.currentelement != null) {
annotationrecoverycheckpoint(singlememberannotation.sourcestart, singlememberannotation.declarationsourceend);

if (this.currentelement instanceof recoveredannotation) {
this.currentelement = ((recoveredannotation)this.currentelement).addannotation(singlememberannotation, oldindex);
}
}

if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
problemreporter().invalidusageofannotation(singlememberannotation);
}
this.recordstringliterals = true;
}
protected void consumesinglememberannotationmembervalue() {
// this rule is used for syntax recovery only
if (this.currentelement != null && this.currentelement instanceof recoveredannotation) {
recoveredannotation recoveredannotation = (recoveredannotation) this.currentelement;

recoveredannotation.setkind(recoveredannotation.single_member);
}

}

protected void consumesinglestaticimportdeclarationname() {
// singletypeimportdeclarationname ::= 'import' 'static' name
/* push an importref build from the last name
stored in the identifier stack. */

importreference impt;
int length;
char[][] tokens = new char[length = this.identifierlengthstack[this.identifierlengthptr--]][];
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(this.identifierstack, this.identifierptr + 1, tokens, 0, length);
system.arraycopy(this.identifierpositionstack, this.identifierptr + 1, positions, 0, length);
pushonaststack(impt = new importreference(tokens, positions, false, classfileconstants.accstatic));

this.modifiers = classfileconstants.accdefault;
this.modifierssourcestart = -1; // <-- see comment into modifiersflag(int)

if (this.currenttoken == tokennamesemicolon){
impt.declarationsourceend = this.scanner.currentposition - 1;
} else {
impt.declarationsourceend = impt.sourceend;
}
impt.declarationend = impt.declarationsourceend;
//this.endposition is just before the ;
impt.declarationsourcestart = this.intstack[this.intptr--];

if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
impt.modifiers = classfileconstants.accdefault; // convert the static import reference to a non-static importe reference
problemreporter().invalidusageofstaticimports(impt);
}

// recovery
if (this.currentelement != null){
this.lastcheckpoint = impt.declarationsourceend+1;
this.currentelement = this.currentelement.add(impt, 0);
this.lastignoredtoken = -1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumesingletypeimportdeclarationname() {
// singletypeimportdeclarationname ::= 'import' name
/* push an importref build from the last name
stored in the identifier stack. */

importreference impt;
int length;
char[][] tokens = new char[length = this.identifierlengthstack[this.identifierlengthptr--]][];
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(this.identifierstack, this.identifierptr + 1, tokens, 0, length);
system.arraycopy(this.identifierpositionstack, this.identifierptr + 1, positions, 0, length);
pushonaststack(impt = new importreference(tokens, positions, false, classfileconstants.accdefault));

if (this.currenttoken == tokennamesemicolon){
impt.declarationsourceend = this.scanner.currentposition - 1;
} else {
impt.declarationsourceend = impt.sourceend;
}
impt.declarationend = impt.declarationsourceend;
//this.endposition is just before the ;
impt.declarationsourcestart = this.intstack[this.intptr--];

// recovery
if (this.currentelement != null){
this.lastcheckpoint = impt.declarationsourceend+1;
this.currentelement = this.currentelement.add(impt, 0);
this.lastignoredtoken = -1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumestatementbreak() {
// breakstatement ::= 'break' ';'
// break pushs a position on this.intstack in case there is no label

pushonaststack(new breakstatement(null, this.intstack[this.intptr--], this.endstatementposition));

if (this.pendingrecoveredtype != null) {
// used only in statements recovery.
// this is not a real break statement but a placeholder for an existing local type.
// the break statement must be replace by the local type.
if (this.pendingrecoveredtype.allocation == null &&
this.endposition <= this.pendingrecoveredtype.declarationsourceend) {
this.aststack[this.astptr] = this.pendingrecoveredtype;
this.pendingrecoveredtype = null;
return;
}
this.pendingrecoveredtype = null;
}
}
protected void consumestatementbreakwithlabel() {
// breakstatement ::= 'break' identifier ';'
// break pushs a position on this.intstack in case there is no label

pushonaststack(
new breakstatement(
this.identifierstack[this.identifierptr--],
this.intstack[this.intptr--],
this.endstatementposition));
this.identifierlengthptr--;
}
protected void consumestatementcatch() {
// catchclause ::= 'catch' '(' formalparameter ')'    block

//catch are stored directly into the try
//has they always comes two by two....
//we remove one entry from the astlengthptr.
//the construction of the try statement must
//then fetch the catches using  2*i and 2*i + 1

this.astlengthptr--;
this.listlength = 0; // reset formalparameter counter (incremented for catch variable)
}
protected void consumestatementcontinue() {
// continuestatement ::= 'continue' ';'
// continue pushs a position on this.intstack in case there is no label

pushonaststack(
new continuestatement(
null,
this.intstack[this.intptr--],
this.endstatementposition));
}
protected void consumestatementcontinuewithlabel() {
// continuestatement ::= 'continue' identifier ';'
// continue pushs a position on this.intstack in case there is no label

pushonaststack(
new continuestatement(
this.identifierstack[this.identifierptr--],
this.intstack[this.intptr--],
this.endstatementposition));
this.identifierlengthptr--;
}
protected void consumestatementdo() {
// dostatement ::= 'do' statement 'while' '(' expression ')' ';'

//the 'while' pushes a value on this.intstack that we need to remove
this.intptr--;

statement statement = (statement) this.aststack[this.astptr];
this.expressionlengthptr--;
this.aststack[this.astptr] =
new dostatement(
this.expressionstack[this.expressionptr--],
statement,
this.intstack[this.intptr--],
this.endstatementposition);
}
protected void consumestatementexpressionlist() {
// statementexpressionlist ::= statementexpressionlist ',' statementexpression
concatexpressionlists();
}
protected void consumestatementfor() {
// forstatement ::= 'for' '(' forinitopt ';' expressionopt ';' forupdateopt ')' statement
// forstatementnoshortif ::= 'for' '(' forinitopt ';' expressionopt ';' forupdateopt ')' statementnoshortif

int length;
expression cond = null;
statement[] inits, updates;
boolean scope = true;

//statements
this.astlengthptr--;
statement statement = (statement) this.aststack[this.astptr--];

//updates are on the expresion stack
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) == 0) {
updates = null;
} else {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
updates = new statement[length],
0,
length);
}

if (this.expressionlengthstack[this.expressionlengthptr--] != 0)
cond = this.expressionstack[this.expressionptr--];

//inits may be on two different stacks
if ((length = this.astlengthstack[this.astlengthptr--]) == 0) {
inits = null;
scope = false;
} else {
if (length == -1) { //on this.expressionstack
scope = false;
length = this.expressionlengthstack[this.expressionlengthptr--];
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
inits = new statement[length],
0,
length);
} else { //on this.aststack
this.astptr -= length;
system.arraycopy(
this.aststack,
this.astptr + 1,
inits = new statement[length],
0,
length);
}
}
pushonaststack(
new forstatement(
inits,
cond,
updates,
statement,
scope,
this.intstack[this.intptr--],
this.endstatementposition));
}
protected void consumestatementifnoelse() {
// ifthenstatement ::=  'if' '(' expression ')' statement

//optimize the push/pop
this.expressionlengthptr--;
statement thenstatement = (statement) this.aststack[this.astptr];
this.aststack[this.astptr] =
new ifstatement(
this.expressionstack[this.expressionptr--],
thenstatement,
this.intstack[this.intptr--],
this.endstatementposition);
}
protected void consumestatementifwithelse() {
// ifthenelsestatement ::=  'if' '(' expression ')' statementnoshortif 'else' statement
// ifthenelsestatementnoshortif ::=  'if' '(' expression ')' statementnoshortif 'else' statementnoshortif

this.expressionlengthptr--;

// optimized {..., then, else } ==> {..., if }
this.astlengthptr--;

//optimize the push/pop
this.aststack[--this.astptr] =
new ifstatement(
this.expressionstack[this.expressionptr--],
(statement) this.aststack[this.astptr],
(statement) this.aststack[this.astptr + 1],
this.intstack[this.intptr--],
this.endstatementposition);
}
protected void consumestatementlabel() {
// labeledstatement ::= 'identifier' ':' statement
// labeledstatementnoshortif ::= 'identifier' ':' statementnoshortif

//optimize push/pop
statement statement = (statement) this.aststack[this.astptr];
this.aststack[this.astptr] =
new labeledstatement(
this.identifierstack[this.identifierptr],
statement,
this.identifierpositionstack[this.identifierptr--],
this.endstatementposition);
this.identifierlengthptr--;
}
protected void consumestatementreturn() {
// returnstatement ::= 'return' expressionopt ';'
// return pushs a position on this.intstack in case there is no expression

if (this.expressionlengthstack[this.expressionlengthptr--] != 0) {
pushonaststack(
new returnstatement(
this.expressionstack[this.expressionptr--],
this.intstack[this.intptr--],
this.endstatementposition)
);
} else {
pushonaststack(new returnstatement(null, this.intstack[this.intptr--], this.endstatementposition));
}
}
protected void consumestatementswitch() {
// switchstatement ::= 'switch' openblock '(' expression ')' switchblock

//openblock just makes the semantic action blockstart()
//the block is inlined but a scope need to be created
//if some declaration occurs.

int length;
switchstatement switchstatement = new switchstatement();
this.expressionlengthptr--;
switchstatement.expression = this.expressionstack[this.expressionptr--];
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
this.astptr -= length;
system.arraycopy(
this.aststack,
this.astptr + 1,
switchstatement.statements = new statement[length],
0,
length);
}
switchstatement.explicitdeclarations = this.realblockstack[this.realblockptr--];
pushonaststack(switchstatement);
switchstatement.blockstart = this.intstack[this.intptr--];
switchstatement.sourcestart = this.intstack[this.intptr--];
switchstatement.sourceend = this.endstatementposition;
if (length == 0 && !containscomment(switchstatement.blockstart, switchstatement.sourceend)) {
switchstatement.bits |= astnode.undocumentedemptyblock;
}
}
protected void consumestatementsynchronized() {
// synchronizedstatement ::= onlysynchronized '(' expression ')' block
//optimize the push/pop

if (this.astlengthstack[this.astlengthptr] == 0) {
this.astlengthstack[this.astlengthptr] = 1;
this.expressionlengthptr--;
this.aststack[++this.astptr] =
new synchronizedstatement(
this.expressionstack[this.expressionptr--],
null,
this.intstack[this.intptr--],
this.endstatementposition);
} else {
this.expressionlengthptr--;
this.aststack[this.astptr] =
new synchronizedstatement(
this.expressionstack[this.expressionptr--],
(block) this.aststack[this.astptr],
this.intstack[this.intptr--],
this.endstatementposition);
}
resetmodifiers();
}
protected void consumestatementthrow() {
// throwstatement ::= 'throw' expression ';'
this.expressionlengthptr--;
pushonaststack(new throwstatement(this.expressionstack[this.expressionptr--], this.intstack[this.intptr--], this.endstatementposition));
}
protected void consumestatementtry(boolean withfinally) {
//trystatement ::= 'try'  block catches
//trystatement ::= 'try'  block catchesopt finally

int length;
trystatement trystmt = new trystatement();
//finally
if (withfinally) {
this.astlengthptr--;
trystmt.finallyblock = (block) this.aststack[this.astptr--];
}
//catches are handle by two <argument-block> [see statementcatch]
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
if (length == 1) {
trystmt.catchblocks = new block[] {(block) this.aststack[this.astptr--]};
trystmt.catcharguments = new argument[] {(argument) this.aststack[this.astptr--]};
} else {
block[] bks = (trystmt.catchblocks = new block[length]);
argument[] args = (trystmt.catcharguments = new argument[length]);
while (length-- > 0) {
bks[length] = (block) this.aststack[this.astptr--];
args[length] = (argument) this.aststack[this.astptr--];
}
}
}
//try
this.astlengthptr--;
trystmt.tryblock = (block) this.aststack[this.astptr--];

//positions
trystmt.sourceend = this.endstatementposition;
trystmt.sourcestart = this.intstack[this.intptr--];
pushonaststack(trystmt);
}
protected void consumestatementwhile() {
// whilestatement ::= 'while' '(' expression ')' statement
// whilestatementnoshortif ::= 'while' '(' expression ')' statementnoshortif

this.expressionlengthptr--;
statement statement = (statement) this.aststack[this.astptr];
this.aststack[this.astptr] =
new whilestatement(
this.expressionstack[this.expressionptr--],
statement,
this.intstack[this.intptr--],
this.endstatementposition);
}
protected void consumestaticimportondemanddeclarationname() {
// typeimportondemanddeclarationname ::= 'import' 'static' name '.' '*'
/* push an importref build from the last name
stored in the identifier stack. */

importreference impt;
int length;
char[][] tokens = new char[length = this.identifierlengthstack[this.identifierlengthptr--]][];
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(this.identifierstack, this.identifierptr + 1, tokens, 0, length);
system.arraycopy(this.identifierpositionstack, this.identifierptr + 1, positions, 0, length);
pushonaststack(impt = new importreference(tokens, positions, true, classfileconstants.accstatic));

this.modifiers = classfileconstants.accdefault;
this.modifierssourcestart = -1; // <-- see comment into modifiersflag(int)

if (this.currenttoken == tokennamesemicolon){
impt.declarationsourceend = this.scanner.currentposition - 1;
} else {
impt.declarationsourceend = impt.sourceend;
}
impt.declarationend = impt.declarationsourceend;
//this.endposition is just before the ;
impt.declarationsourcestart = this.intstack[this.intptr--];

if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
impt.modifiers = classfileconstants.accdefault; // convert the static import reference to a non-static importe reference
problemreporter().invalidusageofstaticimports(impt);
}

// recovery
if (this.currentelement != null){
this.lastcheckpoint = impt.declarationsourceend+1;
this.currentelement = this.currentelement.add(impt, 0);
this.lastignoredtoken = -1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumestaticinitializer() {
// staticinitializer ::=  staticonly block
//push an initializer
//optimize the push/pop
block block = (block) this.aststack[this.astptr];
if (this.diet) block.bits &= ~astnode.undocumentedemptyblock; // clear bit set since was diet
initializer initializer = new initializer(block, classfileconstants.accstatic);
this.aststack[this.astptr] = initializer;
initializer.sourceend = this.endstatementposition;
initializer.declarationsourceend = flushcommentsdefinedpriorto(this.endstatementposition);
this.nestedmethod[this.nestedtype] --;
initializer.declarationsourcestart = this.intstack[this.intptr--];
initializer.bodystart = this.intstack[this.intptr--];
initializer.bodyend = this.endposition;
// doc comment
initializer.javadoc = this.javadoc;
this.javadoc = null;

// recovery
if (this.currentelement != null){
this.lastcheckpoint = initializer.declarationsourceend;
this.currentelement = this.currentelement.add(initializer, 0);
this.lastignoredtoken = -1;
}
}
protected void consumestaticonly() {
// staticonly ::= 'static'
int savedmodifierssourcestart = this.modifierssourcestart;
checkcomment(); // might update declaration source start
if (this.modifierssourcestart >= savedmodifierssourcestart) {
this.modifierssourcestart = savedmodifierssourcestart;
}
pushonintstack(this.scanner.currentposition);
pushonintstack(
this.modifierssourcestart >= 0 ? this.modifierssourcestart : this.scanner.startposition);
jumpovermethodbody();
this.nestedmethod[this.nestedtype]++;
resetmodifiers();
this.expressionlengthptr--; // remove the 0 pushed in consumetoken() for the static modifier

// recovery
if (this.currentelement != null){
this.recoveredstaticinitializerstart = this.intstack[this.intptr]; // remember start position only for static initializers
}
}
protected void consumeswitchblock() {
// switchblock ::= '{' switchblockstatements switchlabels '}'
concatnodelists();
}
protected void consumeswitchblockstatement() {
// switchblockstatement ::= switchlabels blockstatements
concatnodelists();
}
protected void consumeswitchblockstatements() {
// switchblockstatements ::= switchblockstatements switchblockstatement
concatnodelists();
}
protected void consumeswitchlabels() {
// switchlabels ::= switchlabels switchlabel
optimizedconcatnodelists();
}
protected void consumetoken(int type) {
/* remember the last consumed value */
/* try to minimize the number of build values */
//	// clear the commentptr of the scanner in case we read something different from a modifier
//	switch(type) {
//		case tokennameabstract :
//		case tokennamestrictfp :
//		case tokennamefinal :
//		case tokennamenative :
//		case tokennameprivate :
//		case tokennameprotected :
//		case tokennamepublic :
//		case tokennametransient :
//		case tokennamevolatile :
//		case tokennamestatic :
//		case tokennamesynchronized :
//			break;
//		default:
//			this.scanner.commentptr = -1;
//	}
//system.out.println(this.scanner.tostringaction(type));
switch (type) {
case tokennameidentifier :
pushidentifier();
if (this.scanner.useassertasanindentifier  &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
long positions = this.identifierpositionstack[this.identifierptr];
if(!this.statementrecoveryactivated) problemreporter().useassertasanidentifier((int) (positions >>> 32), (int) positions);
}
if (this.scanner.useenumasanindentifier  &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
long positions = this.identifierpositionstack[this.identifierptr];
if(!this.statementrecoveryactivated) problemreporter().useenumasanidentifier((int) (positions >>> 32), (int) positions);
}
break;
case tokennameinterface :
//'class' is pushing two int (positions) on the stack ==> 'interface' needs to do it too....
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
case tokennameabstract :
checkandsetmodifiers(classfileconstants.accabstract);
pushonexpressionstacklengthstack(0);
break;
case tokennamestrictfp :
checkandsetmodifiers(classfileconstants.accstrictfp);
pushonexpressionstacklengthstack(0);
break;
case tokennamefinal :
checkandsetmodifiers(classfileconstants.accfinal);
pushonexpressionstacklengthstack(0);
break;
case tokennamenative :
checkandsetmodifiers(classfileconstants.accnative);
pushonexpressionstacklengthstack(0);
break;
case tokennameprivate :
checkandsetmodifiers(classfileconstants.accprivate);
pushonexpressionstacklengthstack(0);
break;
case tokennameprotected :
checkandsetmodifiers(classfileconstants.accprotected);
pushonexpressionstacklengthstack(0);
break;
case tokennamepublic :
checkandsetmodifiers(classfileconstants.accpublic);
pushonexpressionstacklengthstack(0);
break;
case tokennametransient :
checkandsetmodifiers(classfileconstants.acctransient);
pushonexpressionstacklengthstack(0);
break;
case tokennamevolatile :
checkandsetmodifiers(classfileconstants.accvolatile);
pushonexpressionstacklengthstack(0);
break;
case tokennamestatic :
checkandsetmodifiers(classfileconstants.accstatic);
pushonexpressionstacklengthstack(0);
break;
case tokennamesynchronized :
this.synchronizedblocksourcestart = this.scanner.startposition;
checkandsetmodifiers(classfileconstants.accsynchronized);
pushonexpressionstacklengthstack(0);
break;
//==============================
case tokennamevoid :
pushidentifier(-t_void);
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
//push a default dimension while void is not part of the primitive
//declaration basetype and so takes the place of a type without getting into
//regular type parsing that generates a dimension on this.intstack
case tokennameboolean :
pushidentifier(-t_boolean);
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
case tokennamebyte :
pushidentifier(-t_byte);
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
case tokennamechar :
pushidentifier(-t_char);
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
case tokennamedouble :
pushidentifier(-t_double);
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
case tokennamefloat :
pushidentifier(-t_float);
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
case tokennameint :
pushidentifier(-t_int);
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
case tokennamelong :
pushidentifier(-t_long);
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
case tokennameshort :
pushidentifier(-t_short);
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
//==============================
case tokennameintegerliteral :
pushonexpressionstack(
new intliteral(
this.scanner.getcurrenttokensource(),
this.scanner.startposition,
this.scanner.currentposition - 1));
break;
case tokennamelongliteral :
pushonexpressionstack(
new longliteral(
this.scanner.getcurrenttokensource(),
this.scanner.startposition,
this.scanner.currentposition - 1));
break;
case tokennamefloatingpointliteral :
pushonexpressionstack(
new floatliteral(
this.scanner.getcurrenttokensource(),
this.scanner.startposition,
this.scanner.currentposition - 1));
break;
case tokennamedoubleliteral :
pushonexpressionstack(
new doubleliteral(
this.scanner.getcurrenttokensource(),
this.scanner.startposition,
this.scanner.currentposition - 1));
break;
case tokennamecharacterliteral :
pushonexpressionstack(
new charliteral(
this.scanner.getcurrenttokensource(),
this.scanner.startposition,
this.scanner.currentposition - 1));
break;
case tokennamestringliteral :
stringliteral stringliteral;
if (this.recordstringliterals &&
this.checkexternalizestrings &&
this.lastposistion < this.scanner.currentposition &&
!this.statementrecoveryactivated) {
stringliteral = createstringliteral(
this.scanner.getcurrenttokensourcestring(),
this.scanner.startposition,
this.scanner.currentposition - 1,
util.getlinenumber(this.scanner.startposition, this.scanner.lineends, 0, this.scanner.lineptr));
this.compilationunit.recordstringliteral(stringliteral, this.currentelement != null);
} else {
stringliteral = createstringliteral(
this.scanner.getcurrenttokensourcestring(),
this.scanner.startposition,
this.scanner.currentposition - 1,
0);
}
pushonexpressionstack(stringliteral);
break;
case tokennamefalse :
pushonexpressionstack(
new falseliteral(this.scanner.startposition, this.scanner.currentposition - 1));
break;
case tokennametrue :
pushonexpressionstack(
new trueliteral(this.scanner.startposition, this.scanner.currentposition - 1));
break;
case tokennamenull :
pushonexpressionstack(
new nullliteral(this.scanner.startposition, this.scanner.currentposition - 1));
break;
//============================
case tokennamesuper :
case tokennamethis :
this.endposition = this.scanner.currentposition - 1;
pushonintstack(this.scanner.startposition);
break;
case tokennameassert :
case tokennameimport :
case tokennamepackage :
case tokennamethrow :
case tokennamedo :
case tokennameif :
case tokennamefor :
case tokennameswitch :
case tokennametry :
case tokennamewhile :
case tokennamebreak :
case tokennamecontinue :
case tokennamereturn :
case tokennamecase :
pushonintstack(this.scanner.startposition);
break;
case tokennamenew :
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=40954
resetmodifiers();
pushonintstack(this.scanner.startposition);
break;
case tokennameclass :
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
case tokennameenum :
pushonintstack(this.scanner.currentposition - 1);
pushonintstack(this.scanner.startposition);
break;
case tokennamedefault :
pushonintstack(this.scanner.startposition);
pushonintstack(this.scanner.currentposition - 1);
break;
//let extra semantic action decide when to push
case tokennamerbracket :
this.endposition = this.scanner.startposition;
this.endstatementposition = this.scanner.currentposition - 1;
break;
case tokennamelbrace :
this.endstatementposition = this.scanner.currentposition - 1;
//$fall-through$
case tokennameplus :
case tokennameminus :
case tokennamenot :
case tokennametwiddle :
this.endposition = this.scanner.startposition;
break;
case tokennameplus_plus :
case tokennameminus_minus :
this.endposition = this.scanner.startposition;
this.endstatementposition = this.scanner.currentposition - 1;
break;
case tokennamerbrace:
case tokennamesemicolon :
this.endstatementposition = this.scanner.currentposition - 1;
this.endposition = this.scanner.startposition - 1;
//the item is not part of the potential futur expression/statement
break;
case tokennamerparen :
// in order to handle ( expression) ////// (cast)expression///// foo(x)
this.rparenpos = this.scanner.currentposition - 1; // position of the end of right parenthesis (in case of unicode \u0029) lex00101
break;
case tokennamelparen :
this.lparenpos = this.scanner.startposition;
break;
case tokennameat :
pushonintstack(this.scanner.startposition);
break;
case tokennamequestion  :
pushonintstack(this.scanner.startposition);
pushonintstack(this.scanner.currentposition - 1);
break;
case tokennameless :
pushonintstack(this.scanner.startposition);
break;
case tokennameellipsis :
pushonintstack(this.scanner.currentposition - 1);
break;
case tokennameequal  :
if (this.currentelement != null && this.currentelement instanceof recoveredannotation) {
recoveredannotation recoveredannotation = (recoveredannotation) this.currentelement;
if (recoveredannotation.membervalupairequalend == -1) {
recoveredannotation.membervalupairequalend = this.scanner.currentposition - 1;
}
}
break;
//  case tokennamecomma :
//  case tokennamecolon  :
//  case tokennamelbracket  :
//  case tokennamedot :
//  case tokennameerror :
//  case tokennameeof  :
//  case tokennamecase  :
//  case tokennamecatch  :
//  case tokennameelse  :
//  case tokennameextends  :
//  case tokennamefinally  :
//  case tokennameimplements  :
//  case tokennamethrows  :
//  case tokennameinstanceof  :
//  case tokennameequal_equal  :
//  case tokennameless_equal  :
//  case tokennamegreater_equal  :
//  case tokennamenot_equal  :
//  case tokennameleft_shift  :
//  case tokennameright_shift  :
//  case tokennameunsigned_right_shift :
//  case tokennameplus_equal  :
//  case tokennameminus_equal  :
//  case tokennamemultiply_equal  :
//  case tokennamedivide_equal  :
//  case tokennameand_equal  :
//  case tokennameor_equal  :
//  case tokennamexor_equal  :
//  case tokennameremainder_equal  :
//  case tokennameleft_shift_equal  :
//  case tokennameright_shift_equal  :
//  case tokennameunsigned_right_shift_equal  :
//  case tokennameor_or  :
//  case tokennameand_and  :
//  case tokennameremainder :
//  case tokennamexor  :
//  case tokennameand  :
//  case tokennamemultiply :
//  case tokennameor  :
//  case tokennamedivide :
//  case tokennamegreater  :
}
}
protected void consumetypeargument() {
pushongenericsstack(gettypereference(this.intstack[this.intptr--]));
}
protected void consumetypeargumentlist() {
concatgenericslists();
}
protected void consumetypeargumentlist1() {
concatgenericslists();
}
protected void consumetypeargumentlist2() {
concatgenericslists();
}
protected void consumetypeargumentlist3() {
concatgenericslists();
}
protected void consumetypeargumentreferencetype1() {
concatgenericslists();
pushongenericsstack(gettypereference(0));
this.intptr--;
}
protected void consumetypeargumentreferencetype2() {
concatgenericslists();
pushongenericsstack(gettypereference(0));
this.intptr--;
}
protected void consumetypearguments() {
concatgenericslists();
this.intptr--;

if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5 &&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
int length = this.genericslengthstack[this.genericslengthptr];
problemreporter().invalidusageoftypearguments(
(typereference)this.genericsstack[this.genericsptr - length + 1],
(typereference)this.genericsstack[this.genericsptr]);
}
}
protected void consumetypedeclarations() {
// typedeclarations ::= typedeclarations typedeclaration
concatnodelists();
}
protected void consumetypeheadernamewithtypeparameters() {
// classheadername ::= classheadername1 typeparameters
// interfaceheadername ::= interfaceheadername1 typeparameters
typedeclaration typedecl = (typedeclaration)this.aststack[this.astptr];

// consume type parameters
int length = this.genericslengthstack[this.genericslengthptr--];
this.genericsptr -= length;
system.arraycopy(this.genericsstack, this.genericsptr + 1, typedecl.typeparameters = new typeparameter[length], 0, length);

typedecl.bodystart = typedecl.typeparameters[length-1].declarationsourceend + 1;

this.listtypeparameterlength = 0;

if (this.currentelement != null) {
// is recovering
if (this.currentelement instanceof recoveredtype) {
recoveredtype recoveredtype = (recoveredtype) this.currentelement;
recoveredtype.pendingtypeparameters = null;
this.lastcheckpoint = typedecl.bodystart;
} else {
this.lastcheckpoint = typedecl.bodystart;
this.currentelement = this.currentelement.add(typedecl, 0);
this.lastignoredtoken = -1;
}
}
}
protected void consumetypeimportondemanddeclarationname() {
// typeimportondemanddeclarationname ::= 'import' name '.' '*'
/* push an importref build from the last name
stored in the identifier stack. */

importreference impt;
int length;
char[][] tokens = new char[length = this.identifierlengthstack[this.identifierlengthptr--]][];
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(this.identifierstack, this.identifierptr + 1, tokens, 0, length);
system.arraycopy(this.identifierpositionstack, this.identifierptr + 1, positions, 0, length);
pushonaststack(impt = new importreference(tokens, positions, true, classfileconstants.accdefault));

if (this.currenttoken == tokennamesemicolon){
impt.declarationsourceend = this.scanner.currentposition - 1;
} else {
impt.declarationsourceend = impt.sourceend;
}
impt.declarationend = impt.declarationsourceend;
//this.endposition is just before the ;
impt.declarationsourcestart = this.intstack[this.intptr--];

// recovery
if (this.currentelement != null){
this.lastcheckpoint = impt.declarationsourceend+1;
this.currentelement = this.currentelement.add(impt, 0);
this.lastignoredtoken = -1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumetypeparameter1() {
// nothing to do
}
protected void consumetypeparameter1withextends() {
//typeparameter1 ::= typeparameterheader 'extends' referencetype1
typereference supertype = (typereference) this.genericsstack[this.genericsptr--];
this.genericslengthptr--;
typeparameter typeparameter = (typeparameter) this.genericsstack[this.genericsptr];
typeparameter.declarationsourceend = supertype.sourceend;
typeparameter.type = supertype;
supertype.bits |= astnode.issupertype;
this.genericsstack[this.genericsptr] = typeparameter;
}
protected void consumetypeparameter1withextendsandbounds() {
//typeparameter1 ::= typeparameterheader 'extends' referencetype additionalboundlist1
int additionalboundslength = this.genericslengthstack[this.genericslengthptr--];
typereference[] bounds = new typereference[additionalboundslength];
this.genericsptr -= additionalboundslength;
system.arraycopy(this.genericsstack, this.genericsptr + 1, bounds, 0, additionalboundslength);
typereference supertype = gettypereference(this.intstack[this.intptr--]);
typeparameter typeparameter = (typeparameter) this.genericsstack[this.genericsptr];
typeparameter.declarationsourceend = bounds[additionalboundslength - 1].sourceend;
typeparameter.type = supertype;
supertype.bits |= astnode.issupertype;
typeparameter.bounds = bounds;
for (int i = 0, max = bounds.length; i < max; i++) {
bounds[i].bits |= astnode.issupertype;
}
}
protected void consumetypeparameterheader() {
//typeparameterheader ::= identifier
typeparameter typeparameter = new typeparameter();
long pos = this.identifierpositionstack[this.identifierptr];
final int end = (int) pos;
typeparameter.declarationsourceend = end;
typeparameter.sourceend = end;
final int start = (int) (pos >>> 32);
typeparameter.declarationsourcestart = start;
typeparameter.sourcestart = start;
typeparameter.name = this.identifierstack[this.identifierptr--];
this.identifierlengthptr--;
pushongenericsstack(typeparameter);

this.listtypeparameterlength++;
}
protected void consumetypeparameterlist() {
//typeparameterlist ::= typeparameterlist ',' typeparameter
concatgenericslists();
}
protected void consumetypeparameterlist1() {
//typeparameterlist1 ::= typeparameterlist ',' typeparameter1
concatgenericslists();
}
protected void consumetypeparameters() {
int startpos = this.intstack[this.intptr--];

if(this.currentelement != null) {
if(this.currentelement instanceof recoveredtype) {
recoveredtype recoveredtype =(recoveredtype) this.currentelement;
int length = this.genericslengthstack[this.genericslengthptr];
typeparameter[] typeparameters = new typeparameter[length];
system.arraycopy(this.genericsstack, this.genericsptr - length + 1, typeparameters, 0, length);

recoveredtype.add(typeparameters, startpos);
}
}


if(!this.statementrecoveryactivated &&
this.options.sourcelevel < classfileconstants.jdk1_5&&
this.lasterrorendpositionbeforerecovery < this.scanner.currentposition) {
int length = this.genericslengthstack[this.genericslengthptr];
problemreporter().invalidusageoftypeparameters(
(typeparameter) this.genericsstack[this.genericsptr - length + 1],
(typeparameter) this.genericsstack[this.genericsptr]);
}
}
protected void consumetypeparameterwithextends() {
//typeparameter ::= typeparameterheader 'extends' referencetype
typereference supertype = gettypereference(this.intstack[this.intptr--]);
typeparameter typeparameter = (typeparameter) this.genericsstack[this.genericsptr];
typeparameter.declarationsourceend = supertype.sourceend;
typeparameter.type = supertype;
supertype.bits |= astnode.issupertype;
}
protected void consumetypeparameterwithextendsandbounds() {
//typeparameter ::= typeparameterheader 'extends' referencetype additionalboundlist
int additionalboundslength = this.genericslengthstack[this.genericslengthptr--];
typereference[] bounds = new typereference[additionalboundslength];
this.genericsptr -= additionalboundslength;
system.arraycopy(this.genericsstack, this.genericsptr + 1, bounds, 0, additionalboundslength);
typereference supertype = gettypereference(this.intstack[this.intptr--]);
typeparameter typeparameter = (typeparameter) this.genericsstack[this.genericsptr];
typeparameter.type = supertype;
supertype.bits |= astnode.issupertype;
typeparameter.bounds = bounds;
typeparameter.declarationsourceend = bounds[additionalboundslength - 1].sourceend;
for (int i = 0, max = bounds.length; i < max; i++) {
bounds[i].bits |= astnode.issupertype;
}
}
protected void consumeunaryexpression(int op) {
// unaryexpression ::= '+' pushposition unaryexpression
// unaryexpression ::= '-' pushposition unaryexpression
// unaryexpressionnotplusminus ::= '~' pushposition unaryexpression
// unaryexpressionnotplusminus ::= '!' pushposition unaryexpression

//optimize the push/pop

//handle manually the -2147483648 while it is not a real
//computation of an - and 2147483648 (notice that 2147483648
//is integer.max_value+1.....)
//same for -9223372036854775808l ............

//this.intstack have the position of the operator

expression r, exp = this.expressionstack[this.expressionptr];
if (op == minus) {
if ((exp instanceof intliteral) && (((intliteral) exp).mayrepresentmin_value())) {
r = this.expressionstack[this.expressionptr] = new intliteralminvalue();
} else {
if ((exp instanceof longliteral) && (((longliteral) exp).mayrepresentmin_value())) {
r = this.expressionstack[this.expressionptr] = new longliteralminvalue();
} else {
r = this.expressionstack[this.expressionptr] = new unaryexpression(exp, op);
}
}
} else {
r = this.expressionstack[this.expressionptr] = new unaryexpression(exp, op);
}
r.sourcestart = this.intstack[this.intptr--];
r.sourceend = exp.sourceend;
}
protected void consumeunaryexpression(int op, boolean post) {
// preincrementexpression ::= '++' pushposition unaryexpression
// predecrementexpression ::= '--' pushposition unaryexpression

// ++ and -- operators
//optimize the push/pop

//this.intstack has the position of the operator when prefix

expression lefthandside = this.expressionstack[this.expressionptr];
if (lefthandside instanceof reference) {
// ++foo()++ is unvalid
if (post) {
this.expressionstack[this.expressionptr] =
new postfixexpression(
lefthandside,
intliteral.one,
op,
this.endstatementposition);
} else {
this.expressionstack[this.expressionptr] =
new prefixexpression(
lefthandside,
intliteral.one,
op,
this.intstack[this.intptr--]);
}
} else {
//the ++ or the -- is not taken into account if code gen proceeds
if (!post) {
this.intptr--;
}
if(!this.statementrecoveryactivated) problemreporter().invalidunaryexpression(lefthandside);
}
}
protected void consumevariabledeclarators() {
// variabledeclarators ::= variabledeclarators ',' variabledeclarator
optimizedconcatnodelists();
}
protected void consumevariableinitializers() {
// variableinitializers ::= variableinitializers ',' variableinitializer
concatexpressionlists();
}
protected void consumewildcard() {
final wildcard wildcard = new wildcard(wildcard.unbound);
wildcard.sourceend = this.intstack[this.intptr--];
wildcard.sourcestart = this.intstack[this.intptr--];
pushongenericsstack(wildcard);
}
protected void consumewildcard1() {
final wildcard wildcard = new wildcard(wildcard.unbound);
wildcard.sourceend = this.intstack[this.intptr--];
wildcard.sourcestart = this.intstack[this.intptr--];
pushongenericsstack(wildcard);
}
protected void consumewildcard1withbounds() {
// nothing to do
// the wildcard is created by the consumewildcardbounds1extends or by consumewildcardbounds1super
}
protected void consumewildcard2() {
final wildcard wildcard = new wildcard(wildcard.unbound);
wildcard.sourceend = this.intstack[this.intptr--];
wildcard.sourcestart = this.intstack[this.intptr--];
pushongenericsstack(wildcard);
}
protected void consumewildcard2withbounds() {
// nothing to do
// the wildcard is created by the consumewildcardbounds2extends or by consumewildcardbounds2super
}
protected void consumewildcard3() {
final wildcard wildcard = new wildcard(wildcard.unbound);
wildcard.sourceend = this.intstack[this.intptr--];
wildcard.sourcestart = this.intstack[this.intptr--];
pushongenericsstack(wildcard);
}
protected void consumewildcard3withbounds() {
// nothing to do
// the wildcard is created by the consumewildcardbounds3extends or by consumewildcardbounds3super
}
protected void consumewildcardbounds1extends() {
wildcard wildcard = new wildcard(wildcard.extends);
wildcard.bound = (typereference) this.genericsstack[this.genericsptr];
wildcard.sourceend = wildcard.bound.sourceend;
this.intptr--; // remove end position of the '?'
wildcard.sourcestart = this.intstack[this.intptr--];
this.genericsstack[this.genericsptr] = wildcard;
}
protected void consumewildcardbounds1super() {
wildcard wildcard = new wildcard(wildcard.super);
wildcard.bound = (typereference) this.genericsstack[this.genericsptr];
this.intptr--; // remove the starting position of the super keyword
wildcard.sourceend = wildcard.bound.sourceend;
this.intptr--; // remove end position of the '?'
wildcard.sourcestart = this.intstack[this.intptr--];
this.genericsstack[this.genericsptr] = wildcard;
}
protected void consumewildcardbounds2extends() {
wildcard wildcard = new wildcard(wildcard.extends);
wildcard.bound = (typereference) this.genericsstack[this.genericsptr];
wildcard.sourceend = wildcard.bound.sourceend;
this.intptr--; // remove end position of the '?'
wildcard.sourcestart = this.intstack[this.intptr--];
this.genericsstack[this.genericsptr] = wildcard;
}
protected void consumewildcardbounds2super() {
wildcard wildcard = new wildcard(wildcard.super);
wildcard.bound = (typereference) this.genericsstack[this.genericsptr];
this.intptr--; // remove the starting position of the super keyword
wildcard.sourceend = wildcard.bound.sourceend;
this.intptr--; // remove end position of the '?'
wildcard.sourcestart = this.intstack[this.intptr--];
this.genericsstack[this.genericsptr] = wildcard;
}
protected void consumewildcardbounds3extends() {
wildcard wildcard = new wildcard(wildcard.extends);
wildcard.bound = (typereference) this.genericsstack[this.genericsptr];
wildcard.sourceend = wildcard.bound.sourceend;
this.intptr--; // remove end position of the '?'
wildcard.sourcestart = this.intstack[this.intptr--];
this.genericsstack[this.genericsptr] = wildcard;
}
protected void consumewildcardbounds3super() {
wildcard wildcard = new wildcard(wildcard.super);
wildcard.bound = (typereference) this.genericsstack[this.genericsptr];
this.intptr--; // remove the starting position of the super keyword
wildcard.sourceend = wildcard.bound.sourceend;
this.intptr--; // remove end position of the '?'
wildcard.sourcestart = this.intstack[this.intptr--];
this.genericsstack[this.genericsptr] = wildcard;
}
protected void consumewildcardboundsextends() {
wildcard wildcard = new wildcard(wildcard.extends);
wildcard.bound = gettypereference(this.intstack[this.intptr--]);
wildcard.sourceend = wildcard.bound.sourceend;
this.intptr--; // remove end position of the '?'
wildcard.sourcestart = this.intstack[this.intptr--];
pushongenericsstack(wildcard);
}
protected void consumewildcardboundssuper() {
wildcard wildcard = new wildcard(wildcard.super);
wildcard.bound = gettypereference(this.intstack[this.intptr--]);
this.intptr--; // remove the starting position of the super keyword
wildcard.sourceend = wildcard.bound.sourceend;
this.intptr--; // remove end position of the '?'
wildcard.sourcestart = this.intstack[this.intptr--];
pushongenericsstack(wildcard);
}
protected void consumewildcardwithbounds() {
// nothing to do
// the wildcard is created by the consumewildcardboundsextends or by consumewildcardboundssuper
}
/**
* given the current comment stack, answer whether some comment is available in a certain exclusive range
*
* @@param sourcestart int
* @@param sourceend int
* @@return boolean
*/
public boolean containscomment(int sourcestart, int sourceend) {
int icomment = this.scanner.commentptr;
for (; icomment >= 0; icomment--) {
int commentstart = this.scanner.commentstarts[icomment];
if (commentstart < 0) commentstart = -commentstart;
// ignore comments before start
if (commentstart < sourcestart) continue;
// ignore comments after end
if (commentstart > sourceend) continue;
return true;
}
return false;
}

public methoddeclaration converttomethoddeclaration(constructordeclaration c, compilationresult compilationresult) {
methoddeclaration m = new methoddeclaration(compilationresult);
m.typeparameters = c.typeparameters;
m.sourcestart = c.sourcestart;
m.sourceend = c.sourceend;
m.bodystart = c.bodystart;
m.bodyend = c.bodyend;
m.declarationsourceend = c.declarationsourceend;
m.declarationsourcestart = c.declarationsourcestart;
m.selector = c.selector;
m.statements = c.statements;
m.modifiers = c.modifiers;
m.annotations = c.annotations;
m.arguments = c.arguments;
m.thrownexceptions = c.thrownexceptions;
m.explicitdeclarations = c.explicitdeclarations;
m.returntype = null;
m.javadoc = c.javadoc;
return m;
}

protected typereference copydims(typereference typeref, int dim) {
return typeref.copydims(dim);
}
protected fielddeclaration createfielddeclaration(char[] fielddeclarationname, int sourcestart, int sourceend) {
return new fielddeclaration(fielddeclarationname, sourcestart, sourceend);
}
protected javadocparser createjavadocparser() {
return new javadocparser(this);
}
protected localdeclaration createlocaldeclaration(char[] localdeclarationname, int sourcestart, int sourceend) {
return new localdeclaration(localdeclarationname, sourcestart, sourceend);
}
protected stringliteral createstringliteral(char[] token, int start, int end, int linenumber) {
return new stringliteral(token, start, end, linenumber);
}
protected recoveredtype currentrecoverytype() {
if(this.currentelement != null) {
if(this.currentelement instanceof recoveredtype) {
return (recoveredtype) this.currentelement;
} else {
return this.currentelement.enclosingtype();
}
}
return null;
}
public compilationunitdeclaration dietparse(icompilationunit sourceunit, compilationresult compilationresult) {

compilationunitdeclaration parsedunit;
boolean old = this.diet;
try {
this.diet = true;
parsedunit = parse(sourceunit, compilationresult);
} finally {
this.diet = old;
}
return parsedunit;
}
protected void dispatchdeclarationinto(int length) {
/* they are length on this.aststack that should go into
methods fields constructors lists of the typedecl

return if there is a constructor declaration in the methods declaration */


// looks for the size of each array .

if (length == 0)
return;
int[] flag = new int[length + 1]; //plus one -- see <here>
int size1 = 0, size2 = 0, size3 = 0;
boolean hasabstractmethods = false;
for (int i = length - 1; i >= 0; i--) {
astnode astnode = this.aststack[this.astptr--];
if (astnode instanceof abstractmethoddeclaration) {
//methods and constructors have been regrouped into one single list
flag[i] = 2;
size2++;
if (((abstractmethoddeclaration) astnode).isabstract()) {
hasabstractmethods = true;
}
} else if (astnode instanceof typedeclaration) {
flag[i] = 3;
size3++;
} else {
//field
flag[i] = 1;
size1++;
}
}

//arrays creation
typedeclaration typedecl = (typedeclaration) this.aststack[this.astptr];
if (size1 != 0) {
typedecl.fields = new fielddeclaration[size1];
}
if (size2 != 0) {
typedecl.methods = new abstractmethoddeclaration[size2];
if (hasabstractmethods) typedecl.bits |= astnode.hasabstractmethods;
}
if (size3 != 0) {
typedecl.membertypes = new typedeclaration[size3];
}

//arrays fill up
size1 = size2 = size3 = 0;
int flagi = flag[0], start = 0;
int length2;
for (int end = 0; end <= length; end++) //<here> the plus one allows to
{
if (flagi != flag[end]) //treat the last element as a ended flag.....
{ //array copy
switch (flagi) {
case 1 :
size1 += (length2 = end - start);
system.arraycopy(
this.aststack,
this.astptr + start + 1,
typedecl.fields,
size1 - length2,
length2);
break;
case 2 :
size2 += (length2 = end - start);
system.arraycopy(
this.aststack,
this.astptr + start + 1,
typedecl.methods,
size2 - length2,
length2);
break;
case 3 :
size3 += (length2 = end - start);
system.arraycopy(
this.aststack,
this.astptr + start + 1,
typedecl.membertypes,
size3 - length2,
length2);
break;
}
flagi = flag[start = end];
}
}

if (typedecl.membertypes != null) {
for (int i = typedecl.membertypes.length - 1; i >= 0; i--) {
typedecl.membertypes[i].enclosingtype = typedecl;
}
}
}
protected void dispatchdeclarationintoenumdeclaration(int length) {

if (length == 0)
return;
int[] flag = new int[length + 1]; //plus one -- see <here>
int size1 = 0, size2 = 0, size3 = 0;
typedeclaration enumdeclaration = (typedeclaration) this.aststack[this.astptr - length];
boolean hasabstractmethods = false;
for (int i = length - 1; i >= 0; i--) {
astnode astnode = this.aststack[this.astptr--];
if (astnode instanceof abstractmethoddeclaration) {
//methods and constructors have been regrouped into one single list
flag[i] = 2;
size2++;
if (((abstractmethoddeclaration) astnode).isabstract()) {
hasabstractmethods = true;
}
} else if (astnode instanceof typedeclaration) {
flag[i] = 3;
size3++;
} else if (astnode instanceof fielddeclaration) {
flag[i] = 1;
size1++;
//         if(astnode instanceof enumconstant) {
//            enumconstant constant = (enumconstant) astnode;
//            ((allocationexpression)constant.initialization).type = new singletypereference(enumdeclaration.name,
//                  (((long) enumdeclaration.sourcestart) << 32) + enumdeclaration.sourceend);
//         }
}
}

//arrays creation
if (size1 != 0) {
enumdeclaration.fields = new fielddeclaration[size1];
}
if (size2 != 0) {
enumdeclaration.methods = new abstractmethoddeclaration[size2];
if (hasabstractmethods) enumdeclaration.bits |= astnode.hasabstractmethods;
}
if (size3 != 0) {
enumdeclaration.membertypes = new typedeclaration[size3];
}

//arrays fill up
size1 = size2 = size3 = 0;
int flagi = flag[0], start = 0;
int length2;
for (int end = 0; end <= length; end++) //<here> the plus one allows to
{
if (flagi != flag[end]) //treat the last element as a ended flag.....
{ //array copy
switch (flagi) {
case 1 :
size1 += (length2 = end - start);
system.arraycopy(
this.aststack,
this.astptr + start + 1,
enumdeclaration.fields,
size1 - length2,
length2);
break;
case 2 :
size2 += (length2 = end - start);
system.arraycopy(
this.aststack,
this.astptr + start + 1,
enumdeclaration.methods,
size2 - length2,
length2);
break;
case 3 :
size3 += (length2 = end - start);
system.arraycopy(
this.aststack,
this.astptr + start + 1,
enumdeclaration.membertypes,
size3 - length2,
length2);
break;
}
flagi = flag[start = end];
}
}

if (enumdeclaration.membertypes != null) {
for (int i = enumdeclaration.membertypes.length - 1; i >= 0; i--) {
enumdeclaration.membertypes[i].enclosingtype = enumdeclaration;
}
}}
protected compilationunitdeclaration endparse(int act) {

this.lastact = act;

if(this.statementrecoveryactivated) {
recoveredelement recoveredelement = buildinitialrecoverystate();

if (recoveredelement != null) {
recoveredelement.topelement().updateparsetree();
}

if(this.haserror) resetstacks();
} else if (this.currentelement != null){
if (verbose_recovery){
system.out.print(messages.parser_syntaxrecovery);
system.out.println("--------------------------");		 //$non-nls-1$
system.out.println(this.compilationunit);
system.out.println("----------------------------------"); //$non-nls-1$
}
this.currentelement.topelement().updateparsetree();
} else {
if (this.diet & verbose_recovery){
system.out.print(messages.parser_regularparse);
system.out.println("--------------------------");	 //$non-nls-1$
system.out.println(this.compilationunit);
system.out.println("----------------------------------"); //$non-nls-1$
}
}
persistlineseparatorpositions();
for (int i = 0; i < this.scanner.foundtaskcount; i++){
if(!this.statementrecoveryactivated) problemreporter().task(
new string(this.scanner.foundtasktags[i]),
new string(this.scanner.foundtaskmessages[i]),
this.scanner.foundtaskpriorities[i] == null ? null : new string(this.scanner.foundtaskpriorities[i]),
this.scanner.foundtaskpositions[i][0],
this.scanner.foundtaskpositions[i][1]);
}
return this.compilationunit;
}
/*
* flush comments defined prior to a given positions.
*
* note: comments are stacked in syntactical order
*
* either answer given <position>, or the end position of a comment line
* immediately following the <position> (same line)
*
* e.g.
* void foo(){
* } // end of method foo
*/
public int flushcommentsdefinedpriorto(int position) {

int lastcommentindex = this.scanner.commentptr;
if (lastcommentindex < 0) return position; // no comment

// compute the index of the first obsolete comment
int index = lastcommentindex;
int validcount = 0;
while (index >= 0){
int commentend = this.scanner.commentstops[index];
if (commentend < 0) commentend = -commentend; // negative end position for non-javadoc comments
if (commentend <= position){
break;
}
index--;
validcount++;
}
// if the source at <position> is immediately followed by a line comment, then
// flush this comment and shift <position> to the comment end.
if (validcount > 0){
int immediatecommentend = -this.scanner.commentstops[index+1]; //non-javadoc comment end positions are negative
if (immediatecommentend > 0){ // only tolerating non-javadoc comments
// is there any line break until the end of the immediate comment ? (thus only tolerating line comment)
immediatecommentend--; // comment end in one char too far
if (util.getlinenumber(position, this.scanner.lineends, 0, this.scanner.lineptr)
== util.getlinenumber(immediatecommentend, this.scanner.lineends, 0, this.scanner.lineptr)){
position = immediatecommentend;
validcount--; // flush this comment
index++;
}
}
}

if (index < 0) return position; // no obsolete comment

switch (validcount) {
case 0:
// do nothing
break;
// move valid comment infos, overriding obsolete comment infos
case 2:
this.scanner.commentstarts[0] = this.scanner.commentstarts[index+1];
this.scanner.commentstops[0] = this.scanner.commentstops[index+1];
this.scanner.commenttagstarts[0] = this.scanner.commenttagstarts[index+1];
this.scanner.commentstarts[1] = this.scanner.commentstarts[index+2];
this.scanner.commentstops[1] = this.scanner.commentstops[index+2];
this.scanner.commenttagstarts[1] = this.scanner.commenttagstarts[index+2];
break;
case 1:
this.scanner.commentstarts[0] = this.scanner.commentstarts[index+1];
this.scanner.commentstops[0] = this.scanner.commentstops[index+1];
this.scanner.commenttagstarts[0] = this.scanner.commenttagstarts[index+1];
break;
default:
system.arraycopy(this.scanner.commentstarts, index + 1, this.scanner.commentstarts, 0, validcount);
system.arraycopy(this.scanner.commentstops, index + 1, this.scanner.commentstops, 0, validcount);
system.arraycopy(this.scanner.commenttagstarts, index + 1, this.scanner.commenttagstarts, 0, validcount);
}
this.scanner.commentptr = validcount - 1;
return position;
}

protected typereference getannotationtype() {
int length = this.identifierlengthstack[this.identifierlengthptr--];
if (length == 1) {
return new singletypereference(
this.identifierstack[this.identifierptr],
this.identifierpositionstack[this.identifierptr--]);
} else {
char[][] tokens = new char[length][];
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(this.identifierstack, this.identifierptr + 1, tokens, 0, length);
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);
return new qualifiedtypereference(tokens, positions);
}
}
public int getfirsttoken() {
// the first token is a virtual token that
// allows the parser to parse several goals
// even if they aren't lalr(1)....
// goal ::= '++' compilationunit
// goal ::= '--' methodbody
// goal ::= '==' constructorbody
// -- initializer
// goal ::= '>>' staticinitializer
// goal ::= '>>' block
// -- error recovery
// goal ::= '>>>' headers
// goal ::= '*' blockstatements
// goal ::= '*' methodpushmodifiersheader
// -- jdom
// goal ::= '&&' fielddeclaration
// goal ::= '||' importdeclaration
// goal ::= '?' packagedeclaration
// goal ::= '+' typedeclaration
// goal ::= '/' genericmethoddeclaration
// goal ::= '&' classbodydeclaration
// -- code snippet
// goal ::= '%' expression
// -- completion parser
// goal ::= '!' constructorblockstatementsopt
// goal ::= '~' blockstatementsopt

return this.firsttoken;
}
/*
* answer back an array of sourcestart/sourceend positions of the available javadoc comments.
* the array is a flattened structure: 2*n entries with consecutives start and end positions.
*
* if no javadoc is available, then null is answered instead of an empty array.
*
* e.g. { 10, 20, 25, 45 }  --> javadoc1 from 10 to 20, javadoc2 from 25 to 45
*/
public int[] getjavadocpositions() {

int javadoccount = 0;
int max = this.scanner.commentptr;
for (int i = 0; i <= max; i++){
// javadoc only (non javadoc comment have negative start and/or end positions.)
if (this.scanner.commentstarts[i] >= 0 && this.scanner.commentstops[i] > 0) {
javadoccount++;
}
}
if (javadoccount == 0) return null;

int[] positions = new int[2*javadoccount];
int index = 0;
for (int i = 0; i <= max; i++){
// javadoc only (non javadoc comment have negative start and/or end positions.)
int commentstart = this.scanner.commentstarts[i];
if (commentstart >= 0) {
int commentstop = this.scanner.commentstops[i];
if (commentstop > 0){
positions[index++] = commentstart;
positions[index++] = commentstop-1; //stop is one over
}
}
}
return positions;
}
public void getmethodbodies(compilationunitdeclaration unit) {
//fill the methods bodies in order for the code to be generated

if (unit == null) return;

if (unit.ignoremethodbodies) {
unit.ignorefurtherinvestigation = true;
return;
// if initial diet parse did not work, no need to dig into method bodies.
}

if ((unit.bits & astnode.hasallmethodbodies) != 0)
return; //work already done ...

// save existing values to restore them at the end of the parsing process
// see bug 47079 for more details
int[] oldlineends = this.scanner.lineends;
int oldlineptr = this.scanner.lineptr;

//real parse of the method....
compilationresult compilationresult = unit.compilationresult;
char[] contents = this.readmanager != null
? this.readmanager.getcontents(compilationresult.compilationunit)
: compilationresult.compilationunit.getcontents();
this.scanner.setsource(contents, compilationresult);

if (this.javadocparser != null && this.javadocparser.checkdoccomment) {
this.javadocparser.scanner.setsource(contents);
}
if (unit.types != null) {
for (int i = 0, length = unit.types.length; i < length; i++)
unit.types[i].parsemethods(this, unit);
}

// tag unit has having read bodies
unit.bits |= astnode.hasallmethodbodies;

// this is done to prevent any side effects on the compilation unit result
// line separator positions array.
this.scanner.lineends = oldlineends;
this.scanner.lineptr = oldlineptr;
}
protected char getnextcharacter(char[] comment, int[] index) {
char nextcharacter = comment[index[0]++];
switch(nextcharacter) {
case '\\' :
int c1, c2, c3, c4;
index[0]++;
while (comment[index[0]] == 'u') index[0]++;
if (!(((c1 = scannerhelper.getnumericvalue(comment[index[0]++])) > 15
|| c1 < 0)
|| ((c2 = scannerhelper.getnumericvalue(comment[index[0]++])) > 15 || c2 < 0)
|| ((c3 = scannerhelper.getnumericvalue(comment[index[0]++])) > 15 || c3 < 0)
|| ((c4 = scannerhelper.getnumericvalue(comment[index[0]++])) > 15 || c4 < 0))) {
nextcharacter = (char) (((c1 * 16 + c2) * 16 + c3) * 16 + c4);
}
break;
}
return nextcharacter;
}
protected expression gettypereference(expression exp) {

exp.bits &= ~astnode.restrictiveflagmask;
exp.bits |= binding.type;
return exp;
}
protected typereference gettypereference(int dim) {
/* build a reference on a variable that may be qualified or not
this variable is a type reference and dim will be its dimensions*/

typereference ref;
int length = this.identifierlengthstack[this.identifierlengthptr--];
if (length < 0) { //flag for precompiled type reference on base types
ref = typereference.basetypereference(-length, dim);
ref.sourcestart = this.intstack[this.intptr--];
if (dim == 0) {
ref.sourceend = this.intstack[this.intptr--];
} else {
this.intptr--;
ref.sourceend = this.endposition;
}
} else {
int numberofidentifiers = this.genericsidentifierslengthstack[this.genericsidentifierslengthptr--];
if (length != numberofidentifiers || this.genericslengthstack[this.genericslengthptr] != 0) {
// generic type
ref = gettypereferenceforgenerictype(dim, length, numberofidentifiers);
} else if (length == 1) {
// single variable reference
this.genericslengthptr--; // pop the 0
if (dim == 0) {
ref =
new singletypereference(
this.identifierstack[this.identifierptr],
this.identifierpositionstack[this.identifierptr--]);
} else {
ref =
new arraytypereference(
this.identifierstack[this.identifierptr],
dim,
this.identifierpositionstack[this.identifierptr--]);
ref.sourceend = this.endposition;
}
} else {
this.genericslengthptr--;
//qualified variable reference
char[][] tokens = new char[length][];
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(this.identifierstack, this.identifierptr + 1, tokens, 0, length);
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);
if (dim == 0) {
ref = new qualifiedtypereference(tokens, positions);
} else {
ref = new arrayqualifiedtypereference(tokens, dim, positions);
ref.sourceend = this.endposition;
}
}
}
return ref;
}
protected typereference gettypereferenceforgenerictype(int dim, int identifierlength, int numberofidentifiers) {
if (identifierlength == 1 && numberofidentifiers == 1) {
int currenttypeargumentslength = this.genericslengthstack[this.genericslengthptr--];
typereference[] typearguments = new typereference[currenttypeargumentslength];
this.genericsptr -= currenttypeargumentslength;
system.arraycopy(this.genericsstack, this.genericsptr + 1, typearguments, 0, currenttypeargumentslength);
parameterizedsingletypereference parameterizedsingletypereference = new parameterizedsingletypereference(this.identifierstack[this.identifierptr], typearguments, dim, this.identifierpositionstack[this.identifierptr--]);
if (dim != 0) {
parameterizedsingletypereference.sourceend = this.endstatementposition;
}
return parameterizedsingletypereference;
} else {
typereference[][] typearguments = new typereference[numberofidentifiers][];
char[][] tokens = new char[numberofidentifiers][];
long[] positions = new long[numberofidentifiers];
int index = numberofidentifiers;
int currentidentifierslength = identifierlength;
while (index > 0) {
int currenttypeargumentslength = this.genericslengthstack[this.genericslengthptr--];
if (currenttypeargumentslength != 0) {
this.genericsptr -= currenttypeargumentslength;
system.arraycopy(this.genericsstack, this.genericsptr + 1, typearguments[index - 1] = new typereference[currenttypeargumentslength], 0, currenttypeargumentslength);
}
switch(currentidentifierslength) {
case 1 :
// we are in a case a<b>.c<d> or a<b>.c<d>
tokens[index - 1] = this.identifierstack[this.identifierptr];
positions[index - 1] = this.identifierpositionstack[this.identifierptr--];
break;
default:
// we are in a case a.b.c<b>.c<d> or a.b.c<b>...
this.identifierptr -= currentidentifierslength;
system.arraycopy(this.identifierstack, this.identifierptr + 1, tokens, index - currentidentifierslength, currentidentifierslength);
system.arraycopy(this.identifierpositionstack, this.identifierptr + 1, positions, index - currentidentifierslength, currentidentifierslength);
}
index -= currentidentifierslength;
if (index > 0) {
currentidentifierslength = this.identifierlengthstack[this.identifierlengthptr--];
}
}
parameterizedqualifiedtypereference parameterizedqualifiedtypereference = new parameterizedqualifiedtypereference(tokens, typearguments, dim, positions);
if (dim != 0) {
parameterizedqualifiedtypereference.sourceend = this.endstatementposition;
}
return parameterizedqualifiedtypereference;
}
}
protected namereference getunspecifiedreference() {
/* build a (unspecified) namereference which may be qualified*/

int length;
namereference ref;
if ((length = this.identifierlengthstack[this.identifierlengthptr--]) == 1)
// single variable reference
ref =
new singlenamereference(
this.identifierstack[this.identifierptr],
this.identifierpositionstack[this.identifierptr--]);
else
//qualified variable reference
{
char[][] tokens = new char[length][];
this.identifierptr -= length;
system.arraycopy(this.identifierstack, this.identifierptr + 1, tokens, 0, length);
long[] positions = new long[length];
system.arraycopy(this.identifierpositionstack, this.identifierptr + 1, positions, 0, length);
ref =
new qualifiednamereference(tokens,
positions,
(int) (this.identifierpositionstack[this.identifierptr + 1] >> 32), // sourcestart
(int) this.identifierpositionstack[this.identifierptr + length]); // sourceend
}
return ref;
}
protected namereference getunspecifiedreferenceoptimized() {
/* build a (unspecified) namereference which may be qualified
the optimization occurs for qualified reference while we are
certain in this case the last item of the qualified name is
a field access. this optimization is important while it results
that when a namereference is build, the type checker should always
look for that it is not a type reference */

int length;
namereference ref;
if ((length = this.identifierlengthstack[this.identifierlengthptr--]) == 1) {
// single variable reference
ref =
new singlenamereference(
this.identifierstack[this.identifierptr],
this.identifierpositionstack[this.identifierptr--]);
ref.bits &= ~astnode.restrictiveflagmask;
ref.bits |= binding.local | binding.field;
return ref;
}

//qualified-variable-reference
//in fact it is variable-reference dot field-ref , but it would result in a type
//conflict tha can be only reduce by making a superclass (or inetrface ) between
//namereference and filedreference or putting fieldreference under namereference
//or else..........this optimisation is not really relevant so just leave as it is

char[][] tokens = new char[length][];
this.identifierptr -= length;
system.arraycopy(this.identifierstack, this.identifierptr + 1, tokens, 0, length);
long[] positions = new long[length];
system.arraycopy(this.identifierpositionstack, this.identifierptr + 1, positions, 0, length);
ref = new qualifiednamereference(
tokens,
positions,
(int) (this.identifierpositionstack[this.identifierptr + 1] >> 32), // sourcestart
(int) this.identifierpositionstack[this.identifierptr + length]); // sourceend
ref.bits &= ~astnode.restrictiveflagmask;
ref.bits |= binding.local | binding.field;
return ref;
}
public void goforblockstatementsopt() {
//tells the scanner to go for block statements opt parsing

this.firsttoken = tokennametwiddle;
this.scanner.recordlineseparator = false;
}
public void goforblockstatementsorcatchheader() {
//tells the scanner to go for block statements or method headers parsing

this.firsttoken = tokennamemultiply;
this.scanner.recordlineseparator = false;
}
public void goforclassbodydeclarations() {
//tells the scanner to go for any body declarations parsing

this.firsttoken = tokennameand;
this.scanner.recordlineseparator = true;
}
public void goforcompilationunit(){
//tells the scanner to go for compilation unit parsing

this.firsttoken = tokennameplus_plus ;
this.scanner.foundtaskcount = 0;
this.scanner.recordlineseparator = true;
}
public void goforexpression() {
//tells the scanner to go for an expression parsing

this.firsttoken = tokennameremainder;
this.scanner.recordlineseparator = true; // recovery goals must record line separators
}
public void goforfielddeclaration(){
//tells the scanner to go for field declaration parsing

this.firsttoken = tokennameand_and ;
this.scanner.recordlineseparator = true;
}
public void goforgenericmethoddeclaration(){
//tells the scanner to go for generic method declarations parsing

this.firsttoken = tokennamedivide;
this.scanner.recordlineseparator = true;
}
public void goforheaders(){
//tells the scanner to go for headers only parsing
recoveredtype currenttype = currentrecoverytype();
if(currenttype != null && currenttype.insideenumconstantpart) {
this.firsttoken = tokennamenot;
} else {
this.firsttoken = tokennameunsigned_right_shift;
}
this.scanner.recordlineseparator = true; // recovery goals must record line separators
}
public void goforimportdeclaration(){
//tells the scanner to go for import declaration parsing

this.firsttoken = tokennameor_or ;
this.scanner.recordlineseparator = true;
}
public void goforinitializer(){
//tells the scanner to go for initializer parsing

this.firsttoken = tokennameright_shift ;
this.scanner.recordlineseparator = false;
}
public void goformembervalue() {
//tells the scanner to go for a member value parsing

this.firsttoken = tokennameor_or;
this.scanner.recordlineseparator = true; // recovery goals must record line separators
}
public void goformethodbody(){
//tells the scanner to go for method body parsing

this.firsttoken = tokennameminus_minus ;
this.scanner.recordlineseparator = false;
}
public void goforpackagedeclaration() {
//tells the scanner to go for package declaration parsing

this.firsttoken = tokennamequestion;
this.scanner.recordlineseparator = true;
}
public void gofortypedeclaration() {
//tells the scanner to go for type (interface or class) declaration parsing

this.firsttoken = tokennameplus;
this.scanner.recordlineseparator = true;
}
/**
* look for a specific tag comment leading a given source range (comment located after any statement in aststack)
* @@param rangeend int
* @@return boolean
*/
public boolean hasleadingtagcomment(char[] commentprefixtag, int rangeend) {
int icomment = this.scanner.commentptr;
if (icomment < 0) return false; // no comment available
int istatement = this.astlengthptr;
if (istatement < 0 || this.astlengthstack[istatement] <= 1) return false; // no statement available
// fallthrough comment must be located after the previous statement
astnode lastnode = this.aststack[this.astptr];
int rangestart = lastnode.sourceend;
previouscomment: for (; icomment >= 0; icomment--) {
int commentstart = this.scanner.commentstarts[icomment];
if (commentstart < 0) commentstart = -commentstart; // line comments have negative start positions
// ignore comments before start
if (commentstart < rangestart) return false; // no more comments in range
// ignore comments after end
if (commentstart > rangeend) continue previouscomment;
// found last comment in range - only check the last comment in range
char[] source = this.scanner.source;
int charpos = commentstart+2; // skip // or /*
// tag can be leaded by optional spaces
for (; charpos < rangeend; charpos++) {
char c = source[charpos];
if (c >= scannerhelper.max_obvious || (scannerhelper.obvious_ident_char_natures[c] & scannerhelper.c_jls_space) == 0) {
break;
}
}
for (int itag = 0, length = commentprefixtag.length; itag < length; itag++, charpos++) {
if (charpos >= rangeend) return false; // comment is too small to host tag
if (source[charpos] != commentprefixtag[itag]) return false;
}
return true;
}
return false;
}
protected void ignoreexpressionassignment() {
// assignment ::= invalidarrayinitializerassignement
// encoded operator would be: this.intstack[this.intptr]
this.intptr--;
arrayinitializer arrayinitializer = (arrayinitializer) this.expressionstack[this.expressionptr--];
this.expressionlengthptr -- ;
// report a syntax error and abort parsing
if(!this.statementrecoveryactivated) problemreporter().arrayconstantsonlyinarrayinitializers(arrayinitializer.sourcestart, arrayinitializer.sourceend);
}
public void initialize() {
this.initialize(false);
}
public void initialize(boolean initializenls) {
//positionning the parser for a new compilation unit
//avoiding stack reallocation and all that....
this.astptr = -1;
this.astlengthptr = -1;
this.expressionptr = -1;
this.expressionlengthptr = -1;
this.identifierptr = -1;
this.identifierlengthptr	= -1;
this.intptr = -1;
this.nestedmethod[this.nestedtype = 0] = 0; // need to reset for further reuse
this.variablescounter[this.nestedtype] = 0;
this.dimensions = 0 ;
this.realblockptr = -1;
this.compilationunit = null;
this.referencecontext = null;
this.endstatementposition = 0;

//remove objects from stack too, while the same parser/compiler couple is
//re-used between two compilations ....

int astlength = this.aststack.length;
if (this.noastnodes.length < astlength){
this.noastnodes = new astnode[astlength];
//system.out.println("resized ast stacks : "+ astlength);

}
system.arraycopy(this.noastnodes, 0, this.aststack, 0, astlength);

int expressionlength = this.expressionstack.length;
if (this.noexpressions.length < expressionlength){
this.noexpressions = new expression[expressionlength];
//system.out.println("resized expr stacks : "+ expressionlength);
}
system.arraycopy(this.noexpressions, 0, this.expressionstack, 0, expressionlength);

// reset this.scanner state
this.scanner.commentptr = -1;
this.scanner.foundtaskcount = 0;
this.scanner.eofposition = integer.max_value;
this.recordstringliterals = true;
final boolean checknls = this.options.getseverity(compileroptions.nonexternalizedstring) != problemseverities.ignore;
this.checkexternalizestrings = checknls;
this.scanner.checknonexternalizedstringliterals = initializenls && checknls;
this.scanner.lastposition = -1;

resetmodifiers();

// recovery
this.lastcheckpoint = -1;
this.currentelement = null;
this.restartrecovery = false;
this.hasreportederror = false;
this.recoveredstaticinitializerstart = 0;
this.lastignoredtoken = -1;
this.lasterrorendposition = -1;
this.lasterrorendpositionbeforerecovery = -1;
this.lastjavadocend = -1;
this.listlength = 0;
this.listtypeparameterlength = 0;
this.lastposistion = -1;

this.rbracestart = 0;
this.rbraceend = 0;
this.rbracesuccessorstart = 0;

this.genericsidentifierslengthptr = -1;
this.genericslengthptr = -1;
this.genericsptr = -1;
}
public void initializescanner(){
this.scanner = new scanner(
false /*comment*/,
false /*whitespace*/,
false, /* will be set in initialize(boolean) */
this.options.sourcelevel /*sourcelevel*/,
this.options.compliancelevel /*compliancelevel*/,
this.options.tasktags/*tasktags*/,
this.options.taskpriorities/*taskpriorities*/,
this.options.istaskcasesensitive/*taskcasesensitive*/);
}
public void jumpovermethodbody() {
//on diet parsing.....do not buffer method statements

//the scanner.diet is reinitialized to false
//automatically by the scanner once it has jumped over
//the statements

if (this.diet && (this.dietint == 0))
this.scanner.diet = true;
}
private void jumpovertype(){
if (this.recoveredtypes != null && this.nexttypestart > -1 && this.nexttypestart < this.scanner.currentposition) {

if (debug_automaton) {
system.out.println("jump         -"); //$non-nls-1$
}

typedeclaration typedeclaration = this.recoveredtypes[this.recoveredtypeptr];
boolean isanonymous = typedeclaration.allocation != null;

this.scanner.startposition = typedeclaration.declarationsourceend + 1;
this.scanner.currentposition = typedeclaration.declarationsourceend + 1;
this.scanner.diet = false; // quit jumping over method bodies

if(!isanonymous) {
((recoveryscanner)this.scanner).setpendingtokens(new int[]{tokennamesemicolon, tokennamebreak});
} else {
((recoveryscanner)this.scanner).setpendingtokens(new int[]{tokennameidentifier, tokennameequal, tokennameidentifier});
}

this.pendingrecoveredtype = typedeclaration;

try {
this.currenttoken = this.scanner.getnexttoken();
} catch(invalidinputexception e){
// it's impossible because we added pending tokens before
}

if(++this.recoveredtypeptr < this.recoveredtypes.length) {
typedeclaration nexttypedeclaration = this.recoveredtypes[this.recoveredtypeptr];
this.nexttypestart =
nexttypedeclaration.allocation == null
? nexttypedeclaration.declarationsourcestart
: nexttypedeclaration.allocation.sourcestart;
} else {
this.nexttypestart = integer.max_value;
}
}
}
protected void markenclosingmemberwithlocaltype() {
if (this.currentelement != null) return; // this is already done in the recovery code
for (int i = this.astptr; i >= 0; i--) {
astnode node = this.aststack[i];
if (node instanceof abstractmethoddeclaration
|| node instanceof fielddeclaration
|| (node instanceof typedeclaration // mark type for now: all initializers will be marked when added to this type
// and enclosing type must not be closed (see https://bugs.eclipse.org/bugs/show_bug.cgi?id=147485)
&& ((typedeclaration) node).declarationsourceend == 0)) {
node.bits |= astnode.haslocaltype;
return;
}
}
// default to reference context (case of parse method body)
if (this.referencecontext instanceof abstractmethoddeclaration
|| this.referencecontext instanceof typedeclaration) {
((astnode)this.referencecontext).bits |= astnode.haslocaltype;
}
}

/*
* move checkpoint location (current implementation is moving it by one token)
*
* answers true if successfully moved checkpoint (in other words, it did not attempt to move it
* beyond end of file).
*/
protected boolean moverecoverycheckpoint() {

int pos = this.lastcheckpoint;
/* reset this.scanner, and move checkpoint by one token */
this.scanner.startposition = pos;
this.scanner.currentposition = pos;
this.scanner.diet = false; // quit jumping over method bodies

/* if about to restart, then no need to shift token */
if (this.restartrecovery){
this.lastignoredtoken = -1;
this.scanner.insiderecovery = true;
return true;
}

/* protect against shifting on an invalid token */
this.lastignoredtoken = this.nextignoredtoken;
this.nextignoredtoken = -1;
do {
try {
this.nextignoredtoken = this.scanner.getnexttoken();
if(this.scanner.currentposition == this.scanner.startposition){
this.scanner.currentposition++; // on fake completion identifier
this.nextignoredtoken = -1;
}

} catch(invalidinputexception e){
pos = this.scanner.currentposition;
}
} while (this.nextignoredtoken < 0);

if (this.nextignoredtoken == tokennameeof) { // no more recovery after this point
if (this.currenttoken == tokennameeof) { // already tried one iteration on eof
return false;
}
}
this.lastcheckpoint = this.scanner.currentposition;

/* reset this.scanner again to previous checkpoint location*/
this.scanner.startposition = pos;
this.scanner.currentposition = pos;
this.scanner.commentptr = -1;
this.scanner.foundtaskcount = 0;
return true;

/*
the following implementation moves the checkpoint location by one line:

int pos = this.lastcheckpoint;
// reset this.scanner, and move checkpoint by one token
this.scanner.startposition = pos;
this.scanner.currentposition = pos;
this.scanner.diet = false; // quit jumping over method bodies

// if about to restart, then no need to shift token
if (this.restartrecovery){
this.lastignoredtoken = -1;
return true;
}

// protect against shifting on an invalid token
this.lastignoredtoken = this.nextignoredtoken;
this.nextignoredtoken = -1;

boolean wastokenizingwhitespace = this.scanner.tokenizewhitespace;
this.scanner.tokenizewhitespace = true;
checkpointmove:
do {
try {
this.nextignoredtoken = this.scanner.getnexttoken();
switch(this.nextignoredtoken){
case scanner.tokennamewhitespace :
if(this.scanner.getlinenumber(this.scanner.startposition)
== this.scanner.getlinenumber(this.scanner.currentposition)){
this.nextignoredtoken = -1;
}
break;
case tokennamesemicolon :
case tokennamelbrace :
case tokennamerbrace :
break;
case tokennameidentifier :
if(this.scanner.currentposition == this.scanner.startposition){
this.scanner.currentposition++; // on fake completion identifier
}
default:
this.nextignoredtoken = -1;
break;
case tokennameeof :
break checkpointmove;
}
} catch(invalidinputexception e){
pos = this.scanner.currentposition;
}
} while (this.nextignoredtoken < 0);
this.scanner.tokenizewhitespace = wastokenizingwhitespace;

if (this.nextignoredtoken == tokennameeof) { // no more recovery after this point
if (this.currenttoken == tokennameeof) { // already tried one iteration on eof
return false;
}
}
this.lastcheckpoint = this.scanner.currentposition;

// reset this.scanner again to previous checkpoint location
this.scanner.startposition = pos;
this.scanner.currentposition = pos;
this.scanner.commentptr = -1;

return true;
*/
}
protected messagesend newmessagesend() {
// '(' argumentlistopt ')'
// the arguments are on the expression stack

messagesend m = new messagesend();
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
m.arguments = new expression[length],
0,
length);
}
return m;
}
protected messagesend newmessagesendwithtypearguments() {
messagesend m = new messagesend();
int length;
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
this.expressionptr -= length;
system.arraycopy(
this.expressionstack,
this.expressionptr + 1,
m.arguments = new expression[length],
0,
length);
}
return m;
}
protected void optimizedconcatnodelists() {
/*back from a recursive loop. virtualy group the
astnode into an array using this.astlengthstack*/

/*
* this is a case where you have two sublists into the this.aststack that you want
* to merge in one list. there is no action required on the this.aststack. the only
* thing you need to do is merge the two lengths specified on the aststacklength.
* the top two length are for example:
* ... p   n
* and you want to result in a list like:
* ... n+p
* this means that the p could be equals to 0 in case there is no astnode pushed
* on the this.aststack.
* look at the interfacememberdeclarations for an example.
* this case optimizes the fact that p == 1.
*/

this.astlengthstack[--this.astlengthptr]++;
}
/*main loop of the automat
when a rule is reduced, the method consumerule(int) is called with the number
of the consumed rule. when a terminal is consumed, the method consumetoken(int) is
called in order to remember (when needed) the consumed token */
// (int)asr[asi(act)]
// name[symbol_index[currentkind]]
protected void parse() {
if (debug) system.out.println("-- enter inside parse method --");  //$non-nls-1$

if (debug_automaton) {
system.out.println("- start --------------------------------");  //$non-nls-1$
}

boolean isdietparse = this.diet;
int oldfirsttoken = getfirsttoken();
this.haserror = false;

this.hasreportederror = false;
int act = start_state;
this.statestacktop = -1;
this.currenttoken = getfirsttoken();
processterminals : for (;;) {
int stacklength = this.stack.length;
if (++this.statestacktop >= stacklength) {
system.arraycopy(
this.stack, 0,
this.stack = new int[stacklength + stackincrement], 0,
stacklength);
}
this.stack[this.statestacktop] = act;

act = taction(act, this.currenttoken);
if (act == error_action || this.restartrecovery) {

if (debug_automaton) {
if (this.restartrecovery) {
system.out.println("restart      - "); //$non-nls-1$
} else {
system.out.println("error        - "); //$non-nls-1$
}
}

int errorpos = this.scanner.currentposition - 1;
if (!this.hasreportederror) {
this.haserror = true;
}
int previoustoken = this.currenttoken;
if (resumeonsyntaxerror()) {
if (act == error_action && previoustoken != 0) this.lasterrorendposition = errorpos;
act = start_state;
this.statestacktop = -1;
this.currenttoken = getfirsttoken();
continue processterminals;
}
act = error_action;
break processterminals;
}
if (act <= num_rules) {
this.statestacktop--;

if (debug_automaton) {
system.out.print("reduce       - "); //$non-nls-1$
}

} else if (act > error_action) { /* shift-reduce */
consumetoken(this.currenttoken);
if (this.currentelement != null) {
boolean oldvalue = this.recordstringliterals;
this.recordstringliterals = false;
recoverytokencheck();
this.recordstringliterals = oldvalue;
}
try {
this.currenttoken = this.scanner.getnexttoken();
} catch(invalidinputexception e){
if (!this.hasreportederror){
problemreporter().scannererror(this, e.getmessage());
this.hasreportederror = true;
}
this.lastcheckpoint = this.scanner.currentposition;
this.currenttoken = 0;
this.restartrecovery = true;
}
if(this.statementrecoveryactivated) {
jumpovertype();
}
act -= error_action;

if (debug_automaton) {
system.out.print("shift/reduce - (" + name[terminal_index[this.currenttoken]]+") ");  //$non-nls-1$  //$non-nls-2$
}

} else {
if (act < accept_action) { /* shift */
consumetoken(this.currenttoken);
if (this.currentelement != null) {
boolean oldvalue = this.recordstringliterals;
this.recordstringliterals = false;
recoverytokencheck();
this.recordstringliterals = oldvalue;
}
try{
this.currenttoken = this.scanner.getnexttoken();
} catch(invalidinputexception e){
if (!this.hasreportederror){
problemreporter().scannererror(this, e.getmessage());
this.hasreportederror = true;
}
this.lastcheckpoint = this.scanner.currentposition;
this.currenttoken = 0;
this.restartrecovery = true;
}
if(this.statementrecoveryactivated) {
jumpovertype();
}
if (debug_automaton) {
system.out.println("shift        - (" + name[terminal_index[this.currenttoken]]+")");  //$non-nls-1$  //$non-nls-2$
}
continue processterminals;
}
break processterminals;
}

// processnonterminals :
do { /* reduce */

if (debug_automaton) {
system.out.println(name[non_terminal_index[lhs[act]]]);
}

consumerule(act);
this.statestacktop -= (rhs[act] - 1);
act = ntaction(this.stack[this.statestacktop], lhs[act]);

if (debug_automaton) {
if (act <= num_rules) {
system.out.print("             - ");  //$non-nls-1$
}
}

} while (act <= num_rules);

if (debug_automaton) {
system.out.println("----------------------------------------");  //$non-nls-1$
}
}

if (debug_automaton) {
system.out.println("- end ----------------------------------");  //$non-nls-1$
}

endparse(act);
// record all nls tags in the corresponding compilation unit
final nlstag[] tags = this.scanner.getnlstags();
if (tags != null) {
this.compilationunit.nlstags = tags;
}

this.scanner.checknonexternalizedstringliterals = false;
if (this.reportsyntaxerrorisrequired && this.haserror && !this.statementrecoveryactivated) {
if(!this.options.performstatementsrecovery) {
reportsyntaxerrors(isdietparse, oldfirsttoken);
} else {
recoveryscannerdata data = this.referencecontext.compilationresult().recoveryscannerdata;

if(this.recoveryscanner == null) {
this.recoveryscanner = new recoveryscanner(this.scanner, data);
} else {
this.recoveryscanner.setdata(data);
}

this.recoveryscanner.setsource(this.scanner.source);
this.recoveryscanner.lineends = this.scanner.lineends;
this.recoveryscanner.lineptr = this.scanner.lineptr;

reportsyntaxerrors(isdietparse, oldfirsttoken);

if(data == null) {
this.referencecontext.compilationresult().recoveryscannerdata =
this.recoveryscanner.getdata();
}

if (this.methodrecoveryactivated && this.options.performstatementsrecovery) {
this.methodrecoveryactivated = false;
recoverstatements();
this.methodrecoveryactivated = true;

this.lastact = error_action;
}
}
}

if (debug) system.out.println("-- exit from parse method --");  //$non-nls-1$
}
public void parse(constructordeclaration cd, compilationunitdeclaration unit, boolean recordlineseparator) {
//only parse the method body of cd
//fill out its statements

//convert bugs into parse error

boolean oldmethodrecoveryactivated = this.methodrecoveryactivated;
if(this.options.performmethodsfullrecovery) {
this.methodrecoveryactivated = true;
}

initialize();
goforblockstatementsopt();
if (recordlineseparator) {
this.scanner.recordlineseparator = true;
}
this.nestedmethod[this.nestedtype]++;
pushonrealblockstack(0);

this.referencecontext = cd;
this.compilationunit = unit;

this.scanner.resetto(cd.bodystart, cd.bodyend);
try {
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
} finally {
this.nestedmethod[this.nestedtype]--;
if(this.options.performstatementsrecovery) {
this.methodrecoveryactivated = oldmethodrecoveryactivated;
}
}

checknonnlsafterbodyend(cd.declarationsourceend);

if (this.lastact == error_action) {
cd.bits |= astnode.hassyntaxerrors;
initialize();
return;
}

//statements
cd.explicitdeclarations = this.realblockstack[this.realblockptr--];
int length;
if (this.astlengthptr > -1 && (length = this.astlengthstack[this.astlengthptr--]) != 0) {
this.astptr -= length;
if (!this.options.ignoremethodbodies) {
if (this.aststack[this.astptr + 1] instanceof explicitconstructorcall)
//avoid a issomething that would only be used here but what is faster between two alternatives ?
{
system.arraycopy(
this.aststack,
this.astptr + 2,
cd.statements = new statement[length - 1],
0,
length - 1);
cd.constructorcall = (explicitconstructorcall) this.aststack[this.astptr + 1];
} else { //need to add explicitly the super();
system.arraycopy(
this.aststack,
this.astptr + 1,
cd.statements = new statement[length],
0,
length);
cd.constructorcall = superreference.implicitsuperconstructorcall();
}
}
} else {
if (!this.options.ignoremethodbodies) {
cd.constructorcall = superreference.implicitsuperconstructorcall();
}
if (!containscomment(cd.bodystart, cd.bodyend)) {
cd.bits |= astnode.undocumentedemptyblock;
}
}

explicitconstructorcall explicitconstructorcall = cd.constructorcall;
if (explicitconstructorcall != null && explicitconstructorcall.sourceend == 0) {
explicitconstructorcall.sourceend = cd.sourceend;
explicitconstructorcall.sourcestart = cd.sourcestart;
}
}
// a p i

public void parse(
fielddeclaration field,
typedeclaration type,
compilationunitdeclaration unit,
char[] initializationsource) {
//only parse the initializationsource of the given field

//convert bugs into parse error

initialize();
goforexpression();
this.nestedmethod[this.nestedtype]++;

this.referencecontext = type;
this.compilationunit = unit;

this.scanner.setsource(initializationsource);
this.scanner.resetto(0, initializationsource.length-1);
try {
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
} finally {
this.nestedmethod[this.nestedtype]--;
}

if (this.lastact == error_action) {
field.bits |= astnode.hassyntaxerrors;
return;
}

field.initialization = this.expressionstack[this.expressionptr];

// mark field with local type if one was found during parsing
if ((type.bits & astnode.haslocaltype) != 0) {
field.bits |= astnode.haslocaltype;
}
}
// a p i

public compilationunitdeclaration parse(
icompilationunit sourceunit,
compilationresult compilationresult) {
// parses a compilation unit and manages error handling (even bugs....)

return parse(sourceunit, compilationresult, -1, -1/*parse without reseting the scanner*/);
}
// a p i

public compilationunitdeclaration parse(
icompilationunit sourceunit,
compilationresult compilationresult,
int start,
int end) {
// parses a compilation unit and manages error handling (even bugs....)

compilationunitdeclaration unit;
try {
/* automaton initialization */
initialize(true);
goforcompilationunit();

/* unit creation */
this.referencecontext =
this.compilationunit =
new compilationunitdeclaration(
this.problemreporter,
compilationresult,
0);

/* scanners initialization */
char[] contents;
try {
contents = this.readmanager != null ? this.readmanager.getcontents(sourceunit) : sourceunit.getcontents();
} catch(abortcompilationunit abortexception) {
problemreporter().cannotreadsource(this.compilationunit, abortexception, this.options.verbose);
contents = charoperation.no_char; // pretend empty from thereon
}
this.scanner.setsource(contents);
this.compilationunit.sourceend = this.scanner.source.length - 1;
if (end != -1) this.scanner.resetto(start, end);
if (this.javadocparser != null && this.javadocparser.checkdoccomment) {
this.javadocparser.scanner.setsource(contents);
if (end != -1) {
this.javadocparser.scanner.resetto(start, end);
}
}
/* run automaton */
parse();
} finally {
unit = this.compilationunit;
this.compilationunit = null; // reset parser
// tag unit has having read bodies
if (!this.diet) unit.bits |= astnode.hasallmethodbodies;
}
return unit;
}
// a p i

public void parse(
initializer initializer,
typedeclaration type,
compilationunitdeclaration unit) {
//only parse the method body of md
//fill out method statements

//convert bugs into parse error

boolean oldmethodrecoveryactivated = this.methodrecoveryactivated;
if(this.options.performmethodsfullrecovery) {
this.methodrecoveryactivated = true;
}

initialize();
goforblockstatementsopt();
this.nestedmethod[this.nestedtype]++;
pushonrealblockstack(0);

this.referencecontext = type;
this.compilationunit = unit;

this.scanner.resetto(initializer.bodystart, initializer.bodyend); // just on the beginning {
try {
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
} finally {
this.nestedmethod[this.nestedtype]--;
if(this.options.performstatementsrecovery) {
this.methodrecoveryactivated = oldmethodrecoveryactivated;
}
}

checknonnlsafterbodyend(initializer.declarationsourceend);

if (this.lastact == error_action) {
initializer.bits |= astnode.hassyntaxerrors;
return;
}

//refill statements
initializer.block.explicitdeclarations = this.realblockstack[this.realblockptr--];
int length;
if (this.astlengthptr > -1 && (length = this.astlengthstack[this.astlengthptr--]) > 0) {
system.arraycopy(this.aststack, (this.astptr -= length) + 1, initializer.block.statements = new statement[length], 0, length);
} else {
// check whether this block at least contains some comment in it
if (!containscomment(initializer.block.sourcestart, initializer.block.sourceend)) {
initializer.block.bits |= astnode.undocumentedemptyblock;
}
}

// mark initializer with local type if one was found during parsing
if ((type.bits & astnode.haslocaltype) != 0) {
initializer.bits |= astnode.haslocaltype;
}
}
// a p i
public void parse(methoddeclaration md, compilationunitdeclaration unit) {
//only parse the method body of md
//fill out method statements

//convert bugs into parse error

if (md.isabstract())
return;
if (md.isnative())
return;
if ((md.modifiers & extracompilermodifiers.accsemicolonbody) != 0)
return;

boolean oldmethodrecoveryactivated = this.methodrecoveryactivated;
if(this.options.performmethodsfullrecovery) {
this.methodrecoveryactivated = true;
this.rparenpos = md.sourceend;
}
initialize();
goforblockstatementsopt();
this.nestedmethod[this.nestedtype]++;
pushonrealblockstack(0);

this.referencecontext = md;
this.compilationunit = unit;

this.scanner.resetto(md.bodystart, md.bodyend);
// reset the scanner to parser from { down to }
try {
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
} finally {
this.nestedmethod[this.nestedtype]--;
if(this.options.performstatementsrecovery) {
this.methodrecoveryactivated = oldmethodrecoveryactivated;
}
}

checknonnlsafterbodyend(md.declarationsourceend);

if (this.lastact == error_action) {
md.bits |= astnode.hassyntaxerrors;
return;
}

//refill statements
md.explicitdeclarations = this.realblockstack[this.realblockptr--];
int length;
if (this.astlengthptr > -1 && (length = this.astlengthstack[this.astlengthptr--]) != 0) {
if (this.options.ignoremethodbodies) {
// ignore statements
this.astptr -= length;
} else {
system.arraycopy(
this.aststack,
(this.astptr -= length) + 1,
md.statements = new statement[length],
0,
length);
}
} else {
if (!containscomment(md.bodystart, md.bodyend)) {
md.bits |= astnode.undocumentedemptyblock;
}
}
}
public astnode[] parseclassbodydeclarations(char[] source, int offset, int length, compilationunitdeclaration unit) {
boolean olddiet = this.diet;
/* automaton initialization */
initialize();
goforclassbodydeclarations();
/* scanner initialization */
this.scanner.setsource(source);
this.scanner.resetto(offset, offset + length - 1);
if (this.javadocparser != null && this.javadocparser.checkdoccomment) {
this.javadocparser.scanner.setsource(source);
this.javadocparser.scanner.resetto(offset, offset + length - 1);
}

/* type declaration should be parsed as member type declaration */
this.nestedtype = 1;

/* unit creation */
typedeclaration referencecontexttypedeclaration = new typedeclaration(unit.compilationresult);
referencecontexttypedeclaration.name = util.empty_string.tochararray();
referencecontexttypedeclaration.fields = new fielddeclaration[0];
this.compilationunit = unit;
unit.types = new typedeclaration[1];
unit.types[0] = referencecontexttypedeclaration;
this.referencecontext = unit;

/* run automaton */
try {
this.diet = true;
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
} finally {
this.diet = olddiet;
}

astnode[] result = null;
if (this.lastact == error_action) {
if (!this.options.performmethodsfullrecovery && !this.options.performstatementsrecovery) {
return null;
}
// collect all body declaration inside the compilation unit except the default constructor
final list bodydeclarations = new arraylist();
astvisitor visitor = new astvisitor() {
public boolean visit(methoddeclaration methoddeclaration, classscope scope) {
if (!methoddeclaration.isdefaultconstructor()) {
bodydeclarations.add(methoddeclaration);
}
return false;
}
public boolean visit(fielddeclaration fielddeclaration, methodscope scope) {
bodydeclarations.add(fielddeclaration);
return false;
}
public boolean visit(typedeclaration membertypedeclaration, classscope scope) {
bodydeclarations.add(membertypedeclaration);
return false;
}
};
unit.ignorefurtherinvestigation = false;
unit.traverse(visitor, unit.scope);
unit.ignorefurtherinvestigation = true;
result = (astnode[]) bodydeclarations.toarray(new astnode[bodydeclarations.size()]);
} else {
int astlength;
if (this.astlengthptr > -1 && (astlength = this.astlengthstack[this.astlengthptr--]) != 0) {
result = new astnode[astlength];
this.astptr -= astlength;
system.arraycopy(this.aststack, this.astptr + 1, result, 0, astlength);
} else {
// empty class body declaration (like ';' see https://bugs.eclipse.org/bugs/show_bug.cgi?id=280079).
result = new astnode[0];
}
}
boolean containsinitializers = false;
typedeclaration typedeclaration = null;
for (int i = 0, max = result.length; i < max; i++) {
// parse each class body declaration
astnode node = result[i];
if (node instanceof typedeclaration) {
((typedeclaration) node).parsemethods(this, unit);
} else if (node instanceof abstractmethoddeclaration) {
((abstractmethoddeclaration) node).parsestatements(this, unit);
} else if (node instanceof fielddeclaration) {
fielddeclaration fielddeclaration = (fielddeclaration) node;
switch(fielddeclaration.getkind()) {
case abstractvariabledeclaration.initializer:
containsinitializers = true;
if (typedeclaration == null) {
typedeclaration = referencecontexttypedeclaration;
}
if (typedeclaration.fields == null) {
typedeclaration.fields = new fielddeclaration[1];
typedeclaration.fields[0] = fielddeclaration;
} else {
int length2 = typedeclaration.fields.length;
fielddeclaration[] temp = new fielddeclaration[length2 + 1];
system.arraycopy(typedeclaration.fields, 0, temp, 0, length2);
temp[length2] = fielddeclaration;
typedeclaration.fields = temp;
}
break;
}
}
if (((node.bits & astnode.hassyntaxerrors) != 0) && (!this.options.performmethodsfullrecovery && !this.options.performstatementsrecovery)) {
return null;
}
}
if (containsinitializers) {
fielddeclaration[] fielddeclarations = typedeclaration.fields;
for (int i = 0, max = fielddeclarations.length; i < max; i++) {
initializer initializer = (initializer) fielddeclarations[i];
initializer.parsestatements(this, typedeclaration , unit);
if (((initializer.bits & astnode.hassyntaxerrors) != 0) && (!this.options.performmethodsfullrecovery && !this.options.performstatementsrecovery)) {
return null;
}
}
}
return result;
}
public expression parseexpression(char[] source, int offset, int length, compilationunitdeclaration unit) {

initialize();
goforexpression();
this.nestedmethod[this.nestedtype]++;

this.referencecontext = unit;
this.compilationunit = unit;

this.scanner.setsource(source);
this.scanner.resetto(offset, offset + length - 1);
try {
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
} finally {
this.nestedmethod[this.nestedtype]--;
}

if (this.lastact == error_action) {
return null;
}

return this.expressionstack[this.expressionptr];
}
public expression parsemembervalue(char[] source, int offset, int length, compilationunitdeclaration unit) {

initialize();
goformembervalue();
this.nestedmethod[this.nestedtype]++;

this.referencecontext = unit;
this.compilationunit = unit;

this.scanner.setsource(source);
this.scanner.resetto(offset, offset + length - 1);
try {
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
} finally {
this.nestedmethod[this.nestedtype]--;
}

if (this.lastact == error_action) {
return null;
}

return this.expressionstack[this.expressionptr];
}
public void parsestatements(referencecontext rc, int start, int end, typedeclaration[] types, compilationunitdeclaration unit) {
boolean oldstatementrecoveryenabled = this.statementrecoveryactivated;
this.statementrecoveryactivated = true;

initialize();

goforblockstatementsopt();
this.nestedmethod[this.nestedtype]++;
pushonrealblockstack(0);

pushonastlengthstack(0);

this.referencecontext = rc;
this.compilationunit = unit;

this.pendingrecoveredtype = null;

if(types != null && types.length > 0) {
this.recoveredtypes = types;
this.recoveredtypeptr = 0;
this.nexttypestart =
this.recoveredtypes[0].allocation == null
? this.recoveredtypes[0].declarationsourcestart
: this.recoveredtypes[0].allocation.sourcestart;
} else {
this.recoveredtypes = null;
this.recoveredtypeptr = -1;
this.nexttypestart = -1;
}

this.scanner.resetto(start, end);
// reset the scanner to parser from { down to }

this.lastcheckpoint = this.scanner.initialposition;


this.statestacktop = -1;

try {
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
} finally {
this.nestedmethod[this.nestedtype]--;
this.recoveredtypes = null;
this.statementrecoveryactivated = oldstatementrecoveryenabled;
}

checknonnlsafterbodyend(end);
}
public void persistlineseparatorpositions() {
if (this.scanner.recordlineseparator) {
this.compilationunit.compilationresult.lineseparatorpositions = this.scanner.getlineends();
}
}
/*
* prepares the state of the parser to go for blockstatements.
*/
protected void prepareforblockstatements() {
this.nestedmethod[this.nestedtype = 0] = 1;
this.variablescounter[this.nestedtype] = 0;
this.realblockstack[this.realblockptr = 1] = 0;
}
/**
* returns this parser's problem reporter initialized with its reference context.
* also it is assumed that a problem is going to be reported, so initializes
* the compilation result's line positions.
*
* @@return problemreporter
*/
public problemreporter problemreporter(){
if (this.scanner.recordlineseparator) {
this.compilationunit.compilationresult.lineseparatorpositions = this.scanner.getlineends();
}
this.problemreporter.referencecontext = this.referencecontext;
return this.problemreporter;
}
protected void pushidentifier() {
/*push the consumetoken on the identifier stack.
increase the total number of identifier in the stack.
identifierptr points on the next top */

int stacklength = this.identifierstack.length;
if (++this.identifierptr >= stacklength) {
system.arraycopy(
this.identifierstack, 0,
this.identifierstack = new char[stacklength + 20][], 0,
stacklength);
system.arraycopy(
this.identifierpositionstack, 0,
this.identifierpositionstack = new long[stacklength + 20], 0,
stacklength);
}
this.identifierstack[this.identifierptr] = this.scanner.getcurrentidentifiersource();
this.identifierpositionstack[this.identifierptr] =
(((long) this.scanner.startposition) << 32) + (this.scanner.currentposition - 1);

stacklength = this.identifierlengthstack.length;
if (++this.identifierlengthptr >= stacklength) {
system.arraycopy(
this.identifierlengthstack, 0,
this.identifierlengthstack = new int[stacklength + 10], 0,
stacklength);
}
this.identifierlengthstack[this.identifierlengthptr] = 1;
}
protected void pushidentifier(int flag) {
/*push a special flag on the stack :
-zero stands for optional name
-negative number for direct ref to base types.
identifierlengthptr points on the top */

int stacklength = this.identifierlengthstack.length;
if (++this.identifierlengthptr >= stacklength) {
system.arraycopy(
this.identifierlengthstack, 0,
this.identifierlengthstack = new int[stacklength + 10], 0,
stacklength);
}
this.identifierlengthstack[this.identifierlengthptr] = flag;
}
protected void pushonastlengthstack(int pos) {

int stacklength = this.astlengthstack.length;
if (++this.astlengthptr >= stacklength) {
system.arraycopy(
this.astlengthstack, 0,
this.astlengthstack = new int[stacklength + stackincrement], 0,
stacklength);
}
this.astlengthstack[this.astlengthptr] = pos;
}
protected void pushonaststack(astnode node) {
/*add a new obj on top of the ast stack
astptr points on the top*/

int stacklength = this.aststack.length;
if (++this.astptr >= stacklength) {
system.arraycopy(
this.aststack, 0,
this.aststack = new astnode[stacklength + aststackincrement], 0,
stacklength);
this.astptr = stacklength;
}
this.aststack[this.astptr] = node;

stacklength = this.astlengthstack.length;
if (++this.astlengthptr >= stacklength) {
system.arraycopy(
this.astlengthstack, 0,
this.astlengthstack = new int[stacklength + aststackincrement], 0,
stacklength);
}
this.astlengthstack[this.astlengthptr] = 1;
}
protected void pushonexpressionstack(expression expr) {

int stacklength = this.expressionstack.length;
if (++this.expressionptr >= stacklength) {
system.arraycopy(
this.expressionstack, 0,
this.expressionstack = new expression[stacklength + expressionstackincrement], 0,
stacklength);
}
this.expressionstack[this.expressionptr] = expr;

stacklength = this.expressionlengthstack.length;
if (++this.expressionlengthptr >= stacklength) {
system.arraycopy(
this.expressionlengthstack, 0,
this.expressionlengthstack = new int[stacklength + expressionstackincrement], 0,
stacklength);
}
this.expressionlengthstack[this.expressionlengthptr] = 1;
}
protected void pushonexpressionstacklengthstack(int pos) {

int stacklength = this.expressionlengthstack.length;
if (++this.expressionlengthptr >= stacklength) {
system.arraycopy(
this.expressionlengthstack, 0,
this.expressionlengthstack = new int[stacklength + stackincrement], 0,
stacklength);
}
this.expressionlengthstack[this.expressionlengthptr] = pos;
}
protected void pushongenericsidentifierslengthstack(int pos) {
int stacklength = this.genericsidentifierslengthstack.length;
if (++this.genericsidentifierslengthptr >= stacklength) {
system.arraycopy(
this.genericsidentifierslengthstack, 0,
this.genericsidentifierslengthstack = new int[stacklength + genericsstackincrement], 0,
stacklength);
}
this.genericsidentifierslengthstack[this.genericsidentifierslengthptr] = pos;
}
protected void pushongenericslengthstack(int pos) {
int stacklength = this.genericslengthstack.length;
if (++this.genericslengthptr >= stacklength) {
system.arraycopy(
this.genericslengthstack, 0,
this.genericslengthstack = new int[stacklength + genericsstackincrement], 0,
stacklength);
}
this.genericslengthstack[this.genericslengthptr] = pos;
}
protected void pushongenericsstack(astnode node) {
/*add a new obj on top of the generics stack
genericsptr points on the top*/

int stacklength = this.genericsstack.length;
if (++this.genericsptr >= stacklength) {
system.arraycopy(
this.genericsstack, 0,
this.genericsstack = new astnode[stacklength + genericsstackincrement], 0,
stacklength);
}
this.genericsstack[this.genericsptr] = node;

stacklength = this.genericslengthstack.length;
if (++this.genericslengthptr >= stacklength) {
system.arraycopy(
this.genericslengthstack, 0,
this.genericslengthstack = new int[stacklength + genericsstackincrement], 0,
stacklength);
}
this.genericslengthstack[this.genericslengthptr] = 1;
}
protected void pushonintstack(int pos) {

int stacklength = this.intstack.length;
if (++this.intptr >= stacklength) {
system.arraycopy(
this.intstack, 0,
this.intstack = new int[stacklength + stackincrement], 0,
stacklength);
}
this.intstack[this.intptr] = pos;
}
protected void pushonrealblockstack(int i){

int stacklength = this.realblockstack.length;
if (++this.realblockptr >= stacklength) {
system.arraycopy(
this.realblockstack, 0,
this.realblockstack = new int[stacklength + stackincrement], 0,
stacklength);
}
this.realblockstack[this.realblockptr] = i;
}
protected void recoverstatements() {
class methodvisitor extends astvisitor {
public astvisitor typevisitor;

typedeclaration enclosingtype; // used only for initializer

typedeclaration[] types = new typedeclaration[0];
int typeptr = -1;
public void endvisit(constructordeclaration constructordeclaration, classscope scope) {
endvisitmethod(constructordeclaration, scope);
}
public void endvisit(initializer initializer, methodscope scope) {
if (initializer.block == null) return;
typedeclaration[] foundtypes = null;
int length = 0;
if(this.typeptr > -1) {
length = this.typeptr + 1;
foundtypes = new typedeclaration[length];
system.arraycopy(this.types, 0, foundtypes, 0, length);
}
referencecontext oldcontext = parser.this.referencecontext;
parser.this.recoveryscanner.resetto(initializer.bodystart, initializer.bodyend);
scanner oldscanner = parser.this.scanner;
parser.this.scanner = parser.this.recoveryscanner;
parsestatements(
this.enclosingtype,
initializer.bodystart,
initializer.bodyend,
foundtypes,
parser.this.compilationunit);
parser.this.scanner = oldscanner;
parser.this.referencecontext = oldcontext;

for (int i = 0; i < length; i++) {
foundtypes[i].traverse(this.typevisitor, scope);
}
}
public void endvisit(methoddeclaration methoddeclaration, classscope scope) {
endvisitmethod(methoddeclaration, scope);
}
private void endvisitmethod(abstractmethoddeclaration methoddeclaration, classscope scope) {
typedeclaration[] foundtypes = null;
int length = 0;
if(this.typeptr > -1) {
length = this.typeptr + 1;
foundtypes = new typedeclaration[length];
system.arraycopy(this.types, 0, foundtypes, 0, length);
}
referencecontext oldcontext = parser.this.referencecontext;
parser.this.recoveryscanner.resetto(methoddeclaration.bodystart, methoddeclaration.bodyend);
scanner oldscanner = parser.this.scanner;
parser.this.scanner = parser.this.recoveryscanner;
parsestatements(
methoddeclaration,
methoddeclaration.bodystart,
methoddeclaration.bodyend,
foundtypes,
parser.this.compilationunit);
parser.this.scanner = oldscanner;
parser.this.referencecontext = oldcontext;

for (int i = 0; i < length; i++) {
foundtypes[i].traverse(this.typevisitor, scope);
}
}
public boolean visit(constructordeclaration constructordeclaration, classscope scope) {
this.typeptr = -1;
return true;
}
public boolean visit(initializer initializer, methodscope scope) {
this.typeptr = -1;
if (initializer.block == null) return false;
return true;
}
public boolean visit(methoddeclaration methoddeclaration,classscope scope) {
this.typeptr = -1;
return true;
}
private boolean visit(typedeclaration typedeclaration) {
if(this.types.length <= ++this.typeptr) {
int length = this.typeptr;
system.arraycopy(this.types, 0, this.types = new typedeclaration[length * 2 + 1], 0, length);
}
this.types[this.typeptr] = typedeclaration;
return false;
}
public boolean visit(typedeclaration typedeclaration, blockscope scope) {
return this.visit(typedeclaration);
}
public boolean visit(typedeclaration typedeclaration, classscope scope) {
return this.visit(typedeclaration);
}
}
class typevisitor extends astvisitor {
public methodvisitor methodvisitor;

typedeclaration[] types = new typedeclaration[0];
int typeptr = -1;

public void endvisit(typedeclaration typedeclaration, blockscope scope) {
endvisittype();
}
public void endvisit(typedeclaration typedeclaration, classscope scope) {
endvisittype();
}
private void endvisittype() {
this.typeptr--;
}
public boolean visit(constructordeclaration constructordeclaration, classscope scope) {
if(constructordeclaration.isdefaultconstructor()) return false;

constructordeclaration.traverse(this.methodvisitor, scope);
return false;
}
public boolean visit(initializer initializer, methodscope scope) {
if (initializer.block == null) return false;
this.methodvisitor.enclosingtype = this.types[this.typeptr];
initializer.traverse(this.methodvisitor, scope);
return false;
}
public boolean visit(methoddeclaration methoddeclaration, classscope scope) {
methoddeclaration.traverse(this.methodvisitor, scope);
return false;
}
private boolean visit(typedeclaration typedeclaration) {
if(this.types.length <= ++this.typeptr) {
int length = this.typeptr;
system.arraycopy(this.types, 0, this.types = new typedeclaration[length * 2 + 1], 0, length);
}
this.types[this.typeptr] = typedeclaration;
return true;
}
public boolean visit(typedeclaration typedeclaration, blockscope scope) {
return this.visit(typedeclaration);
}
public boolean visit(typedeclaration typedeclaration, classscope scope) {
return this.visit(typedeclaration);
}
}

methodvisitor methodvisitor = new methodvisitor();
typevisitor typevisitor = new typevisitor();
methodvisitor.typevisitor = typevisitor;
typevisitor.methodvisitor = methodvisitor;

if(this.referencecontext instanceof abstractmethoddeclaration) {
((abstractmethoddeclaration)this.referencecontext).traverse(methodvisitor, (classscope)null);
} else if(this.referencecontext instanceof typedeclaration) {
typedeclaration typecontext = (typedeclaration)this.referencecontext;

int length = typecontext.fields.length;
for (int i = 0; i < length; i++) {
final fielddeclaration fielddeclaration = typecontext.fields[i];
switch(fielddeclaration.getkind()) {
case abstractvariabledeclaration.initializer:
initializer initializer = (initializer) fielddeclaration;
if (initializer.block == null) break;
methodvisitor.enclosingtype = typecontext;
initializer.traverse(methodvisitor, (methodscope)null);
break;
}
}
}
}

public void recoveryexitfromvariable() {
if(this.currentelement != null && this.currentelement.parent != null) {
if(this.currentelement instanceof recoveredlocalvariable) {

int end = ((recoveredlocalvariable)this.currentelement).localdeclaration.sourceend;
this.currentelement.updatesourceendifnecessary(end);
this.currentelement = this.currentelement.parent;
} else if(this.currentelement instanceof recoveredfield
&& !(this.currentelement instanceof recoveredinitializer)) {
// do not move focus to parent if we are still inside an array initializer
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=292087
if (this.currentelement.bracketbalance <= 0) {
int end = ((recoveredfield)this.currentelement).fielddeclaration.sourceend;
this.currentelement.updatesourceendifnecessary(end);
this.currentelement = this.currentelement.parent;
}
}
}
}
/* token check performed on every token shift once having entered
* recovery mode.
*/
public void recoverytokencheck() {
switch (this.currenttoken) {
case tokennamestringliteral :
if (this.recordstringliterals &&
this.checkexternalizestrings &&
this.lastposistion < this.scanner.currentposition &&
!this.statementrecoveryactivated) {
stringliteral stringliteral = createstringliteral(
this.scanner.getcurrenttokensourcestring(),
this.scanner.startposition,
this.scanner.currentposition - 1,
util.getlinenumber(this.scanner.startposition, this.scanner.lineends, 0, this.scanner.lineptr));
this.compilationunit.recordstringliteral(stringliteral, this.currentelement != null);
}
break;
case tokennamelbrace :
recoveredelement newelement = null;
if(!this.ignorenextopeningbrace) {
newelement = this.currentelement.updateonopeningbrace(this.scanner.startposition - 1, this.scanner.currentposition - 1);
}
this.lastcheckpoint = this.scanner.currentposition;
if (newelement != null){ // null means nothing happened
this.restartrecovery = true; // opening brace detected
this.currentelement = newelement;
}
break;

case tokennamerbrace :
this.rbracestart = this.scanner.startposition - 1;
this.rbraceend = this.scanner.currentposition - 1;
this.endposition = flushcommentsdefinedpriorto(this.rbraceend);
newelement =
this.currentelement.updateonclosingbrace(this.scanner.startposition, this.rbraceend);
this.lastcheckpoint = this.scanner.currentposition;
if (newelement != this.currentelement){
this.currentelement = newelement;
//				if (newelement instanceof recoveredfield && this.dietint <= 0) {
//					if (((recoveredfield)newelement).fielddeclaration.type == null) { // enum constant
//						this.isinsideenumconstantpart = true; // restore status
//					}
//				}
}
break;
case tokennamesemicolon :
this.endstatementposition = this.scanner.currentposition - 1;
this.endposition = this.scanner.startposition - 1;
recoveredtype currenttype = currentrecoverytype();
if(currenttype != null) {
currenttype.insideenumconstantpart = false;
}
//$fall-through$
default : {
if (this.rbraceend > this.rbracesuccessorstart && this.scanner.currentposition != this.scanner.startposition){
this.rbracesuccessorstart = this.scanner.startposition;
}
break;
}
}
this.ignorenextopeningbrace = false;
}
// a p i
protected void reportsyntaxerrors(boolean isdietparse, int oldfirsttoken) {
if(this.referencecontext instanceof methoddeclaration) {
methoddeclaration methoddeclaration = (methoddeclaration) this.referencecontext;
if((methoddeclaration.bits & astnode.errorinsignature) != 0){
return;
}
}
this.compilationunit.compilationresult.lineseparatorpositions = this.scanner.getlineends();
this.scanner.recordlineseparator = false;

int start = this.scanner.initialposition;
int end = this.scanner.eofposition == integer.max_value ? this.scanner.eofposition : this.scanner.eofposition - 1;
if(isdietparse) {
typedeclaration[] types = this.compilationunit.types;
int[][] intervaltoskip = org.eclipse.jdt.internal.compiler.parser.diagnose.rangeutil.computedietrange(types);
diagnoseparser diagnoseparser = new diagnoseparser(this, oldfirsttoken, start, end, intervaltoskip[0], intervaltoskip[1], intervaltoskip[2], this.options);
diagnoseparser.diagnoseparse(false);

reportsyntaxerrorsforskippedmethod(types);
this.scanner.resetto(start, end);
} else {
diagnoseparser diagnoseparser = new diagnoseparser(this, oldfirsttoken, start, end, this.options);
diagnoseparser.diagnoseparse(this.options.performstatementsrecovery);
}
}
private void reportsyntaxerrorsforskippedmethod(typedeclaration[] types){
if(types != null) {
for (int i = 0; i < types.length; i++) {
typedeclaration[] membertypes = types[i].membertypes;
if(membertypes != null) {
reportsyntaxerrorsforskippedmethod(membertypes);
}

abstractmethoddeclaration[] methods = types[i].methods;
if(methods != null) {
for (int j = 0; j < methods.length; j++) {
abstractmethoddeclaration method = methods[j];
if((method.bits & astnode.errorinsignature) != 0) {
if(method.isannotationmethod()) {
diagnoseparser diagnoseparser = new diagnoseparser(this, tokennamequestion, method.declarationsourcestart, method.declarationsourceend, this.options);
diagnoseparser.diagnoseparse(this.options.performstatementsrecovery);
} else {
diagnoseparser diagnoseparser = new diagnoseparser(this, tokennamedivide, method.declarationsourcestart, method.declarationsourceend, this.options);
diagnoseparser.diagnoseparse(this.options.performstatementsrecovery);
}

}
}
}

fielddeclaration[] fields = types[i].fields;
if (fields != null) {
int length = fields.length;
for (int j = 0; j < length; j++) {
if (fields[j] instanceof initializer) {
initializer initializer = (initializer)fields[j];
if((initializer.bits & astnode.errorinsignature) != 0){
diagnoseparser diagnoseparser = new diagnoseparser(this, tokennameright_shift, initializer.declarationsourcestart, initializer.declarationsourceend, this.options);
diagnoseparser.diagnoseparse(this.options.performstatementsrecovery);
}
}
}
}
}
}
}
protected void resetmodifiers() {
this.modifiers = classfileconstants.accdefault;
this.modifierssourcestart = -1; // <-- see comment into modifiersflag(int)
this.scanner.commentptr = -1;
}
/*
* reset context so as to resume to regular parse loop
*/
protected void resetstacks() {

this.astptr = -1;
this.astlengthptr = -1;
this.expressionptr = -1;
this.expressionlengthptr = -1;
this.identifierptr = -1;
this.identifierlengthptr	= -1;
this.intptr = -1;
this.nestedmethod[this.nestedtype = 0] = 0; // need to reset for further reuse
this.variablescounter[this.nestedtype] = 0;
this.dimensions = 0 ;
this.realblockstack[this.realblockptr = 0] = 0;
this.recoveredstaticinitializerstart = 0;
this.listlength = 0;
this.listtypeparameterlength = 0;

this.genericsidentifierslengthptr = -1;
this.genericslengthptr = -1;
this.genericsptr = -1;
}
/*
* reset context so as to resume to regular parse loop
* if unable to reset for resuming, answers false.
*
* move checkpoint location, reset internal stacks and
* decide which grammar goal is activated.
*/
protected boolean resumeafterrecovery() {
if(!this.methodrecoveryactivated && !this.statementrecoveryactivated) {

// reset internal stacks
resetstacks();
resetmodifiers();

/* attempt to move checkpoint location */
if (!moverecoverycheckpoint()) {
return false;
}

// only look for headers
if (this.referencecontext instanceof compilationunitdeclaration){
goforheaders();
this.diet = true; // passed this point, will not consider method bodies
return true;
}

// does not know how to restart
return false;
} else if(!this.statementrecoveryactivated) {

// reset internal stacks
resetstacks();
resetmodifiers();

/* attempt to move checkpoint location */
if (!moverecoverycheckpoint()) {
return false;
}

// only look for headers
goforheaders();
return true;
} else {
return false;
}
}
protected boolean resumeonsyntaxerror() {
/* request recovery initialization */
if (this.currentelement == null){
// reset javadoc before restart parsing after recovery
this.javadoc = null;

// do not investigate deeper in statement recovery
if (this.statementrecoveryactivated) return false;

// build some recovered elements
this.currentelement = buildinitialrecoverystate();
}
/* do not investigate deeper in recovery when no recovered element */
if (this.currentelement == null) return false;

/* manual forced recovery restart - after headers */
if (this.restartrecovery){
this.restartrecovery = false;
}
/* update recovery state with current error state of the parser */
updaterecoverystate();
if (getfirsttoken() == tokennameand) {
if (this.referencecontext instanceof compilationunitdeclaration) {
typedeclaration typedeclaration = new typedeclaration(this.referencecontext.compilationresult());
typedeclaration.name = util.empty_string.tochararray();
this.currentelement = this.currentelement.add(typedeclaration, 0);
}
}

if (this.lastposistion < this.scanner.currentposition) {
this.lastposistion = this.scanner.currentposition;
this.scanner.lastposition = this.scanner.currentposition;
}

/* attempt to reset state in order to resume to parse loop */
return resumeafterrecovery();
}
public void setmethodsfullrecovery(boolean enabled) {
this.options.performmethodsfullrecovery = enabled;
}
public void setstatementsrecovery(boolean enabled) {
if(enabled) this.options.performmethodsfullrecovery = true;
this.options.performstatementsrecovery = enabled;
}
public string tostring() {


string s = "lastcheckpoint : int = " + string.valueof(this.lastcheckpoint) + "\n"; //$non-nls-1$ //$non-nls-2$
s = s + "identifierstack : char["+(this.identifierptr + 1)+"][] = {"; //$non-nls-1$ //$non-nls-2$
for (int i = 0; i <= this.identifierptr; i++) {
s = s + "\"" + string.valueof(this.identifierstack[i]) + "\","; //$non-nls-1$ //$non-nls-2$
}
s = s + "}\n"; //$non-nls-1$

s = s + "identifierlengthstack : int["+(this.identifierlengthptr + 1)+"] = {"; //$non-nls-1$ //$non-nls-2$
for (int i = 0; i <= this.identifierlengthptr; i++) {
s = s + this.identifierlengthstack[i] + ","; //$non-nls-1$
}
s = s + "}\n"; //$non-nls-1$

s = s + "astlengthstack : int["+(this.astlengthptr + 1)+"] = {"; //$non-nls-1$ //$non-nls-2$
for (int i = 0; i <= this.astlengthptr; i++) {
s = s + this.astlengthstack[i] + ","; //$non-nls-1$
}
s = s + "}\n"; //$non-nls-1$
s = s + "astptr : int = " + string.valueof(this.astptr) + "\n"; //$non-nls-1$ //$non-nls-2$

s = s + "intstack : int["+(this.intptr + 1)+"] = {"; //$non-nls-1$ //$non-nls-2$
for (int i = 0; i <= this.intptr; i++) {
s = s + this.intstack[i] + ","; //$non-nls-1$
}
s = s + "}\n"; //$non-nls-1$

s = s + "expressionlengthstack : int["+(this.expressionlengthptr + 1)+"] = {"; //$non-nls-1$ //$non-nls-2$
for (int i = 0; i <= this.expressionlengthptr; i++) {
s = s + this.expressionlengthstack[i] + ","; //$non-nls-1$
}
s = s + "}\n"; //$non-nls-1$

s = s + "expressionptr : int = " + string.valueof(this.expressionptr) + "\n"; //$non-nls-1$ //$non-nls-2$

s = s + "genericsidentifierslengthstack : int["+(this.genericsidentifierslengthptr + 1)+"] = {"; //$non-nls-1$ //$non-nls-2$
for (int i = 0; i <= this.genericsidentifierslengthptr; i++) {
s = s + this.genericsidentifierslengthstack[i] + ","; //$non-nls-1$
}
s = s + "}\n"; //$non-nls-1$

s = s + "genericslengthstack : int["+(this.genericslengthptr + 1)+"] = {"; //$non-nls-1$ //$non-nls-2$
for (int i = 0; i <= this.genericslengthptr; i++) {
s = s + this.genericslengthstack[i] + ","; //$non-nls-1$
}
s = s + "}\n"; //$non-nls-1$

s = s + "genericsptr : int = " + string.valueof(this.genericsptr) + "\n"; //$non-nls-1$ //$non-nls-2$

s = s + "\n\n\n----------------scanner--------------\n" + this.scanner.tostring(); //$non-nls-1$
return s;

}
/*
* update recovery state based on current parser/scanner state
*/
protected void updaterecoverystate() {

/* expose parser state to recovery state */
this.currentelement.updatefromparserstate();

/* check and update recovered state based on current token,
this action is also performed when shifting token after recovery
got activated once.
*/
recoverytokencheck();
}
protected void updatesourcedeclarationparts(int variabledeclaratorscounter) {
//fields is a definition of fields that are grouped together like in
//public int[] a, b[], c
//which results into 3 fields.

fielddeclaration field;
int endtypedeclarationposition =
-1 + this.aststack[this.astptr - variabledeclaratorscounter + 1].sourcestart;
for (int i = 0; i < variabledeclaratorscounter - 1; i++) {
//last one is special(see below)
field = (fielddeclaration) this.aststack[this.astptr - i - 1];
field.endpart1position = endtypedeclarationposition;
field.endpart2position = -1 + this.aststack[this.astptr - i].sourcestart;
}
//last one
(field = (fielddeclaration) this.aststack[this.astptr]).endpart1position =
endtypedeclarationposition;
field.endpart2position = field.declarationsourceend;

}
protected void updatesourceposition(expression exp) {
//update the source position of the expression

//this.intstack : int int
//-->
//this.intstack :

exp.sourceend = this.intstack[this.intptr--];
exp.sourcestart = this.intstack[this.intptr--];
}
}
