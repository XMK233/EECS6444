/*******************************************************************************
* copyright (c) 2001 international business machines corp. and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v0.5
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v05.html
*
* contributors:
*     ibm corporation - initial api and implementation
******************************************************************************/
package org.eclipse.jdt.internal.core;

import java.io.file;
import java.lang.reflect.method;

import org.apache.tools.ant.buildexception;
import org.apache.tools.ant.project;
import org.apache.tools.ant.taskdefs.compilers.defaultcompileradapter;
import org.apache.tools.ant.types.commandline;
import org.apache.tools.ant.types.path;
import org.eclipse.core.runtime.ipath;
import org.eclipse.jdt.core.javacore;

/**
* compiler adapter for the jdt compiler.
*/
public class jdtcompileradapter extends defaultcompileradapter {
private static string compilerclass = "org.eclipse.jdt.internal.compiler.batch.main"; //$non-nls-1$
/**
* performs a compile using the jdt batch compiler
*/
public boolean execute() throws buildexception {
attributes.log(util.bind("ant.jdtadapter.info.usingjdtcompiler"), project.msg_verbose); //$non-nls-1$
commandline cmd = setupjavaccommand();

try {
class c = class.forname(compilerclass);
method compile = c.getmethod("main", new class[] { string[].class }); //$non-nls-1$
compile.invoke(null, new object[] { cmd.getarguments()});
} catch (classnotfoundexception cnfe) {
throw new buildexception(util.bind("ant.jdtadapter.error.missingjdtcompiler")); //$non-nls-1$
} catch (exception ex) {
throw new buildexception(ex);
}
return true;
}


protected commandline setupjavaccommand() throws buildexception {
commandline cmd = new commandline();

/*
* this option is used to never exit at the end of the ant task.
*/
cmd.createargument().setvalue("-noexit"); //$non-nls-1$

path classpath = new path(project);

/*
* eclipse compiler doesn't support bootclasspath dir (-bootclasspath).
* it is emulated using the classpath. we add bootclasspath at the beginning of
* the classpath.
*/
if (bootclasspath != null && bootclasspath.size() != 0) {
classpath.append(bootclasspath);
} else {
/*
* no bootclasspath, we will add one throught the jre_lib variable
*/
ipath jre_lib = javacore.getclasspathvariable("jre_lib"); //$non-nls-1$
if (jre_lib == null) {
throw new buildexception(util.bind("ant.jdtadapter.error.missingjrelib")); //$non-nls-1$
}
classpath.addexisting(new path(null, jre_lib.toosstring()));
}

/*
* eclipse compiler doesn't support -extdirs.
* it is emulated using the classpath. we add extdirs entries after the
* bootclasspath.
*/
addextdirstoclasspath(classpath);

/*
* the java runtime is already handled, so we simply want to retrieve the
* ant runtime and the compile classpath.
*/
includejavaruntime = false;
classpath.append(getcompileclasspath());

/*
* set the classpath for the eclipse compiler.
*/
cmd.createargument().setvalue("-classpath"); //$non-nls-1$
cmd.createargument().setpath(classpath);

/*
* handle the nowarn option. if none, then we generate all warnings.
*/
if (attributes.getnowarn()) {
cmd.createargument().setvalue("-nowarn"); //$non-nls-1$
} else {
cmd.createargument().setvalue(
"-warn:constructorname,packagedefaultmethod,maskedcatchblocks,deprecation"); //$non-nls-1$
}

/*
* deprecation option.
*/
if (deprecation) {
cmd.createargument().setvalue("-deprecation"); //$non-nls-1$
}

/*
* destdir option.
*/
if (destdir != null) {
cmd.createargument().setvalue("-d"); //$non-nls-1$
cmd.createargument().setfile(destdir.getabsolutefile());
}

/*
* target option.
*/
if (target != null) {
cmd.createargument().setvalue("-target"); //$non-nls-1$
cmd.createargument().setvalue(target);
}

/*
* debug option
*/
if (debug) {
cmd.createargument().setvalue("-g"); //$non-nls-1$
}

/*
* verbose option
*/
if (verbose) {
cmd.createargument().setvalue("-verbose"); //$non-nls-1$
/*
* extra option allowed by the eclipse compiler
*/
cmd.createargument().setvalue("-log"); //$non-nls-1$
cmd.createargument().setvalue(destdir.getabsolutepath() + ".log"); //$non-nls-1$
}

/*
* failnoerror option
*/
if (!attributes.getfailonerror()) {
cmd.createargument().setvalue("-proceedonerror"); //$non-nls-1$
}

/*
* extra option allowed by the eclipse compiler
*/
cmd.createargument().setvalue("-time"); //$non-nls-1$

/*
* extra option allowed by the eclipse compiler
*/
cmd.createargument().setvalue("-noimporterror"); //$non-nls-1$

/*
* source option
*/
string source = attributes.getsource();
if (source != null) {
cmd.createargument().setvalue("-source"); //$non-nls-1$
cmd.createargument().setvalue(source);
}

/*
* encoding option
*/
if (encoding != null) {
cmd.createargument().setvalue("-encoding"); //$non-nls-1$
cmd.createargument().setvalue(encoding);
}

/*
* eclipse compiler doesn't have a -sourcepath option. this is
* handled through the javac task that collects all source files in
* srcdir option.
*/
logandaddfilestocompile(cmd);
return cmd;
}
}@


1.2
log
@fix for 15244
