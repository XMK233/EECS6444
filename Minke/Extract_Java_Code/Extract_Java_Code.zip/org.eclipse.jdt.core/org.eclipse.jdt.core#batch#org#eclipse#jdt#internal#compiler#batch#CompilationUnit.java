/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.batch;

import java.io.file;
import java.io.ioexception;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.env.icompilationunit;
import org.eclipse.jdt.internal.compiler.problem.abortcompilationunit;
import org.eclipse.jdt.internal.compiler.util.util;

public class compilationunit implements icompilationunit {
public char[] contents;
public char[] filename;
public char[] maintypename;
string encoding;
public string destinationpath;
// a specific destination path for this compilation unit; coding is
// aligned with main.destinationpath:
// == null: unspecified, use whatever value is set by the enclosing
//          context, id est main;
// == main.none: absorbent element, do not output class files;
// else: use as the path of the directory into which class files must
//       be written.

public compilationunit(char[] contents, string filename, string encoding) {
this(contents, filename, encoding, null);
}
public compilationunit(char[] contents, string filename, string encoding,
string destinationpath) {
this.contents = contents;
char[] filenamechararray = filename.tochararray();
switch(file.separatorchar) {
case '/' :
if (charoperation.indexof('\\', filenamechararray) != -1) {
charoperation.replace(filenamechararray, '\\', '/');
}
break;
case '\\' :
if (charoperation.indexof('/', filenamechararray) != -1) {
charoperation.replace(filenamechararray, '/', '\\');
}
}
this.filename = filenamechararray;
int start = charoperation.lastindexof(file.separatorchar, filenamechararray) + 1;

int end = charoperation.lastindexof('.', filenamechararray);
if (end == -1) {
end = filenamechararray.length;
}

this.maintypename = charoperation.subarray(filenamechararray, start, end);
this.encoding = encoding;
this.destinationpath = destinationpath;
}
public char[] getcontents() {
if (this.contents != null)
return this.contents;   // answer the cached source

// otherwise retrieve it
try {
return util.getfilecharcontent(new file(new string(this.filename)), this.encoding);
} catch (ioexception e) {
this.contents = charoperation.no_char; // assume no source if asked again
throw new abortcompilationunit(null, e, this.encoding);
}
}
/**
* @@see org.eclipse.jdt.internal.compiler.env.idependent#getfilename()
*/
public char[] getfilename() {
return this.filename;
}
public char[] getmaintypename() {
return this.maintypename;
}
public char[][] getpackagename() {
return null;
}
public string tostring() {
return "compilationunit[" + new string(this.filename) + "]";  //$non-nls-2$ //$non-nls-1$
}
}
