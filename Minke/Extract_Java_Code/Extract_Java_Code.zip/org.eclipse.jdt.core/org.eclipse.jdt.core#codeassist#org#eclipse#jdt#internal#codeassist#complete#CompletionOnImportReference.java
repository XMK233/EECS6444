/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce an import reference containing the cursor location.
* e.g.
*
*  import java.io[cursor];
*	class x {
*    void foo() {
*    }
*  }
*
*	---> <completeonimport:java.io>
*		 class x {
*         void foo() {
*         }
*       }
*
* the source range is always of length 0.
* the arguments of the allocation expression are all the arguments defined
* before the cursor.
*/

import org.eclipse.jdt.internal.compiler.ast.*;

public class completiononimportreference extends importreference {

public completiononimportreference(char[][] tokens , long[] positions, int modifiers) {
super(tokens, positions, false, modifiers);
}
public stringbuffer print(int indent, stringbuffer output, boolean withondemand) {

printindent(indent, output).append("<completeonimport:"); //$non-nls-1$
for (int i = 0; i < this.tokens.length; i++) {
if (i > 0) output.append('.');
output.append(this.tokens[i]);
}
return output.append('>');
}
}
