/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.impl;

/*
* implementors are valid compilation contexts from which we can
* escape in case of error:
*	for example: method, type or compilation unit.
*/

import org.eclipse.jdt.core.compiler.categorizedproblem;
import org.eclipse.jdt.internal.compiler.compilationresult;

public interface referencecontext {

void abort(int abortlevel, categorizedproblem problem);

compilationresult compilationresult();

boolean haserrors();

void tagashavingerrors();
}
