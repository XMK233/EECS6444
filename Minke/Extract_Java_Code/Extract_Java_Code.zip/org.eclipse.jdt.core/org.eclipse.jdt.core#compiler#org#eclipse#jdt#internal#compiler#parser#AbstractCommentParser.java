/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser;

import java.util.arraylist;
import java.util.list;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.invalidinputexception;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.util.util;

/**
* parser specialized for decoding javadoc comments
*/
public abstract class abstractcommentparser implements javadoctagconstants {

// kind of comment parser
public final static int compil_parser = 0x0001;
public final static int dom_parser = 0x0002;
public final static int selection_parser = 0x0004;
public final static int completion_parser = 0x0008;
public final static int source_parser = 0x0010;
public final static int formatter_comment_parser = 0x0020;
protected final static int parser_kind = 0x00ff;
protected final static int text_parse = 0x0100; // flag saying that text must be stored
protected final static int text_verif = 0x0200; // flag saying that text must be verified

// parser recovery states
protected final static int qualified_name_recovery = 1;
protected final static int argument_recovery= 2;
protected final static int argument_type_recovery = 3;
protected final static int empty_argument_recovery = 4;

// parse infos
public scanner scanner;
public char[] source;
protected parser sourceparser;
private int currenttokentype = -1;

// options
public boolean checkdoccomment = false;
public boolean reportproblems;
protected long compliancelevel;
protected long sourcelevel;

// support for {@@inheritdoc}
protected long [] inheritedpositions;
protected int inheritedpositionsptr;
private final static int inherited_positions_array_increment = 4;

// results
protected boolean deprecated;
protected object returnstatement;

// positions
protected int javadocstart, javadocend;
protected int javadoctextstart, javadoctextend = -1;
protected int firsttagposition;
protected int index, lineend;
protected int tokenpreviousposition, lastidentifierendposition, starposition;
protected int textstart, memberstart;
protected int tagsourcestart, tagsourceend;
protected int inlinetagstart;
protected int[] lineends;

// flags
protected boolean linestarted = false;
protected boolean inlinetagstarted = false;
protected boolean abort = false;
protected int kind;
protected int tagvalue = no_tag_value;
protected int lastblocktagvalue = no_tag_value;

// line pointers
private int lineptr, lastlineptr;

// identifier stack
protected int identifierptr;
protected char[][] identifierstack;
protected int identifierlengthptr;
protected int[] identifierlengthstack;
protected long[] identifierpositionstack;

// ast stack
protected final static int ast_stack_increment = 10;
protected int astptr;
protected object[] aststack;
protected int astlengthptr;
protected int[] astlengthstack;


protected abstractcommentparser(parser sourceparser) {
this.sourceparser = sourceparser;
this.scanner = new scanner(false, false, false, classfileconstants.jdk1_3, null, null, true/*taskcasesensitive*/);
this.identifierstack = new char[20][];
this.identifierpositionstack = new long[20];
this.identifierlengthstack = new int[10];
this.aststack = new object[30];
this.astlengthstack = new int[20];
this.reportproblems = sourceparser != null;
if (sourceparser != null) {
this.checkdoccomment = this.sourceparser.options.doccommentsupport;
this.sourcelevel = this.sourceparser.options.sourcelevel;
this.scanner.sourcelevel = this.sourcelevel;
this.compliancelevel = this.sourceparser.options.compliancelevel;
}
}

/* (non-javadoc)
* returns true if tag @@deprecated is present in javadoc comment.
*
* if javadoc checking is enabled, will also construct an javadoc node,
* which will be stored into parser.javadoc slot for being consumed later on.
*/
protected boolean commentparse() {

boolean validcomment = true;
try {
// init local variables
this.astlengthptr = -1;
this.astptr = -1;
this.identifierptr = -1;
this.currenttokentype = -1;
setinlinetagstarted(false);
this.inlinetagstart = -1;
this.linestarted = false;
this.returnstatement = null;
this.inheritedpositions = null;
this.lastblocktagvalue = no_tag_value;
this.deprecated = false;
this.lastlineptr = getlinenumber(this.javadocend);
this.textstart = -1;
this.abort = false;
char previouschar = 0;
int invalidtaglineend = -1;
int invalidinlinetaglineend = -1;
boolean linehasstar = true;
boolean veriftext = (this.kind & text_verif) != 0;
boolean isdomparser = (this.kind & dom_parser) != 0;
boolean isformatterparser = (this.kind & formatter_comment_parser) != 0;
int laststarposition = -1;

// init scanner position
this.lineptr = getlinenumber(this.firsttagposition);
int realstart = this.lineptr==1 ? this.javadocstart : this.scanner.getlineend(this.lineptr-1)+1;
if (realstart < this.javadocstart) realstart = this.javadocstart;
this.scanner.resetto(realstart, this.javadocend);
this.index = realstart;
if (realstart == this.javadocstart) {
readchar(); // starting '/'
readchar(); // first '*'
}
int previousposition = this.index;
char nextcharacter = 0;
if (realstart == this.javadocstart) {
nextcharacter = readchar(); // second '*'
while (peekchar() == '*') {
nextcharacter = readchar(); // read all contiguous '*'
}
this.javadoctextstart = this.index;
}
this.lineend = (this.lineptr == this.lastlineptr) ? this.javadocend: this.scanner.getlineend(this.lineptr) - 1;
this.javadoctextend = this.javadocend - 2; // supposed text end, it will be refined later...

// loop on each comment character
int textendposition = -1;
while (!this.abort && this.index < this.javadocend) {

// store previous position and char
previousposition = this.index;
previouschar = nextcharacter;

// calculate line end (cannot use this.scanner.lineptr as scanner does not parse line ends again)
if (this.index > (this.lineend+1)) {
updatelineend();
}

// read next char only if token was consumed
if (this.currenttokentype < 0) {
nextcharacter = readchar(); // consider unicodes
} else {
previousposition = this.scanner.getcurrenttokenstartposition();
switch (this.currenttokentype) {
case terminaltokens.tokennamerbrace:
nextcharacter = '}';
break;
case terminaltokens.tokennamemultiply:
nextcharacter = '*';
break;
default:
nextcharacter = this.scanner.currentcharacter;
}
consumetoken();
}

// consume rules depending on the read character
switch (nextcharacter) {
case '@@' :
// start tag parsing only if we are on line beginning or at inline tag beginning
if ((!this.linestarted || previouschar == '{')) {
if (this.inlinetagstarted) {
setinlinetagstarted(false);
// bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=53279
// cannot have @@ inside inline comment
if (this.reportproblems) {
int end = previousposition<invalidinlinetaglineend ? previousposition : invalidinlinetaglineend;
this.sourceparser.problemreporter().javadocunterminatedinlinetag(this.inlinetagstart, end);
}
validcomment = false;
if (this.textstart != -1 && this.textstart < textendposition) {
pushtext(this.textstart, textendposition);
}
if (isdomparser || isformatterparser) {
refreshinlinetagposition(textendposition);
}
}
if (previouschar == '{') {
if (this.textstart != -1) {
if (this.textstart < textendposition) {
pushtext(this.textstart, textendposition);
}
}
setinlinetagstarted(true);
invalidinlinetaglineend = this.lineend;
} else if (this.textstart != -1 && this.textstart < invalidtaglineend) {
pushtext(this.textstart, invalidtaglineend);
}
this.scanner.resetto(this.index, this.javadocend);
this.currenttokentype = -1; // flush token cache at line begin
try {
if (!parsetag(previousposition)) {
// bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=51600
// do not stop the inline tag when error is encountered to get text after
validcomment = false;
// bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=51600
// for dom ast node, store tag as text in case of invalid syntax
if (isdomparser) {
createtag();
}
this.textstart = this.tagsourceend+1;
invalidtaglineend  = this.lineend;
textendposition = this.index;
}
} catch (invalidinputexception e) {
consumetoken();
}
} else {
textendposition = this.index;
if (veriftext && this.tagvalue == tag_return_value && this.returnstatement != null) {
refreshreturnstatement();
} else if (isformatterparser) {
if (this.textstart == -1) this.textstart = previousposition;
}
}
this.linestarted = true;
break;
case '\r':
case '\n':
if (this.linestarted) {
if (isformatterparser && !scannerhelper.iswhitespace(previouschar)) {
textendposition = previousposition;
}
if (this.textstart != -1 && this.textstart < textendposition) {
pushtext(this.textstart, textendposition);
}
}
this.linestarted = false;
linehasstar = false;
// fix bug 51650
this.textstart = -1;
break;
case '}' :
if (veriftext && this.tagvalue == tag_return_value && this.returnstatement != null) {
refreshreturnstatement();
}
if (this.inlinetagstarted) {
if (this.linestarted && this.textstart != -1 && this.textstart < textendposition) {
pushtext(this.textstart, textendposition);
}
refreshinlinetagposition(previousposition);
if (!isformatterparser) this.textstart = this.index;
setinlinetagstarted(false);
} else {
if (!this.linestarted) {
this.textstart = previousposition;
}
}
this.linestarted = true;
textendposition = this.index;
break;
case '{' :
if (veriftext && this.tagvalue == tag_return_value && this.returnstatement != null) {
refreshreturnstatement();
}
if (this.inlinetagstarted) {
setinlinetagstarted(false);
// bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=53279
// cannot have opening brace in inline comment
if (this.reportproblems) {
int end = previousposition<invalidinlinetaglineend ? previousposition : invalidinlinetaglineend;
this.sourceparser.problemreporter().javadocunterminatedinlinetag(this.inlinetagstart, end);
}
if (this.linestarted && this.textstart != -1 && this.textstart < textendposition) {
pushtext(this.textstart, textendposition);
}
refreshinlinetagposition(textendposition);
textendposition = this.index;
} else if (peekchar() != '@@') {
if (this.textstart == -1) this.textstart = previousposition;
textendposition = this.index;
}
if (!this.linestarted) {
this.textstart = previousposition;
}
this.linestarted = true;
this.inlinetagstart = previousposition;
break;
case '*' :
// store the star position as text start while formatting
laststarposition = previousposition;
if (previouschar != '*') {
this.starposition = previousposition;
if (isdomparser || isformatterparser) {
if (linehasstar) {
this.linestarted = true;
if (this.textstart == -1) {
this.textstart = previousposition;
if (this.index <= this.javadoctextend) textendposition = this.index;
}
}
if (!this.linestarted) {
linehasstar = true;
}
}
}
break;
case '\u000c' :	/* form feed               */
case ' ' :			/* space                   */
case '\t' :			/* horizontal tabulation   */
// do not include trailing spaces in text while formatting
if (isformatterparser) {
if (!scannerhelper.iswhitespace(previouschar)) {
textendposition = previousposition;
}
} else if (this.linestarted && isdomparser) {
textendposition = this.index;
}
break;
case '/':
if (previouschar == '*') {
// end of javadoc
break;
}
// $fall-through$ - fall through default case
default :
if (isformatterparser && nextcharacter == '<') {
// html tags are meaningful for formatter parser
int initialindex = this.index;
this.scanner.resetto(this.index, this.javadocend);
if (!scannerhelper.iswhitespace(previouschar)) {
textendposition = previousposition;
}
if (parsehtmltag(previousposition, textendposition)) {
break;
}
if (this.abort) return false;
// wrong html syntax continue to process character normally
this.scanner.currentposition = initialindex;
this.index = initialindex;
}
if (veriftext && this.tagvalue == tag_return_value && this.returnstatement != null) {
refreshreturnstatement();
}
if (!this.linestarted || this.textstart == -1) {
this.textstart = previousposition;
}
this.linestarted = true;
textendposition = this.index;
break;
}
}
this.javadoctextend = this.starposition-1;

// bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=53279
// cannot leave comment inside inline comment
if (this.inlinetagstarted) {
if (this.reportproblems) {
int end = this.javadoctextend<invalidinlinetaglineend ? this.javadoctextend : invalidinlinetaglineend;
if (this.index >= this.javadocend) end = invalidinlinetaglineend;
this.sourceparser.problemreporter().javadocunterminatedinlinetag(this.inlinetagstart, end);
}
if (this.linestarted && this.textstart != -1 && this.textstart < textendposition) {
pushtext(this.textstart, textendposition);
}
refreshinlinetagposition(textendposition);
setinlinetagstarted(false);
} else if (this.linestarted && this.textstart != -1 && this.textstart <= textendposition && (this.textstart < this.starposition || this.starposition == laststarposition)) {
pushtext(this.textstart, textendposition);
}
updatedoccomment();
} catch (exception ex) {
validcomment = false;
}
return validcomment;
}

protected void consumetoken() {
this.currenttokentype = -1; // flush token cache
updatelineend();
}

protected abstract object createargumentreference(char[] name, int dim, boolean isvarargs, object typeref, long[] dimpos, long argnamepos) throws invalidinputexception;
protected boolean createfakereference(int start) {
// do nothing by default
return true;
}
protected abstract object createfieldreference(object receiver) throws invalidinputexception;
protected abstract object createmethodreference(object receiver, list arguments) throws invalidinputexception;
protected object createreturnstatement() { return null; }
protected abstract void createtag();
protected abstract object createtypereference(int primitivetoken);

private int getindexposition() {
if (this.index > this.lineend) {
return this.lineend;
} else {
return this.index-1;
}
}

/**
* search the line number corresponding to a specific position.
* warning: returned position is 1-based index!
* @@see scanner#getlinenumber(int) we cannot directly use this method
* when lineptr field is not initialized.
*/
private int getlinenumber(int position) {

if (this.scanner.lineptr != -1) {
return util.getlinenumber(position, this.scanner.lineends, 0, this.scanner.lineptr);
}
if (this.lineends == null)
return 1;
return util.getlinenumber(position, this.lineends, 0, this.lineends.length-1);
}

private int gettokenendposition() {
if (this.scanner.getcurrenttokenendposition() > this.lineend) {
return this.lineend;
} else {
return this.scanner.getcurrenttokenendposition();
}
}

/**
* @@return returns the currenttokentype.
*/
protected int getcurrenttokentype() {
return this.currenttokentype;
}

/*
* parse argument in @@see tag method reference
*/
protected object parsearguments(object receiver) throws invalidinputexception {

// init
int modulo = 0; // should be 2 for (type,type,...) or 3 for (type arg,type arg,...)
int itoken = 0;
char[] argname = null;
list arguments = new arraylist(10);
int start = this.scanner.getcurrenttokenstartposition();
object typeref = null;
int dim = 0;
boolean isvarargs = false;
long[] dimpositions = new long[20]; // assume that there won't be more than 20 dimensions...
char[] name = null;
long argnamepos = -1;

// parse arguments declaration if method reference
nextarg : while (this.index < this.scanner.eofposition) {

// read argument type reference
try {
typeref = parsequalifiedname(false);
if (this.abort) return null; // may be aborted by specialized parser
} catch (invalidinputexception e) {
break nextarg;
}
boolean firstarg = modulo == 0;
if (firstarg) { // verify position
if (itoken != 0)
break nextarg;
} else if ((itoken % modulo) != 0) {
break nextarg;
}
if (typeref == null) {
if (firstarg && this.currenttokentype == terminaltokens.tokennamerparen) {
// verify characters after arguments declaration (expecting white space or end comment)
if (!verifyspaceorendcomment()) {
int end = this.starposition == -1 ? this.lineend : this.starposition;
if (this.source[end]=='\n') end--;
if (this.reportproblems) this.sourceparser.problemreporter().javadocmalformedseereference(start, end);
return null;
}
this.linestarted = true;
return createmethodreference(receiver, null);
}
break nextarg;
}
itoken++;

// read possible additional type info
dim = 0;
isvarargs = false;
if (readtoken() == terminaltokens.tokennamelbracket) {
// array declaration
int dimstart = this.scanner.getcurrenttokenstartposition();
while (readtoken() == terminaltokens.tokennamelbracket) {
consumetoken();
if (readtoken() != terminaltokens.tokennamerbracket) {
break nextarg;
}
consumetoken();
dimpositions[dim++] = (((long) dimstart) << 32) + this.scanner.getcurrenttokenendposition();
}
} else if (readtoken() == terminaltokens.tokennameellipsis) {
// ellipsis declaration
int dimstart = this.scanner.getcurrenttokenstartposition();
dimpositions[dim++] = (((long) dimstart) << 32) + this.scanner.getcurrenttokenendposition();
consumetoken();
isvarargs = true;
}

// read argument name
argnamepos = -1;
if (readtoken() == terminaltokens.tokennameidentifier) {
consumetoken();
if (firstarg) { // verify position
if (itoken != 1)
break nextarg;
} else if ((itoken % modulo) != 1) {
break nextarg;
}
if (argname == null) { // verify that all arguments name are declared
if (!firstarg) {
break nextarg;
}
}
argname = this.scanner.getcurrentidentifiersource();
argnamepos = (((long)this.scanner.getcurrenttokenstartposition())<<32)+this.scanner.getcurrenttokenendposition();
itoken++;
} else if (argname != null) { // verify that no argument name is declared
break nextarg;
}

// verify token position
if (firstarg) {
modulo = itoken + 1;
} else {
if ((itoken % modulo) != (modulo - 1)) {
break nextarg;
}
}

// read separator or end arguments declaration
int token = readtoken();
name = argname == null ? charoperation.no_char : argname;
if (token == terminaltokens.tokennamecomma) {
// create new argument
object argument = createargumentreference(name, dim, isvarargs, typeref, dimpositions, argnamepos);
if (this.abort) return null; // may be aborted by specialized parser
arguments.add(argument);
consumetoken();
itoken++;
} else if (token == terminaltokens.tokennamerparen) {
// verify characters after arguments declaration (expecting white space or end comment)
if (!verifyspaceorendcomment()) {
int end = this.starposition == -1 ? this.lineend : this.starposition;
if (this.source[end]=='\n') end--;
if (this.reportproblems) this.sourceparser.problemreporter().javadocmalformedseereference(start, end);
return null;
}
// create new argument
object argument = createargumentreference(name, dim, isvarargs, typeref, dimpositions, argnamepos);
if (this.abort) return null; // may be aborted by specialized parser
arguments.add(argument);
consumetoken();
return createmethodreference(receiver, arguments);
} else {
break nextarg;
}
}

// something wrong happened => invalid input
throw new invalidinputexception();
}

/**
* parse a possible html tag like:
* <ul>
* 	<li>&lt;code&gt;
* 	<li>&lt;br&gt;
* 	<li>&lt;h?&gt;
* </ul>
*
* note that the default is to do nothing!
*
* @@param previousposition the position of the '<' character on which the tag might start
* @@param endtextposition the position of the end of the previous text
* @@return <code>true</code> if a valid html tag has been parsed, <code>false</code>
* 	otherwise
* @@throws invalidinputexception if any problem happens during the parse in this area
*/
protected boolean parsehtmltag(int previousposition, int endtextposition) throws invalidinputexception {
return false;
}

/*
* parse an url link reference in @@see tag
*/
protected boolean parsehref() throws invalidinputexception {
boolean skipcomments = this.scanner.skipcomments;
this.scanner.skipcomments = true;
try {
int start = this.scanner.getcurrenttokenstartposition();
char currentchar = readchar();
if (currentchar == 'a' || currentchar == 'a') {
this.scanner.currentposition = this.index;
if (readtoken() == terminaltokens.tokennameidentifier) {
consumetoken();
try {
if (charoperation.equals(this.scanner.getcurrentidentifiersource(), href_tag, false) &&
readtoken() == terminaltokens.tokennameequal) {
consumetoken();
if (readtoken() == terminaltokens.tokennamestringliteral) {
consumetoken();
while (this.index < this.javadocend) { // main loop to search for the </a> pattern
// skip all characters after string literal until closing '>' (see bug 68726)
while (readtoken() != terminaltokens.tokennamegreater) {
if (this.scanner.currentposition >= this.scanner.eofposition || this.scanner.currentcharacter == '@@' ||
(this.inlinetagstarted && this.scanner.currentcharacter == '}')) {
// reset position: we want to rescan last token
this.index = this.tokenpreviousposition;
this.scanner.currentposition = this.tokenpreviousposition;
this.currenttokentype = -1;
// signal syntax error
if (this.tagvalue != tag_value_value) { // do not report error for @@value tag, this will be done after...
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidseehref(start, this.lineend);
}
return false;
}
this.currenttokentype = -1; // consume token without updating line end
}
consumetoken(); // update line end as new lines are allowed in url description
while (readtoken() != terminaltokens.tokennameless) {
if (this.scanner.currentposition >= this.scanner.eofposition || this.scanner.currentcharacter == '@@' ||
(this.inlinetagstarted && this.scanner.currentcharacter == '}')) {
// reset position: we want to rescan last token
this.index = this.tokenpreviousposition;
this.scanner.currentposition = this.tokenpreviousposition;
this.currenttokentype = -1;
// signal syntax error
if (this.tagvalue != tag_value_value) { // do not report error for @@value tag, this will be done after...
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidseehref(start, this.lineend);
}
return false;
}
consumetoken();
}
consumetoken();
start = this.scanner.getcurrenttokenstartposition();
currentchar = readchar();
// search for the </a> pattern and store last char read
if (currentchar == '/') {
currentchar = readchar();
if (currentchar == 'a' || currentchar =='a') {
currentchar = readchar();
if (currentchar == '>') {
return true; // valid href
}
}
}
// search for invalid char in tags
if (currentchar == '\r' || currentchar == '\n' || currentchar == '\t' || currentchar == ' ') {
break;
}
}
}
}
} catch (invalidinputexception ex) {
// do nothing as we want to keep positions for error message
}
}
}
// reset position: we want to rescan last token
this.index = this.tokenpreviousposition;
this.scanner.currentposition = this.tokenpreviousposition;
this.currenttokentype = -1;
// signal syntax error
if (this.tagvalue != tag_value_value) { // do not report error for @@value tag, this will be done after...
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidseehref(start, this.lineend);
}
}
finally {
this.scanner.skipcomments = skipcomments;
}
return false;
}

/*
* parse tag followed by an identifier
*/
protected boolean parseidentifiertag(boolean report) {
int token = readtokensafely();
switch (token) {
case terminaltokens.tokennameidentifier:
pushidentifier(true, false);
return true;
}
if (report) {
this.sourceparser.problemreporter().javadocmissingidentifier(this.tagsourcestart, this.tagsourceend, this.sourceparser.modifiers);
}
return false;
}

/*
* parse a method reference in @@see tag
*/
protected object parsemember(object receiver) throws invalidinputexception {
// init
this.identifierptr = -1;
this.identifierlengthptr = -1;
int start = this.scanner.getcurrenttokenstartposition();
this.memberstart = start;

// get member identifier
if (readtoken() == terminaltokens.tokennameidentifier) {
if (this.scanner.currentcharacter == '.') { // member name may be qualified (inner class constructor reference)
parsequalifiedname(true);
} else {
consumetoken();
pushidentifier(true, false);
}
// look for next token to know whether it's a field or method reference
int previousposition = this.index;
if (readtoken() == terminaltokens.tokennamelparen) {
consumetoken();
start = this.scanner.getcurrenttokenstartposition();
try {
return parsearguments(receiver);
} catch (invalidinputexception e) {
int end = this.scanner.getcurrenttokenendposition() < this.lineend ?
this.scanner.getcurrenttokenendposition() :
this.scanner.getcurrenttokenstartposition();
end = end < this.lineend ? end : this.lineend;
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidseereferenceargs(start, end);
}
return null;
}

// reset position: we want to rescan last token
this.index = previousposition;
this.scanner.currentposition = previousposition;
this.currenttokentype = -1;

// verify character(s) after identifier (expecting space or end comment)
if (!verifyspaceorendcomment()) {
int end = this.starposition == -1 ? this.lineend : this.starposition;
if (this.source[end]=='\n') end--;
if (this.reportproblems) this.sourceparser.problemreporter().javadocmalformedseereference(start, end);
return null;
}
return createfieldreference(receiver);
}
int end = gettokenendposition() - 1;
end = start > end ? start : end;
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidreference(start, end);
// reset position: we want to rescan last token
this.index = this.tokenpreviousposition;
this.scanner.currentposition = this.tokenpreviousposition;
this.currenttokentype = -1;
return null;
}

/*
* parse @@param tag declaration
*/
protected boolean parseparam() throws invalidinputexception {

// store current state
int start = this.tagsourcestart;
int end = this.tagsourceend;
boolean tokenwhitespace = this.scanner.tokenizewhitespace;
this.scanner.tokenizewhitespace = true;

try {
// verify that there are whitespaces after tag
boolean iscompletionparser = (this.kind & completion_parser) != 0;
if (this.scanner.currentcharacter != ' ' && !scannerhelper.iswhitespace(this.scanner.currentcharacter)) {
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidtag(start, this.scanner.getcurrenttokenendposition());
if (!iscompletionparser) {
this.scanner.currentposition = start;
this.index = start;
}
this.currenttokentype = -1;
return false;
}

// get first non whitespace token
this.identifierptr = -1;
this.identifierlengthptr = -1;
boolean hasmultilines = this.scanner.currentposition > (this.lineend+1);
boolean istypeparam = false;
boolean valid = true, empty = true;
boolean maybegeneric = this.sourcelevel >= classfileconstants.jdk1_5;
int token = -1;
nexttoken: while (true) {
this.currenttokentype = -1;
try {
token = readtoken();
} catch (invalidinputexception e) {
valid = false;
}
switch (token) {
case terminaltokens.tokennameidentifier :
if (valid) {
// store param name id
pushidentifier(true, false);
start = this.scanner.getcurrenttokenstartposition();
end = hasmultilines ? this.lineend: this.scanner.getcurrenttokenendposition();
break nexttoken;
}
// $fall-through$ - fall through next case to report error
case terminaltokens.tokennameless:
if (valid && maybegeneric) {
// store '<' in identifiers stack as we need to add it to tag element (bug 79809)
pushidentifier(true, true);
start = this.scanner.getcurrenttokenstartposition();
end = hasmultilines ? this.lineend: this.scanner.getcurrenttokenendposition();
istypeparam = true;
break nexttoken;
}
// $fall-through$ - fall through next case to report error
default:
if (token == terminaltokens.tokennameleft_shift) istypeparam = true;
if (valid && !hasmultilines) start = this.scanner.getcurrenttokenstartposition();
valid = false;
if (!hasmultilines) {
empty = false;
end = hasmultilines ? this.lineend: this.scanner.getcurrenttokenendposition();
break;
}
end = this.lineend;
// $fall-through$ - when several lines, fall through next case to report problem immediately
case terminaltokens.tokennamewhitespace:
if (this.scanner.currentposition > (this.lineend+1)) hasmultilines = true;
if (valid) break;
// $fall-through$ - if not valid fall through next case to report error
case terminaltokens.tokennameeof:
if (this.reportproblems)
if (empty)
this.sourceparser.problemreporter().javadocmissingparamname(start, end, this.sourceparser.modifiers);
else if (maybegeneric && istypeparam)
this.sourceparser.problemreporter().javadocinvalidparamtypeparameter(start, end);
else
this.sourceparser.problemreporter().javadocinvalidparamtagname(start, end);
if (!iscompletionparser) {
this.scanner.currentposition = start;
this.index = start;
}
this.currenttokentype = -1;
return false;
}
}

// scan more tokens for type parameter declaration
if (istypeparam && maybegeneric) {
// get type parameter name
nexttoken: while (true) {
this.currenttokentype = -1;
try {
token = readtoken();
} catch (invalidinputexception e) {
valid = false;
}
switch (token) {
case terminaltokens.tokennamewhitespace:
if (valid && this.scanner.currentposition <= (this.lineend+1)) {
break;
}
// $fall-through$ - if not valid fall through next case to report error
case terminaltokens.tokennameeof:
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidparamtypeparameter(start, end);
if (!iscompletionparser) {
this.scanner.currentposition = start;
this.index = start;
}
this.currenttokentype = -1;
return false;
case terminaltokens.tokennameidentifier :
end = hasmultilines ? this.lineend: this.scanner.getcurrenttokenendposition();
if (valid) {
// store param name id
pushidentifier(false, false);
break nexttoken;
}
break;
default:
end = hasmultilines ? this.lineend: this.scanner.getcurrenttokenendposition();
valid = false;
break;
}
}

// get last character of type parameter declaration
boolean spaces = false;
nexttoken: while (true) {
this.currenttokentype = -1;
try {
token = readtoken();
} catch (invalidinputexception e) {
valid = false;
}
switch (token) {
case terminaltokens.tokennamewhitespace:
if (this.scanner.currentposition > (this.lineend+1)) {
// do not accept type parameter declaration on several lines
hasmultilines = true;
valid = false;
}
spaces = true;
if (valid) break;
// $fall-through$ - if not valid fall through next case to report error
case terminaltokens.tokennameeof:
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidparamtypeparameter(start, end);
if (!iscompletionparser) {
this.scanner.currentposition = start;
this.index = start;
}
this.currenttokentype = -1;
return false;
case terminaltokens.tokennamegreater:
end = hasmultilines ? this.lineend: this.scanner.getcurrenttokenendposition();
if (valid) {
// store '>' in identifiers stack as we need to add it to tag element (bug 79809)
pushidentifier(false, true);
break nexttoken;
}
break;
default:
if (!spaces) end = hasmultilines ? this.lineend: this.scanner.getcurrenttokenendposition();
valid = false;
break;
}
}
}

// verify that tag name is well followed by white spaces
if (valid) {
this.currenttokentype = -1;
int restart = this.scanner.currentposition;
try {
token = readtokenandconsume();
} catch (invalidinputexception e) {
valid = false;
}
if (token == terminaltokens.tokennamewhitespace) {
this.scanner.resetto(restart, this.javadocend);
this.index = restart;
return pushparamname(istypeparam);
}
}
// report problem
this.currenttokentype = -1;
if (iscompletionparser) return false;
if (this.reportproblems) {
// we only need end if we report problems
end = hasmultilines ? this.lineend: this.scanner.getcurrenttokenendposition();
try {
while ((token=readtoken()) != terminaltokens.tokennamewhitespace && token != terminaltokens.tokennameeof) {
this.currenttokentype = -1;
end = hasmultilines ? this.lineend: this.scanner.getcurrenttokenendposition();
}
} catch (invalidinputexception e) {
end = this.lineend;
}
if (maybegeneric && istypeparam)
this.sourceparser.problemreporter().javadocinvalidparamtypeparameter(start, end);
else
this.sourceparser.problemreporter().javadocinvalidparamtagname(start, end);
}
this.scanner.currentposition = start;
this.index = start;
this.currenttokentype = -1;
return false;
} finally {
// we have to make sure that this is reset to the previous value even if an exception occurs
this.scanner.tokenizewhitespace = tokenwhitespace;
}
}

/*
* parse a qualified name and built a type reference if the syntax is valid.
*/
protected object parsequalifiedname(boolean reset) throws invalidinputexception {

// reset identifier stack if requested
if (reset) {
this.identifierptr = -1;
this.identifierlengthptr = -1;
}

// scan tokens
int primitivetoken = -1;
int parserkind = this.kind & parser_kind;
nexttoken : for (int itoken = 0; ; itoken++) {
int token = readtokensafely();
switch (token) {
case terminaltokens.tokennameidentifier :
if (((itoken & 1) != 0)) { // identifiers must be odd tokens
break nexttoken;
}
pushidentifier(itoken == 0, false);
consumetoken();
break;

case terminaltokens.tokennamedot :
if ((itoken & 1) == 0) { // dots must be even tokens
throw new invalidinputexception();
}
consumetoken();
break;

case terminaltokens.tokennameabstract:
case terminaltokens.tokennameassert:
case terminaltokens.tokennameboolean:
case terminaltokens.tokennamebreak:
case terminaltokens.tokennamebyte:
case terminaltokens.tokennamecase:
case terminaltokens.tokennamecatch:
case terminaltokens.tokennamechar:
case terminaltokens.tokennameclass:
case terminaltokens.tokennamecontinue:
case terminaltokens.tokennamedefault:
case terminaltokens.tokennamedo:
case terminaltokens.tokennamedouble:
case terminaltokens.tokennameelse:
case terminaltokens.tokennameextends:
case terminaltokens.tokennamefalse:
case terminaltokens.tokennamefinal:
case terminaltokens.tokennamefinally:
case terminaltokens.tokennamefloat:
case terminaltokens.tokennamefor:
case terminaltokens.tokennameif:
case terminaltokens.tokennameimplements:
case terminaltokens.tokennameimport:
case terminaltokens.tokennameinstanceof:
case terminaltokens.tokennameint:
case terminaltokens.tokennameinterface:
case terminaltokens.tokennamelong:
case terminaltokens.tokennamenative:
case terminaltokens.tokennamenew:
case terminaltokens.tokennamenull:
case terminaltokens.tokennamepackage:
case terminaltokens.tokennameprivate:
case terminaltokens.tokennameprotected:
case terminaltokens.tokennamepublic:
case terminaltokens.tokennameshort:
case terminaltokens.tokennamestatic:
case terminaltokens.tokennamestrictfp:
case terminaltokens.tokennamesuper:
case terminaltokens.tokennameswitch:
case terminaltokens.tokennamesynchronized:
case terminaltokens.tokennamethis:
case terminaltokens.tokennamethrow:
case terminaltokens.tokennametransient:
case terminaltokens.tokennametrue:
case terminaltokens.tokennametry:
case terminaltokens.tokennamevoid:
case terminaltokens.tokennamevolatile:
case terminaltokens.tokennamewhile:
if (itoken == 0) {
pushidentifier(true, true);
primitivetoken = token;
consumetoken();
break nexttoken;
}
// fall through default case to verify that we do not leave on a dot
//$fall-through$
default :
if (itoken == 0) {
if (this.identifierptr>=0) {
this.lastidentifierendposition = (int) this.identifierpositionstack[this.identifierptr];
}
return null;
}
if ((itoken & 1) == 0) { // cannot leave on a dot
switch (parserkind) {
case completion_parser:
if (this.identifierptr>=0) {
this.lastidentifierendposition = (int) this.identifierpositionstack[this.identifierptr];
}
return syntaxrecoverqualifiedname(primitivetoken);
case dom_parser:
if (this.currenttokentype != -1) {
// reset position: we want to rescan last token
this.index = this.tokenpreviousposition;
this.scanner.currentposition = this.tokenpreviousposition;
this.currenttokentype = -1;
}
// $fall-through$ - fall through default case to raise exception
default:
throw new invalidinputexception();
}
}
break nexttoken;
}
}
// reset position: we want to rescan last token
if (parserkind != completion_parser && this.currenttokentype != -1) {
this.index = this.tokenpreviousposition;
this.scanner.currentposition = this.tokenpreviousposition;
this.currenttokentype = -1;
}
if (this.identifierptr>=0) {
this.lastidentifierendposition = (int) this.identifierpositionstack[this.identifierptr];
}
return createtypereference(primitivetoken);
}

/*
* parse a reference in @@see tag
*/
protected boolean parsereference() throws invalidinputexception {
int currentposition = this.scanner.currentposition;
try {
object typeref = null;
object reference = null;
int previousposition = -1;
int typerefstartposition = -1;

// get reference tokens
nexttoken : while (this.index < this.scanner.eofposition) {
previousposition = this.index;
int token = readtokensafely();
switch (token) {
case terminaltokens.tokennamestringliteral : // @@see "string"
// if typeref != null we may raise a warning here to let user know there's an unused reference...
// currently as javadoc 1.4.2 ignore it, we do the same (see bug 69302)
if (typeref != null) break nexttoken;
consumetoken();
int start = this.scanner.getcurrenttokenstartposition();
if (this.tagvalue == tag_value_value) {
// string reference are not allowed for @@value tag
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidvaluereference(start, gettokenendposition(), this.sourceparser.modifiers);
return false;
}

// verify end line
if (verifyendline(previousposition)) {
return createfakereference(start);
}
if (this.reportproblems) this.sourceparser.problemreporter().javadocunexpectedtext(this.scanner.currentposition, this.lineend);
return false;
case terminaltokens.tokennameless : // @@see <a href="url#value">label</a>
// if typeref != null we may raise a warning here to let user know there's an unused reference...
// currently as javadoc 1.4.2 ignore it, we do the same (see bug 69302)
if (typeref != null) break nexttoken;
consumetoken();
start = this.scanner.getcurrenttokenstartposition();
if (parsehref()) {
consumetoken();
if (this.tagvalue == tag_value_value) {
// string reference are not allowed for @@value tag
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidvaluereference(start, getindexposition(), this.sourceparser.modifiers);
return false;
}
// verify end line
if (verifyendline(previousposition)) {
return createfakereference(start);
}
if (this.reportproblems) this.sourceparser.problemreporter().javadocunexpectedtext(this.scanner.currentposition, this.lineend);
}
else if (this.tagvalue == tag_value_value) {
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidvaluereference(start, getindexposition(), this.sourceparser.modifiers);
}
return false;
case terminaltokens.tokennameerror :
consumetoken();
if (this.scanner.currentcharacter == '#') { // @@see ...#member
reference = parsemember(typeref);
if (reference != null) {
return pushseeref(reference);
}
return false;
}
char[] currenterror = this.scanner.getcurrentidentifiersource();
if (currenterror.length>0 && currenterror[0] == '"') {
if (this.reportproblems) {
boolean isurlref = false;
if (this.tagvalue == tag_see_value) {
int length=currenterror.length, i=1 /* first char is " */;
while (i<length && scannerhelper.isletter(currenterror[i])) {
i++;
}
if (i<(length-2) && currenterror[i] == ':' && currenterror[i+1] == '/' && currenterror[i+2] == '/') {
isurlref = true;
}
}
if (isurlref) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=207765
// handle invalid url references in javadoc with dedicated message
this.sourceparser.problemreporter().javadocinvalidseeurlreference(this.scanner.getcurrenttokenstartposition(), gettokenendposition());
} else {
this.sourceparser.problemreporter().javadocinvalidreference(this.scanner.getcurrenttokenstartposition(), gettokenendposition());
}
}
return false;
}
break nexttoken;
case terminaltokens.tokennameidentifier :
if (typeref == null) {
typerefstartposition = this.scanner.getcurrenttokenstartposition();
typeref = parsequalifiedname(true);
if (this.abort) return false; // may be aborted by specialized parser
break;
}
break nexttoken;
default :
break nexttoken;
}
}

// verify that we got a reference
if (reference == null) reference = typeref;
if (reference == null) {
this.index = this.tokenpreviousposition;
this.scanner.currentposition = this.tokenpreviousposition;
this.currenttokentype = -1;
if (this.tagvalue == tag_value_value) {
if ((this.kind & dom_parser) != 0) createtag();
return true;
}
if (this.reportproblems) {
this.sourceparser.problemreporter().javadocmissingreference(this.tagsourcestart, this.tagsourceend, this.sourceparser.modifiers);
}
return false;
}

// reset position at the end of type reference
if (this.lastidentifierendposition > this.javadocstart) {
this.index = this.lastidentifierendposition+1;
this.scanner.currentposition = this.index;
}
this.currenttokentype = -1;

// in case of @@value, we have an invalid reference (only static field refs are valid for this tag)
if (this.tagvalue == tag_value_value) {
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidreference(typerefstartposition, this.lineend);
return false;
}

int currentindex = this.index; // store current index
char ch = readchar();
switch (ch) {
// verify that line end does not start with an open parenthese (which could be a constructor reference wrongly written...)
// see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=47215
case '(' :
if (this.reportproblems) this.sourceparser.problemreporter().javadocmissinghashcharacter(typerefstartposition, this.lineend, string.valueof(this.source, typerefstartposition, this.lineend-typerefstartposition+1));
return false;
// search for the :// url pattern
// see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=168849
case ':' :
ch = readchar();
if (ch == '/' && ch == readchar()) {
if (this.reportproblems) {
this.sourceparser.problemreporter().javadocinvalidseeurlreference(typerefstartposition, this.lineend);
return false;
}
}
}
// revert to last stored index
this.index = currentindex;

// verify that we get white space after reference
if (!verifyspaceorendcomment()) {
this.index = this.tokenpreviousposition;
this.scanner.currentposition = this.tokenpreviousposition;
this.currenttokentype = -1;
int end = this.starposition == -1 ? this.lineend : this.starposition;
if (this.source[end]=='\n') end--;
if (this.reportproblems) this.sourceparser.problemreporter().javadocmalformedseereference(typerefstartposition, end);
return false;
}

// everything is ok, store reference
return pushseeref(reference);
}
catch (invalidinputexception ex) {
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidreference(currentposition, gettokenendposition());
}
// reset position to avoid missing tokens when new line was encountered
this.index = this.tokenpreviousposition;
this.scanner.currentposition = this.tokenpreviousposition;
this.currenttokentype = -1;
return false;
}

/*
* parse tag declaration
*/
protected abstract boolean parsetag(int previousposition) throws invalidinputexception;

/*
* parse @@throws tag declaration
*/
protected boolean parsethrows() {
int start = this.scanner.currentposition;
try {
object typeref = parsequalifiedname(true);
if (this.abort) return false; // may be aborted by specialized parser
if (typeref == null) {
if (this.reportproblems)
this.sourceparser.problemreporter().javadocmissingthrowsclassname(this.tagsourcestart, this.tagsourceend, this.sourceparser.modifiers);
} else {
return pushthrowname(typeref);
}
} catch (invalidinputexception ex) {
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidthrowsclass(start, gettokenendposition());
}
return false;
}

/*
* return current character without move index position.
*/
protected char peekchar() {
int idx = this.index;
char c = this.source[idx++];
if (c == '\\' && this.source[idx] == 'u') {
int c1, c2, c3, c4;
idx++;
while (this.source[idx] == 'u')
idx++;
if (!(((c1 = scannerhelper.getnumericvalue(this.source[idx++])) > 15 || c1 < 0)
|| ((c2 = scannerhelper.getnumericvalue(this.source[idx++])) > 15 || c2 < 0)
|| ((c3 = scannerhelper.getnumericvalue(this.source[idx++])) > 15 || c3 < 0) || ((c4 = scannerhelper.getnumericvalue(this.source[idx++])) > 15 || c4 < 0))) {
c = (char) (((c1 * 16 + c2) * 16 + c3) * 16 + c4);
}
}
return c;
}

/*
* push the consumetoken on the identifier stack. increase the total number of identifier in the stack.
*/
protected void pushidentifier(boolean newlength, boolean istoken) {

int stacklength = this.identifierstack.length;
if (++this.identifierptr >= stacklength) {
system.arraycopy(
this.identifierstack, 0,
this.identifierstack = new char[stacklength + 10][], 0,
stacklength);
system.arraycopy(
this.identifierpositionstack, 0,
this.identifierpositionstack = new long[stacklength + 10], 0,
stacklength);
}
this.identifierstack[this.identifierptr] = istoken ? this.scanner.getcurrenttokensource() : this.scanner.getcurrentidentifiersource();
this.identifierpositionstack[this.identifierptr] = (((long) this.scanner.startposition) << 32) + (this.scanner.currentposition - 1);

if (newlength) {
stacklength = this.identifierlengthstack.length;
if (++this.identifierlengthptr >= stacklength) {
system.arraycopy(
this.identifierlengthstack, 0,
this.identifierlengthstack = new int[stacklength + 10], 0,
stacklength);
}
this.identifierlengthstack[this.identifierlengthptr] = 1;
} else {
this.identifierlengthstack[this.identifierlengthptr]++;
}
}

/*
* add a new obj on top of the ast stack.
* if new length is required, then add also a new length in length stack.
*/
protected void pushonaststack(object node, boolean newlength) {

if (node == null) {
int stacklength = this.astlengthstack.length;
if (++this.astlengthptr >= stacklength) {
system.arraycopy(
this.astlengthstack, 0,
this.astlengthstack = new int[stacklength + ast_stack_increment], 0,
stacklength);
}
this.astlengthstack[this.astlengthptr] = 0;
return;
}

int stacklength = this.aststack.length;
if (++this.astptr >= stacklength) {
system.arraycopy(
this.aststack, 0,
this.aststack = new object[stacklength + ast_stack_increment], 0,
stacklength);
this.astptr = stacklength;
}
this.aststack[this.astptr] = node;

if (newlength) {
stacklength = this.astlengthstack.length;
if (++this.astlengthptr >= stacklength) {
system.arraycopy(
this.astlengthstack, 0,
this.astlengthstack = new int[stacklength + ast_stack_increment], 0,
stacklength);
}
this.astlengthstack[this.astlengthptr] = 1;
} else {
this.astlengthstack[this.astlengthptr]++;
}
}

/*
* push a param name in ast node stack.
*/
protected abstract boolean pushparamname(boolean istypeparam);

/*
* push a reference statement in ast node stack.
*/
protected abstract boolean pushseeref(object statement);

/*
* push a text element in ast node stack
*/
protected void pushtext(int start, int end) {
// do not store text by default
}

/*
* push a throws type ref in ast node stack.
*/
protected abstract boolean pushthrowname(object typeref);

/*
* read current character and move index position.
* warning: scanner position is unchanged using this method!
*/
protected char readchar() {

char c = this.source[this.index++];
if (c == '\\' && this.source[this.index] == 'u') {
int c1, c2, c3, c4;
int pos = this.index;
this.index++;
while (this.source[this.index] == 'u')
this.index++;
if (!(((c1 = scannerhelper.getnumericvalue(this.source[this.index++])) > 15 || c1 < 0)
|| ((c2 = scannerhelper.getnumericvalue(this.source[this.index++])) > 15 || c2 < 0)
|| ((c3 = scannerhelper.getnumericvalue(this.source[this.index++])) > 15 || c3 < 0) || ((c4 = scannerhelper.getnumericvalue(this.source[this.index++])) > 15 || c4 < 0))) {
c = (char) (((c1 * 16 + c2) * 16 + c3) * 16 + c4);
} else {
// todo (frederic) currently reset to previous position, perhaps signal a syntax error would be more appropriate
this.index = pos;
}
}
return c;
}

/*
* read token only if previous was consumed
*/
protected int readtoken() throws invalidinputexception {
if (this.currenttokentype < 0) {
this.tokenpreviousposition = this.scanner.currentposition;
this.currenttokentype = this.scanner.getnexttoken();
if (this.scanner.currentposition > (this.lineend+1)) { // be sure to be on next line (lineend is still on the same line)
this.linestarted = false;
while (this.currenttokentype == terminaltokens.tokennamemultiply) {
this.currenttokentype = this.scanner.getnexttoken();
}
}
this.index = this.scanner.currentposition;
this.linestarted = true; // after having read a token, line is obviously started...
}
return this.currenttokentype;
}

protected int readtokenandconsume() throws invalidinputexception {
int token = readtoken();
consumetoken();
return token;
}

/*
* read token without throwing any invalidinputexception exception.
* returns terminaltokens.tokennameerror instead.
*/
protected int readtokensafely() {
int token = terminaltokens.tokennameerror;
try {
token = readtoken();
}
catch (invalidinputexception iie) {
// token is already set to error
}
return token;
}

protected void recordinheritedposition(long position) {
if (this.inheritedpositions == null) {
this.inheritedpositions = new long[inherited_positions_array_increment];
this.inheritedpositionsptr = 0;
} else {
if (this.inheritedpositionsptr == this.inheritedpositions.length) {
system.arraycopy(
this.inheritedpositions, 0,
this.inheritedpositions = new long[this.inheritedpositionsptr + inherited_positions_array_increment], 0,
this.inheritedpositionsptr);
}
}
this.inheritedpositions[this.inheritedpositionsptr++] = position;
}

/*
* refresh start position and length of an inline tag.
*/
protected void refreshinlinetagposition(int previousposition) {
// do nothing by default
}

/*
* refresh return statement
*/
protected void refreshreturnstatement() {
// do nothing by default
}

/**
* @@param started the inlinetagstarted to set
*/
protected void setinlinetagstarted(boolean started) {
this.inlinetagstarted = started;
}

/*
* entry point for recovery on invalid syntax
*/
protected object syntaxrecoverqualifiedname(int primitivetoken) throws invalidinputexception {
// do nothing, just an entry point for recovery
return null;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
int startpos = this.scanner.currentposition<this.index ? this.scanner.currentposition : this.index;
int endpos = this.scanner.currentposition<this.index ? this.index : this.scanner.currentposition;
if (startpos == this.source.length)
return "eof\n\n" + new string(this.source); //$non-nls-1$
if (endpos > this.source.length)
return "behind the eof\n\n" + new string(this.source); //$non-nls-1$

char front[] = new char[startpos];
system.arraycopy(this.source, 0, front, 0, startpos);

int middlelength = (endpos - 1) - startpos + 1;
char middle[];
if (middlelength > -1) {
middle = new char[middlelength];
system.arraycopy(
this.source,
startpos,
middle,
0,
middlelength);
} else {
middle = charoperation.no_char;
}

char end[] = new char[this.source.length - (endpos - 1)];
system.arraycopy(
this.source,
(endpos - 1) + 1,
end,
0,
this.source.length - (endpos - 1) - 1);

buffer.append(front);
if (this.scanner.currentposition<this.index) {
buffer.append("\n===============================\nscanner current position here -->"); //$non-nls-1$
} else {
buffer.append("\n===============================\nparser index here -->"); //$non-nls-1$
}
buffer.append(middle);
if (this.scanner.currentposition<this.index) {
buffer.append("<-- parser index here\n===============================\n"); //$non-nls-1$
} else {
buffer.append("<-- scanner current position here\n===============================\n"); //$non-nls-1$
}
buffer.append(end);

return buffer.tostring();
}

/*
* update
*/
protected abstract void updatedoccomment();

/*
* update line end
*/
protected void updatelineend() {
while (this.index > (this.lineend+1)) { // be sure to be on next line (lineend is still on the same line)
if (this.lineptr < this.lastlineptr) {
this.lineend = this.scanner.getlineend(++this.lineptr) - 1;
} else {
this.lineend = this.javadocend;
return;
}
}
}

/*
* verify that end of the line only contains space characters or end of comment.
* note that end of comment may be preceding by several contiguous '*' chars.
*/
protected boolean verifyendline(int textposition) {
boolean domparser = (this.kind & dom_parser) != 0;
// special case for inline tag
if (this.inlinetagstarted) {
// expecting closing brace
if (peekchar() == '}') {
if (domparser) {
createtag();
pushtext(textposition, this.starposition);
}
return true;
}
return false;
}

int startposition = this.index;
int previousposition = this.index;
this.starposition = -1;
char ch = readchar();
nextchar: while (true) {
switch (ch) {
case '\r':
case '\n':
if (domparser) {
createtag();
pushtext(textposition, previousposition);
}
this.index = previousposition;
return true;
case '\u000c' :	/* form feed               */
case ' ' :			/* space                   */
case '\t' :			/* horizontal tabulation   */
if (this.starposition >= 0) break nextchar;
break;
case '*':
this.starposition = previousposition;
break;
case '/':
if (this.starposition >= textposition) { // valid only if a star was the previous character
if (domparser) {
createtag();
pushtext(textposition, this.starposition);
}
return true;
}
break nextchar;
default :
// leave loop
break nextchar;

}
previousposition = this.index;
ch = readchar();
}
this.index = startposition;
return false;
}

/*
* verify characters after a name matches one of following conditions:
* 	1- first character is a white space
* 	2- first character is a closing brace *and* we're currently parsing an inline tag
* 	3- are the end of comment (several contiguous star ('*') characters may be
* 	    found before the last slash ('/') character).
*/
protected boolean verifyspaceorendcomment() {
this.starposition = -1;
int startposition = this.index;
// whitespace or inline tag closing brace
char ch = peekchar();
switch (ch) {
case '}':
return this.inlinetagstarted;
default:
if (scannerhelper.iswhitespace(ch)) {
return true;
}
}
// end of comment
int previousposition = this.index;
ch = readchar();
while (this.index<this.source.length) {
switch (ch) {
case '*':
// valid whatever the number of star before last '/'
this.starposition = previousposition;
break;
case '/':
if (this.starposition >= startposition) { // valid only if a star was the previous character
return true;
}
// $fall-through$ - fall through to invalid case
default :
// invalid whatever other character, even white spaces
this.index = startposition;
return false;

}
previousposition = this.index;
ch = readchar();
}
this.index = startposition;
return false;
}
}
