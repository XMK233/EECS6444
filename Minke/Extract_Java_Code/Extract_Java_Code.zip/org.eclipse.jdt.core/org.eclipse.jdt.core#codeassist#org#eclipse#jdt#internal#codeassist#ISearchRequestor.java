/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import org.eclipse.jdt.internal.compiler.env.accessrestriction;

/**
* this is the internal requestor passed to the searchable name environment
* so as to process the multiple search results as they are discovered.
*
* it is used to allow the code assist engine to add some more information
* to the raw name environment results before answering them to the ui.
*/
public interface isearchrequestor {
public void acceptconstructor(
int modifiers,
char[] simpletypename,
int parametercount,
char[] signature,
char[][] parametertypes,
char[][] parameternames,
int typemodifiers,
char[] packagename,
int extraflags,
string path,
accessrestriction access);
/**
* one result of the search consists of a new type.
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    nested type names are in the qualified form "a.i".
*    the default package is represented by an empty array.
*/
public void accepttype(char[] packagename, char[] typename, char[][] enclosingtypenames, int modifiers, accessrestriction accessrestriction);

//	/**
//	 * one result of the search consists of a new annotation.
//	 *
//	 * note - all package and type names are presented in their readable form:
//	 *    package names are in the form "a.b.c".
//	 *    nested type names are in the qualified form "a.i".
//	 *    the default package is represented by an empty array.
//	 */
//	public void acceptannotation(char[] packagename, char[] typename, int modifiers, accessrestriction accessrestriction);
//
//	/**
//	 * one result of the search consists of a new class.
//	 *
//	 * note - all package and type names are presented in their readable form:
//	 *    package names are in the form "a.b.c".
//	 *    nested type names are in the qualified form "a.m".
//	 *    the default package is represented by an empty array.
//	 */
//	public void acceptclass(char[] packagename, char[] typename, int modifiers, accessrestriction accessrestriction);
//
//	/**
//	 * one result of the search consists of a new enum.
//	 *
//	 * note - all package and type names are presented in their readable form:
//	 *    package names are in the form "a.b.c".
//	 *    nested type names are in the qualified form "a.i".
//	 *    the default package is represented by an empty array.
//	 */
//	public void acceptenum(char[] packagename, char[] typename, int modifiers, accessrestriction accessrestriction);
//
//	/**
//	 * one result of the search consists of a new interface.
//	 *
//	 * note - all package and type names are presented in their readable form:
//	 *    package names are in the form "a.b.c".
//	 *    nested type names are in the qualified form "a.i".
//	 *    the default package is represented by an empty array.
//	 */
//	public void acceptinterface(char[] packagename, char[] typename, int modifiers, accessrestriction accessrestriction);

/**
* one result of the search consists of a new package.
*
* note - all package names are presented in their readable form:
*    package names are in the form "a.b.c".
*    the default package is represented by an empty array.
*/
public void acceptpackage(char[] packagename);
}
