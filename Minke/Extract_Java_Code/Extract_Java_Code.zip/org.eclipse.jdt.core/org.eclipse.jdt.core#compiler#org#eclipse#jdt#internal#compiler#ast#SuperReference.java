/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class superreference extends thisreference {

public superreference(int sourcestart, int sourceend) {

super(sourcestart, sourceend);
}

public static explicitconstructorcall implicitsuperconstructorcall() {

return new explicitconstructorcall(explicitconstructorcall.implicitsuper);
}

public boolean isimplicitthis() {

return false;
}

public boolean issuper() {

return true;
}

public boolean isthis() {

return false ;
}

public stringbuffer printexpression(int indent, stringbuffer output){

return output.append("super"); //$non-nls-1$

}

public typebinding resolvetype(blockscope scope) {

this.constant = constant.notaconstant;
if (!checkaccess(scope.methodscope()))
return null;
referencebinding enclosingreceivertype = scope.enclosingreceivertype();
if (enclosingreceivertype.id == t_javalangobject) {
scope.problemreporter().cannotusesuperinjavalangobject(this);
return null;
}
return this.resolvedtype = enclosingreceivertype.superclass();
}

public void traverse(astvisitor visitor, blockscope blockscope) {
visitor.visit(this, blockscope);
visitor.endvisit(this, blockscope);
}
}
