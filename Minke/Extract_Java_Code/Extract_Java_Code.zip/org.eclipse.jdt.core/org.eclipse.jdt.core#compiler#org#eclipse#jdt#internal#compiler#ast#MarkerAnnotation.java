/*******************************************************************************
* copyright (c) 2005, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
/*
* created on 2004-03-11
*
* to change the template for this generated file go to
* window - preferences - java - code generation - code and comments
*/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class markerannotation extends annotation {

public markerannotation(typereference type, int sourcestart) {
this.type = type;
this.sourcestart = sourcestart;
this.sourceend = type.sourceend;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.annotation#membervaluepairs()
*/
public membervaluepair[] membervaluepairs() {
return novaluepairs;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.type != null) {
this.type.traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
