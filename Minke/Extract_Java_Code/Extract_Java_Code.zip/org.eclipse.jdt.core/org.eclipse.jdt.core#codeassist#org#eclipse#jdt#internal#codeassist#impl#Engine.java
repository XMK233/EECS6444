/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.impl;

import java.util.map;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.env.*;

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.*;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.core.namelookup;
import org.eclipse.jdt.internal.core.searchableenvironment;

public abstract class engine implements ityperequestor {

public lookupenvironment lookupenvironment;

protected compilationunitscope unitscope;
public searchableenvironment nameenvironment;

public assistoptions options;
public compileroptions compileroptions;
public boolean forbiddenreferenceiserror;
public boolean discouragedreferenceiserror;

public boolean importcachesinitialized = false;
public char[][][] importscache;
public importbinding[] ondemandimportscache;
public int importcachecount = 0;
public int ondemandimportcachecount = 0;
public char[] currentpackagename = null;

public engine(map settings){
this.options = new assistoptions(settings);
this.compileroptions = new compileroptions(settings);
this.forbiddenreferenceiserror =
(this.compileroptions.getseverity(compileroptions.forbiddenreference) & problemseverities.error) != 0;
this.discouragedreferenceiserror =
(this.compileroptions.getseverity(compileroptions.discouragedreference) & problemseverities.error) != 0;
}

/**
* add an additional binary type
*/
public void accept(ibinarytype binarytype, packagebinding packagebinding, accessrestriction accessrestriction) {
this.lookupenvironment.createbinarytypefrom(binarytype, packagebinding, accessrestriction);
}

/**
* add an additional compilation unit.
*/
public void accept(icompilationunit sourceunit, accessrestriction accessrestriction) {
compilationresult result = new compilationresult(sourceunit, 1, 1, this.compileroptions.maxproblemsperunit);

assistparser assistparser = getparser();
object parserstate = assistparser.becomesimpleparser();

compilationunitdeclaration parsedunit =
assistparser.dietparse(sourceunit, result);

assistparser.restoreassistparser(parserstate);

this.lookupenvironment.buildtypebindings(parsedunit, accessrestriction);
this.lookupenvironment.completetypebindings(parsedunit, true);
}

/**
* add additional source types (the first one is the requested type, the rest is formed by the
* secondary types defined in the same compilation unit).
*/
public void accept(isourcetype[] sourcetypes, packagebinding packagebinding, accessrestriction accessrestriction) {
compilationresult result =
new compilationresult(sourcetypes[0].getfilename(), 1, 1, this.compileroptions.maxproblemsperunit);
compilationunitdeclaration unit =
sourcetypeconverter.buildcompilationunit(
sourcetypes,//sourcetypes[0] is always toplevel here
sourcetypeconverter.field_and_method // need field and methods
| sourcetypeconverter.member_type, // need member types
// no need for field initialization
this.lookupenvironment.problemreporter,
result);

if (unit != null) {
this.lookupenvironment.buildtypebindings(unit, accessrestriction);
this.lookupenvironment.completetypebindings(unit, true);
}
}

public abstract assistparser getparser();

public void initializeimportcaches() {
if (this.currentpackagename == null) {
initializepackagecache();
}

importbinding[] importbindings = this.unitscope.imports;
int length = importbindings == null ? 0 : importbindings.length;

for (int i = 0; i < length; i++) {
importbinding importbinding = importbindings[i];
if(importbinding.ondemand) {
if(this.ondemandimportscache == null) {
this.ondemandimportscache = new importbinding[length - i];
}
this.ondemandimportscache[this.ondemandimportcachecount++] =
importbinding;
} else {
if(!(importbinding.resolvedimport instanceof methodbinding) ||
importbinding instanceof importconflictbinding) {
if(this.importscache == null) {
this.importscache = new char[length - i][][];
}
this.importscache[this.importcachecount++] = new char[][]{
importbinding.compoundname[importbinding.compoundname.length - 1],
charoperation.concatwith(importbinding.compoundname, '.')
};
}
}
}

this.importcachesinitialized = true;
}

public void initializepackagecache() {
if (this.unitscope.fpackage != null) {
this.currentpackagename = charoperation.concatwith(this.unitscope.fpackage.compoundname, '.');
} else if (this.unitscope.referencecontext != null &&
this.unitscope.referencecontext.currentpackage != null) {
this.currentpackagename = charoperation.concatwith(this.unitscope.referencecontext.currentpackage.tokens, '.');
} else {
this.currentpackagename = charoperation.no_char;
}
}

protected boolean mustqualifytype(
char[] packagename,
char[] typename,
char[] enclosingtypenames,
int modifiers) {

// if there are no types defined into the current cu yet.
if (this.unitscope == null)
return true;

if(!this.importcachesinitialized) {
initializeimportcaches();
}

for (int i = 0; i < this.importcachecount; i++) {
char[][] importname = this.importscache[i];
if(charoperation.equals(typename, importname[0])) {
char[] fullyqualifiedtypename =
enclosingtypenames == null || enclosingtypenames.length == 0
? charoperation.concat(
packagename,
typename,
'.')
: charoperation.concat(
charoperation.concat(
packagename,
enclosingtypenames,
'.'),
typename,
'.');
return !charoperation.equals(fullyqualifiedtypename, importname[1]);
}
}

if ((enclosingtypenames == null || enclosingtypenames.length == 0 ) && charoperation.equals(this.currentpackagename, packagename))
return false;

char[] fullyqualifiedenclosingtypename = null;

for (int i = 0; i < this.ondemandimportcachecount; i++) {
importbinding importbinding = this.ondemandimportscache[i];
binding resolvedimport = importbinding.resolvedimport;

char[][] importname = importbinding.compoundname;
char[] importflatname = charoperation.concatwith(importname, '.');

boolean isfound = false;
// resolvedimport is a referencebindng or a packagebinding
if(resolvedimport instanceof referencebinding) {
if(enclosingtypenames != null && enclosingtypenames.length != 0) {
if(fullyqualifiedenclosingtypename == null) {
fullyqualifiedenclosingtypename =
charoperation.concat(
packagename,
enclosingtypenames,
'.');
}
if(charoperation.equals(fullyqualifiedenclosingtypename, importflatname)) {
if(importbinding.isstatic()) {
isfound = (modifiers & classfileconstants.accstatic) != 0;
} else {
isfound = true;
}
}
}
} else {
if(enclosingtypenames == null || enclosingtypenames.length == 0) {
if(charoperation.equals(packagename, importflatname)) {
if(importbinding.isstatic()) {
isfound = (modifiers & classfileconstants.accstatic) != 0;
} else {
isfound = true;
}
}
}
}

// find potential conflict with another import
if(isfound) {
for (int j = 0; j < this.ondemandimportcachecount; j++) {
if(i != j) {
importbinding conflictingimportbinding = this.ondemandimportscache[j];
if(conflictingimportbinding.resolvedimport instanceof referencebinding) {
referencebinding refbinding =
(referencebinding) conflictingimportbinding.resolvedimport;
if (refbinding.getmembertype(typename) != null) {
return true;
}
} else {
char[] conflictingimportname =
charoperation.concatwith(conflictingimportbinding.compoundname, '.');

if (this.nameenvironment.namelookup.findtype(
string.valueof(typename),
string.valueof(conflictingimportname),
false,
namelookup.accept_all,
false/*don't check restrictions*/) != null) {
return true;
}
}
}
}
return false;
}
}
return true;
}

/*
* find the node (a field, a method or an initializer) at the given position
* and parse its block statements if it is a method or an initializer.
* returns the node or null if not found
*/
protected astnode parseblockstatements(compilationunitdeclaration unit, int position) {
int length = unit.types.length;
for (int i = 0; i < length; i++) {
typedeclaration type = unit.types[i];
if (type.declarationsourcestart < position
&& type.declarationsourceend >= position) {
getparser().scanner.setsource(unit.compilationresult);
return parseblockstatements(type, unit, position);
}
}
return null;
}

private astnode parseblockstatements(
typedeclaration type,
compilationunitdeclaration unit,
int position) {
//members
typedeclaration[] membertypes = type.membertypes;
if (membertypes != null) {
int length = membertypes.length;
for (int i = 0; i < length; i++) {
typedeclaration membertype = membertypes[i];
if (membertype.bodystart > position)
continue;
if (membertype.declarationsourceend >= position) {
return parseblockstatements(membertype, unit, position);
}
}
}
//methods
abstractmethoddeclaration[] methods = type.methods;
if (methods != null) {
int length = methods.length;
for (int i = 0; i < length; i++) {
abstractmethoddeclaration method = methods[i];
if (method.bodystart > position + 1)
continue;

if(method.isdefaultconstructor())
continue;

if (method.declarationsourceend >= position) {

getparser().parseblockstatements(method, unit);
return method;
}
}
}
//initializers
fielddeclaration[] fields = type.fields;
if (fields != null) {
int length = fields.length;
for (int i = 0; i < length; i++) {
fielddeclaration field = fields[i];
if (field.sourcestart > position)
continue;
if (field.declarationsourceend >= position) {
if (field instanceof initializer) {
getparser().parseblockstatements((initializer)field, type, unit);
}
return field;
}
}
}
return null;
}

protected void reset(boolean resetlookupenvironment) {
if (resetlookupenvironment) this.lookupenvironment.reset();
}

public static char[] gettypesignature(typebinding typebinding) {
char[] result = typebinding.signature();
if (result != null) {
result = charoperation.replaceoncopy(result, '/', '.');
}
return result;
}

public static char[] getsignature(methodbinding methodbinding) {
char[] result = null;

int oldmod = methodbinding.modifiers;
//todo remove the next line when method from binary type will be able to generate generic signature
methodbinding.modifiers |= extracompilermodifiers.accgenericsignature;
result = methodbinding.genericsignature();
if(result == null) {
result = methodbinding.signature();
}
methodbinding.modifiers = oldmod;

if (result != null) {
result = charoperation.replaceoncopy(result, '/', '.');
}
return result;
}

public static char[] getsignature(typebinding typebinding) {
char[] result = null;

result = typebinding.generictypesignature();

if (result != null) {
result = charoperation.replaceoncopy(result, '/', '.');
}
return result;
}
}
