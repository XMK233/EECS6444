/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import java.util.arraylist;
import java.util.locale;
import java.util.map;

import org.eclipse.core.runtime.iprogressmonitor;
import org.eclipse.core.runtime.operationcanceledexception;
import org.eclipse.jdt.core.completioncontext;
import org.eclipse.jdt.core.completionflags;
import org.eclipse.jdt.core.completionproposal;
import org.eclipse.jdt.core.completionrequestor;
import org.eclipse.jdt.core.flags;
import org.eclipse.jdt.core.iaccessrule;
import org.eclipse.jdt.core.ijavaproject;
import org.eclipse.jdt.core.imethod;
import org.eclipse.jdt.core.itype;
import org.eclipse.jdt.core.ityperoot;
import org.eclipse.jdt.core.javamodelexception;
import org.eclipse.jdt.core.signature;
import org.eclipse.jdt.core.workingcopyowner;
import org.eclipse.jdt.core.compiler.categorizedproblem;
import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.iproblem;
import org.eclipse.jdt.core.search.ijavasearchconstants;

import org.eclipse.jdt.internal.codeassist.complete.*;
import org.eclipse.jdt.internal.codeassist.impl.assistparser;
import org.eclipse.jdt.internal.codeassist.impl.engine;
import org.eclipse.jdt.internal.codeassist.impl.keywords;
import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.defaulterrorhandlingpolicies;
import org.eclipse.jdt.internal.compiler.extraflags;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.env.*;
import org.eclipse.jdt.internal.compiler.impl.referencecontext;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.scannerhelper;
import org.eclipse.jdt.internal.compiler.parser.sourcetypeconverter;
import org.eclipse.jdt.internal.compiler.parser.javadoctagconstants;
import org.eclipse.jdt.internal.compiler.parser.terminaltokens;
import org.eclipse.jdt.internal.compiler.problem.abortcompilation;
import org.eclipse.jdt.internal.compiler.problem.defaultproblemfactory;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;
import org.eclipse.jdt.internal.compiler.util.suffixconstants;
import org.eclipse.jdt.internal.compiler.util.hashtableofobject;
import org.eclipse.jdt.internal.compiler.util.objectvector;
import org.eclipse.jdt.internal.core.basiccompilationunit;
import org.eclipse.jdt.internal.core.inamingrequestor;
import org.eclipse.jdt.internal.core.internalnamingconventions;
import org.eclipse.jdt.internal.core.javamodelmanager;
import org.eclipse.jdt.internal.core.sourcemethod;
import org.eclipse.jdt.internal.core.sourcemethodelementinfo;
import org.eclipse.jdt.internal.core.sourcetype;
import org.eclipse.jdt.internal.core.binarytypeconverter;
import org.eclipse.jdt.internal.core.searchableenvironment;
import org.eclipse.jdt.internal.core.sourcetypeelementinfo;
import org.eclipse.jdt.internal.core.search.matching.javasearchnameenvironment;
import org.eclipse.jdt.internal.core.util.messages;

/**
* this class is the entry point for source completions.
* it contains two public apis used to call codeassist on a given source with
* a given environment, assisting position and storage (and possibly options).
*/
public final class completionengine
extends engine
implements isearchrequestor, typeconstants , terminaltokens , relevanceconstants, suffixconstants {

private static class acceptedconstructor {
public int modifiers;
public char[] simpletypename;
public int parametercount;
public char[] signature;
public char[][] parametertypes;
public char[][] parameternames;
public int typemodifiers;
public char[] packagename;
public int extraflags;
public int accessibility;
public boolean proposetype = false;
public boolean proposeconstructor = false;
public char[] fullyqualifiedname = null;

public boolean mustbequalified = false;

public acceptedconstructor(
int modifiers,
char[] simpletypename,
int parametercount,
char[] signature,
char[][] parametertypes,
char[][] parameternames,
int typemodifiers,
char[] packagename,
int extraflags,
int accessibility) {
this.modifiers = modifiers;
this.simpletypename = simpletypename;
this.parametercount = parametercount;
this.signature = signature;
this.parametertypes = parametertypes;
this.parameternames = parameternames;
this.typemodifiers = typemodifiers;
this.packagename = packagename;
this.extraflags = extraflags;
this.accessibility = accessibility;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append('{');
buffer.append(this.packagename);
buffer.append(',');
buffer.append(this.simpletypename);
buffer.append('}');
return buffer.tostring();
}
}

private static class acceptedtype {
public char[] packagename;
public char[] simpletypename;
public char[][] enclosingtypenames;
public int modifiers;
public int accessibility;
public boolean mustbequalified = false;

public char[] fullyqualifiedname = null;
public char[] qualifiedtypename = null;
public acceptedtype(
char[] packagename,
char[] simpletypename,
char[][] enclosingtypenames,
int modifiers,
int accessibility) {
this.packagename = packagename;
this.simpletypename = simpletypename;
this.enclosingtypenames = enclosingtypenames;
this.modifiers = modifiers;
this.accessibility = accessibility;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append('{');
buffer.append(this.packagename);
buffer.append(',');
buffer.append(this.simpletypename);
buffer.append(',');
buffer.append(charoperation.concatwith(this.enclosingtypenames, '.'));
buffer.append('}');
return buffer.tostring();
}
}

public class completionproblemfactory extends defaultproblemfactory {
private int lasterrorstart;

private boolean checkproblems = false;
public boolean hasforbiddenproblems = false;
public boolean hasallowedproblems = false;

public completionproblemfactory(locale loc) {
super(loc);
}

private categorizedproblem checkproblem(categorizedproblem pb,
char[] originatingfilename,	int severity, int start) {
int id = pb.getid();
if (completionengine.this.actualcompletionposition > start
&& this.lasterrorstart < start
&& pb.iserror()
&& (id & iproblem.syntax) == 0
&& (completionengine.this.filename == null || charoperation.equals(completionengine.this.filename, originatingfilename))) {

completionengine.this.problem = pb;
this.lasterrorstart = start;
}
if (this.checkproblems && !this.hasforbiddenproblems) {
switch (id) {
case iproblem.usingdeprecatedtype:
this.hasforbiddenproblems =
completionengine.this.options.checkdeprecation;
break;
case iproblem.notvisibletype:
this.hasforbiddenproblems =
completionengine.this.options.checkvisibility;
break;
case iproblem.forbiddenreference:
this.hasforbiddenproblems =
completionengine.this.options.checkforbiddenreference;
break;
case iproblem.discouragedreference:
this.hasforbiddenproblems =
completionengine.this.options.checkdiscouragedreference;
break;
default:
if ((severity & problemseverities.optional) != 0) {
this.hasallowedproblems = true;
} else {
this.hasforbiddenproblems = true;
}

break;
}
}

return pb;
}

public categorizedproblem createproblem(
char[] originatingfilename,
int problemid,
string[] problemarguments,
int elaborationid,
string[] messagearguments,
int severity,
int start,
int end,
int linenumber,
int columnnumber) {
return checkproblem(
super.createproblem(
originatingfilename,
problemid,
problemarguments,
elaborationid,
messagearguments,
severity,
start,
end,
linenumber,
columnnumber), originatingfilename, severity, start);
}

public categorizedproblem createproblem(
char[] originatingfilename,
int problemid,
string[] problemarguments,
string[] messagearguments,
int severity,
int start,
int end,
int linenumber,
int columnnumber) {
return checkproblem(
super.createproblem(
originatingfilename,
problemid,
problemarguments,
messagearguments,
severity,
start,
end,
linenumber,
columnnumber), originatingfilename, severity, start);
}

public void startcheckingproblems() {
this.checkproblems = true;
this.hasforbiddenproblems = false;
this.hasallowedproblems = false;
}

public void stopcheckingproblems() {
this.checkproblems = false;
}
}

public static char[] createbindingkey(char[] packagename, char[] typename) {
char[] signature = createtypesignature(packagename, typename);
charoperation.replace(signature, '.', '/');
return signature;
}

public static char[][] createdefaultparameternames(int length) {
char[][] parameters;
switch (length) {
case 0 :
parameters = new char[length][];
break;
case 1 :
parameters = args1;
break;
case 2 :
parameters = args2;
break;
case 3 :
parameters = args3;
break;
case 4 :
parameters = args4;
break;
default :
parameters = new char[length][];
for (int i = 0; i < length; i++) {
parameters[i] = charoperation.concat(arg, string.valueof(i).tochararray());
}
break;
}
return parameters;
}
public static char[] createmethodsignature(char[][] parameterpackagenames, char[][] parametertypenames, char[] returntypesignature) {
char[][] parametertypesignature = new char[parametertypenames.length][];
for (int i = 0; i < parametertypesignature.length; i++) {
parametertypesignature[i] =
signature.createchararraytypesignature(
charoperation.concat(
parameterpackagenames[i],
charoperation.replaceoncopy(parametertypenames[i], '.', '$'), '.'), true);
}

return signature.createmethodsignature(
parametertypesignature,
returntypesignature);
}

public static char[] createmethodsignature(char[][] parameterpackagenames, char[][] parametertypenames, char[] returnpackagename, char[] returntypename) {
char[] returntypesignature =
returntypename == null || returntypename.length == 0
? signature.createchararraytypesignature(void, true)
: signature.createchararraytypesignature(
charoperation.concat(
returnpackagename,
charoperation.replaceoncopy(returntypename, '.', '$'), '.'), true);

return createmethodsignature(
parameterpackagenames,
parametertypenames,
returntypesignature);
}
public static char[] createnongenerictypesignature(char[] qualifiedpackagename, char[] qualifiedtypename) {
return signature.createchararraytypesignature(
charoperation.concat(
qualifiedpackagename,
charoperation.replaceoncopy(qualifiedtypename, '.', '$'), '.'), true);
}

public static char[] createtypesignature(char[] qualifiedpackagename, char[] qualifiedtypename) {
char[] name = new char[qualifiedtypename.length];
system.arraycopy(qualifiedtypename, 0, name, 0, qualifiedtypename.length);

int depth = 0;
int length = name.length;
for (int i = length -1; i >= 0; i--) {
switch (name[i]) {
case '.':
if (depth == 0 && name[i - 1] != '>') {
name[i] = '$';
}
break;
case '<':
depth--;
break;
case '>':
depth++;
break;
}
}
return signature.createchararraytypesignature(
charoperation.concat(
qualifiedpackagename,
name, '.'), true);
}

private static char[] getrequiredtypesignature(typebinding typebinding) {
char[] result = null;
stringbuffer sig = new stringbuffer(10);

sig.append(typebinding.signature());

int siglength = sig.length();
result = new char[siglength];
sig.getchars(0, siglength, result, 0);
result = charoperation.replaceoncopy(result, '/', '.');
return result;
}

private static char[] gettypename(typereference typereference) {
char[] typename = charoperation.concatwith(typereference.gettypename(), '.');
int dims = typereference.dimensions();
if (dims > 0) {
int length = typename.length;
int newlength = length + (dims*2);
system.arraycopy(typename, 0, typename = new char[newlength], 0, length);
for (int k = length; k < newlength; k += 2) {
typename[k] = '[';
typename[k+1] = ']';
}
}

return typename;
}

private static boolean hasstaticmembertypes(referencebinding typebinding, sourcetypebinding invocationtype, compilationunitscope unitscope) {
referencebinding[] membertypes = typebinding.membertypes();
int length = membertypes == null ? 0 : membertypes.length;
next : for (int i = 0; i < length; i++) {
referencebinding membertype = membertypes[i];
if (invocationtype != null && !membertype.canbeseenby(typebinding, invocationtype)) {
continue next;
} else if(invocationtype == null && !membertype.canbeseenby(unitscope.fpackage)) {
continue next;
}

if ((membertype.modifiers & classfileconstants.accstatic) != 0) {
return true;
}
}
return false;
}

private static boolean hasmembertypesinenclosingscope(sourcetypebinding typebinding, scope scope) {
referencebinding[] membertypes = typebinding.membertypes();
int length = membertypes == null ? 0 : membertypes.length;

if (length > 0) {
methodscope methodscope = scope.methodscope();
if (methodscope != null && !methodscope.isstatic) {
classscope classscope = typebinding.scope;
scope currentscope = scope;
while (currentscope != null) {
if (currentscope == classscope) {
return true;
}
currentscope = currentscope.parent;
}
}
}
return false;
}

public hashtableofobject typecache;
public int openedbinarytypes; // used during internalcompletionproposal#findconstructorparameternames()

public static boolean debug = false;
public static boolean perf = false;

private static final char[] known_type_with_unknown_constructors = new char[]{};
private static final char[] known_type_with_known_constructors = new char[]{};

private static final char[] arg = "arg".tochararray();  //$non-nls-1$
private static final char[] arg0 = "arg0".tochararray();  //$non-nls-1$
private static final char[] arg1 = "arg1".tochararray();  //$non-nls-1$
private static final char[] arg2 = "arg2".tochararray();  //$non-nls-1$
private static final char[] arg3 = "arg3".tochararray();  //$non-nls-1$
private static final char[][] args1 = new char[][]{arg0};
private static final char[][] args2 = new char[][]{arg0, arg1};
private static final char[][] args3 = new char[][]{arg0, arg1, arg2};
private static final char[][] args4 = new char[][]{arg0, arg1, arg2, arg3};

private final static int check_cancel_frequency = 50;

// temporary constants to quickly disabled polish features if necessary
public final static boolean no_type_completion_on_empty_token = false;

private final static char[] error_pattern = "*error*".tochararray();  //$non-nls-1$
private final static char[] exception_pattern = "*exception*".tochararray();  //$non-nls-1$
private final static char[] semicolon = new char[] { ';' };

private final static char[] class = "class".tochararray();  //$non-nls-1$
private final static char[] void = "void".tochararray();  //$non-nls-1$
private final static char[] int = "int".tochararray();  //$non-nls-1$
private final static char[] int_signature = new char[]{signature.c_int};
private final static char[] value = "value".tochararray();  //$non-nls-1$
private final static char[] extends = "extends".tochararray();  //$non-nls-1$
private final static char[] super = "super".tochararray();  //$non-nls-1$
private final static char[] default_constructor_signature = "()v".tochararray();  //$non-nls-1$

private final static char[] dot = ".".tochararray();  //$non-nls-1$

private final static char[] varargs = "...".tochararray();  //$non-nls-1$

private final static char[] import = "import".tochararray();  //$non-nls-1$
private final static char[] static = "static".tochararray();  //$non-nls-1$
private final static char[] on_demand = ".*".tochararray();  //$non-nls-1$
private final static char[] import_end = ";\n".tochararray();  //$non-nls-1$

private final static char[] java_lang_object_signature =
createtypesignature(charoperation.concatwith(java_lang, '.'), object);
private final static char[] java_lang_name =
charoperation.concatwith(java_lang, '.');

private final static int none = 0;
private final static int supertype = 1;
private final static int subtype = 2;

int expectedtypesptr = -1;
typebinding[] expectedtypes = new typebinding[1];
int expectedtypesfilter;
boolean hasjavalangobjectasexpectedtype = false;
boolean hasexpectedarraytypes = false;
boolean hascomputedexpectedarraytypes = false;
int uninterestingbindingsptr = -1;
binding[] uninterestingbindings = new binding[1];
int forbbidenbindingsptr = -1;
binding[] forbbidenbindings = new binding[1];
int forbbidenbindingsfilter;

importbinding[] favoritereferencebindings;

boolean assistnodeisclass;
boolean assistnodeisenum;
boolean assistnodeisexception;
boolean assistnodeisinterface;
boolean assistnodeisannotation;
boolean assistnodeisconstructor;
boolean assistnodeissupertype;
boolean assistnodeisextendedtype;
int  assistnodeinjavadoc = 0;
boolean assistnodecanbesinglememberannotation = false;

long targetedelement;

workingcopyowner owner;
iprogressmonitor monitor;
ijavaproject javaproject;
ityperoot typeroot;
completionparser parser;
completionrequestor requestor;
completionproblemfactory problemfactory;
problemreporter problemreporter;
private javasearchnameenvironment nocachenameenvironment;
char[] source;
char[] completiontoken;
char[] qualifiedcompletiontoken;
boolean resolvingimports = false;
boolean resolvingstaticimports = false;
boolean insidequalifiedreference = false;
boolean noproposal = true;
categorizedproblem problem = null;
char[] filename = null;
int startposition, actualcompletionposition, endposition, offset;
int tokenstart, tokenend;
int javadoctagposition; // position of previous tag while completing in javadoc
hashtableofobject knownpkgs = new hashtableofobject(10);
hashtableofobject knowntypes = new hashtableofobject(10);

/*
static final char[][] maindeclarations =
new char[][] {
"package".tochararray(),
"import".tochararray(),
"abstract".tochararray(),
"final".tochararray(),
"public".tochararray(),
"class".tochararray(),
"interface".tochararray()};

static final char[][] modifiers = // may want field, method, type & member type modifiers
new char[][] {
"abstract".tochararray(),
"final".tochararray(),
"native".tochararray(),
"public".tochararray(),
"protected".tochararray(),
"private".tochararray(),
"static".tochararray(),
"strictfp".tochararray(),
"synchronized".tochararray(),
"transient".tochararray(),
"volatile".tochararray()};
*/
static final basetypebinding[] base_types = {
typebinding.boolean,
typebinding.byte,
typebinding.char,
typebinding.double,
typebinding.float,
typebinding.int,
typebinding.long,
typebinding.short,
typebinding.void
};
static final int base_types_length = base_types.length;
static final char[][] base_type_names = new char[base_types_length][];
static final int base_types_without_void_length = base_types.length - 1;
static final char[][] base_type_names_without_void = new char[base_types_without_void_length][];
static {
for (int i=0; i<base_types_length; i++) {
base_type_names[i] = base_types[i].simplename;
}
for (int i=0; i<base_types_without_void_length; i++) {
base_type_names_without_void[i] = base_types[i].simplename;
}
}

static final char[] classfield = "class".tochararray();  //$non-nls-1$
static final char[] lengthfield = "length".tochararray();  //$non-nls-1$
static final char[] clonemethod = "clone".tochararray();  //$non-nls-1$
static final char[] this = "this".tochararray();  //$non-nls-1$
static final char[] throws = "throws".tochararray();  //$non-nls-1$

static invocationsite fakeinvocationsite = new invocationsite(){
public typebinding[] generictypearguments() { return null; }
public boolean issuperaccess(){ return false; }
public boolean istypeaccess(){ return false; }
public void setactualreceivertype(referencebinding receivertype) {/* empty */}
public void setdepth(int depth){/* empty */}
public void setfieldindex(int depth){/* empty */}
public int sourceend() { return 0; 	}
public int sourcestart() { return 0; 	}
};

private int foundtypescount;
private objectvector acceptedtypes;

private int foundconstructorscount;
private objectvector acceptedconstructors;

/**
* the completionengine is responsible for computing source completions.
*
* it requires a searchable name environment, which supports some
* specific search apis, and a requestor to feed back the results to a ui.
*
*  @@param nameenvironment org.eclipse.jdt.internal.codeassist.isearchablenameenvironment
*      used to resolve type/package references and search for types/packages
*      based on partial names.
*
*  @@param requestor org.eclipse.jdt.internal.codeassist.icompletionrequestor
*      since the engine might produce answers of various forms, the engine
*      is associated with a requestor able to accept all possible completions.
*
*  @@param settings java.util.map
*		set of options used to configure the code assist engine.
*/
public completionengine(
searchableenvironment nameenvironment,
completionrequestor requestor,
map settings,
ijavaproject javaproject,
workingcopyowner owner,
iprogressmonitor monitor) {
super(settings);
this.javaproject = javaproject;
this.requestor = requestor;
this.nameenvironment = nameenvironment;
this.typecache = new hashtableofobject(5);
this.openedbinarytypes = 0;

this.problemfactory = new completionproblemfactory(locale.getdefault());
this.problemreporter = new problemreporter(
defaulterrorhandlingpolicies.proceedwithallproblems(),
this.compileroptions,
this.problemfactory);
this.lookupenvironment =
new lookupenvironment(this, this.compileroptions, this.problemreporter, nameenvironment);
this.parser =
new completionparser(this.problemreporter, this.requestor.isextendedcontextrequired());
this.owner = owner;
this.monitor = monitor;
}

public void acceptconstructor(
int modifiers,
char[] simpletypename,
int parametercount,
char[] signature,
char[][] parametertypes,
char[][] parameternames,
int typemodifiers,
char[] packagename,
int extraflags,
string path,
accessrestriction accessrestriction) {

// does not check cancellation for every types to avoid performance loss
if ((this.foundconstructorscount % (check_cancel_frequency)) == 0) checkcancel();
this.foundconstructorscount++;

if ((typemodifiers & classfileconstants.accenum) != 0) return;

if (this.options.checkdeprecation && (typemodifiers & classfileconstants.accdeprecated) != 0) return;

if (this.options.checkvisibility) {
if((typemodifiers & classfileconstants.accpublic) == 0) {
if((typemodifiers & classfileconstants.accprivate) != 0) return;

if (this.currentpackagename == null) {
initializepackagecache();
}

if(!charoperation.equals(packagename, this.currentpackagename)) return;
}
}

int accessibility = iaccessrule.k_accessible;
if(accessrestriction != null) {
switch (accessrestriction.getproblemid()) {
case iproblem.forbiddenreference:
if (this.options.checkforbiddenreference) {
return;
}
accessibility = iaccessrule.k_non_accessible;
break;
case iproblem.discouragedreference:
if (this.options.checkdiscouragedreference) {
return;
}
accessibility = iaccessrule.k_discouraged;
break;
}
}

if(this.acceptedconstructors == null) {
this.acceptedconstructors = new objectvector();
}
this.acceptedconstructors.add(
new acceptedconstructor(
modifiers,
simpletypename,
parametercount,
signature,
parametertypes,
parameternames,
typemodifiers,
packagename,
extraflags,
accessibility));
}

private void acceptconstructors(scope scope) {
final boolean defer_qualified_proposals = false;

this.checkcancel();

if(this.acceptedconstructors == null) return;

int length = this.acceptedconstructors.size();

if(length == 0) return;

hashtableofobject ondemandfound = new hashtableofobject();

arraylist deferredproposals = null;
if (defer_qualified_proposals) {
deferredproposals = new arraylist();
}

try {
next : for (int i = 0; i < length; i++) {

// does not check cancellation for every types to avoid performance loss
if ((i % check_cancel_frequency) == 0) checkcancel();

acceptedconstructor acceptedconstructor = (acceptedconstructor)this.acceptedconstructors.elementat(i);
final int typemodifiers = acceptedconstructor.typemodifiers;
final char[] packagename = acceptedconstructor.packagename;
final char[] simpletypename = acceptedconstructor.simpletypename;
final int modifiers = acceptedconstructor.modifiers;
final int parametercount = acceptedconstructor.parametercount;
final char[] signature = acceptedconstructor.signature;
final char[][] parametertypes = acceptedconstructor.parametertypes;
final char[][] parameternames = acceptedconstructor.parameternames;
final int extraflags = acceptedconstructor.extraflags;
final int accessibility = acceptedconstructor.accessibility;

boolean proposetype = hasarraytypeasexpectedsupertypes() || (extraflags & extraflags.hasnonprivatestaticmembertypes) != 0;

char[] fullyqualifiedname = charoperation.concat(packagename, simpletypename, '.');

object knowntypekind = this.knowntypes.get(fullyqualifiedname);
if (knowntypekind != null) {
if (knowntypekind == known_type_with_known_constructors) {
// the type and its constructors are already accepted
continue next;
}
// this type is already accepted
proposetype = false;
} else {
this.knowntypes.put(fullyqualifiedname, known_type_with_unknown_constructors);
}

boolean proposeconstructor = true;

if (this.options.checkvisibility) {
if((modifiers & classfileconstants.accpublic) == 0) {
if((modifiers & classfileconstants.accprivate) != 0) {
if (!proposetype) continue next;
proposeconstructor = false;
} else {
if (this.currentpackagename == null) {
initializepackagecache();
}

if(!charoperation.equals(packagename, this.currentpackagename)) {

if((typemodifiers & classfileconstants.accabstract) == 0 ||
(modifiers & classfileconstants.accprotected) == 0) {
if (!proposetype) continue next;
proposeconstructor = false;
}
}
}
}
}

acceptedconstructor.fullyqualifiedname = fullyqualifiedname;
acceptedconstructor.proposetype = proposetype;
acceptedconstructor.proposeconstructor = proposeconstructor;


if(!this.importcachesinitialized) {
initializeimportcaches();
}

for (int j = 0; j < this.importcachecount; j++) {
char[][] importname = this.importscache[j];
if(charoperation.equals(simpletypename, importname[0])) {
if (proposetype) {
proposetype(
packagename,
simpletypename,
typemodifiers,
accessibility,
simpletypename,
fullyqualifiedname,
!charoperation.equals(fullyqualifiedname, importname[1]),
scope);
}

if (proposeconstructor && !flags.isenum(typemodifiers)) {
boolean isqualified = !charoperation.equals(fullyqualifiedname, importname[1]);
if (!isqualified) {
proposeconstructor(
simpletypename,
parametercount,
signature,
parametertypes,
parameternames,
modifiers,
packagename,
typemodifiers,
accessibility,
simpletypename,
fullyqualifiedname,
isqualified,
scope,
extraflags);
} else {
acceptedconstructor.mustbequalified = true;
if (defer_qualified_proposals) {
deferredproposals.add(acceptedconstructor);
} else {
proposeconstructor(acceptedconstructor, scope);
}
}
}
continue next;
}
}


if (charoperation.equals(this.currentpackagename, packagename)) {
if (proposetype) {
proposetype(
packagename,
simpletypename,
typemodifiers,
accessibility,
simpletypename,
fullyqualifiedname,
false,
scope);
}

if (proposeconstructor && !flags.isenum(typemodifiers)) {
proposeconstructor(
simpletypename,
parametercount,
signature,
parametertypes,
parameternames,
modifiers,
packagename,
typemodifiers,
accessibility,
simpletypename,
fullyqualifiedname,
false,
scope,
extraflags);
}
continue next;
} else {
char[] fullyqualifiedenclosingtypeorpackagename = null;

acceptedconstructor foundconstructor = null;
if((foundconstructor = (acceptedconstructor)ondemandfound.get(simpletypename)) == null) {
for (int j = 0; j < this.ondemandimportcachecount; j++) {
importbinding importbinding = this.ondemandimportscache[j];

char[][] importname = importbinding.compoundname;
char[] importflatname = charoperation.concatwith(importname, '.');

if(fullyqualifiedenclosingtypeorpackagename == null) {
fullyqualifiedenclosingtypeorpackagename = packagename;
}
if(charoperation.equals(fullyqualifiedenclosingtypeorpackagename, importflatname)) {
if(importbinding.isstatic()) {
if((typemodifiers & classfileconstants.accstatic) != 0) {
ondemandfound.put(
simpletypename,
acceptedconstructor);
continue next;
}
} else {
ondemandfound.put(
simpletypename,
acceptedconstructor);
continue next;
}
}
}
} else if(!foundconstructor.mustbequalified){
done : for (int j = 0; j < this.ondemandimportcachecount; j++) {
importbinding importbinding = this.ondemandimportscache[j];

char[][] importname = importbinding.compoundname;
char[] importflatname = charoperation.concatwith(importname, '.');

if(fullyqualifiedenclosingtypeorpackagename == null) {
fullyqualifiedenclosingtypeorpackagename = packagename;
}
if(charoperation.equals(fullyqualifiedenclosingtypeorpackagename, importflatname)) {
if(importbinding.isstatic()) {
if((typemodifiers & classfileconstants.accstatic) != 0) {
foundconstructor.mustbequalified = true;
break done;
}
} else {
foundconstructor.mustbequalified = true;
break done;
}
}
}
}
if (proposetype) {
proposetype(
packagename,
simpletypename,
typemodifiers,
accessibility,
simpletypename,
fullyqualifiedname,
true,
scope);
}

if (proposeconstructor && !flags.isenum(typemodifiers)) {
acceptedconstructor.mustbequalified = true;
if (defer_qualified_proposals) {
deferredproposals.add(acceptedconstructor);
} else {
proposeconstructor(acceptedconstructor, scope);
}
}
}
}

char[][] keys = ondemandfound.keytable;
object[] values = ondemandfound.valuetable;
int max = keys.length;
for (int i = 0; i < max; i++) {

// does not check cancellation for every types to avoid performance loss
if ((i % check_cancel_frequency) == 0) checkcancel();

if(keys[i] != null) {
acceptedconstructor value = (acceptedconstructor) values[i];
if(value != null) {
if (value.proposetype) {
proposetype(
value.packagename,
value.simpletypename,
value.typemodifiers,
value.accessibility,
value.simpletypename,
value.fullyqualifiedname,
value.mustbequalified,
scope);
}

if (value.proposeconstructor && !flags.isenum(value.modifiers)) {
if (!value.mustbequalified) {
proposeconstructor(
value.simpletypename,
value.parametercount,
value.signature,
value.parametertypes,
value.parameternames,
value.modifiers,
value.packagename,
value.typemodifiers,
value.accessibility,
value.simpletypename,
value.fullyqualifiedname,
value.mustbequalified,
scope,
value.extraflags);
} else {
if (defer_qualified_proposals) {
deferredproposals.add(value);
} else {
proposeconstructor(value, scope);
}
}
}
}
}
}

if (defer_qualified_proposals) {
int size = deferredproposals.size();
for (int i = 0; i < size; i++) {

// does not check cancellation for every types to avoid performance loss
if ((i % check_cancel_frequency) == 0) checkcancel();

acceptedconstructor deferredproposal = (acceptedconstructor)deferredproposals.get(i);

if (deferredproposal.proposeconstructor) {
proposeconstructor(
deferredproposal.simpletypename,
deferredproposal.parametercount,
deferredproposal.signature,
deferredproposal.parametertypes,
deferredproposal.parameternames,
deferredproposal.modifiers,
deferredproposal.packagename,
deferredproposal.typemodifiers,
deferredproposal.accessibility,
deferredproposal.simpletypename,
deferredproposal.fullyqualifiedname,
deferredproposal.mustbequalified,
scope,
deferredproposal.extraflags);
}
}
}
} finally {
this.acceptedtypes = null; // reset
}
}

/**
* one result of the search consists of a new package.
*
* note - all package names are presented in their readable form:
*    package names are in the form "a.b.c".
*    the default package is represented by an empty array.
*/
public void acceptpackage(char[] packagename) {

if (this.knownpkgs.containskey(packagename)) return;

this.knownpkgs.put(packagename, this);

char[] completion;
if(this.resolvingimports) {
if(this.resolvingstaticimports) {
completion = charoperation.concat(packagename, new char[] { '.' });
} else {
completion = charoperation.concat(packagename, new char[] { '.', '*', ';' });
}
} else {
completion = packagename;
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(this.qualifiedcompletiontoken == null ? this.completiontoken : this.qualifiedcompletiontoken, packagename);
if(!this.resolvingimports) {
relevance += computerelevanceforqualification(true);
}
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.package_ref)) {
internalcompletionproposal proposal = createproposal(completionproposal.package_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(packagename);
proposal.setpackagename(packagename);
proposal.setcompletion(completion);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}

/**
* one result of the search consists of a new type.
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    nested type names are in the qualified form "a.i".
*    the default package is represented by an empty array.
*/
public void accepttype(
char[] packagename,
char[] simpletypename,
char[][] enclosingtypenames,
int modifiers,
accessrestriction accessrestriction) {

// does not check cancellation for every types to avoid performance loss
if ((this.foundtypescount % check_cancel_frequency) == 0) checkcancel();
this.foundtypescount++;

if (this.options.checkdeprecation && (modifiers & classfileconstants.accdeprecated) != 0) return;
if (this.assistnodeisextendedtype && (modifiers & classfileconstants.accfinal) != 0) return;

if (this.options.checkvisibility) {
if((modifiers & classfileconstants.accpublic) == 0) {
if((modifiers & classfileconstants.accprivate) != 0) return;

char[] currentpackage = charoperation.concatwith(this.unitscope.fpackage.compoundname, '.');
if(!charoperation.equals(packagename, currentpackage)) return;
}
}

int accessibility = iaccessrule.k_accessible;
if(accessrestriction != null) {
switch (accessrestriction.getproblemid()) {
case iproblem.forbiddenreference:
if (this.options.checkforbiddenreference) {
return;
}
accessibility = iaccessrule.k_non_accessible;
break;
case iproblem.discouragedreference:
if (this.options.checkdiscouragedreference) {
return;
}
accessibility = iaccessrule.k_discouraged;
break;
}
}

if (isforbiddentype(packagename, simpletypename, enclosingtypenames)) {
return;
}

if(this.acceptedtypes == null) {
this.acceptedtypes = new objectvector();
}
this.acceptedtypes.add(new acceptedtype(packagename, simpletypename, enclosingtypenames, modifiers, accessibility));
}

private void accepttypes(scope scope) {
this.checkcancel();

if(this.acceptedtypes == null) return;

int length = this.acceptedtypes.size();

if(length == 0) return;

hashtableofobject ondemandfound = new hashtableofobject();

try {
next : for (int i = 0; i < length; i++) {

// does not check cancellation for every types to avoid performance loss
if ((i % check_cancel_frequency) == 0) checkcancel();

acceptedtype acceptedtype = (acceptedtype)this.acceptedtypes.elementat(i);
char[] packagename = acceptedtype.packagename;
char[] simpletypename = acceptedtype.simpletypename;
char[][] enclosingtypenames = acceptedtype.enclosingtypenames;
int modifiers = acceptedtype.modifiers;
int accessibility = acceptedtype.accessibility;

char[] typename;
char[] flatenclosingtypenames;
if(enclosingtypenames == null || enclosingtypenames.length == 0) {
flatenclosingtypenames = null;
typename = simpletypename;
} else {
flatenclosingtypenames = charoperation.concatwith(acceptedtype.enclosingtypenames, '.');
typename = charoperation.concat(flatenclosingtypenames, simpletypename, '.');
}
char[] fullyqualifiedname = charoperation.concat(packagename, typename, '.');

if (this.knowntypes.containskey(fullyqualifiedname)) continue next;

this.knowntypes.put(fullyqualifiedname, known_type_with_unknown_constructors);

if (this.resolvingimports) {
if(this.compileroptions.compliancelevel >= classfileconstants.jdk1_4 && packagename.length == 0) {
continue next; // import of default package is forbidden when compliance is 1.4 or higher
}

char[] completionname = this.insidequalifiedreference ? simpletypename : fullyqualifiedname;

if(this.resolvingstaticimports) {
if(enclosingtypenames == null || enclosingtypenames.length == 0) {
completionname = charoperation.concat(completionname, new char[] { '.' });
} else if ((modifiers & classfileconstants.accstatic) == 0) {
continue next;
} else {
completionname = charoperation.concat(completionname, new char[] { ';' });
}
} else {
completionname = charoperation.concat(completionname, new char[] { ';' });
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforrestrictions(accessibility);
relevance += computerelevanceforcasematching(this.completiontoken, simpletypename);

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.type_ref)) {
createtypeproposal(packagename, typename, modifiers, accessibility, completionname, relevance);
}
} else {
if(!this.importcachesinitialized) {
initializeimportcaches();
}

for (int j = 0; j < this.importcachecount; j++) {
char[][] importname = this.importscache[j];
if(charoperation.equals(typename, importname[0])) {
proposetype(
packagename,
simpletypename,
modifiers,
accessibility,
typename,
fullyqualifiedname,
!charoperation.equals(fullyqualifiedname, importname[1]),
scope);
continue next;
}
}


if ((enclosingtypenames == null || enclosingtypenames.length == 0 ) && charoperation.equals(this.currentpackagename, packagename)) {
proposetype(
packagename,
simpletypename,
modifiers,
accessibility,
typename,
fullyqualifiedname,
false,
scope);
continue next;
} else {
char[] fullyqualifiedenclosingtypeorpackagename = null;

acceptedtype foundtype = null;
if((foundtype = (acceptedtype)ondemandfound.get(simpletypename)) == null) {
for (int j = 0; j < this.ondemandimportcachecount; j++) {
importbinding importbinding = this.ondemandimportscache[j];

char[][] importname = importbinding.compoundname;
char[] importflatname = charoperation.concatwith(importname, '.');

if(fullyqualifiedenclosingtypeorpackagename == null) {
if(enclosingtypenames != null && enclosingtypenames.length != 0) {
fullyqualifiedenclosingtypeorpackagename =
charoperation.concat(
packagename,
flatenclosingtypenames,
'.');
} else {
fullyqualifiedenclosingtypeorpackagename =
packagename;
}
}
if(charoperation.equals(fullyqualifiedenclosingtypeorpackagename, importflatname)) {
if(importbinding.isstatic()) {
if((modifiers & classfileconstants.accstatic) != 0) {
acceptedtype.qualifiedtypename = typename;
acceptedtype.fullyqualifiedname = fullyqualifiedname;
ondemandfound.put(
simpletypename,
acceptedtype);
continue next;
}
} else {
acceptedtype.qualifiedtypename = typename;
acceptedtype.fullyqualifiedname = fullyqualifiedname;
ondemandfound.put(
simpletypename,
acceptedtype);
continue next;
}
}
}
} else if(!foundtype.mustbequalified){
done : for (int j = 0; j < this.ondemandimportcachecount; j++) {
importbinding importbinding = this.ondemandimportscache[j];

char[][] importname = importbinding.compoundname;
char[] importflatname = charoperation.concatwith(importname, '.');

if(fullyqualifiedenclosingtypeorpackagename == null) {
if(enclosingtypenames != null && enclosingtypenames.length != 0) {
fullyqualifiedenclosingtypeorpackagename =
charoperation.concat(
packagename,
flatenclosingtypenames,
'.');
} else {
fullyqualifiedenclosingtypeorpackagename =
packagename;
}
}
if(charoperation.equals(fullyqualifiedenclosingtypeorpackagename, importflatname)) {
if(importbinding.isstatic()) {
if((modifiers & classfileconstants.accstatic) != 0) {
foundtype.mustbequalified = true;
break done;
}
} else {
foundtype.mustbequalified = true;
break done;
}
}
}
}
proposetype(
packagename,
simpletypename,
modifiers,
accessibility,
typename,
fullyqualifiedname,
true,
scope);
}
}
}

char[][] keys = ondemandfound.keytable;
object[] values = ondemandfound.valuetable;
int max = keys.length;
for (int i = 0; i < max; i++) {
if ((i % check_cancel_frequency) == 0) checkcancel();
if(keys[i] != null) {
acceptedtype value = (acceptedtype) values[i];
if(value != null) {
proposetype(
value.packagename,
value.simpletypename,
value.modifiers,
value.accessibility,
value.qualifiedtypename,
value.fullyqualifiedname,
value.mustbequalified,
scope);
}
}
}
} finally {
this.acceptedtypes = null; // reset
}
}

public void acceptunresolvedname(char[] name) {
int relevance = computebaserelevance();
relevance += computerelevanceforresolution(false);
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(this.completiontoken, name);
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for local variable
completionengine.this.noproposal = false;
if(!completionengine.this.requestor.isignored(completionproposal.local_variable_ref)) {
internalcompletionproposal proposal = completionengine.this.createproposal(completionproposal.local_variable_ref, completionengine.this.actualcompletionposition);
proposal.setsignature(java_lang_object_signature);
proposal.setpackagename(java_lang_name);
proposal.settypename(object);
proposal.setname(name);
proposal.setcompletion(name);
proposal.setflags(flags.accdefault);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
completionengine.this.requestor.accept(proposal);
if(debug) {
completionengine.this.printdebug(proposal);
}
}
}
private void addexpectedtype(typebinding type, scope scope){
if (type == null || !type.isvalidbinding() || type == typebinding.null) return;

// do not add twice the same type
for (int i = 0; i <= this.expectedtypesptr; i++) {
if (this.expectedtypes[i] == type) return;
}

int length = this.expectedtypes.length;
if (++this.expectedtypesptr >= length)
system.arraycopy(this.expectedtypes, 0, this.expectedtypes = new typebinding[length * 2], 0, length);
this.expectedtypes[this.expectedtypesptr] = type;

if(type == scope.getjavalangobject()) {
this.hasjavalangobjectasexpectedtype = true;
}
}

private void addforbiddenbindings(binding binding){
if (binding == null) return;

int length = this.forbbidenbindings.length;
if (++this.forbbidenbindingsptr >= length)
system.arraycopy(this.forbbidenbindings, 0, this.forbbidenbindings = new binding[length * 2], 0, length);
this.forbbidenbindings[this.forbbidenbindingsptr] = binding;
}

private void adduninterestingbindings(binding binding){
if (binding == null) return;

int length = this.uninterestingbindings.length;
if (++this.uninterestingbindingsptr >= length)
system.arraycopy(this.uninterestingbindings, 0, this.uninterestingbindings = new binding[length * 2], 0, length);
this.uninterestingbindings[this.uninterestingbindingsptr] = binding;
}

// this code is derived from methodbinding#areparameterscompatiblewith(typebinding[])
private final boolean areparameterscompatiblewith(typebinding[] parameters, typebinding[] arguments, boolean isvarargs) {
int paramlength = parameters.length;
int arglength = arguments.length;
int lastindex = arglength;
if (isvarargs) {
lastindex = paramlength - 1;
if (paramlength == arglength) { // accept x[] but not x or x[][]
typebinding varargtype = parameters[lastindex]; // is an arraybinding by definition
typebinding lastargument = arguments[lastindex];
if (varargtype != lastargument && !lastargument.iscompatiblewith(varargtype))
return false;
} else if (paramlength < arglength) { // all remainig argument types must be compatible with the elementstype of varargtype
typebinding varargtype = ((arraybinding) parameters[lastindex]).elementstype();
for (int i = lastindex; i < arglength; i++)
if (varargtype != arguments[i] && !arguments[i].iscompatiblewith(varargtype))
return false;
} else if (lastindex != arglength) { // can call foo(int i, x ... x) with foo(1) but not foo();
return false;
}
// now compare standard arguments from 0 to lastindex
} else {
if(paramlength != arglength)
return false;
}
for (int i = 0; i < lastindex; i++)
if (parameters[i] != arguments[i] && !arguments[i].iscompatiblewith(parameters[i]))
return false;
return true;
}

private void buildcontext(
astnode astnode,
astnode astnodeparent,
compilationunitdeclaration compilationunitdeclaration,
binding qualifiedbinding,
scope scope) {
internalcompletioncontext context = new internalcompletioncontext();
if (this.requestor.isextendedcontextrequired()) {
context.setextendeddata(
this.typeroot,
compilationunitdeclaration,
this.lookupenvironment,
scope,
astnode,
this.owner,
this.parser);
}

// build expected types context
if (this.expectedtypesptr > -1) {
int length = this.expectedtypesptr + 1;
char[][] exptypes = new char[length][];
char[][] expkeys = new char[length][];
for (int i = 0; i < length; i++) {
exptypes[i] = getsignature(this.expectedtypes[i]);
expkeys[i] = this.expectedtypes[i].computeuniquekey();
}
context.setexpectedtypessignatures(exptypes);
context.setexpectedtypeskeys(expkeys);
}

context.setoffset(this.actualcompletionposition + 1 - this.offset);

// set javadoc info
if (astnode instanceof completiononjavadoc) {
this.assistnodeinjavadoc = ((completiononjavadoc)astnode).getcompletionflags();
context.setjavadoc(this.assistnodeinjavadoc);
}

if (!(astnode instanceof completiononjavadoc)) {
completionscanner scanner = (completionscanner)this.parser.scanner;
context.settoken(scanner.completionidentifier);
context.settokenrange(
scanner.completedidentifierstart - this.offset,
scanner.completedidentifierend - this.offset,
scanner.endofemptytoken - this.offset);
} else if(astnode instanceof completiononjavadoctag) {
completiononjavadoctag javadoctag = (completiononjavadoctag) astnode;
context.settoken(charoperation.concat(new char[]{'@@'}, javadoctag.token));
context.settokenrange(
javadoctag.tagsourcestart - this.offset,
javadoctag.tagsourceend - this.offset,
((completionscanner)this.parser.javadocparser.scanner).endofemptytoken - this.offset);
} else {
completionscanner scanner = (completionscanner)this.parser.javadocparser.scanner;
context.settoken(scanner.completionidentifier);
context.settokenrange(
scanner.completedidentifierstart - this.offset,
scanner.completedidentifierend - this.offset,
scanner.endofemptytoken - this.offset);
}

if(astnode instanceof completiononstringliteral) {
context.settokenkind(completioncontext.token_kind_string_literal);
} else {
context.settokenkind(completioncontext.token_kind_name);
}

buildtokenlocationcontext(context, scope, astnode, astnodeparent);

if(debug) {
system.out.println(context.tostring());
}
this.requestor.acceptcontext(context);
}

private void buildtokenlocationcontext(internalcompletioncontext context, scope scope, astnode astnode, astnode astnodeparent) {
if (scope == null || context.isinjavadoc()) return;

if (astnode instanceof completiononfieldtype) {
completiononfieldtype field = (completiononfieldtype) astnode;
if (!field.islocalvariable &&
field.modifiers == classfileconstants.accdefault &&
(field.annotations == null || field.annotations.length == 0)) {
context.settokenlocation(completioncontext.tl_member_start);
}
} else if (astnode instanceof completiononmethodreturntype) {
completiononmethodreturntype method = (completiononmethodreturntype) astnode;
if (method.modifiers == classfileconstants.accdefault &&
(method.annotations == null || method.annotations.length == 0)) {
context.settokenlocation(completioncontext.tl_member_start);
}
} else {
referencecontext referencecontext = scope.referencecontext();
if (referencecontext instanceof abstractmethoddeclaration) {
abstractmethoddeclaration methoddeclaration = (abstractmethoddeclaration)referencecontext;
if (methoddeclaration.bodystart <= astnode.sourcestart &&
astnode.sourceend <= methoddeclaration.bodyend) {
// completion is inside a method body
if (astnodeparent == null &&
astnode instanceof completiononsinglenamereference &&
!((completiononsinglenamereference)astnode).isprecededbymodifiers) {
context.settokenlocation(completioncontext.tl_statement_start);
}
}
} else if (referencecontext instanceof typedeclaration) {
typedeclaration typedeclaration = (typedeclaration) referencecontext;
fielddeclaration[] fields = typedeclaration.fields;
if (fields != null) {
done : for (int i = 0; i < fields.length; i++) {
if (fields[i] instanceof initializer) {
initializer initializer = (initializer) fields[i];
if (initializer.block.sourcestart <= astnode.sourcestart &&
astnode.sourcestart < initializer.bodyend) {
// completion is inside an initializer
if (astnodeparent == null &&
astnode instanceof completiononsinglenamereference &&
!((completiononsinglenamereference)astnode).isprecededbymodifiers) {
context.settokenlocation(completioncontext.tl_statement_start);
}
break done;
}
}
}
}
}
}
}

void checkcancel() {
if (this.monitor != null && this.monitor.iscanceled()) {
throw new operationcanceledexception();
}
}

private boolean complete(
astnode astnode,
astnode astnodeparent,
astnode enclosingnode,
compilationunitdeclaration compilationunitdeclaration,
binding qualifiedbinding,
scope scope,
boolean insidetypeannotation) {

setsourceandtokenrange(astnode.sourcestart, astnode.sourceend);

scope = computeforbiddenbindings(astnode, astnodeparent, scope);
computeuninterestingbindings(astnodeparent, scope);
if(astnodeparent != null) {
if(!isvalidparent(astnodeparent, astnode, scope)) return false;
computeexpectedtypes(astnodeparent, astnode, scope);
}

buildcontext(astnode, astnodeparent, compilationunitdeclaration, qualifiedbinding, scope);

if (astnode instanceof completiononfieldtype) {
completiononfieldtype(astnode, scope);
} else if (astnode instanceof completiononmethodreturntype) {
completiononmethodreturntype(astnode, scope);
} else if (astnode instanceof completiononsinglenamereference) {
completiononsinglenamereference(astnode, astnodeparent, scope, insidetypeannotation);
} else if (astnode instanceof completiononsingletypereference) {
completiononsingletypereference(astnode, astnodeparent, qualifiedbinding, scope);
} else if (astnode instanceof completiononqualifiednamereference) {
completiononqualifiednamereference(astnode, enclosingnode, qualifiedbinding, scope, insidetypeannotation);
} else if (astnode instanceof completiononqualifiedtypereference) {
completiononqualifiedtypereference(astnode, astnodeparent, qualifiedbinding, scope);
} else if (astnode instanceof completiononmemberaccess) {
completiononmemberaccess(astnode, enclosingnode, qualifiedbinding, scope, insidetypeannotation);
} else if (astnode instanceof completiononmessagesend) {
completiononmessagesend(astnode, qualifiedbinding, scope);
} else if (astnode instanceof completiononexplicitconstructorcall) {
completiononexplicitconstructorcall(astnode, qualifiedbinding, scope);
} else if (astnode instanceof completiononqualifiedallocationexpression) {
completiononqualifiedallocationexpression(astnode, qualifiedbinding, scope);
} else if (astnode instanceof completiononclassliteralaccess) {
completiononclassliteralaccess(astnode, qualifiedbinding, scope);
} else if (astnode instanceof completiononmethodname) {
completiononmethodname(astnode, scope);
} else if (astnode instanceof completiononfieldname) {
completiononfieldname(astnode, scope);
} else if (astnode instanceof completiononlocalname) {
completiononlocalorargumentname(astnode, scope);
} else if (astnode instanceof completiononargumentname) {
completiononlocalorargumentname(astnode, scope);
} else if (astnode instanceof completiononkeyword) {
completiononkeyword(astnode);
} else if (astnode instanceof completiononparameterizedqualifiedtypereference) {
completiononparameterizedqualifiedtypereference(astnode, astnodeparent, qualifiedbinding, scope);
} else if (astnode instanceof completiononmarkerannotationname) {
completiononmarkerannotationname(astnode, qualifiedbinding, scope);
} else if (astnode instanceof completiononmembervaluename) {
completiononmembervaluename(astnode, astnodeparent, scope, insidetypeannotation);
} else if(astnode instanceof completiononbranchstatementlabel) {
completiononbranchstatementlabel(astnode);
} else if(astnode instanceof completiononmessagesendname) {
completiononmessagesendname(astnode, qualifiedbinding, scope);
// completion on javadoc nodes
} else if ((astnode.bits & astnode.insidejavadoc) != 0) {
if (astnode instanceof completiononjavadocsingletypereference) {
completiononjavadocsingletypereference(astnode, scope);
} else if (astnode instanceof completiononjavadocqualifiedtypereference) {
completiononjavadocqualifiedtypereference(astnode, qualifiedbinding, scope);
} else if (astnode instanceof completiononjavadocfieldreference) {
completiononjavadocfieldreference(astnode, scope);
} else if (astnode instanceof completiononjavadocmessagesend) {
completiononjavadocmessagesend(astnode, qualifiedbinding, scope);
} else if (astnode instanceof completiononjavadocallocationexpression) {
completiononjavadocallocationexpression(astnode, qualifiedbinding, scope);
} else if (astnode instanceof completiononjavadocparamnamereference) {
completiononjavadocparamnamereference(astnode);
} else if (astnode instanceof completiononjavadoctypeparamreference) {
completiononjavadoctypeparamreference(astnode);
} else if (astnode instanceof completiononjavadoctag) {
completiononjavadoctag(astnode);
}
}
return true;
}

/**
* ask the engine to compute a completion at the specified position
* of the given compilation unit.
*
*  no return
*      completion results are answered through a requestor.
*
*  @@param sourceunit org.eclipse.jdt.internal.compiler.env.icompilationunit
*      the source of the current compilation unit.
*
*  @@param completionposition int
*      a position in the source where the completion is taking place.
*      this position is relative to the source provided.
*/
public void complete(icompilationunit sourceunit, int completionposition, int pos, ityperoot root) {

if(debug) {
system.out.print("completion in "); //$non-nls-1$
system.out.print(sourceunit.getfilename());
system.out.print(" at position "); //$non-nls-1$
system.out.println(completionposition);
system.out.println("completion - source :"); //$non-nls-1$
system.out.println(sourceunit.getcontents());
}
if (this.monitor != null) this.monitor.begintask(messages.engine_completing, iprogressmonitor.unknown);
this.requestor.beginreporting();
boolean contextaccepted = false;
try {
this.filename = sourceunit.getfilename();
this.actualcompletionposition = completionposition - 1;
this.offset = pos;
this.typeroot = root;

this.checkcancel();

// for now until we can change the ui.
compilationresult result = new compilationresult(sourceunit, 1, 1, this.compileroptions.maxproblemsperunit);
compilationunitdeclaration parsedunit = this.parser.dietparse(sourceunit, result, this.actualcompletionposition);

//		boolean completionnodefound = false;
if (parsedunit != null) {
if(debug) {
system.out.println("completion - diet ast :"); //$non-nls-1$
system.out.println(parsedunit.tostring());
}

// scan the package & import statements first
if (parsedunit.currentpackage instanceof completiononpackagereference) {
contextaccepted = true;
buildcontext(parsedunit.currentpackage, null, parsedunit, null, null);
if(!this.requestor.isignored(completionproposal.package_ref)) {
findpackages((completiononpackagereference) parsedunit.currentpackage);
}
if(this.noproposal && this.problem != null) {
this.requestor.completionfailure(this.problem);
if(debug) {
this.printdebug(this.problem);
}
}
return;
}

importreference[] imports = parsedunit.imports;
if (imports != null) {
for (int i = 0, length = imports.length; i < length; i++) {
importreference importreference = imports[i];
if (importreference instanceof completiononimportreference) {
this.lookupenvironment.buildtypebindings(parsedunit, null /*no access restriction*/);
if ((this.unitscope = parsedunit.scope) != null) {
contextaccepted = true;
buildcontext(importreference, null, parsedunit, null, null);

long positions = importreference.sourcepositions[importreference.tokens.length - 1];
setsourceandtokenrange((int) (positions >>> 32), (int) positions);

char[][] oldtokens = importreference.tokens;
int tokencount = oldtokens.length;
if (tokencount == 1) {
findimports((completiononimportreference)importreference, true);
} else if(tokencount > 1){
this.insidequalifiedreference = true;

char[] lasttoken = oldtokens[tokencount - 1];
char[][] qualifiertokens = charoperation.subarray(oldtokens, 0, tokencount - 1);

binding binding = this.unitscope.gettypeorpackage(qualifiertokens);
if(binding != null) {
if(binding instanceof packagebinding) {
findimports((completiononimportreference)importreference, false);
} else {
referencebinding ref = (referencebinding) binding;

if(!this.requestor.isignored(completionproposal.type_ref)) {
findimportsofmembertypes(lasttoken, ref, importreference.isstatic());
}
if(importreference.isstatic()) {

if(!this.requestor.isignored(completionproposal.field_ref)) {
findimportsofstaticfields(lasttoken, ref);
}
if(!this.requestor.isignored(completionproposal.method_name_reference)) {
findimportsofstaticmethods(lasttoken, ref);
}
}
}
}
}

if(this.noproposal && this.problem != null) {
this.requestor.completionfailure(this.problem);
if(debug) {
this.printdebug(this.problem);
}
}
}
return;
} else if(importreference instanceof completiononkeyword) {
contextaccepted = true;
buildcontext(importreference, null, parsedunit, null, null);
if(!this.requestor.isignored(completionproposal.keyword)) {
setsourceandtokenrange(importreference.sourcestart, importreference.sourceend);
completiononkeyword keyword = (completiononkeyword)importreference;
findkeywords(keyword.gettoken(), keyword.getpossiblekeywords(), false, false);
}
if(this.noproposal && this.problem != null) {
this.requestor.completionfailure(this.problem);
if(debug) {
this.printdebug(this.problem);
}
}
return;
}
}
}

if (parsedunit.types != null) {
try {
this.lookupenvironment.buildtypebindings(parsedunit, null /*no access restriction*/);

if ((this.unitscope = parsedunit.scope) != null) {
this.source = sourceunit.getcontents();
this.lookupenvironment.completetypebindings(parsedunit, true);
parsedunit.scope.faultintypes();
parseblockstatements(parsedunit, this.actualcompletionposition);
if(debug) {
system.out.println("completion - ast :"); //$non-nls-1$
system.out.println(parsedunit.tostring());
}
parsedunit.resolve();
}
} catch (completionnodefound e) {
//					completionnodefound = true;
if (e.astnode != null) {
// if null then we found a problem in the completion node
if(debug) {
system.out.print("completion - completion node : "); //$non-nls-1$
system.out.println(e.astnode.tostring());
if(this.parser.assistnodeparent != null) {
system.out.print("completion - parent node : ");  //$non-nls-1$
system.out.println(this.parser.assistnodeparent);
}
}
this.lookupenvironment.unitbeingcompleted = parsedunit; // better resilient to further error reporting
contextaccepted =
complete(
e.astnode,
this.parser.assistnodeparent,
this.parser.enclosingnode,
parsedunit,
e.qualifiedbinding,
e.scope,
e.insidetypeannotation);
}
}
}
}

if(this.noproposal && this.problem != null) {
if(!contextaccepted) {
contextaccepted = true;
internalcompletioncontext context = new internalcompletioncontext();
context.setoffset(completionposition - this.offset);
context.settokenkind(completioncontext.token_kind_unknown);
if (this.requestor.isextendedcontextrequired()) context.setextended();
this.requestor.acceptcontext(context);
}
this.requestor.completionfailure(this.problem);
if(debug) {
this.printdebug(this.problem);
}
}
/* ignore package, import, class & interface keywords for now...
if (!completionnodefound) {
if (parsedunit == null || parsedunit.types == null) {
// this is not good enough... can still be trying to define a second type
completionscanner scanner = (completionscanner) this.parser.scanner;
setsourcerange(scanner.completedidentifierstart, scanner.completedidentifierend);
findkeywords(scanner.completionidentifier, maindeclarations, null);
}
// currently have no way to know if extends/implements are possible keywords
}
*/
} catch (indexoutofboundsexception e) { // work-around internal failure - 1gemf6d
if(debug) {
system.out.println("exception caught by completionengine:"); //$non-nls-1$
e.printstacktrace(system.out);
}
} catch (invalidcursorlocation e) { // may eventually report a usefull error
if(debug) {
system.out.println("exception caught by completionengine:"); //$non-nls-1$
e.printstacktrace(system.out);
}
} catch (abortcompilation e) { // ignore this exception for now since it typically means we cannot find java.lang.object
if(debug) {
system.out.println("exception caught by completionengine:"); //$non-nls-1$
e.printstacktrace(system.out);
}
} catch (completionnodefound e){ // internal failure - bugs 5618
if(debug) {
system.out.println("exception caught by completionengine:"); //$non-nls-1$
e.printstacktrace(system.out);
}
} finally {
if(!contextaccepted) {
contextaccepted = true;
internalcompletioncontext context = new internalcompletioncontext();
context.settokenkind(completioncontext.token_kind_unknown);
context.setoffset(completionposition - this.offset);
if (this.requestor.isextendedcontextrequired()) context.setextended();
this.requestor.acceptcontext(context);
}
this.requestor.endreporting();
if (this.monitor != null) this.monitor.done();
reset();
}
}

public void complete(itype type, char[] snippet, int position, char[][] localvariabletypenames, char[][] localvariablenames, int[] localvariablemodifiers, boolean isstatic){
if(this.requestor != null){
this.requestor.beginreporting();
}
boolean contextaccepted = false;
itype topleveltype = type;
while(topleveltype.getdeclaringtype() != null) {
topleveltype = topleveltype.getdeclaringtype();
}

this.filename = topleveltype.getparent().getelementname().tochararray();
compilationresult compilationresult = new compilationresult(this.filename, 1, 1, this.compileroptions.maxproblemsperunit);

compilationunitdeclaration compilationunit = null;

try {
// typeconverter is used instead of sourcetypeconverter because the type
// to convert can be a binary type or a source type
typedeclaration typedeclaration = null;
if (type instanceof sourcetype) {
sourcetype sourcetype = (sourcetype) type;
isourcetype info = (isourcetype) sourcetype.getelementinfo();
compilationunit = sourcetypeconverter.buildcompilationunit(
new isourcetype[] {info},//sourcetypes[0] is always toplevel here
sourcetypeconverter.field_and_method // need field and methods
| sourcetypeconverter.member_type, // need member types
// no need for field initialization
this.problemreporter,
compilationresult);
if (compilationunit.types != null)
typedeclaration = compilationunit.types[0];
} else {
compilationunit = new compilationunitdeclaration(this.problemreporter, compilationresult, 0);
typedeclaration = new binarytypeconverter(this.parser.problemreporter(), compilationresult, null/*no need to remember type names*/).buildtypedeclaration(type, compilationunit);
}

if(typedeclaration != null) {
// build ast from snippet
initializer fakeinitializer = parsesnippeinitializer(snippet, position, localvariabletypenames, localvariablenames, localvariablemodifiers, isstatic);

// merge ast
fielddeclaration[] oldfields = typedeclaration.fields;
fielddeclaration[] newfields = null;
if (oldfields != null) {
newfields = new fielddeclaration[oldfields.length + 1];
system.arraycopy(oldfields, 0, newfields, 0, oldfields.length);
newfields[oldfields.length] = fakeinitializer;
} else {
newfields = new fielddeclaration[] {fakeinitializer};
}
typedeclaration.fields = newfields;

if(debug) {
system.out.println("snippet completion ast :"); //$non-nls-1$
system.out.println(compilationunit.tostring());
}

if (compilationunit.types != null) {
try {
this.lookupenvironment.buildtypebindings(compilationunit, null /*no access restriction*/);

if ((this.unitscope = compilationunit.scope) != null) {
this.lookupenvironment.completetypebindings(compilationunit, true);
compilationunit.scope.faultintypes();
compilationunit.resolve();
}
} catch (completionnodefound e) {
//					completionnodefound = true;
if (e.astnode != null) {
// if null then we found a problem in the completion node
contextaccepted =
complete(
e.astnode,
this.parser.assistnodeparent,
this.parser.enclosingnode,
compilationunit,
e.qualifiedbinding,
e.scope,
e.insidetypeannotation);
}
}
}
if(this.noproposal && this.problem != null) {
if(!contextaccepted) {
contextaccepted = true;
internalcompletioncontext context = new internalcompletioncontext();
if (this.requestor.isextendedcontextrequired()) context.setextended();
this.requestor.acceptcontext(context);
}
this.requestor.completionfailure(this.problem);
if(debug) {
this.printdebug(this.problem);
}
}
}
}  catch (indexoutofboundsexception e) { // work-around internal failure - 1gemf6d (added with fix of 99629)
if(debug) {
system.out.println("exception caught by completionengine:"); //$non-nls-1$
e.printstacktrace(system.out);
}
} catch (invalidcursorlocation e) { // may eventually report a usefull error (added to fix 99629)
if(debug) {
system.out.println("exception caught by completionengine:"); //$non-nls-1$
e.printstacktrace(system.out);
}
} catch (abortcompilation e) { // ignore this exception for now since it typically means we cannot find java.lang.object (added with fix of 99629)
if(debug) {
system.out.println("exception caught by completionengine:"); //$non-nls-1$
e.printstacktrace(system.out);
}
} catch (completionnodefound e){ // internal failure - bugs 5618 (added with fix of 99629)
if(debug) {
system.out.println("exception caught by completionengine:"); //$non-nls-1$
e.printstacktrace(system.out);
}
} catch(javamodelexception e) {
// do nothing
}
if(!contextaccepted) {
contextaccepted = true;
internalcompletioncontext context = new internalcompletioncontext();
if (this.requestor.isextendedcontextrequired()) context.setextended();
this.requestor.acceptcontext(context);
}
if(this.requestor != null){
this.requestor.endreporting();
}
}

private void completiononbranchstatementlabel(astnode astnode) {
if (!this.requestor.isignored(completionproposal.label_ref)) {
completiononbranchstatementlabel label = (completiononbranchstatementlabel) astnode;
this.completiontoken = label.label;
findlabels(this.completiontoken, label.possiblelabels);
}
}

private void completiononclassliteralaccess(astnode astnode, binding qualifiedbinding, scope scope) {
if (!this.requestor.isignored(completionproposal.field_ref)) {
completiononclassliteralaccess access = (completiononclassliteralaccess) astnode;
setsourceandtokenrange(access.classstart, access.sourceend);
this.completiontoken = access.completionidentifier;
findclassfield(
this.completiontoken,
(typebinding) qualifiedbinding,
scope,
null,
null,
null,
false);
}
}

private void completiononexplicitconstructorcall(astnode astnode, binding qualifiedbinding, scope scope) {
if (!this.requestor.isignored(completionproposal.method_ref)) {
setsourceandtokenrange(astnode.sourcestart, astnode.sourceend, false);
completiononexplicitconstructorcall constructorcall = (completiononexplicitconstructorcall) astnode;
typebinding[] argtypes = computetypes(constructorcall.arguments);
findconstructors(
(referencebinding) qualifiedbinding,
argtypes,
scope,
constructorcall,
false,
null,
null,
null,
false);
}
}

private void completiononfieldname(astnode astnode, scope scope) {
if (!this.requestor.isignored(completionproposal.variable_declaration)) {
completiononfieldname field = (completiononfieldname) astnode;

fieldbinding[] fields = scope.enclosingsourcetype().fields();
char[][] excludenames = new char[fields.length][];
for(int i = 0 ; i < fields.length ; i++){
excludenames[i] = fields[i].name;
}

this.completiontoken = field.realname;


int kind =
(field.modifiers & classfileconstants.accstatic) == 0 ?
internalnamingconventions.vk_instance_field :
(field.modifiers & classfileconstants.accfinal) == 0 ?
internalnamingconventions.vk_static_field :
internalnamingconventions.vk_static_final_field;

findvariablenames(field.realname, field.type, excludenames, null, kind);
}
}

private void completiononfieldtype(astnode astnode, scope scope) {
completiononfieldtype field = (completiononfieldtype) astnode;
completiononsingletypereference type = (completiononsingletypereference) field.type;
this.completiontoken = type.token;
setsourceandtokenrange(type.sourcestart, type.sourceend);

findtypesandpackages(this.completiontoken, scope, true, true, new objectvector());
if (!this.requestor.isignored(completionproposal.keyword)) {
findkeywordsformember(this.completiontoken, field.modifiers);
}

if (!field.islocalvariable && field.modifiers == classfileconstants.accdefault) {
sourcetypebinding enclosingtype = scope.enclosingsourcetype();
if (!enclosingtype.isannotationtype()) {
if (!this.requestor.isignored(completionproposal.method_declaration)) {
findmethoddeclarations(
this.completiontoken,
enclosingtype,
scope,
new objectvector(),
null,
null,
null,
false);
}
if (!this.requestor.isignored(completionproposal.potential_method_declaration)) {
proposenewmethod(this.completiontoken, enclosingtype);
}
}
}
}
//todo
private void completiononjavadocallocationexpression(astnode astnode, binding qualifiedbinding, scope scope) {
// setsourcerange(astnode.sourcestart, astnode.sourceend, false);

completiononjavadocallocationexpression allocexpression = (completiononjavadocallocationexpression) astnode;
this.javadoctagposition = allocexpression.tagsourcestart;
int rangestart = astnode.sourcestart;
if (allocexpression.type.isthis()) {
if (allocexpression.completeintext()) {
rangestart = allocexpression.separatorposition;
}
} else if (allocexpression.completeintext()) {
rangestart = allocexpression.type.sourcestart;
}
setsourceandtokenrange(rangestart, astnode.sourceend, false);
typebinding[] argtypes = computetypes(allocexpression.arguments);

referencebinding ref = (referencebinding) qualifiedbinding;
if (!this.requestor.isignored(completionproposal.method_ref) && ref.isclass()) {
findconstructors(ref, argtypes, scope, allocexpression, false, null, null, null, false);
}
}
//todo
private void completiononjavadocfieldreference(astnode astnode, scope scope) {
this.insidequalifiedreference = true;
completiononjavadocfieldreference fieldref = (completiononjavadocfieldreference) astnode;
this.completiontoken = fieldref.token;
long completionposition = fieldref.namesourceposition;
this.javadoctagposition = fieldref.tagsourcestart;

if (fieldref.actualreceivertype != null && fieldref.actualreceivertype.isvalidbinding()) {
referencebinding receivertype = (referencebinding) fieldref.actualreceivertype;
int rangestart = (int) (completionposition >>> 32);
if (fieldref.receiver.isthis()) {
if (fieldref.completeintext()) {
rangestart = fieldref.separatorposition;
}
} else if (fieldref.completeintext()) {
rangestart = fieldref.receiver.sourcestart;
}
setsourceandtokenrange(rangestart, (int) completionposition);

if (!this.requestor.isignored(completionproposal.field_ref)
|| !this.requestor.isignored(completionproposal.javadoc_field_ref)) {
findfields(this.completiontoken,
receivertype,
scope,
new objectvector(),
new objectvector(),
false, /*not only static */
fieldref,
scope,
false,
true,
null,
null,
null,
false,
null,
-1,
-1);
}

if (!this.requestor.isignored(completionproposal.method_ref)
|| !this.requestor.isignored(completionproposal.javadoc_method_ref)) {
findmethods(
this.completiontoken,
null,
null,
receivertype,
scope,
new objectvector(),
false, /*not only static */
false,
fieldref,
scope,
false,
false,
true,
null,
null,
null,
false,
null,
-1,
-1);
if (fieldref.actualreceivertype instanceof referencebinding) {
referencebinding refbinding = (referencebinding)fieldref.actualreceivertype;
if (this.completiontoken == null
|| charoperation.prefixequals(this.completiontoken, refbinding.sourcename)
|| (this.options.camelcasematch && charoperation.camelcasematch(this.completiontoken, refbinding.sourcename))) {
findconstructors(refbinding, null, scope, fieldref, false, null, null, null, false);
}
}
}
}
}
//todo
private void completiononjavadocmessagesend(astnode astnode, binding qualifiedbinding, scope scope) {
completiononjavadocmessagesend messagesend = (completiononjavadocmessagesend) astnode;
typebinding[] argtypes = null; //computetypes(messagesend.arguments);
this.completiontoken = messagesend.selector;
this.javadoctagposition = messagesend.tagsourcestart;

// set source range
int rangestart = astnode.sourcestart;
if (messagesend.receiver.isthis()) {
if (messagesend.completeintext()) {
rangestart = messagesend.separatorposition;
}
} else if (messagesend.completeintext()) {
rangestart = messagesend.receiver.sourcestart;
}
setsourceandtokenrange(rangestart, astnode.sourceend, false);

if (qualifiedbinding == null) {
if (!this.requestor.isignored(completionproposal.method_ref)) {
findimplicitmessagesends(this.completiontoken, argtypes, scope, messagesend, scope, new objectvector());
}
} else if (!this.requestor.isignored(completionproposal.method_ref)) {
findmethods(
this.completiontoken,
null,
argtypes,
(referencebinding) ((referencebinding) qualifiedbinding).capture(scope, messagesend.receiver.sourceend),
scope,
new objectvector(),
false,
false/* prefix match */,
messagesend,
scope,
false,
messagesend.receiver instanceof superreference,
true,
null,
null,
null,
false,
null,
-1,
-1);
}
}
//todo
private void completiononjavadocparamnamereference(astnode astnode) {
if (!this.requestor.isignored(completionproposal.javadoc_param_ref)) {
completiononjavadocparamnamereference paramref = (completiononjavadocparamnamereference) astnode;
setsourceandtokenrange(paramref.tagsourcestart, paramref.tagsourceend);
findjavadocparamnames(paramref.token, paramref.missingparams, false);
findjavadocparamnames(paramref.token, paramref.missingtypeparams, true);
}
}
//todo
private void completiononjavadocqualifiedtypereference(astnode astnode, binding qualifiedbinding, scope scope) {
this.insidequalifiedreference = true;

completiononjavadocqualifiedtypereference typeref = (completiononjavadocqualifiedtypereference) astnode;
this.completiontoken = typeref.completionidentifier;
long completionposition = typeref.sourcepositions[typeref.tokens.length];
this.javadoctagposition = typeref.tagsourcestart;

// get the source positions of the completion identifier
if (qualifiedbinding instanceof referencebinding && !(qualifiedbinding instanceof typevariablebinding)) {
if (!this.requestor.isignored(completionproposal.type_ref) ||
((this.assistnodeinjavadoc & completiononjavadoc.text) != 0 && !this.requestor.isignored(completionproposal.javadoc_type_ref))) {
int rangestart = typeref.completeintext() ? typeref.sourcestart : (int) (completionposition >>> 32);
setsourceandtokenrange(rangestart, (int) completionposition);
findmembertypes(
this.completiontoken,
(referencebinding) qualifiedbinding,
scope,
scope.enclosingsourcetype(),
false,
false,
new objectvector(),
null,
null,
null,
false);
}
} else if (qualifiedbinding instanceof packagebinding) {

setsourcerange(astnode.sourcestart, (int) completionposition);
int rangestart = typeref.completeintext() ? typeref.sourcestart : (int) (completionposition >>> 32);
settokenrange(rangestart, (int) completionposition);
// replace to the end of the completion identifier
findtypesandsubpackages(this.completiontoken, (packagebinding) qualifiedbinding, scope);
}
}
//todo
private void completiononjavadocsingletypereference(astnode astnode, scope scope) {
completiononjavadocsingletypereference typeref = (completiononjavadocsingletypereference) astnode;
this.completiontoken = typeref.token;
this.javadoctagposition = typeref.tagsourcestart;
setsourceandtokenrange(typeref.sourcestart, typeref.sourceend);
findtypesandpackages(
this.completiontoken,
scope,
(this.assistnodeinjavadoc & completiononjavadoc.base_types) != 0,
false,
new objectvector());
}
//todo
private void completiononjavadoctag(astnode astnode) {
completiononjavadoctag javadoctag = (completiononjavadoctag) astnode;
setsourceandtokenrange(javadoctag.tagsourcestart, javadoctag.sourceend);
findjavadocblocktags(javadoctag);
findjavadocinlinetags(javadoctag);
}
//todo
private void completiononjavadoctypeparamreference(astnode astnode) {
if (!this.requestor.isignored(completionproposal.javadoc_param_ref)) {
completiononjavadoctypeparamreference paramref = (completiononjavadoctypeparamreference) astnode;
setsourceandtokenrange(paramref.tagsourcestart, paramref.tagsourceend);
findjavadocparamnames(paramref.token, paramref.missingparams, true);
}
}

private void completiononkeyword(astnode astnode) {
if (!this.requestor.isignored(completionproposal.keyword)) {
completiononkeyword keyword = (completiononkeyword)astnode;
findkeywords(keyword.gettoken(), keyword.getpossiblekeywords(), keyword.cancompleteemptytoken(), false);
}
}

private void completiononlocalorargumentname(astnode astnode, scope scope) {
if (!this.requestor.isignored(completionproposal.variable_declaration)) {
localdeclaration variable = (localdeclaration) astnode;

int kind;
if (variable instanceof completiononlocalname){
this.completiontoken = ((completiononlocalname) variable).realname;
kind = internalnamingconventions.vk_local;
} else {
completiononargumentname arg = (completiononargumentname) variable;
this.completiontoken = arg.realname;
kind = arg.iscatchargument ? internalnamingconventions.vk_local : internalnamingconventions.vk_parameter;
}

char[][] alreadydefinedname = computealreadydefinedname((blockscope)scope, variable);

char[][] forbiddennames = findvariablefromunresolvedreference(variable, (blockscope)scope, alreadydefinedname);

localvariablebinding[] locals = ((blockscope)scope).locals;
char[][] discouragednames = new char[locals.length][];
int localcount = 0;
for(int i = 0 ; i < locals.length ; i++){
if (locals[i] != null) {
discouragednames[localcount++] = locals[i].name;
}
}

system.arraycopy(discouragednames, 0, discouragednames = new char[localcount][], 0, localcount);

findvariablenames(this.completiontoken, variable.type, discouragednames, forbiddennames, kind);
}
}

private void completiononmarkerannotationname(astnode astnode, binding qualifiedbinding, scope scope) {
completiononmarkerannotationname annot = (completiononmarkerannotationname) astnode;

completiononannotationoftype faketype = (completiononannotationoftype)scope.parent.referencecontext();
if (faketype.annotations[0] == annot) {
// when the completion is inside a method body the annotation cannot be accuratly attached to the correct node by completion recovery.
// so 'targetedelement' is not computed in this case.
if (scope.parent.parent == null || !(scope.parent.parent instanceof methodscope)) {
this.targetedelement = computetargetedelement(faketype);
}

}

this.assistnodeisannotation = true;
if (annot.type instanceof completiononsingletypereference) {
completiononsingletypereference type = (completiononsingletypereference) annot.type;
this.completiontoken = type.token;
setsourceandtokenrange(type.sourcestart, type.sourceend);

if (scope.parent.parent != null &&
!(scope.parent.parent instanceof methodscope) &&
!faketype.isparameter) {

if (this.completiontoken.length <= keywords.interface.length
&& charoperation.prefixequals(this.completiontoken, keywords.interface, false /* ignore case */
)){
int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(this.completiontoken, keywords.interface);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for keywords
relevance += r_annotation; // this proposal is most relevant than annotation proposals

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.keyword)) {
completionproposal proposal = createproposal(completionproposal.keyword, this.actualcompletionposition);
proposal.setname(keywords.interface);
proposal.setcompletion(keywords.interface);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}

findtypesandpackages(this.completiontoken, scope, false, false, new objectvector());
} else if (annot.type instanceof completiononqualifiedtypereference) {
this.insidequalifiedreference = true;

completiononqualifiedtypereference type = (completiononqualifiedtypereference) annot.type;
this.completiontoken = type.completionidentifier;
long completionposition = type.sourcepositions[type.tokens.length];
if (qualifiedbinding instanceof packagebinding) {

setsourcerange(astnode.sourcestart, (int) completionposition);
settokenrange((int) (completionposition >>> 32), (int) completionposition);
// replace to the end of the completion identifier
findtypesandsubpackages(this.completiontoken, (packagebinding) qualifiedbinding, scope);
} else {
setsourceandtokenrange((int) (completionposition >>> 32), (int) completionposition);

findmembertypes(
this.completiontoken,
(referencebinding) qualifiedbinding,
scope,
scope.enclosingsourcetype(),
false,
false,
new objectvector(),
null,
null,
null,
false);
}
}
}

private void completiononmemberaccess(astnode astnode, astnode enclosingnode, binding qualifiedbinding,
scope scope, boolean insidetypeannotation) {
this.insidequalifiedreference = true;
completiononmemberaccess access = (completiononmemberaccess) astnode;
long completionposition = access.namesourceposition;
setsourceandtokenrange((int) (completionposition >>> 32), (int) completionposition);

this.completiontoken = access.token;

if (qualifiedbinding.problemid() == problemreasons.notfound) {
// complete method members with missing return type
// class x {
//   missing f() {return null;}
//   void foo() {
//     f().|
//   }
// }
if (this.assistnodeinjavadoc == 0 &&
(this.requestor.isallowingrequiredproposals(completionproposal.field_ref, completionproposal.type_ref) ||
this.requestor.isallowingrequiredproposals(completionproposal.method_ref, completionproposal.type_ref))) {
problemmethodbinding problemmethodbinding = (problemmethodbinding) qualifiedbinding;
findfieldsandmethodsfrommissingreturntype(
problemmethodbinding.selector,
problemmethodbinding.parameters,
scope,
access,
insidetypeannotation);
}
} else {
if (!access.isinsideannotation) {
if (!this.requestor.isignored(completionproposal.keyword)) {
findkeywords(this.completiontoken, new char[][]{keywords.new}, false, false);
}

objectvector fieldsfound = new objectvector();
objectvector methodsfound = new objectvector();

boolean supercall = access.receiver instanceof superreference;

findfieldsandmethods(
this.completiontoken,
((typebinding) qualifiedbinding).capture(scope, access.receiver.sourceend),
scope,
fieldsfound,
methodsfound,
access,
scope,
false,
supercall,
null,
null,
null,
false,
null,
-1,
-1);

if (!supercall) {

checkcancel();

findfieldsandmethodsfromcastedreceiver(
enclosingnode,
qualifiedbinding,
scope,
fieldsfound,
methodsfound,
access,
scope,
access.receiver);
}
}
}
}

private void completiononmembervaluename(astnode astnode, astnode astnodeparent, scope scope,
boolean insidetypeannotation) {
completiononmembervaluename membervaluepair = (completiononmembervaluename) astnode;
annotation annotation = (annotation) astnodeparent;

this.completiontoken = membervaluepair.name;

referencebinding annotationtype = (referencebinding)annotation.resolvedtype;

if (annotationtype != null && annotationtype.isannotationtype()) {
if (!this.requestor.isignored(completionproposal.annotation_attribute_ref)) {
findannotationattributes(this.completiontoken, annotation.membervaluepairs(), annotationtype);
}
if (this.assistnodecanbesinglememberannotation) {
if (this.expectedtypesptr > -1 && this.expectedtypes[0].isannotationtype()) {
findtypesandpackages(this.completiontoken, scope, false, false, new objectvector());
} else {
if (this.expectedtypesptr > -1) {
this.assistnodeisenum = true;
done : for (int i = 0; i <= this.expectedtypesptr; i++) {
if (!this.expectedtypes[i].isenum()) {
this.assistnodeisenum = false;
break done;
}
}

}
if (scope instanceof blockscope && !this.requestor.isignored(completionproposal.local_variable_ref)) {
char[][] alreadydefinedname = computealreadydefinedname((blockscope)scope, fakeinvocationsite);

findunresolvedreference(
membervaluepair.sourcestart,
membervaluepair.sourceend,
(blockscope)scope,
alreadydefinedname);
}
findvariablesandmethods(
this.completiontoken,
scope,
fakeinvocationsite,
scope,
insidetypeannotation,
true);
// can be the start of a qualified type name
findtypesandpackages(this.completiontoken, scope, false, false, new objectvector());
}
}
}
}

private void completiononmessagesend(astnode astnode, binding qualifiedbinding, scope scope) {
setsourceandtokenrange(astnode.sourcestart, astnode.sourceend, false);

completiononmessagesend messagesend = (completiononmessagesend) astnode;
typebinding[] argtypes = computetypes(messagesend.arguments);
this.completiontoken = messagesend.selector;
if (qualifiedbinding == null) {
if (!this.requestor.isignored(completionproposal.method_ref)) {
objectvector methodsfound = new objectvector();

findimplicitmessagesends(this.completiontoken, argtypes, scope, messagesend, scope, methodsfound);

checkcancel();

findlocalmethodsfromstaticimports(
this.completiontoken,
scope,
messagesend,
scope,
true,
methodsfound,
true);
}
} else  if (!this.requestor.isignored(completionproposal.method_ref)) {
findmethods(
this.completiontoken,
null,
argtypes,
(referencebinding)((referencebinding) qualifiedbinding).capture(scope, messagesend.receiver.sourceend),
scope,
new objectvector(),
false,
true,
messagesend,
scope,
false,
messagesend.receiver instanceof superreference,
false,
null,
null,
null,
false,
null,
-1,
-1);
}
}

private void completiononmessagesendname(astnode astnode, binding qualifiedbinding, scope scope) {
if (!this.requestor.isignored(completionproposal.method_ref)) {
completiononmessagesendname messagesend = (completiononmessagesendname) astnode;

this.insidequalifiedreference = true;
this.completiontoken = messagesend.selector;
boolean onlystatic = false;
if (messagesend.receiver instanceof namereference) {
onlystatic = ((namereference)messagesend.receiver).istypereference();
} else if (!(messagesend.receiver instanceof messagesend) &&
!(messagesend.receiver instanceof fieldreference) &&
!(messagesend.receiver.isthis())) {
onlystatic = true;
}

typebinding receivertype = (typebinding)qualifiedbinding;

if(receivertype != null && receivertype instanceof referencebinding) {
typebinding[] typeargtypes = computetypesifcorrect(messagesend.typearguments);
if(typeargtypes != null) {
findmethods(
this.completiontoken,
typeargtypes,
null,
(referencebinding)receivertype.capture(scope, messagesend.receiver.sourceend),
scope,
new objectvector(),
onlystatic,
false,
messagesend,
scope,
false,
false,
false,
null,
null,
null,
false,
null,
-1,
-1);
}
}
}
}

private void completiononmethodname(astnode astnode, scope scope) {
if (!this.requestor.isignored(completionproposal.variable_declaration)) {
completiononmethodname method = (completiononmethodname) astnode;

setsourceandtokenrange(method.sourcestart, method.selectorend);

fieldbinding[] fields = scope.enclosingsourcetype().fields();
char[][] excludenames = new char[fields.length][];
for(int i = 0 ; i < fields.length ; i++){
excludenames[i] = fields[i].name;
}

this.completiontoken = method.selector;


int kind =
(method.modifiers & classfileconstants.accstatic) == 0 ?
internalnamingconventions.vk_instance_field :
(method.modifiers & classfileconstants.accfinal) == 0 ?
internalnamingconventions.vk_static_field :
internalnamingconventions.vk_static_final_field;

findvariablenames(this.completiontoken, method.returntype, excludenames, null, kind);
}
}

private void completiononmethodreturntype(astnode astnode, scope scope) {
completiononmethodreturntype method = (completiononmethodreturntype) astnode;
singletypereference type = (completiononsingletypereference) method.returntype;
this.completiontoken = type.token;
setsourceandtokenrange(type.sourcestart, type.sourceend);
findtypesandpackages(this.completiontoken, scope.parent, true, true, new objectvector());
if (!this.requestor.isignored(completionproposal.keyword)) {
findkeywordsformember(this.completiontoken, method.modifiers);
}

if (method.modifiers == classfileconstants.accdefault) {
sourcetypebinding enclosingtype = scope.enclosingsourcetype();
if (!enclosingtype.isannotationtype()) {
if (!this.requestor.isignored(completionproposal.method_declaration)) {
findmethoddeclarations(
this.completiontoken,
scope.enclosingsourcetype(),
scope,
new objectvector(),
null,
null,
null,
false);
}
if (!this.requestor.isignored(completionproposal.potential_method_declaration)) {
proposenewmethod(this.completiontoken, scope.enclosingsourcetype());
}
}
}
}

private void completiononparameterizedqualifiedtypereference(astnode astnode, astnode astnodeparent, binding qualifiedbinding, scope scope) {
if (!this.requestor.isignored(completionproposal.type_ref)) {
completiononparameterizedqualifiedtypereference ref = (completiononparameterizedqualifiedtypereference) astnode;

this.insidequalifiedreference = true;

this.assistnodeisclass = ref.isclass();
this.assistnodeisexception = ref.isexception();
this.assistnodeisinterface = ref.isinterface();
this.assistnodeissupertype = ref.issupertype();
this.assistnodeisextendedtype = assistnodeisextendedtype(astnode, astnodeparent);

this.completiontoken = ref.completionidentifier;
long completionposition = ref.sourcepositions[ref.tokens.length];
setsourceandtokenrange((int) (completionposition >>> 32), (int) completionposition);

if (qualifiedbinding.problemid() == problemreasons.notfound ||
(((referencebinding)qualifiedbinding).tagbits & tagbits.hasmissingtype) != 0) {
if (this.assistnodeinjavadoc == 0 &&
(this.requestor.isallowingrequiredproposals(completionproposal.type_ref, completionproposal.type_ref))) {
if(ref.tokens.length == 1) {
findmembertypesfrommissingtype(
ref,
ref.sourcepositions[0],
scope);
}
}
} else {
objectvector typesfound = new objectvector();
if (this.assistnodeisexception && astnodeparent instanceof trystatement) {
findexceptionfromtrystatement(
this.completiontoken,
(referencebinding)qualifiedbinding,
scope.enclosingsourcetype(),
(blockscope)scope,
typesfound);
}

checkcancel();

findmembertypes(
this.completiontoken,
(referencebinding) qualifiedbinding,
scope,
scope.enclosingsourcetype(),
false,
false,
typesfound,
null,
null,
null,
false);
}
}
}

private boolean assistnodeisextendedtype(astnode astnode, astnode astnodeparent) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=99399, don't propose final types for extension.
if (astnodeparent == null)
return false;
if (astnodeparent instanceof typedeclaration) {
typedeclaration typedeclaration = (typedeclaration) astnodeparent;
return (typedeclaration.superclass == astnode);
} else if (astnodeparent instanceof typeparameter) {
typeparameter typeparameter = (typeparameter) astnodeparent;
return (typeparameter.type == astnode);
} else if (astnodeparent instanceof wildcard) {
wildcard wildcard = (wildcard) astnodeparent;
return (wildcard.bound == astnode && wildcard.kind == wildcard.extends);
}
return false;
}

private void completiononqualifiedallocationexpression(astnode astnode, binding qualifiedbinding, scope scope) {
setsourceandtokenrange(astnode.sourcestart, astnode.sourceend, false);

completiononqualifiedallocationexpression allocexpression =
(completiononqualifiedallocationexpression) astnode;
typebinding[] argtypes = computetypes(allocexpression.arguments);

referencebinding ref = (referencebinding) qualifiedbinding;

if (ref.problemid() == problemreasons.notfound) {
findconstructorsfrommissingtype(
allocexpression.type,
argtypes,
scope,
allocexpression);
} else {
if (!this.requestor.isignored(completionproposal.method_ref)
&& ref.isclass()
&& !ref.isabstract()) {
findconstructors(
ref,
argtypes,
scope,
allocexpression,
false,
null,
null,
null,
false);
}

checkcancel();

if (!this.requestor.isignored(completionproposal.anonymous_class_declaration)
&& !ref.isfinal()
&& !ref.isenum()){
findanonymoustype(
ref,
argtypes,
scope,
allocexpression,
null,
null,
null,
false);
}
}
}

private void completiononqualifiednamereference(astnode astnode, astnode enclosingnode, binding qualifiedbinding,
scope scope, boolean insidetypeannotation) {
this.insidequalifiedreference = true;
completiononqualifiednamereference ref =
(completiononqualifiednamereference) astnode;
this.completiontoken = ref.completionidentifier;
long completionposition = ref.sourcepositions[ref.sourcepositions.length - 1];

if (qualifiedbinding.problemid() == problemreasons.notfound) {
setsourceandtokenrange((int) (completionposition >>> 32), (int) completionposition);
// complete field members with missing fields type
// class x {
//   missing f;
//   void foo() {
//     f.|
//   }
// }
if (this.assistnodeinjavadoc == 0 &&
(this.requestor.isallowingrequiredproposals(completionproposal.field_ref, completionproposal.type_ref) ||
this.requestor.isallowingrequiredproposals(completionproposal.method_ref, completionproposal.type_ref) ||
this.requestor.isallowingrequiredproposals(completionproposal.type_ref, completionproposal.type_ref))) {
if(ref.tokens.length == 1) {
boolean foundsomefields = findfieldsandmethodsfrommissingfieldtype(ref.tokens[0], scope, ref, insidetypeannotation);

if (!foundsomefields) {

checkcancel();

findmembersfrommissingtype(
ref.tokens[0],
ref.sourcepositions[0],
null,
scope,
ref,
ref.isinsideannotationattribute);
}
}
}
} else if (qualifiedbinding instanceof variablebinding) {
setsourceandtokenrange((int) (completionposition >>> 32), (int) completionposition);
typebinding receivertype = ((variablebinding) qualifiedbinding).type;
if (receivertype != null && (receivertype.tagbits & tagbits.hasmissingtype) == 0) {
objectvector fieldsfound = new objectvector();
objectvector methodsfound = new objectvector();

findfieldsandmethods(
this.completiontoken,
receivertype.capture(scope, ref.sourceend),
scope,
fieldsfound,
methodsfound,
ref,
scope,
false,
false,
null,
null,
null,
false,
null,
-1,
-1);

checkcancel();

findfieldsandmethodsfromcastedreceiver(
enclosingnode,
qualifiedbinding,
scope,
fieldsfound,
methodsfound,
ref,
scope,
ref);

} else if (this.assistnodeinjavadoc == 0 &&
(this.requestor.isallowingrequiredproposals(completionproposal.field_ref, completionproposal.type_ref) ||
this.requestor.isallowingrequiredproposals(completionproposal.method_ref, completionproposal.type_ref))) {
boolean proposefield = !this.requestor.isignored(completionproposal.field_ref);
boolean proposemethod = !this.requestor.isignored(completionproposal.method_ref);
if (proposefield || proposemethod) {
if(ref.tokens.length == 1) {
if (qualifiedbinding instanceof localvariablebinding) {
// complete local variable members with missing variables type
// class x {
//   void foo() {
//     missing f;
//     f.|
//   }
// }
localvariablebinding localvariablebinding = (localvariablebinding) qualifiedbinding;
findfieldsandmethodsfrommissingtype(
localvariablebinding.declaration.type,
localvariablebinding.declaringscope,
ref,
scope);
} else {
// complete field members with missing fields type
// class x {
//   missing f;
//   void foo() {
//     f.|
//   }
// }
findfieldsandmethodsfrommissingfieldtype(ref.tokens[0], scope, ref, insidetypeannotation);
}

}
}
}

} else if (qualifiedbinding instanceof referencebinding && !(qualifiedbinding instanceof typevariablebinding)) {
boolean isinsideannotationattribute = ref.isinsideannotationattribute;
referencebinding receivertype = (referencebinding) qualifiedbinding;
setsourceandtokenrange((int) (completionposition >>> 32), (int) completionposition);

findmembers(
this.completiontoken,
receivertype,
scope,
ref,
isinsideannotationattribute,
null,
null,
null,
false);

} else if (qualifiedbinding instanceof packagebinding) {

setsourcerange(astnode.sourcestart, (int) completionposition);
settokenrange((int) (completionposition >>> 32), (int) completionposition);

// replace to the end of the completion identifier
findtypesandsubpackages(this.completiontoken, (packagebinding) qualifiedbinding, scope);
}
}

private void completiononqualifiedtypereference(astnode astnode, astnode astnodeparent, binding qualifiedbinding,
scope scope) {
this.insidequalifiedreference = true;

completiononqualifiedtypereference ref =
(completiononqualifiedtypereference) astnode;

this.assistnodeisclass = ref.isclass();
this.assistnodeisexception = ref.isexception();
this.assistnodeisinterface = ref.isinterface();
this.assistnodeisconstructor = ref.isconstructortype;
this.assistnodeissupertype = ref.issupertype();
this.assistnodeisextendedtype = assistnodeisextendedtype(astnode, astnodeparent);

this.completiontoken = ref.completionidentifier;
long completionposition = ref.sourcepositions[ref.tokens.length];

// get the source positions of the completion identifier
if (qualifiedbinding.problemid() == problemreasons.notfound) {
setsourceandtokenrange((int) (completionposition >>> 32), (int) completionposition);
if (this.assistnodeinjavadoc == 0 &&
(this.requestor.isallowingrequiredproposals(completionproposal.type_ref, completionproposal.type_ref))) {
if(ref.tokens.length == 1) {
findmembertypesfrommissingtype(
ref.tokens[0],
ref.sourcepositions[0],
scope);
}
}
} else if (qualifiedbinding instanceof referencebinding && !(qualifiedbinding instanceof typevariablebinding)) {
if (!this.requestor.isignored(completionproposal.type_ref)) {
setsourceandtokenrange((int) (completionposition >>> 32), (int) completionposition);

objectvector typesfound = new objectvector();

if (this.assistnodeisexception && astnodeparent instanceof trystatement) {
findexceptionfromtrystatement(
this.completiontoken,
(referencebinding)qualifiedbinding,
scope.enclosingsourcetype(),
(blockscope)scope,
typesfound);
}

checkcancel();

findmembertypes(
this.completiontoken,
(referencebinding) qualifiedbinding,
scope,
scope.enclosingsourcetype(),
false,
false,
typesfound,
null,
null,
null,
false);
}
} else if (qualifiedbinding instanceof packagebinding) {

setsourcerange(astnode.sourcestart, (int) completionposition);
settokenrange((int) (completionposition >>> 32), (int) completionposition);
// replace to the end of the completion identifier
findtypesandsubpackages(this.completiontoken, (packagebinding) qualifiedbinding, scope);
}
}

private void completiononsinglenamereference(astnode astnode, astnode astnodeparent, scope scope,
boolean insidetypeannotation) {
completiononsinglenamereference singlenamereference = (completiononsinglenamereference) astnode;
this.completiontoken = singlenamereference.token;
switchstatement switchstatement = astnodeparent instanceof switchstatement ? (switchstatement) astnodeparent : null;
if (switchstatement != null
&& switchstatement.expression.resolvedtype != null
&& switchstatement.expression.resolvedtype.isenum()) {
if (!this.requestor.isignored(completionproposal.field_ref)) {
this.assistnodeisenum = true;
findenumconstantsfromswithstatement(this.completiontoken, (switchstatement) astnodeparent);
}
} else if (this.expectedtypesptr > -1 && this.expectedtypes[0].isannotationtype()) {
findtypesandpackages(this.completiontoken, scope, false, false, new objectvector());
} else {
if (this.expectedtypesptr > -1) {
this.assistnodeisenum = true;
done : for (int i = 0; i <= this.expectedtypesptr; i++) {
if (!this.expectedtypes[i].isenum()) {
this.assistnodeisenum = false;
break done;
}
}

}
if (scope instanceof blockscope && !this.requestor.isignored(completionproposal.local_variable_ref)) {
char[][] alreadydefinedname = computealreadydefinedname((blockscope)scope, singlenamereference);

findunresolvedreference(
singlenamereference.sourcestart,
singlenamereference.sourceend,
(blockscope)scope,
alreadydefinedname);
}

checkcancel();

findvariablesandmethods(
this.completiontoken,
scope,
singlenamereference,
scope,
insidetypeannotation,
singlenamereference.isinsideannotationattribute);

checkcancel();

// can be the start of a qualified type name
findtypesandpackages(this.completiontoken, scope, true, false, new objectvector());
if (!this.requestor.isignored(completionproposal.keyword)) {
if (this.completiontoken != null && this.completiontoken.length != 0) {
findkeywords(this.completiontoken, singlenamereference.possiblekeywords, false, false);
} else {
findtrueorfalsekeywords(singlenamereference.possiblekeywords);
}
}
if (singlenamereference.canbeexplicitconstructor && !this.requestor.isignored(completionproposal.method_ref)){
if (charoperation.prefixequals(this.completiontoken, keywords.this, false)) {
referencebinding ref = scope.enclosingsourcetype();
findexplicitconstructors(keywords.this, ref, (methodscope)scope, singlenamereference);
} else if (charoperation.prefixequals(this.completiontoken, keywords.super, false)) {
referencebinding ref = scope.enclosingsourcetype();
findexplicitconstructors(keywords.super, ref.superclass(), (methodscope)scope, singlenamereference);
}
}
}
}

private void completiononsingletypereference(astnode astnode, astnode astnodeparent, binding qualifiedbinding, scope scope) {
completiononsingletypereference singleref = (completiononsingletypereference) astnode;

this.completiontoken = singleref.token;

this.assistnodeisclass = singleref.isclass();
this.assistnodeisexception = singleref.isexception();
this.assistnodeisinterface = singleref.isinterface();
this.assistnodeisconstructor = singleref.isconstructortype;
this.assistnodeissupertype = singleref.issupertype();
this.assistnodeisextendedtype = assistnodeisextendedtype(astnode, astnodeparent);

// can be the start of a qualified type name
if (qualifiedbinding == null) {
if (this.completiontoken.length == 0 &&
(astnodeparent instanceof parameterizedsingletypereference ||
astnodeparent instanceof parameterizedqualifiedtypereference)) {
this.setsourceandtokenrange(astnode.sourcestart, astnode.sourcestart - 1, false);

findparameterizedtype((typereference)astnodeparent, scope);
} else {
objectvector typesfound = new objectvector();
if (this.assistnodeisexception && astnodeparent instanceof trystatement) {
findexceptionfromtrystatement(
this.completiontoken,
null,
scope.enclosingsourcetype(),
(blockscope)scope,
typesfound);
}

checkcancel();

findtypesandpackages(this.completiontoken, scope, this.assistnodeisconstructor, false, typesfound);
}
} else if (!this.requestor.isignored(completionproposal.type_ref)) {
findmembertypes(
this.completiontoken,
(referencebinding) qualifiedbinding,
scope,
scope.enclosingsourcetype(),
false,
false,
false,
false,
!this.assistnodeisconstructor,
null,
new objectvector(),
null,
null,
null,
false);
}
}

private char[][] computealreadydefinedname(
blockscope scope,
invocationsite invocationsite) {
arraylist result = new arraylist();

boolean staticsonly = false;

scope currentscope = scope;

done1 : while (true) { // done when a compilation_unit_scope is found

switch (currentscope.kind) {

case scope.method_scope :
// handle the error case inside an explicit constructor call (see methodscope>>findfield)
methodscope methodscope = (methodscope) currentscope;
staticsonly |= methodscope.isstatic | methodscope.isconstructorcall;

//$fall-through$
case scope.block_scope :
blockscope blockscope = (blockscope) currentscope;

next : for (int i = 0, length = blockscope.locals.length; i < length; i++) {
localvariablebinding local = blockscope.locals[i];

if (local == null)
break next;

if (local.issecret())
continue next;

result.add(local.name);
}
break;

case scope.class_scope :
classscope classscope = (classscope) currentscope;
sourcetypebinding enclosingtype = classscope.referencecontext.binding;
computealreadydefinedname(
enclosingtype,
classscope,
staticsonly,
invocationsite,
result);
staticsonly |= enclosingtype.isstatic();
break;

case scope.compilation_unit_scope :
break done1;
}
currentscope = currentscope.parent;
}

if (result.size() == 0) return charoperation.no_char_char;

return (char[][])result.toarray(new char[result.size()][]);
}

private void computealreadydefinedname(
fieldbinding[] fields,
scope scope,
boolean onlystaticfields,
referencebinding receivertype,
invocationsite invocationsite,
arraylist result) {

next : for (int f = fields.length; --f >= 0;) {
fieldbinding field = fields[f];

if (field.issynthetic()) continue next;

if (onlystaticfields && !field.isstatic()) continue next;

if (!field.canbeseenby(receivertype, invocationsite, scope)) continue next;

result.add(field.name);
}
}

private void computealreadydefinedname(
sourcetypebinding receivertype,
classscope scope,
boolean onlystaticfields,
invocationsite invocationsite,
arraylist result) {

referencebinding currenttype = receivertype;
referencebinding[] interfacestovisit = null;
int nextposition = 0;
do {
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}

fieldbinding[] fields = currenttype.availablefields();
if(fields != null && fields.length > 0) {
computealreadydefinedname(
fields,
scope,
onlystaticfields,
receivertype,
invocationsite,
result);
}
currenttype = currenttype.superclass();
} while ( currenttype != null);

if (interfacestovisit != null) {
for (int i = 0; i < nextposition; i++) {
referencebinding aninterface = interfacestovisit[i];
fieldbinding[] fields = aninterface.availablefields();
if(fields !=  null) {
computealreadydefinedname(
fields,
scope,
onlystaticfields,
receivertype,
invocationsite,
result);
}

referencebinding[] itsinterfaces = aninterface.superinterfaces();
if (itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
}

int computebaserelevance(){
return r_default;
}

private void computeexpectedtypes(astnode parent, astnode node, scope scope){

// default filter
this.expectedtypesfilter = subtype;
this.hasjavalangobjectasexpectedtype = false;

// find types from parent
if(parent instanceof abstractvariabledeclaration && !(parent instanceof typeparameter)) {
abstractvariabledeclaration variable = (abstractvariabledeclaration)parent;
typebinding binding = variable.type.resolvedtype;
if(binding != null) {
if(!(variable.initialization instanceof arrayinitializer)) {
addexpectedtype(binding, scope);
}
}
} else if(parent instanceof assignment) {
typebinding binding = ((assignment)parent).lhs.resolvedtype;
if(binding != null) {
addexpectedtype(binding, scope);
}
} else if(parent instanceof returnstatement) {
if(scope.methodscope().referencecontext instanceof abstractmethoddeclaration) {
methodbinding methodbinding = ((abstractmethoddeclaration) scope.methodscope().referencecontext).binding;
typebinding binding = methodbinding  == null ? null : methodbinding.returntype;
if(binding != null) {
addexpectedtype(binding, scope);
}
}
} else if(parent instanceof castexpression) {
expression e = ((castexpression)parent).type;
typebinding binding = e.resolvedtype;
if(binding != null){
addexpectedtype(binding, scope);
this.expectedtypesfilter = subtype | supertype;
}
} else if(parent instanceof messagesend) {
messagesend messagesend = (messagesend) parent;

if(messagesend.actualreceivertype instanceof referencebinding) {
referencebinding binding = (referencebinding)messagesend.actualreceivertype;
boolean isstatic = messagesend.receiver.istypereference();

while(binding != null) {
computeexpectedtypesformessagesend(
binding,
messagesend.selector,
messagesend.arguments,
(referencebinding)messagesend.actualreceivertype,
scope,
messagesend,
isstatic);
computeexpectedtypesformessagesendforinterface(
binding,
messagesend.selector,
messagesend.arguments,
(referencebinding)messagesend.actualreceivertype,
scope,
messagesend,
isstatic);
binding = binding.superclass();
}
}
} else if(parent instanceof allocationexpression) {
allocationexpression allocationexpression = (allocationexpression) parent;

referencebinding binding = (referencebinding)allocationexpression.type.resolvedtype;

if(binding != null) {
computeexpectedtypesforallocationexpression(
binding,
allocationexpression.arguments,
scope,
allocationexpression);
}
} else if(parent instanceof operatorexpression) {
int operator = (parent.bits & astnode.operatormask) >> astnode.operatorshift;
if(parent instanceof conditionalexpression) {
// for future use
} else if(parent instanceof instanceofexpression) {
instanceofexpression e = (instanceofexpression) parent;
typebinding binding = e.expression.resolvedtype;
if(binding != null){
addexpectedtype(binding, scope);
this.expectedtypesfilter = subtype | supertype;
}
} else if(parent instanceof binaryexpression) {
binaryexpression binaryexpression = (binaryexpression) parent;
switch(operator) {
case operatorids.equal_equal :
// expected type is not relevant in this case
typebinding binding = binaryexpression.left.resolvedtype;
if (binding != null) {
addexpectedtype(binding, scope);
this.expectedtypesfilter = subtype | supertype;
}
break;
case operatorids.plus :
addexpectedtype(typebinding.short, scope);
addexpectedtype(typebinding.int, scope);
addexpectedtype(typebinding.long, scope);
addexpectedtype(typebinding.float, scope);
addexpectedtype(typebinding.double, scope);
addexpectedtype(typebinding.char, scope);
addexpectedtype(typebinding.byte, scope);
addexpectedtype(scope.getjavalangstring(), scope);
break;
case operatorids.and_and :
case operatorids.or_or :
case operatorids.xor :
addexpectedtype(typebinding.boolean, scope);
break;
default :
addexpectedtype(typebinding.short, scope);
addexpectedtype(typebinding.int, scope);
addexpectedtype(typebinding.long, scope);
addexpectedtype(typebinding.float, scope);
addexpectedtype(typebinding.double, scope);
addexpectedtype(typebinding.char, scope);
addexpectedtype(typebinding.byte, scope);
break;
}
if(operator == operatorids.less) {
if(binaryexpression.left instanceof singlenamereference){
singlenamereference name = (singlenamereference) binaryexpression.left;
binding b = scope.getbinding(name.token, binding.variable | binding.type, name, false);
if(b instanceof referencebinding) {
typevariablebinding[] typevariablebindings =((referencebinding)b).typevariables();
if(typevariablebindings != null && typevariablebindings.length > 0) {
addexpectedtype(typevariablebindings[0].firstbound, scope);
}

}
}
}
} else if(parent instanceof unaryexpression) {
switch(operator) {
case operatorids.not :
addexpectedtype(typebinding.boolean, scope);
break;
case operatorids.twiddle :
addexpectedtype(typebinding.short, scope);
addexpectedtype(typebinding.int, scope);
addexpectedtype(typebinding.long, scope);
addexpectedtype(typebinding.char, scope);
addexpectedtype(typebinding.byte, scope);
break;
case operatorids.plus :
case operatorids.minus :
case operatorids.plus_plus :
case operatorids.minus_minus :
addexpectedtype(typebinding.short, scope);
addexpectedtype(typebinding.int, scope);
addexpectedtype(typebinding.long, scope);
addexpectedtype(typebinding.float, scope);
addexpectedtype(typebinding.double, scope);
addexpectedtype(typebinding.char, scope);
addexpectedtype(typebinding.byte, scope);
break;
}
}
} else if(parent instanceof arrayreference) {
addexpectedtype(typebinding.short, scope);
addexpectedtype(typebinding.int, scope);
addexpectedtype(typebinding.long, scope);
} else if(parent instanceof parameterizedsingletypereference) {
parameterizedsingletypereference ref = (parameterizedsingletypereference) parent;
typevariablebinding[] typevariables = ((referencebinding)ref.resolvedtype).typevariables();
int length = ref.typearguments == null ? 0 : ref.typearguments.length;
if(typevariables != null && typevariables.length >= length) {
int index = length - 1;
while(index > -1 && ref.typearguments[index] != node) index--;

typebinding bound = typevariables[index].firstbound;
addexpectedtype(bound == null ? scope.getjavalangobject() : bound, scope);
}
} else if(parent instanceof parameterizedqualifiedtypereference) {
parameterizedqualifiedtypereference ref = (parameterizedqualifiedtypereference) parent;
typevariablebinding[] typevariables = ((referencebinding)ref.resolvedtype).typevariables();
typereference[][] arguments = ref.typearguments;
if(typevariables != null) {
int ilength = arguments == null ? 0 : arguments.length;
done: for (int i = 0; i < ilength; i++) {
int jlength = arguments[i] == null ? 0 : arguments[i].length;
for (int j = 0; j < jlength; j++) {
if(arguments[i][j] == node && typevariables.length > j) {
typebinding bound = typevariables[j].firstbound;
addexpectedtype(bound == null ? scope.getjavalangobject() : bound, scope);
break done;
}
}
}
}
} else if(parent instanceof membervaluepair) {
membervaluepair membervaluepair = (membervaluepair) parent;
if(membervaluepair.binding != null) {
addexpectedtype(membervaluepair.binding.returntype, scope);
}
} else if (parent instanceof normalannotation) {
normalannotation annotation = (normalannotation) parent;
membervaluepair[] membervaluepairs = annotation.membervaluepairs();
if(membervaluepairs == null || membervaluepairs.length == 0) {
if(annotation.resolvedtype instanceof referencebinding) {
methodbinding[] methodbindings =
((referencebinding)annotation.resolvedtype).availablemethods();
if (methodbindings != null &&
methodbindings.length > 0 &&
charoperation.equals(methodbindings[0].selector, value)) {
boolean canbesinglememberannotation = true;
done : for (int i = 1; i < methodbindings.length; i++) {
if((methodbindings[i].modifiers & classfileconstants.accannotationdefault) == 0) {
canbesinglememberannotation = false;
break done;
}
}
if (canbesinglememberannotation) {
this.assistnodecanbesinglememberannotation = canbesinglememberannotation;
addexpectedtype(methodbindings[0].returntype, scope);
}
}
}
}
} else if (parent instanceof trystatement) {
boolean isexception = false;
if (node instanceof completiononsingletypereference) {
isexception = ((completiononsingletypereference)node).isexception();
} else if (node instanceof completiononqualifiedtypereference) {
isexception = ((completiononqualifiedtypereference)node).isexception();
} else if (node instanceof completiononparameterizedqualifiedtypereference) {
isexception = ((completiononparameterizedqualifiedtypereference)node).isexception();
}
if (isexception) {
thrownexceptionfinder thrownexceptionfinder = new thrownexceptionfinder();
referencebinding[] bindings = thrownexceptionfinder.find((trystatement) parent, (blockscope)scope);
if (bindings != null && bindings.length > 0) {
for (int i = 0; i < bindings.length; i++) {
addexpectedtype(bindings[i], scope);
}
this.expectedtypesfilter = supertype;
}
}
} else if (parent instanceof switchstatement) {
switchstatement switchstatement = (switchstatement) parent;
if (switchstatement.expression != null &&
switchstatement.expression.resolvedtype != null) {
addexpectedtype(switchstatement.expression.resolvedtype, scope);
}
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=253008, flag boolean as the expected
// type if we are completing inside if(), for (; ;), while() and do while()
} else if (parent instanceof whilestatement) {  // covers both while and do-while loops
addexpectedtype(typebinding.boolean, scope);
} else if (parent instanceof ifstatement) {
addexpectedtype(typebinding.boolean, scope);
} else if (parent instanceof assertstatement) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=274466
// if the assertexpression is same as the node , then the assistnode is the conditional part of the assert statement
assertstatement assertstatement = (assertstatement) parent;
if (assertstatement.assertexpression == node) {
addexpectedtype(typebinding.boolean, scope);
}
} else if (parent instanceof forstatement) {   // astnodeparent set to forstatement only for the condition
addexpectedtype(typebinding.boolean, scope);

// expected types for javadoc
} else if (parent instanceof javadoc) {
if (scope.kind == scope.method_scope) {
methodscope methodscope = (methodscope) scope;
abstractmethoddeclaration methoddecl = methodscope.referencemethod();
if (methoddecl != null && methoddecl.binding != null) {
referencebinding[] exceptions = methoddecl.binding.thrownexceptions;
if (exceptions != null) {
for (int i = 0; i < exceptions.length; i++) {
addexpectedtype(exceptions[i], scope);
}
}
}
}
}

if(this.expectedtypesptr + 1 != this.expectedtypes.length) {
system.arraycopy(this.expectedtypes, 0, this.expectedtypes = new typebinding[this.expectedtypesptr + 1], 0, this.expectedtypesptr + 1);
}
}

private void computeexpectedtypesforallocationexpression(
referencebinding binding,
expression[] arguments,
scope scope,
invocationsite invocationsite) {

methodbinding[] methods = binding.availablemethods();
nextmethod : for (int i = 0; i < methods.length; i++) {
methodbinding method = methods[i];

if (!method.isconstructor()) continue nextmethod;

if (method.issynthetic()) continue nextmethod;

if (this.options.checkvisibility && !method.canbeseenby(invocationsite, scope)) continue nextmethod;

typebinding[] parameters = method.parameters;
if(parameters.length < arguments.length)
continue nextmethod;

int length = arguments.length - 1;

for (int j = 0; j < length; j++) {
expression argument = arguments[j];
typebinding argtype = argument.resolvedtype;
if(argtype != null && !argtype.iscompatiblewith(parameters[j]))
continue nextmethod;
}

typebinding expectedtype = method.parameters[arguments.length - 1];
if(expectedtype != null) {
addexpectedtype(expectedtype, scope);
}
}
}
private void computeexpectedtypesformessagesend(
referencebinding binding,
char[] selector,
expression[] arguments,
referencebinding receivertype,
scope scope,
invocationsite invocationsite,
boolean isstatic) {

methodbinding[] methods = binding.availablemethods();
nextmethod : for (int i = 0; i < methods.length; i++) {
methodbinding method = methods[i];

if (method.issynthetic()) continue nextmethod;

if (method.isdefaultabstract())	continue nextmethod;

if (method.isconstructor()) continue nextmethod;

if (isstatic && !method.isstatic()) continue nextmethod;

if (this.options.checkvisibility && !method.canbeseenby(receivertype, invocationsite, scope)) continue nextmethod;

if(!charoperation.equals(method.selector, selector)) continue nextmethod;

typebinding[] parameters = method.parameters;
if(parameters.length < arguments.length)
continue nextmethod;

int length = arguments.length - 1;

for (int j = 0; j < length; j++) {
expression argument = arguments[j];
typebinding argtype = argument.resolvedtype;
if(argtype != null && !argtype.iscompatiblewith(parameters[j]))
continue nextmethod;
}

typebinding expectedtype = method.parameters[arguments.length - 1];
if(expectedtype != null) {
addexpectedtype(expectedtype, scope);
}
}
}
private void computeexpectedtypesformessagesendforinterface(
referencebinding binding,
char[] selector,
expression[] arguments,
referencebinding receivertype,
scope scope,
invocationsite invocationsite,
boolean isstatic) {

referencebinding[] itsinterfaces = binding.superinterfaces();
if (itsinterfaces != binding.no_superinterfaces) {
referencebinding[] interfacestovisit = itsinterfaces;
int nextposition = interfacestovisit.length;

for (int i = 0; i < nextposition; i++) {
referencebinding currenttype = interfacestovisit[i];
computeexpectedtypesformessagesend(
currenttype,
selector,
arguments,
receivertype,
scope,
invocationsite,
isstatic);

if ((itsinterfaces = currenttype.superinterfaces()) != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
}

private scope computeforbiddenbindings(astnode astnode, astnode astnodeparent, scope scope) {
this.forbbidenbindingsfilter = none;
if(scope instanceof classscope) {
typedeclaration typedeclaration = ((classscope)scope).referencecontext;
if(typedeclaration.superclass == astnode) {
addforbiddenbindings(typedeclaration.binding);
addforbiddenbindingsformembertypes(typedeclaration);
return scope.parent;
}
typereference[] superinterfaces = typedeclaration.superinterfaces;
int length = superinterfaces == null ? 0 : superinterfaces.length;
int astnodeindex = -1;
for (int i = 0; i < length; i++) {
if(superinterfaces[i] == astnode) {
addforbiddenbindings(typedeclaration.binding);
addforbiddenbindingsformembertypes(typedeclaration);
astnodeindex = i;
break;
}
}
if (astnodeindex >= 0) {
// need to loop only up to astnodeindex as the rest will be undefined.
for (int i = 0; i < astnodeindex; i++) {
addforbiddenbindings(superinterfaces[i].resolvedtype);
}
return scope.parent;
}
} else {
if (astnodeparent != null && astnodeparent instanceof trystatement) {
boolean isexception = false;
if (astnode instanceof completiononsingletypereference) {
isexception = ((completiononsingletypereference)astnode).isexception();
} else if (astnode instanceof completiononqualifiedtypereference) {
isexception = ((completiononqualifiedtypereference)astnode).isexception();
} else if (astnode instanceof completiononparameterizedqualifiedtypereference) {
isexception = ((completiononparameterizedqualifiedtypereference)astnode).isexception();
}
if (isexception) {
argument[] catcharguments = ((trystatement) astnodeparent).catcharguments;
int length = catcharguments == null ? 0 : catcharguments.length;
for (int i = 0; i < length; i++) {
typebinding caughtexception = catcharguments[i].type.resolvedtype;
if (caughtexception != null) {
addforbiddenbindings(caughtexception);
this.knowntypes.put(charoperation.concat(caughtexception.qualifiedpackagename(), caughtexception.qualifiedsourcename(), '.'), known_type_with_known_constructors);
}
}
this.forbbidenbindingsfilter = subtype;
}
}
}
//		else if(scope instanceof methodscope) {
//			methodscope methodscope = (methodscope) scope;
//			if(methodscope.insidetypeannotation) {
//				return methodscope.parent.parent;
//			}
//		}
return scope;
}

// https://bugs.eclipse.org/bugs/show_bug.cgi?id=270437
private void addforbiddenbindingsformembertypes(typedeclaration typedeclaration) {
typedeclaration[] membertypes = typedeclaration.membertypes;
int membertypeslen = membertypes == null ? 0 : membertypes.length;
for (int i = 0; i < membertypeslen; i++) {
addforbiddenbindings(membertypes[i].binding);
addforbiddenbindingsformembertypes(membertypes[i]);
}
}

private char[] computeprefix(sourcetypebinding declarationtype, sourcetypebinding invocationtype, boolean isstatic){

stringbuffer completion = new stringbuffer(10);

if (isstatic) {
completion.append(declarationtype.sourcename());

} else if (declarationtype == invocationtype) {
completion.append(this);

} else {

if (!declarationtype.isnestedtype()) {

completion.append(declarationtype.sourcename());
completion.append('.');
completion.append(this);

} else if (!declarationtype.isanonymoustype()) {

completion.append(declarationtype.sourcename());
completion.append('.');
completion.append(this);

}
}

return completion.tostring().tochararray();
}

private int computerelevanceforannotation(){
if(this.assistnodeisannotation) {
return r_annotation;
}
return 0;
}

private int computerelevanceforannotationtarget(typebinding typebinding){
if (this.assistnodeisannotation &&
(this.targetedelement & tagbits.annotationtargetmask) != 0) {
long target = typebinding.getannotationtagbits() & tagbits.annotationtargetmask;
if(target == 0 || (target & this.targetedelement) != 0) {
return r_target;
}
}
return 0;
}
int computerelevanceforcasematching(char[] token, char[] proposalname){
if (this.options.camelcasematch) {
if(charoperation.equals(token, proposalname, true /* do not ignore case */)) {
return r_case + r_exact_name;
} else if (charoperation.prefixequals(token, proposalname, true /* do not ignore case */)) {
return r_case;
} else if (charoperation.camelcasematch(token, proposalname)){
return r_camel_case;
} else if(charoperation.equals(token, proposalname, false /* ignore case */)) {
return r_exact_name;
}
} else if (charoperation.prefixequals(token, proposalname, true /* do not ignore case */)) {
if(charoperation.equals(token, proposalname, true /* do not ignore case */)) {
return r_case + r_exact_name;
} else {
return r_case;
}
} else if(charoperation.equals(token, proposalname, false /* ignore case */)) {
return r_exact_name;
}
return 0;
}

private int computerelevanceforclass(){
if(this.assistnodeisclass) {
return r_class;
}
return 0;
}

private int computerelevanceforenum(){
if(this.assistnodeisenum) {
return r_enum;
}
return 0;
}

private int computerelevanceforenumconstant(typebinding proposaltype){
if(this.assistnodeisenum &&
proposaltype != null &&
this.expectedtypes != null) {
for (int i = 0; i <= this.expectedtypesptr; i++) {
if (proposaltype.isenum() &&
proposaltype == this.expectedtypes[i]) {
return r_enum + r_enum_constant;
}

}
}
return 0;
}

private int computerelevanceforexception(){
if (this.assistnodeisexception) {
return r_exception;
}
return 0;
}

private int computerelevanceforexception(char[] proposalname){

if((this.assistnodeisexception || (this.assistnodeinjavadoc & completiononjavadoc.exception) != 0 )&&
(charoperation.match(exception_pattern, proposalname, false) ||
charoperation.match(error_pattern, proposalname, false))) {
return r_exception;
}
return 0;
}

private int computerelevanceforexpectingtype(char[] packagename, char[] typename){
if(this.expectedtypes != null) {
for (int i = 0; i <= this.expectedtypesptr; i++) {
if(charoperation.equals(this.expectedtypes[i].qualifiedpackagename(), packagename) &&
charoperation.equals(this.expectedtypes[i].qualifiedsourcename(), typename)) {
return r_exact_expected_type;
}
}
if(this.hasjavalangobjectasexpectedtype) {
return r_expected_type;
}
}
return 0;
}

private int computerelevanceforexpectingtype(typebinding proposaltype){
if(this.expectedtypes != null && proposaltype != null) {
int relevance = 0;
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=271296
// if there is at least one expected type, then void proposal types attract a degraded relevance.
if (proposaltype == typebinding.void && this.expectedtypesptr >=0) {
return r_void;
}
for (int i = 0; i <= this.expectedtypesptr; i++) {
if((this.expectedtypesfilter & subtype) != 0
&& proposaltype.iscompatiblewith(this.expectedtypes[i])) {

if(charoperation.equals(this.expectedtypes[i].qualifiedpackagename(), proposaltype.qualifiedpackagename()) &&
charoperation.equals(this.expectedtypes[i].qualifiedsourcename(), proposaltype.qualifiedsourcename())) {
return r_exact_expected_type;
}

relevance = r_expected_type;
}
if((this.expectedtypesfilter & supertype) != 0
&& this.expectedtypes[i].iscompatiblewith(proposaltype)) {

if(charoperation.equals(this.expectedtypes[i].qualifiedpackagename(), proposaltype.qualifiedpackagename()) &&
charoperation.equals(this.expectedtypes[i].qualifiedsourcename(), proposaltype.qualifiedsourcename())) {
return r_exact_expected_type;
}

relevance = r_expected_type;
}
// bug 84720 - [1.5][assist] proposal ranking by return value should consider auto(un)boxing
// just ensuring that the unitscope is not null, even though it's an unlikely case.
if (this.unitscope != null && this.unitscope.isboxingcompatiblewith(proposaltype, this.expectedtypes[i])) {
relevance = r_expected_type;
}
}
return relevance;
}
return 0;
}

private int computerelevanceforinheritance(referencebinding receivertype, referencebinding declaringclass) {
if (receivertype == declaringclass) return r_non_inherited;
return 0;
}

int computerelevanceforinterestingproposal(){
return computerelevanceforinterestingproposal(null);
}

private int computerelevanceforinterestingproposal(binding binding){
if(this.uninterestingbindings != null) {
for (int i = 0; i <= this.uninterestingbindingsptr; i++) {
if(this.uninterestingbindings[i] == binding) {
return 0;
}
}
}
return r_interesting;
}

private int computerelevanceforinterface(){
if(this.assistnodeisinterface) {
return r_interface;
}
return 0;
}

private int computerelevanceformissingelements(boolean hasproblems) {
if (!hasproblems) {
return r_no_problems;
}
return 0;
}
int computerelevanceforqualification(boolean prefixrequired) {
if(!prefixrequired && !this.insidequalifiedreference) {
return r_unqualified;
}

if(prefixrequired && this.insidequalifiedreference) {
return r_qualified;
}
return 0;
}

int computerelevanceforresolution(){
return computerelevanceforresolution(true);
}

int computerelevanceforresolution(boolean isresolved){
if (isresolved) {
return r_resolved;
}
return 0;
}

int computerelevanceforrestrictions(int accessrulekind) {
if(accessrulekind == iaccessrule.k_accessible) {
return r_non_restricted;
}
return 0;
}

private int computerelevanceforstatic(boolean onlystatic, boolean isstatic) {
if(this.insidequalifiedreference && !onlystatic && !isstatic) {
return r_non_static;
}
return 0;
}

private long computetargetedelement(completiononannotationoftype fakenode) {
astnode annotatedelement = fakenode.potentialannotatednode;

if (annotatedelement instanceof typedeclaration) {
typedeclaration annotatedtypedeclaration = (typedeclaration) annotatedelement;
if (typedeclaration.kind(annotatedtypedeclaration.modifiers) == typedeclaration.annotation_type_decl) {
return tagbits.annotationforannotationtype | tagbits.annotationfortype;
}
return tagbits.annotationfortype;
} else if (annotatedelement instanceof fielddeclaration) {
if (fakenode.isparameter) {
return tagbits.annotationforparameter;
}
return tagbits.annotationforfield;
} else if (annotatedelement instanceof methoddeclaration) {
return tagbits.annotationformethod;
} else if (annotatedelement instanceof argument) {
return tagbits.annotationforparameter;
} else if (annotatedelement instanceof constructordeclaration) {
return tagbits.annotationforconstructor;
} else if (annotatedelement instanceof localdeclaration) {
return tagbits.annotationforlocalvariable;
} else if (annotatedelement instanceof importreference) {
return tagbits.annotationforpackage;
}
return 0;
}
private typebinding[] computetypes(expression[] arguments) {
if (arguments == null) return null;
int argslength = arguments.length;
typebinding[] argtypes = new typebinding[argslength];
for (int a = argslength; --a >= 0;) {
argtypes[a] = arguments[a].resolvedtype;
}
return argtypes;
}

private typebinding[] computetypesifcorrect(expression[] arguments) {
if (arguments == null) return null;
int argslength = arguments.length;
typebinding[] argtypes = new typebinding[argslength];
for (int a = argslength; --a >= 0;) {
typebinding typebinding = arguments[a].resolvedtype;
if(typebinding == null || !typebinding.isvalidbinding()) return null;
argtypes[a] = typebinding;
}
return argtypes;
}

private void computeuninterestingbindings(astnode parent, scope scope){
if(parent instanceof localdeclaration) {
adduninterestingbindings(((localdeclaration)parent).binding);
} else if (parent instanceof fielddeclaration) {
adduninterestingbindings(((fielddeclaration)parent).binding);
}
}

private char[] createimportchararray(char[] importedelement, boolean isstatic, boolean ondemand) {
char[] result = import;
if (isstatic) {
result = charoperation.concat(result, static, ' ');
}
result = charoperation.concat(result, importedelement, ' ');
if (ondemand) {
result = charoperation.concat(result, on_demand);
}
return charoperation.concat(result, import_end);
}

private void createmethod(methodbinding method, char[][] parameterpackagenames, char[][] parametertypenames, char[][] parameternames, scope scope, stringbuffer completion) {
//// modifiers
// flush uninteresting modifiers
int insertedmodifiers = method.modifiers & ~(classfileconstants.accnative | classfileconstants.accabstract);
if(insertedmodifiers != classfileconstants.accdefault){
astnode.printmodifiers(insertedmodifiers, completion);
}

//// type parameters

typevariablebinding[] typevariablebindings = method.typevariables;
if(typevariablebindings != null && typevariablebindings.length != 0) {
completion.append('<');
for (int i = 0; i < typevariablebindings.length; i++) {
if(i != 0) {
completion.append(',');
completion.append(' ');
}
createtypevariable(typevariablebindings[i], scope, completion);
}
completion.append('>');
completion.append(' ');
}

//// return type
createtype(method.returntype, scope, completion);
completion.append(' ');

//// selector
completion.append(method.selector);

completion.append('(');

////parameters
typebinding[] parametertypes = method.parameters;
int length = parametertypes.length;
for (int i = 0; i < length; i++) {
if(i != 0) {
completion.append(',');
completion.append(' ');
}
createtype(parametertypes[i], scope, completion);
completion.append(' ');
if(parameternames != null){
completion.append(parameternames[i]);
} else {
completion.append('%');
}
}

completion.append(')');

//// exceptions
referencebinding[] exceptions = method.thrownexceptions;

if (exceptions != null && exceptions.length > 0){
completion.append(' ');
completion.append(throws);
completion.append(' ');
for(int i = 0; i < exceptions.length ; i++){
if(i != 0) {
completion.append(' ');
completion.append(',');
}
createtype(exceptions[i], scope, completion);
}
}
}

protected internalcompletionproposal createproposal(int kind, int completionoffset) {
internalcompletionproposal proposal = (internalcompletionproposal) completionproposal.create(kind, completionoffset - this.offset);
proposal.namelookup = this.nameenvironment.namelookup;
proposal.completionengine = this;
return proposal;
}

private completionproposal createrequiredtypeproposal(binding binding, int start, int end, int relevance) {
internalcompletionproposal proposal = null;
if (binding instanceof referencebinding) {
referencebinding typebinding = (referencebinding) binding;

char[] packagename = typebinding.qualifiedpackagename();
char[] typename = typebinding.qualifiedsourcename();
char[] fullyqualifiedname = charoperation.concat(packagename, typename, '.');

proposal = createproposal(completionproposal.type_ref, this.actualcompletionposition);
proposal.namelookup = this.nameenvironment.namelookup;
proposal.completionengine = this;
proposal.setdeclarationsignature(packagename);
proposal.setsignature(getrequiredtypesignature(typebinding));
proposal.setpackagename(packagename);
proposal.settypename(typename);
proposal.setcompletion(fullyqualifiedname);
proposal.setflags(typebinding.modifiers);
proposal.setreplacerange(start - this.offset, end - this.offset);
proposal.settokenrange(start - this.offset, end - this.offset);
proposal.setrelevance(relevance);
} else if (binding instanceof packagebinding) {
packagebinding packagebinding = (packagebinding) binding;

char[] packagename = charoperation.concatwith(packagebinding.compoundname, '.');

proposal = createproposal(completionproposal.package_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(packagename);
proposal.setpackagename(packagename);
proposal.setcompletion(packagename);
proposal.setreplacerange(start - this.offset, end - this.offset);
proposal.settokenrange(start - this.offset, end - this.offset);
proposal.setrelevance(relevance);
}
return proposal;
}

private void createtype(typebinding type, scope scope, stringbuffer completion) {
switch (type.kind()) {
case binding.base_type :
completion.append(type.sourcename());
break;
case binding.wildcard_type :
case binding.intersection_type : // todo (david) need to handle intersection type specifically
wildcardbinding wildcardbinding = (wildcardbinding) type;
completion.append('?');
switch (wildcardbinding.boundkind) {
case wildcard.extends:
completion.append(' ');
completion.append(extends);
completion.append(' ');
createtype(wildcardbinding.bound, scope, completion);
if(wildcardbinding.otherbounds != null) {

int length = wildcardbinding.otherbounds.length;
for (int i = 0; i < length; i++) {
completion.append(' ');
completion.append('&');
completion.append(' ');
createtype(wildcardbinding.otherbounds[i], scope, completion);
}
}
break;
case wildcard.super:
completion.append(' ');
completion.append(super);
completion.append(' ');
createtype(wildcardbinding.bound, scope, completion);
break;
}
break;
case binding.array_type :
createtype(type.leafcomponenttype(), scope, completion);
int dim = type.dimensions();
for (int i = 0; i < dim; i++) {
completion.append('[');
completion.append(']');
}
break;
case binding.parameterized_type :
parameterizedtypebinding parameterizedtype = (parameterizedtypebinding) type;
if (type.ismembertype()) {
createtype(parameterizedtype.enclosingtype(), scope, completion);
completion.append('.');
completion.append(parameterizedtype.sourcename);
} else {
completion.append(charoperation.concatwith(parameterizedtype.generictype().compoundname, '.'));
}
if (parameterizedtype.arguments != null) {
completion.append('<');
for (int i = 0, length = parameterizedtype.arguments.length; i < length; i++) {
if (i != 0) completion.append(',');
createtype(parameterizedtype.arguments[i], scope, completion);
}
completion.append('>');
}
break;
default :
char[] packagename = type.qualifiedpackagename();
char[] typename = type.qualifiedsourcename();
if(mustqualifytype(
(referencebinding)type,
packagename,
scope)) {
completion.append(charoperation.concat(packagename, typename,'.'));
} else {
completion.append(type.sourcename());
}
break;
}
}

/*
* create a completion proposal for a member type.
*/
private void createtypeparameterproposal(typeparameter typeparameter, int relevance) {
char[] completionname = typeparameter.name;

// create standard type proposal
if(!this.requestor.isignored(completionproposal.type_ref)) {
internalcompletionproposal proposal = (internalcompletionproposal) completionproposal.create(completionproposal.type_ref, this.actualcompletionposition - this.offset);
proposal.namelookup = this.nameenvironment.namelookup;
proposal.completionengine = this;
proposal.setsignature(getsignature(typeparameter.binding));
proposal.settypename(completionname);
proposal.setcompletion(completionname);
proposal.setflags(typeparameter.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}

// create javadoc text proposal if necessary
if ((this.assistnodeinjavadoc & completiononjavadoc.text) != 0 && !this.requestor.isignored(completionproposal.javadoc_type_ref)) {
char[] javadoccompletion= inlinetagcompletion(completionname, javadoctagconstants.tag_link);
internalcompletionproposal proposal = (internalcompletionproposal) completionproposal.create(completionproposal.javadoc_type_ref, this.actualcompletionposition - this.offset);
proposal.namelookup = this.nameenvironment.namelookup;
proposal.completionengine = this;
proposal.setsignature(getsignature(typeparameter.binding));
proposal.settypename(javadoccompletion);
proposal.setcompletion(javadoccompletion);
proposal.setflags(typeparameter.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance+r_inline_tag);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}

/*
* create a completion proposal for a type.
*/
private void createtypeproposal(char[] packagename, char[] typename, int modifiers, int accessibility, char[] completionname, int relevance) {

// create standard type proposal
if(!this.requestor.isignored(completionproposal.type_ref) && (this.assistnodeinjavadoc & completiononjavadoc.only_inline_tag) == 0) {
internalcompletionproposal proposal = (internalcompletionproposal) completionproposal.create(completionproposal.type_ref, this.actualcompletionposition - this.offset);
proposal.namelookup = this.nameenvironment.namelookup;
proposal.completionengine = this;
proposal.setdeclarationsignature(packagename);
proposal.setsignature(createnongenerictypesignature(packagename, typename));
proposal.setpackagename(packagename);
proposal.settypename(typename);
proposal.setcompletion(completionname);
proposal.setflags(modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
proposal.setaccessibility(accessibility);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}

// create javadoc text proposal if necessary
if ((this.assistnodeinjavadoc & completiononjavadoc.text) != 0 && !this.requestor.isignored(completionproposal.javadoc_type_ref)) {
char[] javadoccompletion= inlinetagcompletion(completionname, javadoctagconstants.tag_link);
internalcompletionproposal proposal = (internalcompletionproposal) completionproposal.create(completionproposal.javadoc_type_ref, this.actualcompletionposition - this.offset);
proposal.namelookup = this.nameenvironment.namelookup;
proposal.completionengine = this;
proposal.setdeclarationsignature(packagename);
proposal.setsignature(createnongenerictypesignature(packagename, typename));
proposal.setpackagename(packagename);
proposal.settypename(typename);
proposal.setcompletion(javadoccompletion);
proposal.setflags(modifiers);
int start = (this.assistnodeinjavadoc & completiononjavadoc.replace_tag) != 0 ? this.javadoctagposition : this.startposition;
proposal.setreplacerange(start - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance+r_inline_tag);
proposal.setaccessibility(accessibility);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}

/*
* create a completion proposal for a member type.
*/
private void createtypeproposal(
referencebinding refbinding,
char[] typename,
int accessibility,
char[] completionname,
int relevance,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems) {

// create standard type proposal
if(!this.isignored(completionproposal.type_ref, missingelements != null) && (this.assistnodeinjavadoc & completiononjavadoc.only_inline_tag) == 0) {
internalcompletionproposal proposal = (internalcompletionproposal) completionproposal.create(completionproposal.type_ref, this.actualcompletionposition - this.offset);
proposal.namelookup = this.nameenvironment.namelookup;
proposal.completionengine = this;
proposal.setdeclarationsignature(refbinding.qualifiedpackagename());
proposal.setsignature(getcompletedtypesignature(refbinding));
proposal.setpackagename(refbinding.qualifiedpackagename());
proposal.settypename(typename);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(completionname);
proposal.setflags(refbinding.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}

// create javadoc text proposal if necessary
if ((this.assistnodeinjavadoc & completiononjavadoc.text) != 0 && !this.requestor.isignored(completionproposal.javadoc_type_ref)) {
char[] javadoccompletion= inlinetagcompletion(completionname, javadoctagconstants.tag_link);
internalcompletionproposal proposal = (internalcompletionproposal) completionproposal.create(completionproposal.javadoc_type_ref, this.actualcompletionposition - this.offset);
proposal.namelookup = this.nameenvironment.namelookup;
proposal.completionengine = this;
proposal.setdeclarationsignature(refbinding.qualifiedpackagename());
proposal.setsignature(getcompletedtypesignature(refbinding));
proposal.setpackagename(refbinding.qualifiedpackagename());
proposal.settypename(typename);
proposal.setcompletion(javadoccompletion);
proposal.setflags(refbinding.modifiers);
int start = (this.assistnodeinjavadoc & completiononjavadoc.replace_tag) != 0 ? this.javadoctagposition : this.startposition;
proposal.setreplacerange(start - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance+r_inline_tag);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
private void createtypevariable(typevariablebinding typevariable, scope scope, stringbuffer completion) {
completion.append(typevariable.sourcename);

if (typevariable.superclass != null && typevariable.firstbound == typevariable.superclass) {
completion.append(' ');
completion.append(extends);
completion.append(' ');
createtype(typevariable.superclass, scope, completion);
}
if (typevariable.superinterfaces != null && typevariable.superinterfaces != binding.no_superinterfaces) {
if (typevariable.firstbound != typevariable.superclass) {
completion.append(' ');
completion.append(extends);
completion.append(' ');
}
for (int i = 0, length = typevariable.superinterfaces.length; i < length; i++) {
if (i > 0 || typevariable.firstbound == typevariable.superclass) {
completion.append(' ');
completion.append(extends);
completion.append(' ');
}
createtype(typevariable.superinterfaces[i], scope, completion);
}
}
}
private void createvargstype(typebinding type, scope scope, stringbuffer completion) {
if (type.isarraytype()) {
createtype(type.leafcomponenttype(), scope, completion);
int dim = type.dimensions() - 1;
for (int i = 0; i < dim; i++) {
completion.append('[');
completion.append(']');
}
completion.append(varargs);
} else {
createtype(type, scope, completion);
}
}
private void findannotationattributes(char[] token, membervaluepair[] attributesfound, referencebinding annotation) {
methodbinding[] methods = annotation.availablemethods();
nextattribute: for (int i = 0; i < methods.length; i++) {
methodbinding method = methods[i];

if(!charoperation.prefixequals(token, method.selector, false)
&& !(this.options.camelcasematch && charoperation.camelcasematch(token, method.selector))) continue nextattribute;

int length = attributesfound == null ? 0 : attributesfound.length;
for (int j = 0; j < length; j++) {
if(charoperation.equals(method.selector, attributesfound[j].name, false)) continue nextattribute;
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal(method);
relevance += computerelevanceforcasematching(token, method.selector);
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.annotation_attribute_ref)) {
completionproposal proposal = createproposal(completionproposal.annotation_attribute_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(method.declaringclass));
proposal.setsignature(getsignature(method.returntype));
proposal.setname(method.selector);
proposal.setcompletion(method.selector);
proposal.setflags(method.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}
void findanonymoustype(
referencebinding currenttype,
typebinding[] argtypes,
scope scope,
invocationsite invocationsite,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems) {

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

if (missingelements != null) {
relevance += computerelevanceformissingelements(missingelementshaveproblems);
}

findanonymoustype(
currenttype,
argtypes,
scope,
invocationsite,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
true,
false,
relevance);
}
private void findanonymoustype(
referencebinding currenttype,
typebinding[] argtypes,
scope scope,
invocationsite invocationsite,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems,
boolean exactmatch,
boolean isqualified,
int relevance) {

if (currenttype.isinterface()) {
char[] completion = charoperation.no_char;
char[] typecompletion = null;
if (!exactmatch) {
typecompletion =
isqualified ?
charoperation.concat(currenttype.qualifiedpackagename(), currenttype.qualifiedsourcename(), '.') :
currenttype.sourcename();
if (this.source != null
&& this.source.length > this.endposition
&& this.source[this.endposition] == '(') {
completion = charoperation.no_char;
} else {
completion = new char[] { '(', ')' };
}
}

this.noproposal = false;
if (!exactmatch) {
if(!isignored(completionproposal.anonymous_class_constructor_invocation, completionproposal.type_ref)) {
char[] packagename = currenttype.islocaltype() ? null : currenttype.qualifiedpackagename();
char[] typename = currenttype.qualifiedsourcename();

internalcompletionproposal proposal = createproposal(completionproposal.anonymous_class_constructor_invocation, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(currenttype));
proposal.setdeclarationkey(currenttype.computeuniquekey());
proposal.setsignature(
createmethodsignature(
charoperation.no_char_char,
charoperation.no_char_char,
charoperation.no_char,
charoperation.no_char));
//proposal.setoriginalsignature(null);
//proposal.setuniquekey(null);
proposal.setdeclarationpackagename(packagename);
proposal.setdeclarationtypename(typename);
//proposal.setparameterpackagenames(null);
//proposal.setparametertypenames(null);
//proposal.setpackagename(null);
//proposal.settypename(null);
proposal.setname(currenttype.sourcename());

internalcompletionproposal typeproposal = createproposal(completionproposal.type_ref, this.actualcompletionposition);
typeproposal.namelookup = this.nameenvironment.namelookup;
typeproposal.completionengine = this;
typeproposal.setdeclarationsignature(packagename);
typeproposal.setsignature(getrequiredtypesignature(currenttype));
typeproposal.setpackagename(packagename);
typeproposal.settypename(typename);
typeproposal.setcompletion(typecompletion);
typeproposal.setflags(currenttype.modifiers);
typeproposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
typeproposal.settokenrange(this.startposition - this.offset, this.endposition - this.offset);
typeproposal.setrelevance(relevance);
proposal.setrequiredproposals( new completionproposal[]{typeproposal});

proposal.setcompletion(completion);
proposal.setflags(flags.accpublic);
proposal.setreplacerange(this.endposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}  else {
if(!isignored(completionproposal.anonymous_class_declaration, missingelements != null)) {
internalcompletionproposal proposal = createproposal(completionproposal.anonymous_class_declaration, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(currenttype));
proposal.setdeclarationkey(currenttype.computeuniquekey());
proposal.setsignature(
createmethodsignature(
charoperation.no_char_char,
charoperation.no_char_char,
charoperation.no_char,
charoperation.no_char));
//proposal.setoriginalsignature(null);
//proposal.setuniquekey(null);
proposal.setdeclarationpackagename(currenttype.qualifiedpackagename());
proposal.setdeclarationtypename(currenttype.qualifiedsourcename());
//proposal.setparameterpackagenames(null);
//proposal.setparametertypenames(null);
//proposal.setpackagename(null);
//proposal.settypename(null);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(completion);
proposal.setflags(flags.accpublic);
proposal.setreplacerange(this.endposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenend - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
} else {
findconstructors(
currenttype,
argtypes,
scope,
invocationsite,
true,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
exactmatch,
isqualified,
relevance);
}
}
private void findclassfield(
char[] token,
typebinding receivertype,
scope scope,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems) {

if (token == null) return;

if (token.length <= classfield.length
&& charoperation.prefixequals(token, classfield, false /* ignore case */
)) {
int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(token, classfield);
relevance += computerelevanceforexpectingtype(scope.getjavalangclass());
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); //no access restriction for class field
relevance += r_non_inherited;

if (missingelements != null) {
relevance += computerelevanceformissingelements(missingelementshaveproblems);
}

this.noproposal = false;
if(!isignored(completionproposal.field_ref, missingelements != null)) {
internalcompletionproposal proposal = createproposal(completionproposal.field_ref, this.actualcompletionposition);
//proposal.setdeclarationsignature(null);
char[] signature =
createnongenerictypesignature(
charoperation.concatwith(java_lang, '.'),
class);
if (this.compileroptions.sourcelevel > classfileconstants.jdk1_4) {
// add type argument
char[] typeargument = gettypesignature(receivertype);
int oldlength = signature.length;
int argumentlength = typeargument.length;
int newlength = oldlength + argumentlength + 2;
system.arraycopy(signature, 0, signature = new char[newlength], 0, oldlength - 1);
signature[oldlength - 1] = '<';
system.arraycopy(typeargument, 0, signature, oldlength , argumentlength);
signature[newlength - 2] = '>';
signature[newlength - 1] = ';';
}
proposal.setsignature(signature);
//proposal.setdeclarationpackagename(null);
//proposal.setdeclarationtypename(null);
proposal.setpackagename(charoperation.concatwith(java_lang, '.'));
proposal.settypename(class);
proposal.setname(classfield);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(classfield);
proposal.setflags(flags.accstatic | flags.accpublic);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}

void findconstructors(
referencebinding currenttype,
typebinding[] argtypes,
scope scope,
invocationsite invocationsite,
boolean foranonymoustype,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems) {

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

if (missingelements != null) {
relevance += computerelevanceformissingelements(missingelementshaveproblems);
}

findconstructors(
currenttype,
argtypes,
scope,
invocationsite,
foranonymoustype,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
true,
false,
relevance);
}


private void findconstructorsfrommissingtype(
typereference typeref,
final typebinding[] argtypes,
final scope scope,
final invocationsite invocationsite) {
missingtypesguesser missingtypesconverter = new missingtypesguesser(this);
missingtypesguesser.guessedtyperequestor substitutionrequestor =
new missingtypesguesser.guessedtyperequestor() {
public void accept(
typebinding guessedtype,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean hasproblems) {
if (guessedtype instanceof referencebinding) {
referencebinding ref = (referencebinding) guessedtype;
if (!isignored(completionproposal.method_ref, missingelements != null)
&& ref.isclass()
&& !ref.isabstract()) {
findconstructors(
ref,
argtypes,
scope,
invocationsite,
false,
missingelements,
missingelementsstarts,
missingelementsends,
hasproblems);
}

checkcancel();

if (!isignored(completionproposal.anonymous_class_declaration, missingelements != null)
&& !ref.isfinal()
&& !ref.isenum()){
findanonymoustype(
ref,
argtypes,
scope,
invocationsite,
missingelements,
missingelementsstarts,
missingelementsends,
hasproblems);
}
}
}
};
missingtypesconverter.guess(typeref, scope, substitutionrequestor);
}

private void findconstructors(
referencebinding currenttype,
typebinding[] argtypes,
scope scope,
invocationsite invocationsite,
boolean foranonymoustype,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems,
boolean exactmatch,
boolean isqualified,
int relevance) {

// no visibility checks can be performed without the scope & invocationsite
methodbinding[] methods = currenttype.availablemethods();
if(methods != null) {
int minarglength = argtypes == null ? 0 : argtypes.length;
next : for (int f = methods.length; --f >= 0;) {
methodbinding constructor = methods[f];
if (constructor.isconstructor()) {

if (constructor.issynthetic()) continue next;

if (this.options.checkdeprecation &&
constructor.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(constructor.declaringclass))
continue next;

if (this.options.checkvisibility
&& !constructor.canbeseenby(invocationsite, scope)) {
if(!foranonymoustype || !constructor.isprotected())
continue next;
}

typebinding[] parameters = constructor.parameters;
int paramlength = parameters.length;
if (minarglength > paramlength)
continue next;
for (int a = minarglength; --a >= 0;)
if (argtypes[a] != null) { // can be null if it could not be resolved properly
if (!argtypes[a].iscompatiblewith(constructor.parameters[a]))
continue next;
}

char[][] parameterpackagenames = new char[paramlength][];
char[][] parametertypenames = new char[paramlength][];
for (int i = 0; i < paramlength; i++) {
typebinding type = parameters[i];
parameterpackagenames[i] = type.qualifiedpackagename();
parametertypenames[i] = type.qualifiedsourcename();
}
char[][] parameternames = findmethodparameternames(constructor,parametertypenames);

char[] completion = charoperation.no_char;

if(foranonymoustype){
char[] typecompletion = null;
if (!exactmatch) {
typecompletion =
isqualified ?
charoperation.concat(currenttype.qualifiedpackagename(), currenttype.qualifiedsourcename(), '.') :
currenttype.sourcename();
if (this.source != null
&& this.source.length > this.endposition
&& this.source[this.endposition] == '(') {
completion = charoperation.no_char;
} else {
completion = new char[] { '(', ')' };
}
}

this.noproposal = false;
if (!exactmatch) {
if(!isignored(completionproposal.anonymous_class_constructor_invocation, completionproposal.type_ref)) {
char[] packagename = currenttype.islocaltype() ? null : currenttype.qualifiedpackagename();
char[] typename = currenttype.qualifiedsourcename();

internalcompletionproposal proposal = createproposal(completionproposal.anonymous_class_constructor_invocation, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(currenttype));
proposal.setdeclarationkey(currenttype.computeuniquekey());
proposal.setsignature(getsignature(constructor));
methodbinding original = constructor.original();
if(original != constructor) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setkey(constructor.computeuniquekey());
proposal.setdeclarationpackagename(packagename);
proposal.setdeclarationtypename(typename);
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
//proposal.setpackagename(null);
//proposal.settypename(null);
proposal.setname(currenttype.sourcename());

internalcompletionproposal typeproposal = createproposal(completionproposal.type_ref, this.actualcompletionposition);
typeproposal.namelookup = this.nameenvironment.namelookup;
typeproposal.completionengine = this;
typeproposal.setdeclarationsignature(packagename);
typeproposal.setsignature(getrequiredtypesignature(currenttype));
typeproposal.setpackagename(packagename);
typeproposal.settypename(typename);
typeproposal.setcompletion(typecompletion);
typeproposal.setflags(currenttype.modifiers);
typeproposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
typeproposal.settokenrange(this.startposition - this.offset, this.endposition - this.offset);
typeproposal.setrelevance(relevance);
proposal.setrequiredproposals( new completionproposal[]{typeproposal});

proposal.setcompletion(completion);
proposal.setflags(constructor.modifiers);
proposal.setreplacerange(this.endposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
} else {
if(!isignored(completionproposal.anonymous_class_declaration, missingelements != null)) {
internalcompletionproposal proposal = createproposal(completionproposal.anonymous_class_declaration, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(currenttype));
proposal.setdeclarationkey(currenttype.computeuniquekey());
proposal.setsignature(getsignature(constructor));
methodbinding original = constructor.original();
if(original != constructor) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setkey(constructor.computeuniquekey());
proposal.setdeclarationpackagename(currenttype.qualifiedpackagename());
proposal.setdeclarationtypename(currenttype.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
//proposal.setpackagename(null);
//proposal.settypename(null);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(completion);
proposal.setflags(constructor.modifiers);
proposal.setreplacerange(this.endposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenend - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
} else {
char[] typecompletion = null;
// special case for completion in javadoc
if (this.assistnodeinjavadoc > 0) {
expression receiver = null;
char[] selector = null;
if (invocationsite instanceof completiononjavadocallocationexpression) {
completiononjavadocallocationexpression alloc = (completiononjavadocallocationexpression) invocationsite;
receiver = alloc.type;
} else if (invocationsite instanceof completiononjavadocfieldreference) {
completiononjavadocfieldreference fieldref = (completiononjavadocfieldreference) invocationsite;
receiver = fieldref.receiver;
}
if (receiver != null) {
stringbuffer javadoccompletion = new stringbuffer();
if (receiver.isthis()) {
selector = (((javadocimplicittypereference)receiver).token);
if ((this.assistnodeinjavadoc & completiononjavadoc.text) != 0) {
javadoccompletion.append('#');
}
} else if (receiver instanceof javadocsingletypereference) {
javadocsingletypereference typeref = (javadocsingletypereference) receiver;
selector = typeref.token;
if ((this.assistnodeinjavadoc & completiononjavadoc.text) != 0) {
javadoccompletion.append(typeref.token);
javadoccompletion.append('#');
}
} else if (receiver instanceof javadocqualifiedtypereference) {
javadocqualifiedtypereference typeref = (javadocqualifiedtypereference) receiver;
selector = typeref.tokens[typeref.tokens.length-1];
if ((this.assistnodeinjavadoc & completiononjavadoc.text) != 0) {
javadoccompletion.append(charoperation.concatwith(typeref.tokens, '.'));
javadoccompletion.append('#');
}
}
// append parameters types
javadoccompletion.append(selector);
javadoccompletion.append('(');
if (constructor.parameters != null) {
boolean isvarargs = constructor.isvarargs();
for (int p=0, ln=constructor.parameters.length; p<ln; p++) {
if (p>0) javadoccompletion.append(", "); //$non-nls-1$
typebinding argtypebinding = constructor.parameters[p];
if (isvarargs && p == ln - 1)  {
createvargstype(argtypebinding.erasure(), scope, javadoccompletion);
} else {
createtype(argtypebinding.erasure(), scope, javadoccompletion);
}
}
}
javadoccompletion.append(')');
completion = javadoccompletion.tostring().tochararray();
}
} else {
if (!exactmatch) {
typecompletion =
isqualified ?
charoperation.concat(currenttype.qualifiedpackagename(), currenttype.qualifiedsourcename(), '.') :
currenttype.sourcename();

if (this.source != null
&& this.source.length > this.endposition
&& this.source[this.endposition] == '(') {
completion = charoperation.no_char;
} else {
completion = new char[] { '(', ')' };
}
}
}

// create standard proposal
this.noproposal = false;
if (!exactmatch) {
if(!isignored(completionproposal.constructor_invocation, completionproposal.type_ref)) {
char[] packagename = currenttype.islocaltype() ? null : currenttype.qualifiedpackagename();
char[] typename = currenttype.qualifiedsourcename();

internalcompletionproposal proposal =  createproposal(completionproposal.constructor_invocation, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(currenttype));
proposal.setsignature(getsignature(constructor));
methodbinding original = constructor.original();
if(original != constructor) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setdeclarationpackagename(packagename);
proposal.setdeclarationtypename(typename);
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
//proposal.setpackagename(null);
//proposal.settypename(null);
proposal.setname(currenttype.sourcename());

internalcompletionproposal typeproposal = createproposal(completionproposal.type_ref, this.actualcompletionposition);
typeproposal.namelookup = this.nameenvironment.namelookup;
typeproposal.completionengine = this;
typeproposal.setdeclarationsignature(packagename);
typeproposal.setsignature(getrequiredtypesignature(currenttype));
typeproposal.setpackagename(packagename);
typeproposal.settypename(typename);
typeproposal.setcompletion(typecompletion);
typeproposal.setflags(currenttype.modifiers);
typeproposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
typeproposal.settokenrange(this.startposition - this.offset, this.endposition - this.offset);
typeproposal.setrelevance(relevance);
proposal.setrequiredproposals( new completionproposal[]{typeproposal});

proposal.setiscontructor(true);
proposal.setcompletion(completion);
proposal.setflags(constructor.modifiers);
proposal.setreplacerange(this.endposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
} else {
if(!isignored(completionproposal.method_ref, missingelements != null) && (this.assistnodeinjavadoc & completiononjavadoc.only_inline_tag) == 0) {
internalcompletionproposal proposal =  createproposal(completionproposal.method_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(currenttype));
proposal.setsignature(getsignature(constructor));
methodbinding original = constructor.original();
if(original != constructor) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setdeclarationpackagename(currenttype.qualifiedpackagename());
proposal.setdeclarationtypename(currenttype.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
//proposal.setpackagename(null);
//proposal.settypename(null);
proposal.setname(currenttype.sourcename());
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setiscontructor(true);
proposal.setcompletion(completion);
proposal.setflags(constructor.modifiers);
int start = (this.assistnodeinjavadoc > 0) ? this.startposition : this.endposition;
proposal.setreplacerange(start - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
if ((this.assistnodeinjavadoc & completiononjavadoc.text) != 0 && !this.requestor.isignored(completionproposal.javadoc_method_ref)) {
char[] javadoccompletion = inlinetagcompletion(completion, javadoctagconstants.tag_link);
internalcompletionproposal proposal =  createproposal(completionproposal.javadoc_method_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(currenttype));
proposal.setsignature(getsignature(constructor));
methodbinding original = constructor.original();
if(original != constructor) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setdeclarationpackagename(currenttype.qualifiedpackagename());
proposal.setdeclarationtypename(currenttype.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
//proposal.setpackagename(null);
//proposal.settypename(null);
proposal.setname(currenttype.sourcename());
proposal.setiscontructor(true);
proposal.setcompletion(javadoccompletion);
proposal.setflags(constructor.modifiers);
int start = (this.assistnodeinjavadoc & completiononjavadoc.replace_tag) != 0 ? this.javadoctagposition : this.startposition;
proposal.setreplacerange(start - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance+r_inline_tag);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}
}
}
}
}

private char[] getresolvedsignature(char[][] parametertypes, char[] fullyqualifiedtypename, int parametercount, scope scope) {
char[][] cn = charoperation.spliton('.', fullyqualifiedtypename);

typereference ref;
if (cn.length == 1) {
ref = new singletypereference(cn[0], 0);
} else {
ref = new qualifiedtypereference(cn,new long[cn.length]);
}

typebinding guessedtype = null;
inameenvironment oldnameenvironment = this.lookupenvironment.nameenvironment;
this.lookupenvironment.nameenvironment = getnocachenameenvironment();
try {
switch (scope.kind) {
case scope.method_scope :
case scope.block_scope :
guessedtype = ref.resolvetype((blockscope)scope);
break;
case scope.class_scope :
guessedtype = ref.resolvetype((classscope)scope);
break;
}


if (guessedtype != null && guessedtype.isvalidbinding()) {
// the erasure must be used because guessedtype can be a rawtypebinding (https://bugs.eclipse.org/bugs/show_bug.cgi?id=276890)
guessedtype = guessedtype.erasure();

if (guessedtype instanceof sourcetypebinding) {
sourcetypebinding refbinding = (sourcetypebinding) guessedtype;

if (refbinding.scope == null || refbinding.scope.referencecontext == null) return null;

typedeclaration typedeclaration = refbinding.scope.referencecontext;
abstractmethoddeclaration[] methods = typedeclaration.methods;

next : for (int i = 0; i < methods.length; i++) {
abstractmethoddeclaration method = methods[i];

if (!method.isconstructor()) continue next;

argument[] arguments = method.arguments;
int argumentslength = arguments == null ? 0 : arguments.length;

if (parametercount != argumentslength) continue next;

for (int j = 0; j < argumentslength; j++) {
char[] argumenttypename = gettypename(arguments[j].type);

if (!charoperation.equals(argumenttypename, parametertypes[j])) {
continue next;
}
}

refbinding.resolvetypesfor(method.binding); // force resolution
if (method.binding == null) continue next;
return getsignature(method.binding);
}
}
}
} finally {
this.lookupenvironment.nameenvironment = oldnameenvironment;
}

return null;
}

private void findconstructorsoranonymoustypes(
referencebinding currenttype,
scope scope,
invocationsite invocationsite,
boolean isqualified,
int relevance) {

if (!isignored(completionproposal.constructor_invocation, completionproposal.type_ref)
&& currenttype.isclass()
&& !currenttype.isabstract()) {
findconstructors(
currenttype,
null,
scope,
invocationsite,
false,
null,
null,
null,
false,
false,
isqualified,
relevance);
}

// this code is disabled because there is too much proposals when constructors and anonymous are proposed
if (!isignored(completionproposal.anonymous_class_constructor_invocation, completionproposal.type_ref)
&& !currenttype.isfinal()
&& (currenttype.isinterface() || (currenttype.isclass() && currenttype.isabstract()))){
findanonymoustype(
currenttype,
null,
scope,
invocationsite,
null,
null,
null,
false,
false,
isqualified,
relevance);
}
}
private char[][] findenclosingtypenames(scope scope){
char[][] excludednames = new char[10][];
int excludednamecount = 0;

scope currentscope = scope;
while(currentscope != null) {
switch (currentscope.kind) {
case scope.class_scope :
classscope classscope = (classscope) currentscope;

typedeclaration typedeclaration = classscope.referencecontext;

if(excludednamecount == excludednames.length) {
system.arraycopy(excludednames, 0, excludednames = new char[excludednamecount * 2][], 0, excludednamecount);
}
excludednames[excludednamecount++] = typedeclaration.name;

typeparameter[] classtypeparameters = typedeclaration.typeparameters;
if(classtypeparameters != null) {
for (int i = 0; i < classtypeparameters.length; i++) {
typeparameter typeparameter = classtypeparameters[i];
if(excludednamecount == excludednames.length) {
system.arraycopy(excludednames, 0, excludednames = new char[excludednamecount * 2][], 0, excludednamecount);
}
excludednames[excludednamecount++] = typeparameter.name;
}
}
break;
case scope.method_scope :
methodscope methodscope = (methodscope) currentscope;
if(methodscope.referencecontext instanceof abstractmethoddeclaration) {
typeparameter[] methodtypeparameters = ((abstractmethoddeclaration)methodscope.referencecontext).typeparameters();
if(methodtypeparameters != null) {
for (int i = 0; i < methodtypeparameters.length; i++) {
typeparameter typeparameter = methodtypeparameters[i];
if(excludednamecount == excludednames.length) {
system.arraycopy(excludednames, 0, excludednames = new char[excludednamecount * 2][], 0, excludednamecount);
}
excludednames[excludednamecount++] = typeparameter.name;
}
}
}
break;
}

currentscope = currentscope.parent;
}

if(excludednamecount == 0) {
return charoperation.no_char_char;
}
system.arraycopy(excludednames, 0, excludednames = new char[excludednamecount][], 0, excludednamecount);
return excludednames;
}
private void findenumconstants(
char[] enumconstantname,
referencebinding enumtype,
scope invocationscope,
objectvector fieldsfound,
char[][] alreadyusedconstants,
int alreadyusedconstantcount,
boolean needqualification) {

fieldbinding[] fields = enumtype.fields();

int enumconstantlength = enumconstantname.length;
next : for (int f = fields.length; --f >= 0;) {
fieldbinding field = fields[f];

if (field.issynthetic()) continue next;

if ((field.modifiers & flags.accenum) == 0) continue next;

if (enumconstantlength > field.name.length) continue next;

if (!charoperation.prefixequals(enumconstantname, field.name, false /* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(enumconstantname, field.name)))	continue next;

char[] fieldname = field.name;

for (int i = 0; i < alreadyusedconstantcount; i++) {
if(charoperation.equals(alreadyusedconstants[i], fieldname)) continue next;
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal(field);
relevance += computerelevanceforcasematching(enumconstantname, field.name);
relevance += computerelevanceforexpectingtype(field.type);
relevance += computerelevanceforenumconstant(field.type);
relevance += computerelevanceforqualification(needqualification);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

this.noproposal = false;
if (!needqualification) {
char[] completion = fieldname;

if(!this.requestor.isignored(completionproposal.field_ref)) {
internalcompletionproposal proposal = createproposal(completionproposal.field_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(field.declaringclass));
proposal.setsignature(getsignature(field.type));
proposal.setdeclarationpackagename(field.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(field.declaringclass.qualifiedsourcename());
proposal.setpackagename(field.type.qualifiedpackagename());
proposal.settypename(field.type.qualifiedsourcename());
proposal.setname(field.name);
proposal.setcompletion(completion);
proposal.setflags(field.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}

} else {
typebinding visibletype = invocationscope.gettype(field.type.sourcename());
boolean needimport = visibletype == null || !visibletype.isvalidbinding();

char[] completion = charoperation.concat(field.type.sourcename(), field.name, '.');

if (!needimport) {
if(!this.requestor.isignored(completionproposal.field_ref)) {
internalcompletionproposal proposal = createproposal(completionproposal.field_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(field.declaringclass));
proposal.setsignature(getsignature(field.type));
proposal.setdeclarationpackagename(field.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(field.declaringclass.qualifiedsourcename());
proposal.setpackagename(field.type.qualifiedpackagename());
proposal.settypename(field.type.qualifiedsourcename());
proposal.setname(field.name);
proposal.setcompletion(completion);
proposal.setflags(field.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
} else {
if (!this.isignored(completionproposal.field_ref, completionproposal.type_import)) {
compilationunitdeclaration cu = this.unitscope.referencecontext;
int importstart = cu.types[0].declarationsourcestart;
int importend = importstart;

referencebinding fieldtype = (referencebinding)field.type;

internalcompletionproposal proposal = createproposal(completionproposal.field_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(field.declaringclass));
proposal.setsignature(getsignature(field.type));
proposal.setdeclarationpackagename(field.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(field.declaringclass.qualifiedsourcename());
proposal.setpackagename(field.type.qualifiedpackagename());
proposal.settypename(field.type.qualifiedsourcename());
proposal.setname(field.name);
proposal.setcompletion(completion);
proposal.setflags(field.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);

char[] typeimportcompletion = createimportchararray(charoperation.concatwith(fieldtype.compoundname, '.'), false, false);

internalcompletionproposal typeimportproposal = createproposal(completionproposal.type_import, this.actualcompletionposition);
typeimportproposal.namelookup = this.nameenvironment.namelookup;
typeimportproposal.completionengine = this;
char[] packagename = fieldtype.qualifiedpackagename();
typeimportproposal.setdeclarationsignature(packagename);
typeimportproposal.setsignature(getsignature(fieldtype));
typeimportproposal.setpackagename(packagename);
typeimportproposal.settypename(fieldtype.qualifiedsourcename());
typeimportproposal.setcompletion(typeimportcompletion);
typeimportproposal.setflags(fieldtype.modifiers);
typeimportproposal.setadditionalflags(completionflags.default);
typeimportproposal.setreplacerange(importstart - this.offset, importend - this.offset);
typeimportproposal.settokenrange(importstart - this.offset, importend - this.offset);
typeimportproposal.setrelevance(relevance);

proposal.setrequiredproposals(new completionproposal[]{typeimportproposal});

this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}
}
}
private void findenumconstantsfromexpectedtypes(
char[] token,
scope invocationscope,
objectvector fieldsfound) {
int length = this.expectedtypesptr + 1;
for (int i = 0; i < length; i++) {
if (this.expectedtypes[i].isenum()) {
findenumconstants(
token,
(referencebinding)this.expectedtypes[i],
invocationscope,
fieldsfound,
charoperation.no_char_char,
0,
true);
}
}

}
private void findenumconstantsfromswithstatement(char[] enumconstantname, switchstatement switchstatement) {
typebinding expressiontype = switchstatement.expression.resolvedtype;
if(expressiontype != null && expressiontype.isenum()) {
referencebinding enumtype = (referencebinding) expressiontype;

casestatement[] cases = switchstatement.cases;

char[][] alreadyusedconstants = new char[switchstatement.casecount][];
int alreadyusedconstantcount = 0;
for (int i = 0; i < switchstatement.casecount; i++) {
expression caseexpression = cases[i].constantexpression;
if((caseexpression instanceof singlenamereference)
&& (caseexpression.resolvedtype != null && caseexpression.resolvedtype.isenum())) {
alreadyusedconstants[alreadyusedconstantcount++] = ((singlenamereference)cases[i].constantexpression).token;
}
}

findenumconstants(
enumconstantname,
enumtype,
null /* doesn't need invocation scope */,
new objectvector(),
alreadyusedconstants,
alreadyusedconstantcount,
false);
}
}
private void findexceptionfromtrystatement(
char[] typename,
referencebinding exceptiontype,
referencebinding receivertype,
sourcetypebinding invocationtype,
blockscope scope,
objectvector typesfound,
boolean searchsuperclasses) {

if (searchsuperclasses) {
referencebinding javalangthrowable = scope.getjavalangthrowable();
if (exceptiontype != javalangthrowable) {
referencebinding superclass = exceptiontype.superclass();
while(superclass != null && superclass != javalangthrowable) {
findexceptionfromtrystatement(typename, superclass, receivertype, invocationtype, scope, typesfound, false);
superclass = superclass.superclass();
}
}
}

if (typename.length > exceptiontype.sourcename.length)
return;

if (!charoperation.prefixequals(typename, exceptiontype.sourcename, false/* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(typename, exceptiontype.sourcename)))
return;

if (this.options.checkdeprecation &&
exceptiontype.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(exceptiontype))
return;

if (this.options.checkvisibility) {
if (invocationtype != null) {
if (receivertype != null) {
if (!exceptiontype.canbeseenby(receivertype, invocationtype)) return;
} else {
if (!exceptiontype.canbeseenby(exceptiontype, invocationtype)) return;
}
} else if(!exceptiontype.canbeseenby(this.unitscope.fpackage)) {
return;
}
}

for (int j = typesfound.size; --j >= 0;) {
referencebinding othertype = (referencebinding) typesfound.elementat(j);

if (exceptiontype == othertype)
return;

if (charoperation.equals(exceptiontype.sourcename, othertype.sourcename, true)) {

if (exceptiontype.enclosingtype().issuperclassof(othertype.enclosingtype()))
return;

if (othertype.enclosingtype().isinterface())
if (exceptiontype.enclosingtype()
.implementsinterface(othertype.enclosingtype(), true))
return;

if (exceptiontype.enclosingtype().isinterface())
if (othertype.enclosingtype()
.implementsinterface(exceptiontype.enclosingtype(), true))
return;
}
}

typesfound.add(exceptiontype);

char[] completionname = exceptiontype.sourcename();

boolean isqualified = false;

if(!this.insidequalifiedreference) {
isqualified = true;

char[] memberpackagename = exceptiontype.qualifiedpackagename();
char[] membertypename = exceptiontype.sourcename();
char[] memberenclosingtypenames = null;

referencebinding enclosingtype = exceptiontype.enclosingtype();
if (enclosingtype != null) {
memberenclosingtypenames = exceptiontype.enclosingtype().qualifiedsourcename();
}

scope currentscope = scope;
done : while (currentscope != null) { // done when a compilation_unit_scope is found

switch (currentscope.kind) {

case scope.method_scope :
case scope.block_scope :
blockscope blockscope = (blockscope) currentscope;

for (int j = 0, length = blockscope.subscopecount; j < length; j++) {

if (blockscope.subscopes[j] instanceof classscope) {
sourcetypebinding localtype =
((classscope) blockscope.subscopes[j]).referencecontext.binding;

if (localtype == exceptiontype) {
isqualified = false;
break done;
}
}
}
break;

case scope.class_scope :
sourcetypebinding type = ((classscope)currentscope).referencecontext.binding;
referencebinding[] membertypes = type.membertypes();
if (membertypes != null) {
for (int j = 0; j < membertypes.length; j++) {
if (membertypes[j] == exceptiontype) {
isqualified = false;
break done;
}
}
}


break;

case scope.compilation_unit_scope :
sourcetypebinding[] types = ((compilationunitscope)currentscope).topleveltypes;
if (types != null) {
for (int j = 0; j < types.length; j++) {
if (types[j] == exceptiontype) {
isqualified = false;
break done;
}
}
}
break done;
}
currentscope = currentscope.parent;
}

if (isqualified && mustqualifytype(memberpackagename, membertypename, memberenclosingtypenames, exceptiontype.modifiers)) {
if (memberpackagename == null || memberpackagename.length == 0)
if (this.unitscope != null && this.unitscope.fpackage.compoundname != charoperation.no_char_char)
return; // ignore types from the default package from outside it
} else {
isqualified = false;
}

if (isqualified) {
completionname =
charoperation.concat(
memberpackagename,
charoperation.concat(
memberenclosingtypenames,
membertypename,
'.'),
'.');
}
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(typename, exceptiontype.sourcename);
relevance += computerelevanceforexpectingtype(exceptiontype);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);
if(!this.insidequalifiedreference) {
relevance += computerelevanceforqualification(isqualified);
}
relevance += computerelevanceforclass();
relevance += computerelevanceforexception();

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.type_ref)) {
createtypeproposal(
exceptiontype,
exceptiontype.qualifiedsourcename(),
iaccessrule.k_accessible,
completionname,
relevance,
null,
null,
null,
false);
}
}
private void findexceptionfromtrystatement(
char[] typename,
referencebinding receivertype,
sourcetypebinding invocationtype,
blockscope scope,
objectvector typesfound) {

for (int i = 0; i <= this.expectedtypesptr; i++) {
referencebinding exceptiontype = (referencebinding)this.expectedtypes[i];

findexceptionfromtrystatement(typename, exceptiontype, receivertype, invocationtype, scope, typesfound, true);
}
}
private void findexplicitconstructors(
char[] name,
referencebinding currenttype,
methodscope scope,
invocationsite invocationsite) {

constructordeclaration constructordeclaration = (constructordeclaration)scope.referencecontext;
methodbinding enclosingconstructor = constructordeclaration.binding;

// no visibility checks can be performed without the scope & invocationsite
methodbinding[] methods = currenttype.availablemethods();
if(methods != null) {
next : for (int f = methods.length; --f >= 0;) {
methodbinding constructor = methods[f];
if (constructor != enclosingconstructor && constructor.isconstructor()) {

if (constructor.issynthetic()) continue next;

if (this.options.checkdeprecation &&
constructor.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(constructor.declaringclass))
continue next;

if (this.options.checkvisibility
&& !constructor.canbeseenby(invocationsite, scope))	continue next;

typebinding[] parameters = constructor.parameters;
int paramlength = parameters.length;

char[][] parameterpackagenames = new char[paramlength][];
char[][] parametertypenames = new char[paramlength][];
for (int i = 0; i < paramlength; i++) {
typebinding type = parameters[i];
parameterpackagenames[i] = type.qualifiedpackagename();
parametertypenames[i] = type.qualifiedsourcename();
}
char[][] parameternames = findmethodparameternames(constructor,parametertypenames);

char[] completion = charoperation.no_char;
if (this.source != null
&& this.source.length > this.endposition
&& this.source[this.endposition] == '(')
completion = name;
else
completion = charoperation.concat(name, new char[] { '(', ')' });

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(this.completiontoken, name);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.method_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.method_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(currenttype));
proposal.setsignature(getsignature(constructor));
methodbinding original = constructor.original();
if(original != constructor) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setdeclarationpackagename(currenttype.qualifiedpackagename());
proposal.setdeclarationtypename(currenttype.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
//proposal.setpackagename(null);
//proposal.settypename(null);
proposal.setname(name);
proposal.setiscontructor(true);
proposal.setcompletion(completion);
proposal.setflags(constructor.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}
}
}
// helper method for findfields(char[], referencebinding, scope, objectvector, boolean)
private void findfields(
char[] fieldname,
fieldbinding[] fields,
scope scope,
objectvector fieldsfound,
objectvector localsfound,
boolean onlystaticfields,
referencebinding receivertype,
invocationsite invocationsite,
scope invocationscope,
boolean implicitcall,
boolean canbeprefixed,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems,
char[] castedreceiver,
int receiverstart,
int receiverend) {

objectvector newfieldsfound = new objectvector();
// inherited fields which are hidden by subclasses are filtered out
// no visibility checks can be performed without the scope & invocationsite

int fieldlength = fieldname.length;
next : for (int f = fields.length; --f >= 0;) {
fieldbinding field = fields[f];

if (field.issynthetic())	continue next;

if (onlystaticfields && !field.isstatic()) continue next;

if (fieldlength > field.name.length) continue next;

if (!charoperation.prefixequals(fieldname, field.name, false /* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(fieldname, field.name)))	continue next;

if (this.options.checkdeprecation &&
field.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(field.declaringclass))
continue next;

if (this.options.checkvisibility
&& !field.canbeseenby(receivertype, invocationsite, scope))	continue next;

boolean prefixrequired = false;

for (int i = fieldsfound.size; --i >= 0;) {
object[] other = (object[])fieldsfound.elementat(i);
fieldbinding otherfield = (fieldbinding) other[0];
referencebinding otherreceivertype = (referencebinding) other[1];
if (field == otherfield && receivertype == otherreceivertype)
continue next;
if (charoperation.equals(field.name, otherfield.name, true)) {
if (field.declaringclass.issuperclassof(otherfield.declaringclass))
continue next;
if (otherfield.declaringclass.isinterface()) {
if (field.declaringclass == scope.getjavalangobject())
continue next;
if (field.declaringclass.implementsinterface(otherfield.declaringclass, true))
continue next;
}
if (field.declaringclass.isinterface())
if (otherfield.declaringclass.implementsinterface(field.declaringclass, true))
continue next;
if(canbeprefixed) {
prefixrequired = true;
} else {
continue next;
}
}
}

for (int l = localsfound.size; --l >= 0;) {
localvariablebinding local = (localvariablebinding) localsfound.elementat(l);

if (charoperation.equals(field.name, local.name, true)) {
sourcetypebinding declarationtype = scope.enclosingsourcetype();
if (declarationtype.isanonymoustype() && declarationtype != invocationscope.enclosingsourcetype()) {
continue next;
}
if(canbeprefixed) {
prefixrequired = true;
} else {
continue next;
}
break;
}
}

newfieldsfound.add(new object[]{field, receivertype});

char[] completion = field.name;

if(prefixrequired || this.options.forceimplicitqualification){
char[] prefix = computeprefix(scope.enclosingsourcetype(), invocationscope.enclosingsourcetype(), field.isstatic());
completion = charoperation.concat(prefix,completion,'.');
}


if (castedreceiver != null) {
completion = charoperation.concat(castedreceiver, completion);
}

// special case for javadoc completion
if (this.assistnodeinjavadoc > 0) {
if (invocationsite instanceof completiononjavadocfieldreference) {
completiononjavadocfieldreference fieldref = (completiononjavadocfieldreference) invocationsite;
if (fieldref.receiver.isthis()) {
if (fieldref.completeintext()) {
completion = charoperation.concat(new char[] { '#' }, field.name);
}
} else if (fieldref.completeintext()) {
if (fieldref.receiver instanceof javadocsingletypereference) {
javadocsingletypereference typeref = (javadocsingletypereference) fieldref.receiver;
completion = charoperation.concat(typeref.token, field.name, '#');
} else if (fieldref.receiver instanceof javadocqualifiedtypereference) {
javadocqualifiedtypereference typeref = (javadocqualifiedtypereference) fieldref.receiver;
completion = charoperation.concat(charoperation.concatwith(typeref.tokens, '.'), field.name, '#');
}
}
}
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal(field);
relevance += computerelevanceforcasematching(fieldname, field.name);
relevance += computerelevanceforexpectingtype(field.type);
relevance += computerelevanceforenumconstant(field.type);
relevance += computerelevanceforstatic(onlystaticfields, field.isstatic());
relevance += computerelevanceforqualification(prefixrequired);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);
if (onlystaticfields && this.insidequalifiedreference) {
relevance += computerelevanceforinheritance(receivertype, field.declaringclass);
}
if (missingelements != null) {
relevance += computerelevanceformissingelements(missingelementshaveproblems);
}

this.noproposal = false;
if (castedreceiver == null) {
// standard proposal
if (!this.isignored(completionproposal.field_ref, missingelements != null) && (this.assistnodeinjavadoc & completiononjavadoc.only_inline_tag) == 0) {
internalcompletionproposal proposal =  createproposal(completionproposal.field_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(field.declaringclass));
proposal.setsignature(getsignature(field.type));
proposal.setdeclarationpackagename(field.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(field.declaringclass.qualifiedsourcename());
proposal.setpackagename(field.type.qualifiedpackagename());
proposal.settypename(field.type.qualifiedsourcename());
proposal.setname(field.name);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(completion);
proposal.setflags(field.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}

// javadoc completions
if ((this.assistnodeinjavadoc & completiononjavadoc.text) != 0 && !this.requestor.isignored(completionproposal.javadoc_field_ref)) {
char[] javadoccompletion = inlinetagcompletion(completion, javadoctagconstants.tag_link);
internalcompletionproposal proposal =  createproposal(completionproposal.javadoc_field_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(field.declaringclass));
proposal.setsignature(getsignature(field.type));
proposal.setdeclarationpackagename(field.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(field.declaringclass.qualifiedsourcename());
proposal.setpackagename(field.type.qualifiedpackagename());
proposal.settypename(field.type.qualifiedsourcename());
proposal.setname(field.name);
proposal.setcompletion(javadoccompletion);
proposal.setflags(field.modifiers);
int start = (this.assistnodeinjavadoc & completiononjavadoc.replace_tag) != 0 ? this.javadoctagposition : this.startposition;
proposal.setreplacerange(start - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance+r_inline_tag);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
// javadoc value completion for static fields
if (field.isstatic() && !this.requestor.isignored(completionproposal.javadoc_value_ref)) {
javadoccompletion = inlinetagcompletion(completion, javadoctagconstants.tag_value);
internalcompletionproposal valueproposal = createproposal(completionproposal.javadoc_value_ref, this.actualcompletionposition);
valueproposal.setdeclarationsignature(getsignature(field.declaringclass));
valueproposal.setsignature(getsignature(field.type));
valueproposal.setdeclarationpackagename(field.declaringclass.qualifiedpackagename());
valueproposal.setdeclarationtypename(field.declaringclass.qualifiedsourcename());
valueproposal.setpackagename(field.type.qualifiedpackagename());
valueproposal.settypename(field.type.qualifiedsourcename());
valueproposal.setname(field.name);
valueproposal.setcompletion(javadoccompletion);
valueproposal.setflags(field.modifiers);
valueproposal.setreplacerange(start - this.offset, this.endposition - this.offset);
valueproposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
valueproposal.setrelevance(relevance+r_value_tag);
this.requestor.accept(valueproposal);
if(debug) {
this.printdebug(valueproposal);
}
}
}
} else {
if(!this.isignored(completionproposal.field_ref_with_casted_receiver, missingelements != null)) {
internalcompletionproposal proposal = createproposal(completionproposal.field_ref_with_casted_receiver, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(field.declaringclass));
proposal.setsignature(getsignature(field.type));
proposal.setreceiversignature(getsignature(receivertype));
proposal.setdeclarationpackagename(field.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(field.declaringclass.qualifiedsourcename());
proposal.setpackagename(field.type.qualifiedpackagename());
proposal.settypename(field.type.qualifiedsourcename());
proposal.setname(field.name);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(completion);
proposal.setflags(field.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.setreceiverrange(receiverstart - this.offset, receiverend - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}

fieldsfound.addall(newfieldsfound);
}
private void findfields(
char[] fieldname,
referencebinding receivertype,
scope scope,
objectvector fieldsfound,
objectvector localsfound,
boolean onlystaticfields,
invocationsite invocationsite,
scope invocationscope,
boolean implicitcall,
boolean canbeprefixed,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems,
char[] castedreceiver,
int receiverstart,
int receiverend) {

boolean notinjavadoc = this.assistnodeinjavadoc == 0;
if (fieldname == null && notinjavadoc)
return;

referencebinding currenttype = receivertype;
referencebinding[] interfacestovisit = null;
int nextposition = 0;
do {
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (notinjavadoc && itsinterfaces != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}

fieldbinding[] fields = currenttype.availablefields();
if(fields != null && fields.length > 0) {
findfields(
fieldname,
fields,
scope,
fieldsfound,
localsfound,
onlystaticfields,
receivertype,
invocationsite,
invocationscope,
implicitcall,
canbeprefixed,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
castedreceiver,
receiverstart,
receiverend);
}
currenttype = currenttype.superclass();
} while (notinjavadoc && currenttype != null);

if (notinjavadoc && interfacestovisit != null) {
for (int i = 0; i < nextposition; i++) {
referencebinding aninterface = interfacestovisit[i];
fieldbinding[] fields = aninterface.availablefields();
if(fields !=  null) {
findfields(
fieldname,
fields,
scope,
fieldsfound,
localsfound,
onlystaticfields,
receivertype,
invocationsite,
invocationscope,
implicitcall,
canbeprefixed,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
castedreceiver,
receiverstart,
receiverend);
}

referencebinding[] itsinterfaces = aninterface.superinterfaces();
if (itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
}

protected void findfieldsandmethods(
char[] token,
typebinding receivertype,
scope scope,
objectvector fieldsfound,
objectvector methodsfound,
invocationsite invocationsite,
scope invocationscope,
boolean implicitcall,
boolean supercall,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems,
char[] castedreceiver,
int receiverstart,
int receiverend) {

if (token == null)
return;

if (receivertype.isbasetype())
return; // nothing else is possible with base types

boolean proposefield =
castedreceiver == null ?
!this.isignored(completionproposal.field_ref, missingelements != null) :
!this.isignored(completionproposal.field_ref_with_casted_receiver, missingelements != null) ;
boolean proposemethod =
castedreceiver == null ?
!this.isignored(completionproposal.method_ref, missingelements != null) :
!this.isignored(completionproposal.method_ref_with_casted_receiver, missingelements != null);

if (receivertype.isarraytype()) {
if (proposefield
&& token.length <= lengthfield.length
&& charoperation.prefixequals(token, lengthfield, false /* ignore case */
)) {

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(token,lengthfield);
relevance += computerelevanceforexpectingtype(typebinding.int);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for length field
if (missingelements != null) {
relevance += computerelevanceformissingelements(missingelementshaveproblems);
}
this.noproposal = false;
if (castedreceiver == null) {
if(!isignored(completionproposal.field_ref, missingelements != null)) {
internalcompletionproposal proposal =  createproposal(completionproposal.field_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(receivertype));
proposal.setsignature(int_signature);
proposal.settypename(int);
proposal.setname(lengthfield);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(lengthfield);
proposal.setflags(flags.accpublic);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
} else {
char[] completion = charoperation.concat(castedreceiver, lengthfield);

if(!this.isignored(completionproposal.field_ref_with_casted_receiver, missingelements != null)) {
internalcompletionproposal proposal =  createproposal(completionproposal.field_ref_with_casted_receiver, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(receivertype));
proposal.setsignature(int_signature);
proposal.setreceiversignature(getsignature(receivertype));
proposal.settypename(int);
proposal.setname(lengthfield);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(completion);
proposal.setflags(flags.accpublic);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.setreceiverrange(receiverstart - this.offset, receiverend - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}
if (proposemethod
&& token.length <= clonemethod.length
&& charoperation.prefixequals(token, clonemethod, false /* ignore case */)
) {
referencebinding objectref = scope.getjavalangobject();

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(token, clonemethod);
relevance += computerelevanceforexpectingtype(objectref);
relevance += computerelevanceforstatic(false, false);
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for clone() method
if (missingelements != null) {
relevance += computerelevanceformissingelements(missingelementshaveproblems);
}
char[] completion;
if (this.source != null
&& this.source.length > this.endposition
&& this.source[this.endposition] == '(') {
completion = clonemethod;
} else {
completion = charoperation.concat(clonemethod, new char[] { '(', ')' });
}

if (castedreceiver != null) {
completion = charoperation.concat(castedreceiver, completion);
}

this.noproposal = false;
if (castedreceiver == null) {
if (!this.isignored(completionproposal.method_ref, missingelements != null)) {
internalcompletionproposal proposal =  createproposal(completionproposal.method_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(receivertype));
proposal.setsignature(
this.compileroptions.sourcelevel > classfileconstants.jdk1_4 && receivertype.isarraytype() ?
createmethodsignature(
charoperation.no_char_char,
charoperation.no_char_char,
getsignature(receivertype)) :
createmethodsignature(
charoperation.no_char_char,
charoperation.no_char_char,
charoperation.concatwith(java_lang, '.'),
object));
//proposal.setoriginalsignature(null);
//proposal.setdeclarationpackagename(null);
//proposal.setdeclarationtypename(null);
//proposal.setparameterpackagenames(null);
//proposal.setparametertypenames(null);
proposal.setpackagename(charoperation.concatwith(java_lang, '.'));
proposal.settypename(object);
proposal.setname(clonemethod);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(completion);
proposal.setflags(flags.accpublic);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
methodsfound.add(new object[]{objectref.getmethods(clonemethod)[0], objectref});
} else {
if(!this.isignored(completionproposal.method_ref_with_casted_receiver, missingelements != null)) {
internalcompletionproposal proposal =  createproposal(completionproposal.method_ref_with_casted_receiver, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(receivertype));
proposal.setsignature(
this.compileroptions.sourcelevel > classfileconstants.jdk1_4 && receivertype.isarraytype() ?
createmethodsignature(
charoperation.no_char_char,
charoperation.no_char_char,
getsignature(receivertype)) :
createmethodsignature(
charoperation.no_char_char,
charoperation.no_char_char,
charoperation.concatwith(java_lang, '.'),
object));
proposal.setreceiversignature(getsignature(receivertype));
proposal.setpackagename(charoperation.concatwith(java_lang, '.'));
proposal.settypename(object);
proposal.setname(clonemethod);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(completion);
proposal.setflags(flags.accpublic);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.setreceiverrange(receiverstart - this.offset, receiverend - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}

receivertype = scope.getjavalangobject();
}

checkcancel();

if(proposefield) {
findfields(
token,
(referencebinding) receivertype,
scope,
fieldsfound,
new objectvector(),
false,
invocationsite,
invocationscope,
implicitcall,
false,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
castedreceiver,
receiverstart,
receiverend);
}

if(proposemethod) {
findmethods(
token,
null,
null,
(referencebinding) receivertype,
scope,
methodsfound,
false,
false,
invocationsite,
invocationscope,
implicitcall,
supercall,
false,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
castedreceiver,
receiverstart,
receiverend);
}
}

protected void findfieldsandmethodsfromanotherreceiver(
char[] token,
typereference receivertype,
scope scope,
objectvector fieldsfound,
objectvector methodsfound,
invocationsite invocationsite,
scope invocationscope,
boolean implicitcall,
boolean supercall,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems,
char[][] receivername,
int receiverstart,
int receiverend) {

if (receivertype.resolvedtype == null) return;

typebinding receivertypebinding = receivertype.resolvedtype;
char[] castedreceiver = null;

char[] castedtypechars = charoperation.concatwith(receivertype.gettypename(), '.');
if(this.source != null) {
int memberrefstart = this.startposition;

char[] receiverchars = charoperation.subarray(this.source, receiverstart, receiverend);
char[] dotchars = charoperation.subarray(this.source, receiverend, memberrefstart);

castedreceiver =
charoperation.concat(
charoperation.concat(
'(',
charoperation.concat(
charoperation.concat('(', castedtypechars, ')'),
receiverchars),
')'),
dotchars);
} else {
castedreceiver =
charoperation.concat(
charoperation.concat(
'(',
charoperation.concat(
charoperation.concat('(', castedtypechars, ')'),
charoperation.concatwith(receivername, '.')),
')'),
dot);
}

if (castedreceiver == null) return;

int oldstartposition = this.startposition;
this.startposition = receiverstart;

findfieldsandmethods(
token,
receivertypebinding,
scope,
fieldsfound,
methodsfound,
invocationsite,
invocationscope,
implicitcall,
supercall,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
castedreceiver,
receiverstart,
receiverend);

this.startposition = oldstartposition;
}
private void findfieldsandmethodsfromcastedreceiver(
astnode enclosingnode,
binding qualifiedbinding,
scope scope,
objectvector fieldsfound,
objectvector methodsfound,
invocationsite invocationsite,
scope invocationscope,
expression receiver) {

if (enclosingnode == null || !(enclosingnode instanceof ifstatement)) return;

ifstatement ifstatement = (ifstatement)enclosingnode;

if (!(ifstatement.condition instanceof instanceofexpression)) return;

instanceofexpression instanceofexpression = (instanceofexpression) ifstatement.condition;

typereference instanceoftype = instanceofexpression.type;

if (instanceoftype.resolvedtype == null) return;

boolean findfromanotherreceiver = false;

char[][] receivername = null;
int receiverstart = -1;
int receiverend = -1;

if (receiver instanceof qualifiednamereference) {
qualifiednamereference qualifiednamereference = (qualifiednamereference) receiver;

receivername = qualifiednamereference.tokens;

if (receivername.length != 1) return;

receiverstart = (int) (qualifiednamereference.sourcepositions[0] >>> 32);
receiverend = (int) qualifiednamereference.sourcepositions[qualifiednamereference.tokens.length - 1] + 1;

// if (local instanceof x) local.|
// if (field instanceof x) field.|
if (instanceofexpression.expression instanceof singlenamereference &&
((singlenamereference)instanceofexpression.expression).binding == qualifiedbinding &&
(qualifiedbinding instanceof localvariablebinding || qualifiedbinding instanceof fieldbinding)) {
findfromanotherreceiver = true;
}

// if (this.field instanceof x) field.|
if (instanceofexpression.expression instanceof fieldreference) {
fieldreference fieldreference = (fieldreference)instanceofexpression.expression;

if (fieldreference.receiver instanceof thisreference &&
qualifiedbinding instanceof fieldbinding &&
fieldreference.binding == qualifiedbinding) {
findfromanotherreceiver = true;
}
}
} else if (receiver instanceof fieldreference) {
fieldreference fieldreference1 = (fieldreference) receiver;

receiverstart = fieldreference1.sourcestart;
receiverend = fieldreference1.sourceend + 1;

if (fieldreference1.receiver instanceof thisreference) {

receivername = new char[][] {this, fieldreference1.token};

// if (field instanceof x) this.field.|
if (instanceofexpression.expression instanceof singlenamereference &&
((singlenamereference)instanceofexpression.expression).binding == fieldreference1.binding) {
findfromanotherreceiver = true;
}

// if (this.field instanceof x) this.field.|
if (instanceofexpression.expression instanceof fieldreference) {
fieldreference fieldreference2 = (fieldreference)instanceofexpression.expression;

if (fieldreference2.receiver instanceof thisreference &&
fieldreference2.binding == fieldreference1.binding) {
findfromanotherreceiver = true;
}
}
}
}

if (findfromanotherreceiver) {
typebinding receivertypebinding = instanceoftype.resolvedtype;
char[] castedreceiver = null;

char[] castedtypechars = charoperation.concatwith(instanceoftype.gettypename(), '.');
if(this.source != null) {
int memberrefstart = this.startposition;

char[] receiverchars = charoperation.subarray(this.source, receiverstart, receiverend);
char[] dotchars = charoperation.subarray(this.source, receiverend, memberrefstart);

castedreceiver =
charoperation.concat(
charoperation.concat(
'(',
charoperation.concat(
charoperation.concat('(', castedtypechars, ')'),
receiverchars),
')'),
dotchars);
} else {
castedreceiver =
charoperation.concat(
charoperation.concat(
'(',
charoperation.concat(
charoperation.concat('(', castedtypechars, ')'),
charoperation.concatwith(receivername, '.')),
')'),
dot);
}

if (castedreceiver == null) return;

int oldstartposition = this.startposition;
this.startposition = receiverstart;

findfieldsandmethods(
this.completiontoken,
receivertypebinding,
scope,
fieldsfound,
methodsfound,
invocationsite,
invocationscope,
false,
false,
null,
null,
null,
false,
castedreceiver,
receiverstart,
receiverend);

this.startposition = oldstartposition;
}
}
private void findfieldsandmethodsfromfavorites(
char[] token,
scope scope,
invocationsite invocationsite,
scope invocationscope,
objectvector localsfound,
objectvector fieldsfound,
objectvector methodsfound) {

objectvector methodsfoundfromfavorites = new objectvector();

importbinding[] favoritebindings = getfavoritereferencebindings(invocationscope);

if (favoritebindings != null && favoritebindings.length > 0) {
for (int i = 0; i < favoritebindings.length; i++) {
importbinding favoritebinding = favoritebindings[i];
switch (favoritebinding.resolvedimport.kind()) {
case binding.field:
fieldbinding fieldbinding = (fieldbinding) favoritebinding.resolvedimport;
findfieldsfromfavorites(
token,
new fieldbinding[]{fieldbinding},
scope,
fieldsfound,
localsfound,
fieldbinding.declaringclass,
invocationsite,
invocationscope);
break;
case binding.method:
methodbinding methodbinding = (methodbinding) favoritebinding.resolvedimport;
methodbinding[] methods = methodbinding.declaringclass.availablemethods();
long range;
if ((range = referencebinding.binarysearch(methodbinding.selector, methods)) >= 0) {
int start = (int) range, end = (int) (range >> 32);
int length = end - start + 1;
system.arraycopy(methods, start, methods = new methodbinding[length], 0, length);
} else {
methods = binding.no_methods;
}
findlocalmethodsfromfavorites(
token,
methods,
scope,
methodsfound,
methodsfoundfromfavorites,
methodbinding.declaringclass,
invocationsite,
invocationscope);
break;
case binding.type:
referencebinding referencebinding = (referencebinding) favoritebinding.resolvedimport;
if(favoritebinding.ondemand) {
findfieldsfromfavorites(
token,
referencebinding.availablefields(),
scope,
fieldsfound,
localsfound,
referencebinding,
invocationsite,
invocationscope);

findlocalmethodsfromfavorites(
token,
referencebinding.availablemethods(),
scope,
methodsfound,
methodsfoundfromfavorites,
referencebinding,
invocationsite,
invocationscope);
}
break;
}
}
}

methodsfound.addall(methodsfoundfromfavorites);
}

private boolean findfieldsandmethodsfrommissingfieldtype(
char[] token,
scope scope,
invocationsite invocationsite,
boolean insidetypeannotation) {

boolean foundsomefields = false;

boolean staticsonly = false;
scope currentscope = scope;

done : while (true) { // done when a compilation_unit_scope is found

switch (currentscope.kind) {

case scope.method_scope :
// handle the error case inside an explicit constructor call (see methodscope>>findfield)
methodscope methodscope = (methodscope) currentscope;
staticsonly |= methodscope.isstatic | methodscope.isconstructorcall;
break;
case scope.class_scope :
classscope classscope = (classscope) currentscope;
sourcetypebinding enclosingtype = classscope.referencecontext.binding;
if(!insidetypeannotation) {

fielddeclaration[] fields = classscope.referencecontext.fields;

int fieldscount = fields == null ? 0 : fields.length;
for (int i = 0; i < fieldscount; i++) {
fielddeclaration fielddeclaration = fields[i];
if (charoperation.equals(fielddeclaration.name, token)) {
fieldbinding fieldbinding = fielddeclaration.binding;
if (fieldbinding == null || fieldbinding.type == null  || (fieldbinding.type.tagbits & tagbits.hasmissingtype) != 0) {
foundsomefields = true;
findfieldsandmethodsfrommissingtype(
fielddeclaration.type,
currentscope,
invocationsite,
scope);
}
break done;
}
}
}
staticsonly |= enclosingtype.isstatic();
insidetypeannotation = false;
break;
case scope.compilation_unit_scope :
break done;
}
currentscope = currentscope.parent;
}
return foundsomefields;
}

private void findfieldsandmethodsfrommissingreturntype(
char[] token,
typebinding[] arguments,
scope scope,
invocationsite invocationsite,
boolean insidetypeannotation) {

boolean staticsonly = false;
scope currentscope = scope;

done : while (true) { // done when a compilation_unit_scope is found

switch (currentscope.kind) {

case scope.method_scope :
// handle the error case inside an explicit constructor call (see methodscope>>findfield)
methodscope methodscope = (methodscope) currentscope;
staticsonly |= methodscope.isstatic | methodscope.isconstructorcall;
break;
case scope.class_scope :
classscope classscope = (classscope) currentscope;
sourcetypebinding enclosingtype = classscope.referencecontext.binding;
if(!insidetypeannotation) {

abstractmethoddeclaration[] methods = classscope.referencecontext.methods;

int methodscount = methods == null ? 0 : methods.length;
for (int i = 0; i < methodscount; i++) {
abstractmethoddeclaration methoddeclaration = methods[i];
if (methoddeclaration instanceof methoddeclaration &&
charoperation.equals(methoddeclaration.selector, token)) {
methoddeclaration method = (methoddeclaration) methoddeclaration;
methodbinding methodbinding = method.binding;
if (methodbinding == null || methodbinding.returntype == null  || (methodbinding.returntype.tagbits & tagbits.hasmissingtype) != 0) {
argument[] parameters = method.arguments;
int parameterslength = parameters == null ? 0 : parameters.length;
int argumentslength = arguments == null ? 0 : arguments.length;

if (parameterslength == 0) {
if (argumentslength == 0) {
findfieldsandmethodsfrommissingtype(
method.returntype,
currentscope,
invocationsite,
scope);
break done;
}
} else {
typebinding[] parametersbindings;
if (methodbinding == null) { // since no binding, extra types from type references
parametersbindings = new typebinding[parameterslength];
for (int j = 0; j < parameterslength; j++) {
typebinding parametertype = parameters[j].type.resolvedtype;
if (!parametertype.isvalidbinding() && parametertype.closestmatch() != null) {
parametertype = parametertype.closestmatch();
}
parametersbindings[j] = parametertype;
}
} else {
parametersbindings = methodbinding.parameters;
}
if(areparameterscompatiblewith(parametersbindings, arguments, parameters[parameterslength - 1].isvarargs())) {
findfieldsandmethodsfrommissingtype(
method.returntype,
currentscope,
invocationsite,
scope);
break done;
}
}
}

}
}
}
staticsonly |= enclosingtype.isstatic();
insidetypeannotation = false;
break;
case scope.compilation_unit_scope :
break done;
}
currentscope = currentscope.parent;
}
}

private void findfieldsandmethodsfrommissingtype(
typereference typeref,
final scope scope,
final invocationsite invocationsite,
final scope invocationscope) {
missingtypesguesser missingtypesconverter = new missingtypesguesser(this);
missingtypesguesser.guessedtyperequestor substitutionrequestor =
new missingtypesguesser.guessedtyperequestor() {
public void accept(
typebinding guessedtype,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean hasproblems) {
findfieldsandmethods(
completionengine.this.completiontoken,
guessedtype,
scope,
new objectvector(),
new objectvector(),
invocationsite,
invocationscope,
false,
false,
missingelements,
missingelementsstarts,
missingelementsends,
hasproblems,
null,
-1,
-1);

}
};
missingtypesconverter.guess(typeref, scope, substitutionrequestor);
}

private void findfieldsandmethodsfromstaticimports(
char[] token,
scope scope,
invocationsite invocationsite,
scope invocationscope,
boolean exactmatch,
boolean insideannotationattribute,
objectvector localsfound,
objectvector fieldsfound,
objectvector methodsfound,
boolean proposefield,
boolean proposemethod) {
// search in static import
importbinding[] importbindings = scope.compilationunitscope().imports;
for (int i = 0; i < importbindings.length; i++) {
importbinding importbinding = importbindings[i];
if(importbinding.isvalidbinding() && importbinding.isstatic()) {
binding binding = importbinding.resolvedimport;
if(binding != null && binding.isvalidbinding()) {
if(importbinding.ondemand) {
if((binding.kind() & binding.type) != 0) {
if(proposefield) {
findfields(
token,
(referencebinding)binding,
scope,
fieldsfound,
localsfound,
true,
invocationsite,
invocationscope,
true,
false,
null,
null,
null,
false,
null,
-1,
-1);
}
if(proposemethod && !insideannotationattribute) {
findmethods(
token,
null,
null,
(referencebinding)binding,
scope,
methodsfound,
true,
exactmatch,
invocationsite,
invocationscope,
true,
false,
false,
null,
null,
null,
false,
null,
-1,
-1);
}
}
} else {
if ((binding.kind() & binding.field) != 0) {
if(proposefield) {
findfields(
token,
new fieldbinding[]{(fieldbinding)binding},
scope,
fieldsfound,
localsfound,
true,
((fieldbinding)binding).declaringclass,
invocationsite,
invocationscope,
true,
false,
null,
null,
null,
false,
null,
-1,
-1);
}
} else if ((binding.kind() & binding.method) != 0) {
if(proposemethod && !insideannotationattribute) {
methodbinding methodbinding = (methodbinding)binding;
if ((exactmatch && charoperation.equals(token, methodbinding.selector)) ||
!exactmatch && charoperation.prefixequals(token, methodbinding.selector) ||
(this.options.camelcasematch && charoperation.camelcasematch(token, methodbinding.selector))) {
findlocalmethodsfromstaticimports(
token,
methodbinding.declaringclass.getmethods(methodbinding.selector),
scope,
exactmatch,
methodsfound,
methodbinding.declaringclass,
invocationsite);
}
}
}
}
}
}
}
}

private void findfieldsfromfavorites(
char[] fieldname,
fieldbinding[] fields,
scope scope,
objectvector fieldsfound,
objectvector localsfound,
referencebinding receivertype,
invocationsite invocationsite,
scope invocationscope) {

char[] typename = charoperation.concatwith(receivertype.compoundname, '.');

int fieldlength = fieldname.length;
next : for (int f = fields.length; --f >= 0;) {
fieldbinding field = fields[f];

if (field.issynthetic())	continue next;

// only static fields must be proposed
if (!field.isstatic()) continue next;

if (fieldlength > field.name.length) continue next;

if (!charoperation.prefixequals(fieldname, field.name, false /* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(fieldname, field.name)))	continue next;

if (this.options.checkdeprecation &&
field.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(field.declaringclass))
continue next;

if (this.options.checkvisibility
&& !field.canbeseenby(receivertype, invocationsite, scope))	continue next;

for (int i = fieldsfound.size; --i >= 0;) {
object[] other = (object[])fieldsfound.elementat(i);
fieldbinding otherfield = (fieldbinding) other[0];

if (field == otherfield) continue next;
}

fieldsfound.add(new object[]{field, receivertype});

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal(field);
relevance += computerelevanceforcasematching(fieldname, field.name);
relevance += computerelevanceforexpectingtype(field.type);
relevance += computerelevanceforenumconstant(field.type);
relevance += computerelevanceforstatic(true, true);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

compilationunitdeclaration cu = this.unitscope.referencecontext;
int importstart = cu.types[0].declarationsourcestart;
int importend = importstart;

this.noproposal = false;

if (this.compileroptions.compliancelevel < classfileconstants.jdk1_5 ||
!this.options.suggeststaticimport) {
if (!this.isignored(completionproposal.field_ref, completionproposal.type_import)) {
char[] completion = charoperation.concat(receivertype.sourcename, field.name, '.');

internalcompletionproposal proposal =  createproposal(completionproposal.field_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(field.declaringclass));
proposal.setsignature(getsignature(field.type));
proposal.setdeclarationpackagename(field.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(field.declaringclass.qualifiedsourcename());
proposal.setpackagename(field.type.qualifiedpackagename());
proposal.settypename(field.type.qualifiedsourcename());
proposal.setname(field.name);
proposal.setcompletion(completion);
proposal.setflags(field.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);

char[] typeimportcompletion = createimportchararray(typename, false, false);

internalcompletionproposal typeimportproposal = createproposal(completionproposal.type_import, this.actualcompletionposition);
typeimportproposal.namelookup = this.nameenvironment.namelookup;
typeimportproposal.completionengine = this;
char[] packagename = receivertype.qualifiedpackagename();
typeimportproposal.setdeclarationsignature(packagename);
typeimportproposal.setsignature(getsignature(receivertype));
typeimportproposal.setpackagename(packagename);
typeimportproposal.settypename(receivertype.qualifiedsourcename());
typeimportproposal.setcompletion(typeimportcompletion);
typeimportproposal.setflags(receivertype.modifiers);
typeimportproposal.setadditionalflags(completionflags.default);
typeimportproposal.setreplacerange(importstart - this.offset, importend - this.offset);
typeimportproposal.settokenrange(importstart - this.offset, importend - this.offset);
typeimportproposal.setrelevance(relevance);

proposal.setrequiredproposals(new completionproposal[]{typeimportproposal});

this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
} else {
if (!this.isignored(completionproposal.field_ref, completionproposal.field_import)) {
char[] completion = field.name;

internalcompletionproposal proposal =  createproposal(completionproposal.field_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(field.declaringclass));
proposal.setsignature(getsignature(field.type));
proposal.setdeclarationpackagename(field.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(field.declaringclass.qualifiedsourcename());
proposal.setpackagename(field.type.qualifiedpackagename());
proposal.settypename(field.type.qualifiedsourcename());
proposal.setname(field.name);
proposal.setcompletion(completion);
proposal.setflags(field.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);

char[] fieldimportcompletion = createimportchararray(charoperation.concat(typename, field.name, '.'), true, false);

internalcompletionproposal fieldimportproposal = createproposal(completionproposal.field_import, this.actualcompletionposition);
fieldimportproposal.setdeclarationsignature(getsignature(field.declaringclass));
fieldimportproposal.setsignature(getsignature(field.type));
fieldimportproposal.setdeclarationpackagename(field.declaringclass.qualifiedpackagename());
fieldimportproposal.setdeclarationtypename(field.declaringclass.qualifiedsourcename());
fieldimportproposal.setpackagename(field.type.qualifiedpackagename());
fieldimportproposal.settypename(field.type.qualifiedsourcename());
fieldimportproposal.setname(field.name);
fieldimportproposal.setcompletion(fieldimportcompletion);
fieldimportproposal.setflags(field.modifiers);
fieldimportproposal.setadditionalflags(completionflags.staticimport);
fieldimportproposal.setreplacerange(importstart - this.offset, importend - this.offset);
fieldimportproposal.settokenrange(importstart - this.offset, importend - this.offset);
fieldimportproposal.setrelevance(relevance);

proposal.setrequiredproposals(new completionproposal[]{fieldimportproposal});

this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}
}
private void findimplicitmessagesends(
char[] token,
typebinding[] argtypes,
scope scope,
invocationsite invocationsite,
scope invocationscope,
objectvector methodsfound) {

if (token == null)
return;

boolean staticsonly = false;
// need to know if we're in a static context (or inside a constructor)

done : while (true) { // done when a compilation_unit_scope is found

switch (scope.kind) {

case scope.method_scope :
// handle the error case inside an explicit constructor call (see methodscope>>findfield)
methodscope methodscope = (methodscope) scope;
staticsonly |= methodscope.isstatic | methodscope.isconstructorcall;
break;

case scope.class_scope :
classscope classscope = (classscope) scope;
sourcetypebinding enclosingtype = classscope.referencecontext.binding;
findmethods(
token,
null,
argtypes,
enclosingtype,
classscope,
methodsfound,
staticsonly,
true,
invocationsite,
invocationscope,
true,
false,
true,
null,
null,
null,
false,
null,
-1,
-1);
staticsonly |= enclosingtype.isstatic();
break;

case scope.compilation_unit_scope :
break done;
}
scope = scope.parent;
}
}
private void findimports(completiononimportreference importreference, boolean findmembers) {
char[][] tokens = importreference.tokens;

char[] importname = charoperation.concatwith(tokens, '.');

if (importname.length == 0)
return;

char[] lasttoken = tokens[tokens.length - 1];
if(lasttoken != null && lasttoken.length == 0)
importname = charoperation.concat(importname, new char[]{'.'});

this.resolvingimports = true;
this.resolvingstaticimports = importreference.isstatic();

this.completiontoken =  lasttoken;
this.qualifiedcompletiontoken = importname;

// want to replace the existing .*;
if(!this.requestor.isignored(completionproposal.package_ref)) {
int oldstart = this.startposition;
int oldend = this.endposition;
setsourcerange(
importreference.sourcestart,
importreference.declarationsourceend);
this.nameenvironment.findpackages(importname, this);
setsourcerange(
oldstart,
oldend - 1,
false);
}
if(!this.requestor.isignored(completionproposal.type_ref)) {
this.foundtypescount = 0;
this.nameenvironment.findtypes(
importname,
findmembers,
this.options.camelcasematch,
ijavasearchconstants.type,
this,
this.monitor);
accepttypes(null);
}
}

private void findimportsofmembertypes(char[] typename,	referencebinding ref, boolean onlystatic) {
referencebinding[] membertypes = ref.membertypes();

int typelength = typename.length;
next : for (int m = membertypes.length; --m >= 0;) {
referencebinding membertype = membertypes[m];
//		if (!wantclasses && membertype.isclass()) continue next;
//		if (!wantinterfaces && membertype.isinterface()) continue next;

if (onlystatic && !membertype.isstatic())
continue next;

if (typelength > membertype.sourcename.length)
continue next;

if (!charoperation.prefixequals(typename, membertype.sourcename, false/* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(typename, membertype.sourcename)))
continue next;

if (this.options.checkdeprecation && membertype.isviewedasdeprecated()) continue next;

if (this.options.checkvisibility
&& !membertype.canbeseenby(this.unitscope.fpackage))
continue next;

char[] completionname = charoperation.concat(membertype.sourcename, semicolon);

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(typename, membertype.sourcename);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

if (membertype.isclass()) {
relevance += computerelevanceforclass();
} else if(membertype.isenum()) {
relevance += computerelevanceforenum();
} else if (membertype.isinterface()) {
relevance += computerelevanceforinterface();
}
this.noproposal = false;
if(!this.requestor.isignored(completionproposal.type_ref)) {
createtypeproposal(
membertype,
membertype.qualifiedsourcename(),
iaccessrule.k_accessible,
completionname,
relevance,
null,
null,
null,
false);
}
}
}

private void findimportsofstaticfields(char[] fieldname, referencebinding ref) {
fieldbinding[] fields = ref.availablefields();

int fieldlength = fieldname.length;
next : for (int m = fields.length; --m >= 0;) {
fieldbinding field = fields[m];

if (fieldlength > field.name.length)
continue next;

if (field.issynthetic())
continue next;

if (!field.isstatic())
continue next;

if (!charoperation.prefixequals(fieldname, field.name, false/* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(fieldname, field.name)))
continue next;

if (this.options.checkdeprecation && field.isviewedasdeprecated()) continue next;

if (this.options.checkvisibility
&& !field.canbeseenby(this.unitscope.fpackage))
continue next;

char[] completionname = charoperation.concat(field.name, semicolon);

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(fieldname, field.name);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.field_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.field_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(field.declaringclass));
proposal.setsignature(getsignature(field.type));
proposal.setdeclarationpackagename(field.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(field.declaringclass.qualifiedsourcename());
proposal.setpackagename(field.type.qualifiedpackagename());
proposal.settypename(field.type.qualifiedsourcename());
proposal.setname(field.name);
proposal.setcompletion(completionname);
proposal.setflags(field.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}

private void findimportsofstaticmethods(char[] methodname, referencebinding ref) {
methodbinding[] methods = ref.availablemethods();

int methodlength = methodname.length;
next : for (int m = methods.length; --m >= 0;) {
methodbinding method = methods[m];

if (method.issynthetic()) continue next;

if (method.isdefaultabstract())	continue next;

if (method.isconstructor()) continue next;

if (!method.isstatic()) continue next;

if (this.options.checkdeprecation && method.isviewedasdeprecated()) continue next;

if (this.options.checkvisibility
&& !method.canbeseenby(this.unitscope.fpackage)) continue next;

if (methodlength > method.selector.length)
continue next;

if (!charoperation.prefixequals(methodname, method.selector, false/* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(methodname, method.selector)))
continue next;

int length = method.parameters.length;
char[][] parameterpackagenames = new char[length][];
char[][] parametertypenames = new char[length][];

for (int i = 0; i < length; i++) {
typebinding type = method.original().parameters[i];
parameterpackagenames[i] = type.qualifiedpackagename();
parametertypenames[i] = type.qualifiedsourcename();
}
char[][] parameternames = findmethodparameternames(method,parametertypenames);

char[] completionname = charoperation.concat(method.selector, semicolon);

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(methodname, method.selector);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.method_name_reference)) {
internalcompletionproposal proposal =  createproposal(completionproposal.method_name_reference, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(method.declaringclass));
proposal.setsignature(getsignature(method));
proposal.setdeclarationpackagename(method.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(method.declaringclass.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
proposal.setpackagename(method.returntype.qualifiedpackagename());
proposal.settypename(method.returntype.qualifiedsourcename());
proposal.setname(method.selector);
proposal.setcompletion(completionname);
proposal.setflags(method.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}

private void findinterfacesmethoddeclarations(
char[] selector,
referencebinding receivertype,
referencebinding[] itsinterfaces,
scope scope,
objectvector methodsfound,
binding[] missingelements,
int[] missingelementssstarts,
int[] missingelementsends,
boolean missingelementshaveproblems) {

if (selector == null)
return;

if (itsinterfaces != binding.no_superinterfaces) {
referencebinding[] interfacestovisit = itsinterfaces;
int nextposition = interfacestovisit.length;

for (int i = 0; i < nextposition; i++) {
referencebinding currenttype = interfacestovisit[i];
methodbinding[] methods = currenttype.availablemethods();
if(methods != null) {
findlocalmethoddeclarations(
selector,
methods,
scope,
methodsfound,
false,
receivertype);
}

itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
}

private void findinterfacesmethods(
char[] selector,
typebinding[] typeargtypes,
typebinding[] argtypes,
referencebinding receivertype,
referencebinding[] itsinterfaces,
scope scope,
objectvector methodsfound,
boolean onlystaticmethods,
boolean exactmatch,
invocationsite invocationsite,
scope invocationscope,
boolean implicitcall,
boolean supercall,
boolean canbeprefixed,
binding[] missingelements,
int[] missingelementssstarts,
int[] missingelementsends,
boolean missingelementshaveproblems,
char[] castedreceiver,
int receiverstart,
int receiverend) {

if (selector == null)
return;

if (itsinterfaces != binding.no_superinterfaces) {
referencebinding[] interfacestovisit = itsinterfaces;
int nextposition = interfacestovisit.length;

for (int i = 0; i < nextposition; i++) {
referencebinding currenttype = interfacestovisit[i];
methodbinding[] methods = currenttype.availablemethods();
if(methods != null) {
findlocalmethods(
selector,
typeargtypes,
argtypes,
methods,
scope,
methodsfound,
onlystaticmethods,
exactmatch,
receivertype,
invocationsite,
invocationscope,
implicitcall,
supercall,
canbeprefixed,
missingelements,
missingelementssstarts,
missingelementsends,
missingelementshaveproblems,
castedreceiver,
receiverstart,
receiverend);
}

itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
}
/*
* find javadoc block tags for a given completion javadoc tag node
*/
private void findjavadocblocktags(completiononjavadoctag javadoctag) {
char[][] possibletags = javadoctag.getpossibleblocktags();
if (possibletags == null) return;
int length = possibletags.length;
for (int i=0; i<length; i++) {
int relevance = computebaserelevance();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for keywors

this.noproposal = false;
if (!this.requestor.isignored(completionproposal.javadoc_block_tag)) {
char[] possibletag = possibletags[i];
internalcompletionproposal proposal =  createproposal(completionproposal.javadoc_block_tag, this.actualcompletionposition);
proposal.setname(possibletag);
int taglength = possibletag.length;
char[] completion = new char[1+taglength];
completion[0] = '@@';
system.arraycopy(possibletag, 0, completion, 1, taglength);
proposal.setcompletion(completion);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if (debug) {
this.printdebug(proposal);
}
}
}
}

/*
* find javadoc inline tags for a given completion javadoc tag node
*/
private void findjavadocinlinetags(completiononjavadoctag javadoctag) {
char[][] possibletags = javadoctag.getpossibleinlinetags();
if (possibletags == null) return;
int length = possibletags.length;
for (int i=0; i<length; i++) {
int relevance = computebaserelevance();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for keywors

this.noproposal = false;
if (!this.requestor.isignored(completionproposal.javadoc_inline_tag)) {
char[] possibletag = possibletags[i];
internalcompletionproposal proposal =  createproposal(completionproposal.javadoc_inline_tag, this.actualcompletionposition);
proposal.setname(possibletag);
int taglength = possibletag.length;
//				boolean inlinetagstarted = javadoctag.completeinlinetagstarted();
char[] completion = new char[2+taglength+1];
completion[0] = '{';
completion[1] = '@@';
system.arraycopy(possibletag, 0, completion, 2, taglength);
// do not add space at end of inline tag (see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=121026)
//completion[taglength+2] = ' ';
completion[taglength+2] = '}';
proposal.setcompletion(completion);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if (debug) {
this.printdebug(proposal);
}
}
}
}

/*
* find javadoc parameter names.
*/
private void findjavadocparamnames(char[] token, char[][] missingparams, boolean istypeparam) {

if (missingparams == null) return;

// get relevance
int relevance = computebaserelevance();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for param name
if (!istypeparam) relevance += r_interesting;

// propose missing param
int length = missingparams.length;
relevance += length;
for (int i=0; i<length; i++) {
char[] argname = missingparams[i];
if (token == null || charoperation.prefixequals(token, argname)) {

this.noproposal = false;
if (!this.requestor.isignored(completionproposal.javadoc_param_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.javadoc_param_ref, this.actualcompletionposition);
proposal.setname(argname);
char[] completion = istypeparam ? charoperation.concat('<', argname, '>') : argname;
proposal.setcompletion(completion);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(--relevance);
this.requestor.accept(proposal);
if (debug) {
this.printdebug(proposal);
}
}
}
}
}

// what about ondemand types? ignore them since it does not happen!
// import p1.p2.a.*;
private void findkeywords(char[] keyword, char[][] choices, boolean cancompleteemptytoken, boolean staticfieldsandmethodonly) {
if(choices == null || choices.length == 0) return;

int length = keyword.length;
if (cancompleteemptytoken || length > 0)
for (int i = 0; i < choices.length; i++)
if (length <= choices[i].length
&& charoperation.prefixequals(keyword, choices[i], false /* ignore case */
)){
int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(keyword, choices[i]);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for keywords
if (staticfieldsandmethodonly && this.insidequalifiedreference) relevance += r_non_inherited;

if(charoperation.equals(choices[i], keywords.true) || charoperation.equals(choices[i], keywords.false)) {
relevance += computerelevanceforexpectingtype(typebinding.boolean);
relevance += computerelevanceforqualification(false);
}
this.noproposal = false;
if(!this.requestor.isignored(completionproposal.keyword)) {
internalcompletionproposal proposal =  createproposal(completionproposal.keyword, this.actualcompletionposition);
proposal.setname(choices[i]);
proposal.setcompletion(choices[i]);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}
private void findkeywordsformember(char[] token, int modifiers) {
char[][] keywords = new char[keywords.count][];
int count = 0;

// visibility
if((modifiers & classfileconstants.accprivate) == 0
&& (modifiers & classfileconstants.accprotected) == 0
&& (modifiers & classfileconstants.accpublic) == 0) {
keywords[count++] = keywords.protected;
keywords[count++] = keywords.public;
if((modifiers & classfileconstants.accabstract) == 0) {
keywords[count++] = keywords.private;
}
}

if((modifiers & classfileconstants.accabstract) == 0) {
// abtract
if((modifiers & ~(extracompilermodifiers.accvisibilitymask | classfileconstants.accstatic)) == 0) {
keywords[count++] = keywords.abstract;
}

// final
if((modifiers & classfileconstants.accfinal) == 0) {
keywords[count++] = keywords.final;
}

// static
if((modifiers & classfileconstants.accstatic) == 0) {
keywords[count++] = keywords.static;
}

boolean canbefield = true;
boolean canbemethod = true;
boolean canbetype = true;
if((modifiers & classfileconstants.accnative) != 0
|| (modifiers & classfileconstants.accstrictfp) != 0
|| (modifiers & classfileconstants.accsynchronized) != 0) {
canbefield = false;
canbetype = false;
}

if((modifiers & classfileconstants.acctransient) != 0
|| (modifiers & classfileconstants.accvolatile) != 0) {
canbemethod = false;
canbetype = false;
}

if(canbefield) {
// transient
if((modifiers & classfileconstants.acctransient) == 0) {
keywords[count++] = keywords.transient;
}

// volatile
if((modifiers & classfileconstants.accvolatile) == 0) {
keywords[count++] = keywords.volatile;
}
}

if(canbemethod) {
// native
if((modifiers & classfileconstants.accnative) == 0) {
keywords[count++] = keywords.native;
}

// strictfp
if((modifiers & classfileconstants.accstrictfp) == 0) {
keywords[count++] = keywords.strictfp;
}

// synchronized
if((modifiers & classfileconstants.accsynchronized) == 0) {
keywords[count++] = keywords.synchronized;
}
}

if(canbetype) {
keywords[count++] = keywords.class;
keywords[count++] = keywords.interface;

if((modifiers & classfileconstants.accfinal) == 0) {
keywords[count++] = keywords.enum;
}
}
} else {
// class
keywords[count++] = keywords.class;
keywords[count++] = keywords.interface;
}
system.arraycopy(keywords, 0, keywords = new char[count][], 0, count);

findkeywords(token, keywords, false, false);
}
private void findlabels(char[] label, char[][] choices) {
if(choices == null || choices.length == 0) return;

int length = label.length;
for (int i = 0; i < choices.length; i++) {
if (length <= choices[i].length
&& charoperation.prefixequals(label, choices[i], false /* ignore case */
)){
int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(label, choices[i]);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for keywors

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.label_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.label_ref, this.actualcompletionposition);
proposal.setname(choices[i]);
proposal.setcompletion(choices[i]);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}
}

// helper method for findmethods(char[], methodbinding[], scope, objectvector, boolean, boolean, boolean, typebinding)
private void findlocalmethoddeclarations(
char[] methodname,
methodbinding[] methods,
scope scope,
objectvector methodsfound,
//	boolean novoidreturntype, how do you know?
boolean exactmatch,
referencebinding receivertype) {

objectvector newmethodsfound =  new objectvector();
// inherited methods which are hidden by subclasses are filtered out
// no visibility checks can be performed without the scope & invocationsite
int methodlength = methodname.length;
next : for (int f = methods.length; --f >= 0;) {

methodbinding method = methods[f];
if (method.issynthetic())	continue next;

if (method.isdefaultabstract()) continue next;

if (method.isconstructor()) continue next;

if (method.isfinal()) {
newmethodsfound.add(method);
continue next;
}

if (this.options.checkdeprecation &&
method.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(method.declaringclass))
continue next;

//		if (novoidreturntype && method.returntype == basetypes.voidbinding) continue next;
if(method.isstatic()) continue next;

if (!method.canbeseenby(receivertype, fakeinvocationsite , scope)) continue next;

if (exactmatch) {
if (!charoperation.equals(methodname, method.selector, false /* ignore case */
))
continue next;

} else {

if (methodlength > method.selector.length)
continue next;

if (!charoperation.prefixequals(methodname, method.selector, false/* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(methodname, method.selector)))
continue next;
}

for (int i = methodsfound.size; --i >= 0;) {
methodbinding othermethod = (methodbinding) methodsfound.elementat(i);
if (method == othermethod)
continue next;

if (charoperation.equals(method.selector, othermethod.selector, true)
&& this.lookupenvironment.methodverifier().ismethodsubsignature(othermethod, method)) {
continue next;
}
}

newmethodsfound.add(method);

int length = method.parameters.length;
char[][] parameterpackagenames = new char[length][];
char[][] parameterfulltypenames = new char[length][];

for (int i = 0; i < length; i++) {
typebinding type = method.parameters[i];
parameterpackagenames[i] = type.qualifiedpackagename();
parameterfulltypenames[i] = type.qualifiedsourcename();
}

char[][] parameternames = findmethodparameternames(method, parameterfulltypenames);

if(method.typevariables != null && method.typevariables.length > 0) {
char[][] excludednames = findenclosingtypenames(scope);
char[][] substituedparameternames = substitutemethodtypeparameternames(method.typevariables, excludednames);
if(substituedparameternames != null) {
method = new parameterizedmethodbinding(
method.declaringclass,
method,
substituedparameternames,
scope.environment());
}
}

stringbuffer completion = new stringbuffer(10);
if (!exactmatch) {
createmethod(method, parameterpackagenames, parameterfulltypenames, parameternames, scope, completion);
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(methodname, method.selector);
relevance += r_method_overide;
if(method.isabstract()) relevance += r_abstract_method;
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.method_declaration)) {
internalcompletionproposal proposal =  createproposal(completionproposal.method_declaration, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(method.declaringclass));
proposal.setdeclarationkey(method.declaringclass.computeuniquekey());
proposal.setsignature(getsignature(method));
methodbinding original = method.original();
if(original != method) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setkey(method.computeuniquekey());
proposal.setdeclarationpackagename(method.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(method.declaringclass.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parameterfulltypenames);
proposal.setpackagename(method.returntype.qualifiedpackagename());
proposal.settypename(method.returntype.qualifiedsourcename());
proposal.setcompletion(completion.tostring().tochararray());
proposal.setname(method.selector);
proposal.setflags(method.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
methodsfound.addall(newmethodsfound);
}

// helper method for findmethods(char[], typebinding[], referencebinding, scope, objectvector, boolean, boolean, boolean)
private void findlocalmethods(
char[] methodname,
typebinding[] typeargtypes,
typebinding[] argtypes,
methodbinding[] methods,
scope scope,
objectvector methodsfound,
boolean onlystaticmethods,
boolean exactmatch,
referencebinding receivertype,
invocationsite invocationsite,
scope invocationscope,
boolean implicitcall,
boolean supercall,
boolean canbeprefixed,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems,
char[] castedreceiver,
int receiverstart,
int receiverend) {

objectvector newmethodsfound =  new objectvector();
// inherited methods which are hidden by subclasses are filtered out
// no visibility checks can be performed without the scope & invocationsite

int methodlength = methodname.length;
int mintypearglength = typeargtypes == null ? 0 : typeargtypes.length;
int minarglength = argtypes == null ? 0 : argtypes.length;

next : for (int f = methods.length; --f >= 0;) {
methodbinding method = methods[f];

if (method.issynthetic()) continue next;

if (method.isdefaultabstract())	continue next;

if (method.isconstructor()) continue next;

if (this.options.checkdeprecation &&
method.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(method.declaringclass))
continue next;

//todo (david) perhaps the relevance of a void method must be lesser than other methods
//if (expectedtypesptr > -1 && method.returntype == basetypes.voidbinding) continue next;

if (onlystaticmethods && !method.isstatic()) continue next;

if (this.options.checkvisibility
&& !method.canbeseenby(receivertype, invocationsite, scope)) continue next;

if(supercall && method.isabstract()) {
methodsfound.add(new object[]{method, receivertype});
continue next;
}

if (exactmatch) {
if (!charoperation.equals(methodname, method.selector, false /* ignore case */)) {
continue next;
}
} else {
if (methodlength > method.selector.length) continue next;
if (!charoperation.prefixequals(methodname, method.selector, false /* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(methodname, method.selector))) {
continue next;
}
}

if (mintypearglength != 0 && mintypearglength != method.typevariables.length)
continue next;

if (mintypearglength != 0) {
method = scope.environment().createparameterizedgenericmethod(method, typeargtypes);
}

if (minarglength > method.parameters.length)
continue next;

for (int a = minarglength; --a >= 0;){
if (argtypes[a] != null) { // can be null if it could not be resolved properly
if (!argtypes[a].iscompatiblewith(method.parameters[a])) {
continue next;
}
}
}

boolean prefixrequired = false;

for (int i = methodsfound.size; --i >= 0;) {
object[] other = (object[]) methodsfound.elementat(i);
methodbinding othermethod = (methodbinding) other[0];
referencebinding otherreceivertype = (referencebinding) other[1];
if (method == othermethod && receivertype == otherreceivertype)
continue next;

if (charoperation.equals(method.selector, othermethod.selector, true)) {
if (receivertype == otherreceivertype) {
if (this.lookupenvironment.methodverifier().ismethodsubsignature(othermethod, method)) {
if (!supercall || !othermethod.declaringclass.isinterface()) {
continue next;
}
}
} else {
if (this.lookupenvironment.methodverifier().ismethodsubsignature(othermethod, method)) {
if(receivertype.isanonymoustype()) continue next;

if(!supercall) {
if(!canbeprefixed) continue next;

prefixrequired = true;
}
}
}
}
}

newmethodsfound.add(new object[]{method, receivertype});

referencebinding supertypewithsameerasure = (referencebinding)receivertype.findsupertypeoriginatingfrom(method.declaringclass);
if (method.declaringclass != supertypewithsameerasure) {
methodbinding[] othermethods = supertypewithsameerasure.getmethods(method.selector);
for (int i = 0; i < othermethods.length; i++) {
if(othermethods[i].original() == method.original()) {
method = othermethods[i];
}
}
}

int length = method.parameters.length;
char[][] parameterpackagenames = new char[length][];
char[][] parametertypenames = new char[length][];

for (int i = 0; i < length; i++) {
typebinding type = method.original().parameters[i];
parameterpackagenames[i] = type.qualifiedpackagename();
parametertypenames[i] = type.qualifiedsourcename();
}
char[][] parameternames = findmethodparameternames(method,parametertypenames);

char[] completion = charoperation.no_char;

int previousstartposition = this.startposition;
int previoustokenstart = this.tokenstart;

// special case for completion in javadoc
if (this.assistnodeinjavadoc > 0) {
expression receiver = null;
if (invocationsite instanceof completiononjavadocmessagesend) {
completiononjavadocmessagesend msg = (completiononjavadocmessagesend) invocationsite;
receiver = msg.receiver;
} else if (invocationsite instanceof completiononjavadocfieldreference) {
completiononjavadocfieldreference fieldref = (completiononjavadocfieldreference) invocationsite;
receiver = fieldref.receiver;
}
if (receiver != null) {
stringbuffer javadoccompletion = new stringbuffer();
if (receiver.isthis()) {
if ((this.assistnodeinjavadoc & completiononjavadoc.text) != 0) {
javadoccompletion.append('#');
}
} else if ((this.assistnodeinjavadoc & completiononjavadoc.text) != 0) {
if (receiver instanceof javadocsingletypereference) {
javadocsingletypereference typeref = (javadocsingletypereference) receiver;
javadoccompletion.append(typeref.token);
javadoccompletion.append('#');
} else if (receiver instanceof javadocqualifiedtypereference) {
javadocqualifiedtypereference typeref = (javadocqualifiedtypereference) receiver;
completion = charoperation.concat(charoperation.concatwith(typeref.tokens, '.'), method.selector, '#');
for (int t=0,nt =typeref.tokens.length; t<nt; t++) {
if (t>0) javadoccompletion.append('.');
javadoccompletion.append(typeref.tokens[t]);
}
javadoccompletion.append('#');
}
}
javadoccompletion.append(method.selector);
// append parameters types
javadoccompletion.append('(');
if (method.parameters != null) {
boolean isvarargs = method.isvarargs();
for (int p=0, ln=method.parameters.length; p<ln; p++) {
if (p>0) javadoccompletion.append(", "); //$non-nls-1$
typebinding argtypebinding = method.parameters[p];
if (isvarargs && p == ln - 1)  {
createvargstype(argtypebinding.erasure(), scope, javadoccompletion);
} else {
createtype(argtypebinding.erasure(), scope,javadoccompletion);
}
}
}
javadoccompletion.append(')');
completion = javadoccompletion.tostring().tochararray();
}
} else {
// nothing to insert - do not want to replace the existing selector & arguments
if (!exactmatch) {
if (this.source != null
&& this.source.length > this.endposition
&& this.source[this.endposition] == '(')
completion = method.selector;
else
completion = charoperation.concat(method.selector, new char[] { '(', ')' });

if (castedreceiver != null) {
completion = charoperation.concat(castedreceiver, completion);
}
} else {
if(prefixrequired && (this.source != null)) {
completion = charoperation.subarray(this.source, this.startposition, this.endposition);
} else {
this.startposition = this.endposition;
}
this.tokenstart = this.tokenend;
}

if(prefixrequired || this.options.forceimplicitqualification){
char[] prefix = computeprefix(scope.enclosingsourcetype(), invocationscope.enclosingsourcetype(), method.isstatic());
completion = charoperation.concat(prefix,completion,'.');
}
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(methodname, method.selector);
relevance += computerelevanceforexpectingtype(method.returntype);
relevance += computerelevanceforenumconstant(method.returntype);
relevance += computerelevanceforstatic(onlystaticmethods, method.isstatic());
relevance += computerelevanceforqualification(prefixrequired);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);
if (onlystaticmethods && this.insidequalifiedreference) {
relevance += computerelevanceforinheritance(receivertype, method.declaringclass);
}
if (missingelements != null) {
relevance += computerelevanceformissingelements(missingelementshaveproblems);
}

this.noproposal = false;

if (castedreceiver == null) {
// standard proposal
if(!this.isignored(completionproposal.method_ref, missingelements != null) && (this.assistnodeinjavadoc & completiononjavadoc.only_inline_tag) == 0) {
internalcompletionproposal proposal =  createproposal(completionproposal.method_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(method.declaringclass));
proposal.setsignature(getsignature(method));
methodbinding original = method.original();
if(original != method) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setdeclarationpackagename(method.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(method.declaringclass.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
proposal.setpackagename(method.returntype.qualifiedpackagename());
proposal.settypename(method.returntype.qualifiedsourcename());
proposal.setname(method.selector);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(completion);
proposal.setflags(method.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}

// javadoc proposal
if ((this.assistnodeinjavadoc & completiononjavadoc.text) != 0 && !this.requestor.isignored(completionproposal.javadoc_method_ref)) {
char[] javadoccompletion = inlinetagcompletion(completion, javadoctagconstants.tag_link);
internalcompletionproposal proposal =  createproposal(completionproposal.javadoc_method_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(method.declaringclass));
proposal.setsignature(getsignature(method));
methodbinding original = method.original();
if(original != method) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setdeclarationpackagename(method.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(method.declaringclass.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
proposal.setpackagename(method.returntype.qualifiedpackagename());
proposal.settypename(method.returntype.qualifiedsourcename());
proposal.setname(method.selector);
proposal.setcompletion(javadoccompletion);
proposal.setflags(method.modifiers);
int start = (this.assistnodeinjavadoc & completiononjavadoc.replace_tag) != 0 ? this.javadoctagposition : this.startposition;
proposal.setreplacerange(start - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance+r_inline_tag);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
} else {
if(!this.isignored(completionproposal.method_ref_with_casted_receiver, missingelements != null)) {
internalcompletionproposal proposal =  createproposal(completionproposal.method_ref_with_casted_receiver, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(method.declaringclass));
proposal.setsignature(getsignature(method));
methodbinding original = method.original();
if(original != method) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setreceiversignature(getsignature(receivertype));
proposal.setdeclarationpackagename(method.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(method.declaringclass.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
proposal.setpackagename(method.returntype.qualifiedpackagename());
proposal.settypename(method.returntype.qualifiedsourcename());
proposal.setname(method.selector);
if (missingelements != null) {
completionproposal[] subproposals = new completionproposal[missingelements.length];
for (int i = 0; i < missingelements.length; i++) {
subproposals[i] =
createrequiredtypeproposal(
missingelements[i],
missingelementsstarts[i],
missingelementsends[i],
relevance);
}
proposal.setrequiredproposals(subproposals);
}
proposal.setcompletion(completion);
proposal.setflags(method.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.setreceiverrange(receiverstart - this.offset, receiverend - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
this.startposition = previousstartposition;
this.tokenstart = previoustokenstart;
}

methodsfound.addall(newmethodsfound);
}
private void findlocalmethodsfromfavorites(
char[] methodname,
methodbinding[] methods,
scope scope,
objectvector methodsfound,
objectvector methodsfoundfromfavorites,
referencebinding receivertype,
invocationsite invocationsite,
scope invocationscope) {

char[] typename = charoperation.concatwith(receivertype.compoundname, '.');

int methodlength = methodname.length;

next : for (int f = methods.length; --f >= 0;) {
methodbinding method = methods[f];

if (method.issynthetic()) continue next;

if (method.isdefaultabstract())	continue next;

if (method.isconstructor()) continue next;

if (this.options.checkdeprecation &&
method.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(method.declaringclass))
continue next;

if (!method.isstatic()) continue next;

if (this.options.checkvisibility
&& !method.canbeseenby(receivertype, invocationsite, scope)) continue next;

if (methodlength > method.selector.length) continue next;

if (!charoperation.prefixequals(methodname, method.selector, false /* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(methodname, method.selector))) {
continue next;
}

for (int i = methodsfoundfromfavorites.size; --i >= 0;) {
object[] other = (object[]) methodsfoundfromfavorites.elementat(i);
methodbinding othermethod = (methodbinding) other[0];

if (method == othermethod) continue next;

if (charoperation.equals(method.selector, othermethod.selector, true)) {
if (othermethod.declaringclass == method.declaringclass &&
this.lookupenvironment.methodverifier().ismethodsubsignature(othermethod, method)) {
continue next;
}
}
}

for (int i = methodsfound.size; --i >= 0;) {
object[] other = (object[]) methodsfound.elementat(i);
methodbinding othermethod = (methodbinding) other[0];

if (method == othermethod) continue next;

if (charoperation.equals(method.selector, othermethod.selector, true)) {
if (this.lookupenvironment.methodverifier().ismethodsubsignature(othermethod, method)) {
continue next;
}
}
}

boolean proposestaticimport = !(this.compileroptions.compliancelevel < classfileconstants.jdk1_5) &&
this.options.suggeststaticimport;

boolean isalreadyimported = false;
if (!proposestaticimport) {
if(!this.importcachesinitialized) {
initializeimportcaches();
}
for (int j = 0; j < this.importcachecount; j++) {
char[][] importname = this.importscache[j];
if(charoperation.equals(receivertype.sourcename, importname[0])) {
if (!charoperation.equals(typename, importname[1])) {
continue next;
} else {
isalreadyimported = true;
}
}
}
}

methodsfoundfromfavorites.add(new object[]{method, receivertype});

referencebinding supertypewithsameerasure = (referencebinding)receivertype.findsupertypeoriginatingfrom(method.declaringclass);
if (method.declaringclass != supertypewithsameerasure) {
methodbinding[] othermethods = supertypewithsameerasure.getmethods(method.selector);
for (int i = 0; i < othermethods.length; i++) {
if(othermethods[i].original() == method.original()) {
method = othermethods[i];
}
}
}

int length = method.parameters.length;
char[][] parameterpackagenames = new char[length][];
char[][] parametertypenames = new char[length][];

for (int i = 0; i < length; i++) {
typebinding type = method.original().parameters[i];
parameterpackagenames[i] = type.qualifiedpackagename();
parametertypenames[i] = type.qualifiedsourcename();
}
char[][] parameternames = findmethodparameternames(method,parametertypenames);

char[] completion = charoperation.no_char;

int previousstartposition = this.startposition;
int previoustokenstart = this.tokenstart;

if (this.source != null
&& this.source.length > this.endposition
&& this.source[this.endposition] == '(') {
completion = method.selector;
} else {
completion = charoperation.concat(method.selector, new char[] { '(', ')' });
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(methodname, method.selector);
relevance += computerelevanceforexpectingtype(method.returntype);
relevance += computerelevanceforenumconstant(method.returntype);
relevance += computerelevanceforstatic(true, method.isstatic());
relevance += computerelevanceforqualification(true);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

compilationunitdeclaration cu = this.unitscope.referencecontext;
int importstart = cu.types[0].declarationsourcestart;
int importend = importstart;

this.noproposal = false;

if (!proposestaticimport) {
if (isalreadyimported) {
if (!isignored(completionproposal.method_ref)) {
completion = charoperation.concat(receivertype.sourcename, completion, '.');

internalcompletionproposal proposal =  createproposal(completionproposal.method_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(method.declaringclass));
proposal.setsignature(getsignature(method));
methodbinding original = method.original();
if(original != method) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setdeclarationpackagename(method.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(method.declaringclass.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
proposal.setpackagename(method.returntype.qualifiedpackagename());
proposal.settypename(method.returntype.qualifiedsourcename());
proposal.setname(method.selector);
proposal.setcompletion(completion);
proposal.setflags(method.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);

this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
} else if (!this.isignored(completionproposal.method_ref, completionproposal.type_import)) {
completion = charoperation.concat(receivertype.sourcename, completion, '.');

internalcompletionproposal proposal =  createproposal(completionproposal.method_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(method.declaringclass));
proposal.setsignature(getsignature(method));
methodbinding original = method.original();
if(original != method) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setdeclarationpackagename(method.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(method.declaringclass.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
proposal.setpackagename(method.returntype.qualifiedpackagename());
proposal.settypename(method.returntype.qualifiedsourcename());
proposal.setname(method.selector);
proposal.setcompletion(completion);
proposal.setflags(method.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);

char[] typeimportcompletion = createimportchararray(typename, false, false);

internalcompletionproposal typeimportproposal = createproposal(completionproposal.type_import, this.actualcompletionposition);
typeimportproposal.namelookup = this.nameenvironment.namelookup;
typeimportproposal.completionengine = this;
char[] packagename = receivertype.qualifiedpackagename();
typeimportproposal.setdeclarationsignature(packagename);
typeimportproposal.setsignature(getsignature(receivertype));
typeimportproposal.setpackagename(packagename);
typeimportproposal.settypename(receivertype.qualifiedsourcename());
typeimportproposal.setcompletion(typeimportcompletion);
typeimportproposal.setflags(receivertype.modifiers);
typeimportproposal.setadditionalflags(completionflags.default);
typeimportproposal.setreplacerange(importstart - this.offset, importend - this.offset);
typeimportproposal.settokenrange(importstart - this.offset, importend - this.offset);
typeimportproposal.setrelevance(relevance);

proposal.setrequiredproposals(new completionproposal[]{typeimportproposal});

this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
} else {
if (!this.isignored(completionproposal.method_ref, completionproposal.method_import)) {
internalcompletionproposal proposal =  createproposal(completionproposal.method_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(method.declaringclass));
proposal.setsignature(getsignature(method));
methodbinding original = method.original();
if(original != method) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setdeclarationpackagename(method.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(method.declaringclass.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
proposal.setpackagename(method.returntype.qualifiedpackagename());
proposal.settypename(method.returntype.qualifiedsourcename());
proposal.setname(method.selector);
proposal.setcompletion(completion);
proposal.setflags(method.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);

char[] methodimportcompletion = createimportchararray(charoperation.concat(typename, method.selector, '.'), true, false);

internalcompletionproposal methodimportproposal = createproposal(completionproposal.method_import, this.actualcompletionposition);
methodimportproposal.setdeclarationsignature(getsignature(method.declaringclass));
methodimportproposal.setsignature(getsignature(method));
if(original != method) {
proposal.setoriginalsignature(getsignature(original));
}
methodimportproposal.setdeclarationpackagename(method.declaringclass.qualifiedpackagename());
methodimportproposal.setdeclarationtypename(method.declaringclass.qualifiedsourcename());
methodimportproposal.setparameterpackagenames(parameterpackagenames);
methodimportproposal.setparametertypenames(parametertypenames);
methodimportproposal.setpackagename(method.returntype.qualifiedpackagename());
methodimportproposal.settypename(method.returntype.qualifiedsourcename());
methodimportproposal.setname(method.selector);
methodimportproposal.setcompletion(methodimportcompletion);
methodimportproposal.setflags(method.modifiers);
methodimportproposal.setadditionalflags(completionflags.staticimport);
methodimportproposal.setreplacerange(importstart - this.offset, importend - this.offset);
methodimportproposal.settokenrange(importstart - this.offset, importend - this.offset);
methodimportproposal.setrelevance(relevance);
if(parameternames != null) methodimportproposal.setparameternames(parameternames);

proposal.setrequiredproposals(new completionproposal[]{methodimportproposal});

this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}

this.startposition = previousstartposition;
this.tokenstart = previoustokenstart;
}
}

/**
* helper method for findmethods(char[], typebinding[], referencebinding, scope, objectvector, boolean, boolean, boolean)
* note that the method doesn't do a comparison of the method names and expects the client to handle the same.
*
* @@methodname method as entered by the user, the one to completed
* @@param methods a resultant array of methodbinding, whose names should match methodname. the calling client must ensure that this check is handled.
*/
private void findlocalmethodsfromstaticimports(
char[] methodname,
methodbinding[] methods,
scope scope,
boolean exactmatch,
objectvector methodsfound,
referencebinding receivertype,
invocationsite invocationsite) {

objectvector newmethodsfound =  new objectvector();

next : for (int f = methods.length; --f >= 0;) {
methodbinding method = methods[f];

if (method.issynthetic()) continue next;

if (method.isdefaultabstract())	continue next;

if (method.isconstructor()) continue next;

if (!method.isstatic()) continue next;

if (this.options.checkdeprecation &&
method.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(method.declaringclass))
continue next;

if (this.options.checkvisibility
&& !method.canbeseenby(receivertype, invocationsite, scope)) continue next;

for (int i = methodsfound.size; --i >= 0;) {
object[] other = (object[]) methodsfound.elementat(i);
methodbinding othermethod = (methodbinding) other[0];
referencebinding otherreceivertype = (referencebinding) other[1];
if (method == othermethod && receivertype == otherreceivertype)
continue next;

if (charoperation.equals(method.selector, othermethod.selector, true)) {
if (this.lookupenvironment.methodverifier().ismethodsubsignature(othermethod, method)) {
continue next;
}
}
}

newmethodsfound.add(new object[]{method, receivertype});

int length = method.parameters.length;
char[][] parameterpackagenames = new char[length][];
char[][] parametertypenames = new char[length][];

for (int i = 0; i < length; i++) {
typebinding type = method.original().parameters[i];
parameterpackagenames[i] = type.qualifiedpackagename();
parametertypenames[i] = type.qualifiedsourcename();
}
char[][] parameternames = findmethodparameternames(method,parametertypenames);

char[] completion = charoperation.no_char;

int previousstartposition = this.startposition;
int previoustokenstart = this.tokenstart;

if (!exactmatch) {
if (this.source != null
&& this.source.length > this.endposition
&& this.source[this.endposition] == '(') {
completion = method.selector;
} else {
completion = charoperation.concat(method.selector, new char[] { '(', ')' });
}
} else {
this.startposition = this.endposition;
this.tokenstart = this.tokenend;
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(methodname, method.selector);
relevance += computerelevanceforexpectingtype(method.returntype);
relevance += computerelevanceforenumconstant(method.returntype);
relevance += computerelevanceforstatic(true, method.isstatic());
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.method_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.method_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(method.declaringclass));
proposal.setsignature(getsignature(method));
methodbinding original = method.original();
if(original != method) {
proposal.setoriginalsignature(getsignature(original));
}
proposal.setdeclarationpackagename(method.declaringclass.qualifiedpackagename());
proposal.setdeclarationtypename(method.declaringclass.qualifiedsourcename());
proposal.setparameterpackagenames(parameterpackagenames);
proposal.setparametertypenames(parametertypenames);
proposal.setpackagename(method.returntype.qualifiedpackagename());
proposal.settypename(method.returntype.qualifiedsourcename());
proposal.setname(method.selector);
proposal.setcompletion(completion);
proposal.setflags(method.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
if(parameternames != null) proposal.setparameternames(parameternames);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
this.startposition = previousstartposition;
this.tokenstart = previoustokenstart;
}

methodsfound.addall(newmethodsfound);
}

private void findlocalmethodsfromstaticimports(
char[] token,
scope scope,
invocationsite invocationsite,
scope invocationscope,
boolean exactmatch,
objectvector methodsfound,
boolean proposemethod) {
findfieldsandmethodsfromstaticimports(
token,
scope,
invocationsite,
invocationscope,
exactmatch,
false,
new objectvector(),
new objectvector(),
methodsfound,
false,
proposemethod);
}
protected void findmembers(
char[] token,
referencebinding receivertype,
scope scope,
invocationsite invocationsite,
boolean isinsideannotationattribute,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems) {

if (!this.requestor.isignored(completionproposal.type_ref)) {
findmembertypes(
token,
receivertype,
scope,
scope.enclosingsourcetype(),
false,
true,
new objectvector(),
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems);
}
if (!this.requestor.isignored(completionproposal.field_ref)) {
findclassfield(
token,
receivertype,
scope,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems);
}

methodscope methodscope = null;
if (!isinsideannotationattribute &&
!this.requestor.isignored(completionproposal.keyword) &&
((scope instanceof methodscope && !((methodscope)scope).isstatic)
|| ((methodscope = scope.enclosingmethodscope()) != null && !methodscope.isstatic))) {
if (token.length > 0) {
findkeywords(token, new char[][]{keywords.this}, false, true);
} else {
int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(this.completiontoken, keywords.this);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for keywords
relevance += r_non_inherited;

this.noproposal = false;
if (!this.requestor.isignored(completionproposal.keyword)) {
internalcompletionproposal proposal =  createproposal(completionproposal.keyword, this.actualcompletionposition);
proposal.setname(keywords.this);
proposal.setcompletion(keywords.this);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if (debug) {
this.printdebug(proposal);
}
}
}
}

if (!this.requestor.isignored(completionproposal.field_ref)) {
findfields(
token,
receivertype,
scope,
new objectvector(),
new objectvector(),
true,
invocationsite,
scope,
false,
false,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
null,
-1,
-1);
}

if (!isinsideannotationattribute && !this.requestor.isignored(completionproposal.method_ref)) {
findmethods(
token,
null,
null,
receivertype,
scope,
new objectvector(),
true,
false,
invocationsite,
scope,
false,
false,
false,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
null,
-1,
-1);
}
}

private void findmembersfrommissingtype(
final char[] token,
final long pos,
typebinding resolvetype,
final scope scope,
final invocationsite invocationsite,
final boolean isinsideannotationattribute) {
missingtypesguesser missingtypesconverter = new missingtypesguesser(this);
missingtypesguesser.guessedtyperequestor substitutionrequestor =
new missingtypesguesser.guessedtyperequestor() {
public void accept(
typebinding guessedtype,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean hasproblems) {
if (guessedtype instanceof referencebinding) {
findmembers(
completionengine.this.completiontoken,
(referencebinding)guessedtype,
scope,
invocationsite,
isinsideannotationattribute,
missingelements,
missingelementsstarts,
missingelementsends,
hasproblems);
}
}
};
singletypereference typeref = new singletypereference(token, pos);
typeref.resolvedtype = new problemreferencebinding(new char[][]{ token }, null, problemreasons.notfound);
missingtypesconverter.guess(typeref, scope, substitutionrequestor);
}

private void findmembertypes(
char[] typename,
referencebinding receivertype,
scope scope,
sourcetypebinding typeinvocation,
boolean staticonly,
boolean staticfieldsandmethodonly,
boolean fromstaticimport,
boolean checkqualification,
boolean proposeallmembertypes,
sourcetypebinding typetoignore,
objectvector typesfound,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems) {

referencebinding currenttype = receivertype;
if (typename == null)
return;

if (this.insidequalifiedreference
|| typename.length == 0) { // do not search up the hierarchy

findmembertypes(
typename,
currenttype.membertypes(),
typesfound,
receivertype,
typeinvocation,
staticonly,
staticfieldsandmethodonly,
fromstaticimport,
checkqualification,
scope,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems);
return;
}

referencebinding[] interfacestovisit = null;
int nextposition = 0;

do {
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}

findmembertypes(
typename,
currenttype.membertypes(),
typesfound,
receivertype,
typeinvocation,
staticonly,
staticfieldsandmethodonly,
fromstaticimport,
checkqualification,
scope,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems);

currenttype = currenttype.superclass();
} while (currenttype != null);

if(proposeallmembertypes) {
referencebinding[] membertypes = receivertype.membertypes();
for (int i = 0; i < membertypes.length; i++) {
if(membertypes[i] != typetoignore) {
findsubmembertypes(
typename,
membertypes[i],
scope,
typeinvocation,
staticonly,
staticfieldsandmethodonly,
fromstaticimport,
typesfound);
}
}
}

if (interfacestovisit != null) {
for (int i = 0; i < nextposition; i++) {
referencebinding aninterface = interfacestovisit[i];
findmembertypes(
typename,
aninterface.membertypes(),
typesfound,
receivertype,
typeinvocation,
staticonly,
staticfieldsandmethodonly,
fromstaticimport,
checkqualification,
scope,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems);

referencebinding[] itsinterfaces = aninterface.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
}

protected void findmembertypes(
char[] typename,
referencebinding receivertype,
scope scope,
sourcetypebinding typeinvocation,
boolean staticonly,
boolean staticfieldsandmethodonly,
objectvector typesfound,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems)  {
findmembertypes(
typename,
receivertype,
scope,
typeinvocation,
staticonly,
staticfieldsandmethodonly,
false,
false,
false,
null,
typesfound,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems);
}
// helper method for findmembertypes(char[], referencebinding, scope)
private void findmembertypes(
char[] typename,
referencebinding[] membertypes,
objectvector typesfound,
referencebinding receivertype,
sourcetypebinding invocationtype,
boolean staticonly,
boolean staticfieldsandmethodonly,
boolean fromstaticimport,
boolean checkqualification,
scope scope,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems) {

// inherited member types which are hidden by subclasses are filtered out
// no visibility checks can be performed without the scope & invocationsite
int typelength = typename.length;
next : for (int m = membertypes.length; --m >= 0;) {
referencebinding membertype = membertypes[m];
//		if (!wantclasses && membertype.isclass()) continue next;
//		if (!wantinterfaces && membertype.isinterface()) continue next;

if (staticonly && !membertype.isstatic()) continue next;

if (isforbidden(membertype)) continue next;

if (typelength > membertype.sourcename.length)
continue next;

if (!charoperation.prefixequals(typename, membertype.sourcename, false/* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(typename, membertype.sourcename)))
continue next;

if (this.options.checkdeprecation &&
membertype.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(membertype))
continue next;

if (this.options.checkvisibility) {
if (invocationtype != null && !membertype.canbeseenby(receivertype, invocationtype)) {
continue next;
} else if(invocationtype == null && !membertype.canbeseenby(this.unitscope.fpackage)) {
continue next;
}
}

if (this.insidequalifiedreference &&
receivertype.isparameterizedtype() &&
membertype.isstatic()) {
continue next;
}

for (int i = typesfound.size; --i >= 0;) {
referencebinding othertype = (referencebinding) typesfound.elementat(i);

if (membertype == othertype)
continue next;

if (charoperation.equals(membertype.sourcename, othertype.sourcename, true)) {

if (membertype.enclosingtype().issuperclassof(othertype.enclosingtype()))
continue next;

if (othertype.enclosingtype().isinterface())
if (membertype.enclosingtype()
.implementsinterface(othertype.enclosingtype(), true))
continue next;

if (membertype.enclosingtype().isinterface())
if (othertype.enclosingtype()
.implementsinterface(membertype.enclosingtype(), true))
continue next;
}
}

typesfound.add(membertype);

if (this.assistnodeisextendedtype && membertype.isfinal()) continue next;
if(!this.insidequalifiedreference) {
if(this.assistnodeisclass) {
if(!membertype.isclass()) continue next;
} else if(this.assistnodeisinterface) {
if(!membertype.isinterface() && !membertype.isannotationtype()) continue next;
} else if (this.assistnodeisannotation) {
if(!membertype.isannotationtype()) continue next;
}
}

char[] completionname = membertype.sourcename();

boolean isqualified = false;
if(checkqualification && !fromstaticimport) {
char[] memberpackagename = membertype.qualifiedpackagename();
char[] membertypename = membertype.sourcename();
char[] memberenclosingtypenames = membertype.enclosingtype().qualifiedsourcename();
if (mustqualifytype(memberpackagename, membertypename, memberenclosingtypenames, membertype.modifiers)) {
if (memberpackagename == null || memberpackagename.length == 0)
if (this.unitscope != null && this.unitscope.fpackage.compoundname != charoperation.no_char_char)
break next; // ignore types from the default package from outside it
isqualified = true;
completionname =
charoperation.concat(
memberpackagename,
charoperation.concat(
memberenclosingtypenames,
membertypename,
'.'),
'.');
}
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(typename, membertype.sourcename);
relevance += computerelevanceforexpectingtype(membertype);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);
if(!this.insidequalifiedreference) {
relevance += computerelevanceforqualification(isqualified);
}
if (staticfieldsandmethodonly && this.insidequalifiedreference) relevance += r_non_inherited; // this criterion doesn't concern types and is added to be balanced with field and method relevance.

if (membertype.isannotationtype()) {
relevance += computerelevanceforannotation();
relevance += computerelevanceforannotationtarget(membertype);
} else if (membertype.isclass()) {
relevance += computerelevanceforclass();
relevance += computerelevanceforexception(membertype.sourcename);
} else if(membertype.isenum()) {
relevance += computerelevanceforenum();
} else if(membertype.isinterface()) {
relevance += computerelevanceforinterface();
}

if (missingelements != null) {
relevance += computerelevanceformissingelements(missingelementshaveproblems);
}

boolean allowinglongcomputationproposals = isallowinglongcomputationproposals();

this.noproposal = false;
if (!this.assistnodeisconstructor ||
!allowinglongcomputationproposals ||
hasstaticmembertypes(membertype, invocationtype, this.unitscope) ||
(membertype instanceof sourcetypebinding && hasmembertypesinenclosingscope((sourcetypebinding)membertype, scope)) ||
hasarraytypeasexpectedsupertypes()) {
createtypeproposal(
membertype,
membertype.qualifiedsourcename(),
iaccessrule.k_accessible,
completionname,
relevance,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems);
}

if (this.assistnodeisconstructor && allowinglongcomputationproposals) {
findconstructorsoranonymoustypes(
membertype,
scope,
fakeinvocationsite,
isqualified,
relevance);
}
}
}
private void findmembertypesfrommissingtype(
char[] typename,
final long pos,
final scope scope)  {
missingtypesguesser missingtypesconverter = new missingtypesguesser(this);
missingtypesguesser.guessedtyperequestor substitutionrequestor =
new missingtypesguesser.guessedtyperequestor() {
public void accept(
typebinding guessedtype,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean hasproblems) {
if (guessedtype instanceof referencebinding) {
findmembertypes(
completionengine.this.completiontoken,
(referencebinding)guessedtype,
scope,
scope.enclosingsourcetype(),
false,
false,
new objectvector(),
missingelements,
missingelementsstarts,
missingelementsends,
hasproblems);
}
}
};
singletypereference typeref = new singletypereference(typename, pos);
typeref.resolvedtype = new problemreferencebinding(new char[][]{ typename }, null, problemreasons.notfound);
missingtypesconverter.guess(typeref, scope, substitutionrequestor);
}

private void findmembertypesfrommissingtype(
typereference typeref,
final long pos,
final scope scope)  {
missingtypesguesser missingtypesconverter = new missingtypesguesser(this);
missingtypesguesser.guessedtyperequestor substitutionrequestor =
new missingtypesguesser.guessedtyperequestor() {
public void accept(
typebinding guessedtype,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean hasproblems) {
if (guessedtype instanceof referencebinding) {
findmembertypes(
completionengine.this.completiontoken,
(referencebinding)guessedtype,
scope,
scope.enclosingsourcetype(),
false,
false,
new objectvector(),
missingelements,
missingelementsstarts,
missingelementsends,
hasproblems);
}
}
};
missingtypesconverter.guess(typeref, scope, substitutionrequestor);
}

private void findmethoddeclarations(
char[] selector,
referencebinding receivertype,
scope scope,
objectvector methodsfound,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems) {

if (selector == null) {
return;
}

methodbinding[] receivertypemethods = receivertype.availablemethods();
if (receivertypemethods != null){
for (int i = 0; i < receivertypemethods.length; i++) {
if(!receivertypemethods[i].isdefaultabstract()) {
methodsfound.add(receivertypemethods[i]);
}
}
}

referencebinding currenttype = receivertype;

findinterfacesmethoddeclarations(
selector,
receivertype,
currenttype.superinterfaces(),
scope,
methodsfound,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems);

if (receivertype.isinterface()) {
currenttype = scope.getjavalangobject();
} else {
currenttype = receivertype.superclass();
}

boolean haspotentialdefaultabstractmethods = true;
while (currenttype != null) {

methodbinding[] methods = currenttype.availablemethods();
if (methods != null) {
findlocalmethoddeclarations(
selector,
methods,
scope,
methodsfound,
false,
receivertype);
}

if (haspotentialdefaultabstractmethods &&
(currenttype.isabstract() ||
currenttype.istypevariable() ||
currenttype.isintersectiontype() ||
currenttype.isenum())){

referencebinding[] superinterfaces = currenttype.superinterfaces();

findinterfacesmethoddeclarations(
selector,
receivertype,
superinterfaces,
scope,
methodsfound,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems);
} else {
haspotentialdefaultabstractmethods = false;
}
currenttype = currenttype.superclass();
}
}

private char[][] findmethodparameternames(methodbinding method, char[][] parametertypenames){
typebinding erasure =  method.declaringclass.erasure();
if(!(erasure instanceof referencebinding)) return null;

char[][] parameternames = null;

int length = parametertypenames.length;

if (length == 0){
return charoperation.no_char_char;
}
// look into the corresponding unit if it is available
if (erasure instanceof sourcetypebinding){
sourcetypebinding sourcetype = (sourcetypebinding) erasure;

if (sourcetype.scope != null){
typedeclaration parsedtype;

if ((parsedtype = sourcetype.scope.referencecontext) != null){
abstractmethoddeclaration methoddecl = parsedtype.declarationof(method.original());

if (methoddecl != null){
argument[] arguments = methoddecl.arguments;
parameternames = new char[length][];

for(int i = 0 ; i < length ; i++){
parameternames[i] = arguments[i].name;
}
}
}
}
}
// look into the model
if(parameternames == null){

referencebinding bindingtype = (referencebinding)erasure;

char[] compoundname = charoperation.concatwith(bindingtype.compoundname, '.');
object type = this.typecache.get(compoundname);

isourcetype sourcetype = null;
if(type != null) {
if(type instanceof isourcetype) {
sourcetype = (isourcetype) type;
}
} else {
nameenvironmentanswer answer = this.nameenvironment.findtype(bindingtype.compoundname);
if(answer != null && answer.issourcetype()) {
sourcetype = answer.getsourcetypes()[0];
this.typecache.put(compoundname, sourcetype);
}
}

if(sourcetype != null) {
itype typehandle = ((sourcetypeelementinfo) sourcetype).gethandle();

string[] parametertypesignatures = new string[length];
for (int i = 0; i < length; i++) {
parametertypesignatures[i] = signature.createtypesignature(parametertypenames[i], false);
}
imethod searchedmethod = typehandle.getmethod(string.valueof(method.selector), parametertypesignatures);
imethod[] foundmethods = typehandle.findmethods(searchedmethod);

if(foundmethods != null) {
int len = foundmethods.length;
if(len == 1) {
try {
sourcemethod sourcemethod = (sourcemethod) foundmethods[0];
parameternames = ((sourcemethodelementinfo) sourcemethod.getelementinfo()).getargumentnames();
} catch (javamodelexception e) {
// method doesn't exist: ignore
}
}
}
}
}
return parameternames;
}

private void findmethods(
char[] selector,
typebinding[] typeargtypes,
typebinding[] argtypes,
referencebinding receivertype,
scope scope,
objectvector methodsfound,
boolean onlystaticmethods,
boolean exactmatch,
invocationsite invocationsite,
scope invocationscope,
boolean implicitcall,
boolean supercall,
boolean canbeprefixed,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean missingelementshaveproblems,
char[] castedreceiver,
int receiverstart,
int receiverend) {

boolean notinjavadoc = this.assistnodeinjavadoc == 0;
if (selector == null && notinjavadoc) {
return;
}

referencebinding currenttype = receivertype;
if (notinjavadoc) {
if (receivertype.isinterface()) {
findinterfacesmethods(
selector,
typeargtypes,
argtypes,
receivertype,
new referencebinding[]{currenttype},
scope,
methodsfound,
onlystaticmethods,
exactmatch,
invocationsite,
invocationscope,
implicitcall,
supercall,
canbeprefixed,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
castedreceiver,
receiverstart,
receiverend);

currenttype = scope.getjavalangobject();
}
}
boolean haspotentialdefaultabstractmethods = true;
while (currenttype != null) {

methodbinding[] methods = currenttype.availablemethods();
if (methods != null) {
findlocalmethods(
selector,
typeargtypes,
argtypes,
methods,
scope,
methodsfound,
onlystaticmethods,
exactmatch,
receivertype,
invocationsite,
invocationscope,
implicitcall,
supercall,
canbeprefixed,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
castedreceiver,
receiverstart,
receiverend);
}

if (haspotentialdefaultabstractmethods &&
(currenttype.isabstract() ||
currenttype.istypevariable() ||
currenttype.isintersectiontype() ||
currenttype.isenum())){

referencebinding[] superinterfaces = currenttype.superinterfaces();
if (superinterfaces != null && currenttype.isintersectiontype()) {
for (int i = 0; i < superinterfaces.length; i++) {
superinterfaces[i] = (referencebinding)superinterfaces[i].capture(invocationscope, invocationsite.sourceend());
}
}

findinterfacesmethods(
selector,
typeargtypes,
argtypes,
receivertype,
superinterfaces,
scope,
methodsfound,
onlystaticmethods,
exactmatch,
invocationsite,
invocationscope,
implicitcall,
supercall,
canbeprefixed,
missingelements,
missingelementsstarts,
missingelementsends,
missingelementshaveproblems,
castedreceiver,
receiverstart,
receiverend);
} else {
haspotentialdefaultabstractmethods = false;
}
currenttype = currenttype.superclass();
}
}

private void findnestedtypes(
char[] typename,
sourcetypebinding currenttype,
scope scope,
boolean proposeallmembertypes,
objectvector typesfound) {

if (typename == null)
return;

int typelength = typename.length;

sourcetypebinding nexttypetoignore = null;
while (scope != null) { // done when a compilation_unit_scope is found

switch (scope.kind) {

case scope.method_scope :
case scope.block_scope :
blockscope blockscope = (blockscope) scope;

next : for (int i = 0, length = blockscope.subscopecount; i < length; i++) {

if (blockscope.subscopes[i] instanceof classscope) {
sourcetypebinding localtype =
((classscope) blockscope.subscopes[i]).referencecontext.binding;

if (!localtype.isanonymoustype()) {
if (isforbidden(localtype))
continue next;

if (typelength > localtype.sourcename.length)
continue next;
if (!charoperation.prefixequals(typename, localtype.sourcename, false/* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(typename, localtype.sourcename)))
continue next;

for (int j = typesfound.size; --j >= 0;) {
referencebinding othertype = (referencebinding) typesfound.elementat(j);

if (localtype == othertype)
continue next;
}

if (this.assistnodeisextendedtype && localtype.isfinal()) continue next;
if(this.assistnodeisclass) {
if(!localtype.isclass()) continue next;
} else if(this.assistnodeisinterface) {
if(!localtype.isinterface() && !localtype.isannotationtype()) continue next;
} else if (this.assistnodeisannotation) {
if(!localtype.isannotationtype()) continue next;
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(typename, localtype.sourcename);
relevance += computerelevanceforexpectingtype(localtype);
relevance += computerelevanceforexception(localtype.sourcename);
relevance += computerelevanceforclass();
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for nested type
relevance += computerelevanceforannotationtarget(localtype);

boolean allowinglongcomputationproposals = isallowinglongcomputationproposals();
if (!this.assistnodeisconstructor || !allowinglongcomputationproposals || hasarraytypeasexpectedsupertypes()) {
this.noproposal = false;
if(!this.requestor.isignored(completionproposal.type_ref)) {
createtypeproposal(
localtype,
localtype.sourcename,
iaccessrule.k_accessible,
localtype.sourcename,
relevance,
null,
null,
null,
false);
}
}

if (this.assistnodeisconstructor && allowinglongcomputationproposals) {
findconstructorsoranonymoustypes(
localtype,
blockscope,
fakeinvocationsite,
false,
relevance);
}
}
}
}
break;

case scope.class_scope :
sourcetypebinding enclosingsourcetype = scope.enclosingsourcetype();
findmembertypes(
typename,
enclosingsourcetype,
scope,
currenttype,
false,
false,
false,
false,
proposeallmembertypes,
nexttypetoignore,
typesfound,
null,
null,
null,
false);
nexttypetoignore = enclosingsourcetype;
if (typelength == 0)
return; // do not search outside the class scope if no prefix was provided
break;

case scope.compilation_unit_scope :
return;
}
scope = scope.parent;
}
}

private void findpackages(completiononpackagereference packagestatement) {

this.completiontoken = charoperation.concatwith(packagestatement.tokens, '.');
if (this.completiontoken.length == 0)
return;

setsourcerange(packagestatement.sourcestart, packagestatement.sourceend);
long completionposition = packagestatement.sourcepositions[packagestatement.sourcepositions.length - 1];
settokenrange((int) (completionposition >>> 32), (int) completionposition);
this.nameenvironment.findpackages(charoperation.tolowercase(this.completiontoken), this);
}

private void findparameterizedtype(typereference ref, scope scope) {
referencebinding refbinding = (referencebinding) ref.resolvedtype;
if(refbinding != null) {
if (this.options.checkdeprecation &&
refbinding.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(refbinding))
return;

int accessibility = iaccessrule.k_accessible;
if(refbinding.hasrestrictedaccess()) {
accessrestriction accessrestriction = this.lookupenvironment.getaccessrestriction(refbinding);
if(accessrestriction != null) {
switch (accessrestriction.getproblemid()) {
case iproblem.forbiddenreference:
if (this.options.checkforbiddenreference) {
return;
}
accessibility = iaccessrule.k_non_accessible;
break;
case iproblem.discouragedreference:
if (this.options.checkdiscouragedreference) {
return;
}
accessibility = iaccessrule.k_discouraged;
break;
}
}
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(refbinding.sourcename, refbinding.sourcename);
relevance += computerelevanceforexpectingtype(refbinding);
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforrestrictions(accessibility); // no access restriction for type in the current unit

if(!this.requestor.isignored(completionproposal.type_ref)) {
createtypeproposal(
refbinding,
refbinding.qualifiedsourcename(),
iaccessrule.k_accessible,
charoperation.no_char,
relevance,
null,
null,
null,
false);
}
}
}

private void findsubmembertypes(
char[] typename,
referencebinding receivertype,
scope scope,
sourcetypebinding typeinvocation,
boolean staticonly,
boolean staticfieldsandmethodonly,
boolean fromstaticimport,
objectvector typesfound) {

referencebinding currenttype = receivertype;
if (typename == null)
return;

if (this.assistnodeissupertype && !this.insidequalifiedreference && isforbidden(currenttype)) return; // we're trying to find a supertype

findmembertypes(
typename,
currenttype.membertypes(),
typesfound,
receivertype,
typeinvocation,
staticonly,
staticfieldsandmethodonly,
fromstaticimport,
true,
scope,
null,
null,
null,
false);

referencebinding[] membertypes = receivertype.membertypes();
next : for (int i = 0; i < membertypes.length; i++) {
if (this.options.checkvisibility) {
if (typeinvocation != null && !membertypes[i].canbeseenby(receivertype, typeinvocation)) {
continue next;
} else if(typeinvocation == null && !membertypes[i].canbeseenby(this.unitscope.fpackage)) {
continue next;
}
}
findsubmembertypes(
typename,
membertypes[i],
scope,
typeinvocation,
staticonly,
staticfieldsandmethodonly,
fromstaticimport,
typesfound);
}
}

private void findtrueorfalsekeywords(char[][] choices) {
if(choices == null || choices.length == 0) return;

if(this.expectedtypesptr != 0 || this.expectedtypes[0] != typebinding.boolean) return;

for (int i = 0; i < choices.length; i++) {
if (charoperation.equals(choices[i], keywords.true) ||
charoperation.equals(choices[i], keywords.false)
){
int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(charoperation.no_char, choices[i]);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for keywors
relevance += computerelevanceforexpectingtype(typebinding.boolean);
relevance += computerelevanceforqualification(false);
relevance += r_true_or_false;

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.keyword)) {
internalcompletionproposal proposal =  createproposal(completionproposal.keyword, this.actualcompletionposition);
proposal.setname(choices[i]);
proposal.setcompletion(choices[i]);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}
}

private void findtypeparameters(char[] token, scope scope) {
if (this.compileroptions.sourcelevel < classfileconstants.jdk1_5) return;

typeparameter[] typeparameters = null;
while (scope != null) { // done when a compilation_unit_scope is found
typeparameters = null;
switch (scope.kind) {
case scope.method_scope :
methodscope methodscope = (methodscope) scope;
if(methodscope.referencecontext instanceof methoddeclaration) {
methoddeclaration methoddeclaration = (methoddeclaration) methodscope.referencecontext;
typeparameters = methoddeclaration.typeparameters;
} else if(methodscope.referencecontext instanceof constructordeclaration) {
constructordeclaration methoddeclaration = (constructordeclaration) methodscope.referencecontext;
typeparameters = methoddeclaration.typeparameters;
}
break;
case scope.class_scope :
classscope classscope = (classscope) scope;
typeparameters = classscope.referencecontext.typeparameters;
break;
case scope.compilation_unit_scope :
return;
}
if(typeparameters != null) {
for (int i = 0; i < typeparameters.length; i++) {
int typelength = token.length;
typeparameter typeparameter = typeparameters[i];

if(typeparameter.binding == null) continue;

if (typelength > typeparameter.name.length) continue;

if (!charoperation.prefixequals(token, typeparameter.name, false)
&& !(this.options.camelcasematch && charoperation.camelcasematch(token, typeparameter.name))) continue;

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(token, typeparameter.name);
relevance += computerelevanceforexpectingtype(typeparameter.type == null ? null :typeparameter.type.resolvedtype);
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforexception(typeparameter.name);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction fot type parameter

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.type_ref)) {
createtypeparameterproposal(typeparameter, relevance);
}
}
}
scope = scope.parent;
}
}

private void findtypesandpackages(char[] token, scope scope, boolean proposebasetypes, boolean proposevoidtype, objectvector typesfound) {

if (token == null)
return;

boolean allowinglongcomputationproposals = isallowinglongcomputationproposals();

boolean proposetype =
!this.requestor.isignored(completionproposal.type_ref) ||
((this.assistnodeinjavadoc & completiononjavadoc.text) != 0 && !this.requestor.isignored(completionproposal.javadoc_type_ref));

boolean proposeallmembertypes = !this.assistnodeisconstructor;

boolean proposeconstructor =
allowinglongcomputationproposals &&
this.assistnodeisconstructor &&
(!isignored(completionproposal.constructor_invocation, completionproposal.type_ref) ||
!isignored(completionproposal.anonymous_class_constructor_invocation, completionproposal.type_ref));


if ((proposetype || proposeconstructor) && scope.enclosingsourcetype() != null) {

checkcancel();

findnestedtypes(token, scope.enclosingsourcetype(), scope, proposeallmembertypes, typesfound);
if(!this.assistnodeisinterface &&
!this.assistnodeisconstructor &&
!this.assistnodeisannotation &&
this.assistnodeinjavadoc == 0) {

checkcancel();

// don't propose type parameters if the completion is a constructor ('new |')
findtypeparameters(token, scope);
}
}

boolean isemptyprefix = token.length == 0;

if ((proposetype || proposeconstructor) && this.unitscope != null) {

referencebinding outerinvocationtype = scope.enclosingsourcetype();
if(outerinvocationtype != null) {
referencebinding temp = outerinvocationtype.enclosingtype();
while(temp != null) {
outerinvocationtype = temp;
temp = temp.enclosingtype();
}
}

int typelength = token.length;
sourcetypebinding[] types = this.unitscope.topleveltypes;

next : for (int i = 0, length = types.length; i < length; i++) {

checkcancel();

sourcetypebinding sourcetype = types[i];

if(isforbidden(sourcetype)) continue next;

if(proposeallmembertypes &&
sourcetype != outerinvocationtype) {
findsubmembertypes(
token,
sourcetype,
scope,
scope.enclosingsourcetype(),
false,
false,
false,
typesfound);
}

if (sourcetype.sourcename == completionparser.fake_type_name) continue next;
if (sourcetype.sourcename == typeconstants.package_info_name) continue next;

if (typelength > sourcetype.sourcename.length) continue next;

if (!charoperation.prefixequals(token, sourcetype.sourcename, false)
&& !(this.options.camelcasematch && charoperation.camelcasematch(token, sourcetype.sourcename))) continue next;

if (this.assistnodeisannotation && !haspossibleannotationtarget(sourcetype, scope)) {
continue next;
}

for (int j = typesfound.size; --j >= 0;) {
referencebinding othertype = (referencebinding) typesfound.elementat(j);

if (sourcetype == othertype) continue next;
}

typesfound.add(sourcetype);

if (this.assistnodeisextendedtype && sourcetype.isfinal()) continue next;
if(this.assistnodeisclass) {
if(!sourcetype.isclass()) continue next;
} else if(this.assistnodeisinterface) {
if(!sourcetype.isinterface() && !sourcetype.isannotationtype()) continue next;
} else if (this.assistnodeisannotation) {
if(!sourcetype.isannotationtype()) continue next;
} else if (isemptyprefix && this.assistnodeisexception) {
if (sourcetype.findsupertypeoriginatingfrom(typeids.t_javalangthrowable, true) == null) {
continue next;
}
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(token, sourcetype.sourcename);
relevance += computerelevanceforexpectingtype(sourcetype);
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for type in the current unit

if (sourcetype.isannotationtype()) {
relevance += computerelevanceforannotation();
relevance += computerelevanceforannotationtarget(sourcetype);
} else if (sourcetype.isinterface()) {
relevance += computerelevanceforinterface();
} else if(sourcetype.isclass()){
relevance += computerelevanceforclass();
relevance += computerelevanceforexception(sourcetype.sourcename);
}


this.noproposal = false;
if(proposetype &&
(!this.assistnodeisconstructor ||
!allowinglongcomputationproposals ||
hasstaticmembertypes(sourcetype, null, this.unitscope) ||
hasmembertypesinenclosingscope(sourcetype, scope)) ||
hasarraytypeasexpectedsupertypes()) {
char[] typename = sourcetype.sourcename();
createtypeproposal(
sourcetype,
typename,
iaccessrule.k_accessible,
typename,
relevance,
null,
null,
null,
false);
}

if (proposeconstructor) {
findconstructorsoranonymoustypes(
sourcetype,
scope,
fakeinvocationsite,
false,
relevance);
}
}
}

if (proposeconstructor && !isemptyprefix) {

checkcancel();

findtypesfromimports(token, scope, proposetype, typesfound);
} else if(proposetype) {

checkcancel();

findtypesfromstaticimports(token, scope, proposeallmembertypes, typesfound);
}

if (proposeconstructor) {

checkcancel();

findtypesfromexpectedtypes(token, scope, typesfound, proposetype, proposeconstructor);
}

if (isemptyprefix && !this.assistnodeisannotation) {
if (!proposeconstructor) {
findtypesfromexpectedtypes(token, scope, typesfound, proposetype, proposeconstructor);
}
} else {
if(!isemptyprefix && !this.requestor.isignored(completionproposal.keyword)) {
if (this.assistnodeinjavadoc == 0 || (this.assistnodeinjavadoc & completiononjavadoc.base_types) != 0) {
if (proposebasetypes) {
if (proposevoidtype) {
findkeywords(token, base_type_names, false, false);
} else {
findkeywords(token, base_type_names_without_void, false, false);
}
}
}
}

if (proposeconstructor) {
int l = typesfound.size();
for (int i = 0; i < l; i++) {
referencebinding typefound = (referencebinding) typesfound.elementat(i);
char[] fullyqualifiedtypename =
charoperation.concat(
typefound.qualifiedpackagename(),
typefound.qualifiedsourcename(),
'.');
this.knowntypes.put(fullyqualifiedtypename, known_type_with_known_constructors);
}

checkcancel();

this.foundconstructorscount = 0;
this.nameenvironment.findconstructordeclarations(
token,
this.options.camelcasematch,
this,
this.monitor);
acceptconstructors(scope);
} else if (proposetype) {
int l = typesfound.size();
for (int i = 0; i < l; i++) {
referencebinding typefound = (referencebinding) typesfound.elementat(i);
char[] fullyqualifiedtypename =
charoperation.concat(
typefound.qualifiedpackagename(),
typefound.qualifiedsourcename(),
'.');
this.knowntypes.put(fullyqualifiedtypename, known_type_with_known_constructors);
}
int searchfor = ijavasearchconstants.type;
if(this.assistnodeisclass) {
searchfor = ijavasearchconstants.class;
} else if(this.assistnodeisinterface) {
searchfor = ijavasearchconstants.interface_and_annotation;
} else if(this.assistnodeisenum) {
searchfor = ijavasearchconstants.enum;
} else if(this.assistnodeisannotation) {
searchfor = ijavasearchconstants.annotation_type;
}

checkcancel();

this.foundtypescount = 0;
this.nameenvironment.findtypes(
token,
proposeallmembertypes,
this.options.camelcasematch,
searchfor,
this,
this.monitor);
accepttypes(scope);
}
if(!isemptyprefix && !this.requestor.isignored(completionproposal.package_ref)) {

checkcancel();

this.nameenvironment.findpackages(token, this);
}
}
}

private void findtypesandsubpackages(
char[] token,
packagebinding packagebinding,
scope scope) {

boolean allowinglongcomputationproposals = isallowinglongcomputationproposals();

boolean proposetype =
!this.requestor.isignored(completionproposal.type_ref) ||
((this.assistnodeinjavadoc & completiononjavadoc.text) != 0 && !this.requestor.isignored(completionproposal.javadoc_type_ref));

boolean proposeconstructor =
allowinglongcomputationproposals &&
this.assistnodeisconstructor &&
(!isignored(completionproposal.constructor_invocation, completionproposal.type_ref) ||
!isignored(completionproposal.anonymous_class_constructor_invocation, completionproposal.type_ref));

char[] qualifiedname =
charoperation.concatwith(packagebinding.compoundname, token, '.');

if (token == null || token.length == 0) {
int length = qualifiedname.length;
system.arraycopy(
qualifiedname,
0,
qualifiedname = new char[length + 1],
0,
length);
qualifiedname[length] = '.';
}

this.qualifiedcompletiontoken = qualifiedname;

if ((proposetype || proposeconstructor) && this.unitscope != null) {
int typelength = qualifiedname.length;
sourcetypebinding[] types = this.unitscope.topleveltypes;

for (int i = 0, length = types.length; i < length; i++) {

checkcancel();

sourcetypebinding sourcetype = types[i];

if (isforbidden(sourcetype)) continue;
if (this.assistnodeisclass && sourcetype.isinterface()) continue;
if (this.assistnodeisinterface && sourcetype.isclass()) continue;

char[] qualifiedsourcetypename = charoperation.concatwith(sourcetype.compoundname, '.');

if (sourcetype.sourcename == completionparser.fake_type_name) continue;
if (sourcetype.sourcename == typeconstants.package_info_name) continue;
if (typelength > qualifiedsourcetypename.length) continue;
if (!(packagebinding == sourcetype.getpackage())) continue;

if (!charoperation.prefixequals(qualifiedname, qualifiedsourcetypename, false)
&& !(this.options.camelcasematch && charoperation.camelcasematch(token, sourcetype.sourcename)))	continue;

if (this.options.checkdeprecation &&
sourcetype.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(sourcetype))
continue;

if (this.assistnodeisextendedtype && sourcetype.isfinal()) continue;
int accessibility = iaccessrule.k_accessible;
if(sourcetype.hasrestrictedaccess()) {
accessrestriction accessrestriction = this.lookupenvironment.getaccessrestriction(sourcetype);
if(accessrestriction != null) {
switch (accessrestriction.getproblemid()) {
case iproblem.forbiddenreference:
if (this.options.checkforbiddenreference) {
continue;
}
accessibility = iaccessrule.k_non_accessible;
break;
case iproblem.discouragedreference:
if (this.options.checkdiscouragedreference) {
continue;
}
accessibility = iaccessrule.k_discouraged;
break;
}
}
}

this.knowntypes.put(charoperation.concat(sourcetype.qualifiedpackagename(), sourcetype.sourcename(), '.'), known_type_with_known_constructors);

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(qualifiedname, qualifiedsourcetypename);
relevance += computerelevanceforexpectingtype(sourcetype);
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforrestrictions(accessibility);

if (sourcetype.isannotationtype()) {
relevance += computerelevanceforannotation();
} else if (sourcetype.isinterface()) {
relevance += computerelevanceforinterface();
} else if (sourcetype.isclass()) {
relevance += computerelevanceforclass();
relevance += computerelevanceforexception(sourcetype.sourcename);
}

this.noproposal = false;
if(proposetype &&
(!this.assistnodeisconstructor ||
!allowinglongcomputationproposals ||
hasstaticmembertypes(sourcetype, null, this.unitscope) ||
hasmembertypesinenclosingscope(sourcetype, scope)) ||
hasarraytypeasexpectedsupertypes()) {
char[] typename = sourcetype.sourcename();
createtypeproposal(
sourcetype,
typename,
iaccessrule.k_accessible,
typename,
relevance,
null,
null,
null,
false);
}

if (proposeconstructor) {
findconstructorsoranonymoustypes(
sourcetype,
scope,
fakeinvocationsite,
false,
relevance);
}
}
}

if (proposeconstructor) {


checkcancel();

this.foundconstructorscount = 0;
this.nameenvironment.findconstructordeclarations(
qualifiedname,
this.options.camelcasematch,
this,
this.monitor);
acceptconstructors(scope);
} if(proposetype) {
int searchfor = ijavasearchconstants.type;
if(this.assistnodeisclass) {
searchfor = ijavasearchconstants.class;
} else if(this.assistnodeisinterface) {
searchfor = ijavasearchconstants.interface_and_annotation;
} else if(this.assistnodeisenum) {
searchfor = ijavasearchconstants.enum;
} else if(this.assistnodeisannotation) {
searchfor = ijavasearchconstants.annotation_type;
}

checkcancel();

this.foundtypescount = 0;
this.nameenvironment.findtypes(
qualifiedname,
false,
this.options.camelcasematch,
searchfor,
this,
this.monitor);
accepttypes(scope);
}

if(!this.requestor.isignored(completionproposal.package_ref)) {
this.nameenvironment.findpackages(qualifiedname, this);
}
}

private void findtypesfromexpectedtypes(char[] token, scope scope, objectvector typesfound, boolean proposetype, boolean proposeconstructor) {
if(this.expectedtypesptr > -1) {
boolean allowinglongcomputationproposals = isallowinglongcomputationproposals();

int typelength = token == null ? 0 : token.length;

next : for (int i = 0; i <= this.expectedtypesptr; i++) {

checkcancel();

if(this.expectedtypes[i] instanceof referencebinding) {
referencebinding refbinding = (referencebinding)this.expectedtypes[i];

if (typelength > 0) {
if (typelength > refbinding.sourcename.length) continue next;

if (!charoperation.prefixequals(token, refbinding.sourcename, false)
&& !(this.options.camelcasematch && charoperation.camelcasematch(token, refbinding.sourcename))) continue next;
}


if(refbinding.istypevariable() && this.assistnodeisconstructor) {
// don't propose type variable if the completion is a constructor ('new |')
continue next;
}
if (this.options.checkdeprecation &&
refbinding.isviewedasdeprecated() &&
!scope.isdefinedinsameunit(refbinding))
continue next;

int accessibility = iaccessrule.k_accessible;
if(refbinding.hasrestrictedaccess()) {
accessrestriction accessrestriction = this.lookupenvironment.getaccessrestriction(refbinding);
if(accessrestriction != null) {
switch (accessrestriction.getproblemid()) {
case iproblem.forbiddenreference:
if (this.options.checkforbiddenreference) {
continue next;
}
accessibility = iaccessrule.k_non_accessible;
break;
case iproblem.discouragedreference:
if (this.options.checkdiscouragedreference) {
continue next;
}
accessibility = iaccessrule.k_discouraged;
break;
}
}
}

for (int j = 0; j < typesfound.size(); j++) {
referencebinding typefound = (referencebinding)typesfound.elementat(j);
if (typefound == refbinding.erasure()) {
continue next;
}
}

typesfound.add(refbinding);

boolean insameunit = this.unitscope.isdefinedinsameunit(refbinding);

// top level types of the current unit are already proposed.
if(!insameunit || (insameunit && refbinding.ismembertype())) {
char[] packagename = refbinding.qualifiedpackagename();
char[] typename = refbinding.sourcename();
char[] completionname = typename;

boolean isqualified = false;
if (!this.insidequalifiedreference && !refbinding.ismembertype()) {
if (mustqualifytype(packagename, typename, null, refbinding.modifiers)) {
if (packagename == null || packagename.length == 0)
if (this.unitscope != null && this.unitscope.fpackage.compoundname != charoperation.no_char_char)
continue next; // ignore types from the default package from outside it
completionname = charoperation.concat(packagename, typename, '.');
isqualified = true;
}
}

if (this.assistnodeisextendedtype && refbinding.isfinal()) continue next;
if(this.assistnodeisclass) {
if(!refbinding.isclass()) continue next;
} else if(this.assistnodeisinterface) {
if(!refbinding.isinterface() && !refbinding.isannotationtype()) continue next;
} else if (this.assistnodeisannotation) {
if(!refbinding.isannotationtype()) continue next;
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(token, typename);
relevance += computerelevanceforexpectingtype(refbinding);
relevance += computerelevanceforqualification(isqualified);
relevance += computerelevanceforrestrictions(accessibility);

if(refbinding.isclass()) {
relevance += computerelevanceforclass();
relevance += computerelevanceforexception(typename);
} else if(refbinding.isenum()) {
relevance += computerelevanceforenum();
} else if(refbinding.isinterface()) {
relevance += computerelevanceforinterface();
}

if (proposetype &&
(!this.assistnodeisconstructor ||
!allowinglongcomputationproposals ||
hasstaticmembertypes(refbinding, scope.enclosingsourcetype() ,this.unitscope)) ||
hasarraytypeasexpectedsupertypes()) {
this.noproposal = false;
if(!this.requestor.isignored(completionproposal.type_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.type_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(packagename);
proposal.setsignature(getsignature(refbinding));
proposal.setpackagename(packagename);
proposal.settypename(typename);
proposal.setcompletion(completionname);
proposal.setflags(refbinding.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
proposal.setaccessibility(accessibility);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}

if (proposeconstructor) {
findconstructorsoranonymoustypes(
refbinding,
scope,
fakeinvocationsite,
isqualified,
relevance);
}
}
}
}
}
}

private void findtypesfromimports(char[] token, scope scope, boolean proposetype, objectvector typesfound) {
importbinding[] importbindings = scope.compilationunitscope().imports;
next : for (int i = 0; i < importbindings.length; i++) {
importbinding importbinding = importbindings[i];
if(importbinding.isvalidbinding()) {
binding binding = importbinding.resolvedimport;
if(binding != null && binding.isvalidbinding()) {
if(importbinding.ondemand) {
if (importbinding.isstatic()) {
if((binding.kind() & binding.type) != 0) {
this.findmembertypes(
token,
(referencebinding) binding,
scope,
scope.enclosingsourcetype(),
true,
false,
true,
true,
false,
null,
typesfound,
null,
null,
null,
false);
}
}
} else {
if ((binding.kind() & binding.type) != 0) {
referencebinding typebinding = (referencebinding) binding;
int typelength = token.length;

if (!typebinding.isstatic()) continue next;

if (typelength > typebinding.sourcename.length)	continue next;

if (!charoperation.prefixequals(token, typebinding.sourcename, false)
&& !(this.options.camelcasematch && charoperation.camelcasematch(token, typebinding.sourcename))) continue next;

int accessibility = iaccessrule.k_accessible;
if(typebinding.hasrestrictedaccess()) {
accessrestriction accessrestriction = this.lookupenvironment.getaccessrestriction(typebinding);
if(accessrestriction != null) {
switch (accessrestriction.getproblemid()) {
case iproblem.forbiddenreference:
if (this.options.checkforbiddenreference) {
continue next;
}
accessibility = iaccessrule.k_non_accessible;
break;
case iproblem.discouragedreference:
if (this.options.checkdiscouragedreference) {
continue next;
}
accessibility = iaccessrule.k_discouraged;
break;
}
}
}

if (typesfound.contains(typebinding)) continue next;

typesfound.add(typebinding);

if (this.assistnodeisextendedtype && typebinding.isfinal()) continue;
if(this.assistnodeisclass) {
if(!typebinding.isclass()) continue;
} else if(this.assistnodeisinterface) {
if(!typebinding.isinterface() && !typebinding.isannotationtype()) continue;
} else if (this.assistnodeisannotation) {
if(!typebinding.isannotationtype()) continue;
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(token, typebinding.sourcename);
relevance += computerelevanceforexpectingtype(typebinding);
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforrestrictions(accessibility);

if (typebinding.isannotationtype()) {
relevance += computerelevanceforannotation();
relevance += computerelevanceforannotationtarget(typebinding);
} else if (typebinding.isinterface()) {
relevance += computerelevanceforinterface();
} else if(typebinding.isclass()){
relevance += computerelevanceforclass();
relevance += computerelevanceforexception(typebinding.sourcename);
}

if (proposetype &&
(hasstaticmembertypes(typebinding, scope.enclosingsourcetype(), this.unitscope) || hasarraytypeasexpectedsupertypes())) {
this.noproposal = false;
if(!this.requestor.isignored(completionproposal.type_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.type_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(typebinding.qualifiedpackagename());
proposal.setsignature(getsignature(typebinding));
proposal.setpackagename(typebinding.qualifiedpackagename());
proposal.settypename(typebinding.qualifiedsourcename());
proposal.setcompletion(typebinding.sourcename());
proposal.setflags(typebinding.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}

findconstructorsoranonymoustypes(
typebinding,
scope,
fakeinvocationsite,
false,
relevance);
}
}
}
}
}
}

private void findtypesfromstaticimports(char[] token, scope scope, boolean proposeallmembertypes, objectvector typesfound) {
importbinding[] importbindings = scope.compilationunitscope().imports;
for (int i = 0; i < importbindings.length; i++) {
importbinding importbinding = importbindings[i];
if(importbinding.isvalidbinding() && importbinding.isstatic()) {
binding binding = importbinding.resolvedimport;
if(binding != null && binding.isvalidbinding()) {
if(importbinding.ondemand) {
if((binding.kind() & binding.type) != 0) {
this.findmembertypes(
token,
(referencebinding) binding,
scope,
scope.enclosingsourcetype(),
true,
false,
true,
true,
proposeallmembertypes,
null,
typesfound,
null,
null,
null,
false);
}
} else {
if ((binding.kind() & binding.type) != 0) {
referencebinding typebinding = (referencebinding) binding;
int typelength = token.length;

if (!typebinding.isstatic()) continue;

if (typelength > typebinding.sourcename.length)	continue;

if (!charoperation.prefixequals(token, typebinding.sourcename, false)
&& !(this.options.camelcasematch && charoperation.camelcasematch(token, typebinding.sourcename)))	continue;

if (typesfound.contains(typebinding))  continue;

typesfound.add(typebinding);

if (this.assistnodeisextendedtype && typebinding.isfinal()) continue;
if(this.assistnodeisclass) {
if(!typebinding.isclass()) continue;
} else if(this.assistnodeisinterface) {
if(!typebinding.isinterface() && !typebinding.isannotationtype()) continue;
} else if (this.assistnodeisannotation) {
if(!typebinding.isannotationtype()) continue;
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(token, typebinding.sourcename);
relevance += computerelevanceforexpectingtype(typebinding);
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible);

if (typebinding.isclass()) {
relevance += computerelevanceforclass();
relevance += computerelevanceforexception(typebinding.sourcename);
} else if(typebinding.isenum()) {
relevance += computerelevanceforenum();
} else if(typebinding.isinterface()) {
relevance += computerelevanceforinterface();
}

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.type_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.type_ref, this.actualcompletionposition);
proposal.setdeclarationsignature(typebinding.qualifiedpackagename());
proposal.setsignature(getsignature(typebinding));
proposal.setpackagename(typebinding.qualifiedpackagename());
proposal.settypename(typebinding.qualifiedsourcename());
proposal.setcompletion(typebinding.sourcename());
proposal.setflags(typebinding.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
}
}
}
}
}

private void findunresolvedreference(int completednamestart, int completednameend, blockscope scope, char[][] discouragednames) {
char[][] foundnames = findunresolvedreferencebefore(completednamestart - 1, completednameend, scope, discouragednames);
if (foundnames != null && foundnames.length > 1) {
int discouragednameslength = discouragednames.length;
int foundnameslength = foundnames.length;
int newlength = discouragednameslength + foundnameslength;
system.arraycopy(discouragednames, 0, discouragednames = new char[newlength][], 0, discouragednameslength);
system.arraycopy(foundnames, 0, discouragednames, discouragednameslength, foundnameslength);
}
findunresolvedreferenceafter(completednameend + 1, scope, discouragednames);
}

private char[][] findunresolvedreferenceafter(int from, blockscope scope, final char[][] discouragednames) {
final arraylist proposednames = new arraylist();

unresolvedreferencenamefinder.unresolvedreferencenamerequestor namerequestor =
new unresolvedreferencenamefinder.unresolvedreferencenamerequestor() {
public void acceptname(char[] name) {
completionengine.this.acceptunresolvedname(name);
proposednames.add(name);
}
};

referencecontext referencecontext = scope.referencecontext();
if (referencecontext instanceof abstractmethoddeclaration) {
abstractmethoddeclaration md = (abstractmethoddeclaration)referencecontext;

unresolvedreferencenamefinder namefinder = new unresolvedreferencenamefinder(this);
namefinder.findafter(
this.completiontoken,
md.scope,
md.scope.classscope(),
from,
md.bodyend,
discouragednames,
namerequestor);
} else if (referencecontext instanceof typedeclaration) {
typedeclaration typedeclaration = (typedeclaration) referencecontext;
fielddeclaration[] fields = typedeclaration.fields;
if (fields != null) {
done : for (int i = 0; i < fields.length; i++) {
if (fields[i] instanceof initializer) {
initializer initializer = (initializer) fields[i];
if (initializer.block.sourcestart <= from &&
from < initializer.bodyend) {
unresolvedreferencenamefinder namefinder = new unresolvedreferencenamefinder(this);
namefinder.findafter(
this.completiontoken,
typedeclaration.scope,
typedeclaration.scope,
from,
initializer.bodyend,
discouragednames,
namerequestor);
break done;
}
}
}
}
}

int proposednamescount = proposednames.size();
if (proposednamescount > 0) {
return (char[][])proposednames.toarray(new char[proposednamescount][]);
}

return null;
}

private char[][] findunresolvedreferencebefore(int recordto, int parseto, blockscope scope, final char[][] discouragednames) {
final arraylist proposednames = new arraylist();

unresolvedreferencenamefinder.unresolvedreferencenamerequestor namerequestor =
new unresolvedreferencenamefinder.unresolvedreferencenamerequestor() {
public void acceptname(char[] name) {
completionengine.this.acceptunresolvedname(name);
proposednames.add(name);
}
};

blockscope upperscope = scope;
while (upperscope.enclosingmethodscope() != null) {
upperscope = upperscope.enclosingmethodscope();
}

referencecontext referencecontext = upperscope.referencecontext();
if (referencecontext instanceof abstractmethoddeclaration) {
abstractmethoddeclaration md = (abstractmethoddeclaration)referencecontext;

unresolvedreferencenamefinder namefinder = new unresolvedreferencenamefinder(this);
namefinder.findbefore(
this.completiontoken,
md.scope,
md.scope.classscope(),
md.bodystart,
recordto,
parseto,
discouragednames,
namerequestor);
} else if (referencecontext instanceof typedeclaration) {
typedeclaration typedeclaration = (typedeclaration) referencecontext;


done : {
fielddeclaration[] fields = typedeclaration.fields;
if (fields != null) {
for (int i = 0; i < fields.length; i++) {
if (fields[i] instanceof initializer) {
initializer initializer = (initializer) fields[i];
if (initializer.block.sourcestart <= recordto &&
recordto < initializer.bodyend) {

unresolvedreferencenamefinder namefinder = new unresolvedreferencenamefinder(this);
namefinder.findbefore(
this.completiontoken,
typedeclaration.scope,
typedeclaration.scope,
initializer.block.sourcestart,
recordto,
parseto,
discouragednames,
namerequestor);
break done;
}
}
}
}
}
}

int proposednamescount = proposednames.size();
if (proposednamescount > 0) {
return (char[][])proposednames.toarray(new char[proposednamescount][]);
}

return null;
}

private char[][] findvariablefromunresolvedreference(localdeclaration variable, blockscope scope, final char[][] discouragednames) {
final typereference type = variable.type;
if(type != null &&
type.resolvedtype != null &&
type.resolvedtype.problemid() == problemreasons.noerror){

final arraylist proposednames = new arraylist();

unresolvedreferencenamefinder.unresolvedreferencenamerequestor namerequestor =
new unresolvedreferencenamefinder.unresolvedreferencenamerequestor() {
public void acceptname(char[] name) {
int relevance = computebaserelevance();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(completionengine.this.completiontoken, name);
relevance += r_name_first_prefix;
relevance += r_name_first_suffix;
relevance += r_name_less_new_characters;
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for variable name

// accept result
completionengine.this.noproposal = false;
if(!completionengine.this.requestor.isignored(completionproposal.variable_declaration)) {
internalcompletionproposal proposal =  completionengine.this.createproposal(completionproposal.variable_declaration, completionengine.this.actualcompletionposition);
proposal.setsignature(getsignature(type.resolvedtype));
proposal.setpackagename(type.resolvedtype.qualifiedpackagename());
proposal.settypename(type.resolvedtype.qualifiedsourcename());
proposal.setname(name);
proposal.setcompletion(name);
//proposal.setflags(flags.accdefault);
proposal.setreplacerange(completionengine.this.startposition - completionengine.this.offset, completionengine.this.endposition - completionengine.this.offset);
proposal.settokenrange(completionengine.this.tokenstart - completionengine.this.offset, completionengine.this.tokenend - completionengine.this.offset);
proposal.setrelevance(relevance);
completionengine.this.requestor.accept(proposal);
if(debug) {
completionengine.this.printdebug(proposal);
}
}
proposednames.add(name);
}
};

referencecontext referencecontext = scope.referencecontext();
if (referencecontext instanceof abstractmethoddeclaration) {
abstractmethoddeclaration md = (abstractmethoddeclaration)referencecontext;

unresolvedreferencenamefinder namefinder = new unresolvedreferencenamefinder(this);
namefinder.find(
this.completiontoken,
md,
variable.declarationsourceend + 1,
discouragednames,
namerequestor);
} else if (referencecontext instanceof typedeclaration) {
typedeclaration typedeclaration = (typedeclaration) referencecontext;
fielddeclaration[] fields = typedeclaration.fields;
if (fields != null) {
done : for (int i = 0; i < fields.length; i++) {
if (fields[i] instanceof initializer) {
initializer initializer = (initializer) fields[i];
if (initializer.bodystart <= variable.sourcestart &&
variable.sourcestart < initializer.bodyend) {
unresolvedreferencenamefinder namefinder = new unresolvedreferencenamefinder(this);
namefinder.find(
this.completiontoken,
initializer,
typedeclaration.scope,
variable.declarationsourceend + 1,
discouragednames,
namerequestor);
break done;
}
}
}
}
}

int proposednamescount = proposednames.size();
if (proposednamescount > 0) {
return (char[][])proposednames.toarray(new char[proposednamescount][]);
}
}

return null;
}

private void findvariablename(
char[] token,
char[] qualifiedpackagename,
char[] qualifiedsourcename,
char[] sourcename,
final typebinding typebinding,
char[][] discouragednames,
final char[][] forbiddennames,
boolean forcollection,
int dim,
int kind){

if(sourcename == null || sourcename.length == 0)
return;

// compute variable name for non base type
final char[] displayname;
if (!forcollection) {
if (dim > 0){
int l = qualifiedsourcename.length;
displayname = new char[l+(2*dim)];
system.arraycopy(qualifiedsourcename, 0, displayname, 0, l);
for(int i = 0; i < dim; i++){
displayname[l+(i*2)] = '[';
displayname[l+(i*2)+1] = ']';
}
} else {
displayname = qualifiedsourcename;
}
} else {
displayname = typebinding.qualifiedsourcename();
}

final char[] t = token;
final char[] q = qualifiedpackagename;
inamingrequestor namingrequestor = new inamingrequestor() {
void accept(char[] name, int prefixandsuffixrelevance, int reusedcharacters){
int l = forbiddennames == null ? 0 : forbiddennames.length;
for (int i = 0; i < l; i++) {
if (charoperation.equals(forbiddennames[i], name, false)) return;
}

if (charoperation.prefixequals(t, name, false)) {
int relevance = computebaserelevance();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforcasematching(t, name);
relevance += prefixandsuffixrelevance;
if(reusedcharacters > 0) relevance += r_name_less_new_characters;
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for variable name

// accept result
completionengine.this.noproposal = false;
if(!completionengine.this.requestor.isignored(completionproposal.variable_declaration)) {
internalcompletionproposal proposal =  completionengine.this.createproposal(completionproposal.variable_declaration, completionengine.this.actualcompletionposition);
proposal.setsignature(getsignature(typebinding));
proposal.setpackagename(q);
proposal.settypename(displayname);
proposal.setname(name);
proposal.setcompletion(name);
//proposal.setflags(flags.accdefault);
proposal.setreplacerange(completionengine.this.startposition - completionengine.this.offset, completionengine.this.endposition - completionengine.this.offset);
proposal.settokenrange(completionengine.this.tokenstart - completionengine.this.offset, completionengine.this.tokenend - completionengine.this.offset);
proposal.setrelevance(relevance);
completionengine.this.requestor.accept(proposal);
if(debug) {
completionengine.this.printdebug(proposal);
}
}
}
}

public void acceptnamewithoutprefixandsuffix(char[] name,int reusedcharacters) {
accept(name, 0, reusedcharacters);
}

public void acceptnamewithprefix(char[] name, boolean isfirstprefix, int reusedcharacters) {
accept(name, isfirstprefix ? r_name_first_prefix :  r_name_prefix, reusedcharacters);
}

public void acceptnamewithprefixandsuffix(char[] name, boolean isfirstprefix, boolean isfirstsuffix, int reusedcharacters) {
accept(
name,
(isfirstprefix ? r_name_first_prefix : r_name_prefix) + (isfirstsuffix ? r_name_first_suffix : r_name_suffix),
reusedcharacters);
}
public void acceptnamewithsuffix(char[] name, boolean isfirstsuffix, int reusedcharacters) {
accept(name, isfirstsuffix ? r_name_first_suffix : r_name_suffix, reusedcharacters);
}
};

internalnamingconventions.suggestvariablenames(
kind,
internalnamingconventions.bk_simple_type_name,
qualifiedsourcename,
this.javaproject,
dim,
token,
discouragednames,
true,
namingrequestor);
}

// helper method for private void findvariablenames(char[] name, typereference type )
private void findvariablename(
char[] token,
char[] qualifiedpackagename,
char[] qualifiedsourcename,
char[] sourcename,
final typebinding typebinding,
char[][] discouragednames,
final char[][] forbiddennames,
int dim,
int kind){
findvariablename(
token,
qualifiedpackagename,
qualifiedsourcename,
sourcename,
typebinding,
discouragednames,
forbiddennames,
false,
dim,
kind);
}
private void findvariablenameforcollection(
char[] token,
char[] qualifiedpackagename,
char[] qualifiedsourcename,
char[] sourcename,
final typebinding typebinding,
char[][] discouragednames,
final char[][] forbiddennames,
int kind){

findvariablename(
token,
qualifiedpackagename,
qualifiedsourcename,
sourcename,
typebinding,
discouragednames,
forbiddennames,
false,
1,
kind);
}
private void findvariablenames(char[] name, typereference type , char[][] discouragednames, char[][] forbiddennames, int kind){
if(type != null &&
type.resolvedtype != null) {
typebinding tb = type.resolvedtype;

if (tb.problemid() == problemreasons.noerror &&
tb != scope.getbasetype(void)) {
findvariablename(
name,
tb.leafcomponenttype().qualifiedpackagename(),
tb.leafcomponenttype().qualifiedsourcename(),
tb.leafcomponenttype().sourcename(),
tb,
discouragednames,
forbiddennames,
type.dimensions(),
kind);

if (tb.isparameterizedtype() &&
tb.findsupertypeoriginatingfrom(typeids.t_javautilcollection, false) != null) {
parameterizedtypebinding ptb = ((parameterizedtypebinding) tb);
typebinding[] arguments = ptb.arguments;
if (arguments != null && arguments.length == 1) {
typebinding argument = arguments[0];
findvariablenameforcollection(
name,
argument.leafcomponenttype().qualifiedpackagename(),
argument.leafcomponenttype().qualifiedsourcename(),
argument.leafcomponenttype().sourcename(),
tb,
discouragednames,
forbiddennames,
kind);
}
}
}
}

}
private void findvariablesandmethods(
char[] token,
scope scope,
invocationsite invocationsite,
scope invocationscope,
boolean insidetypeannotation,
boolean insideannotationattribute) {

if (token == null)
return;

// should local variables hide fields from the receiver type or any of its enclosing types?
// we know its an implicit field/method access... see blockscope getbinding/getimplicitmethod

boolean staticsonly = false;
// need to know if we're in a static context (or inside a constructor)
int tokenlength = token.length;

objectvector localsfound = new objectvector();
objectvector fieldsfound = new objectvector();
objectvector methodsfound = new objectvector();

scope currentscope = scope;

if (!this.requestor.isignored(completionproposal.local_variable_ref)) {
done1 : while (true) { // done when a compilation_unit_scope is found

switch (currentscope.kind) {

case scope.method_scope :
// handle the error case inside an explicit constructor call (see methodscope>>findfield)
methodscope methodscope = (methodscope) currentscope;
staticsonly |= methodscope.isstatic | methodscope.isconstructorcall;

//$fall-through$
case scope.block_scope :
blockscope blockscope = (blockscope) currentscope;

next : for (int i = 0, length = blockscope.locals.length; i < length; i++) {
localvariablebinding local = blockscope.locals[i];

if (local == null)
break next;

if (tokenlength > local.name.length)
continue next;

if (!charoperation.prefixequals(token, local.name, false /* ignore case */)
&& !(this.options.camelcasematch && charoperation.camelcasematch(token, local.name)))
continue next;

if (local.issecret())
continue next;

for (int f = 0; f < localsfound.size; f++) {
localvariablebinding otherlocal =
(localvariablebinding) localsfound.elementat(f);
if (charoperation.equals(otherlocal.name, local.name, true))
continue next;
}
localsfound.add(local);

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal(local);
relevance += computerelevanceforcasematching(token, local.name);
relevance += computerelevanceforexpectingtype(local.type);
relevance += computerelevanceforenumconstant(local.type);
relevance += computerelevanceforqualification(false);
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for local variable
this.noproposal = false;
if(!this.requestor.isignored(completionproposal.local_variable_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.local_variable_ref, this.actualcompletionposition);
proposal.setsignature(
local.type == null
? createtypesignature(
charoperation.no_char,
local.declaration.type.tostring().tochararray())
: getsignature(local.type));
if(local.type == null) {
//proposal.setpackagename(null);
proposal.settypename(local.declaration.type.tostring().tochararray());
} else {
proposal.setpackagename(local.type.qualifiedpackagename());
proposal.settypename(local.type.qualifiedsourcename());
}
proposal.setname(local.name);
proposal.setcompletion(local.name);
proposal.setflags(local.modifiers);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
break;

case scope.compilation_unit_scope :
break done1;
}
currentscope = currentscope.parent;
}
}

checkcancel();

boolean proposefield = !this.requestor.isignored(completionproposal.field_ref);
boolean proposemethod = !this.requestor.isignored(completionproposal.method_ref);

staticsonly = false;
currentscope = scope;

if(proposefield || proposemethod) {
done2 : while (true) { // done when a compilation_unit_scope is found

switch (currentscope.kind) {
case scope.method_scope :
// handle the error case inside an explicit constructor call (see methodscope>>findfield)
methodscope methodscope = (methodscope) currentscope;
staticsonly |= methodscope.isstatic | methodscope.isconstructorcall;
break;
case scope.class_scope :
classscope classscope = (classscope) currentscope;
sourcetypebinding enclosingtype = classscope.referencecontext.binding;
/*				if (tokenlength == 0) { // only search inside the type itself if no prefix was provided
findfields(token, enclosingtype.fields(), classscope, fieldsfound, staticsonly);
findmethods(token, enclosingtype.methods(), classscope, methodsfound, staticsonly, false);
break done;
} else { */
if(!insidetypeannotation) {
if(proposefield) {
findfields(
token,
enclosingtype,
classscope,
fieldsfound,
localsfound,
staticsonly,
invocationsite,
invocationscope,
true,
true,
null,
null,
null,
false,
null,
-1,
-1);
}
if(proposemethod && !insideannotationattribute) {
findmethods(
token,
null,
null,
enclosingtype,
classscope,
methodsfound,
staticsonly,
false,
invocationsite,
invocationscope,
true,
false,
true,
null,
null,
null,
false,
null,
-1,
-1);
}
}
staticsonly |= enclosingtype.isstatic();
insidetypeannotation = false;
//				}
break;

case scope.compilation_unit_scope :
break done2;
}
currentscope = currentscope.parent;
}

checkcancel();

findfieldsandmethodsfromstaticimports(
token,
scope,
invocationsite,
invocationscope,
false,
insideannotationattribute,
localsfound,
fieldsfound,
methodsfound,
proposefield,
proposemethod);

if (this.assistnodeinjavadoc == 0) {

checkcancel();

// search in favorites import
findfieldsandmethodsfromfavorites(
token,
scope,
invocationsite,
invocationscope,
localsfound,
fieldsfound,
methodsfound);
}

checkcancel();

findenumconstantsfromexpectedtypes(
token,
invocationscope,
fieldsfound);
}
}

private char[] getcompletedtypesignature(referencebinding referencebinding) {
char[] result = null;
stringbuffer sig = new stringbuffer(10);
if (!referencebinding.ismembertype()) {
char[] typesig = referencebinding.generictypesignature();
sig.append(typesig, 0, typesig.length);
} else if (!this.insidequalifiedreference) {
if (referencebinding.isstatic()) {
char[] typesig = referencebinding.signature();
sig.append(typesig, 0, typesig.length-1); // copy all but trailing semicolon

typevariablebinding[] typevariables = referencebinding.typevariables();
if (typevariables != binding.no_type_variables) {
sig.append(signature.c_generic_start);
for (int i = 0, length = typevariables.length; i < length; i++) {
sig.append(typevariables[i].generictypesignature());
}
sig.append(signature.c_generic_end);
}
sig.append(signature.c_semicolon);
} else {
char[] typesig = referencebinding.generictypesignature();
sig.append(typesig, 0, typesig.length);
}
} else {
referencebinding enclosingtype = referencebinding.enclosingtype();
if (enclosingtype.isparameterizedtype()) {
char[] typesig = referencebinding.generictypesignature();
sig.append(typesig, 0, typesig.length-1);

typevariablebinding[] typevariables = referencebinding.typevariables();
if (typevariables != binding.no_type_variables) {
sig.append(signature.c_generic_start);
for (int i = 0, length = typevariables.length; i < length; i++) {
sig.append(typevariables[i].generictypesignature());
}
sig.append(signature.c_generic_end);
}
} else {
char[] typesig = referencebinding.signature();
sig.append(typesig, 0, typesig.length-1); // copy all but trailing semicolon

if (referencebinding.isstatic()) {
typevariablebinding[] typevariables = referencebinding.typevariables();
if (typevariables != binding.no_type_variables) {
sig.append(signature.c_generic_start);
for (int i = 0, length = typevariables.length; i < length; i++) {
sig.append(typevariables[i].generictypesignature());
}
sig.append(signature.c_generic_end);
}
}
}
sig.append(signature.c_semicolon);
}
int siglength = sig.length();
result = new char[siglength];
sig.getchars(0, siglength, result, 0);
result = charoperation.replaceoncopy(result, '/', signature.c_dot);
return result;
}

private importbinding[] getfavoritereferencebindings(scope scope) {
if (this.favoritereferencebindings != null) return this.favoritereferencebindings;

string[] favoritereferences = this.requestor.getfavoritereferences();

if (favoritereferences == null || favoritereferences.length == 0) return null;

importbinding[] resolvedimports = new importbinding[favoritereferences.length];

int count = 0;
next : for (int i = 0; i < favoritereferences.length; i++) {
string favoritereference = favoritereferences[i];

int length;
if (favoritereference == null || (length = favoritereference.length()) == 0) continue next;

boolean ondemand = favoritereference.charat(length - 1) == '*';

char[][] compoundname = charoperation.spliton('.', favoritereference.tochararray());
if (ondemand) {
compoundname = charoperation.subarray(compoundname, 0, compoundname.length - 1);
}

// remove duplicate and conflicting
for (int j = 0; j < count; j++) {
importreference f = resolvedimports[j].reference;

if (charoperation.equals(f.tokens, compoundname)) continue next;

if (!ondemand && ((f.bits & astnode.ondemand) == 0)) {
if (charoperation.equals(f.tokens[f.tokens.length - 1], compoundname[compoundname.length - 1]))
continue next;
}
}

boolean isstatic = true;

importreference importreference =
new importreference(
compoundname,
new long[compoundname.length],
ondemand,
isstatic ? classfileconstants.accstatic : classfileconstants.accdefault);

binding importbinding = this.unitscope.findimport(compoundname, isstatic, ondemand);

if (!importbinding.isvalidbinding()) {
continue next;
}

if (importbinding instanceof packagebinding) {
continue next;
}

resolvedimports[count++] =
new importbinding(compoundname, ondemand, importbinding, importreference);
}

if (resolvedimports.length > count)
system.arraycopy(resolvedimports, 0, resolvedimports = new importbinding[count], 0, count);

return this.favoritereferencebindings = resolvedimports;
}

private inameenvironment getnocachenameenvironment() {
if (this.nocachenameenvironment == null) {
javamodelmanager.getjavamodelmanager().cachezipfiles(this);
this.nocachenameenvironment = new javasearchnameenvironment(this.javaproject, this.owner == null ? null : javamodelmanager.getjavamodelmanager().getworkingcopies(this.owner, true/*add primary wcs*/));
}
return this.nocachenameenvironment;
}

public assistparser getparser() {

return this.parser;
}
protected boolean hasarraytypeasexpectedsupertypes() {
if ((this.expectedtypesfilter & ~subtype) != 0) return false;

if (!this.hascomputedexpectedarraytypes) {
if(this.expectedtypes != null) {
done : for (int i = 0; i <= this.expectedtypesptr; i++) {
if(this.expectedtypes[i].isarraytype()) {
this.hasexpectedarraytypes = true;
break done;
}
}
}

this.hascomputedexpectedarraytypes = true;
}

return this.hasexpectedarraytypes;
}
protected boolean haspossibleannotationtarget(typebinding typebinding, scope scope) {
if (this.targetedelement == tagbits.annotationforpackage) {
long target = typebinding.getannotationtagbits() & tagbits.annotationtargetmask;
if(target != 0 && (target & tagbits.annotationforpackage) == 0) {
return false;
}
} else if ((this.targetedelement & tagbits.annotationfortype) != 0) {
if (scope.parent != null &&
scope.parent.parent != null &&
scope.parent.referencecontext() instanceof completiononannotationoftype &&
scope.parent.parent instanceof compilationunitscope) {
long target = typebinding.getannotationtagbits() & tagbits.annotationtargetmask;
if ((this.targetedelement & tagbits.annotationforannotationtype) != 0) {
if(target != 0 && (target &(tagbits.annotationfortype | tagbits.annotationforannotationtype)) == 0) {
return false;
}
} else {
if(target != 0 && (target &(tagbits.annotationfortype)) == 0) {
return false;
}
}
}
}
return true;
}
/**
* returns completion string inserted inside a specified inline tag.
* @@param completionname
* @@return char[] completion text inclunding specified inline tag
*/
private char[] inlinetagcompletion(char[] completionname, char[] inlinetag) {
int taglength= inlinetag.length;
int completionlength = completionname.length;
int inlinelength = 2+taglength+1+completionlength+1;
char[] inlinecompletion = new char[inlinelength];
inlinecompletion[0] = '{';
inlinecompletion[1] = '@@';
system.arraycopy(inlinetag, 0, inlinecompletion, 2, taglength);
inlinecompletion[taglength+2] = ' ';
system.arraycopy(completionname, 0, inlinecompletion, taglength+3, completionlength);
// do not add space at end of inline tag (see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=121026)
//inlinecompletion[inlinelength-2] = ' ';
inlinecompletion[inlinelength-1] = '}';
return inlinecompletion;
}
private boolean isallowinglongcomputationproposals() {
return this.monitor != null;
}
private boolean isforbidden(binding binding) {
for (int i = 0; i <= this.forbbidenbindingsptr; i++) {
if(this.forbbidenbindings[i] == binding) {
return true;
}
if((this.forbbidenbindingsfilter & subtype) != 0) {
if (binding instanceof typebinding &&
this.forbbidenbindings[i] instanceof typebinding &&
((typebinding)binding).iscompatiblewith((typebinding)this.forbbidenbindings[i])) {
return true;
}
}
}
return false;
}

private boolean isforbiddentype(char[] givenpkgname, char[] giventypename, char[][] enclosingtypenames) {
// charoperation.concatwith() handles the cases where input args are null/empty
char[] fulltypename = charoperation.concatwith(enclosingtypenames, giventypename, '.');
for (int i = 0; i <= this.forbbidenbindingsptr; i++) {
if (this.forbbidenbindings[i] instanceof typebinding) {
typebinding typebinding = (typebinding) this.forbbidenbindings[i];
char[] currpkgname = typebinding.qualifiedpackagename();
if (charoperation.equals(givenpkgname, currpkgname))	{
char[] currtypename = typebinding.qualifiedsourcename();
if (charoperation.equals(fulltypename, currtypename)) {
return true;
}
}
}
}
return false;
}

private boolean isignored(int kind) {
return this.requestor.isignored(kind);
}
boolean isignored(int kind, boolean missingtypes) {
return this.requestor.isignored(kind) ||
(missingtypes && !this.requestor.isallowingrequiredproposals(kind, completionproposal.type_ref));
}

private boolean isignored(int kind, int requiredproposalkind) {
return this.requestor.isignored(kind) ||
!this.requestor.isallowingrequiredproposals(kind, requiredproposalkind);
}
private boolean isvalidparent(astnode parent, astnode node, scope scope){

if(parent instanceof parameterizedsingletypereference) {
parameterizedsingletypereference ref = (parameterizedsingletypereference) parent;
typevariablebinding[] typevariables = ((referencebinding)ref.resolvedtype).typevariables();
int length = ref.typearguments == null ? 0 : ref.typearguments.length;
int nodeindex = -1;
for(int i = length - 1 ; i > -1 ; i--) {
if(node == ref.typearguments[i]) {
nodeindex = i;
break;
}
}
if(nodeindex > -1 && (typevariables == null || typevariables.length < nodeindex + 1)) {
typebinding[] typebindings = new typebinding[nodeindex + 1];
for(int i = 0; i < nodeindex; i++) {
typebindings[i] = ref.typearguments[i].resolvedtype;
}
typebindings[nodeindex] = scope.getjavalangobject();
if(typevariables == null || typevariables.length == 0) {
scope.problemreporter().nongenerictypecannotbeparameterized(0, ref, ref.resolvedtype, typebindings);
} else {
scope.problemreporter().incorrectarityforparameterizedtype(ref, ref.resolvedtype, typebindings);
}
return false;
}
} else if(parent instanceof parameterizedqualifiedtypereference) {
parameterizedqualifiedtypereference ref = (parameterizedqualifiedtypereference) parent;
typevariablebinding[] typevariables = ((referencebinding)ref.resolvedtype).typevariables();
typereference[][] arguments = ref.typearguments;
int ilength = arguments == null ? 0 : arguments.length;
for (int i = 0; i < ilength; i++) {
int jlength = arguments[i] == null ? 0 : arguments[i].length;
for (int j = 0; j < jlength; j++) {
if(arguments[i][j] == node && (typevariables == null || typevariables.length <= j)) {
typebinding[] typebindings = new typebinding[j + 1];
for(int k = 0; k < j; k++) {
typebindings[k] = ref.typearguments[i][k].resolvedtype;
}
typebindings[j] = scope.getjavalangobject();
if(typevariables == null || typevariables.length == 0) {
scope.problemreporter().nongenerictypecannotbeparameterized(0, ref, ref.resolvedtype, typebindings);
} else {
scope.problemreporter().incorrectarityforparameterizedtype(ref, ref.resolvedtype, typebindings);
}
return false;
}
}
}
}
return true;
}
private boolean mustqualifytype(referencebinding type, char[] packagename, scope scope) {
if(!mustqualifytype(
packagename,
type.sourcename(),
type.ismembertype() ? type.enclosingtype().qualifiedsourcename() : null,
type.modifiers)) {
return false;
}
referencebinding enclosingtype = scope.enclosingsourcetype();
while (enclosingtype != null) {
referencebinding currenttype = enclosingtype;
while (currenttype != null) {
referencebinding[] membertypes = currenttype.membertypes();
if(membertypes != null) {
for (int i = 0; i < membertypes.length; i++) {
if (charoperation.equals(membertypes[i].sourcename, type.sourcename()) &&
membertypes[i].canbeseenby(scope)) {
return membertypes[i] != type;
}
}
}
currenttype = currenttype.superclass();
}
enclosingtype = enclosingtype.enclosingtype();
}
return true;
}
private initializer parsesnippeinitializer(char[] snippet, int position, char[][] localvariabletypenames, char[][] localvariablenames, int[] localvariablemodifiers, boolean isstatic){
stringbuffer prefix = new stringbuffer();
prefix.append("public class faketype {\n "); //$non-nls-1$
if(isstatic) {
prefix.append("static "); //$non-nls-1$
}
prefix.append("{\n"); //$non-nls-1$
for (int i = 0; i < localvariabletypenames.length; i++) {
astnode.printmodifiers(localvariablemodifiers[i], prefix);
prefix.append(' ');
prefix.append(localvariabletypenames[i]);
prefix.append(' ');
prefix.append(localvariablenames[i]);
prefix.append(';');
}

char[] fakesource = charoperation.concat(prefix.tostring().tochararray(), snippet, "}}".tochararray());//$non-nls-1$
this.offset = prefix.length();

string encoding = this.compileroptions.defaultencoding;
basiccompilationunit fakeunit = new basiccompilationunit(
fakesource,
null,
"faketype.java", //$non-nls-1$
encoding);

this.actualcompletionposition = prefix.length() + position - 1;

compilationresult fakeresult = new compilationresult(fakeunit, 1, 1, this.compileroptions.maxproblemsperunit);
compilationunitdeclaration fakeast = this.parser.dietparse(fakeunit, fakeresult, this.actualcompletionposition);

parseblockstatements(fakeast, this.actualcompletionposition);

return (initializer)fakeast.types[0].fields[0];
}
protected void printdebug(categorizedproblem error) {
if(completionengine.debug) {
system.out.print("completion - completionfailure("); //$non-nls-1$
system.out.print(error);
system.out.println(")"); //$non-nls-1$
}
}
protected void printdebug(completionproposal proposal){
stringbuffer buffer = new stringbuffer();
printdebug(proposal, 0, buffer);
system.out.println(buffer.tostring());
}

private void printdebug(completionproposal proposal, int tab, stringbuffer buffer){
printdebugtab(tab, buffer);
buffer.append("completion - "); //$non-nls-1$
switch(proposal.getkind()) {
case completionproposal.anonymous_class_declaration :
buffer.append("anonymous_class_declaration"); //$non-nls-1$
break;
case completionproposal.field_ref :
buffer.append("field_ref"); //$non-nls-1$
break;
case completionproposal.field_ref_with_casted_receiver :
buffer.append("field_ref_with_casted_receiver"); //$non-nls-1$
break;
case completionproposal.keyword :
buffer.append("keyword"); //$non-nls-1$
break;
case completionproposal.label_ref :
buffer.append("label_ref"); //$non-nls-1$
break;
case completionproposal.local_variable_ref :
buffer.append("local_variable_ref"); //$non-nls-1$
break;
case completionproposal.method_declaration :
buffer.append("method_declaration"); //$non-nls-1$
break;
case completionproposal.method_ref :
buffer.append("method_ref"); //$non-nls-1$
break;
case completionproposal.method_ref_with_casted_receiver :
buffer.append("method_ref_with_casted_receiver"); //$non-nls-1$
break;
case completionproposal.package_ref :
buffer.append("package_ref"); //$non-nls-1$
break;
case completionproposal.type_ref :
buffer.append("type_ref"); //$non-nls-1$
break;
case completionproposal.variable_declaration :
buffer.append("variable_declaration"); //$non-nls-1$
break;
case completionproposal.potential_method_declaration :
buffer.append("potential_method_declaration"); //$non-nls-1$
break;
case completionproposal.method_name_reference :
buffer.append("method_name_reference"); //$non-nls-1$
break;
case completionproposal.annotation_attribute_ref :
buffer.append("annotation_attribut_ref"); //$non-nls-1$
break;
case completionproposal.field_import :
buffer.append("field_import"); //$non-nls-1$
break;
case completionproposal.method_import :
buffer.append("method_import"); //$non-nls-1$
break;
case completionproposal.type_import :
buffer.append("type_import"); //$non-nls-1$
break;
case completionproposal.constructor_invocation :
buffer.append("constructor_invocation"); //$non-nls-1$
break;
case completionproposal.anonymous_class_constructor_invocation :
buffer.append("anonymous_class_constructor_invocation"); //$non-nls-1$
break;
default :
buffer.append("proposal"); //$non-nls-1$
break;

}

buffer.append("{\n");//$non-nls-1$
printdebugtab(tab, buffer);
buffer.append("\tcompletion[").append(proposal.getcompletion() == null ? "null".tochararray() : proposal.getcompletion()).append("]\n"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
printdebugtab(tab, buffer);
buffer.append("\tdeclarationsignature[").append(proposal.getdeclarationsignature() == null ? "null".tochararray() : proposal.getdeclarationsignature()).append("]\n"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
printdebugtab(tab, buffer);
buffer.append("\tdeclarationkey[").append(proposal.getdeclarationkey() == null ? "null".tochararray() : proposal.getdeclarationkey()).append("]\n"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
printdebugtab(tab, buffer);
buffer.append("\tsignature[").append(proposal.getsignature() == null ? "null".tochararray() : proposal.getsignature()).append("]\n"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
printdebugtab(tab, buffer);
buffer.append("\tkey[").append(proposal.getkey() == null ? "null".tochararray() : proposal.getkey()).append("]\n"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
printdebugtab(tab, buffer);
buffer.append("\tname[").append(proposal.getname() == null ? "null".tochararray() : proposal.getname()).append("]\n"); //$non-nls-1$ //$non-nls-2$ //$non-nls-3$

printdebugtab(tab, buffer);
buffer.append("\tflags[");//$non-nls-1$
int flags = proposal.getflags();
buffer.append(flags.tostring(flags));
if((flags & flags.accinterface) != 0) buffer.append("interface ");//$non-nls-1$
if((flags & flags.accenum) != 0) buffer.append("enum ");//$non-nls-1$
buffer.append("]\n"); //$non-nls-1$

completionproposal[] proposals = proposal.getrequiredproposals();
if(proposals != null) {
printdebugtab(tab, buffer);
buffer.append("\trequiredproposals[");//$non-nls-1$
for (int i = 0; i < proposals.length; i++) {
buffer.append("\n"); //$non-nls-1$
printdebug(proposals[i], tab + 2, buffer);
}
printdebugtab(tab, buffer);
buffer.append("\n\t]\n"); //$non-nls-1$
}

printdebugtab(tab, buffer);
buffer.append("\tcompletionlocation[").append(proposal.getcompletionlocation()).append("]\n"); //$non-nls-1$ //$non-nls-2$
int start = proposal.getreplacestart();
int end = proposal.getreplaceend();
printdebugtab(tab, buffer);
buffer.append("\treplacestart[").append(start).append("]"); //$non-nls-1$ //$non-nls-2$
buffer.append("-replaceend[").append(end).append("]\n"); //$non-nls-1$ //$non-nls-2$
start = proposal.gettokenstart();
end = proposal.gettokenend();
printdebugtab(tab, buffer);
buffer.append("\ttokenstart[").append(start).append("]"); //$non-nls-1$ //$non-nls-2$
buffer.append("-tokenend[").append(end).append("]\n"); //$non-nls-1$ //$non-nls-2$
if (this.source != null) {
printdebugtab(tab, buffer);
buffer.append("\treplacedtext[").append(this.source, start, end-start).append("]\n"); //$non-nls-1$ //$non-nls-2$
}
printdebugtab(tab, buffer);
buffer.append("\ttokenstart[").append(proposal.gettokenstart()).append("]"); //$non-nls-1$ //$non-nls-2$
buffer.append("-tokenend[").append(proposal.gettokenend()).append("]\n"); //$non-nls-1$ //$non-nls-2$
printdebugtab(tab, buffer);
buffer.append("\trelevance[").append(proposal.getrelevance()).append("]\n"); //$non-nls-1$ //$non-nls-2$

printdebugtab(tab, buffer);
buffer.append("}\n");//$non-nls-1$
}

private void printdebugtab(int tab, stringbuffer buffer) {
for (int i = 0; i < tab; i++) {
buffer.append('\t');
}
}

private void proposeconstructor(acceptedconstructor deferredproposal, scope scope) {
if (deferredproposal.proposeconstructor) {
proposeconstructor(
deferredproposal.simpletypename,
deferredproposal.parametercount,
deferredproposal.signature,
deferredproposal.parametertypes,
deferredproposal.parameternames,
deferredproposal.modifiers,
deferredproposal.packagename,
deferredproposal.typemodifiers,
deferredproposal.accessibility,
deferredproposal.simpletypename,
deferredproposal.fullyqualifiedname,
deferredproposal.mustbequalified,
scope,
deferredproposal.extraflags);
}
}

private void proposeconstructor(
char[] simpletypename,
int parametercount,
char[] signature,
char[][] parametertypes,
char[][] parameternames,
int modifiers,
char[] packagename,
int typemodifiers,
int accessibility,
char[] typename,
char[] fullyqualifiedname,
boolean isqualified,
scope scope,
int extraflags) {
char[] typecompletion = fullyqualifiedname;
if(isqualified) {
if (packagename == null || packagename.length == 0)
if (this.unitscope != null && this.unitscope.fpackage.compoundname != charoperation.no_char_char)
return; // ignore types from the default package from outside it
} else {
typecompletion = simpletypename;
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforrestrictions(accessibility);
relevance += computerelevanceforcasematching(this.completiontoken, simpletypename);
relevance += computerelevanceforexpectingtype(packagename, simpletypename);
relevance += computerelevanceforqualification(isqualified);

boolean isinterface = false;
int kind = typemodifiers & (classfileconstants.accinterface | classfileconstants.accenum | classfileconstants.accannotation);
switch (kind) {
case classfileconstants.accannotation:
case classfileconstants.accannotation | classfileconstants.accinterface:
relevance += computerelevanceforannotation();
relevance += computerelevanceforinterface();
isinterface = true;
break;
case classfileconstants.accenum:
relevance += computerelevanceforenum();
break;
case classfileconstants.accinterface:
relevance += computerelevanceforinterface();
isinterface = true;
break;
default:
relevance += computerelevanceforclass();
relevance += computerelevanceforexception(simpletypename);
break;
}

char[] completion;
if (this.source != null
&& this.source.length > this.endposition
&& this.source[this.endposition] == '(') {
completion = charoperation.no_char;
} else {
completion = new char[] { '(', ')' };
}

internalcompletionproposal typeproposal = createproposal(completionproposal.type_ref, this.actualcompletionposition);
typeproposal.namelookup = this.nameenvironment.namelookup;
typeproposal.completionengine = this;
typeproposal.setdeclarationsignature(packagename);
typeproposal.setsignature(createnongenerictypesignature(packagename, typename));
typeproposal.setpackagename(packagename);
typeproposal.settypename(typename);
typeproposal.setcompletion(typecompletion);
typeproposal.setflags(typemodifiers);
typeproposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
typeproposal.settokenrange(this.startposition - this.offset, this.endposition - this.offset);
typeproposal.setrelevance(relevance);

switch (parametercount) {
case -1: // default constructor
int flags = flags.accpublic;
if (flags.isdeprecated(typemodifiers)) {
flags |= flags.accdeprecated;
}

if (isinterface || (typemodifiers & classfileconstants.accabstract) != 0) {
this.noproposal = false;
if(!isignored(completionproposal.anonymous_class_constructor_invocation, completionproposal.type_ref)) {
internalcompletionproposal proposal = createproposal(completionproposal.anonymous_class_constructor_invocation, this.actualcompletionposition);
proposal.setdeclarationsignature(createnongenerictypesignature(packagename, typename));
proposal.setdeclarationkey(createbindingkey(packagename, typename));
proposal.setsignature(default_constructor_signature);
proposal.setdeclarationpackagename(packagename);
proposal.setdeclarationtypename(typename);
proposal.setparameterpackagenames(charoperation.no_char_char);
proposal.setparametertypenames(charoperation.no_char_char);
proposal.setparameternames(charoperation.no_char_char);
proposal.setname(simpletypename);
proposal.setrequiredproposals(new completionproposal[]{typeproposal});
proposal.setiscontructor(true);
proposal.setcompletion(completion);
proposal.setflags(flags);
proposal.setreplacerange(this.endposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
} else {
this.noproposal = false;
if(!isignored(completionproposal.constructor_invocation, completionproposal.type_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.constructor_invocation, this.actualcompletionposition);
proposal.setdeclarationsignature(createnongenerictypesignature(packagename, typename));
proposal.setsignature(default_constructor_signature);
proposal.setdeclarationpackagename(packagename);
proposal.setdeclarationtypename(typename);
proposal.setparameterpackagenames(charoperation.no_char_char);
proposal.setparametertypenames(charoperation.no_char_char);
proposal.setparameternames(charoperation.no_char_char);
proposal.setname(simpletypename);
proposal.setrequiredproposals(new completionproposal[]{typeproposal});
proposal.setiscontructor(true);
proposal.setcompletion(completion);
proposal.setflags(flags);
proposal.setreplacerange(this.endposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
break;
case 0: // constructor with no parameter

if ((typemodifiers & classfileconstants.accabstract) != 0) {
this.noproposal = false;
if(!isignored(completionproposal.anonymous_class_constructor_invocation, completionproposal.type_ref)) {
internalcompletionproposal proposal = createproposal(completionproposal.anonymous_class_constructor_invocation, this.actualcompletionposition);
proposal.setdeclarationsignature(createnongenerictypesignature(packagename, typename));
proposal.setdeclarationkey(createbindingkey(packagename, typename));
proposal.setsignature(default_constructor_signature);
proposal.setdeclarationpackagename(packagename);
proposal.setdeclarationtypename(typename);
proposal.setparameterpackagenames(charoperation.no_char_char);
proposal.setparametertypenames(charoperation.no_char_char);
proposal.setparameternames(charoperation.no_char_char);
proposal.setname(simpletypename);
proposal.setrequiredproposals(new completionproposal[]{typeproposal});
proposal.setiscontructor(true);
proposal.setcompletion(completion);
proposal.setflags(modifiers);
proposal.setreplacerange(this.endposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
} else {
this.noproposal = false;
if(!isignored(completionproposal.constructor_invocation, completionproposal.type_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.constructor_invocation, this.actualcompletionposition);
proposal.setdeclarationsignature(createnongenerictypesignature(packagename, typename));
proposal.setsignature(default_constructor_signature);
proposal.setdeclarationpackagename(packagename);
proposal.setdeclarationtypename(typename);
proposal.setparameterpackagenames(charoperation.no_char_char);
proposal.setparametertypenames(charoperation.no_char_char);
proposal.setparameternames(charoperation.no_char_char);
proposal.setname(simpletypename);
proposal.setrequiredproposals(new completionproposal[]{typeproposal});
proposal.setiscontructor(true);
proposal.setcompletion(completion);
proposal.setflags(modifiers);
proposal.setreplacerange(this.endposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
break;
default: // constructor with parameter
if (signature == null) {
// resolve type to found parameter types
signature = getresolvedsignature(parametertypes, fullyqualifiedname, parametercount, scope);
if (signature == null) return;
} else {
signature = charoperation.replaceoncopy(signature, '/', '.');
}

int parameternameslength = parameternames == null ? 0 : parameternames.length;
if (parametercount != parameternameslength) {
parameternames = null;
}

if ((typemodifiers & classfileconstants.accabstract) != 0) {
this.noproposal = false;
if(!isignored(completionproposal.anonymous_class_constructor_invocation, completionproposal.type_ref)) {
internalcompletionproposal proposal = createproposal(completionproposal.anonymous_class_constructor_invocation, this.actualcompletionposition);
proposal.setdeclarationsignature(createnongenerictypesignature(packagename, typename));
proposal.setdeclarationkey(createbindingkey(packagename, typename));
proposal.setsignature(signature);
proposal.setdeclarationpackagename(packagename);
proposal.setdeclarationtypename(typename);
proposal.setparameterpackagenames(charoperation.no_char_char);
proposal.setparametertypenames(charoperation.no_char_char);
if (parameternames != null) {
proposal.setparameternames(parameternames);
} else {
proposal.sethasnoparameternamesfromindex(true);
}
proposal.setname(simpletypename);
proposal.setrequiredproposals(new completionproposal[]{typeproposal});
proposal.setiscontructor(true);
proposal.setcompletion(completion);
proposal.setflags(modifiers);
proposal.setreplacerange(this.endposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
} else {
this.noproposal = false;
if(!isignored(completionproposal.constructor_invocation, completionproposal.type_ref)) {
internalcompletionproposal proposal =  createproposal(completionproposal.constructor_invocation, this.actualcompletionposition);
proposal.setdeclarationsignature(createnongenerictypesignature(packagename, typename));
proposal.setsignature(signature);
proposal.setdeclarationpackagename(packagename);
proposal.setdeclarationtypename(typename);
proposal.setparameterpackagenames(charoperation.no_char_char);
proposal.setparametertypenames(charoperation.no_char_char);
if (parameternames != null) {
proposal.setparameternames(parameternames);
} else {
proposal.sethasnoparameternamesfromindex(true);
}
proposal.setname(simpletypename);
proposal.setrequiredproposals(new completionproposal[]{typeproposal});
proposal.setiscontructor(true);
proposal.setcompletion(completion);
proposal.setflags(modifiers);
proposal.setreplacerange(this.endposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);

this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}
break;
}
}

private void proposenewmethod(char[] token, referencebinding reference) {
if(!this.requestor.isignored(completionproposal.potential_method_declaration)) {
int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforrestrictions(iaccessrule.k_accessible); // no access restriction for new method

internalcompletionproposal proposal =  createproposal(completionproposal.potential_method_declaration, this.actualcompletionposition);
proposal.setdeclarationsignature(getsignature(reference));
proposal.setsignature(
createmethodsignature(
charoperation.no_char_char,
charoperation.no_char_char,
charoperation.no_char,
void));
proposal.setdeclarationpackagename(reference.qualifiedpackagename());
proposal.setdeclarationtypename(reference.qualifiedsourcename());

//proposal.setpackagename(null);
proposal.settypename(void);
proposal.setname(token);
//proposal.setparameterpackagenames(null);
//proposal.setparametertypenames(null);
//proposal.setpackagename(null);
proposal.setcompletion(token);
proposal.setflags(flags.accpublic);
proposal.setreplacerange(this.startposition - this.offset, this.endposition - this.offset);
proposal.settokenrange(this.tokenstart - this.offset, this.tokenend - this.offset);
proposal.setrelevance(relevance);
this.requestor.accept(proposal);
if(debug) {
this.printdebug(proposal);
}
}
}

private void proposetype(
char[] packagename,
char[] simpletypename,
int modifiers,
int accessibility,
char[] typename,
char[] fullyqualifiedname,
boolean isqualified,
scope scope) {
char[] completionname = fullyqualifiedname;
if(isqualified) {
if (packagename == null || packagename.length == 0)
if (this.unitscope != null && this.unitscope.fpackage.compoundname != charoperation.no_char_char)
return; // ignore types from the default package from outside it
} else {
completionname = simpletypename;
}

typebinding guessedtype = null;
if ((modifiers & classfileconstants.accannotation) != 0 &&
this.assistnodeisannotation &&
(this.targetedelement & tagbits.annotationtargetmask) != 0) {
char[][] cn = charoperation.spliton('.', fullyqualifiedname);

typereference ref;
if (cn.length == 1) {
ref = new singletypereference(simpletypename, 0);
} else {
ref = new qualifiedtypereference(cn,new long[cn.length]);
}

switch (scope.kind) {
case scope.method_scope :
case scope.block_scope :
guessedtype = ref.resolvetype((blockscope)scope);
break;
case scope.class_scope :
guessedtype = ref.resolvetype((classscope)scope);
break;
}

if (guessedtype == null || !guessedtype.isvalidbinding()) return;

if (!haspossibleannotationtarget(guessedtype, scope)) return;
}

int relevance = computebaserelevance();
relevance += computerelevanceforresolution();
relevance += computerelevanceforinterestingproposal();
relevance += computerelevanceforrestrictions(accessibility);
relevance += computerelevanceforcasematching(this.completiontoken, simpletypename);
relevance += computerelevanceforexpectingtype(packagename, simpletypename);
relevance += computerelevanceforqualification(isqualified);

int kind = modifiers & (classfileconstants.accinterface | classfileconstants.accenum | classfileconstants.accannotation);
switch (kind) {
case classfileconstants.accannotation:
case classfileconstants.accannotation | classfileconstants.accinterface:
relevance += computerelevanceforannotation();
if (guessedtype != null) relevance += computerelevanceforannotationtarget(guessedtype);
relevance += computerelevanceforinterface();
break;
case classfileconstants.accenum:
relevance += computerelevanceforenum();
break;
case classfileconstants.accinterface:
relevance += computerelevanceforinterface();
break;
default:
relevance += computerelevanceforclass();
relevance += computerelevanceforexception(simpletypename);
break;
}

this.noproposal = false;
if(!this.requestor.isignored(completionproposal.type_ref)) {
createtypeproposal(packagename, typename, modifiers, accessibility, completionname, relevance);
}
}

protected void reset() {

super.reset(false);
this.knownpkgs = new hashtableofobject(10);
this.knowntypes = new hashtableofobject(10);
if (this.nocachenameenvironment != null) {
this.nocachenameenvironment.cleanup();
this.nocachenameenvironment = null;
javamodelmanager.getjavamodelmanager().flushzipfiles(this);
}
}

private void setsourceandtokenrange(int start, int end) {
this.setsourceandtokenrange(start, end, true);
}

private void setsourceandtokenrange(int start, int end, boolean emptytokenadjstment) {
this.setsourcerange(start, end, emptytokenadjstment);
this.settokenrange(start, end, emptytokenadjstment);
}

private void setsourcerange(int start, int end) {
this.setsourcerange(start, end, true);
}

private void setsourcerange(int start, int end, boolean emptytokenadjstment) {
this.startposition = start;
if(emptytokenadjstment) {
int endofemptytoken = ((completionscanner)this.parser.scanner).endofemptytoken;
this.endposition = endofemptytoken > end ? endofemptytoken + 1 : end + 1;
} else {
this.endposition = end + 1;
}
}

private void settokenrange(int start, int end) {
this.settokenrange(start, end, true);
}
private void settokenrange(int start, int end, boolean emptytokenadjstment) {
this.tokenstart = start;
if(emptytokenadjstment) {
int endofemptytoken = ((completionscanner)this.parser.scanner).endofemptytoken;
this.tokenend = endofemptytoken > end ? endofemptytoken + 1 : end + 1;
} else {
this.tokenend = end + 1;
}
}

private char[] substitutemethodtypeparametername(char firstname, char startchar, char endchar, char[][] excludednames, char[][] otherparameternames) {
char name = firstname;
next : while (true) {
for (int i = 0 ; i < excludednames.length ; i++){
if(excludednames[i].length == 1 && scannerhelper.tolowercase(excludednames[i][0]) == scannerhelper.tolowercase(name)) {
name++;
if(name > endchar)
name = startchar;
if(name == firstname)
return substitutemethodtypeparametername(new char[]{firstname}, excludednames, otherparameternames);
continue next;
}
}

for (int i = 0; i < otherparameternames.length; i++) {
if(otherparameternames[i].length == 1 && scannerhelper.tolowercase(otherparameternames[i][0]) == scannerhelper.tolowercase(name)) {
name++;
if(name > endchar)
name = startchar;
if(name == firstname)
return substitutemethodtypeparametername(new char[]{firstname}, excludednames, otherparameternames);
continue next;
}
}
break next;
}
return new char[]{name};
}

private char[] substitutemethodtypeparametername(char[] firstname, char[][] excludednames, char[][] otherparameternames) {
char[] name = firstname;
int count = 2;
next : while(true) {
for(int k = 0 ; k < excludednames.length ; k++){
if(charoperation.equals(name, excludednames[k], false)) {
name = charoperation.concat(firstname, string.valueof(count++).tochararray());
continue next;
}
}
for (int i = 0; i < otherparameternames.length; i++) {
if(charoperation.equals(name, otherparameternames[i], false)) {
name = charoperation.concat(firstname, string.valueof(count++).tochararray());
continue next;
}
}
break next;
}
return name;
}

private char[][] substitutemethodtypeparameternames(typevariablebinding[] typevariables, char[][] excludednames) {
char[][] substituedparameternames = new char[typevariables.length][];

for (int i = 0; i < substituedparameternames.length; i++) {
substituedparameternames[i] = typevariables[i].sourcename;
}

boolean foundconflicts = false;

nexttypeparameter : for (int i = 0; i < typevariables.length; i++) {
typevariablebinding typevariablebinding = typevariables[i];
char[] methodparametername = typevariablebinding.sourcename;

for (int j = 0; j < excludednames.length; j++) {
char[] typeparametername = excludednames[j];
if(charoperation.equals(typeparametername, methodparametername, false)) {
char[] substitution;
if(methodparametername.length == 1) {
if(scannerhelper.isuppercase(methodparametername[0])) {
substitution = substitutemethodtypeparametername(methodparametername[0], 'a', 'z', excludednames, substituedparameternames);
} else {
substitution = substitutemethodtypeparametername(methodparametername[0], 'a', 'z', excludednames, substituedparameternames);
}
} else {
substitution = substitutemethodtypeparametername(methodparametername, excludednames, substituedparameternames);
}
substituedparameternames[i] = substitution;

foundconflicts = true;
continue nexttypeparameter;
}
}
}

if(foundconflicts) return substituedparameternames;
return null;
}
}@


1.410
log
@head - findbugs changes
