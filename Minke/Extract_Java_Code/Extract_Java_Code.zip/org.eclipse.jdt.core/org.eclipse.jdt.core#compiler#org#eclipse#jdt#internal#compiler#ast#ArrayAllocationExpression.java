/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class arrayallocationexpression extends expression {

public typereference type;

//dimensions.length gives the number of dimensions, but the
// last ones may be nulled as in new int[4][5][][]
public expression[] dimensions;
public arrayinitializer initializer;

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
for (int i = 0, max = this.dimensions.length; i < max; i++) {
expression dim;
if ((dim = this.dimensions[i]) != null) {
flowinfo = dim.analysecode(currentscope, flowcontext, flowinfo);
}
}
if (this.initializer != null) {
return this.initializer.analysecode(currentscope, flowcontext, flowinfo);
}
return flowinfo;
}

/**
* code generation for a array allocation expression
*/
public void generatecode(blockscope currentscope, 	codestream codestream, boolean valuerequired) {

int pc = codestream.position;

if (this.initializer != null) {
this.initializer.generatecode(currentscope, codestream, valuerequired);
return;
}

int explicitdimcount = 0;
for (int i = 0, max = this.dimensions.length; i < max; i++) {
expression dimexpression;
if ((dimexpression = this.dimensions[i]) == null) break; // implicit dim, no further explict after this point
dimexpression.generatecode(currentscope, codestream, true);
explicitdimcount++;
}

// array allocation
if (explicitdimcount == 1) {
// mono-dimensional array
codestream.newarray((arraybinding)this.resolvedtype);
} else {
// multi-dimensional array
codestream.multianewarray(this.resolvedtype, explicitdimcount);
}
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else {
codestream.pop();
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}


public stringbuffer printexpression(int indent, stringbuffer output) {
output.append("new "); //$non-nls-1$
this.type.print(0, output);
for (int i = 0; i < this.dimensions.length; i++) {
if (this.dimensions[i] == null)
output.append("[]"); //$non-nls-1$
else {
output.append('[');
this.dimensions[i].printexpression(0, output);
output.append(']');
}
}
if (this.initializer != null) this.initializer.printexpression(0, output);
return output;
}

public typebinding resolvetype(blockscope scope) {
// build an array type reference using the current dimensions
// the parser does not check for the fact that dimension may be null
// only at the -end- like new int [4][][]. the parser allows new int[][4][]
// so this must be checked here......(this comes from a reduction to ll1 grammar)

typebinding referencetype = this.type.resolvetype(scope, true /* check bounds*/);

// will check for null after dimensions are checked
this.constant = constant.notaconstant;
if (referencetype == typebinding.void) {
scope.problemreporter().cannotallocatevoidarray(this);
referencetype = null;
}

// check the validity of the dimension syntax (and test for all null dimensions)
int explicitdimindex = -1;
loop: for (int i = this.dimensions.length; --i >= 0;) {
if (this.dimensions[i] != null) {
if (explicitdimindex < 0) explicitdimindex = i;
} else if (explicitdimindex > 0) {
// should not have an empty dimension before an non-empty one
scope.problemreporter().incorrectlocationfornonemptydimension(this, explicitdimindex);
break loop;
}
}

// explicitdimindex < 0 says if all dimensions are nulled
// when an initializer is given, no dimension must be specified
if (this.initializer == null) {
if (explicitdimindex < 0) {
scope.problemreporter().mustdefinedimensionsorinitializer(this);
}
// allow new list<?>[5] - only check for generic array when no initializer, since also checked inside initializer resolution
if (referencetype != null && !referencetype.isreifiable()) {
scope.problemreporter().illegalgenericarray(referencetype, this);
}
} else if (explicitdimindex >= 0) {
scope.problemreporter().cannotdefinedimensionsandinitializer(this);
}

// dimensions resolution
for (int i = 0; i <= explicitdimindex; i++) {
expression dimexpression;
if ((dimexpression = this.dimensions[i]) != null) {
typebinding dimensiontype = dimexpression.resolvetypeexpecting(scope, typebinding.int);
if (dimensiontype != null) {
this.dimensions[i].computeconversion(scope, typebinding.int, dimensiontype);
}
}
}

// building the array binding
if (referencetype != null) {
if (this.dimensions.length > 255) {
scope.problemreporter().toomanydimensions(this);
}
this.resolvedtype = scope.createarraytype(referencetype, this.dimensions.length);

// check the initializer
if (this.initializer != null) {
if ((this.initializer.resolvetypeexpecting(scope, this.resolvedtype)) != null)
this.initializer.binding = (arraybinding)this.resolvedtype;
}
if ((referencetype.tagbits & tagbits.hasmissingtype) != 0) {
return null;
}
}
return this.resolvedtype;
}


public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
int dimensionslength = this.dimensions.length;
this.type.traverse(visitor, scope);
for (int i = 0; i < dimensionslength; i++) {
if (this.dimensions[i] != null)
this.dimensions[i].traverse(visitor, scope);
}
if (this.initializer != null)
this.initializer.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
