/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;

/**
* normal annotation node
*/
public class normalannotation extends annotation {

public membervaluepair[] membervaluepairs;

public normalannotation(typereference type, int sourcestart) {
this.type = type;
this.sourcestart = sourcestart;
this.sourceend = type.sourceend;
}

public elementvaluepair[] computeelementvaluepairs() {
int numberofpairs = this.membervaluepairs == null ? 0 : this.membervaluepairs.length;
if (numberofpairs == 0)
return binding.no_element_value_pairs;

elementvaluepair[] pairs = new elementvaluepair[numberofpairs];
for (int i = 0; i < numberofpairs; i++)
pairs[i] = this.membervaluepairs[i].compilerelementpair;
return pairs;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.annotation#membervaluepairs()
*/
public membervaluepair[] membervaluepairs() {
return this.membervaluepairs == null ? novaluepairs : this.membervaluepairs;
}
public stringbuffer printexpression(int indent, stringbuffer output) {
super.printexpression(indent, output);
output.append('(');
if (this.membervaluepairs != null) {
for (int i = 0, max = this.membervaluepairs.length; i < max; i++) {
if (i > 0) {
output.append(',');
}
this.membervaluepairs[i].print(indent, output);
}
}
output.append(')');
return output;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.type != null) {
this.type.traverse(visitor, scope);
}
if (this.membervaluepairs != null) {
int membervaluepairslength = this.membervaluepairs.length;
for (int i = 0; i < membervaluepairslength; i++)
this.membervaluepairs[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
