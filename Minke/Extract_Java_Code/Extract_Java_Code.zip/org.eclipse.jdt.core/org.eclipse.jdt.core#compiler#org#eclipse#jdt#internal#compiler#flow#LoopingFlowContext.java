/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.expression;
import org.eclipse.jdt.internal.compiler.ast.reference;
import org.eclipse.jdt.internal.compiler.codegen.branchlabel;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.lookup.variablebinding;

/**
* reflects the context of code analysis, keeping track of enclosing
*	try statements, exception handlers, etc...
*/
public class loopingflowcontext extends switchflowcontext {

public branchlabel continuelabel;
public unconditionalflowinfo initsoncontinue = flowinfo.dead_end;
private unconditionalflowinfo upstreamnullflowinfo;
private loopingflowcontext innerflowcontexts[] = null;
private unconditionalflowinfo innerflowinfos[] = null;
private int innerflowcontextscount = 0;
private labelflowcontext breaktargetcontexts[] = null;
private int breaktargetscount = 0;

reference finalassignments[];
variablebinding finalvariables[];
int assigncount = 0;

localvariablebinding[] nulllocals;
expression[] nullreferences;
int[] nullchecktypes;
int nullcount;

scope associatedscope;

public loopingflowcontext(
flowcontext parent,
flowinfo upstreamnullflowinfo,
astnode associatednode,
branchlabel breaklabel,
branchlabel continuelabel,
scope associatedscope) {
super(parent, associatednode, breaklabel);
this.tagbits |= flowcontext.preempt_null_diagnostic;
// children will defer to this, which may defer to its own parent
this.continuelabel = continuelabel;
this.associatedscope = associatedscope;
this.upstreamnullflowinfo = upstreamnullflowinfo.unconditionalcopy();
}

/**
* perform deferred checks relative to final variables duplicate initialization
* of lack of initialization.
* @@param scope the scope to which this context is associated
* @@param flowinfo the flow info against which checks must be performed
*/
public void complainondeferredfinalchecks(blockscope scope, flowinfo flowinfo) {
// complain on final assignments in loops
for (int i = 0; i < this.assigncount; i++) {
variablebinding variable = this.finalvariables[i];
if (variable == null) continue;
boolean complained = false; // remember if have complained on this final assignment
if (variable instanceof fieldbinding) {
if (flowinfo.ispotentiallyassigned((fieldbinding) variable)) {
complained = true;
scope.problemreporter().duplicateinitializationofblankfinalfield(
(fieldbinding) variable,
this.finalassignments[i]);
}
} else {
if (flowinfo.ispotentiallyassigned((localvariablebinding) variable)) {
complained = true;
scope.problemreporter().duplicateinitializationoffinallocal(
(localvariablebinding) variable,
this.finalassignments[i]);
}
}
// any reference reported at this level is removed from the parent context where it
// could also be reported again
if (complained) {
flowcontext context = this.parent;
while (context != null) {
context.removefinalassignmentifany(this.finalassignments[i]);
context = context.parent;
}
}
}
}

/**
* perform deferred checks relative to the null status of local variables.
* @@param scope the scope to which this context is associated
* @@param callerflowinfo the flow info against which checks must be performed
*/
public void complainondeferrednullchecks(blockscope scope, flowinfo callerflowinfo) {
for (int i = 0 ; i < this.innerflowcontextscount ; i++) {
this.upstreamnullflowinfo.
addpotentialnullinfofrom(
this.innerflowcontexts[i].upstreamnullflowinfo).
addpotentialnullinfofrom(this.innerflowinfos[i]);
}
this.innerflowcontextscount = 0;
unconditionalflowinfo flowinfo = this.upstreamnullflowinfo.
addpotentialnullinfofrom(callerflowinfo.unconditionalinitswithoutsideeffect());
if ((this.tagbits & flowcontext.defer_null_diagnostic) != 0) {
// check only immutable null checks on innermost looping context
for (int i = 0; i < this.nullcount; i++) {
localvariablebinding local = this.nulllocals[i];
expression expression = this.nullreferences[i];
// final local variable
switch (this.nullchecktypes[i]) {
case can_only_non_null | in_comparison_null:
case can_only_non_null | in_comparison_non_null:
if (flowinfo.isdefinitelynonnull(local)) {
this.nullreferences[i] = null;
if (this.nullchecktypes[i] == (can_only_non_null | in_comparison_non_null)) {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnonnull(local, expression);
}
} else {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenonnullcomparedtonull(local, expression);
}
}
continue;
}
break;
case can_only_null_non_null | in_comparison_null:
case can_only_null_non_null | in_comparison_non_null:
if (flowinfo.isdefinitelynonnull(local)) {
this.nullreferences[i] = null;
if (this.nullchecktypes[i] == (can_only_null_non_null | in_comparison_non_null)) {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnonnull(local, expression);
}
} else {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenonnullcomparedtonull(local, expression);
}
}
continue;
}
if (flowinfo.isdefinitelynull(local)) {
this.nullreferences[i] = null;
if (this.nullchecktypes[i] == (can_only_null_non_null | in_comparison_null)) {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnull(local, expression);
}
} else {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenullcomparedtononnull(local, expression);
}
}
continue;
}
break;
case can_only_null | in_comparison_null:
case can_only_null | in_comparison_non_null:
case can_only_null | in_assignment:
case can_only_null | in_instanceof:
if (flowinfo.isdefinitelynull(local)) {
this.nullreferences[i] = null;
switch(this.nullchecktypes[i] & context_mask) {
case flowcontext.in_comparison_null:
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, expression);
continue;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnull(local, expression);
}
continue;
case flowcontext.in_comparison_non_null:
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, expression);
continue;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenullcomparedtononnull(local, expression);
}
continue;
case flowcontext.in_assignment:
scope.problemreporter().localvariableredundantnullassignment(local, expression);
continue;
case flowcontext.in_instanceof:
scope.problemreporter().localvariablenullinstanceof(local, expression);
continue;
}
} else if (flowinfo.ispotentiallynull(local)) {
switch(this.nullchecktypes[i] & context_mask) {
case flowcontext.in_comparison_null:
this.nullreferences[i] = null;
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, expression);
continue;
}
break;
case flowcontext.in_comparison_non_null:
this.nullreferences[i] = null;
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, expression);
continue;
}
break;
}
}
break;
case may_null:
if (flowinfo.isdefinitelynull(local)) {
this.nullreferences[i] = null;
scope.problemreporter().localvariablenullreference(local, expression);
continue;
}
break;
default:
// never happens
}
this.parent.recordusingnullreference(scope, local, expression,
this.nullchecktypes[i], flowinfo);
}
}
else {
// check inconsistent null checks on outermost looping context
for (int i = 0; i < this.nullcount; i++) {
expression expression = this.nullreferences[i];
// final local variable
localvariablebinding local = this.nulllocals[i];
switch (this.nullchecktypes[i]) {
case can_only_null_non_null | in_comparison_null:
case can_only_null_non_null | in_comparison_non_null:
if (flowinfo.isdefinitelynonnull(local)) {
this.nullreferences[i] = null;
if (this.nullchecktypes[i] == (can_only_null_non_null | in_comparison_non_null)) {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnonnull(local, expression);
}
} else {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenonnullcomparedtonull(local, expression);
}
}
continue;
}
//$fall-through$
case can_only_null | in_comparison_null:
case can_only_null | in_comparison_non_null:
case can_only_null | in_assignment:
case can_only_null | in_instanceof:
if (flowinfo.isdefinitelynull(local)) {
this.nullreferences[i] = null;
switch(this.nullchecktypes[i] & context_mask) {
case flowcontext.in_comparison_null:
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, expression);
continue;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnull(local, expression);
}
continue;
case flowcontext.in_comparison_non_null:
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, expression);
continue;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenullcomparedtononnull(local, expression);
}
continue;
case flowcontext.in_assignment:
scope.problemreporter().localvariableredundantnullassignment(local, expression);
continue;
case flowcontext.in_instanceof:
scope.problemreporter().localvariablenullinstanceof(local, expression);
continue;
}
} else if (flowinfo.ispotentiallynull(local)) {
switch(this.nullchecktypes[i] & context_mask) {
case flowcontext.in_comparison_null:
this.nullreferences[i] = null;
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, expression);
continue;
}
break;
case flowcontext.in_comparison_non_null:
this.nullreferences[i] = null;
if (((this.nullchecktypes[i] & check_mask) == can_only_null) && (expression.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, expression);
continue;
}
break;
}
}
break;
case may_null:
if (flowinfo.isdefinitelynull(local)) {
this.nullreferences[i] = null;
scope.problemreporter().localvariablenullreference(local, expression);
continue;
}
if (flowinfo.ispotentiallynull(local)) {
this.nullreferences[i] = null;
scope.problemreporter().localvariablepotentialnullreference(local, expression);
continue;
}
break;
default:
// never happens
}
}
}
// propagate breaks
this.initsonbreak.addpotentialnullinfofrom(flowinfo);
for (int i = 0; i < this.breaktargetscount; i++) {
this.breaktargetcontexts[i].initsonbreak.addpotentialnullinfofrom(flowinfo);
}
}

public branchlabel continuelabel() {
return this.continuelabel;
}

public string individualtostring() {
stringbuffer buffer = new stringbuffer("looping flow context"); //$non-nls-1$
buffer.append("[initsonbreak - ").append(this.initsonbreak.tostring()).append(']'); //$non-nls-1$
buffer.append("[initsoncontinue - ").append(this.initsoncontinue.tostring()).append(']'); //$non-nls-1$
buffer.append("[finalassignments count - ").append(this.assigncount).append(']'); //$non-nls-1$
buffer.append("[nullreferences count - ").append(this.nullcount).append(']'); //$non-nls-1$
return buffer.tostring();
}

public boolean iscontinuable() {
return true;
}

public boolean iscontinuedto() {
return this.initsoncontinue != flowinfo.dead_end;
}

public void recordbreakto(flowcontext targetcontext) {
if (targetcontext instanceof labelflowcontext) {
int current;
if ((current = this.breaktargetscount++) == 0) {
this.breaktargetcontexts = new labelflowcontext[2];
} else if (current == this.breaktargetcontexts.length) {
system.arraycopy(this.breaktargetcontexts, 0, this.breaktargetcontexts = new labelflowcontext[current + 2], 0, current);
}
this.breaktargetcontexts[current] = (labelflowcontext) targetcontext;
}
}

public void recordcontinuefrom(flowcontext innerflowcontext, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0)	{
if ((this.initsoncontinue.tagbits & flowinfo.unreachable) == 0) {
this.initsoncontinue = this.initsoncontinue.
mergedwith(flowinfo.unconditionalinitswithoutsideeffect());
}
else {
this.initsoncontinue = flowinfo.unconditionalcopy();
}
flowcontext inner = innerflowcontext;
while (inner != this && !(inner instanceof loopingflowcontext)) {
inner = inner.parent;
}
if (inner == this) {
this.upstreamnullflowinfo.
addpotentialnullinfofrom(
flowinfo.unconditionalinitswithoutsideeffect());
}
else {
int length = 0;
if (this.innerflowcontexts == null) {
this.innerflowcontexts = new loopingflowcontext[5];
this.innerflowinfos = new unconditionalflowinfo[5];
}
else if (this.innerflowcontextscount ==
(length = this.innerflowcontexts.length) - 1) {
system.arraycopy(this.innerflowcontexts, 0,
(this.innerflowcontexts = new loopingflowcontext[length + 5]),
0, length);
system.arraycopy(this.innerflowinfos, 0,
(this.innerflowinfos= new unconditionalflowinfo[length + 5]),
0, length);
}
this.innerflowcontexts[this.innerflowcontextscount] = (loopingflowcontext) inner;
this.innerflowinfos[this.innerflowcontextscount++] =
flowinfo.unconditionalinitswithoutsideeffect();
}
}
}

protected boolean recordfinalassignment(
variablebinding binding,
reference finalassignment) {

// do not consider variables which are defined inside this loop
if (binding instanceof localvariablebinding) {
scope scope = ((localvariablebinding) binding).declaringscope;
while ((scope = scope.parent) != null) {
if (scope == this.associatedscope)
return false;
}
}
if (this.assigncount == 0) {
this.finalassignments = new reference[5];
this.finalvariables = new variablebinding[5];
} else {
if (this.assigncount == this.finalassignments.length)
system.arraycopy(
this.finalassignments,
0,
(this.finalassignments = new reference[this.assigncount * 2]),
0,
this.assigncount);
system.arraycopy(
this.finalvariables,
0,
(this.finalvariables = new variablebinding[this.assigncount * 2]),
0,
this.assigncount);
}
this.finalassignments[this.assigncount] = finalassignment;
this.finalvariables[this.assigncount++] = binding;
return true;
}

protected void recordnullreference(localvariablebinding local,
expression expression, int status) {
if (this.nullcount == 0) {
this.nulllocals = new localvariablebinding[5];
this.nullreferences = new expression[5];
this.nullchecktypes = new int[5];
}
else if (this.nullcount == this.nulllocals.length) {
system.arraycopy(this.nulllocals, 0,
this.nulllocals = new localvariablebinding[this.nullcount * 2], 0, this.nullcount);
system.arraycopy(this.nullreferences, 0,
this.nullreferences = new expression[this.nullcount * 2], 0, this.nullcount);
system.arraycopy(this.nullchecktypes, 0,
this.nullchecktypes = new int[this.nullcount * 2], 0, this.nullcount);
}
this.nulllocals[this.nullcount] = local;
this.nullreferences[this.nullcount] = expression;
this.nullchecktypes[this.nullcount++] = status;
}

public void recordusingnullreference(scope scope, localvariablebinding local,
expression reference, int checktype, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) != 0 ||
flowinfo.isdefinitelyunknown(local)) {
return;
}
switch (checktype) {
case can_only_null_non_null | in_comparison_null:
case can_only_null_non_null | in_comparison_non_null:
if (flowinfo.isdefinitelynonnull(local)) {
if (checktype == (can_only_null_non_null | in_comparison_non_null)) {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnonnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhenfalse().setreachmode(flowinfo.unreachable);
}
} else {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenonnullcomparedtonull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhentrue().setreachmode(flowinfo.unreachable);
}
}
} else if (flowinfo.isdefinitelynull(local)) {
if (checktype == (can_only_null_non_null | in_comparison_null)) {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhenfalse().setreachmode(flowinfo.unreachable);
}
} else {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenullcomparedtononnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhentrue().setreachmode(flowinfo.unreachable);
}
}
} else if (this.upstreamnullflowinfo.isdefinitelynonnull(local) && !flowinfo.ispotentiallynull(local)) {    // https://bugs.eclipse.org/bugs/show_bug.cgi?id=291418
flowinfo.markasdefinitelynonnull(local);
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
recordnullreference(local, reference, checktype);
}
} else if (! flowinfo.cannotbedefinitelynullornonnull(local)) {
if (flowinfo.ispotentiallynonnull(local)) {
recordnullreference(local, reference, can_only_non_null | checktype & context_mask);
} else {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
recordnullreference(local, reference, checktype);
}
}
}
return;
case can_only_null | in_comparison_null:
case can_only_null | in_comparison_non_null:
case can_only_null | in_assignment:
case can_only_null | in_instanceof:
if (flowinfo.ispotentiallynonnull(local)
|| flowinfo.ispotentiallyunknown(local)) {
return;
}
if (flowinfo.isdefinitelynull(local)) {
switch(checktype & context_mask) {
case flowcontext.in_comparison_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhenfalse().setreachmode(flowinfo.unreachable);
}
return;
case flowcontext.in_comparison_non_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenullcomparedtononnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhentrue().setreachmode(flowinfo.unreachable);
}
return;
case flowcontext.in_assignment:
scope.problemreporter().localvariableredundantnullassignment(local, reference);
return;
case flowcontext.in_instanceof:
scope.problemreporter().localvariablenullinstanceof(local, reference);
return;
}
} else if (flowinfo.ispotentiallynull(local)) {
switch(checktype & context_mask) {
case flowcontext.in_comparison_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, reference);
return;
}
break;
case flowcontext.in_comparison_non_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, reference);
return;
}
break;
}
}
// if the contention is inside assert statement, we want to avoid null warnings only in case of
// comparisons and not in case of assignment and instanceof
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0
|| (checktype & context_mask) == flowcontext.in_assignment
|| (checktype & context_mask) == flowcontext.in_instanceof) {
recordnullreference(local, reference, checktype);
}
return;
case may_null :
if (flowinfo.isdefinitelynonnull(local)) {
return;
}
if (flowinfo.isdefinitelynull(local)) {
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
if (flowinfo.ispotentiallynull(local)) {
scope.problemreporter().localvariablepotentialnullreference(local, reference);
return;
}
recordnullreference(local, reference, checktype);
return;
default:
// never happens
}
}

void removefinalassignmentifany(reference reference) {
for (int i = 0; i < this.assigncount; i++) {
if (this.finalassignments[i] == reference) {
this.finalassignments[i] = null;
this.finalvariables[i] = null;
return;
}
}
}
}
