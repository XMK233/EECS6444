/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.casestatement;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.ast.typereference;

public final class localtypebinding extends nestedtypebinding {
final static char[] localtypeprefix = { '$', 'l', 'o', 'c', 'a', 'l', '$' };

private inneremulationdependency[] dependents;
public arraybinding[] localarraybindings; // used to cache array bindings of various dimensions for this local type
public casestatement enclosingcase; // from 1.4 on, local types should not be accessed across switch case blocks (52221)
public int sourcestart; // used by computeuniquekey to uniquely identify this binding
public methodbinding enclosingmethod;

//	public referencebinding anonymousoriginalsupertype;

public localtypebinding(classscope scope, sourcetypebinding enclosingtype, casestatement switchcase, referencebinding anonymousoriginalsupertype) {
super(
new char[][] {charoperation.concat(localtypebinding.localtypeprefix, scope.referencecontext.name)},
scope,
enclosingtype);
typedeclaration typedeclaration = scope.referencecontext;
if ((typedeclaration.bits & astnode.isanonymoustype) != 0) {
this.tagbits |= tagbits.anonymoustypemask;
} else {
this.tagbits |= tagbits.localtypemask;
}
this.enclosingcase = switchcase;
this.sourcestart = typedeclaration.sourcestart;
methodscope methodscope = scope.enclosingmethodscope();
abstractmethoddeclaration methoddeclaration = methodscope.referencemethod();
if (methoddeclaration != null) {
this.enclosingmethod = methoddeclaration.binding;
}
}

/* record a dependency onto a source target type which may be altered
* by the end of the innerclass emulation. later on, we will revisit
* all its dependents so as to update them (see updateinneremulationdependents()).
*/
public void addinneremulationdependent(blockscope dependentscope, boolean wasenclosinginstancesupplied) {
int index;
if (this.dependents == null) {
index = 0;
this.dependents = new inneremulationdependency[1];
} else {
index = this.dependents.length;
for (int i = 0; i < index; i++)
if (this.dependents[i].scope == dependentscope)
return; // already stored
system.arraycopy(this.dependents, 0, (this.dependents = new inneremulationdependency[index + 1]), 0, index);
}
this.dependents[index] = new inneremulationdependency(dependentscope, wasenclosinginstancesupplied);
//  system.out.println("adding dependency: "+ new string(scope.enclosingtype().readablename()) + " --> " + new string(this.readablename()));
}

/*
* returns the anonymous original super type (in some error cases, superclass may get substituted with object)
*/
public referencebinding anonymousoriginalsupertype() {
if (this.superinterfaces != binding.no_superinterfaces) {
return this.superinterfaces[0];
}
if ((this.tagbits & tagbits.hierarchyhasproblems) == 0) {
return this.superclass;
}
if (this.scope != null) {
typereference typereference = this.scope.referencecontext.allocation.type;
if (typereference != null) {
return (referencebinding) typereference.resolvedtype;
}
}
return this.superclass; // default answer
}

public char[] computeuniquekey(boolean isleaf) {
char[] outerkey = outermostenclosingtype().computeuniquekey(isleaf);
int semicolon = charoperation.lastindexof(';', outerkey);

stringbuffer sig = new stringbuffer();
sig.append(outerkey, 0, semicolon);

// insert $sourcestart
sig.append('$');
sig.append(string.valueof(this.sourcestart));

// insert $localname if local
if (!isanonymoustype()) {
sig.append('$');
sig.append(this.sourcename);
}

// insert remaining from outer key
sig.append(outerkey, semicolon, outerkey.length-semicolon);

int siglength = sig.length();
char[] uniquekey = new char[siglength];
sig.getchars(0, siglength, uniquekey, 0);
return uniquekey;
}

public char[] constantpoolname() /* java/lang/object */ {
return this.constantpoolname;
}

arraybinding createarraytype(int dimensioncount, lookupenvironment lookupenvironment) {
if (this.localarraybindings == null) {
this.localarraybindings = new arraybinding[] {new arraybinding(this, dimensioncount, lookupenvironment)};
return this.localarraybindings[0];
}
// find the cached array binding for this dimensioncount (if any)
int length = this.localarraybindings.length;
for (int i = 0; i < length; i++)
if (this.localarraybindings[i].dimensions == dimensioncount)
return this.localarraybindings[i];

// no matching array
system.arraycopy(this.localarraybindings, 0, this.localarraybindings = new arraybinding[length + 1], 0, length);
return this.localarraybindings[length] = new arraybinding(this, dimensioncount, lookupenvironment);
}

/*
* overriden for code assist. in this case, the constantpoolname() has not been computed yet.
* slam the source name so that the signature is syntactically correct.
* (see https://bugs.eclipse.org/bugs/show_bug.cgi?id=99686)
*/
public char[] generictypesignature() {
if (this.genericreferencetypesignature == null && constantpoolname() == null) {
if (isanonymoustype())
setconstantpoolname(superclass().sourcename());
else
setconstantpoolname(sourcename());
}
return super.generictypesignature();
}

public char[] readablename() /*java.lang.object,  p.x<t> */ {
char[] readablename;
if (isanonymoustype()) {
readablename = charoperation.concat(typeconstants.anonym_prefix, anonymousoriginalsupertype().readablename(), typeconstants.anonym_suffix);
} else if (ismembertype()) {
readablename = charoperation.concat(enclosingtype().readablename(), this.sourcename, '.');
} else {
readablename = this.sourcename;
}
typevariablebinding[] typevars;
if ((typevars = typevariables()) != binding.no_type_variables) {
stringbuffer namebuffer = new stringbuffer(10);
namebuffer.append(readablename).append('<');
for (int i = 0, length = typevars.length; i < length; i++) {
if (i > 0) namebuffer.append(',');
namebuffer.append(typevars[i].readablename());
}
namebuffer.append('>');
int namelength = namebuffer.length();
readablename = new char[namelength];
namebuffer.getchars(0, namelength, readablename, 0);
}
return readablename;
}

public char[] shortreadablename() /*object*/ {
char[] shortreadablename;
if (isanonymoustype()) {
shortreadablename = charoperation.concat(typeconstants.anonym_prefix, anonymousoriginalsupertype().shortreadablename(), typeconstants.anonym_suffix);
} else if (ismembertype()) {
shortreadablename = charoperation.concat(enclosingtype().shortreadablename(), this.sourcename, '.');
} else {
shortreadablename = this.sourcename;
}
typevariablebinding[] typevars;
if ((typevars = typevariables()) != binding.no_type_variables) {
stringbuffer namebuffer = new stringbuffer(10);
namebuffer.append(shortreadablename).append('<');
for (int i = 0, length = typevars.length; i < length; i++) {
if (i > 0) namebuffer.append(',');
namebuffer.append(typevars[i].shortreadablename());
}
namebuffer.append('>');
int namelength = namebuffer.length();
shortreadablename = new char[namelength];
namebuffer.getchars(0, namelength, shortreadablename, 0);
}
return shortreadablename;
}

// record that the type is a local member type
public void setasmembertype() {
this.tagbits |= tagbits.membertypemask;
}

public void setconstantpoolname(char[] computedconstantpoolname) /* java/lang/object */ {
this.constantpoolname = computedconstantpoolname;
}

/*
* overriden for code assist. in this case, the constantpoolname() has not been computed yet.
* slam the source name so that the signature is syntactically correct.
* (see https://bugs.eclipse.org/bugs/show_bug.cgi?id=102284)
*/
public char[] signature() {
if (this.signature == null && constantpoolname() == null) {
if (isanonymoustype())
setconstantpoolname(superclass().sourcename());
else
setconstantpoolname(sourcename());
}
return super.signature();
}

public char[] sourcename() {
if (isanonymoustype()) {
return charoperation.concat(typeconstants.anonym_prefix, anonymousoriginalsupertype().sourcename(), typeconstants.anonym_suffix);
} else
return this.sourcename;
}

public string tostring() {
if (isanonymoustype())
return "anonymous type : " + super.tostring(); //$non-nls-1$
if (ismembertype())
return "local member type : " + new string(sourcename()) + " " + super.tostring(); //$non-nls-2$ //$non-nls-1$
return "local type : " + new string(sourcename()) + " " + super.tostring(); //$non-nls-2$ //$non-nls-1$
}

/* trigger the dependency mechanism forcing the innerclass emulation
* to be propagated to all dependent source types.
*/
public void updateinneremulationdependents() {
if (this.dependents != null) {
for (int i = 0; i < this.dependents.length; i++) {
inneremulationdependency dependency = this.dependents[i];
// system.out.println("updating " + new string(this.readablename()) + " --> " + new string(dependency.scope.enclosingtype().readablename()));
dependency.scope.propagateinneremulation(this, dependency.wasenclosinginstancesupplied);
}
}
}
}
