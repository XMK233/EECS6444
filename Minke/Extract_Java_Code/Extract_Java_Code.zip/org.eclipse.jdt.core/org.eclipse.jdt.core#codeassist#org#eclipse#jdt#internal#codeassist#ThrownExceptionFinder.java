/*******************************************************************************
* copyright (c) 2007, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import java.util.stack;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.ast.allocationexpression;
import org.eclipse.jdt.internal.compiler.ast.argument;
import org.eclipse.jdt.internal.compiler.ast.block;
import org.eclipse.jdt.internal.compiler.ast.messagesend;
import org.eclipse.jdt.internal.compiler.ast.throwstatement;
import org.eclipse.jdt.internal.compiler.ast.trystatement;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.compilationunitscope;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.util.simpleset;

public class thrownexceptionfinder extends astvisitor {

private simpleset thrownexceptions;
private stack exceptionsstack;

public referencebinding[] find(trystatement trystatement, blockscope scope) {
this.thrownexceptions = new simpleset();
this.exceptionsstack = new stack();
trystatement.traverse(this, scope);
removecaughtexceptions(trystatement);

referencebinding[] result = new referencebinding[this.thrownexceptions.elementsize];
this.thrownexceptions.asarray(result);
return result;
}

private void acceptexception(referencebinding binding) {
if (binding != null && binding.isvalidbinding()) {
this.thrownexceptions.add(binding);
}
}

public void endvisit(messagesend messagesend, blockscope scope) {
if (messagesend.binding != null) {
endvisitmethodinvocation(messagesend.binding);
}
super.endvisit(messagesend, scope);
}

public void endvisit(allocationexpression allocationexpression, blockscope scope) {
if (allocationexpression.binding != null) {
endvisitmethodinvocation(allocationexpression.binding);
}
super.endvisit(allocationexpression, scope);
}

public void endvisit(throwstatement throwstatement, blockscope scope) {
acceptexception((referencebinding)throwstatement.exception.resolvedtype);
super.endvisit(throwstatement, scope);
}


private void endvisitmethodinvocation(methodbinding methodbinding) {
referencebinding[] thrownexceptionbindings = methodbinding.thrownexceptions;
int length = thrownexceptionbindings == null ? 0 : thrownexceptionbindings.length;
for (int i = 0; i < length; i++) {
acceptexception(thrownexceptionbindings[i]);
}
}

public boolean visit(typedeclaration typedeclaration, compilationunitscope scope) {
return visittype(typedeclaration);
}

public boolean visit(typedeclaration membertypedeclaration, classscope scope) {
return visittype(membertypedeclaration);
}

public boolean visit(typedeclaration localtypedeclaration, blockscope scope) {
return visittype(localtypedeclaration);
}

private boolean visittype(typedeclaration typedeclaration) {
return false;
}

public boolean visit(trystatement trystatement, blockscope scope) {
this.exceptionsstack.push(this.thrownexceptions);
simpleset exceptionset = new simpleset();
this.thrownexceptions = exceptionset;
trystatement.tryblock.traverse(this, scope);

removecaughtexceptions(trystatement);

this.thrownexceptions = (simpleset)this.exceptionsstack.pop();

object[] values = exceptionset.values;
for (int i = 0; i < values.length; i++) {
if (values[i] != null) {
this.thrownexceptions.add(values[i]);
}
}

block[] catchblocks = trystatement.catchblocks;
int length = catchblocks == null ? 0 : catchblocks.length;
for (int i = 0; i < length; i++) {
catchblocks[i].traverse(this, scope);
}
return false;
}

private void removecaughtexceptions(trystatement trystatement) {
argument[] catcharguments = trystatement.catcharguments;
int length = catcharguments == null ? 0 : catcharguments.length;
for (int i = 0; i < length; i++) {
typebinding exception = catcharguments[i].type.resolvedtype;
if (exception != null && exception.isvalidbinding()) {
removecaughtexception((referencebinding)exception);

}
}
}

private void removecaughtexception(referencebinding caughtexception) {
object[] exceptions = this.thrownexceptions.values;
for (int i = 0; i < exceptions.length; i++) {
referencebinding exception = (referencebinding)exceptions[i];
if (exception != null) {
if (exception == caughtexception || caughtexception.issuperclassof(exception)) {
this.thrownexceptions.remove(exception);
}
}
}
}
}
