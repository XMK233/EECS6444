/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

/*
* selection node build by the parser in any case it was intending to
* reduce an allocation expression containing the cursor.
* if the allocation expression is not qualified, the enclosinginstance field
* is null.
* e.g.
*
*	class x {
*    void foo() {
*      new [start]bar[end](1, 2)
*    }
*  }
*
*	---> class x {
*         void foo() {
*           <selectonallocationexpression:new bar(1, 2)>
*         }
*       }
*
*/

import org.eclipse.jdt.internal.compiler.ast.constructordeclaration;
import org.eclipse.jdt.internal.compiler.ast.qualifiedallocationexpression;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.localtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class selectiononqualifiedallocationexpression extends qualifiedallocationexpression {

public selectiononqualifiedallocationexpression() {
// constructor without argument
}

public selectiononqualifiedallocationexpression(typedeclaration anonymous) {
super(anonymous);
}

public stringbuffer printexpression(int indent, stringbuffer output) {
if (this.enclosinginstance == null)
output.append("<selectonallocationexpression:");  //$non-nls-1$
else
output.append("<selectonqualifiedallocationexpression:"); //$non-nls-1$

return super.printexpression(indent, output).append('>');
}

public typebinding resolvetype(blockscope scope) {
super.resolvetype(scope);

if (this.binding == null) {
throw new selectionnodefound();
}

// tolerate some error cases
if (!this.binding.isvalidbinding()) {
switch (this.binding.problemid()) {
case problemreasons.notvisible:
// visibility is ignored
break;
case problemreasons.notfound:
if (this.resolvedtype != null && this.resolvedtype.isvalidbinding()) {
throw new selectionnodefound(this.resolvedtype);
}
throw new selectionnodefound();
default:
throw new selectionnodefound();
}
}

if (this.anonymoustype == null)
throw new selectionnodefound(this.binding);

// if selecting a type for an anonymous type creation, we have to
// find its target super constructor (if extending a class) or its target
// super interface (if extending an interface)
if (this.anonymoustype.binding != null) {
localtypebinding localtype = (localtypebinding) this.anonymoustype.binding;
if (localtype.superinterfaces == binding.no_superinterfaces) {
// find the constructor binding inside the super constructor call
constructordeclaration constructor = (constructordeclaration) this.anonymoustype.declarationof(this.binding.original());
if (constructor != null) {
throw new selectionnodefound(constructor.constructorcall.binding);
}
throw new selectionnodefound(this.binding);
}
// open on the only super interface
throw new selectionnodefound(localtype.superinterfaces[0]);
} else {
if (this.resolvedtype.isinterface()) {
throw new selectionnodefound(this.resolvedtype);
}
throw new selectionnodefound(this.binding);
}
}
}
