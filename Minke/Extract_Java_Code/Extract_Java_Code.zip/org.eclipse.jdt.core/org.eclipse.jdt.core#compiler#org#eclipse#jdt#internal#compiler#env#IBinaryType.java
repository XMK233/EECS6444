/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

import org.eclipse.jdt.core.compiler.charoperation;

public interface ibinarytype extends igenerictype {

char[][] nointerface = charoperation.no_char_char;
ibinarynestedtype[] nonestedtype = new ibinarynestedtype[0];
ibinaryfield[] nofield = new ibinaryfield[0];
ibinarymethod[] nomethod = new ibinarymethod[0];
/**
* answer the runtime visible and invisible annotations for this type or null if none.
*/

ibinaryannotation[] getannotations();
/**
* answer the enclosing method (including method selector and method descriptor), or
* null if none.
*
* for example, "foo()ljava/lang/object;v"
*/

char[] getenclosingmethod();
/**
* answer the resolved name of the enclosing type in the
* class file format as specified in section 4.2 of the java 2 vm spec
* or null if the receiver is a top level type.
*
* for example, java.lang.string is java/lang/string.
*/

char[] getenclosingtypename();
/**
* answer the receiver's fields or null if the array is empty.
*/

ibinaryfield[] getfields();
/**
* answer the receiver's signature which describes the parameter &
* return types as specified in section 4.4.4 of the java 2 vm spec 3rd edition.
* returns null if none.
*
* @@return the receiver's signature, null if none
*/
char[] getgenericsignature();
/**
* answer the resolved names of the receiver's interfaces in the
* class file format as specified in section 4.2 of the java 2 vm spec
* or null if the array is empty.
*
* for example, java.lang.string is java/lang/string.
*/

char[][] getinterfacenames();
/**
* answer the receiver's nested types or null if the array is empty.
*
* this nested type info is extracted from the inner class attributes.
* ask the name environment to find a member type using its compound name.
*/

// note: the compiler examines the nested type info & ignores the local types
// so the local types do not have to be included.

ibinarynestedtype[] getmembertypes();
/**
* answer the receiver's methods or null if the array is empty.
*/

ibinarymethod[] getmethods();

/**
* answer the list of missing type names which were referenced from
* the problem classfile. this list is encoded via an extra attribute.
*/
char[][][] getmissingtypenames();

/**
* answer the resolved name of the type in the
* class file format as specified in section 4.2 of the java 2 vm spec.
*
* for example, java.lang.string is java/lang/string.
*/
char[] getname();

/**
* answer the simple name of the type in the class file.
* for member a$b, will answer b.
* for anonymous will answer null.
*/
char[] getsourcename();

/**
* answer the resolved name of the receiver's superclass in the
* class file format as specified in section 4.2 of the java 2 vm spec
* or null if it does not have one.
*
* for example, java.lang.string is java/lang/string.
*/

char[] getsuperclassname();
/**
* answer the tagbits set according to the bits for annotations.
*/
long gettagbits();
/**
* answer true if the receiver is an anonymous class.
* false otherwise
*/
boolean isanonymous();

/**
* answer true if the receiver is a local class.
* false otherwise
*/
boolean islocal();

/**
* answer true if the receiver is a member class.
* false otherwise
*/
boolean ismember();

/**
* answer the source file attribute, or null if none.
*
* for example, "string.java"
*/

char[] sourcefilename();

}
