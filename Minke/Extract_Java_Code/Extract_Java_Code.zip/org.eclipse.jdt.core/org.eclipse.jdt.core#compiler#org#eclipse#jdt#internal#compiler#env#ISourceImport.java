/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

public interface isourceimport {

/**
* answer the source end position of the import declaration.
*/

int getdeclarationsourceend();
/**
* answer the source start position of the import declaration.
*/

int getdeclarationsourcestart();

/**
* answer an int whose bits are set according the access constants
* defined by the vm spec.
* since java 1.5, static imports can be defined.
*/
int getmodifiers();
}
