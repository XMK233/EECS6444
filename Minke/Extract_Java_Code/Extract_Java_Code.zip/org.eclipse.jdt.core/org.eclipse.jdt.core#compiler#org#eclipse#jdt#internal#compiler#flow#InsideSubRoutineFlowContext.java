/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.subroutinestatement;

/**
* reflects the context of code analysis, keeping track of enclosing
*	try statements, exception handlers, etc...
*/
public class insidesubroutineflowcontext extends flowcontext {

public unconditionalflowinfo initsonreturn;

public insidesubroutineflowcontext(
flowcontext parent,
astnode associatednode) {
super(parent, associatednode);
this.initsonreturn = flowinfo.dead_end;
}

public string individualtostring() {
stringbuffer buffer = new stringbuffer("inside subroutine flow context"); //$non-nls-1$
buffer.append("[initsonreturn -").append(this.initsonreturn.tostring()).append(']'); //$non-nls-1$
return buffer.tostring();
}

public unconditionalflowinfo initsonreturn(){
return this.initsonreturn;
}

public boolean isnonreturningcontext() {
return ((subroutinestatement) this.associatednode).issubroutineescaping();
}

public void recordreturnfrom(unconditionalflowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0)	{
if (this.initsonreturn == flowinfo.dead_end) {
this.initsonreturn = (unconditionalflowinfo) flowinfo.copy();
} else {
this.initsonreturn = this.initsonreturn.mergedwith(flowinfo);
}
}
}

public subroutinestatement subroutine() {
return (subroutinestatement) this.associatednode;
}
}
