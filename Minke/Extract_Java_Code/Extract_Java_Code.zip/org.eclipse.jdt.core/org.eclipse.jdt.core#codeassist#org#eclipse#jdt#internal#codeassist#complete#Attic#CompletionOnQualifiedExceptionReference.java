/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce an exception type reference containing the completion identifier
* as part of a qualified name.
* e.g.
*
*	class x {
*    void foo() {
*      try {
*        bar();
*      } catch (java.io.ioexc[cursor] e) {
*      }
*    }
*  }
*
*	---> class x {
*         void foo() {
*           try {
*             bar();
*           } catch (<completeonexception:java.io.ioexc> e) {
*           }
*         }
*       }
*
* the source range of the completion node denotes the source range
* which should be replaced by the completion.
*/
public class completiononqualifiedexceptionreference extends completiononqualifiedtypereference {
public completiononqualifiedexceptionreference(char[][] previousidentifiers, char[] completionidentifier, long[] positions) {
super(previousidentifiers, completionidentifier, positions);
}
public stringbuffer printexpression(int indent, stringbuffer output) {

output.append("<completeonexception:"); //$non-nls-1$
for (int i = 0; i < tokens.length; i++) {
output.append(tokens[i]);
output.append('.');
}
output.append(completionidentifier).append('>');
return output;
}
}
