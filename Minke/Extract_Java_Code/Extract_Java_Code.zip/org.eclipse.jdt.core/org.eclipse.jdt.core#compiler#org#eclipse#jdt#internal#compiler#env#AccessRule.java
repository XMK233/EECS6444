/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.iproblem;

public class accessrule {

public static final int ignoreifbetter = 0x02000000; // value must be greater than iproblem#forbiddenreference and discouragedreference

public char[] pattern;
public int problemid;

public accessrule(char[] pattern, int problemid) {
this(pattern, problemid, false);
}

public accessrule(char[] pattern, int problemid, boolean keeplooking) {
this.pattern = pattern;
this.problemid = keeplooking ? problemid | ignoreifbetter : problemid;
}

public int hashcode() {
return this.problemid * 17 + charoperation.hashcode(this.pattern);
}

public boolean equals(object obj) {
if (!(obj instanceof accessrule)) return false;
accessrule other = (accessrule) obj;
if (this.problemid != other.problemid) return false;
return charoperation.equals(this.pattern, other.pattern);
}

public int getproblemid() {
return this.problemid & ~ignoreifbetter;
}

public boolean ignoreifbetter() {
return (this.problemid & ignoreifbetter) != 0;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append("pattern="); //$non-nls-1$
buffer.append(this.pattern);
switch (getproblemid()) {
case iproblem.forbiddenreference:
buffer.append(" (non accessible"); //$non-nls-1$
break;
case iproblem.discouragedreference:
buffer.append(" (discouraged"); //$non-nls-1$
break;
default:
buffer.append(" (accessible"); //$non-nls-1$
break;
}
if (ignoreifbetter())
buffer.append(" | ignore if better"); //$non-nls-1$
buffer.append(')');
return buffer.tostring();
}
}
