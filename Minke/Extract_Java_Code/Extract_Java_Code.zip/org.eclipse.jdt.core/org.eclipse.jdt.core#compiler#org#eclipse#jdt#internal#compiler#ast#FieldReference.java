/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.codegen.opcodes;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.invocationsite;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.missingtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.problemfieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.problemreferencebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;

public class fieldreference extends reference implements invocationsite {

public static final int read = 0;
public static final int write = 1;
public expression receiver;
public char[] token;
public fieldbinding binding;															// exact binding resulting from lookup
public methodbinding[] syntheticaccessors; // [0]=read accessor [1]=write accessor

public long namesourceposition; //(start<<32)+end
public typebinding actualreceivertype;
public typebinding genericcast;

public fieldreference(char[] source, long pos) {
this.token = source;
this.namesourceposition = pos;
//by default the position are the one of the field (not true for super access)
this.sourcestart = (int) (pos >>> 32);
this.sourceend = (int) (pos & 0x00000000ffffffffl);
this.bits |= binding.field;

}

public flowinfo analyseassignment(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo, assignment assignment, boolean iscompound) {
// compound assignment extra work
if (iscompound) { // check the variable part is initialized if blank final
if (this.binding.isblankfinal()
&& this.receiver.isthis()
&& currentscope.needblankfinalfieldinitializationcheck(this.binding)) {
flowinfo fieldinits = flowcontext.getinitsforfinalblankinitializationcheck(this.binding.declaringclass.original(), flowinfo);
if (!fieldinits.isdefinitelyassigned(this.binding)) {
currentscope.problemreporter().uninitializedblankfinalfield(this.binding, this);
// we could improve error msg here telling "cannot use compound assignment on final blank field"
}
}
managesyntheticaccessifnecessary(currentscope, flowinfo, true /*read-access*/);
}
flowinfo =
this.receiver
.analysecode(currentscope, flowcontext, flowinfo, !this.binding.isstatic())
.unconditionalinits();
if (assignment.expression != null) {
flowinfo =
assignment
.expression
.analysecode(currentscope, flowcontext, flowinfo)
.unconditionalinits();
}
managesyntheticaccessifnecessary(currentscope, flowinfo, false /*write-access*/);

// check if assigning a final field
if (this.binding.isfinal()) {
// in a context where it can be assigned?
if (this.binding.isblankfinal()
&& !iscompound
&& this.receiver.isthis()
&& !(this.receiver instanceof qualifiedthisreference)
&& ((this.receiver.bits & astnode.parenthesizedmask) == 0) // (this).x is forbidden
&& currentscope.allowblankfinalfieldassignment(this.binding)) {
if (flowinfo.ispotentiallyassigned(this.binding)) {
currentscope.problemreporter().duplicateinitializationofblankfinalfield(
this.binding,
this);
} else {
flowcontext.recordsettingfinal(this.binding, this, flowinfo);
}
flowinfo.markasdefinitelyassigned(this.binding);
} else {
// assigning a final field outside an initializer or constructor or wrong reference
currentscope.problemreporter().cannotassigntofinalfield(this.binding, this);
}
}
return flowinfo;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
return analysecode(currentscope, flowcontext, flowinfo, true);
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo, boolean valuerequired) {
boolean nonstatic = !this.binding.isstatic();
this.receiver.analysecode(currentscope, flowcontext, flowinfo, nonstatic);
if (nonstatic) {
this.receiver.checknpe(currentscope, flowcontext, flowinfo);
}

if (valuerequired || currentscope.compileroptions().compliancelevel >= classfileconstants.jdk1_4) {
managesyntheticaccessifnecessary(currentscope, flowinfo, true /*read-access*/);
}
return flowinfo;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#computeconversion(org.eclipse.jdt.internal.compiler.lookup.scope, org.eclipse.jdt.internal.compiler.lookup.typebinding, org.eclipse.jdt.internal.compiler.lookup.typebinding)
*/
public void computeconversion(scope scope, typebinding runtimetimetype, typebinding compiletimetype) {
if (runtimetimetype == null || compiletimetype == null)
return;
// set the generic cast after the fact, once the type expectation is fully known (no need for strict cast)
if (this.binding != null && this.binding.isvalidbinding()) {
fieldbinding originalbinding = this.binding.original();
typebinding originaltype = originalbinding.type;
// extra cast needed if field type is type variable
if (originaltype.leafcomponenttype().istypevariable()) {
typebinding targettype = (!compiletimetype.isbasetype() && runtimetimetype.isbasetype())
? compiletimetype  // unboxing: checkcast before conversion
: runtimetimetype;
this.genericcast = originalbinding.type.genericcast(targettype);
if (this.genericcast instanceof referencebinding) {
referencebinding referencecast = (referencebinding) this.genericcast;
if (!referencecast.canbeseenby(scope)) {
scope.problemreporter().invalidtype(this,
new problemreferencebinding(
charoperation.spliton('.', referencecast.shortreadablename()),
referencecast,
problemreasons.notvisible));
}
}
}
}
super.computeconversion(scope, runtimetimetype, compiletimetype);
}

public fieldbinding fieldbinding() {
return this.binding;
}

public void generateassignment(blockscope currentscope, codestream codestream, assignment assignment, boolean valuerequired) {
int pc = codestream.position;
fieldbinding codegenbinding = this.binding.original();
this.receiver.generatecode(currentscope, codestream, !codegenbinding.isstatic());
codestream.recordpositionsfrom(pc, this.sourcestart);
assignment.expression.generatecode(currentscope, codestream, true);
fieldstore(currentscope, codestream, codegenbinding, this.syntheticaccessors == null ? null : this.syntheticaccessors[fieldreference.write], this.actualreceivertype, this.receiver.isimplicitthis(), valuerequired);
if (valuerequired) {
codestream.generateimplicitconversion(assignment.implicitconversion);
}
// no need for generic cast as value got dupped
}

/**
* field reference code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
if (this.constant != constant.notaconstant) {
if (valuerequired) {
codestream.generateconstant(this.constant, this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
fieldbinding codegenbinding = this.binding.original();
boolean isstatic = codegenbinding.isstatic();
boolean isthisreceiver = this.receiver instanceof thisreference;
constant fieldconstant = codegenbinding.constant();
if (fieldconstant != constant.notaconstant) {
if (!isthisreceiver) {
this.receiver.generatecode(currentscope, codestream, !isstatic);
if (!isstatic){
codestream.invokeobjectgetclass();
codestream.pop();
}
}
if (valuerequired) {
codestream.generateconstant(fieldconstant, this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
if (valuerequired
|| (!isthisreceiver && currentscope.compileroptions().compliancelevel >= classfileconstants.jdk1_4)
|| ((this.implicitconversion & typeids.unboxing) != 0)
|| (this.genericcast != null)) {
this.receiver.generatecode(currentscope, codestream, !isstatic);
if ((this.bits & needreceivergenericcast) != 0) {
codestream.checkcast(this.actualreceivertype);
}
pc = codestream.position;
if (codegenbinding.declaringclass == null) { // array length
codestream.arraylength();
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else {
// could occur if !valuerequired but compliance >= 1.4
codestream.pop();
}
} else {
if (this.syntheticaccessors == null || this.syntheticaccessors[fieldreference.read] == null) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenbinding, this.actualreceivertype, this.receiver.isimplicitthis());
if (isstatic) {
codestream.fieldaccess(opcodes.opc_getstatic, codegenbinding, constantpooldeclaringclass);
} else {
codestream.fieldaccess(opcodes.opc_getfield, codegenbinding, constantpooldeclaringclass);
}
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessors[fieldreference.read], null /* default declaringclass */);
}
// required cast must occur even if no value is required
if (this.genericcast != null) codestream.checkcast(this.genericcast);
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else {
boolean isunboxing = (this.implicitconversion & typeids.unboxing) != 0;
// conversion only generated if unboxing
if (isunboxing) codestream.generateimplicitconversion(this.implicitconversion);
switch (isunboxing ? postconversiontype(currentscope).id : codegenbinding.type.id) {
case t_long :
case t_double :
codestream.pop2();
break;
default :
codestream.pop();
}
}
}
} else {
if (isthisreceiver) {
if (isstatic){
// if no valuerequired, still need possible side-effects of <clinit> invocation, if field belongs to different class
if (this.binding.original().declaringclass != this.actualreceivertype.erasure()) {
methodbinding accessor = this.syntheticaccessors == null ? null : this.syntheticaccessors[fieldreference.read];
if (accessor == null) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenbinding, this.actualreceivertype, this.receiver.isimplicitthis());
codestream.fieldaccess(opcodes.opc_getstatic, codegenbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, accessor, null /* default declaringclass */);
}
switch (codegenbinding.type.id) {
case t_long :
case t_double :
codestream.pop2();
break;
default :
codestream.pop();
}
}
}
} else {
this.receiver.generatecode(currentscope, codestream, !isstatic);
if (!isstatic){
codestream.invokeobjectgetclass(); // perform null check
codestream.pop();
}
}
}
codestream.recordpositionsfrom(pc, this.sourceend);
}

public void generatecompoundassignment(blockscope currentscope, codestream codestream, expression expression, int operator, int assignmentimplicitconversion, boolean valuerequired) {
boolean isstatic;
fieldbinding codegenbinding = this.binding.original();
this.receiver.generatecode(currentscope, codestream, !(isstatic = codegenbinding.isstatic()));
if (isstatic) {
if (this.syntheticaccessors == null || this.syntheticaccessors[fieldreference.read] == null) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenbinding, this.actualreceivertype, this.receiver.isimplicitthis());
codestream.fieldaccess(opcodes.opc_getstatic, codegenbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessors[fieldreference.read], null /* default declaringclass */);
}
} else {
codestream.dup();
if (this.syntheticaccessors == null || this.syntheticaccessors[fieldreference.read] == null) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenbinding, this.actualreceivertype, this.receiver.isimplicitthis());
codestream.fieldaccess(opcodes.opc_getfield, codegenbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessors[fieldreference.read], null /* default declaringclass */);
}
}
int operationtypeid;
switch(operationtypeid = (this.implicitconversion & typeids.implicit_conversion_mask) >> 4) {
case t_javalangstring :
case t_javalangobject :
case t_undefined :
codestream.generatestringconcatenationappend(currentscope, null, expression);
break;
default :
if (this.genericcast != null)
codestream.checkcast(this.genericcast);
// promote the array reference to the suitable operation type
codestream.generateimplicitconversion(this.implicitconversion);
// generate the increment value (will by itself  be promoted to the operation value)
if (expression == intliteral.one) { // prefix operation
codestream.generateconstant(expression.constant, this.implicitconversion);
} else {
expression.generatecode(currentscope, codestream, true);
}
// perform the operation
codestream.sendoperator(operator, operationtypeid);
// cast the value back to the array reference type
codestream.generateimplicitconversion(assignmentimplicitconversion);
}
fieldstore(currentscope, codestream, codegenbinding, this.syntheticaccessors == null ? null : this.syntheticaccessors[fieldreference.write], this.actualreceivertype, this.receiver.isimplicitthis(), valuerequired);
// no need for generic cast as value got dupped
}

public void generatepostincrement(blockscope currentscope, codestream codestream, compoundassignment postincrement, boolean valuerequired) {
boolean isstatic;
fieldbinding codegenbinding = this.binding.original();
this.receiver.generatecode(currentscope, codestream, !(isstatic = codegenbinding.isstatic()));
if (isstatic) {
if (this.syntheticaccessors == null || this.syntheticaccessors[fieldreference.read] == null) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenbinding, this.actualreceivertype, this.receiver.isimplicitthis());
codestream.fieldaccess(opcodes.opc_getstatic, codegenbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessors[fieldreference.read], null /* default declaringclass */);
}
} else {
codestream.dup();
if (this.syntheticaccessors == null || this.syntheticaccessors[fieldreference.read] == null) {
typebinding constantpooldeclaringclass = codestream.getconstantpooldeclaringclass(currentscope, codegenbinding, this.actualreceivertype, this.receiver.isimplicitthis());
codestream.fieldaccess(opcodes.opc_getfield, codegenbinding, constantpooldeclaringclass);
} else {
codestream.invoke(opcodes.opc_invokestatic, this.syntheticaccessors[fieldreference.read], null /* default declaringclass */);
}
}
typebinding operandtype;
if (this.genericcast != null) {
codestream.checkcast(this.genericcast);
operandtype = this.genericcast;
} else {
operandtype = codegenbinding.type;
}
if (valuerequired) {
if (isstatic) {
switch (operandtype.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2();
break;
default :
codestream.dup();
break;
}
} else { // stack:  [owner][old field value]  ---> [old field value][owner][old field value]
switch (operandtype.id) {
case typeids.t_long :
case typeids.t_double :
codestream.dup2_x1();
break;
default :
codestream.dup_x1();
break;
}
}
}
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generateconstant(
postincrement.expression.constant,
this.implicitconversion);
codestream.sendoperator(postincrement.operator, this.implicitconversion & typeids.compile_type_mask);
codestream.generateimplicitconversion(
postincrement.preassignimplicitconversion);
fieldstore(currentscope, codestream, codegenbinding, this.syntheticaccessors == null ? null : this.syntheticaccessors[fieldreference.write], this.actualreceivertype, this.receiver.isimplicitthis(), false);
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#generictypearguments()
*/
public typebinding[] generictypearguments() {
return null;
}
public boolean issuperaccess() {
return this.receiver.issuper();
}

public boolean istypeaccess() {
return this.receiver != null && this.receiver.istypereference();
}

/*
* no need to emulate access to protected fields since not implicitly accessed
*/
public void managesyntheticaccessifnecessary(blockscope currentscope, flowinfo flowinfo, boolean isreadaccess) {
if ((flowinfo.tagbits & flowinfo.unreachable) != 0)	return;

// if field from parameterized type got found, use the original field at codegen time
fieldbinding codegenbinding = this.binding.original();
if (this.binding.isprivate()) {
if ((currentscope.enclosingsourcetype() != codegenbinding.declaringclass)
&& this.binding.constant() == constant.notaconstant) {
if (this.syntheticaccessors == null)
this.syntheticaccessors = new methodbinding[2];
this.syntheticaccessors[isreadaccess ? fieldreference.read : fieldreference.write] =
((sourcetypebinding) codegenbinding.declaringclass).addsyntheticmethod(codegenbinding, isreadaccess, false /* not super ref in remote type*/);
currentscope.problemreporter().needtoemulatefieldaccess(codegenbinding, this, isreadaccess);
return;
}
} else if (this.receiver instanceof qualifiedsuperreference) { // qualified super
// qualified super need emulation always
sourcetypebinding destinationtype = (sourcetypebinding) (((qualifiedsuperreference) this.receiver).currentcompatibletype);
if (this.syntheticaccessors == null)
this.syntheticaccessors = new methodbinding[2];
this.syntheticaccessors[isreadaccess ? fieldreference.read : fieldreference.write] = destinationtype.addsyntheticmethod(codegenbinding, isreadaccess, issuperaccess());
currentscope.problemreporter().needtoemulatefieldaccess(codegenbinding, this, isreadaccess);
return;

} else if (this.binding.isprotected()) {
sourcetypebinding enclosingsourcetype;
if (((this.bits & astnode.depthmask) != 0)
&& this.binding.declaringclass.getpackage()
!= (enclosingsourcetype = currentscope.enclosingsourcetype()).getpackage()) {

sourcetypebinding currentcompatibletype =
(sourcetypebinding) enclosingsourcetype.enclosingtypeat(
(this.bits & astnode.depthmask) >> astnode.depthshift);
if (this.syntheticaccessors == null)
this.syntheticaccessors = new methodbinding[2];
this.syntheticaccessors[isreadaccess ? fieldreference.read : fieldreference.write] = currentcompatibletype.addsyntheticmethod(codegenbinding, isreadaccess, issuperaccess());
currentscope.problemreporter().needtoemulatefieldaccess(codegenbinding, this, isreadaccess);
return;
}
}
}

public int nullstatus(flowinfo flowinfo) {
return flowinfo.unknown;
}

public constant optimizedbooleanconstant() {
switch (this.resolvedtype.id) {
case t_boolean :
case t_javalangboolean :
return this.constant != constant.notaconstant ? this.constant : this.binding.constant();
default :
return constant.notaconstant;
}
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#postconversiontype(scope)
*/
public typebinding postconversiontype(scope scope) {
typebinding convertedtype = this.resolvedtype;
if (this.genericcast != null)
convertedtype = this.genericcast;
int runtimetype = (this.implicitconversion & typeids.implicit_conversion_mask) >> 4;
switch (runtimetype) {
case t_boolean :
convertedtype = typebinding.boolean;
break;
case t_byte :
convertedtype = typebinding.byte;
break;
case t_short :
convertedtype = typebinding.short;
break;
case t_char :
convertedtype = typebinding.char;
break;
case t_int :
convertedtype = typebinding.int;
break;
case t_float :
convertedtype = typebinding.float;
break;
case t_long :
convertedtype = typebinding.long;
break;
case t_double :
convertedtype = typebinding.double;
break;
default :
}
if ((this.implicitconversion & typeids.boxing) != 0) {
convertedtype = scope.environment().computeboxingtype(convertedtype);
}
return convertedtype;
}

public stringbuffer printexpression(int indent, stringbuffer output) {
return this.receiver.printexpression(0, output).append('.').append(this.token);
}

public typebinding resolvetype(blockscope scope) {
// answer the signature type of the field.
// constants are propaged when the field is final
// and initialized with a (compile time) constant

//always ignore receiver cast, since may affect constant pool reference
boolean receivercast = false;
if (this.receiver instanceof castexpression) {
this.receiver.bits |= astnode.disableunnecessarycastcheck; // will check later on
receivercast = true;
}
this.actualreceivertype = this.receiver.resolvetype(scope);
if (this.actualreceivertype == null) {
this.constant = constant.notaconstant;
return null;
}
if (receivercast) {
// due to change of declaring class with receiver type, only identity cast should be notified
if (((castexpression)this.receiver).expression.resolvedtype == this.actualreceivertype) {
scope.problemreporter().unnecessarycast((castexpression)this.receiver);
}
}
// the case receivertype.isarraytype and token = 'length' is handled by the scope api
fieldbinding fieldbinding = this.binding = scope.getfield(this.actualreceivertype, this.token, this);
if (!fieldbinding.isvalidbinding()) {
this.constant = constant.notaconstant;
if (this.receiver.resolvedtype instanceof problemreferencebinding) {
// problem already got signaled on receiver, do not report secondary problem
return null;
}
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=245007 avoid secondary errors in case of
// missing super type for anonymous classes ...
referencebinding declaringclass = fieldbinding.declaringclass;
boolean avoidsecondary = declaringclass != null &&
declaringclass.isanonymoustype() &&
declaringclass.superclass() instanceof missingtypebinding;
if (!avoidsecondary) {
scope.problemreporter().invalidfield(this, this.actualreceivertype);
}
if (fieldbinding instanceof problemfieldbinding) {
problemfieldbinding problemfieldbinding = (problemfieldbinding) fieldbinding;
fieldbinding closestmatch = problemfieldbinding.closestmatch;
switch(problemfieldbinding.problemid()) {
case problemreasons.inheritednamehidesenclosingname :
case problemreasons.notvisible :
case problemreasons.nonstaticreferenceinconstructorinvocation :
case problemreasons.nonstaticreferenceinstaticcontext :
if (closestmatch != null) {
fieldbinding = closestmatch;
}
}
}
if (!fieldbinding.isvalidbinding()) {
return null;
}
}
// handle indirect inheritance thru variable secondary bound
// receiver may receive generic cast, as part of implicit conversion
typebinding oldreceivertype = this.actualreceivertype;
this.actualreceivertype = this.actualreceivertype.geterasurecompatibletype(fieldbinding.declaringclass);
this.receiver.computeconversion(scope, this.actualreceivertype, this.actualreceivertype);
if (this.actualreceivertype != oldreceivertype && this.receiver.postconversiontype(scope) != this.actualreceivertype) { // record need for explicit cast at codegen since receiver could not handle it
this.bits |= needreceivergenericcast;
}
if (isfieldusedeprecated(fieldbinding, scope, (this.bits & astnode.isstrictlyassigned) !=0)) {
scope.problemreporter().deprecatedfield(fieldbinding, this);
}
boolean isimplicitthisrcv = this.receiver.isimplicitthis();
this.constant = isimplicitthisrcv ? fieldbinding.constant() : constant.notaconstant;
if (fieldbinding.isstatic()) {
// static field accessed through receiver? legal but unoptimal (optional warning)
if (!(isimplicitthisrcv
|| (this.receiver instanceof namereference
&& (((namereference) this.receiver).bits & binding.type) != 0))) {
scope.problemreporter().nonstaticaccesstostaticfield(this, fieldbinding);
}
referencebinding declaringclass = this.binding.declaringclass;
if (!isimplicitthisrcv
&& declaringclass != this.actualreceivertype
&& declaringclass.canbeseenby(scope)) {
scope.problemreporter().indirectaccesstostaticfield(this, fieldbinding);
}
// check if accessing enum static field in initializer
if (declaringclass.isenum()) {
methodscope methodscope = scope.methodscope();
sourcetypebinding sourcetype = scope.enclosingsourcetype();
if (this.constant == constant.notaconstant
&& !methodscope.isstatic
&& (sourcetype == declaringclass || sourcetype.superclass == declaringclass) // enum constant body
&& methodscope.isinsideinitializerorconstructor()) {
scope.problemreporter().enumstaticfieldusedduringinitialization(this.binding, this);
}
}
}
typebinding fieldtype = fieldbinding.type;
if (fieldtype != null) {
if ((this.bits & astnode.isstrictlyassigned) == 0) {
fieldtype = fieldtype.capture(scope, this.sourceend);	// perform capture conversion if read access
}
this.resolvedtype = fieldtype;
if ((fieldtype.tagbits & tagbits.hasmissingtype) != 0) {
scope.problemreporter().invalidtype(this, fieldtype);
return null;
}
}
return fieldtype;
}

public void setactualreceivertype(referencebinding receivertype) {
this.actualreceivertype = receivertype;
}

public void setdepth(int depth) {
this.bits &= ~astnode.depthmask; // flush previous depth if any
if (depth > 0) {
this.bits |= (depth & 0xff) << astnode.depthshift; // encoded on 8 bits
}
}

public void setfieldindex(int index) {
// ignored
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
this.receiver.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
