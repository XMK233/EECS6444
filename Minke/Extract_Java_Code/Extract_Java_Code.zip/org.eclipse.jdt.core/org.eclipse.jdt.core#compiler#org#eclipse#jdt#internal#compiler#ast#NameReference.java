/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.lookup.*;

public abstract class namereference extends reference implements invocationsite {

public binding binding; //may be atypebinding-afieldbinding-alocalvariablebinding

public typebinding actualreceivertype;	// modified receiver type - actual one according to namelookup

//the error printing
//some name reference are build as name reference but
//only used as type reference. when it happens, instead of
//creating a new objet (atypereference) we just flag a boolean
//this concesion is valuable while their are cases when the namereference
//will be a typereference (static message sends.....) and there is
//no changeclass in java.
public namereference() {
this.bits |= binding.type | binding.variable; // restrictiveflag
}

public fieldbinding fieldbinding() {
//this method should be sent only after a check against isfieldreference()
//check its use doing senders.........
return (fieldbinding) this.binding ;
}

public boolean issuperaccess() {
return false;
}

public boolean istypeaccess() {
// null is acceptable when we are resolving the first part of a reference
return this.binding == null || this.binding instanceof referencebinding;
}

public boolean istypereference() {
return this.binding instanceof referencebinding;
}

public void setactualreceivertype(referencebinding receivertype) {
if (receivertype == null) return; // error scenario only
this.actualreceivertype = receivertype;
}

public void setdepth(int depth) {
this.bits &= ~depthmask; // flush previous depth if any
if (depth > 0) {
this.bits |= (depth & 0xff) << depthshift; // encoded on 8 bits
}
}

public void setfieldindex(int index){
// ignored
}

public abstract string unboundreferenceerrorname();
}
