/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.util.arraylist;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.env.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.problem.abortcompilation;
import org.eclipse.jdt.internal.compiler.util.simplelookuptable;

/*
not all fields defined by this type are initialized when it is created.
some are initialized only when needed.

accessors have been provided for some public fields so all typebindings have the same api...
but access public fields directly whenever possible.
non-public fields have accessors which should be used everywhere you expect the field to be initialized.

null is not a valid value for a non-public field... it just means the field is not initialized.
*/

public class binarytypebinding extends referencebinding {

// all of these fields are only guaranteed to be initialized if accessed using their public accessor method
protected referencebinding superclass;
protected referencebinding enclosingtype;
protected referencebinding[] superinterfaces;
protected fieldbinding[] fields;
protected methodbinding[] methods;
protected referencebinding[] membertypes;
protected typevariablebinding[] typevariables;

// for the link with the principle structure
protected lookupenvironment environment;

protected simplelookuptable storedannotations = null; // keys are this referencebinding & its fields and methods, value is an annotationholder

static object convertmembervalue(object binaryvalue, lookupenvironment env, char[][][] missingtypenames) {
if (binaryvalue == null) return null;
if (binaryvalue instanceof constant)
return binaryvalue;
if (binaryvalue instanceof classsignature)
return env.gettypefromsignature(((classsignature) binaryvalue).gettypename(), 0, -1, false, null, missingtypenames);
if (binaryvalue instanceof ibinaryannotation)
return createannotation((ibinaryannotation) binaryvalue, env, missingtypenames);
if (binaryvalue instanceof enumconstantsignature) {
enumconstantsignature ref = (enumconstantsignature) binaryvalue;
referencebinding enumtype = (referencebinding) env.gettypefromsignature(ref.gettypename(), 0, -1, false, null, missingtypenames);
enumtype = (referencebinding) resolvetype(enumtype, env, false /* no raw conversion */);
return enumtype.getfield(ref.getenumconstantname(), false);
}
if (binaryvalue instanceof object[]) {
object[] objects = (object[]) binaryvalue;
int length = objects.length;
if (length == 0) return objects;
object[] values = new object[length];
for (int i = 0; i < length; i++)
values[i] = convertmembervalue(objects[i], env, missingtypenames);
return values;
}

// should never reach here.
throw new illegalstateexception();
}

static annotationbinding createannotation(ibinaryannotation annotationinfo, lookupenvironment env, char[][][] missingtypenames) {
ibinaryelementvaluepair[] binarypairs = annotationinfo.getelementvaluepairs();
int length = binarypairs == null ? 0 : binarypairs.length;
elementvaluepair[] pairs = length == 0 ? binding.no_element_value_pairs : new elementvaluepair[length];
for (int i = 0; i < length; i++)
pairs[i] = new elementvaluepair(binarypairs[i].getname(), convertmembervalue(binarypairs[i].getvalue(), env, missingtypenames), null);

char[] typename = annotationinfo.gettypename();
referencebinding annotationtype = env.gettypefromconstantpoolname(typename, 1, typename.length - 1, false, missingtypenames);
return new unresolvedannotationbinding(annotationtype, pairs, env);
}

public static annotationbinding[] createannotations(ibinaryannotation[] annotationinfos, lookupenvironment env, char[][][] missingtypenames) {
int length = annotationinfos == null ? 0 : annotationinfos.length;
annotationbinding[] result = length == 0 ? binding.no_annotations : new annotationbinding[length];
for (int i = 0; i < length; i++)
result[i] = createannotation(annotationinfos[i], env, missingtypenames);
return result;
}

public static typebinding resolvetype(typebinding type, lookupenvironment environment, boolean convertgenerictorawtype) {
switch (type.kind()) {
case binding.parameterized_type :
((parameterizedtypebinding) type).resolve();
break;

case binding.wildcard_type :
case binding.intersection_type :
return ((wildcardbinding) type).resolve();

case binding.array_type :
resolvetype(((arraybinding) type).leafcomponenttype, environment, convertgenerictorawtype);
break;

case binding.type_parameter :
((typevariablebinding) type).resolve();
break;

case binding.generic_type :
if (convertgenerictorawtype) // raw reference to generic ?
return environment.convertunresolvedbinarytorawtype(type);
break;

default:
if (type instanceof unresolvedreferencebinding)
return ((unresolvedreferencebinding) type).resolve(environment, convertgenerictorawtype);
if (convertgenerictorawtype) // raw reference to generic ?
return environment.convertunresolvedbinarytorawtype(type);
break;
}
return type;
}

/**
* default empty constructor for subclasses only.
*/
protected binarytypebinding() {
// only for subclasses
}

/**
* standard constructor for creating binary type bindings from binary models (classfiles)
* @@param packagebinding
* @@param binarytype
* @@param environment
*/
public binarytypebinding(packagebinding packagebinding, ibinarytype binarytype, lookupenvironment environment) {
this.compoundname = charoperation.spliton('/', binarytype.getname());
computeid();

this.tagbits |= tagbits.isbinarybinding;
this.environment = environment;
this.fpackage = packagebinding;
this.filename = binarytype.getfilename();

char[] typesignature = environment.globaloptions.sourcelevel >= classfileconstants.jdk1_5 ? binarytype.getgenericsignature() : null;
this.typevariables = typesignature != null && typesignature.length > 0 && typesignature[0] == '<'
? null // is initialized in cachepartsfrom (called from lookupenvironment.createbinarytypefrom())... must set to null so isgenerictype() answers true
: binding.no_type_variables;

this.sourcename = binarytype.getsourcename();
this.modifiers = binarytype.getmodifiers();

if ((binarytype.gettagbits() & tagbits.hierarchyhasproblems) != 0)
this.tagbits |= tagbits.hierarchyhasproblems;

if (binarytype.isanonymous()) {
this.tagbits |= tagbits.anonymoustypemask;
} else if (binarytype.islocal()) {
this.tagbits |= tagbits.localtypemask;
} else if (binarytype.ismember()) {
this.tagbits |= tagbits.membertypemask;
}
// need enclosing type to access type variables
char[] enclosingtypename = binarytype.getenclosingtypename();
if (enclosingtypename != null) {
// attempt to find the enclosing type if it exists in the cache (otherwise - resolve it when requested)
this.enclosingtype = environment.gettypefromconstantpoolname(enclosingtypename, 0, -1, true, null /* could not be missing */); // pretend parameterized to avoid raw
this.tagbits |= tagbits.membertypemask;   // must be a member type not a top-level or local type
this.tagbits |= 	tagbits.hasunresolvedenclosingtype;
if (enclosingtype().isstrictfp())
this.modifiers |= classfileconstants.accstrictfp;
if (enclosingtype().isdeprecated())
this.modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
}
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#availablemethods()
*/
public fieldbinding[] availablefields() {
if ((this.tagbits & tagbits.arefieldscomplete) != 0)
return this.fields;

// lazily sort fields
if ((this.tagbits & tagbits.arefieldssorted) == 0) {
int length = this.fields.length;
if (length > 1)
referencebinding.sortfields(this.fields, 0, length);
this.tagbits |= tagbits.arefieldssorted;
}
fieldbinding[] availablefields = new fieldbinding[this.fields.length];
int count = 0;
for (int i = 0; i < this.fields.length; i++) {
try {
availablefields[count] = resolvetypefor(this.fields[i]);
count++;
} catch (abortcompilation a){
// silent abort
}
}
if (count < availablefields.length)
system.arraycopy(availablefields, 0, availablefields = new fieldbinding[count], 0, count);
return availablefields;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#availablemethods()
*/
public methodbinding[] availablemethods() {
if ((this.tagbits & tagbits.aremethodscomplete) != 0)
return this.methods;

// lazily sort methods
if ((this.tagbits & tagbits.aremethodssorted) == 0) {
int length = this.methods.length;
if (length > 1)
referencebinding.sortmethods(this.methods, 0, length);
this.tagbits |= tagbits.aremethodssorted;
}
methodbinding[] availablemethods = new methodbinding[this.methods.length];
int count = 0;
for (int i = 0; i < this.methods.length; i++) {
try {
availablemethods[count] = resolvetypesfor(this.methods[i]);
count++;
} catch (abortcompilation a){
// silent abort
}
}
if (count < availablemethods.length)
system.arraycopy(availablemethods, 0, availablemethods = new methodbinding[count], 0, count);
return availablemethods;
}

void cachepartsfrom(ibinarytype binarytype, boolean needfieldsandmethods) {
try {
// default initialization for super-interfaces early, in case some aborting compilation error occurs,
// and still want to use binaries passed that point (e.g. type hierarchy resolver, see bug 63748).
this.typevariables = binding.no_type_variables;
this.superinterfaces = binding.no_superinterfaces;

// must retrieve member types in case superclass/interfaces need them
this.membertypes = binding.no_member_types;
ibinarynestedtype[] membertypestructures = binarytype.getmembertypes();
if (membertypestructures != null) {
int size = membertypestructures.length;
if (size > 0) {
this.membertypes = new referencebinding[size];
for (int i = 0; i < size; i++)
// attempt to find each member type if it exists in the cache (otherwise - resolve it when requested)
this.membertypes[i] = this.environment.gettypefromconstantpoolname(membertypestructures[i].getname(), 0, -1, false, null /* could not be missing */);
this.tagbits |= 	tagbits.hasunresolvedmembertypes;
}
}

long sourcelevel = this.environment.globaloptions.sourcelevel;
char[] typesignature = null;
if (sourcelevel >= classfileconstants.jdk1_5) {
typesignature = binarytype.getgenericsignature();
this.tagbits |= binarytype.gettagbits();
}
char[][][] missingtypenames = binarytype.getmissingtypenames();
if (typesignature == null) {
char[] superclassname = binarytype.getsuperclassname();
if (superclassname != null) {
// attempt to find the superclass if it exists in the cache (otherwise - resolve it when requested)
this.superclass = this.environment.gettypefromconstantpoolname(superclassname, 0, -1, false, missingtypenames);
this.tagbits |= tagbits.hasunresolvedsuperclass;
}

this.superinterfaces = binding.no_superinterfaces;
char[][] interfacenames = binarytype.getinterfacenames();
if (interfacenames != null) {
int size = interfacenames.length;
if (size > 0) {
this.superinterfaces = new referencebinding[size];
for (int i = 0; i < size; i++)
// attempt to find each superinterface if it exists in the cache (otherwise - resolve it when requested)
this.superinterfaces[i] = this.environment.gettypefromconstantpoolname(interfacenames[i], 0, -1, false, missingtypenames);
this.tagbits |= tagbits.hasunresolvedsuperinterfaces;
}
}
} else {
// classsignature = parameterpart(optional) super_typesignature interface_signature
signaturewrapper wrapper = new signaturewrapper(typesignature);
if (wrapper.signature[wrapper.start] == '<') {
// parameterpart = '<' parametersignature(s) '>'
wrapper.start++; // skip '<'
this.typevariables = createtypevariables(wrapper, true, missingtypenames);
wrapper.start++; // skip '>'
this.tagbits |=  tagbits.hasunresolvedtypevariables;
this.modifiers |= extracompilermodifiers.accgenericsignature;
}
typevariablebinding[] typevars = binding.no_type_variables;
char[] methoddescriptor = binarytype.getenclosingmethod();
if (methoddescriptor != null) {
methodbinding enclosingmethod = findmethod(methoddescriptor, missingtypenames);
if (enclosingmethod != null) {
typevars = enclosingmethod.typevariables;
}
}

// attempt to find the superclass if it exists in the cache (otherwise - resolve it when requested)
this.superclass = (referencebinding) this.environment.gettypefromtypesignature(wrapper, typevars, this, missingtypenames);
this.tagbits |= tagbits.hasunresolvedsuperclass;

this.superinterfaces = binding.no_superinterfaces;
if (!wrapper.atend()) {
// attempt to find each superinterface if it exists in the cache (otherwise - resolve it when requested)
java.util.arraylist types = new java.util.arraylist(2);
do {
types.add(this.environment.gettypefromtypesignature(wrapper, typevars, this, missingtypenames));
} while (!wrapper.atend());
this.superinterfaces = new referencebinding[types.size()];
types.toarray(this.superinterfaces);
this.tagbits |= tagbits.hasunresolvedsuperinterfaces;
}
}

if (needfieldsandmethods) {
createfields(binarytype.getfields(), sourcelevel, missingtypenames);
createmethods(binarytype.getmethods(), sourcelevel, missingtypenames);
boolean isviewedasdeprecated = isviewedasdeprecated();
if (isviewedasdeprecated) {
for (int i = 0, max = this.fields.length; i < max; i++) {
fieldbinding field = this.fields[i];
if (!field.isdeprecated()) {
field.modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
}
}
for (int i = 0, max = this.methods.length; i < max; i++) {
methodbinding method = this.methods[i];
if (!method.isdeprecated()) {
method.modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
}
}
}
}
if (this.environment.globaloptions.storeannotations)
setannotations(createannotations(binarytype.getannotations(), this.environment, missingtypenames));
} finally {
// protect against incorrect use of the needfieldsandmethods flag, see 48459
if (this.fields == null)
this.fields = binding.no_fields;
if (this.methods == null)
this.methods = binding.no_methods;
}
}

private void createfields(ibinaryfield[] ifields, long sourcelevel, char[][][] missingtypenames) {
this.fields = binding.no_fields;
if (ifields != null) {
int size = ifields.length;
if (size > 0) {
this.fields = new fieldbinding[size];
boolean use15specifics = sourcelevel >= classfileconstants.jdk1_5;
boolean hasrestrictedaccess = hasrestrictedaccess();
int firstannotatedfieldindex = -1;
for (int i = 0; i < size; i++) {
ibinaryfield binaryfield = ifields[i];
char[] fieldsignature = use15specifics ? binaryfield.getgenericsignature() : null;
typebinding type = fieldsignature == null
? this.environment.gettypefromsignature(binaryfield.gettypename(), 0, -1, false, this, missingtypenames)
: this.environment.gettypefromtypesignature(new signaturewrapper(fieldsignature), binding.no_type_variables, this, missingtypenames);
fieldbinding field =
new fieldbinding(
binaryfield.getname(),
type,
binaryfield.getmodifiers() | extracompilermodifiers.accunresolved,
this,
binaryfield.getconstant());
if (firstannotatedfieldindex < 0
&& this.environment.globaloptions.storeannotations
&& binaryfield.getannotations() != null) {
firstannotatedfieldindex = i;
}
field.id = i; // ordinal
if (use15specifics)
field.tagbits |= binaryfield.gettagbits();
if (hasrestrictedaccess)
field.modifiers |= extracompilermodifiers.accrestrictedaccess;
if (fieldsignature != null)
field.modifiers |= extracompilermodifiers.accgenericsignature;
this.fields[i] = field;
}
// second pass for reifying annotations, since may refer to fields being constructed (147875)
if (firstannotatedfieldindex >= 0) {
for (int i = firstannotatedfieldindex; i <size; i++) {
ibinaryfield binaryfield = ifields[i];
this.fields[i].setannotations(createannotations(binaryfield.getannotations(), this.environment, missingtypenames));
}
}
}
}
}

private methodbinding createmethod(ibinarymethod method, long sourcelevel, char[][][] missingtypenames) {
int methodmodifiers = method.getmodifiers() | extracompilermodifiers.accunresolved;
if (sourcelevel < classfileconstants.jdk1_5)
methodmodifiers &= ~classfileconstants.accvarargs; // vararg methods are not recognized until 1.5
referencebinding[] exceptions = binding.no_exceptions;
typebinding[] parameters = binding.no_parameters;
typevariablebinding[] typevars = binding.no_type_variables;
annotationbinding[][] paramannotations = null;
typebinding returntype = null;

final boolean use15specifics = sourcelevel >= classfileconstants.jdk1_5;
char[] methodsignature = use15specifics ? method.getgenericsignature() : null;
if (methodsignature == null) { // no generics
char[] methoddescriptor = method.getmethoddescriptor();   // of the form (i[ljava/jang/string;)v
int numofparams = 0;
char nextchar;
int index = 0; // first character is always '(' so skip it
while ((nextchar = methoddescriptor[++index]) != ')') {
if (nextchar != '[') {
numofparams++;
if (nextchar == 'l')
while ((nextchar = methoddescriptor[++index]) != ';'){/*empty*/}
}
}

// ignore synthetic argument for member types or enum types.
int startindex = 0;
if (method.isconstructor()) {
if (ismembertype() && !isstatic()) {
// enclosing type
startindex++;
}
if (isenum()) {
// synthetic arguments (string, int)
startindex += 2;
}
}
int size = numofparams - startindex;
if (size > 0) {
parameters = new typebinding[size];
if (this.environment.globaloptions.storeannotations)
paramannotations = new annotationbinding[size][];
index = 1;
int end = 0;   // first character is always '(' so skip it
for (int i = 0; i < numofparams; i++) {
while ((nextchar = methoddescriptor[++end]) == '['){/*empty*/}
if (nextchar == 'l')
while ((nextchar = methoddescriptor[++end]) != ';'){/*empty*/}

if (i >= startindex) {   // skip the synthetic arg if necessary
parameters[i - startindex] = this.environment.gettypefromsignature(methoddescriptor, index, end, false, this, missingtypenames);
// 'paramannotations' line up with 'parameters'
// int parameter to method.getparameterannotations() include the synthetic arg
if (paramannotations != null)
paramannotations[i - startindex] = createannotations(method.getparameterannotations(i - startindex), this.environment, missingtypenames);
}
index = end + 1;
}
}

char[][] exceptiontypes = method.getexceptiontypenames();
if (exceptiontypes != null) {
size = exceptiontypes.length;
if (size > 0) {
exceptions = new referencebinding[size];
for (int i = 0; i < size; i++)
exceptions[i] = this.environment.gettypefromconstantpoolname(exceptiontypes[i], 0, -1, false, missingtypenames);
}
}

if (!method.isconstructor())
returntype = this.environment.gettypefromsignature(methoddescriptor, index + 1, -1, false, this, missingtypenames);   // index is currently pointing at the ')'
} else {
methodmodifiers |= extracompilermodifiers.accgenericsignature;
// methodtypesignature = parameterpart(optional) '(' typesignatures ')' return_typesignature ['^' typesignature (optional)]
signaturewrapper wrapper = new signaturewrapper(methodsignature);
if (wrapper.signature[wrapper.start] == '<') {
// <a::ljava/lang/annotation/annotation;>(ljava/lang/class<ta;>;)ta;
// parameterpart = '<' parametersignature(s) '>'
wrapper.start++; // skip '<'
typevars = createtypevariables(wrapper, false, missingtypenames);
wrapper.start++; // skip '>'
}

if (wrapper.signature[wrapper.start] == '(') {
wrapper.start++; // skip '('
if (wrapper.signature[wrapper.start] == ')') {
wrapper.start++; // skip ')'
} else {
java.util.arraylist types = new java.util.arraylist(2);
while (wrapper.signature[wrapper.start] != ')')
types.add(this.environment.gettypefromtypesignature(wrapper, typevars, this, missingtypenames));
wrapper.start++; // skip ')'
int numparam = types.size();
parameters = new typebinding[numparam];
types.toarray(parameters);
if (this.environment.globaloptions.storeannotations) {
paramannotations = new annotationbinding[numparam][];
for (int i = 0; i < numparam; i++)
paramannotations[i] = createannotations(method.getparameterannotations(i), this.environment, missingtypenames);
}
}
}

// always retrieve return type (for constructors, its v for void - will be ignored)
returntype = this.environment.gettypefromtypesignature(wrapper, typevars, this, missingtypenames);

if (!wrapper.atend() && wrapper.signature[wrapper.start] == '^') {
// attempt to find each exception if it exists in the cache (otherwise - resolve it when requested)
java.util.arraylist types = new java.util.arraylist(2);
do {
wrapper.start++; // skip '^'
types.add(this.environment.gettypefromtypesignature(wrapper, typevars, this, missingtypenames));
} while (!wrapper.atend() && wrapper.signature[wrapper.start] == '^');
exceptions = new referencebinding[types.size()];
types.toarray(exceptions);
} else { // get the exceptions the old way
char[][] exceptiontypes = method.getexceptiontypenames();
if (exceptiontypes != null) {
int size = exceptiontypes.length;
if (size > 0) {
exceptions = new referencebinding[size];
for (int i = 0; i < size; i++)
exceptions[i] = this.environment.gettypefromconstantpoolname(exceptiontypes[i], 0, -1, false, missingtypenames);
}
}
}
}

methodbinding result = method.isconstructor()
? new methodbinding(methodmodifiers, parameters, exceptions, this)
: new methodbinding(methodmodifiers, method.getselector(), returntype, parameters, exceptions, this);
if (this.environment.globaloptions.storeannotations)
result.setannotations(
createannotations(method.getannotations(), this.environment, missingtypenames),
paramannotations,
isannotationtype() ? convertmembervalue(method.getdefaultvalue(), this.environment, missingtypenames) : null,
this.environment);

if (use15specifics)
result.tagbits |= method.gettagbits();
result.typevariables = typevars;
// fixup the declaring element of the type variable
for (int i = 0, length = typevars.length; i < length; i++)
typevars[i].declaringelement = result;
return result;
}

/**
* create method bindings for binary type, filtering out <clinit> and synthetics
*/
private void createmethods(ibinarymethod[] imethods, long sourcelevel, char[][][] missingtypenames) {
int total = 0, initialtotal = 0, iclinit = -1;
int[] toskip = null;
if (imethods != null) {
total = initialtotal = imethods.length;
boolean keepbridgemethods = sourcelevel < classfileconstants.jdk1_5
&& this.environment.globaloptions.compliancelevel >= classfileconstants.jdk1_5;
for (int i = total; --i >= 0;) {
ibinarymethod method = imethods[i];
if ((method.getmodifiers() & classfileconstants.accsynthetic) != 0) {
if (keepbridgemethods && (method.getmodifiers() & classfileconstants.accbridge) != 0)
continue; // want to see bridge methods as real methods
// discard synthetics methods
if (toskip == null) toskip = new int[imethods.length];
toskip[i] = -1;
total--;
} else if (iclinit == -1) {
char[] methodname = method.getselector();
if (methodname.length == 8 && methodname[0] == '<') {
// discard <clinit>
iclinit = i;
total--;
}
}
}
}
if (total == 0) {
this.methods = binding.no_methods;
return;
}

boolean hasrestrictedaccess = hasrestrictedaccess();
this.methods = new methodbinding[total];
if (total == initialtotal) {
for (int i = 0; i < initialtotal; i++) {
methodbinding method = createmethod(imethods[i], sourcelevel, missingtypenames);
if (hasrestrictedaccess)
method.modifiers |= extracompilermodifiers.accrestrictedaccess;
this.methods[i] = method;
}
} else {
for (int i = 0, index = 0; i < initialtotal; i++) {
if (iclinit != i && (toskip == null || toskip[i] != -1)) {
methodbinding method = createmethod(imethods[i], sourcelevel, missingtypenames);
if (hasrestrictedaccess)
method.modifiers |= extracompilermodifiers.accrestrictedaccess;
this.methods[index++] = method;
}
}
}
}

private typevariablebinding[] createtypevariables(signaturewrapper wrapper, boolean assignvariables, char[][][] missingtypenames) {
// detect all type variables first
char[] typesignature = wrapper.signature;
int depth = 0, length = typesignature.length;
int rank = 0;
arraylist variables = new arraylist(1);
depth = 0;
boolean pendingvariable = true;
createvariables: {
for (int i = 1; i < length; i++) {
switch(typesignature[i]) {
case '<' :
depth++;
break;
case '>' :
if (--depth < 0)
break createvariables;
break;
case ';' :
if ((depth == 0) && (i +1 < length) && (typesignature[i+1] != ':'))
pendingvariable = true;
break;
default:
if (pendingvariable) {
pendingvariable = false;
int colon = charoperation.indexof(':', typesignature, i);
char[] variablename = charoperation.subarray(typesignature, i, colon);
variables.add(new typevariablebinding(variablename, this, rank++, this.environment));
}
}
}
}
// initialize type variable bounds - may refer to forward variables
typevariablebinding[] result;
variables.toarray(result = new typevariablebinding[rank]);
// when creating the type variables for a type, the type must remember them before initializing each variable
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=163680
if (assignvariables)
this.typevariables = result;
for (int i = 0; i < rank; i++) {
initializetypevariable(result[i], result, wrapper, missingtypenames);
}
return result;
}

/* answer the receiver's enclosing type... null if the receiver is a top level type.
*
* note: enclosingtype of a binary type is resolved when needed
*/
public referencebinding enclosingtype() {
if ((this.tagbits & tagbits.hasunresolvedenclosingtype) == 0)
return this.enclosingtype;

// finish resolving the type
this.enclosingtype = (referencebinding) resolvetype(this.enclosingtype, this.environment, false /* no raw conversion */);
this.tagbits &= ~tagbits.hasunresolvedenclosingtype;
return this.enclosingtype;
}
// note: the type of each field of a binary type is resolved when needed
public fieldbinding[] fields() {
if ((this.tagbits & tagbits.arefieldscomplete) != 0)
return this.fields;

// lazily sort fields
if ((this.tagbits & tagbits.arefieldssorted) == 0) {
int length = this.fields.length;
if (length > 1)
referencebinding.sortfields(this.fields, 0, length);
this.tagbits |= tagbits.arefieldssorted;
}
for (int i = this.fields.length; --i >= 0;)
resolvetypefor(this.fields[i]);
this.tagbits |= tagbits.arefieldscomplete;
return this.fields;
}

private methodbinding findmethod(char[] methoddescriptor, char[][][] missingtypenames) {
int index = -1;
while (methoddescriptor[++index] != '(') {
// empty
}
char[] selector = new char[index];
system.arraycopy(methoddescriptor, 0, selector, 0, index);
typebinding[] parameters = binding.no_parameters;
int numofparams = 0;
char nextchar;
int paramstart = index;
while ((nextchar = methoddescriptor[++index]) != ')') {
if (nextchar != '[') {
numofparams++;
if (nextchar == 'l')
while ((nextchar = methoddescriptor[++index]) != ';'){/*empty*/}
}
}
if (numofparams > 0) {
parameters = new typebinding[numofparams];
index = paramstart + 1;
int end = paramstart; // first character is always '(' so skip it
for (int i = 0; i < numofparams; i++) {
while ((nextchar = methoddescriptor[++end]) == '['){/*empty*/}
if (nextchar == 'l')
while ((nextchar = methoddescriptor[++end]) != ';'){/*empty*/}

typebinding param = this.environment.gettypefromsignature(methoddescriptor, index, end, false, this, missingtypenames);
if (param instanceof unresolvedreferencebinding) {
param = resolvetype(param, this.environment, true /* raw conversion */);
}
parameters[i] = param;
index = end + 1;
}
}

int parameterlength = parameters.length;
methodbinding[] methods2 = this.enclosingtype.getmethods(selector, parameterlength);
// find matching method using parameters
loop: for (int i = 0, max = methods2.length; i < max; i++) {
methodbinding currentmethod = methods2[i];
typebinding[] parameters2 = currentmethod.parameters;
int currentmethodparameterlength = parameters2.length;
if (parameterlength == currentmethodparameterlength) {
for (int j = 0; j < currentmethodparameterlength; j++) {
if (parameters[j] != parameters2[j] && parameters[j].erasure() != parameters2[j].erasure()) {
continue loop;
}
}
return currentmethod;
}
}
return null;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#generictypesignature()
*/
public char[] generictypesignature() {
return computegenerictypesignature(this.typevariables);
}

//note: the return type, arg & exception types of each method of a binary type are resolved when needed
public methodbinding getexactconstructor(typebinding[] argumenttypes) {

// lazily sort methods
if ((this.tagbits & tagbits.aremethodssorted) == 0) {
int length = this.methods.length;
if (length > 1)
referencebinding.sortmethods(this.methods, 0, length);
this.tagbits |= tagbits.aremethodssorted;
}
int argcount = argumenttypes.length;
long range;
if ((range = referencebinding.binarysearch(typeconstants.init, this.methods)) >= 0) {
nextmethod: for (int imethod = (int)range, end = (int)(range >> 32); imethod <= end; imethod++) {
methodbinding method = this.methods[imethod];
if (method.parameters.length == argcount) {
resolvetypesfor(method);
typebinding[] tomatch = method.parameters;
for (int iarg = 0; iarg < argcount; iarg++)
if (tomatch[iarg] != argumenttypes[iarg])
continue nextmethod;
return method;
}
}
}
return null;
}

//note: the return type, arg & exception types of each method of a binary type are resolved when needed
//searches up the hierarchy as long as no potential (but not exact) match was found.
public methodbinding getexactmethod(char[] selector, typebinding[] argumenttypes, compilationunitscope refscope) {
// sender from refscope calls recordtypereference(this)

// lazily sort methods
if ((this.tagbits & tagbits.aremethodssorted) == 0) {
int length = this.methods.length;
if (length > 1)
referencebinding.sortmethods(this.methods, 0, length);
this.tagbits |= tagbits.aremethodssorted;
}

int argcount = argumenttypes.length;
boolean foundnothing = true;

long range;
if ((range = referencebinding.binarysearch(selector, this.methods)) >= 0) {
nextmethod: for (int imethod = (int)range, end = (int)(range >> 32); imethod <= end; imethod++) {
methodbinding method = this.methods[imethod];
foundnothing = false; // inner type lookups must know that a method with this name exists
if (method.parameters.length == argcount) {
resolvetypesfor(method);
typebinding[] tomatch = method.parameters;
for (int iarg = 0; iarg < argcount; iarg++)
if (tomatch[iarg] != argumenttypes[iarg])
continue nextmethod;
return method;
}
}
}
if (foundnothing) {
if (isinterface()) {
if (superinterfaces().length == 1) { // ensure superinterfaces are resolved before checking
if (refscope != null)
refscope.recordtypereference(this.superinterfaces[0]);
return this.superinterfaces[0].getexactmethod(selector, argumenttypes, refscope);
}
} else if (superclass() != null) { // ensure superclass is resolved before checking
if (refscope != null)
refscope.recordtypereference(this.superclass);
return this.superclass.getexactmethod(selector, argumenttypes, refscope);
}
}
return null;
}
//note: the type of a field of a binary type is resolved when needed
public fieldbinding getfield(char[] fieldname, boolean needresolve) {
// lazily sort fields
if ((this.tagbits & tagbits.arefieldssorted) == 0) {
int length = this.fields.length;
if (length > 1)
referencebinding.sortfields(this.fields, 0, length);
this.tagbits |= tagbits.arefieldssorted;
}
fieldbinding field = referencebinding.binarysearch(fieldname, this.fields);
return needresolve && field != null ? resolvetypefor(field) : field;
}
/**
*  rewrite of default getmembertype to avoid resolving eagerly all member types when one is requested
*/
public referencebinding getmembertype(char[] typename) {
for (int i = this.membertypes.length; --i >= 0;) {
referencebinding membertype = this.membertypes[i];
if (membertype instanceof unresolvedreferencebinding) {
char[] name = membertype.sourcename; // source name is qualified with enclosing type name
int prefixlength = this.compoundname[this.compoundname.length - 1].length + 1; // enclosing$
if (name.length == (prefixlength + typename.length)) // enclosing $ typename
if (charoperation.fragmentequals(typename, name, prefixlength, true)) // only check trailing portion
return this.membertypes[i] = (referencebinding) resolvetype(membertype, this.environment, false /* no raw conversion for now */);
} else if (charoperation.equals(typename, membertype.sourcename)) {
return membertype;
}
}
return null;
}
// note: the return type, arg & exception types of each method of a binary type are resolved when needed
public methodbinding[] getmethods(char[] selector) {
if ((this.tagbits & tagbits.aremethodscomplete) != 0) {
long range;
if ((range = referencebinding.binarysearch(selector, this.methods)) >= 0) {
int start = (int) range, end = (int) (range >> 32);
int length = end - start + 1;
if ((this.tagbits & tagbits.aremethodscomplete) != 0) {
// simply clone method subset
methodbinding[] result;
system.arraycopy(this.methods, start, result = new methodbinding[length], 0, length);
return result;
}
}
return binding.no_methods;
}
// lazily sort methods
if ((this.tagbits & tagbits.aremethodssorted) == 0) {
int length = this.methods.length;
if (length > 1)
referencebinding.sortmethods(this.methods, 0, length);
this.tagbits |= tagbits.aremethodssorted;
}
long range;
if ((range = referencebinding.binarysearch(selector, this.methods)) >= 0) {
int start = (int) range, end = (int) (range >> 32);
int length = end - start + 1;
methodbinding[] result = new methodbinding[length];
// iterate methods to resolve them
for (int i = start, index = 0; i <= end; i++, index++)
result[index] = resolvetypesfor(this.methods[i]);
return result;
}
return binding.no_methods;
}
// answer methods named selector, which take no more than the suggestedparameterlength.
// the suggested parameter length is optional and may not be guaranteed by every type.
public methodbinding[] getmethods(char[] selector, int suggestedparameterlength) {
if ((this.tagbits & tagbits.aremethodscomplete) != 0)
return getmethods(selector);
// lazily sort methods
if ((this.tagbits & tagbits.aremethodssorted) == 0) {
int length = this.methods.length;
if (length > 1)
referencebinding.sortmethods(this.methods, 0, length);
this.tagbits |= tagbits.aremethodssorted;
}
long range;
if ((range = referencebinding.binarysearch(selector, this.methods)) >= 0) {
int start = (int) range, end = (int) (range >> 32);
int length = end - start + 1;
int count = 0;
for (int i = start; i <= end; i++) {
int len = this.methods[i].parameters.length;
if (len <= suggestedparameterlength || (this.methods[i].isvarargs() && len == suggestedparameterlength + 1))
count++;
}
if (count == 0) {
methodbinding[] result = new methodbinding[length];
// iterate methods to resolve them
for (int i = start, index = 0; i <= end; i++)
result[index++] = resolvetypesfor(this.methods[i]);
return result;
} else {
methodbinding[] result = new methodbinding[count];
// iterate methods to resolve them
for (int i = start, index = 0; i <= end; i++) {
int len = this.methods[i].parameters.length;
if (len <= suggestedparameterlength || (this.methods[i].isvarargs() && len == suggestedparameterlength + 1))
result[index++] = resolvetypesfor(this.methods[i]);
}
return result;
}
}
return binding.no_methods;
}
public boolean hasmembertypes() {
return this.membertypes.length > 0;
}
// note: member types of binary types are resolved when needed
public typevariablebinding gettypevariable(char[] variablename) {
typevariablebinding variable = super.gettypevariable(variablename);
variable.resolve();
return variable;
}
private void initializetypevariable(typevariablebinding variable, typevariablebinding[] existingvariables, signaturewrapper wrapper, char[][][] missingtypenames) {
// parametersignature = identifier ':' typesignature
//   or identifier ':' typesignature(optional) interfacebound(s)
// interfacebound = ':' typesignature
int colon = charoperation.indexof(':', wrapper.signature, wrapper.start);
wrapper.start = colon + 1; // skip name + ':'
referencebinding type, firstbound = null;
if (wrapper.signature[wrapper.start] == ':') {
type = this.environment.getresolvedtype(typeconstants.java_lang_object, null);
} else {
type = (referencebinding) this.environment.gettypefromtypesignature(wrapper, existingvariables, this, missingtypenames);
firstbound = type;
}

// variable is visible to its bounds
variable.modifiers |= extracompilermodifiers.accunresolved;
variable.superclass = type;

referencebinding[] bounds = null;
if (wrapper.signature[wrapper.start] == ':') {
java.util.arraylist types = new java.util.arraylist(2);
do {
wrapper.start++; // skip ':'
types.add(this.environment.gettypefromtypesignature(wrapper, existingvariables, this, missingtypenames));
} while (wrapper.signature[wrapper.start] == ':');
bounds = new referencebinding[types.size()];
types.toarray(bounds);
}

variable.superinterfaces = bounds == null ? binding.no_superinterfaces : bounds;
if (firstbound == null) {
firstbound = variable.superinterfaces.length == 0 ? null : variable.superinterfaces[0];
}
variable.firstbound = firstbound;
}
/**
* returns true if a type is identical to another one,
* or for generic types, true if compared to its raw type.
*/
public boolean isequivalentto(typebinding othertype) {
if (this == othertype) return true;
if (othertype == null) return false;
switch(othertype.kind()) {
case binding.wildcard_type :
case binding.intersection_type :
return ((wildcardbinding) othertype).boundcheck(this);
case binding.raw_type :
return othertype.erasure() == this;
}
return false;
}
public boolean isgenerictype() {
return this.typevariables != binding.no_type_variables;
}
public boolean ishierarchyconnected() {
return (this.tagbits & (tagbits.hasunresolvedsuperclass | tagbits.hasunresolvedsuperinterfaces)) == 0;
}
public int kind() {
if (this.typevariables != binding.no_type_variables)
return binding.generic_type;
return binding.type;
}
// note: member types of binary types are resolved when needed
public referencebinding[] membertypes() {
if ((this.tagbits & tagbits.hasunresolvedmembertypes) == 0)
return this.membertypes;

for (int i = this.membertypes.length; --i >= 0;)
this.membertypes[i] = (referencebinding) resolvetype(this.membertypes[i], this.environment, false /* no raw conversion for now */);
this.tagbits &= ~tagbits.hasunresolvedmembertypes;
return this.membertypes;
}
// note: the return type, arg & exception types of each method of a binary type are resolved when needed
public methodbinding[] methods() {
if ((this.tagbits & tagbits.aremethodscomplete) != 0)
return this.methods;

// lazily sort methods
if ((this.tagbits & tagbits.aremethodssorted) == 0) {
int length = this.methods.length;
if (length > 1)
referencebinding.sortmethods(this.methods, 0, length);
this.tagbits |= tagbits.aremethodssorted;
}
for (int i = this.methods.length; --i >= 0;)
resolvetypesfor(this.methods[i]);
this.tagbits |= tagbits.aremethodscomplete;
return this.methods;
}
private fieldbinding resolvetypefor(fieldbinding field) {
if ((field.modifiers & extracompilermodifiers.accunresolved) == 0)
return field;

typebinding resolvedtype = resolvetype(field.type, this.environment, true /* raw conversion */);
field.type = resolvedtype;
if ((resolvedtype.tagbits & tagbits.hasmissingtype) != 0) {
field.tagbits |= tagbits.hasmissingtype;
}
field.modifiers &= ~extracompilermodifiers.accunresolved;
return field;
}
methodbinding resolvetypesfor(methodbinding method) {
if ((method.modifiers & extracompilermodifiers.accunresolved) == 0)
return method;

if (!method.isconstructor()) {
typebinding resolvedtype = resolvetype(method.returntype, this.environment, true /* raw conversion */);
method.returntype = resolvedtype;
if ((resolvedtype.tagbits & tagbits.hasmissingtype) != 0) {
method.tagbits |= tagbits.hasmissingtype;
}
}
for (int i = method.parameters.length; --i >= 0;) {
typebinding resolvedtype = resolvetype(method.parameters[i], this.environment, true /* raw conversion */);
method.parameters[i] = resolvedtype;
if ((resolvedtype.tagbits & tagbits.hasmissingtype) != 0) {
method.tagbits |= tagbits.hasmissingtype;
}
}
for (int i = method.thrownexceptions.length; --i >= 0;) {
referencebinding resolvedtype = (referencebinding) resolvetype(method.thrownexceptions[i], this.environment, true /* raw conversion */);
method.thrownexceptions[i] = resolvedtype;
if ((resolvedtype.tagbits & tagbits.hasmissingtype) != 0) {
method.tagbits |= tagbits.hasmissingtype;
}
}
for (int i = method.typevariables.length; --i >= 0;) {
method.typevariables[i].resolve();
}
method.modifiers &= ~extracompilermodifiers.accunresolved;
return method;
}
annotationbinding[] retrieveannotations(binding binding) {
return annotationbinding.addstandardannotations(super.retrieveannotations(binding), binding.getannotationtagbits(), this.environment);
}
simplelookuptable storedannotations(boolean forceinitialize) {
if (forceinitialize && this.storedannotations == null) {
if (!this.environment.globaloptions.storeannotations)
return null; // not supported during this compile
this.storedannotations = new simplelookuptable(3);
}
return this.storedannotations;
}
/* answer the receiver's superclass... null if the receiver is object or an interface.
*
* note: superclass of a binary type is resolved when needed
*/
public referencebinding superclass() {
if ((this.tagbits & tagbits.hasunresolvedsuperclass) == 0)
return this.superclass;

// finish resolving the type
this.superclass = (referencebinding) resolvetype(this.superclass, this.environment, true /* raw conversion */);
this.tagbits &= ~tagbits.hasunresolvedsuperclass;
if (this.superclass.problemid() == problemreasons.notfound)
this.tagbits |= tagbits.hierarchyhasproblems; // propagate type inconsistency
return this.superclass;
}
// note: superinterfaces of binary types are resolved when needed
public referencebinding[] superinterfaces() {
if ((this.tagbits & tagbits.hasunresolvedsuperinterfaces) == 0)
return this.superinterfaces;

for (int i = this.superinterfaces.length; --i >= 0;) {
this.superinterfaces[i] = (referencebinding) resolvetype(this.superinterfaces[i], this.environment, true /* raw conversion */);
if (this.superinterfaces[i].problemid() == problemreasons.notfound)
this.tagbits |= tagbits.hierarchyhasproblems; // propagate type inconsistency
}
this.tagbits &= ~tagbits.hasunresolvedsuperinterfaces;
return this.superinterfaces;
}
public typevariablebinding[] typevariables() {
if ((this.tagbits & tagbits.hasunresolvedtypevariables) == 0)
return this.typevariables;

for (int i = this.typevariables.length; --i >= 0;)
this.typevariables[i].resolve();
this.tagbits &= ~tagbits.hasunresolvedtypevariables;
return this.typevariables;
}
public string tostring() {
stringbuffer buffer = new stringbuffer();

if (isdeprecated()) buffer.append("deprecated "); //$non-nls-1$
if (ispublic()) buffer.append("public "); //$non-nls-1$
if (isprotected()) buffer.append("protected "); //$non-nls-1$
if (isprivate()) buffer.append("private "); //$non-nls-1$
if (isabstract() && isclass()) buffer.append("abstract "); //$non-nls-1$
if (isstatic() && isnestedtype()) buffer.append("static "); //$non-nls-1$
if (isfinal()) buffer.append("final "); //$non-nls-1$

if (isenum()) buffer.append("enum "); //$non-nls-1$
else if (isannotationtype()) buffer.append("@@interface "); //$non-nls-1$
else if (isclass()) buffer.append("class "); //$non-nls-1$
else buffer.append("interface "); //$non-nls-1$
buffer.append((this.compoundname != null) ? charoperation.tostring(this.compoundname) : "unnamed type"); //$non-nls-1$

if (this.typevariables == null) {
buffer.append("<null type variables>"); //$non-nls-1$
} else if (this.typevariables != binding.no_type_variables) {
buffer.append("<"); //$non-nls-1$
for (int i = 0, length = this.typevariables.length; i < length; i++) {
if (i  > 0) buffer.append(", "); //$non-nls-1$
if (this.typevariables[i] == null) {
buffer.append("null type variable"); //$non-nls-1$
continue;
}
char[] varchars = this.typevariables[i].tostring().tochararray();
buffer.append(varchars, 1, varchars.length - 2);
}
buffer.append(">"); //$non-nls-1$
}
buffer.append("\n\textends "); //$non-nls-1$
buffer.append((this.superclass != null) ? this.superclass.debugname() : "null type"); //$non-nls-1$

if (this.superinterfaces != null) {
if (this.superinterfaces != binding.no_superinterfaces) {
buffer.append("\n\timplements : "); //$non-nls-1$
for (int i = 0, length = this.superinterfaces.length; i < length; i++) {
if (i  > 0)
buffer.append(", "); //$non-nls-1$
buffer.append((this.superinterfaces[i] != null) ? this.superinterfaces[i].debugname() : "null type"); //$non-nls-1$
}
}
} else {
buffer.append("null superinterfaces"); //$non-nls-1$
}

if (this.enclosingtype != null) {
buffer.append("\n\tenclosing type : "); //$non-nls-1$
buffer.append(this.enclosingtype.debugname());
}

if (this.fields != null) {
if (this.fields != binding.no_fields) {
buffer.append("\n/*   fields   */"); //$non-nls-1$
for (int i = 0, length = this.fields.length; i < length; i++)
buffer.append((this.fields[i] != null) ? "\n" + this.fields[i].tostring() : "\nnull field"); //$non-nls-1$ //$non-nls-2$
}
} else {
buffer.append("null fields"); //$non-nls-1$
}

if (this.methods != null) {
if (this.methods != binding.no_methods) {
buffer.append("\n/*   methods   */"); //$non-nls-1$
for (int i = 0, length = this.methods.length; i < length; i++)
buffer.append((this.methods[i] != null) ? "\n" + this.methods[i].tostring() : "\nnull method"); //$non-nls-1$ //$non-nls-2$
}
} else {
buffer.append("null methods"); //$non-nls-1$
}

if (this.membertypes != null) {
if (this.membertypes != binding.no_member_types) {
buffer.append("\n/*   members   */"); //$non-nls-1$
for (int i = 0, length = this.membertypes.length; i < length; i++)
buffer.append((this.membertypes[i] != null) ? "\n" + this.membertypes[i].tostring() : "\nnull type"); //$non-nls-1$ //$non-nls-2$
}
} else {
buffer.append("null member types"); //$non-nls-1$
}

buffer.append("\n\n\n"); //$non-nls-1$
return buffer.tostring();
}
methodbinding[] unresolvedmethods() { // for the methodverifier so it doesn't resolve types
return this.methods;
}
}
