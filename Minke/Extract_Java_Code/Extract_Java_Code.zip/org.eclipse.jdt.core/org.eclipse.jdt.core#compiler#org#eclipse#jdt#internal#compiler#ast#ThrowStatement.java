/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;

public class throwstatement extends statement {

public expression exception;
public typebinding exceptiontype;

public throwstatement(expression exception, int sourcestart, int sourceend) {
this.exception = exception;
this.sourcestart = sourcestart;
this.sourceend = sourceend;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
this.exception.analysecode(currentscope, flowcontext, flowinfo);
this.exception.checknpe(currentscope, flowcontext, flowinfo);
// need to check that exception thrown is actually caught somewhere
flowcontext.checkexceptionhandlers(this.exceptiontype, this, flowinfo, currentscope);
return flowinfo.dead_end;
}

/**
* throw code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & astnode.isreachable) == 0)
return;
int pc = codestream.position;
this.exception.generatecode(currentscope, codestream, true);
codestream.athrow();
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public stringbuffer printstatement(int indent, stringbuffer output) {
printindent(indent, output).append("throw "); //$non-nls-1$
this.exception.printexpression(0, output);
return output.append(';');
}

public void resolve(blockscope scope) {
this.exceptiontype = this.exception.resolvetype(scope);
if (this.exceptiontype != null && this.exceptiontype.isvalidbinding()) {
if (this.exceptiontype == typebinding.null) {
if (scope.compileroptions().compliancelevel <= classfileconstants.jdk1_3){
// if compliant with 1.4, this problem will not be reported
scope.problemreporter().cannotthrownull(this.exception);
}
} else if (this.exceptiontype.findsupertypeoriginatingfrom(typeids.t_javalangthrowable, true) == null) {
scope.problemreporter().cannotthrowtype(this.exception, this.exceptiontype);
}
this.exception.computeconversion(scope, this.exceptiontype, this.exceptiontype);
}
}

public void traverse(astvisitor visitor, blockscope blockscope) {
if (visitor.visit(this, blockscope))
this.exception.traverse(visitor, blockscope);
visitor.endvisit(this, blockscope);
}
}
