/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.astvisitor;

public class emptystatement extends statement {

public emptystatement(int startposition, int endposition) {
this.sourcestart = startposition;
this.sourceend = endposition;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
return flowinfo;
}

// report an error if necessary
public int complainifunreachable(flowinfo flowinfo, blockscope scope, int complaintlevel) {
// before 1.4, empty statements are tolerated anywhere
if (scope.compileroptions().compliancelevel < classfileconstants.jdk1_4) {
return complaintlevel;
}
return super.complainifunreachable(flowinfo, scope, complaintlevel);
}

public void generatecode(blockscope currentscope, codestream codestream){
// no bytecode, no need to check for reachability or recording source positions
}

public stringbuffer printstatement(int tab, stringbuffer output) {
return printindent(tab, output).append(';');
}

public void resolve(blockscope scope) {
if ((this.bits & isusefulemptystatement) == 0) {
scope.problemreporter().superfluoussemicolon(this.sourcestart, this.sourceend);
} else {
scope.problemreporter().emptycontrolflowstatement(this.sourcestart, this.sourceend);
}
}

public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}


}

