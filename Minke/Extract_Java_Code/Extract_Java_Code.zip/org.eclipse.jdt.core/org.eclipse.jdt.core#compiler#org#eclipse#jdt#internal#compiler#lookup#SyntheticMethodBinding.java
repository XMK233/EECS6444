/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;

public class syntheticmethodbinding extends methodbinding {

public fieldbinding targetreadfield;		// read access to a field
public fieldbinding targetwritefield;		// write access to a field
public methodbinding targetmethod;			// method or constructor
public typebinding targetenumtype; 			// enum type

public int purpose;

public final static int fieldreadaccess = 1; 		// field read
public final static int fieldwriteaccess = 2; 		// field write
public final static int superfieldreadaccess = 3; // super field read
public final static int superfieldwriteaccess = 4; // super field write
public final static int methodaccess = 5; 		// normal method
public final static int constructoraccess = 6; 	// constructor
public final static int supermethodaccess = 7; // super method
public final static int bridgemethod = 8; // bridge method
public final static int enumvalues = 9; // enum #values()
public final static int enumvalueof = 10; // enum #valueof(string)
public final static int switchtable = 11; // switch table method

public int sourcestart = 0; // start position of the matching declaration
public int index; // used for sorting access methods in the class file

public syntheticmethodbinding(fieldbinding targetfield, boolean isreadaccess, boolean issuperaccess, referencebinding declaringclass) {

this.modifiers = classfileconstants.accdefault | classfileconstants.accstatic | classfileconstants.accsynthetic;
this.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
sourcetypebinding declaringsourcetype = (sourcetypebinding) declaringclass;
syntheticmethodbinding[] knownaccessmethods = declaringsourcetype.syntheticmethods();
int methodid = knownaccessmethods == null ? 0 : knownaccessmethods.length;
this.index = methodid;
this.selector = charoperation.concat(typeconstants.synthetic_access_method_prefix, string.valueof(methodid).tochararray());
if (isreadaccess) {
this.returntype = targetfield.type;
if (targetfield.isstatic()) {
this.parameters = binding.no_parameters;
} else {
this.parameters = new typebinding[1];
this.parameters[0] = declaringsourcetype;
}
this.targetreadfield = targetfield;
this.purpose = issuperaccess ? syntheticmethodbinding.superfieldreadaccess : syntheticmethodbinding.fieldreadaccess;
} else {
this.returntype = typebinding.void;
if (targetfield.isstatic()) {
this.parameters = new typebinding[1];
this.parameters[0] = targetfield.type;
} else {
this.parameters = new typebinding[2];
this.parameters[0] = declaringsourcetype;
this.parameters[1] = targetfield.type;
}
this.targetwritefield = targetfield;
this.purpose = issuperaccess ? syntheticmethodbinding.superfieldwriteaccess : syntheticmethodbinding.fieldwriteaccess;
}
this.thrownexceptions = binding.no_exceptions;
this.declaringclass = declaringsourcetype;

// check for method collision
boolean needrename;
do {
check : {
needrename = false;
// check for collision with known methods
long range;
methodbinding[] methods = declaringsourcetype.methods();
if ((range = referencebinding.binarysearch(this.selector, methods)) >= 0) {
int paramcount = this.parameters.length;
nextmethod: for (int imethod = (int)range, end = (int)(range >> 32); imethod <= end; imethod++) {
methodbinding method = methods[imethod];
if (method.parameters.length == paramcount) {
typebinding[] tomatch = method.parameters;
for (int i = 0; i < paramcount; i++) {
if (tomatch[i] != this.parameters[i]) {
continue nextmethod;
}
}
needrename = true;
break check;
}
}
}
// check for collision with synthetic accessors
if (knownaccessmethods != null) {
for (int i = 0, length = knownaccessmethods.length; i < length; i++) {
if (knownaccessmethods[i] == null) continue;
if (charoperation.equals(this.selector, knownaccessmethods[i].selector) && areparametersequal(methods[i])) {
needrename = true;
break check;
}
}
}
}
if (needrename) { // retry with a selector postfixed by a growing methodid
setselector(charoperation.concat(typeconstants.synthetic_access_method_prefix, string.valueof(++methodid).tochararray()));
}
} while (needrename);

// retrieve sourcestart position for the target field for line number attributes
fielddeclaration[] fielddecls = declaringsourcetype.scope.referencecontext.fields;
if (fielddecls != null) {
for (int i = 0, max = fielddecls.length; i < max; i++) {
if (fielddecls[i].binding == targetfield) {
this.sourcestart = fielddecls[i].sourcestart;
return;
}
}
}

/* did not find the target field declaration - it is a synthetic one
public class a {
public class b {
public class c {
void foo() {
system.out.println("a.this = " + a.this);
}
}
}
public static void main(string args[]) {
new a().new b().new c().foo();
}
}
*/
// we now at this point - per construction - it is for sure an enclosing instance, we are going to
// show the target field type declaration location.
this.sourcestart = declaringsourcetype.scope.referencecontext.sourcestart; // use the target declaring class name position instead
}

public syntheticmethodbinding(fieldbinding targetfield, referencebinding declaringclass, typebinding enumbinding, char[] selector) {
this.modifiers = classfileconstants.accdefault | classfileconstants.accstatic | classfileconstants.accsynthetic;
this.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
sourcetypebinding declaringsourcetype = (sourcetypebinding) declaringclass;
syntheticmethodbinding[] knownaccessmethods = declaringsourcetype.syntheticmethods();
int methodid = knownaccessmethods == null ? 0 : knownaccessmethods.length;
this.index = methodid;
this.selector = selector;
this.returntype = declaringsourcetype.scope.createarraytype(typebinding.int, 1);
this.parameters = binding.no_parameters;
this.targetreadfield = targetfield;
this.targetenumtype = enumbinding;
this.purpose = syntheticmethodbinding.switchtable;
this.thrownexceptions = binding.no_exceptions;
this.declaringclass = declaringsourcetype;

if (declaringsourcetype.isstrictfp()) {
this.modifiers |= classfileconstants.accstrictfp;
}
// check for method collision
boolean needrename;
do {
check : {
needrename = false;
// check for collision with known methods
long range;
methodbinding[] methods = declaringsourcetype.methods();
if ((range = referencebinding.binarysearch(this.selector, methods)) >= 0) {
int paramcount = this.parameters.length;
nextmethod: for (int imethod = (int)range, end = (int)(range >> 32); imethod <= end; imethod++) {
methodbinding method = methods[imethod];
if (method.parameters.length == paramcount) {
typebinding[] tomatch = method.parameters;
for (int i = 0; i < paramcount; i++) {
if (tomatch[i] != this.parameters[i]) {
continue nextmethod;
}
}
needrename = true;
break check;
}
}
}
// check for collision with synthetic accessors
if (knownaccessmethods != null) {
for (int i = 0, length = knownaccessmethods.length; i < length; i++) {
if (knownaccessmethods[i] == null) continue;
if (charoperation.equals(this.selector, knownaccessmethods[i].selector) && areparametersequal(methods[i])) {
needrename = true;
break check;
}
}
}
}
if (needrename) { // retry with a selector postfixed by a growing methodid
setselector(charoperation.concat(selector, string.valueof(++methodid).tochararray()));
}
} while (needrename);

// we now at this point - per construction - it is for sure an enclosing instance, we are going to
// show the target field type declaration location.
this.sourcestart = declaringsourcetype.scope.referencecontext.sourcestart; // use the target declaring class name position instead
}

public syntheticmethodbinding(methodbinding targetmethod, boolean issuperaccess, referencebinding declaringclass) {

if (targetmethod.isconstructor()) {
initializeconstructoraccessor(targetmethod);
} else {
initializemethodaccessor(targetmethod, issuperaccess, declaringclass);
}
}

/**
* construct a bridge method
*/
public syntheticmethodbinding(methodbinding overridenmethodtobridge, methodbinding targetmethod, sourcetypebinding declaringclass) {

this.declaringclass = declaringclass;
this.selector = overridenmethodtobridge.selector;
// amongst other, clear the accgenericsignature, so as to ensure no remains of original inherited persist (101794)
// also use the modifiers from the target method, as opposed to inherited one (147690)
this.modifiers = (targetmethod.modifiers | classfileconstants.accbridge | classfileconstants.accsynthetic) & ~(classfileconstants.accabstract | classfileconstants.accnative  | classfileconstants.accfinal | extracompilermodifiers.accgenericsignature);
this.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
this.returntype = overridenmethodtobridge.returntype;
this.parameters = overridenmethodtobridge.parameters;
this.thrownexceptions = overridenmethodtobridge.thrownexceptions;
this.targetmethod = targetmethod;
this.purpose = syntheticmethodbinding.bridgemethod;
syntheticmethodbinding[] knownaccessmethods = declaringclass.syntheticmethods();
int methodid = knownaccessmethods == null ? 0 : knownaccessmethods.length;
this.index = methodid;
}

/**
* construct enum special methods: values or valueof methods
*/
public syntheticmethodbinding(sourcetypebinding declaringenum, char[] selector) {
this.declaringclass = declaringenum;
this.selector = selector;
this.modifiers = classfileconstants.accpublic | classfileconstants.accstatic;
this.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
lookupenvironment environment = declaringenum.scope.environment();
this.thrownexceptions = binding.no_exceptions;
if (selector == typeconstants.values) {
this.returntype = environment.createarraytype(environment.converttoparameterizedtype(declaringenum), 1);
this.parameters = binding.no_parameters;
this.purpose = syntheticmethodbinding.enumvalues;
} else if (selector == typeconstants.valueof) {
this.returntype = environment.converttoparameterizedtype(declaringenum);
this.parameters = new typebinding[]{ declaringenum.scope.getjavalangstring() };
this.purpose = syntheticmethodbinding.enumvalueof;
}
syntheticmethodbinding[] knownaccessmethods = ((sourcetypebinding)this.declaringclass).syntheticmethods();
int methodid = knownaccessmethods == null ? 0 : knownaccessmethods.length;
this.index = methodid;
if (declaringenum.isstrictfp()) {
this.modifiers |= classfileconstants.accstrictfp;
}
}

// create a synthetic method that will simply call the super classes method.
// used when a public method is inherited from a non-public class into a public class.
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=288658
public syntheticmethodbinding(methodbinding overridenmethodtobridge, sourcetypebinding declaringclass) {

this.declaringclass = declaringclass;
this.selector = overridenmethodtobridge.selector;
// amongst other, clear the accgenericsignature, so as to ensure no remains of original inherited persist (101794)
// also use the modifiers from the target method, as opposed to inherited one (147690)
this.modifiers = (overridenmethodtobridge.modifiers | classfileconstants.accbridge | classfileconstants.accsynthetic) & ~(classfileconstants.accabstract | classfileconstants.accnative  | classfileconstants.accfinal | extracompilermodifiers.accgenericsignature);
this.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
this.returntype = overridenmethodtobridge.returntype;
this.parameters = overridenmethodtobridge.parameters;
this.thrownexceptions = overridenmethodtobridge.thrownexceptions;
this.targetmethod = overridenmethodtobridge;
this.purpose = syntheticmethodbinding.supermethodaccess;
syntheticmethodbinding[] knownaccessmethods = declaringclass.syntheticmethods();
int methodid = knownaccessmethods == null ? 0 : knownaccessmethods.length;
this.index = methodid;
}

/**
* an constructor accessor is a constructor with an extra argument (declaringclass), in case of
* collision with an existing constructor, then add again an extra argument (declaringclass again).
*/
public void initializeconstructoraccessor(methodbinding accessedconstructor) {

this.targetmethod = accessedconstructor;
this.modifiers = classfileconstants.accdefault | classfileconstants.accsynthetic;
this.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
sourcetypebinding sourcetype = (sourcetypebinding) accessedconstructor.declaringclass;
syntheticmethodbinding[] knownsyntheticmethods = sourcetype.syntheticmethods();
this.index = knownsyntheticmethods == null ? 0 : knownsyntheticmethods.length;

this.selector = accessedconstructor.selector;
this.returntype = accessedconstructor.returntype;
this.purpose = syntheticmethodbinding.constructoraccess;
this.parameters = new typebinding[accessedconstructor.parameters.length + 1];
system.arraycopy(
accessedconstructor.parameters,
0,
this.parameters,
0,
accessedconstructor.parameters.length);
this.parameters[accessedconstructor.parameters.length] =
accessedconstructor.declaringclass;
this.thrownexceptions = accessedconstructor.thrownexceptions;
this.declaringclass = sourcetype;

// check for method collision
boolean needrename;
do {
check : {
needrename = false;
// check for collision with known methods
methodbinding[] methods = sourcetype.methods();
for (int i = 0, length = methods.length; i < length; i++) {
if (charoperation.equals(this.selector, methods[i].selector) && areparametererasuresequal(methods[i])) {
needrename = true;
break check;
}
}
// check for collision with synthetic accessors
if (knownsyntheticmethods != null) {
for (int i = 0, length = knownsyntheticmethods.length; i < length; i++) {
if (knownsyntheticmethods[i] == null)
continue;
if (charoperation.equals(this.selector, knownsyntheticmethods[i].selector) && areparametererasuresequal(knownsyntheticmethods[i])) {
needrename = true;
break check;
}
}
}
}
if (needrename) { // retry with a new extra argument
int length = this.parameters.length;
system.arraycopy(
this.parameters,
0,
this.parameters = new typebinding[length + 1],
0,
length);
this.parameters[length] = this.declaringclass;
}
} while (needrename);

// retrieve sourcestart position for the target method for line number attributes
abstractmethoddeclaration[] methoddecls =
sourcetype.scope.referencecontext.methods;
if (methoddecls != null) {
for (int i = 0, length = methoddecls.length; i < length; i++) {
if (methoddecls[i].binding == accessedconstructor) {
this.sourcestart = methoddecls[i].sourcestart;
return;
}
}
}
}

/**
* an method accessor is a method with an access$n selector, where n is incremented in case of collisions.
*/
public void initializemethodaccessor(methodbinding accessedmethod, boolean issuperaccess, referencebinding receivertype) {

this.targetmethod = accessedmethod;
this.modifiers = classfileconstants.accdefault | classfileconstants.accstatic | classfileconstants.accsynthetic;
this.tagbits |= (tagbits.annotationresolved | tagbits.deprecatedannotationresolved);
sourcetypebinding declaringsourcetype = (sourcetypebinding) receivertype;
syntheticmethodbinding[] knownaccessmethods = declaringsourcetype.syntheticmethods();
int methodid = knownaccessmethods == null ? 0 : knownaccessmethods.length;
this.index = methodid;

this.selector = charoperation.concat(typeconstants.synthetic_access_method_prefix, string.valueof(methodid).tochararray());
this.returntype = accessedmethod.returntype;
this.purpose = issuperaccess ? syntheticmethodbinding.supermethodaccess : syntheticmethodbinding.methodaccess;

if (accessedmethod.isstatic()) {
this.parameters = accessedmethod.parameters;
} else {
this.parameters = new typebinding[accessedmethod.parameters.length + 1];
this.parameters[0] = declaringsourcetype;
system.arraycopy(accessedmethod.parameters, 0, this.parameters, 1, accessedmethod.parameters.length);
}
this.thrownexceptions = accessedmethod.thrownexceptions;
this.declaringclass = declaringsourcetype;

// check for method collision
boolean needrename;
do {
check : {
needrename = false;
// check for collision with known methods
methodbinding[] methods = declaringsourcetype.methods();
for (int i = 0, length = methods.length; i < length; i++) {
if (charoperation.equals(this.selector, methods[i].selector) && areparametererasuresequal(methods[i])) {
needrename = true;
break check;
}
}
// check for collision with synthetic accessors
if (knownaccessmethods != null) {
for (int i = 0, length = knownaccessmethods.length; i < length; i++) {
if (knownaccessmethods[i] == null) continue;
if (charoperation.equals(this.selector, knownaccessmethods[i].selector) && areparametererasuresequal(knownaccessmethods[i])) {
needrename = true;
break check;
}
}
}
}
if (needrename) { // retry with a selector & a growing methodid
setselector(charoperation.concat(typeconstants.synthetic_access_method_prefix, string.valueof(++methodid).tochararray()));
}
} while (needrename);

// retrieve sourcestart position for the target method for line number attributes
abstractmethoddeclaration[] methoddecls = declaringsourcetype.scope.referencecontext.methods;
if (methoddecls != null) {
for (int i = 0, length = methoddecls.length; i < length; i++) {
if (methoddecls[i].binding == accessedmethod) {
this.sourcestart = methoddecls[i].sourcestart;
return;
}
}
}
}

protected boolean isconstructorrelated() {
return this.purpose == syntheticmethodbinding.constructoraccess;
}
}
