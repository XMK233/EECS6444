/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import org.eclipse.jdt.core.compiler.categorizedproblem;

/**
* a selection requestor accepts results from the selection engine.
*/
public interface iselectionrequestor {
/**
* code assist notification of a enum selection.
* @@param packagename char[]
* 		declaring package name of the type.
*
* @@param annotationname char[]
* 		name of the type.
*
* @@param isdeclaration boolean
*  	answer if the selected type is a declaration
*
* @@param generictypesignature
*  	genric type signature of the selected type if it is a
*  	parameterized type
*
* @@param start
*  	start of the selection
*
* @@param end
*  	end of the selection
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*/
void accepttype(
char[] packagename,
char[] annotationname,
int modifiers,
boolean isdeclaration,
char[] generictypesignature,
int start,
int end);

/**
* code assist notification of a compilation error detected during selection.
*  @@param error categorizedproblem
*      only problems which are categorized as errors are notified to the requestor,
*		warnings are silently ignored.
*		in case an error got signaled, no other completions might be available,
*		therefore the problem message should be presented to the user.
*		the source positions of the problem are related to the source where it was
*		detected (might be in another compilation unit, if it was indirectly requested
*		during the code assist process).
*      note: the problem knows its originating file name.
*/
void accepterror(categorizedproblem error);

/**
* code assist notification of a field selection.
* @@param declaringtypepackagename char[]
* 		name of the package in which the type that contains this field is declared.
*
* @@param declaringtypename char[]
* 		name of the type declaring this new field.
*
* @@param name char[]
* 		name of the field.
*
* @@param isdeclaration boolean
*  	answer if the selected field is a declaration
*
* @@param uniquekey
*  	unique key of this field
*
* @@param start
*  	start of the selection
*
* @@param end
*  	end of the selection
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*/
void acceptfield(
char[] declaringtypepackagename,
char[] declaringtypename,
char[] name,
boolean isdeclaration,
char[] uniquekey,
int start,
int end);

/**
* code assist notification of a method selection.
* @@param declaringtypepackagename char[]
* 		name of the package in which the type that contains this new method is declared.
*
* @@param declaringtypename char[]
* 		name of the type declaring this new method.
*
* @@param enclosingdeclaringtypesignature string
*  	type signature of the declaring type of the declaring type or <code>null</code>
*  	if declaring type is a top level type.
*
* @@param selector char[]
* 		name of the new method.
*
* @@param parameterpackagenames char[][]
* 		names of the packages in which the parameter types are declared.
*    	should contain as many elements as parametertypenames.
*
* @@param parametertypenames char[][]
* 		names of the parameters types.
*    	should contain as many elements as parameterpackagenames.
*
* @@param parametersignatures string[]
* 		signature of the parameters types.
*    	should contain as many elements as parameterpackagenames.
*
*  @@param isconstructor boolean
* 		answer if the method is a constructor.
*
* @@param isdeclaration boolean
*  	answer if the selected method is a declaration
*
* @@param uniquekey
*  	unique key of the method
*
* @@param start
*  	start of the selection
*
* @@param end
*  	end of the selection
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    base types are in the form "int" or "boolean".
*    array types are in the qualified form "m[]" or "int[]".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*/
// parameters 'isdeclaration', 'start' and 'end' are use to distinguish duplicate methods declarations
void acceptmethod(
char[] declaringtypepackagename,
char[] declaringtypename,
string enclosingdeclaringtypesignature,
char[] selector,
char[][] parameterpackagenames,
char[][] parametertypenames,
string[] parametersignatures,
char[][] typeparameternames,
char[][][] typeparameterboundnames,
boolean isconstructor,
boolean isdeclaration,
char[] uniquekey,
int start,
int end);

/**
* code assist notification of a package selection.
* @@param packagename char[]
* 		the package name.
*
* note - all package names are presented in their readable form:
*    package names are in the form "a.b.c".
*    the default package is represented by an empty array.
*/
void acceptpackage(char[] packagename);
/**
* code assist notification of a type parameter selection.
*
* @@param declaringtypepackagename char[]
* 		name of the package in which the type that contains this new method is declared.
*
* @@param declaringtypename char[]
* 		name of the type declaring this new method.
*
* @@param typeparametername char[]
* 		name of the type parameter.
*
* @@param isdeclaration boolean
*  	answer if the selected type parameter is a declaration
*
* @@param start
*  	start of the selection
*
* @@param end
*  	end of the selection
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*/
void accepttypeparameter(
char[] declaringtypepackagename,
char[] declaringtypename,
char[] typeparametername,
boolean isdeclaration,
int start,
int end);

/**
* code assist notification of a type parameter selection.
*
* @@param declaringtypepackagename char[]
* 		name of the package in which the type that contains this new method is declared.
*
* @@param declaringtypename char[]
* 		name of the type declaring this new method.
*
* @@param selector char[]
* 		name of the declaring method.
*
* @@param selectorstart int
* 		start of the selector.
*
* @@param selectorend int
* 		end of the selector.
*
* @@param typeparametername char[]
* 		name of the type parameter.
*
* @@param isdeclaration boolean
*  	answer if the selected type parameter is a declaration
*
* @@param start
*  	start of the selection
*
* @@param end
*  	end of the selection
*
* note - all package and type names are presented in their readable form:
*    package names are in the form "a.b.c".
*    nested type names are in the qualified form "a.m".
*    the default package is represented by an empty array.
*/
void acceptmethodtypeparameter(
char[] declaringtypepackagename,
char[] declaringtypename,
char[] selector,
int selectorstart,
int selectorend,
char[] typeparametername,
boolean isdeclaration,
int start,
int end);
}
