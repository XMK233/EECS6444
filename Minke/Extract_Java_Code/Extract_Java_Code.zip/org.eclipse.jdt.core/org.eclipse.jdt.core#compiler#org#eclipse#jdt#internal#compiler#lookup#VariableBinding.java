/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.constant;

public abstract class variablebinding extends binding {

public int modifiers;
public typebinding type;
public char[] name;
protected constant constant;
public int id; // for flow-analysis (position in flowinfo bit vector)
public long tagbits;

public variablebinding(char[] name, typebinding type, int modifiers, constant constant) {
this.name = name;
this.type = type;
this.modifiers = modifiers;
this.constant = constant;
if (type != null) {
this.tagbits |= (type.tagbits & tagbits.hasmissingtype);
}
}

public constant constant() {
return this.constant;
}

public abstract annotationbinding[] getannotations();

public final boolean isblankfinal(){
return (this.modifiers & extracompilermodifiers.accblankfinal) != 0;
}
/* answer true if the receiver is final and cannot be changed
*/

public final boolean isfinal() {
return (this.modifiers & classfileconstants.accfinal) != 0;
}
public char[] readablename() {
return this.name;
}
public void setconstant(constant constant) {
this.constant = constant;
}
public string tostring() {
stringbuffer output = new stringbuffer(10);
astnode.printmodifiers(this.modifiers, output);
if ((this.modifiers & extracompilermodifiers.accunresolved) != 0) {
output.append("[unresolved] "); //$non-nls-1$
}
output.append(this.type != null ? this.type.debugname() : "<no type>"); //$non-nls-1$
output.append(" "); //$non-nls-1$
output.append((this.name != null) ? new string(this.name) : "<no name>"); //$non-nls-1$
return output.tostring();
}
}
