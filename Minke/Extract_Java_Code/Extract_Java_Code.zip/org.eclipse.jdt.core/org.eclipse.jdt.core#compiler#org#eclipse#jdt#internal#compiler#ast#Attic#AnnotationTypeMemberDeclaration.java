/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.flow.exceptionhandlingflowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.flow.initializationflowcontext;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.parser.parser;
import org.eclipse.jdt.internal.compiler.problem.abortmethod;

public class annotationtypememberdeclaration extends abstractmethoddeclaration {

public typereference returntype;
public expression membervalue;
public int extendeddimensions;

/**
* methoddeclaration constructor comment.
*/
public annotationtypememberdeclaration(compilationresult compilationresult) {
super(compilationresult);
}

public void analysecode(
classscope classscope,
initializationflowcontext initializationcontext,
flowinfo flowinfo) {

// starting of the code analysis for methods
if (ignorefurtherinvestigation) {
return;
}
if (this.extendeddimensions != 0) {
scope.problemreporter().illegalextendeddimensions(this);
}
try {
if (binding == null) {
return;
}

if (this.binding.isprivate() && !this.binding.isprivateused()) {
if (!classscope.referencecompilationunit().compilationresult.hassyntaxerror()) {
scope.problemreporter().unusedprivatemethod(this);
}
}

// may be in a non necessary <clinit> for innerclass with static final constant fields
if (binding.isabstract() || binding.isnative())
return;

exceptionhandlingflowcontext methodcontext =
new exceptionhandlingflowcontext(
initializationcontext,
this,
binding.thrownexceptions,
scope,
flowinfo.dead_end);

// propagate to statements
if (statements != null) {
boolean didalreadycomplain = false;
for (int i = 0, count = statements.length; i < count; i++) {
statement stat = statements[i];
if (!stat.complainifunreachable(flowinfo, scope, didalreadycomplain)) {
flowinfo = stat.analysecode(scope, methodcontext, flowinfo);
} else {
didalreadycomplain = true;
}
}
}
// check for missing returning path
typebinding returntypebinding = binding.returntype;
if ((returntypebinding == voidbinding) || isabstract()) {
this.needfreereturn = flowinfo.isreachable();
} else {
if (flowinfo != flowinfo.dead_end) {
scope.problemreporter().shouldreturn(returntypebinding, this);
}
}
// check unreachable catch blocks
methodcontext.complainifunusedexceptionhandlers(this);
} catch (abortmethod e) {
this.ignorefurtherinvestigation = true;
}
}


public void parsestatements(parser parser, compilationunitdeclaration unit) {
// nothing to do
// annotation type member declaration don't have any body
}

public stringbuffer printreturntype(int indent, stringbuffer output) {

if (returntype == null) return output;
return returntype.printexpression(0, output).append(' ');
}

public void resolve(classscope upperscope) {
if (this.binding == null) {
this.ignorefurtherinvestigation = true;
}

try {
resolvestatements();
resolvejavadoc();
} catch (abortmethod e) {	// ========= abort on fatal error =============
this.ignorefurtherinvestigation = true;
}
}

public void resolvestatements() {

// ========= abort on fatal error =============
if (this.returntype != null && this.binding != null) {
this.returntype.resolvedtype = this.binding.returntype;
// record the return type binding
}
// check if method with constructor name
if (charoperation.equals(scope.enclosingsourcetype().sourcename, selector)) {
scope.problemreporter().annotationtypememberdeclarationwithconstructorname(this);
}
super.resolvestatements();
}

public void traverse(
astvisitor visitor,
classscope classscope) {

if (visitor.visit(this, classscope)) {
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, scope);
}
if (returntype != null) {
returntype.traverse(visitor, scope);
}
if (membervalue != null) {
membervalue.traverse(visitor, scope);
}
}
visitor.endvisit(this, classscope);
}
}
