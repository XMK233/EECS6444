/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.lang.reflect.field;

import org.eclipse.jdt.core.compiler.charoperation;

public class problemreferencebinding extends referencebinding {
referencebinding closestmatch;
private int problemreason;

// note: must only answer the subset of the name related to the problem

public problemreferencebinding(char[][] compoundname, referencebinding closestmatch, int problemreason) {
this.compoundname = compoundname;
this.closestmatch = closestmatch;
this.problemreason = problemreason;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#closestmatch()
*/
public typebinding closestmatch() {
return this.closestmatch;
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#closestmatch()
*/
public referencebinding closestreferencematch() {
return this.closestmatch;
}

/* api
* answer the problem id associated with the receiver.
* noerror if the receiver is a valid binding.
*/
public int problemid() {
return this.problemreason;
}

public static string problemreasonstring(int problemreason) {
try {
class reasons = problemreasons.class;
string simplename = reasons.getname();
int lastdot = simplename.lastindexof('.');
if (lastdot >= 0) {
simplename = simplename.substring(lastdot+1);
}
field[] fields = reasons.getfields();
for (int i = 0, length = fields.length; i < length; i++) {
field field = fields[i];
if (!field.gettype().equals(int.class)) continue;
if (field.getint(reasons) == problemreason) {
return simplename + '.' + field.getname();
}
}
} catch (illegalaccessexception e) {
// do nothing
}
return "unknown"; //$non-nls-1$
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.referencebinding#shortreadablename()
*/
public char[] shortreadablename() {
return readablename();
}

public string tostring() {
stringbuffer buffer = new stringbuffer(10);
buffer.append("problemtype:[compoundname="); //$non-nls-1$
buffer.append(this.compoundname == null ? "<null>" : new string(charoperation.concatwith(this.compoundname,'.'))); //$non-nls-1$
buffer.append("][problemid=").append(problemreasonstring(this.problemreason)); //$non-nls-1$
buffer.append("][closestmatch="); //$non-nls-1$
buffer.append(this.closestmatch == null ? "<null>" : this.closestmatch.tostring()); //$non-nls-1$
buffer.append("]"); //$non-nls-1$
return buffer.tostring();
}
}
