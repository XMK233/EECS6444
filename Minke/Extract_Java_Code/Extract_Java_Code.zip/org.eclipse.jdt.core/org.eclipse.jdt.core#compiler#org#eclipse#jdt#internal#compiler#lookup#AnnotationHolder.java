/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

public class annotationholder {
annotationbinding[] annotations;

static annotationholder storeannotations(annotationbinding[] annotations, annotationbinding[][] parameterannotations, object defaultvalue, lookupenvironment optionalenv) {
if (parameterannotations != null) {
boolean isempty = true;
for (int i = parameterannotations.length; isempty && --i >= 0;)
if (parameterannotations[i] != null && parameterannotations[i].length > 0)
isempty = false;
if (isempty)
parameterannotations = null; // does not have any
}

if (defaultvalue != null)
return new annotationmethodholder(annotations, parameterannotations, defaultvalue, optionalenv);
if (parameterannotations != null)
return new methodholder(annotations, parameterannotations);
return new annotationholder().setannotations(annotations);
}

annotationbinding[] getannotations() {
return this.annotations;
}
object getdefaultvalue() {
return null;
}
public annotationbinding[][] getparameterannotations() {
return null;
}
annotationbinding[] getparameterannotations(int paramindex) {
return binding.no_annotations;
}
annotationholder setannotations(annotationbinding[] annotations) {
if (annotations == null || annotations.length == 0)
return null; // no longer needed

this.annotations = annotations;
return this;
}

static class methodholder extends annotationholder {
annotationbinding[][] parameterannotations; // is null if empty

methodholder(annotationbinding[] annotations, annotationbinding[][] parameterannotations) {
super();
setannotations(annotations);
this.parameterannotations = parameterannotations;
}
public annotationbinding[][] getparameterannotations() {
return this.parameterannotations;
}
annotationbinding[] getparameterannotations(int paramindex) {
annotationbinding[] result = this.parameterannotations == null ? null : this.parameterannotations[paramindex];
return result == null ? binding.no_annotations : result;
}
annotationholder setannotations(annotationbinding[] annotations) {
this.annotations = annotations == null || annotations.length == 0 ? binding.no_annotations : annotations;
return this;
}
}

static class annotationmethodholder extends methodholder {
object defaultvalue;
lookupenvironment env;

annotationmethodholder(annotationbinding[] annotations, annotationbinding[][] parameterannotations, object defaultvalue, lookupenvironment optionalenv) {
super(annotations, parameterannotations);
this.defaultvalue = defaultvalue;
this.env = optionalenv;
}
object getdefaultvalue() {
if (this.defaultvalue instanceof unresolvedreferencebinding) {
if (this.env == null)
throw new illegalstateexception();
this.defaultvalue = ((unresolvedreferencebinding) this.defaultvalue).resolve(this.env, false);
}
return this.defaultvalue;
}
}
}
