/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.compilationunitdeclaration;
import org.eclipse.jdt.internal.compiler.ast.javadocsinglenamereference;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.parser.javadoctagconstants;

public class completiononjavadoctag extends javadocsinglenamereference implements javadoctagconstants, completiononjavadoc {
public int completionflags = javadoc;
public final static char[][][] no_char_char_char = new char[0][][];
private char[][][] possibletags = no_char_char_char;

public completiononjavadoctag(char[] source, long pos, int tagstart, int tagend, char[][][] possibletags, boolean orphan) {
super(source, pos, tagstart, tagend);
this.possibletags = possibletags;
if (orphan) this.completionflags |= all_possible_tags;
}

/**
* @@param flags the completionflags to set.
*/
public void addcompletionflags(int flags) {
this.completionflags |= flags;
}

/**
* get completion node flags.
*
* @@return int flags of the javadoc completion node.
*/
public int getcompletionflags() {
return this.completionflags;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.allocationexpression#printexpression(int, java.lang.stringbuffer)
*/
public stringbuffer printexpression(int indent, stringbuffer output) {
output.append("<completeonjavadoctag:"); //$non-nls-1$
output.append('@@');
if (this.token != null) super.printexpression(indent, output);
// print block tags
char[][] blocktags = this.possibletags[block_idx];
if (blocktags != null) {
int length=blocktags.length;
if (length > 0) {
output.append("\npossible block tags:"); //$non-nls-1$
for (int i=0; i<length; i++) {
output.append("\n	- "); //$non-nls-1$
output.append(blocktags[i]);
}
output.append('\n');
}
}
// print inline tags
char[][] inlinetags = this.possibletags[inline_idx];
if (inlinetags != null) {
int length=inlinetags.length;
if (length > 0) {
output.append("\npossible inline tags:"); //$non-nls-1$
for (int i=0; i<length; i++) {
output.append("\n	- "); //$non-nls-1$
output.append(inlinetags[i]);
}
output.append('\n');
}
}
return output.append('>');
}

public void filterpossibletags(scope scope) {
if (this.possibletags == null || this.possibletags.length == 0 || (this.completionflags & all_possible_tags) != 0) {
return;
}
int kind = scope.kind;
char[][] specifiedtags = null;
switch (kind) {
case scope.compilation_unit_scope:
// bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=255752
// check for fake_type_name to allow proposals (@@see completionparser#consumecompilationunit)
compilationunitdeclaration compilationunit = scope.referencecompilationunit();
if (compilationunit != null &&
(compilationunit.types.length > 0 && compilationunit.types[0].name == completionparser.fake_type_name)) {
specifiedtags = class_tags;
} else {
specifiedtags = compilation_unit_tags;
}
break;
case scope.class_scope:
specifiedtags = class_tags;
break;
case scope.method_scope:
methodscope methodscope = (methodscope) scope;
if (methodscope.referencemethod() == null) {
if (methodscope.initializedfield == null) {
specifiedtags = package_tags;
} else {
specifiedtags = field_tags;
}
} else {
specifiedtags = method_tags;
}
break;
default:
return;
}
int kinds = this.possibletags.length;
for (int k=0; k<kinds; k++) {
int length = this.possibletags[k].length;
int speclenth = specifiedtags.length;
char[][] filteredtags = new char[length][];
int size = 0;
for (int i=0; i<length; i++) {
char[] possibletag = this.possibletags[k][i];
for (int j=0; j<speclenth; j++) {
if (possibletag[0] == specifiedtags[j][0] && charoperation.equals(possibletag, specifiedtags[j])) {
if (possibletag == tag_param) {
switch (scope.kind) {
case scope.class_scope:
if (scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
if (((classscope)scope).referencecontext.binding.isgenerictype()) {
filteredtags[size++] = possibletag;
}
}
break;
case scope.compilation_unit_scope:
if (scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
filteredtags[size++] = possibletag;
}
break;
default:
filteredtags[size++] = possibletag;
break;
}
} else {
filteredtags[size++] = possibletag;
}
break;
}
}
}
if (size<length) {
system.arraycopy(filteredtags, 0, this.possibletags[k] = new char[size][], 0, size);
}
}
}

/**
* return possible block tags
*
* @@return char[][]
*/
public char[][] getpossibleblocktags() {
return this.possibletags[block_idx];
}

/**
* return possible inline tags
*
* @@return char[][]
*/
public char[][] getpossibleinlinetags() {
return this.possibletags[inline_idx];
}
}
