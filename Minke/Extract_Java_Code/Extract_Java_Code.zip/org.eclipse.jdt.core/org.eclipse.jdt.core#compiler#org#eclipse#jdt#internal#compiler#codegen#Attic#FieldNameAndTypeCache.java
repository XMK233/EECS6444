/*******************************************************************************
* copyright (c) 2000, 2006 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;

public class fieldnameandtypecache {
public fieldbinding keytable[];
public int valuetable[];
int elementsize;
int threshold;
/**
* constructs a new, empty hashtable. a default capacity is used.
* note that the hashtable will automatically grow when it gets full.
*/
public fieldnameandtypecache() {
this(13);
}
/**
* constructs a new, empty hashtable with the specified initial
* capacity.
* @@param initialcapacity int
*	the initial number of buckets
*/
public fieldnameandtypecache(int initialcapacity) {
this.elementsize = 0;
this.threshold = (int) (initialcapacity * 0.66f);
this.keytable = new fieldbinding[initialcapacity];
this.valuetable = new int[initialcapacity];
}
/**
* clears the hash table so that it has no more elements in it.
*/
public void clear() {
for (int i = keytable.length; --i >= 0;) {
keytable[i] = null;
valuetable[i] = 0;
}
elementsize = 0;
}
/** returns true if the collection contains an element for the key.
*
* @@param key char[] the key that we are looking for
* @@return boolean
*/
public boolean containskey(fieldbinding key) {
int index = hashcode(key), length = keytable.length;
while (keytable[index] != null) {
if (equalsfornameandtype(keytable[index], key))
return true;
if (++index == length) {
index = 0;
}
}
return false;
}
/**
* return true if the two field binding are consider like equals.
*/
public boolean equalsfornameandtype(fieldbinding field1, fieldbinding field2) {
return ((field1.type == field2.type) && charoperation.equals(field1.name, field2.name));
}
/** gets the object associated with the specified key in the
* hashtable.
* @@param key <code>char[]</code> the specified key
* @@return int the element for the key or -1 if the key is not
*	defined in the hash table.
*/
public int get(fieldbinding key) {
int index = hashcode(key), length = keytable.length;
while (keytable[index] != null) {
if (equalsfornameandtype(keytable[index], key))
return valuetable[index];
if (++index == length) {
index = 0;
}
}
return -1;
}
/**
* return the hashcode for the key parameter
*
* @@param key org.eclipse.jdt.internal.compiler.lookup.methodbinding
* @@return int
*/
public int hashcode(fieldbinding key) {
return ((charoperation.hashcode(key.name) + key.type.hashcode()) & 0x7fffffff) % keytable.length;
}
/**
* puts the specified element into the hashtable, using the specified
* key.  the element may be retrieved by doing a get() with the same key.
* the key and the element cannot be null.
*
* @@param key <code>object</code> the specified key in the hashtable
* @@param value <code>int</code> the specified element
* @@return int the old value of the key, or -1 if it did not have one.
*/
public int put(fieldbinding key, int value) {
int index = hashcode(key), length = keytable.length;
while (keytable[index] != null) {
if (equalsfornameandtype(keytable[index], key))
return valuetable[index] = value;
if (++index == length) {
index = 0;
}
}
keytable[index] = key;
valuetable[index] = value;

// assumes the threshold is never equal to the size of the table
if (++elementsize > threshold)
rehash();
return value;
}
/**
* rehashes the content of the table into a bigger table.
* this method is called automatically when the hashtable's
* size exceeds the threshold.
*/
private void rehash() {
fieldnameandtypecache newhashtable = new fieldnameandtypecache(keytable.length * 2);
for (int i = keytable.length; --i >= 0;)
if (keytable[i] != null)
newhashtable.put(keytable[i], valuetable[i]);

this.keytable = newhashtable.keytable;
this.valuetable = newhashtable.valuetable;
this.threshold = newhashtable.threshold;
}
/**
* returns the number of elements contained in the hashtable.
*
* @@return <code>int</code> the size of the table
*/
public int size() {
return elementsize;
}
/**
* converts to a rather lengthy string.
*
* @@return string the ascii representation of the receiver
*/
public string tostring() {
int max = size();
stringbuffer buf = new stringbuffer();
buf.append("{"); //$non-nls-1$
for (int i = 0; i < max; ++i) {
if (keytable[i] != null) {
buf.append(keytable[i]).append("->").append(valuetable[i]); //$non-nls-1$
}
if (i < max) {
buf.append(", "); //$non-nls-1$
}
}
buf.append("}"); //$non-nls-1$
return buf.tostring();
}
}
