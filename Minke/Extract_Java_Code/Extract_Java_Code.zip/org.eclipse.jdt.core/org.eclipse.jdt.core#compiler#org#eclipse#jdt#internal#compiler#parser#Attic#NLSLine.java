/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser;

import java.util.arraylist;
import java.util.iterator;
import java.util.list;
import org.eclipse.jdt.internal.compiler.ast.stringliteral;

public class nlsline {

public list elements;
public int remainingelementssize;

public nlsline() {
this.elements = new arraylist();
}

/**
* adds a nls element to this line.
*/
public void add(stringliteral element) {
this.elements.add(element);
this.remainingelementssize++;
}

public stringliteral get(int index) {
return (stringliteral) this.elements.get(index);
}

public void set(int index, stringliteral literal) {
this.elements.set(index, literal);
this.remainingelementssize--;
}

public int size(){
return this.elements.size();
}

public void clear() {
this.elements.clear();
}

public string tostring() {
stringbuffer result= new stringbuffer();
for (iterator iter= iterator(); iter.hasnext(); ) {
result.append("\t"); //$non-nls-1$
result.append(iter.next().tostring());
result.append("\n"); //$non-nls-1$
}
return result.tostring();
}

/**
* returns an iterator over nlselements
*/
public iterator iterator() {
return this.elements.iterator();
}
}
