/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;

public class completiononfieldname extends fielddeclaration {
private static final char[] fakenamesuffix = " ".tochararray(); //$non-nls-1$
public char[] realname;
public completiononfieldname(char[] name, int sourcestart, int sourceend) {
super(charoperation.concat(name, fakenamesuffix), sourcestart, sourceend);
this.realname = name;
}

public stringbuffer printstatement(int tab, stringbuffer output) {

printindent(tab, output).append("<completeonfieldname:"); //$non-nls-1$
if (this.type != null) this.type.print(0, output).append(' ');
output.append(this.realname);
if (this.initialization != null) {
output.append(" = "); //$non-nls-1$
this.initialization.printexpression(0, output);
}
return output.append(">;"); //$non-nls-1$
}

public void resolve(methodscope initializationscope) {
super.resolve(initializationscope);

throw new completionnodefound(this, initializationscope);
}
}

