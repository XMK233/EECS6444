/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.antadapter;

import java.text.messageformat;
import java.util.locale;
import java.util.missingresourceexception;
import java.util.resourcebundle;

public class antadaptermessages {

private static final string bundle_name = "org.eclipse.jdt.internal.antadapter.messages"; //$non-nls-1$

private static resourcebundle resource_bundle;

static {
try {
resource_bundle = resourcebundle.getbundle(bundle_name, locale.getdefault());
} catch(missingresourceexception e) {
system.out.println("missing resource : " + bundle_name.replace('.', '/') + ".properties for locale " + locale.getdefault()); //$non-nls-1$//$non-nls-2$
throw e;
}
}

private antadaptermessages() {
// cannot be instantiated
}

public static string getstring(string key) {
try {
return resource_bundle.getstring(key);
} catch (missingresourceexception e) {
return '!' + key + '!';
}
}

public static string getstring(string key, string argument) {
try {
string message = resource_bundle.getstring(key);
messageformat messageformat = new messageformat(message);
return messageformat.format(new string[] { argument } );
} catch (missingresourceexception e) {
return '!' + key + '!';
}
}
}
