/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

/*
* selection node build by the parser in any case it was intending to
* reduce an explicit constructor call containing the cursor.
* e.g.
*
*	class x {
*    void foo() {
*      y.[start]super[end](1, 2)
*    }
*  }
*
*	---> class x {
*         void foo() {
*           <selectonexplicitconstructorcall:y.super(1, 2)>
*         }
*       }
*
*/

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class selectiononexplicitconstructorcall extends explicitconstructorcall {

public selectiononexplicitconstructorcall(int accessmode) {

super(accessmode);
}

public stringbuffer printstatement(int tab, stringbuffer output) {

printindent(tab, output);
output.append("<selectonexplicitconstructorcall:"); //$non-nls-1$
if (this.qualification != null) this.qualification.printexpression(0, output).append('.');
if (this.accessmode == this) {
output.append("this("); //$non-nls-1$
} else {
output.append("super("); //$non-nls-1$
}
if (this.arguments != null) {
for (int i = 0; i < this.arguments.length; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.arguments[i].printexpression(0, output);
}
}
return output.append(")>;"); //$non-nls-1$
}

public void resolve(blockscope scope) {

super.resolve(scope);

// tolerate some error cases
if (this.binding == null ||
!(this.binding.isvalidbinding() ||
this.binding.problemid() == problemreasons.notvisible))
throw new selectionnodefound();
else
throw new selectionnodefound(this.binding);
}
}
