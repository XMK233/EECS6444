/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;

public class verificationtypeinfo {
/**
* the tag value representing top variable info
* @@since 3.2
*/
public static final int item_top = 0;
/**
* the tag value representing integer variable info
* @@since 3.2
*/
public static final int item_integer = 1;
/**
* the tag value representing float variable info
* @@since 3.2
*/
public static final int item_float = 2;
/**
* the tag value representing double variable info
* @@since 3.2
*/
public static final int item_double = 3;
/**
* the tag value representing long variable info
* @@since 3.2
*/
public static final int item_long = 4;
/**
* the tag value representing null variable info
* @@since 3.2
*/
public static final int item_null = 5;
/**
* the tag value representing uninitialized this variable info
* @@since 3.2
*/
public static final int item_uninitialized_this = 6;
/**
* the tag value representing object variable info
* @@since 3.2
*/
public static final int item_object = 7;
/**
* the tag value representing uninitialized variable info
* @@since 3.2
*/
public static final int item_uninitialized = 8;

public int tag;
private int id;
private char[] constantpoolname;
public int offset;

private verificationtypeinfo() {
// for duplication
}
public verificationtypeinfo(int id, char[] constantpoolname) {
this(id, verificationtypeinfo.item_object, constantpoolname);
}
public verificationtypeinfo(int id, int tag, char[] constantpoolname) {
this.id = id;
this.tag = tag;
this.constantpoolname = constantpoolname;
}
public verificationtypeinfo(int tag, typebinding binding) {
this(binding);
this.tag = tag;
}
public verificationtypeinfo(typebinding binding) {
this.id = binding.id;
switch(binding.id) {
case typeids.t_boolean :
case typeids.t_byte :
case typeids.t_char :
case typeids.t_int :
case typeids.t_short :
this.tag = verificationtypeinfo.item_integer;
break;
case typeids.t_float :
this.tag = verificationtypeinfo.item_float;
break;
case typeids.t_long :
this.tag = verificationtypeinfo.item_long;
break;
case typeids.t_double :
this.tag = verificationtypeinfo.item_double;
break;
case typeids.t_null :
this.tag = verificationtypeinfo.item_null;
break;
default:
this.tag =  verificationtypeinfo.item_object;
this.constantpoolname = binding.constantpoolname();
}
}
public void setbinding(typebinding binding) {
this.constantpoolname = binding.constantpoolname();
final int typebindingid = binding.id;
this.id = typebindingid;
switch(typebindingid) {
case typeids.t_boolean :
case typeids.t_byte :
case typeids.t_char :
case typeids.t_int :
case typeids.t_short :
this.tag = verificationtypeinfo.item_integer;
break;
case typeids.t_float :
this.tag = verificationtypeinfo.item_float;
break;
case typeids.t_long :
this.tag = verificationtypeinfo.item_long;
break;
case typeids.t_double :
this.tag = verificationtypeinfo.item_double;
break;
case typeids.t_null :
this.tag = verificationtypeinfo.item_null;
break;
default:
this.tag =  verificationtypeinfo.item_object;
}
}
public int id() {
return this.id;
}
public string tostring() {
stringbuffer buffer = new stringbuffer();
switch(this.tag) {
case verificationtypeinfo.item_uninitialized_this :
buffer.append("uninitialized_this(").append(readablename()).append(")"); //$non-nls-1$//$non-nls-2$
break;
case verificationtypeinfo.item_uninitialized :
buffer.append("uninitialized(").append(readablename()).append(")"); //$non-nls-1$//$non-nls-2$
break;
case verificationtypeinfo.item_object :
buffer.append(readablename());
break;
case verificationtypeinfo.item_double :
buffer.append('d');
break;
case verificationtypeinfo.item_float :
buffer.append('f');
break;
case verificationtypeinfo.item_integer :
buffer.append('i');
break;
case verificationtypeinfo.item_long :
buffer.append('j');
break;
case verificationtypeinfo.item_null :
buffer.append("null"); //$non-nls-1$
break;
case verificationtypeinfo.item_top :
buffer.append("top"); //$non-nls-1$
break;
}
return string.valueof(buffer);
}
public verificationtypeinfo duplicate() {
final verificationtypeinfo verificationtypeinfo = new verificationtypeinfo();
verificationtypeinfo.id = this.id;
verificationtypeinfo.tag = this.tag;
verificationtypeinfo.constantpoolname = this.constantpoolname;
verificationtypeinfo.offset = this.offset;
return verificationtypeinfo;
}
public boolean equals(object obj) {
if (obj instanceof verificationtypeinfo) {
verificationtypeinfo info1 = (verificationtypeinfo) obj;
return info1.tag == this.tag && charoperation.equals(info1.constantpoolname(), constantpoolname());
}
return false;
}
public int hashcode() {
return this.tag + this.id + this.constantpoolname.length + this.offset;
}
public char[] constantpoolname() {
return this.constantpoolname;
}
public char[] readablename() {
return this.constantpoolname;
}
public void replacewithelementtype() {
if (this.constantpoolname[1] == 'l') {
this.constantpoolname = charoperation.subarray(this.constantpoolname, 2,  this.constantpoolname.length - 1);
} else {
this.constantpoolname = charoperation.subarray(this.constantpoolname, 1, this.constantpoolname.length);
if (this.constantpoolname.length == 1) {
switch(this.constantpoolname[0]) {
case 'i' :
this.id = typeids.t_int;
break;
case 'b' :
this.id = typeids.t_byte;
break;
case 's' :
this.id = typeids.t_short;
break;
case 'c' :
this.id = typeids.t_char;
break;
case 'j' :
this.id = typeids.t_long;
break;
case 'f' :
this.id = typeids.t_float;
break;
case 'd' :
this.id = typeids.t_double;
break;
case 'z' :
this.id = typeids.t_boolean;
break;
case 'n' :
this.id = typeids.t_null;
break;
case 'v' :
this.id = typeids.t_void;
break;
}
}
}
}
}
