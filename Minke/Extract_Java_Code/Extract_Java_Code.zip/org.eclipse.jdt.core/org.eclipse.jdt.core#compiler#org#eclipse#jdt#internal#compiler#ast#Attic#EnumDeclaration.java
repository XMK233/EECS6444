/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.compilationunitscope;
import org.eclipse.jdt.internal.compiler.problem.aborttype;

/**
* enum declaration
*/
public class enumdeclaration extends typedeclaration {

public enumconstant[] enumconstants;

/**
* @@param compilationresult
*/
public enumdeclaration(compilationresult compilationresult) {
super(compilationresult);
}

public stringbuffer printbody(int indent, stringbuffer output) {

output.append(" {"); //$non-nls-1$
if (enumconstants != null) {
int length = enumconstants.length;
output.append('\n');
for (int i = 0; i < length - 1; i++) {
if (enumconstants[i] != null) {
enumconstants[i].print(indent + 1, output);
output.append(",\n");//$non-nls-1$
}
}
enumconstants[length - 1].print(indent + 1, output);
output.append("\n;\n");//$non-nls-1$
}
if (this.enums != null) {
for (int i = 0; i < this.enums.length; i++) {
if (this.enums[i] != null) {
output.append('\n');
this.enums[i].print(indent + 1, output);
}
}
}
if (membertypes != null) {
for (int i = 0; i < membertypes.length; i++) {
if (membertypes[i] != null) {
output.append('\n');
membertypes[i].print(indent + 1, output);
}
}
}
if (fields != null) {
for (int fieldi = 0; fieldi < fields.length; fieldi++) {
if (fields[fieldi] != null) {
output.append('\n');
fields[fieldi].print(indent + 1, output);
}
}
}
if (methods != null) {
for (int i = 0; i < methods.length; i++) {
if (methods[i] != null) {
output.append('\n');
methods[i].print(indent + 1, output);
}
}
}
output.append('\n');
return printindent(indent, output).append('}');
}

public void traverse(astvisitor visitor, blockscope blockscope) {

if (ignorefurtherinvestigation)
return;
try {
if (visitor.visit(this, blockscope)) {
if (this.typeparameters != null) {
int length = this.typeparameters.length;
for (int i = 0; i < length; i++) {
this.typeparameters[i].traverse(visitor, scope);
}
}
if (this.superclass != null)
this.superclass.traverse(visitor, scope);
if (this.superinterfaces != null) {
int length = this.superinterfaces.length;
for (int i = 0; i < length; i++)
this.superinterfaces[i].traverse(visitor, scope);
}
if (this.membertypes != null) {
int length = this.membertypes.length;
for (int i = 0; i < length; i++)
this.membertypes[i].traverse(visitor, scope);
}
if (this.enums != null) {
int length = this.enums.length;
for (int i = 0; i < length; i++) {
this.enums[i].traverse(visitor, scope);
}
}
if (this.fields != null) {
int length = this.fields.length;
for (int i = 0; i < length; i++) {
fielddeclaration field;
if ((field = this.fields[i]).isstatic()) {
field.traverse(visitor, staticinitializerscope);
} else {
field.traverse(visitor, initializerscope);
}
}
}
if (this.methods != null) {
int length = methods.length;
for (int i = 0; i < length; i++)
this.methods[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, blockscope);
} catch (aborttype e) {
// silent abort
}
}
public void traverse(astvisitor visitor, classscope classscope) {

if (ignorefurtherinvestigation)
return;
try {
if (visitor.visit(this, classscope)) {
if (this.typeparameters != null) {
int typeparameterslength = this.typeparameters.length;
for (int i = 0; i < typeparameterslength; i++) {
this.typeparameters[i].traverse(visitor, scope);
}
}
if (this.superclass != null)
this.superclass.traverse(visitor, scope);
if (this.superinterfaces != null) {
int length = this.superinterfaces.length;
for (int i = 0; i < length; i++)
this.superinterfaces[i].traverse(visitor, scope);
}
if (this.membertypes != null) {
int length = this.membertypes.length;
for (int i = 0; i < length; i++)
this.membertypes[i].traverse(visitor, scope);
}
if (this.enums != null) {
int length = this.enums.length;
for (int i = 0; i < length; i++) {
this.enums[i].traverse(visitor, scope);
}
}
if (this.fields != null) {
int length = this.fields.length;
for (int i = 0; i < length; i++) {
fielddeclaration field;
if ((field = this.fields[i]).isstatic()) {
field.traverse(visitor, staticinitializerscope);
} else {
field.traverse(visitor, initializerscope);
}
}
}
if (this.methods != null) {
int length = this.methods.length;
for (int i = 0; i < length; i++)
this.methods[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, classscope);
} catch (aborttype e) {
// silent abort
}
}

public void traverse(astvisitor visitor, compilationunitscope unitscope) {

if (ignorefurtherinvestigation)
return;
try {
if (visitor.visit(this, unitscope)) {
if (this.typeparameters != null) {
int length = this.typeparameters.length;
for (int i = 0; i < length; i++) {
this.typeparameters[i].traverse(visitor, scope);
}
}
if (this.superclass != null)
this.superclass.traverse(visitor, scope);
if (this.superinterfaces != null) {
int length = this.superinterfaces.length;
for (int i = 0; i < length; i++)
this.superinterfaces[i].traverse(visitor, scope);
}
if (this.membertypes != null) {
int length = this.membertypes.length;
for (int i = 0; i < length; i++)
this.membertypes[i].traverse(visitor, scope);
}
if (this.enums != null) {
int length = this.enums.length;
for (int i = 0; i < length; i++) {
this.enums[i].traverse(visitor, scope);
}
}
if (this.fields != null) {
int length = this.fields.length;
for (int i = 0; i < length; i++) {
fielddeclaration field;
if ((field = this.fields[i]).isstatic()) {
field.traverse(visitor, staticinitializerscope);
} else {
field.traverse(visitor, initializerscope);
}
}
}
if (this.methods != null) {
int length = this.methods.length;
for (int i = 0; i < length; i++)
this.methods[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, unitscope);
} catch (aborttype e) {
// silent abort
}
}
}
