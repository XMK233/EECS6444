/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class dostatement extends statement {

public expression condition;
public statement action;

private branchlabel breaklabel, continuelabel;

// for local variables table attributes
int mergedinitstateindex = -1;
int preconditioninitstateindex = -1;

public dostatement(expression condition, statement action, int sourcestart, int sourceend) {

this.sourcestart = sourcestart;
this.sourceend = sourceend;
this.condition = condition;
this.action = action;
// remember useful empty statement
if (action instanceof emptystatement) action.bits |= astnode.isusefulemptystatement;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
this.breaklabel = new branchlabel();
this.continuelabel = new branchlabel();
loopingflowcontext loopingcontext =
new loopingflowcontext(
flowcontext,
flowinfo,
this,
this.breaklabel,
this.continuelabel,
currentscope);

constant cst = this.condition.constant;
boolean isconditiontrue = cst != constant.notaconstant && cst.booleanvalue() == true;
cst = this.condition.optimizedbooleanconstant();
boolean isconditionoptimizedtrue = cst != constant.notaconstant && cst.booleanvalue() == true;
boolean isconditionoptimizedfalse = cst != constant.notaconstant && cst.booleanvalue() == false;

int previousmode = flowinfo.reachmode();

unconditionalflowinfo actioninfo = flowinfo.nullinfolessunconditionalcopy();
// we need to collect the contribution to nulls of the coming paths through the
// loop, be they falling through normally or branched to break, continue labels
// or catch blocks
if ((this.action != null) && !this.action.isemptyblock()) {
actioninfo = this.action.
analysecode(currentscope, loopingcontext, actioninfo).
unconditionalinits();

// code generation can be optimized when no need to continue in the loop
if ((actioninfo.tagbits &
loopingcontext.initsoncontinue.tagbits &
flowinfo.unreachable) != 0) {
this.continuelabel = null;
}
}
/* reset reach mode, to address following scenario.
*   final blank;
*   do { if (true) break; else blank = 0; } while(false);
*   blank = 1; // may be initialized already
*/
actioninfo.setreachmode(previousmode);

loopingflowcontext condloopcontext;
flowinfo condinfo =
this.condition.analysecode(
currentscope,
(condloopcontext =
new loopingflowcontext(flowcontext,	flowinfo, this, null,
null, currentscope)),
(this.action == null
? actioninfo
: (actioninfo.mergedwith(loopingcontext.initsoncontinue))).copy());
this.preconditioninitstateindex = currentscope.methodscope().recordinitializationstates(actioninfo);
if (!isconditionoptimizedfalse && this.continuelabel != null) {
loopingcontext.complainondeferredfinalchecks(currentscope, condinfo);
condloopcontext.complainondeferredfinalchecks(currentscope, condinfo);
loopingcontext.complainondeferrednullchecks(currentscope,
flowinfo.unconditionalcopy().addpotentialnullinfofrom(
condinfo.initswhentrue().unconditionalinits()));
condloopcontext.complainondeferrednullchecks(currentscope,
actioninfo.addpotentialnullinfofrom(
condinfo.initswhentrue().unconditionalinits()));
}

// end of loop
flowinfo mergedinfo =
flowinfo.mergedoptimizedbranches(
(loopingcontext.initsonbreak.tagbits & flowinfo.unreachable) != 0
? loopingcontext.initsonbreak
: flowinfo.unconditionalcopy().addinitializationsfrom(loopingcontext.initsonbreak),
// recover upstream null info
isconditionoptimizedtrue,
(condinfo.tagbits & flowinfo.unreachable) == 0
? flowinfo.addinitializationsfrom(condinfo.initswhenfalse())
: condinfo,
// recover null inits from before condition analysis
false, // never consider opt false case for do loop, since break can always occur (47776)
!isconditiontrue /*do{}while(true); unreachable(); */);
this.mergedinitstateindex = currentscope.methodscope().recordinitializationstates(mergedinfo);
return mergedinfo;
}

/**
* do statement code generation
*
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & astnode.isreachable) == 0) {
return;
}
int pc = codestream.position;

// labels management
branchlabel actionlabel = new branchlabel(codestream);
if (this.action != null) actionlabel.tagbits |= branchlabel.used;
actionlabel.place();
this.breaklabel.initialize(codestream);
boolean hascontinuelabel = this.continuelabel != null;
if (hascontinuelabel) {
this.continuelabel.initialize(codestream);
}

// generate action
if (this.action != null) {
this.action.generatecode(currentscope, codestream);
}
// continue label (135602)
if (hascontinuelabel) {
this.continuelabel.place();
// may loose some local variable initializations : affecting the local variable attributes
if (this.preconditioninitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.preconditioninitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.preconditioninitstateindex);
}
// generate condition
constant cst = this.condition.optimizedbooleanconstant();
boolean isconditionoptimizedfalse = cst != constant.notaconstant && cst.booleanvalue() == false;
if (isconditionoptimizedfalse){
this.condition.generatecode(currentscope, codestream, false);
} else {
this.condition.generateoptimizedboolean(
currentscope,
codestream,
actionlabel,
null,
true);
}
}
// may loose some local variable initializations : affecting the local variable attributes
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
if (this.breaklabel.forwardreferencecount() > 0) {
this.breaklabel.place();
}

codestream.recordpositionsfrom(pc, this.sourcestart);
}

public stringbuffer printstatement(int indent, stringbuffer output) {
printindent(indent, output).append("do"); //$non-nls-1$
if (this.action == null)
output.append(" ;\n"); //$non-nls-1$
else {
output.append('\n');
this.action.printstatement(indent + 1, output).append('\n');
}
output.append("while ("); //$non-nls-1$
return this.condition.printexpression(0, output).append(");"); //$non-nls-1$
}

public void resolve(blockscope scope) {
typebinding type = this.condition.resolvetypeexpecting(scope, typebinding.boolean);
this.condition.computeconversion(scope, type, type);
if (this.action != null)
this.action.resolve(scope);
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.action != null) {
this.action.traverse(visitor, scope);
}
this.condition.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
