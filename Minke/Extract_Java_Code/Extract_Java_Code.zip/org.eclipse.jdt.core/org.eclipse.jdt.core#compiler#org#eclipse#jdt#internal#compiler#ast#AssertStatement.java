/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.astvisitor;

public class assertstatement extends statement {

public expression assertexpression, exceptionargument;

// for local variable attribute
int preassertinitstateindex = -1;
private fieldbinding assertionsyntheticfieldbinding;

public assertstatement(	expression exceptionargument, expression assertexpression, int startposition) {
this.assertexpression = assertexpression;
this.exceptionargument = exceptionargument;
this.sourcestart = startposition;
this.sourceend = exceptionargument.sourceend;
}

public assertstatement(expression assertexpression, int startposition) {
this.assertexpression = assertexpression;
this.sourcestart = startposition;
this.sourceend = assertexpression.sourceend;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
this.preassertinitstateindex = currentscope.methodscope().recordinitializationstates(flowinfo);

constant cst = this.assertexpression.optimizedbooleanconstant();
boolean isoptimizedtrueassertion = cst != constant.notaconstant && cst.booleanvalue() == true;
boolean isoptimizedfalseassertion = cst != constant.notaconstant && cst.booleanvalue() == false;

flowcontext.tagbits |= flowcontext.hide_null_comparison_warning;
flowinfo conditionflowinfo = this.assertexpression.analysecode(currentscope, flowcontext, flowinfo.copy());
flowcontext.tagbits &= ~flowcontext.hide_null_comparison_warning;
unconditionalflowinfo assertwhentrueinfo = conditionflowinfo.initswhentrue().unconditionalinits();
flowinfo assertinfo = conditionflowinfo.initswhenfalse();
if (isoptimizedtrueassertion) {
assertinfo.setreachmode(flowinfo.unreachable);
}

if (this.exceptionargument != null) {
// only gets evaluated when escaping - results are not taken into account
flowinfo exceptioninfo = this.exceptionargument.analysecode(currentscope, flowcontext, assertinfo.copy());

if (isoptimizedtrueassertion){
currentscope.problemreporter().fakereachable(this.exceptionargument);
} else {
flowcontext.checkexceptionhandlers(
currentscope.getjavalangassertionerror(),
this,
exceptioninfo,
currentscope);
}
}

if (!isoptimizedtrueassertion){
// add the assert support in the clinit
managesyntheticaccessifnecessary(currentscope, flowinfo);
}
if (isoptimizedfalseassertion) {
return flowinfo; // if assertions are enabled, the following code will be unreachable
// change this if we need to carry null analysis results of the assert
// expression downstream
} else {
return flowinfo.mergedwith(assertinfo.nullinfolessunconditionalcopy()).
addinitializationsfrom(assertwhentrueinfo.discardinitializationinfo());
// keep the merge from the initial code for the definite assignment
// analysis, tweak the null part to influence nulls downstream
}
}

public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & isreachable) == 0) {
return;
}
int pc = codestream.position;

if (this.assertionsyntheticfieldbinding != null) {
branchlabel assertionactivationlabel = new branchlabel(codestream);
codestream.fieldaccess(opcodes.opc_getstatic, this.assertionsyntheticfieldbinding, null /* default declaringclass */);
codestream.ifne(assertionactivationlabel);

branchlabel falselabel;
this.assertexpression.generateoptimizedboolean(currentscope, codestream, (falselabel = new branchlabel(codestream)), null , true);
codestream.newjavalangassertionerror();
codestream.dup();
if (this.exceptionargument != null) {
this.exceptionargument.generatecode(currentscope, codestream, true);
codestream.invokejavalangassertionerrorconstructor(this.exceptionargument.implicitconversion & 0xf);
} else {
codestream.invokejavalangassertionerrordefaultconstructor();
}
codestream.athrow();

// may loose some local variable initializations : affecting the local variable attributes
if (this.preassertinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.preassertinitstateindex);
}
falselabel.place();
assertionactivationlabel.place();
} else {
// may loose some local variable initializations : affecting the local variable attributes
if (this.preassertinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.preassertinitstateindex);
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public void resolve(blockscope scope) {
this.assertexpression.resolvetypeexpecting(scope, typebinding.boolean);
if (this.exceptionargument != null) {
typebinding exceptionargumenttype = this.exceptionargument.resolvetype(scope);
if (exceptionargumenttype != null){
int id = exceptionargumenttype.id;
switch(id) {
case t_void :
scope.problemreporter().illegalvoidexpression(this.exceptionargument);
//$fall-through$
default:
id = t_javalangobject;
//$fall-through$
case t_boolean :
case t_byte :
case t_char :
case t_short :
case t_double :
case t_float :
case t_int :
case t_long :
case t_javalangstring :
this.exceptionargument.implicitconversion = (id << 4) + id;
}
}
}
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
this.assertexpression.traverse(visitor, scope);
if (this.exceptionargument != null) {
this.exceptionargument.traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}

public void managesyntheticaccessifnecessary(blockscope currentscope, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0) {
// need assertion flag: $assertionsdisabled on outer most source clas
// (in case of static member of interface, will use the outermost static member - bug 22334)
sourcetypebinding outermostclass = currentscope.enclosingsourcetype();
while (outermostclass.islocaltype()) {
referencebinding enclosing = outermostclass.enclosingtype();
if (enclosing == null || enclosing.isinterface()) break;
outermostclass = (sourcetypebinding) enclosing;
}
this.assertionsyntheticfieldbinding = outermostclass.addsyntheticfieldforassert(currentscope);

// find <clinit> and enable assertion support
typedeclaration typedeclaration = outermostclass.scope.referencetype();
abstractmethoddeclaration[] methods = typedeclaration.methods;
for (int i = 0, max = methods.length; i < max; i++) {
abstractmethoddeclaration method = methods[i];
if (method.isclinit()) {
((clinit) method).setassertionsupport(this.assertionsyntheticfieldbinding, currentscope.compileroptions().sourcelevel < classfileconstants.jdk1_5);
break;
}
}
}
}

public stringbuffer printstatement(int tab, stringbuffer output) {
printindent(tab, output);
output.append("assert "); //$non-nls-1$
this.assertexpression.printexpression(0, output);
if (this.exceptionargument != null) {
output.append(": "); //$non-nls-1$
this.exceptionargument.printexpression(0, output);
}
return output.append(';');
}
}
