/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class unaryexpression extends operatorexpression {

public expression expression;
public constant optimizedbooleanconstant;

public unaryexpression(expression expression, int operator) {
this.expression = expression;
this.bits |= operator << operatorshift; // encode operator
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {
this.expression.checknpe(currentscope, flowcontext, flowinfo);
if (((this.bits & operatormask) >> operatorshift) == not) {
return this.expression.
analysecode(currentscope, flowcontext, flowinfo).
asnegatedcondition();
} else {
return this.expression.
analysecode(currentscope, flowcontext, flowinfo);
}
}

public constant optimizedbooleanconstant() {

return this.optimizedbooleanconstant == null
? this.constant
: this.optimizedbooleanconstant;
}

/**
* code generation for an unary operation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(
blockscope currentscope,
codestream codestream,
boolean valuerequired) {

int pc = codestream.position;
branchlabel falselabel, endiflabel;
if (this.constant != constant.notaconstant) {
// inlined value
if (valuerequired) {
codestream.generateconstant(this.constant, this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
switch ((this.bits & operatormask) >> operatorshift) {
case not :
switch ((this.expression.implicitconversion & implicit_conversion_mask) >> 4) /* runtime type */ {
case t_boolean :
// ! <boolean>
// generate code for the condition
this.expression.generateoptimizedboolean(
currentscope,
codestream,
null,
(falselabel = new branchlabel(codestream)),
valuerequired);
if (valuerequired) {
codestream.iconst_0();
if (falselabel.forwardreferencecount() > 0) {
codestream.goto_(endiflabel = new branchlabel(codestream));
codestream.decrstacksize(1);
falselabel.place();
codestream.iconst_1();
endiflabel.place();
}
} else { // 6596: if (!(a && b)){} - must still place falselabel
falselabel.place();
}
break;
}
break;
case twiddle :
switch ((this.expression.implicitconversion & implicit_conversion_mask) >> 4 /* runtime */) {
case t_int :
// ~int
this.expression.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
codestream.iconst_m1();
codestream.ixor();
}
break;
case t_long :
this.expression.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
codestream.ldc2_w(-1l);
codestream.lxor();
}
}
break;
case minus :
// - <num>
if (this.constant != constant.notaconstant) {
if (valuerequired) {
switch ((this.expression.implicitconversion & implicit_conversion_mask) >> 4){ /* runtime */
case t_int :
codestream.generateinlinedvalue(this.constant.intvalue() * -1);
break;
case t_float :
codestream.generateinlinedvalue(this.constant.floatvalue() * -1.0f);
break;
case t_long :
codestream.generateinlinedvalue(this.constant.longvalue() * -1l);
break;
case t_double :
codestream.generateinlinedvalue(this.constant.doublevalue() * -1.0);
}
}
} else {
this.expression.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
switch ((this.expression.implicitconversion & implicit_conversion_mask) >> 4){ /* runtime type */
case t_int :
codestream.ineg();
break;
case t_float :
codestream.fneg();
break;
case t_long :
codestream.lneg();
break;
case t_double :
codestream.dneg();
}
}
}
break;
case plus :
this.expression.generatecode(currentscope, codestream, valuerequired);
}
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* boolean operator code generation
*	optimized operations are: &&, ||, <, <=, >, >=, &, |, ^
*/
public void generateoptimizedboolean(
blockscope currentscope,
codestream codestream,
branchlabel truelabel,
branchlabel falselabel,
boolean valuerequired) {

if ((this.constant != constant.notaconstant) && (this.constant.typeid() == t_boolean)) {
super.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
return;
}
if (((this.bits & operatormask) >> operatorshift) == not) {
this.expression.generateoptimizedboolean(
currentscope,
codestream,
falselabel,
truelabel,
valuerequired);
} else {
super.generateoptimizedboolean(
currentscope,
codestream,
truelabel,
falselabel,
valuerequired);
}
}

public stringbuffer printexpressionnoparenthesis(int indent, stringbuffer output) {

output.append(operatortostring()).append(' ');
return this.expression.printexpression(0, output);
}

public typebinding resolvetype(blockscope scope) {
boolean expressioniscast;
if ((expressioniscast = this.expression instanceof castexpression) == true) this.expression.bits |= disableunnecessarycastcheck; // will check later on
typebinding expressiontype = this.expression.resolvetype(scope);
if (expressiontype == null) {
this.constant = constant.notaconstant;
return null;
}
int expressiontypeid = expressiontype.id;
// autoboxing support
boolean use15specifics = scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
if (use15specifics) {
if (!expressiontype.isbasetype()) {
expressiontypeid = scope.environment().computeboxingtype(expressiontype).id;
}
}
if (expressiontypeid > 15) {
this.constant = constant.notaconstant;
scope.problemreporter().invalidoperator(this, expressiontype);
return null;
}

int tableid;
switch ((this.bits & operatormask) >> operatorshift) {
case not :
tableid = and_and;
break;
case twiddle :
tableid = left_shift;
break;
default :
tableid = minus;
} //+ and - cases

// the code is an int
// (cast)  left   op (cast)  rigth --> result
//  0000   0000       0000   0000      0000
//  <<16   <<12       <<8    <<4       <<0
int operatorsignature = operatorsignatures[tableid][(expressiontypeid << 4) + expressiontypeid];
this.expression.computeconversion(scope, typebinding.wellknowntype(scope, (operatorsignature >>> 16) & 0x0000f), expressiontype);
this.bits |= operatorsignature & 0xf;
switch (operatorsignature & 0xf) { // only switch on possible result type.....
case t_boolean :
this.resolvedtype = typebinding.boolean;
break;
case t_byte :
this.resolvedtype = typebinding.byte;
break;
case t_char :
this.resolvedtype = typebinding.char;
break;
case t_double :
this.resolvedtype = typebinding.double;
break;
case t_float :
this.resolvedtype = typebinding.float;
break;
case t_int :
this.resolvedtype = typebinding.int;
break;
case t_long :
this.resolvedtype = typebinding.long;
break;
default : //error........
this.constant = constant.notaconstant;
if (expressiontypeid != t_undefined)
scope.problemreporter().invalidoperator(this, expressiontype);
return null;
}
// compute the constant when valid
if (this.expression.constant != constant.notaconstant) {
this.constant =
constant.computeconstantoperation(
this.expression.constant,
expressiontypeid,
(this.bits & operatormask) >> operatorshift);
} else {
this.constant = constant.notaconstant;
if (((this.bits & operatormask) >> operatorshift) == not) {
constant cst = this.expression.optimizedbooleanconstant();
if (cst != constant.notaconstant)
this.optimizedbooleanconstant = booleanconstant.fromvalue(!cst.booleanvalue());
}
}
if (expressioniscast) {
// check need for operand cast
castexpression.checkneedforargumentcast(scope, tableid, operatorsignature, this.expression, expressiontypeid);
}
return this.resolvedtype;
}

public void traverse(
astvisitor visitor,
blockscope blockscope) {

if (visitor.visit(this, blockscope)) {
this.expression.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}
}
