/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

import org.eclipse.jdt.internal.compiler.env.*;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.core.compiler.*;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.*;
import org.eclipse.jdt.internal.compiler.problem.*;
import org.eclipse.jdt.internal.core.util.commentrecorderparser;

/**
* a source element parser extracts structural and reference information
* from a piece of source.
*
* also see @@isourceelementrequestor
*
* the structural investigation includes:
* - the package statement
* - import statements
* - top-level types: package member, member types (member types of member types...)
* - fields
* - methods
*
* if reference information is requested, then all source constructs are
* investigated and type, field & method references are provided as well.
*
* any (parsing) problem encountered is also provided.
*/
public class sourceelementparser extends commentrecorderparser {

isourceelementrequestor requestor;
int fieldcount;
isourcetype sourcetype;
boolean reportreferenceinfo;
char[][] typenames;
char[][] supertypenames;
int nestedtypeindex;
static final char[] java_lang_object = "java.lang.object".tochararray(); //$non-nls-1$
namereference[] unknownrefs;
int unknownrefscounter;
localdeclarationvisitor localdeclarationvisitor = null;
compileroptions options;

/**
* an ast visitor that visits local type declarations.
*/
public class localdeclarationvisitor extends astvisitor {
public boolean visit(typedeclaration typedeclaration, blockscope scope) {
notifysourceelementrequestor(typedeclaration, sourcetype == null);
return false; // don't visit members as this was done during notifysourceelementrequestor(...)
}
public boolean visit(typedeclaration typedeclaration, classscope scope) {
notifysourceelementrequestor(typedeclaration, sourcetype == null);
return false; // don't visit members as this was done during notifysourceelementrequestor(...)
}

}

public sourceelementparser(
final isourceelementrequestor requestor,
iproblemfactory problemfactory,
compileroptions options) {
// we want to notify all syntax error with the acceptproblem api
// to do so, we define the record method of the problemreporter
super(new problemreporter(
defaulterrorhandlingpolicies.exitafterallproblems(),
options,
problemfactory) {
public void record(iproblem problem, compilationresult unitresult, referencecontext context) {
unitresult.record(problem, context); // todo (jerome) clients are trapping problems either through factory or requestor... is result storing needed?
requestor.acceptproblem(problem);
}
},
true);
this.requestor = requestor;
typenames = new char[4][];
supertypenames = new char[4][];
nestedtypeindex = 0;
this.options = options;
}

public sourceelementparser(
final isourceelementrequestor requestor,
iproblemfactory problemfactory,
compileroptions options,
boolean reportlocaldeclarations) {
this(requestor, problemfactory, options);
if (reportlocaldeclarations) {
this.localdeclarationvisitor = new localdeclarationvisitor();
}
}

public void checkcomment() {
if (this.currentelement != null && this.scanner.commentptr >= 0) {
flushcommentsdefinedpriorto(this.endstatementposition); // discard obsolete comments during recovery
}

int lastcomment = this.scanner.commentptr;

if (this.modifierssourcestart >= 0) {
// eliminate comments located after modifiersourcestart if positionned
while (lastcomment >= 0 && math.abs(this.scanner.commentstarts[lastcomment]) > this.modifierssourcestart) lastcomment--;
}
if (lastcomment >= 0) {
// consider all remaining leading comments to be part of current declaration
this.modifierssourcestart = math.abs(this.scanner.commentstarts[0]);

// check deprecation in last comment if javadoc (can be followed by non-javadoc comments which are simply ignored)
while (lastcomment >= 0 && this.scanner.commentstops[lastcomment] < 0) lastcomment--; // non javadoc comment have negative end positions
if (lastcomment >= 0 && this.javadocparser != null) {
if (this.javadocparser.checkdeprecation(
this.scanner.commentstarts[lastcomment],
this.scanner.commentstops[lastcomment] - 1)) { //stop is one over,
checkandsetmodifiers(accdeprecated);
}
this.javadoc = this.javadocparser.doccomment;	// null if check javadoc is not activated
}
}

if (this.reportreferenceinfo && this.javadocparser.checkdoccomment && this.javadoc != null) {
// report reference info in javadoc comment @@throws/@@exception tags
typereference[] thrownexceptions = this.javadoc.thrownexceptions;
int throwstagsnbre = thrownexceptions == null ? 0 : thrownexceptions.length;
for (int i = 0; i < throwstagsnbre; i++) {
typereference typeref = thrownexceptions[i];
if (typeref instanceof javadocsingletypereference) {
javadocsingletypereference singleref = (javadocsingletypereference) typeref;
this.requestor.accepttypereference(singleref.token, singleref.sourcestart);
} else if (typeref instanceof javadocqualifiedtypereference) {
javadocqualifiedtypereference qualifiedref = (javadocqualifiedtypereference) typeref;
this.requestor.accepttypereference(qualifiedref.tokens, qualifiedref.sourcestart, qualifiedref.sourceend);
}
}

// report reference info in javadoc comment @@see tags
expression[] references = this.javadoc.references;
int seetagsnbre = references == null ? 0 : references.length;
for (int i = 0; i < seetagsnbre; i++) {
expression reference = references[i];
acceptjavadoctypereference(reference);
if (reference instanceof javadocfieldreference) {
javadocfieldreference fieldref = (javadocfieldreference) reference;
this.requestor.acceptfieldreference(fieldref.token, fieldref.sourcestart);
if (fieldref.receiver != null && !fieldref.receiver.isthis()) {
acceptjavadoctypereference(fieldref.receiver);
}
} else if (reference instanceof javadocmessagesend) {
javadocmessagesend messagesend = (javadocmessagesend) reference;
int argcount = messagesend.arguments == null ? 0 : messagesend.arguments.length;
this.requestor.acceptmethodreference(messagesend.selector, argcount, messagesend.sourcestart);
if (messagesend.receiver != null && !messagesend.receiver.isthis()) {
acceptjavadoctypereference(messagesend.receiver);
}
} else if (reference instanceof javadocallocationexpression) {
javadocallocationexpression constructor = (javadocallocationexpression) reference;
int argcount = constructor.arguments == null ? 0 : constructor.arguments.length;
if (constructor.type != null) {
char[][] compoundname = constructor.type.gettypename();
this.requestor.acceptconstructorreference(compoundname[compoundname.length-1], argcount, constructor.sourcestart);
if (!constructor.type.isthis()) {
acceptjavadoctypereference(constructor.type);
}
}
}
}
}
}
private void acceptjavadoctypereference(expression expression) {
if (expression instanceof javadocsingletypereference) {
javadocsingletypereference singleref = (javadocsingletypereference) expression;
this.requestor.accepttypereference(singleref.token, singleref.sourcestart);
} else if (expression instanceof javadocqualifiedtypereference) {
javadocqualifiedtypereference qualifiedref = (javadocqualifiedtypereference) expression;
this.requestor.accepttypereference(qualifiedref.tokens, qualifiedref.sourcestart, qualifiedref.sourceend);
}
}
protected void classinstancecreation(boolean alwaysqualified) {

boolean previousflag = reportreferenceinfo;
reportreferenceinfo = false; // not to see the type reference reported in super call to gettypereference(...)
super.classinstancecreation(alwaysqualified);
reportreferenceinfo = previousflag;
if (reportreferenceinfo){
allocationexpression alloc = (allocationexpression)expressionstack[expressionptr];
typereference typeref = alloc.type;
requestor.acceptconstructorreference(
typeref instanceof singletypereference
? ((singletypereference) typeref).token
: charoperation.concatwith(alloc.type.gettypename(), '.'),
alloc.arguments == null ? 0 : alloc.arguments.length,
alloc.sourcestart);
}
}
protected void consumeconstructorheadername() {
// constructorheadername ::=  modifiersopt 'identifier' '('

/* recovering - might be an empty message send */
if (currentelement != null){
if (lastignoredtoken == tokennamenew){ // was an allocation expression
lastcheckpoint = scanner.startposition; // force to restart at this exact position
restartrecovery = true;
return;
}
}
sourceconstructordeclaration cd = new sourceconstructordeclaration(this.compilationunit.compilationresult);

//name -- this is not really revelant but we do .....
cd.selector = identifierstack[identifierptr];
long selectorsourcepositions = identifierpositionstack[identifierptr--];
identifierlengthptr--;

//modifiers
cd.declarationsourcestart = intstack[intptr--];
cd.modifiers = intstack[intptr--];
// javadoc
cd.javadoc = this.javadoc;
this.javadoc = null;

//highlight starts at the selector starts
cd.sourcestart = (int) (selectorsourcepositions >>> 32);
cd.selectorsourceend = (int) selectorsourcepositions;
pushonaststack(cd);

cd.sourceend = lparenpos;
cd.bodystart = lparenpos+1;
listlength = 0; // initialize listlength before reading parameters/throws

// recovery
if (currentelement != null){
lastcheckpoint = cd.bodystart;
if ((currentelement instanceof recoveredtype && lastignoredtoken != tokennamedot)
|| cd.modifiers != 0){
currentelement = currentelement.add(cd, 0);
lastignoredtoken = -1;
}
}
}
/*
*
* internal use-only
*/
protected void consumeexitvariablewithinitialization() {
// exitvariablewithinitialization ::= $empty
// the scanner is located after the comma or the semi-colon.
// we want to include the comma or the semi-colon
super.consumeexitvariablewithinitialization();
if (islocaldeclaration() || ((currenttoken != tokennamecomma) && (currenttoken != tokennamesemicolon)))
return;
((sourcefielddeclaration) aststack[astptr]).fieldendposition = scanner.currentposition - 1;
}
protected void consumeexitvariablewithoutinitialization() {
// exitvariablewithoutinitialization ::= $empty
// do nothing by default
super.consumeexitvariablewithoutinitialization();
if (islocaldeclaration() || ((currenttoken != tokennamecomma) && (currenttoken != tokennamesemicolon)))
return;
((sourcefielddeclaration) aststack[astptr]).fieldendposition = scanner.currentposition - 1;
}
/*
*
* internal use-only
*/
protected void consumefieldaccess(boolean issuperaccess) {
// fieldaccess ::= primary '.' 'identifier'
// fieldaccess ::= 'super' '.' 'identifier'
super.consumefieldaccess(issuperaccess);
fieldreference fr = (fieldreference) expressionstack[expressionptr];
if (reportreferenceinfo) {
requestor.acceptfieldreference(fr.token, fr.sourcestart);
}
}
protected void consumemethodheadername() {
// methodheadername ::= modifiersopt type 'identifier' '('
sourcemethoddeclaration md = new sourcemethoddeclaration(this.compilationunit.compilationresult);

//name
md.selector = identifierstack[identifierptr];
long selectorsourcepositions = identifierpositionstack[identifierptr--];
identifierlengthptr--;
//type
md.returntype = gettypereference(intstack[intptr--]);
//modifiers
md.declarationsourcestart = intstack[intptr--];
md.modifiers = intstack[intptr--];
// javadoc
md.javadoc = this.javadoc;
this.javadoc = null;

//highlight starts at selector start
md.sourcestart = (int) (selectorsourcepositions >>> 32);
md.selectorsourceend = (int) selectorsourcepositions;
pushonaststack(md);
md.sourceend = lparenpos;
md.bodystart = lparenpos+1;
listlength = 0; // initialize listlength before reading parameters/throws

// recovery
if (currentelement != null){
if (currentelement instanceof recoveredtype
//|| md.modifiers != 0
|| (scanner.getlinenumber(md.returntype.sourcestart)
== scanner.getlinenumber(md.sourcestart))){
lastcheckpoint = md.bodystart;
currentelement = currentelement.add(md, 0);
lastignoredtoken = -1;
} else {
lastcheckpoint = md.sourcestart;
restartrecovery = true;
}
}
}
/*
*
* internal use-only
*/
protected void consumemethodinvocationname() {
// methodinvocation ::= name '(' argumentlistopt ')'

// when the name is only an identifier...we have a message send to "this" (implicit)
super.consumemethodinvocationname();
messagesend messagesend = (messagesend) expressionstack[expressionptr];
expression[] args = messagesend.arguments;
if (reportreferenceinfo) {
requestor.acceptmethodreference(
messagesend.selector,
args == null ? 0 : args.length,
(int)(messagesend.namesourceposition >>> 32));
}
}
/*
*
* internal use-only
*/
protected void consumemethodinvocationprimary() {
super.consumemethodinvocationprimary();
messagesend messagesend = (messagesend) expressionstack[expressionptr];
expression[] args = messagesend.arguments;
if (reportreferenceinfo) {
requestor.acceptmethodreference(
messagesend.selector,
args == null ? 0 : args.length,
(int)(messagesend.namesourceposition >>> 32));
}
}
/*
*
* internal use-only
*/
protected void consumemethodinvocationsuper() {
// methodinvocation ::= 'super' '.' 'identifier' '(' argumentlistopt ')'
super.consumemethodinvocationsuper();
messagesend messagesend = (messagesend) expressionstack[expressionptr];
expression[] args = messagesend.arguments;
if (reportreferenceinfo) {
requestor.acceptmethodreference(
messagesend.selector,
args == null ? 0 : args.length,
(int)(messagesend.namesourceposition >>> 32));
}
}
protected void consumesingletypeimportdeclarationname() {
// singletypeimportdeclarationname ::= 'import' name
/* push an importref build from the last name
stored in the identifier stack. */

super.consumesingletypeimportdeclarationname();
importreference impt = (importreference)aststack[astptr];
if (reportreferenceinfo) {
requestor.accepttypereference(impt.tokens, impt.sourcestart, impt.sourceend);
}
}
protected void consumetypeimportondemanddeclarationname() {
// typeimportondemanddeclarationname ::= 'import' name '.' '*'
/* push an importref build from the last name
stored in the identifier stack. */

super.consumetypeimportondemanddeclarationname();
importreference impt = (importreference)aststack[astptr];
if (reportreferenceinfo) {
requestor.acceptunknownreference(impt.tokens, impt.sourcestart, impt.sourceend);
}
}
public methoddeclaration converttomethoddeclaration(constructordeclaration c, compilationresult compilationresult) {
sourcemethoddeclaration m = new sourcemethoddeclaration(compilationresult);
m.sourcestart = c.sourcestart;
m.sourceend = c.sourceend;
m.bodystart = c.bodystart;
m.bodyend = c.bodyend;
m.declarationsourceend = c.declarationsourceend;
m.declarationsourcestart = c.declarationsourcestart;
m.selector = c.selector;
m.statements = c.statements;
m.modifiers = c.modifiers;
m.arguments = c.arguments;
m.thrownexceptions = c.thrownexceptions;
m.explicitdeclarations = c.explicitdeclarations;
m.returntype = null;
if (c instanceof sourceconstructordeclaration) {
m.selectorsourceend = ((sourceconstructordeclaration)c).selectorsourceend;
}
return m;
}
protected fielddeclaration createfielddeclaration(char[] fieldname, int sourcestart, int sourceend) {
return new sourcefielddeclaration(fieldname, sourcestart, sourceend);
}
protected compilationunitdeclaration endparse(int act) {
if (sourcetype != null) {
if (sourcetype.isinterface()) {
consumeinterfacedeclaration();
} else {
consumeclassdeclaration();
}
}
if (compilationunit != null) {
compilationunitdeclaration result = super.endparse(act);
return result;
} else {
return null;
}
}
public typereference gettypereference(int dim) {
/* build a reference on a variable that may be qualified or not
* this variable is a type reference and dim will be its dimensions
*/
int length;
if ((length = identifierlengthstack[identifierlengthptr--]) == 1) {
// single variable reference
if (dim == 0) {
singletypereference ref =
new singletypereference(
identifierstack[identifierptr],
identifierpositionstack[identifierptr--]);
if (reportreferenceinfo) {
requestor.accepttypereference(ref.token, ref.sourcestart);
}
return ref;
} else {
arraytypereference ref =
new arraytypereference(
identifierstack[identifierptr],
dim,
identifierpositionstack[identifierptr--]);
ref.sourceend = endposition;
if (reportreferenceinfo) {
requestor.accepttypereference(ref.token, ref.sourcestart);
}
return ref;
}
} else {
if (length < 0) { //flag for precompiled type reference on base types
typereference ref = typereference.basetypereference(-length, dim);
ref.sourcestart = intstack[intptr--];
if (dim == 0) {
ref.sourceend = intstack[intptr--];
} else {
intptr--; // no need to use this position as it is an array
ref.sourceend = endposition;
}
if (reportreferenceinfo){
requestor.accepttypereference(ref.gettypename(), ref.sourcestart, ref.sourceend);
}
return ref;
} else { //qualified variable reference
char[][] tokens = new char[length][];
identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(identifierstack, identifierptr + 1, tokens, 0, length);
system.arraycopy(
identifierpositionstack,
identifierptr + 1,
positions,
0,
length);
if (dim == 0) {
qualifiedtypereference ref = new qualifiedtypereference(tokens, positions);
if (reportreferenceinfo) {
requestor.accepttypereference(ref.tokens, ref.sourcestart, ref.sourceend);
}
return ref;
} else {
arrayqualifiedtypereference ref =
new arrayqualifiedtypereference(tokens, dim, positions);
ref.sourceend = endposition;
if (reportreferenceinfo) {
requestor.accepttypereference(ref.tokens, ref.sourcestart, ref.sourceend);
}
return ref;
}
}
}
}
public namereference getunspecifiedreference() {
/* build a (unspecified) namereference which may be qualified*/

int length;
if ((length = identifierlengthstack[identifierlengthptr--]) == 1) {
// single variable reference
singlenamereference ref =
new singlenamereference(
identifierstack[identifierptr],
identifierpositionstack[identifierptr--]);
if (reportreferenceinfo) {
this.addunknownref(ref);
}
return ref;
} else {
//qualified variable reference
char[][] tokens = new char[length][];
identifierptr -= length;
system.arraycopy(identifierstack, identifierptr + 1, tokens, 0, length);
long[] positions = new long[length];
system.arraycopy(identifierpositionstack, identifierptr + 1, positions, 0, length);
qualifiednamereference ref =
new qualifiednamereference(
tokens,
positions,
(int) (identifierpositionstack[identifierptr + 1] >> 32), // sourcestart
(int) identifierpositionstack[identifierptr + length]); // sourceend
if (reportreferenceinfo) {
this.addunknownref(ref);
}
return ref;
}
}
public namereference getunspecifiedreferenceoptimized() {
/* build a (unspecified) namereference which may be qualified
the optimization occurs for qualified reference while we are
certain in this case the last item of the qualified name is
a field access. this optimization is important while it results
that when a namereference is build, the type checker should always
look for that it is not a type reference */

int length;
if ((length = identifierlengthstack[identifierlengthptr--]) == 1) {
// single variable reference
singlenamereference ref =
new singlenamereference(
identifierstack[identifierptr],
identifierpositionstack[identifierptr--]);
ref.bits &= ~astnode.restrictiveflagmask;
ref.bits |= local | field;
if (reportreferenceinfo) {
this.addunknownref(ref);
}
return ref;
}

//qualified-variable-reference
//in fact it is variable-reference dot field-ref , but it would result in a type
//conflict tha can be only reduce by making a superclass (or inetrface ) between
//namereference and filedreference or putting fieldreference under namereference
//or else..........this optimisation is not really relevant so just leave as it is

char[][] tokens = new char[length][];
identifierptr -= length;
system.arraycopy(identifierstack, identifierptr + 1, tokens, 0, length);
long[] positions = new long[length];
system.arraycopy(identifierpositionstack, identifierptr + 1, positions, 0, length);
qualifiednamereference ref =
new qualifiednamereference(
tokens,
positions,
(int) (identifierpositionstack[identifierptr + 1] >> 32),
// sourcestart
(int) identifierpositionstack[identifierptr + length]); // sourceend
ref.bits &= ~astnode.restrictiveflagmask;
ref.bits |= local | field;
if (reportreferenceinfo) {
this.addunknownref(ref);
}
return ref;
}
/*
*
* internal use-only
*/
private boolean islocaldeclaration() {
int nesteddepth = nestedtype;
while (nesteddepth >= 0) {
if (nestedmethod[nesteddepth] != 0) {
return true;
}
nesteddepth--;
}
return false;
}
/*
* update the bodystart of the corresponding parse node
*/
public void notifysourceelementrequestor(compilationunitdeclaration parsedunit) {
if (parsedunit == null) {
// when we parse a single type member declaration the compilation unit is null, but we still
// want to be able to notify the requestor on the created ast node
if (aststack[0] instanceof abstractmethoddeclaration) {
notifysourceelementrequestor((abstractmethoddeclaration) aststack[0]);
return;
}
return;
}
// range check
boolean isinrange =
scanner.initialposition <= parsedunit.sourcestart
&& scanner.eofposition >= parsedunit.sourceend;

if (reportreferenceinfo) {
notifyallunknownreferences();
}
// collect the top level ast nodes
int length = 0;
astnode[] nodes = null;
if (sourcetype == null){
if (isinrange) {
requestor.entercompilationunit();
}
importreference currentpackage = parsedunit.currentpackage;
importreference[] imports = parsedunit.imports;
typedeclaration[] types = parsedunit.types;
length =
(currentpackage == null ? 0 : 1)
+ (imports == null ? 0 : imports.length)
+ (types == null ? 0 : types.length);
nodes = new astnode[length];
int index = 0;
if (currentpackage != null) {
nodes[index++] = currentpackage;
}
if (imports != null) {
for (int i = 0, max = imports.length; i < max; i++) {
nodes[index++] = imports[i];
}
}
if (types != null) {
for (int i = 0, max = types.length; i < max; i++) {
nodes[index++] = types[i];
}
}
} else {
typedeclaration[] types = parsedunit.types;
if (types != null) {
length = types.length;
nodes = new astnode[length];
for (int i = 0, max = types.length; i < max; i++) {
nodes[i] = types[i];
}
}
}

// notify the nodes in the syntactical order
if (nodes != null && length > 0) {
quicksort(nodes, 0, length-1);
for (int i=0;i<length;i++) {
astnode node = nodes[i];
if (node instanceof importreference) {
importreference importref = (importreference)node;
if (node == parsedunit.currentpackage) {
notifysourceelementrequestor(importref, true);
} else {
notifysourceelementrequestor(importref, false);
}
} else { // instanceof typedeclaration
notifysourceelementrequestor((typedeclaration)node, sourcetype == null);
}
}
}

if (sourcetype == null){
if (isinrange) {
requestor.exitcompilationunit(parsedunit.sourceend);
}
}
}

private void notifyallunknownreferences() {
for (int i = 0, max = this.unknownrefscounter; i < max; i++) {
namereference nameref = this.unknownrefs[i];
if ((nameref.bits & bindingids.variable) != 0) {
if ((nameref.bits & bindingids.type) == 0) {
// variable but not type
if (nameref instanceof singlenamereference) {
// local var or field
requestor.acceptunknownreference(((singlenamereference) nameref).token, nameref.sourcestart);
} else {
// qualifiednamereference
// the last token is a field reference and the previous tokens are a type/variable references
char[][] tokens = ((qualifiednamereference) nameref).tokens;
int tokenslength = tokens.length;
requestor.acceptfieldreference(tokens[tokenslength - 1], nameref.sourceend - tokens[tokenslength - 1].length + 1);
char[][] typeref = new char[tokenslength - 1][];
system.arraycopy(tokens, 0, typeref, 0, tokenslength - 1);
requestor.acceptunknownreference(typeref, nameref.sourcestart, nameref.sourceend - tokens[tokenslength - 1].length);
}
} else {
// variable or type
if (nameref instanceof singlenamereference) {
requestor.acceptunknownreference(((singlenamereference) nameref).token, nameref.sourcestart);
} else {
//qualifiednamereference
requestor.acceptunknownreference(((qualifiednamereference) nameref).tokens, nameref.sourcestart, nameref.sourceend);
}
}
} else if ((nameref.bits & bindingids.type) != 0) {
if (nameref instanceof singlenamereference) {
requestor.accepttypereference(((singlenamereference) nameref).token, nameref.sourcestart);
} else {
// it is a qualifiednamereference
requestor.accepttypereference(((qualifiednamereference) nameref).tokens, nameref.sourcestart, nameref.sourceend);
}
}
}
}
/*
* update the bodystart of the corresponding parse node
*/
public void notifysourceelementrequestor(abstractmethoddeclaration methoddeclaration) {

// range check
boolean isinrange =
scanner.initialposition <= methoddeclaration.declarationsourcestart
&& scanner.eofposition >= methoddeclaration.declarationsourceend;

if (methoddeclaration.isclinit()) {
this.visitifneeded(methoddeclaration);
return;
}

if (methoddeclaration.isdefaultconstructor()) {
if (reportreferenceinfo) {
constructordeclaration constructordeclaration = (constructordeclaration) methoddeclaration;
explicitconstructorcall constructorcall = constructordeclaration.constructorcall;
if (constructorcall != null) {
switch(constructorcall.accessmode) {
case explicitconstructorcall.this :
requestor.acceptconstructorreference(
typenames[nestedtypeindex-1],
constructorcall.arguments == null ? 0 : constructorcall.arguments.length,
constructorcall.sourcestart);
break;
case explicitconstructorcall.super :
case explicitconstructorcall.implicitsuper :
requestor.acceptconstructorreference(
supertypenames[nestedtypeindex-1],
constructorcall.arguments == null ? 0 : constructorcall.arguments.length,
constructorcall.sourcestart);
break;
}
}
}
return;
}
char[][] argumenttypes = null;
char[][] argumentnames = null;
argument[] arguments = methoddeclaration.arguments;
if (arguments != null) {
int argumentlength = arguments.length;
argumenttypes = new char[argumentlength][];
argumentnames = new char[argumentlength][];
for (int i = 0; i < argumentlength; i++) {
argumenttypes[i] = returntypename(arguments[i].type);
argumentnames[i] = arguments[i].name;
}
}
char[][] thrownexceptiontypes = null;
typereference[] thrownexceptions = methoddeclaration.thrownexceptions;
if (thrownexceptions != null) {
int thrownexceptionlength = thrownexceptions.length;
thrownexceptiontypes = new char[thrownexceptionlength][];
for (int i = 0; i < thrownexceptionlength; i++) {
thrownexceptiontypes[i] =
charoperation.concatwith(thrownexceptions[i].gettypename(), '.');
}
}
// by default no selector end position
int selectorsourceend = -1;
if (methoddeclaration.isconstructor()) {
if (methoddeclaration instanceof sourceconstructordeclaration) {
selectorsourceend =
((sourceconstructordeclaration) methoddeclaration).selectorsourceend;
}
if (isinrange){
requestor.enterconstructor(
methoddeclaration.declarationsourcestart,
methoddeclaration.modifiers,
methoddeclaration.selector,
methoddeclaration.sourcestart,
selectorsourceend,
argumenttypes,
argumentnames,
thrownexceptiontypes);
}
if (reportreferenceinfo) {
constructordeclaration constructordeclaration = (constructordeclaration) methoddeclaration;
explicitconstructorcall constructorcall = constructordeclaration.constructorcall;
if (constructorcall != null) {
switch(constructorcall.accessmode) {
case explicitconstructorcall.this :
requestor.acceptconstructorreference(
typenames[nestedtypeindex-1],
constructorcall.arguments == null ? 0 : constructorcall.arguments.length,
constructorcall.sourcestart);
break;
case explicitconstructorcall.super :
case explicitconstructorcall.implicitsuper :
requestor.acceptconstructorreference(
supertypenames[nestedtypeindex-1],
constructorcall.arguments == null ? 0 : constructorcall.arguments.length,
constructorcall.sourcestart);
break;
}
}
}
this.visitifneeded(methoddeclaration);
if (isinrange){
requestor.exitconstructor(methoddeclaration.declarationsourceend);
}
return;
}
if (methoddeclaration instanceof sourcemethoddeclaration) {
selectorsourceend =
((sourcemethoddeclaration) methoddeclaration).selectorsourceend;
}
if (isinrange) {
int currentmodifiers = methoddeclaration.modifiers;
boolean deprecated = (currentmodifiers & accdeprecated) != 0; // remember deprecation so as to not lose it below
requestor.entermethod(
methoddeclaration.declarationsourcestart,
deprecated ? (currentmodifiers & accjustflag) | accdeprecated : currentmodifiers & accjustflag,
returntypename(((methoddeclaration) methoddeclaration).returntype),
methoddeclaration.selector,
methoddeclaration.sourcestart,
selectorsourceend,
argumenttypes,
argumentnames,
thrownexceptiontypes);
}
this.visitifneeded(methoddeclaration);

if (isinrange){
requestor.exitmethod(methoddeclaration.declarationsourceend);
}
}
/*
* update the bodystart of the corresponding parse node
*/
public void notifysourceelementrequestor(fielddeclaration fielddeclaration) {

// range check
boolean isinrange =
scanner.initialposition <= fielddeclaration.declarationsourcestart
&& scanner.eofposition >= fielddeclaration.declarationsourceend;

if (fielddeclaration.isfield()) {
int fieldendposition = fielddeclaration.declarationsourceend;
if (fielddeclaration instanceof sourcefielddeclaration) {
fieldendposition = ((sourcefielddeclaration) fielddeclaration).fieldendposition;
if (fieldendposition == 0) {
// use the declaration source end by default
fieldendposition = fielddeclaration.declarationsourceend;
}
}
if (isinrange) {
int currentmodifiers = fielddeclaration.modifiers;
boolean deprecated = (currentmodifiers & accdeprecated) != 0; // remember deprecation so as to not lose it below
requestor.enterfield(
fielddeclaration.declarationsourcestart,
deprecated ? (currentmodifiers & accjustflag) | accdeprecated : currentmodifiers & accjustflag,
returntypename(fielddeclaration.type),
fielddeclaration.name,
fielddeclaration.sourcestart,
fielddeclaration.sourceend);
}
this.visitifneeded(fielddeclaration);
if (isinrange){
requestor.exitfield(
// filter out initializations that are not a constant (simple check)
(fielddeclaration.initialization == null
|| fielddeclaration.initialization instanceof arrayinitializer
|| fielddeclaration.initialization instanceof allocationexpression
|| fielddeclaration.initialization instanceof arrayallocationexpression
|| fielddeclaration.initialization instanceof assignment
|| fielddeclaration.initialization instanceof classliteralaccess
|| fielddeclaration.initialization instanceof messagesend
|| fielddeclaration.initialization instanceof arrayreference
|| fielddeclaration.initialization instanceof thisreference) ?
-1 :
fielddeclaration.initialization.sourcestart,
fieldendposition,
fielddeclaration.declarationsourceend);
}

} else {
if (isinrange){
requestor.enterinitializer(
fielddeclaration.declarationsourcestart,
fielddeclaration.modifiers);
}
this.visitifneeded((initializer)fielddeclaration);
if (isinrange){
requestor.exitinitializer(fielddeclaration.declarationsourceend);
}
}
}
public void notifysourceelementrequestor(
importreference importreference,
boolean ispackage) {
if (ispackage) {
requestor.acceptpackage(
importreference.declarationsourcestart,
importreference.declarationsourceend,
charoperation.concatwith(importreference.getimportname(), '.'));
} else {
requestor.acceptimport(
importreference.declarationsourcestart,
importreference.declarationsourceend,
charoperation.concatwith(importreference.getimportname(), '.'),
importreference.ondemand,
importreference.modifiers);
}
}
public void notifysourceelementrequestor(typedeclaration typedeclaration, boolean notifytypepresence) {

// range check
boolean isinrange =
scanner.initialposition <= typedeclaration.declarationsourcestart
&& scanner.eofposition >= typedeclaration.declarationsourceend;

fielddeclaration[] fields = typedeclaration.fields;
abstractmethoddeclaration[] methods = typedeclaration.methods;
typedeclaration[] membertypes = typedeclaration.membertypes;
int fieldcounter = fields == null ? 0 : fields.length;
int methodcounter = methods == null ? 0 : methods.length;
int membertypecounter = membertypes == null ? 0 : membertypes.length;
int fieldindex = 0;
int methodindex = 0;
int membertypeindex = 0;
boolean isinterface = typedeclaration.isinterface();

if (notifytypepresence){
char[][] interfacenames = null;
int superinterfaceslength = 0;
typereference[] superinterfaces = typedeclaration.superinterfaces;
if (superinterfaces != null) {
superinterfaceslength = superinterfaces.length;
interfacenames = new char[superinterfaceslength][];
} else {
if ((typedeclaration.bits & astnode.isanonymoustypemask) != 0) {
// see pr 3442
qualifiedallocationexpression alloc = typedeclaration.allocation;
if (alloc != null && alloc.type != null) {
superinterfaces = new typereference[] { typedeclaration.allocation.type};
superinterfaceslength = 1;
interfacenames = new char[1][];
}
}
}
if (superinterfaces != null) {
for (int i = 0; i < superinterfaceslength; i++) {
interfacenames[i] =
charoperation.concatwith(superinterfaces[i].gettypename(), '.');
}
}
if (isinterface) {
if (isinrange){
int currentmodifiers = typedeclaration.modifiers;
boolean deprecated = (currentmodifiers & accdeprecated) != 0; // remember deprecation so as to not lose it below
requestor.enterinterface(
typedeclaration.declarationsourcestart,
deprecated ? (currentmodifiers & accjustflag) | accdeprecated : currentmodifiers & accjustflag,
typedeclaration.name,
typedeclaration.sourcestart,
sourceend(typedeclaration),
interfacenames);
}
if (nestedtypeindex == typenames.length) {
// need a resize
system.arraycopy(typenames, 0, (typenames = new char[nestedtypeindex * 2][]), 0, nestedtypeindex);
system.arraycopy(supertypenames, 0, (supertypenames = new char[nestedtypeindex * 2][]), 0, nestedtypeindex);
}
typenames[nestedtypeindex] = typedeclaration.name;
supertypenames[nestedtypeindex++] = java_lang_object;
} else {
typereference superclass = typedeclaration.superclass;
if (superclass == null) {
if (isinrange){
requestor.enterclass(
typedeclaration.declarationsourcestart,
typedeclaration.modifiers,
typedeclaration.name,
typedeclaration.sourcestart,
sourceend(typedeclaration),
null,
interfacenames);
}
} else {
if (isinrange){
requestor.enterclass(
typedeclaration.declarationsourcestart,
typedeclaration.modifiers,
typedeclaration.name,
typedeclaration.sourcestart,
sourceend(typedeclaration),
charoperation.concatwith(superclass.gettypename(), '.'),
interfacenames);
}
}
if (nestedtypeindex == typenames.length) {
// need a resize
system.arraycopy(typenames, 0, (typenames = new char[nestedtypeindex * 2][]), 0, nestedtypeindex);
system.arraycopy(supertypenames, 0, (supertypenames = new char[nestedtypeindex * 2][]), 0, nestedtypeindex);
}
typenames[nestedtypeindex] = typedeclaration.name;
supertypenames[nestedtypeindex++] = superclass == null ? java_lang_object : charoperation.concatwith(superclass.gettypename(), '.');
}
}
while ((fieldindex < fieldcounter)
|| (membertypeindex < membertypecounter)
|| (methodindex < methodcounter)) {
fielddeclaration nextfielddeclaration = null;
abstractmethoddeclaration nextmethoddeclaration = null;
typedeclaration nextmemberdeclaration = null;

int position = integer.max_value;
int nextdeclarationtype = -1;
if (fieldindex < fieldcounter) {
nextfielddeclaration = fields[fieldindex];
if (nextfielddeclaration.declarationsourcestart < position) {
position = nextfielddeclaration.declarationsourcestart;
nextdeclarationtype = 0; // field
}
}
if (methodindex < methodcounter) {
nextmethoddeclaration = methods[methodindex];
if (nextmethoddeclaration.declarationsourcestart < position) {
position = nextmethoddeclaration.declarationsourcestart;
nextdeclarationtype = 1; // method
}
}
if (membertypeindex < membertypecounter) {
nextmemberdeclaration = membertypes[membertypeindex];
if (nextmemberdeclaration.declarationsourcestart < position) {
position = nextmemberdeclaration.declarationsourcestart;
nextdeclarationtype = 2; // member
}
}
switch (nextdeclarationtype) {
case 0 :
fieldindex++;
notifysourceelementrequestor(nextfielddeclaration);
break;
case 1 :
methodindex++;
notifysourceelementrequestor(nextmethoddeclaration);
break;
case 2 :
membertypeindex++;
notifysourceelementrequestor(nextmemberdeclaration, true);
}
}
if (notifytypepresence){
if (isinrange){
if (isinterface) {
requestor.exitinterface(typedeclaration.declarationsourceend);
} else {
requestor.exitclass(typedeclaration.declarationsourceend);
}
}
nestedtypeindex--;
}
}
private int sourceend(typedeclaration typedeclaration) {
if ((typedeclaration.bits & astnode.isanonymoustypemask) != 0) {
return typedeclaration.allocation.type.sourceend;
} else {
return typedeclaration.sourceend;
}
}
public void parsecompilationunit(
icompilationunit unit,
int start,
int end,
boolean fullparse) {

this.reportreferenceinfo = fullparse;
boolean old = diet;
if (fullparse) {
unknownrefs = new namereference[10];
unknownrefscounter = 0;
}

try {
diet = true;
compilationresult compilationunitresult = new compilationresult(unit, 0, 0, this.options.maxproblemsperunit);
compilationunitdeclaration parsedunit = parse(unit, compilationunitresult, start, end);
if (scanner.recordlineseparator) {
requestor.acceptlineseparatorpositions(scanner.getlineends());
}
if (this.localdeclarationvisitor != null || fullparse){
diet = false;
this.getmethodbodies(parsedunit);
}
this.scanner.resetto(start, end);
notifysourceelementrequestor(parsedunit);
} catch (abortcompilation e) {
// ignore this exception
} finally {
diet = old;
}
}
public compilationunitdeclaration parsecompilationunit(
icompilationunit unit,
boolean fullparse) {

boolean old = diet;
if (fullparse) {
unknownrefs = new namereference[10];
unknownrefscounter = 0;
}

try {
diet = true;
this.reportreferenceinfo = fullparse;
compilationresult compilationunitresult = new compilationresult(unit, 0, 0, this.options.maxproblemsperunit);
compilationunitdeclaration parsedunit = parse(unit, compilationunitresult);
if (scanner.recordlineseparator) {
requestor.acceptlineseparatorpositions(scanner.getlineends());
}
int initialstart = this.scanner.initialposition;
int initialend = this.scanner.eofposition;
if (this.localdeclarationvisitor != null || fullparse){
diet = false;
this.getmethodbodies(parsedunit);
}
this.scanner.resetto(initialstart, initialend);
notifysourceelementrequestor(parsedunit);
return parsedunit;
} catch (abortcompilation e) {
// ignore this exception
} finally {
diet = old;
}
return null;
}
public void parsetypememberdeclarations(
isourcetype type,
icompilationunit sourceunit,
int start,
int end,
boolean needreferenceinfo) {
boolean old = diet;
if (needreferenceinfo) {
unknownrefs = new namereference[10];
unknownrefscounter = 0;
}

try {
diet = !needreferenceinfo;
reportreferenceinfo = needreferenceinfo;
compilationresult compilationunitresult =
new compilationresult(sourceunit, 0, 0, this.options.maxproblemsperunit);
compilationunitdeclaration unit =
sourcetypeconverter.buildcompilationunit(
new isourcetype[]{type},
// no need for field and methods
// no need for member types
// no need for field initialization
sourcetypeconverter.none,
problemreporter(),
compilationunitresult);
if ((unit == null) || (unit.types == null) || (unit.types.length != 1))
return;
this.sourcetype = type;
try {
/* automaton initialization */
initialize();
goforclassbodydeclarations();
/* scanner initialization */
scanner.setsource(sourceunit.getcontents());
scanner.resetto(start, end);
/* unit creation */
referencecontext = compilationunit = unit;
/* initialize the aststacl */
// the compilationunitdeclaration should contain exactly one type
pushonaststack(unit.types[0]);
/* run automaton */
parse();
notifysourceelementrequestor(unit);
} finally {
unit = compilationunit;
compilationunit = null; // reset parser
}
} catch (abortcompilation e) {
// ignore this exception
} finally {
if (scanner.recordlineseparator) {
requestor.acceptlineseparatorpositions(scanner.getlineends());
}
diet = old;
}
}

public void parsetypememberdeclarations(
char[] contents,
int start,
int end) {

boolean old = diet;

try {
diet = true;

/* automaton initialization */
initialize();
goforclassbodydeclarations();
/* scanner initialization */
scanner.setsource(contents);
scanner.recordlineseparator = false;
scanner.tasktags = null;
scanner.taskpriorities = null;
scanner.resetto(start, end);

/* unit creation */
referencecontext = null;

/* initialize the aststacl */
// the compilationunitdeclaration should contain exactly one type
/* run automaton */
parse();
notifysourceelementrequestor((compilationunitdeclaration)null);
} catch (abortcompilation e) {
// ignore this exception
} finally {
diet = old;
}
}
/*
* sort the given ast nodes by their positions.
*/
private static void quicksort(astnode[] sortedcollection, int left, int right) {
int original_left = left;
int original_right = right;
astnode mid = sortedcollection[ (left + right) / 2];
do {
while (sortedcollection[left].sourcestart < mid.sourcestart) {
left++;
}
while (mid.sourcestart < sortedcollection[right].sourcestart) {
right--;
}
if (left <= right) {
astnode tmp = sortedcollection[left];
sortedcollection[left] = sortedcollection[right];
sortedcollection[right] = tmp;
left++;
right--;
}
} while (left <= right);
if (original_left < right) {
quicksort(sortedcollection, original_left, right);
}
if (left < original_right) {
quicksort(sortedcollection, left, original_right);
}
}
/*
* answer a char array representation of the type name formatted like:
* - type name + dimensions
* example:
* "a[][]".tochararray()
* "java.lang.string".tochararray()
*/
private char[] returntypename(typereference type) {
if (type == null)
return null;
int dimension = type.dimensions();
if (dimension != 0) {
char[] dimensionsarray = new char[dimension * 2];
for (int i = 0; i < dimension; i++) {
dimensionsarray[i * 2] = '[';
dimensionsarray[(i * 2) + 1] = ']';
}
return charoperation.concat(
charoperation.concatwith(type.gettypename(), '.'),
dimensionsarray);
}
return charoperation.concatwith(type.gettypename(), '.');
}

public void addunknownref(namereference nameref) {
if (this.unknownrefs.length == this.unknownrefscounter) {
// resize
system.arraycopy(
this.unknownrefs,
0,
(this.unknownrefs = new namereference[this.unknownrefscounter * 2]),
0,
this.unknownrefscounter);
}
this.unknownrefs[this.unknownrefscounter++] = nameref;
}

private void visitifneeded(abstractmethoddeclaration method) {
if (this.localdeclarationvisitor != null
&& (method.bits & astnode.haslocaltypemask) != 0) {
if (method.statements != null) {
int statementslength = method.statements.length;
for (int i = 0; i < statementslength; i++)
method.statements[i].traverse(this.localdeclarationvisitor, method.scope);
}
}
}

private void visitifneeded(fielddeclaration field) {
if (this.localdeclarationvisitor != null
&& (field.bits & astnode.haslocaltypemask) != 0) {
if (field.initialization != null) {
field.initialization.traverse(this.localdeclarationvisitor, null);
}
}
}

private void visitifneeded(initializer initializer) {
if (this.localdeclarationvisitor != null
&& (initializer.bits & astnode.haslocaltypemask) != 0) {
if (initializer.block != null) {
initializer.block.traverse(this.localdeclarationvisitor, null);
}
}
}
}
