/*******************************************************************************
* copyright (c) 2004, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.annotation;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;

public class completiononannotationoftype extends typedeclaration {
public astnode potentialannotatednode;
// during recovery a parameter can be parsed as a fielddeclaration instead of argument.
// 'isparameter' is set to true in this case.
public boolean isparameter;

public completiononannotationoftype(char[] typename, compilationresult compilationresult, annotation annotation){
super(compilationresult);
this.sourceend = annotation.sourceend;
this.sourcestart = annotation.sourceend;
this.name = typename;
this.annotations = new annotation[]{annotation};
}

public stringbuffer print(int indent, stringbuffer output) {
return this.annotations[0].print(indent, output);
}
}
