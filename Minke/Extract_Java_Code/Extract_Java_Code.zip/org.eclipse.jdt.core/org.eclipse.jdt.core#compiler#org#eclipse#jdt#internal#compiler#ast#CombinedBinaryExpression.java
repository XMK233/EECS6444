/*******************************************************************************
* copyright (c) 2006, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;

/**
* combinedbinaryexpression is an implementation of binaryexpression that
* specifically attempts to mitigate the issues raised by expressions which
* have a very deep leftmost branch. it does so by maintaining a table of
* direct references to its subexpressions, and implementing non-recursive
* variants of the most significant recursive algorithms of its ancestors.
* the subexpressions table only holds intermediate binary expressions. its
* role is to provide the reversed navigation through the left relationship
* of binaryexpression to expression. to cope with potentially very deep
* left branches, an instance of combinedbinaryexpression is created once in
* a while, using variable thresholds held by {@@link #aritymax}.
* as a specific case, the topmost node of all binary expressions that are
* deeper than one is a combinedbinaryexpression, but it has no references
* table.<br>
* notes:
* <ul>
* <li>combinedbinaryexpression is not meant to behave in other ways than
*     binaryexpression in any observable respect;</li>
* <li>visitors that implement their own traversal upon binary expressions
*     should consider taking advantage of combined binary expressions, or
*     else face a risk of stackoverflowerror upon deep instances;</li>
* <li>callers that need to change the operator should rebuild the expression
*     from scratch, or else amend the references table as needed to cope with
*     the resulting, separated expressions.</li>
* </ul>
*/
public class combinedbinaryexpression extends binaryexpression {

/**
* the number of consecutive binary expressions of this' left branch that
* bear the same operator as this.<br>
* notes:
* <ul><li>the presence of a combinedbinaryexpression instance resets
*         arity, even when its operator is compatible;</li>
*	   <li>this property is maintained by the parser.</li>
* </ul>
*/
public int arity;

/**
* the threshold that will trigger the creation of the next full-fledged
* combinedbinaryexpression. this field is only maintained for the
* topmost binary expression (it is 0 otherwise). it enables a variable
* policy, which scales better with very large expressions.
*/
public int aritymax;

/**
* upper limit for {@@link #aritymax}.
*/
public static final int arity_max_max = 160;

/**
* default lower limit for {@@link #aritymax}.
*/
public static final int arity_max_min = 20;

/**
* default value for the first term of the series of {@@link #aritymax}
* values. changing this allows for experimentation. not meant to be
* changed during a parse operation.
*/
public static int defaultaritymaxstartingvalue = arity_max_min;

/**
* a table of references to the binary expressions of this' left branch.
* instances of combinedbinaryexpression are not repeated here. instead,
* the left subexpression of referencestable[0] may be a combined binary
* expression, if appropriate. null when this only cares about tracking
* the expression's arity.
*/
public binaryexpression referencestable[];

/**
* make a new combinedbinaryexpression. if arity is strictly greater than one,
* a references table is built and initialized with the reverse relationship of
* the one defined by {@@link binaryexpression#left}. arity and left must be
* compatible with each other (that is, there must be at least arity - 1
* consecutive compatible binary expressions into the leftmost branch of left,
* the topmost of which being left's immediate left expression).
* @@param left the left branch expression
* @@param right the right branch expression
* @@param operator the operator for this binary expression - only plus for now
* @@param arity the number of binary expressions of a compatible operator that
*        already exist into the leftmost branch of left (including left); must
*        be strictly greater than 0
*/
public combinedbinaryexpression(expression left, expression right, int operator, int arity) {
super(left, right, operator);
initarity(left, arity);
}
public combinedbinaryexpression(combinedbinaryexpression expression) {
super(expression);
initarity(expression.left, expression.arity);
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext,
flowinfo flowinfo) {
// keep implementation in sync with binaryexpression#analysecode
if (this.referencestable == null) {
return super.analysecode(currentscope, flowcontext, flowinfo);
}
binaryexpression cursor;
if ((cursor = this.referencestable[0]).resolvedtype.id !=
typeids.t_javalangstring) {
cursor.left.checknpe(currentscope, flowcontext, flowinfo);
}
flowinfo = cursor.left.analysecode(currentscope, flowcontext, flowinfo).
unconditionalinits();
for (int i = 0, end = this.arity; i < end; i ++) {
if ((cursor = this.referencestable[i]).resolvedtype.id !=
typeids.t_javalangstring) {
cursor.right.checknpe(currentscope, flowcontext, flowinfo);
}
flowinfo = cursor.right.
analysecode(currentscope, flowcontext, flowinfo).
unconditionalinits();
}
if (this.resolvedtype.id != typeids.t_javalangstring) {
this.right.checknpe(currentscope, flowcontext, flowinfo);
}
return this.right.analysecode(currentscope, flowcontext, flowinfo).
unconditionalinits();
}

public void generateoptimizedstringconcatenation(blockscope blockscope,
codestream codestream, int typeid) {
// keep implementation in sync with binaryexpression and expression
// #generateoptimizedstringconcatenation
if (this.referencestable == null) {
super.generateoptimizedstringconcatenation(blockscope, codestream,
typeid);
} else {
if ((((this.bits & astnode.operatormask) >> astnode.operatorshift) ==
operatorids.plus)
&& ((this.bits & astnode.returntypeidmask) == typeids.t_javalangstring)) {
if (this.constant != constant.notaconstant) {
codestream.generateconstant(this.constant, this.implicitconversion);
codestream.invokestringconcatenationappendfortype(
this.implicitconversion & typeids.compile_type_mask);
} else {
binaryexpression cursor = this.referencestable[0];

int restart = 0;
//			int cursortypeid;
int pc = codestream.position;
for (restart = this.arity - 1; restart >= 0; restart--) {
if ((cursor = this.referencestable[restart]).constant !=
constant.notaconstant) {
codestream.generateconstant(cursor.constant,
cursor.implicitconversion);
codestream.invokestringconcatenationappendfortype(
cursor.implicitconversion & typeids.compile_type_mask);
break;
}
// never happens for now - may reconsider if we decide to
// cover more than string concatenation
//				if (!((((cursor = this.referencestable[restart]).bits &
//						astnode.operatormask) >> astnode.operatorshift) ==
//							operatorids.plus) &
//						((cursortypeid = cursor.bits & astnode.returntypeidmask) ==
//							typeids.t_javalangstring)) {
//					if (cursortypeid == t_javalangstring &&
//							cursor.constant != constant.notaconstant &&
//							cursor.constant.stringvalue().length() == 0) {
//						break; // optimize str + ""
//					}
//					cursor.generatecode(blockscope, codestream, true);
//					codestream.invokestringconcatenationappendfortype(
//							cursortypeid);
//					break;
//				}
}
restart++;
if (restart == 0) { // reached the leftmost expression
cursor.left.generateoptimizedstringconcatenation(
blockscope,
codestream,
cursor.left.implicitconversion & typeids.compile_type_mask);
}
int pcaux;
for (int i = restart; i < this.arity; i++) {
codestream.recordpositionsfrom(pc,
(cursor = this.referencestable[i]).left.sourcestart);
pcaux = codestream.position;
cursor.right.generateoptimizedstringconcatenation(blockscope,
codestream,	cursor.right.implicitconversion &
typeids.compile_type_mask);
codestream.recordpositionsfrom(pcaux, cursor.right.sourcestart);
}
codestream.recordpositionsfrom(pc, this.left.sourcestart);
pc = codestream.position;
this.right.generateoptimizedstringconcatenation(
blockscope,
codestream,
this.right.implicitconversion & typeids.compile_type_mask);
codestream.recordpositionsfrom(pc, this.right.sourcestart);
}
} else {
super.generateoptimizedstringconcatenation(blockscope, codestream,
typeid);
}
}
}

public void generateoptimizedstringconcatenationcreation(blockscope blockscope,
codestream codestream, int typeid) {
// keep implementation in sync with binaryexpression
// #generateoptimizedstringconcatenationcreation
if (this.referencestable == null) {
super.generateoptimizedstringconcatenationcreation(blockscope,
codestream,	typeid);
} else {
if ((((this.bits & astnode.operatormask) >> astnode.operatorshift) ==
operatorids.plus) &&
((this.bits & astnode.returntypeidmask) ==
typeids.t_javalangstring) &&
this.constant == constant.notaconstant) {
int pc = codestream.position;
binaryexpression cursor = this.referencestable[this.arity - 1];
// silence warnings
int restart = 0;
for (restart = this.arity - 1; restart >= 0; restart--) {
if (((((cursor = this.referencestable[restart]).bits &
astnode.operatormask) >> astnode.operatorshift) ==
operatorids.plus) &&
((cursor.bits & astnode.returntypeidmask) ==
typeids.t_javalangstring)) {
if (cursor.constant != constant.notaconstant) {
codestream.newstringcontatenation(); // new: java.lang.stringbuffer
codestream.dup();
codestream.ldc(cursor.constant.stringvalue());
codestream.invokestringconcatenationstringconstructor();
// invokespecial: java.lang.stringbuffer.<init>(ljava.lang.string;)v
break;
}
} else {
cursor.generateoptimizedstringconcatenationcreation(blockscope,
codestream, cursor.implicitconversion &
typeids.compile_type_mask);
break;
}
}
restart++;
if (restart == 0) { // reached the leftmost expression
cursor.left.generateoptimizedstringconcatenationcreation(
blockscope,
codestream,
cursor.left.implicitconversion & typeids.compile_type_mask);
}
int pcaux;
for (int i = restart; i < this.arity; i++) {
codestream.recordpositionsfrom(pc,
(cursor = this.referencestable[i]).left.sourcestart);
pcaux = codestream.position;
cursor.right.generateoptimizedstringconcatenation(blockscope,
codestream,	cursor.right.implicitconversion &
typeids.compile_type_mask);
codestream.recordpositionsfrom(pcaux, cursor.right.sourcestart);
}
codestream.recordpositionsfrom(pc, this.left.sourcestart);
pc = codestream.position;
this.right.generateoptimizedstringconcatenation(
blockscope,
codestream,
this.right.implicitconversion & typeids.compile_type_mask);
codestream.recordpositionsfrom(pc, this.right.sourcestart);
} else {
super.generateoptimizedstringconcatenationcreation(blockscope,
codestream, typeid);
}
}
}
private void initarity(expression expression, int value) {
this.arity = value;
if (value > 1) {
this.referencestable = new binaryexpression[value];
this.referencestable[value - 1] = (binaryexpression) expression;
for (int i = value - 1; i > 0; i--) {
this.referencestable[i - 1] =
(binaryexpression) this.referencestable[i].left;
}
} else {
this.aritymax = defaultaritymaxstartingvalue;
}
}

public stringbuffer printexpressionnoparenthesis(int indent,
stringbuffer output) {
// keep implementation in sync with
// binaryexpression#printexpressionnoparenthesis and
// operatorexpression#printexpression
if (this.referencestable == null) {
return super.printexpressionnoparenthesis(indent, output);
}
string operatorstring = operatortostring();
for (int i = this.arity - 1; i >= 0; i--) {
output.append('(');
}
output = this.referencestable[0].left.
printexpression(indent, output);
for (int i = 0, end = this.arity;
i < end; i++) {
output.append(' ').append(operatorstring).append(' ');
output = this.referencestable[i].right.
printexpression(0, output);
output.append(')');
}
output.append(' ').append(operatorstring).append(' ');
return this.right.printexpression(0, output);
}

public typebinding resolvetype(blockscope scope) {
// keep implementation in sync with binaryexpression#resolvetype
if (this.referencestable == null) {
return super.resolvetype(scope);
}
binaryexpression cursor;
if ((cursor = this.referencestable[0]).left instanceof castexpression) {
cursor.left.bits |= astnode.disableunnecessarycastcheck;
// will check later on
}
cursor.left.resolvetype(scope);
for (int i = 0, end = this.arity; i < end; i ++) {
this.referencestable[i].nonrecursiveresolvetypeupwards(scope);
}
nonrecursiveresolvetypeupwards(scope);
return this.resolvedtype;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (this.referencestable == null) {
super.traverse(visitor, scope);
} else {
if (visitor.visit(this, scope)) {
int restart;
for (restart = this.arity - 1;
restart >= 0;
restart--) {
if (!visitor.visit(
this.referencestable[restart], scope)) {
visitor.endvisit(
this.referencestable[restart], scope);
break;
}
}
restart++;
// restart now points to the deepest be for which
// visit returned true, if any
if (restart == 0) {
this.referencestable[0].left.traverse(visitor, scope);
}
for (int i = restart, end = this.arity;
i < end; i++) {
this.referencestable[i].right.traverse(visitor, scope);
visitor.endvisit(this.referencestable[i], scope);
}
this.right.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}

/**
* change {@@link #aritymax} if and as needed. the current policy is to double
* aritymax each time this method is called, until it reaches
* {@@link #arity_max_max}. other policies may consider incrementing it less
* agressively. call only after an appropriate value has been assigned to
* {@@link #left}.
*/
// more sophisticate increment policies would leverage the leftmost expression
// to hold an indication of the number of uses of a given aritymax in a row
public void tunearitymax() {
if (this.aritymax < arity_max_max) {
this.aritymax *= 2;
}
}
}
