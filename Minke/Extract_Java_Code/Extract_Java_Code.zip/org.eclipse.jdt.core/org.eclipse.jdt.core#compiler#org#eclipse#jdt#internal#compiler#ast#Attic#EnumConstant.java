/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.compilationunitscope;
import org.eclipse.jdt.internal.compiler.problem.aborttype;

/**
* enum constant node
*/
public class enumconstant extends typedeclaration {

public expression[] arguments;

public enumconstant(compilationresult compilationresult) {
super(compilationresult);
this.compilationresult = compilationresult;
}

public stringbuffer print(int indent, stringbuffer output) {
output.append(name);
if (arguments != null) {
output.append('(');
int length = arguments.length;
for (int i = 0; i < length - 1; i++) {
arguments[i].print(0, output);
output.append(", ");//$non-nls-1$
}
arguments[length - 1].print(0, output);
output.append(')');
}
printbody(indent, output);
return output;
}

/**
*	iteration for a package member type
*
*/
public void traverse(
astvisitor visitor,
compilationunitscope unitscope) {

if (ignorefurtherinvestigation)
return;
try {
if (visitor.visit(this, unitscope)) {
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, scope);
}
if (this.arguments != null) {
int length = this.arguments.length;
for (int i = 0; i < length; i++)
this.arguments[i].traverse(visitor, scope);
}
if (this.membertypes != null) {
int length = this.membertypes.length;
for (int i = 0; i < length; i++)
this.membertypes[i].traverse(visitor, scope);
}
if (this.enums != null) {
int length = this.enums.length;
for (int i = 0; i < length; i++)
this.enums[i].traverse(visitor, scope);
}
if (this.fields != null) {
int length = this.fields.length;
for (int i = 0; i < length; i++) {
fielddeclaration field;
if ((field = this.fields[i]).isstatic()) {
field.traverse(visitor, staticinitializerscope);
} else {
field.traverse(visitor, initializerscope);
}
}
}
if (this.methods != null) {
int length = this.methods.length;
for (int i = 0; i < length; i++)
this.methods[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, unitscope);
} catch (aborttype e) {
// silent abort
}
}

/**
*	iteration for a local innertype
*
*/
public void traverse(astvisitor visitor, blockscope blockscope) {

if (ignorefurtherinvestigation)
return;
try {
if (visitor.visit(this, blockscope)) {
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, scope);
}
if (this.arguments != null) {
int length = this.arguments.length;
for (int i = 0; i < length; i++)
this.arguments[i].traverse(visitor, scope);
}
if (this.membertypes != null) {
int length = this.membertypes.length;
for (int i = 0; i < length; i++)
this.membertypes[i].traverse(visitor, scope);
}
if (this.enums != null) {
int length = this.enums.length;
for (int i = 0; i < length; i++)
this.enums[i].traverse(visitor, scope);
}
if (this.fields != null) {
int length = this.fields.length;
for (int i = 0; i < length; i++) {
fielddeclaration field;
if ((field = this.fields[i]).isstatic()) {
field.traverse(visitor, staticinitializerscope);
} else {
field.traverse(visitor, initializerscope);
}
}
}
if (this.methods != null) {
int length = this.methods.length;
for (int i = 0; i < length; i++)
this.methods[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, blockscope);
} catch (aborttype e) {
// silent abort
}
}

/**
*	iteration for a member innertype
*
*/
public void traverse(astvisitor visitor, classscope classscope) {

if (ignorefurtherinvestigation)
return;
try {
if (visitor.visit(this, classscope)) {
if (this.annotations != null) {
int annotationslength = this.annotations.length;
for (int i = 0; i < annotationslength; i++)
this.annotations[i].traverse(visitor, scope);
}
if (this.arguments != null) {
int length = this.arguments.length;
for (int i = 0; i < length; i++)
this.arguments[i].traverse(visitor, scope);
}
if (this.membertypes != null) {
int length = this.membertypes.length;
for (int i = 0; i < length; i++)
this.membertypes[i].traverse(visitor, scope);
}
if (this.enums != null) {
int length = this.enums.length;
for (int i = 0; i < length; i++)
this.enums[i].traverse(visitor, scope);
}
if (this.fields != null) {
int length = this.fields.length;
for (int i = 0; i < length; i++) {
fielddeclaration field;
if ((field = this.fields[i]).isstatic()) {
field.traverse(visitor, staticinitializerscope);
} else {
field.traverse(visitor, initializerscope);
}
}
}
if (this.methods != null) {
int length = this.methods.length;
for (int i = 0; i < length; i++)
this.methods[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, classscope);
} catch (aborttype e) {
// silent abort
}
}
}@


1.3
log
@head - add 1.5 construct support inside the code formatter. need further improvement.
