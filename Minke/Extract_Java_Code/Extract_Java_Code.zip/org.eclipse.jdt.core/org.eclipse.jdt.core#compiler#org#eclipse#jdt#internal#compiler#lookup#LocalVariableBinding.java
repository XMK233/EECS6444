/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.annotation;
import org.eclipse.jdt.internal.compiler.ast.localdeclaration;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.impl.referencecontext;

public class localvariablebinding extends variablebinding {

public int resolvedposition; // for code generation (position in method context)

public static final int unused = 0;
public static final int used = 1;
public static final int fake_used = 2;
public int useflag; // for flow analysis (default is unused)

public blockscope declaringscope; // back-pointer to its declaring scope
public localdeclaration declaration; // for source-positions

public int[] initializationpcs;
public int initializationcount = 0;

// for synthetic local variables
// if declaration slot is not positionned, the variable will not be listed in attribute
// note that the name of a variable should be chosen so as not to conflict with user ones (usually starting with a space char is all needed)
public localvariablebinding(char[] name, typebinding type, int modifiers, boolean isargument) {
super(name, type, modifiers, isargument ? constant.notaconstant : null);
if (isargument) this.tagbits |= tagbits.isargument;
}

// regular local variable or argument
public localvariablebinding(localdeclaration declaration, typebinding type, int modifiers, boolean isargument) {

this(declaration.name, type, modifiers, isargument);
this.declaration = declaration;
}

/* api
* answer the receiver's binding type from binding.bindingid.
*/
public final int kind() {
return local;
}

/*
* declaringuniquekey # scopeindex(0-based) # varname [# occurrencecount(0-based)]
* p.x { void foo() { int local; int local;} } --> lp/x;.foo()v#1#local#1
*/
public char[] computeuniquekey(boolean isleaf) {
stringbuffer buffer = new stringbuffer();

// declaring method or type
blockscope scope = this.declaringscope;
int occurencecount = 0;
if (scope != null) {
// the scope can be null. see https://bugs.eclipse.org/bugs/show_bug.cgi?id=185129
methodscope methodscope = scope instanceof methodscope ? (methodscope) scope : scope.enclosingmethodscope();
referencecontext referencecontext = methodscope.referencecontext;
if (referencecontext instanceof abstractmethoddeclaration) {
methodbinding methodbinding = ((abstractmethoddeclaration) referencecontext).binding;
if (methodbinding != null) {
buffer.append(methodbinding.computeuniquekey(false/*not a leaf*/));
}
} else if (referencecontext instanceof typedeclaration) {
typebinding typebinding = ((typedeclaration) referencecontext).binding;
if (typebinding != null) {
buffer.append(typebinding.computeuniquekey(false/*not a leaf*/));
}
}

// scope index
getscopekey(scope, buffer);

// find number of occurences of a variable with the same name in the scope
localvariablebinding[] locals = scope.locals;
for (int i = 0; i < scope.localindex; i++) { // use linear search assuming the number of locals per scope is low
localvariablebinding local = locals[i];
if (charoperation.equals(this.name, local.name)) {
if (this == local)
break;
occurencecount++;
}
}
}
// variable name
buffer.append('#');
buffer.append(this.name);

// add occurence count to avoid same key for duplicate variables
// (see https://bugs.eclipse.org/bugs/show_bug.cgi?id=149590)
if (occurencecount > 0) {
buffer.append('#');
buffer.append(occurencecount);
}

int length = buffer.length();
char[] uniquekey = new char[length];
buffer.getchars(0, length, uniquekey, 0);
return uniquekey;
}

public annotationbinding[] getannotations() {
if (this.declaringscope == null) {
if ((this.tagbits & tagbits.annotationresolved) != 0) {
// annotation are already resolved
if (this.declaration == null) {
return binding.no_annotations;
}
annotation[] annotations = this.declaration.annotations;
if (annotations != null) {
int length = annotations.length;
annotationbinding[] annotationbindings = new annotationbinding[length];
for (int i = 0; i < length; i++) {
annotationbinding compilerannotation = annotations[i].getcompilerannotation();
if (compilerannotation == null) {
return binding.no_annotations;
}
annotationbindings[i] = compilerannotation;
}
return annotationbindings;
}
}
return binding.no_annotations;
}
sourcetypebinding sourcetype = this.declaringscope.enclosingsourcetype();
if (sourcetype == null)
return binding.no_annotations;

annotationbinding[] annotations = sourcetype.retrieveannotations(this);
if ((this.tagbits & tagbits.annotationresolved) == 0) {
if (((this.tagbits & tagbits.isargument) != 0) && this.declaration != null) {
annotation[] annotationnodes = this.declaration.annotations;
if (annotationnodes != null) {
int length = annotationnodes.length;
astnode.resolveannotations(this.declaringscope, annotationnodes, this);
annotations = new annotationbinding[length];
for (int i = 0; i < length; i++)
annotations[i] = new annotationbinding(annotationnodes[i]);
setannotations(annotations);
}
}
}
return annotations;
}

private void getscopekey(blockscope scope, stringbuffer buffer) {
int scopeindex = scope.scopeindex();
if (scopeindex != -1) {
getscopekey((blockscope)scope.parent, buffer);
buffer.append('#');
buffer.append(scopeindex);
}
}

// answer whether the variable binding is a secret variable added for code gen purposes
public boolean issecret() {

return this.declaration == null && (this.tagbits & tagbits.isargument) == 0;
}

public void recordinitializationendpc(int pc) {

if (this.initializationpcs[((this.initializationcount - 1) << 1) + 1] == -1)
this.initializationpcs[((this.initializationcount - 1) << 1) + 1] = pc;
}

public void recordinitializationstartpc(int pc) {

if (this.initializationpcs == null) {
return;
}
if (this.initializationcount > 0) {
int previousendpc = this.initializationpcs[ ((this.initializationcount - 1) << 1) + 1];
// interval still open, keep using it (108180)
if (previousendpc == -1) {
return;
}
// optimize cases where reopening a contiguous interval
if (previousendpc == pc) {
this.initializationpcs[ ((this.initializationcount - 1) << 1) + 1] = -1; // reuse previous interval (its range will be augmented)
return;
}
}
int index = this.initializationcount << 1;
if (index == this.initializationpcs.length) {
system.arraycopy(this.initializationpcs, 0, (this.initializationpcs = new int[this.initializationcount << 2]), 0, index);
}
this.initializationpcs[index] = pc;
this.initializationpcs[index + 1] = -1;
this.initializationcount++;
}

public void setannotations(annotationbinding[] annotations) {
if (this.declaringscope == null) return;

sourcetypebinding sourcetype = this.declaringscope.enclosingsourcetype();
if (sourcetype != null)
sourcetype.storeannotations(this, annotations);
}

public void resetinitializations() {
this.initializationcount = 0;
this.initializationpcs = null;
}

public string tostring() {

string s = super.tostring();
switch (this.useflag){
case used:
s += "[pos: " + string.valueof(this.resolvedposition) + "]"; //$non-nls-2$ //$non-nls-1$
break;
case unused:
s += "[pos: unused]"; //$non-nls-1$
break;
case fake_used:
s += "[pos: fake_used]"; //$non-nls-1$
break;
}
s += "[id:" + string.valueof(this.id) + "]"; //$non-nls-2$ //$non-nls-1$
if (this.initializationcount > 0) {
s += "[pc: "; //$non-nls-1$
for (int i = 0; i < this.initializationcount; i++) {
if (i > 0)
s += ", "; //$non-nls-1$
s += string.valueof(this.initializationpcs[i << 1]) + "-" + ((this.initializationpcs[(i << 1) + 1] == -1) ? "?" : string.valueof(this.initializationpcs[(i<< 1) + 1])); //$non-nls-2$ //$non-nls-1$
}
s += "]"; //$non-nls-1$
}
return s;
}
}
