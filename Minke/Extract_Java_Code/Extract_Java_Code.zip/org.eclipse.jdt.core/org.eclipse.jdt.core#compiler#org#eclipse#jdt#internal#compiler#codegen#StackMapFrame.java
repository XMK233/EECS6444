/*******************************************************************************
* copyright (c) 2005, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

import java.text.messageformat;

import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;

public class stackmapframe {
public static final int used = 1;
public static final int same_frame = 0;
public static final int chop_frame = 1;
public static final int append_frame = 2;
public static final int same_frame_extended = 3;
public static final int full_frame = 4;
public static final int same_locals_1_stack_items = 5;
public static final int same_locals_1_stack_items_extended = 6;

public int pc;
public int numberofstackitems;
private int numberoflocals;
public int localindex;
public verificationtypeinfo[] locals;
public verificationtypeinfo[] stackitems;
private int numberofdifferentlocals = -1;
public int tagbits;

public stackmapframe(int initiallocalsize) {
this.locals = new verificationtypeinfo[initiallocalsize];
this.numberoflocals = -1;
this.numberofdifferentlocals = -1;
}
public int getframetype(stackmapframe prevframe) {
final int offsetdelta = getoffsetdelta(prevframe);
switch(this.numberofstackitems) {
case 0 :
switch(numberofdifferentlocals(prevframe)) {
case 0 :
return offsetdelta <= 63 ? same_frame : same_frame_extended;
case 1 :
case 2 :
case 3 :
return append_frame;
case -1 :
case -2 :
case -3 :
return chop_frame;
}
break;
case 1 :
switch(numberofdifferentlocals(prevframe)) {
case 0 :
return offsetdelta <= 63 ? same_locals_1_stack_items : same_locals_1_stack_items_extended;
}
}
return full_frame;
}
public void addlocal(int resolvedposition, verificationtypeinfo info) {
if (this.locals == null) {
this.locals = new verificationtypeinfo[resolvedposition + 1];
this.locals[resolvedposition] = info;
} else {
final int length = this.locals.length;
if (resolvedposition >= length) {
system.arraycopy(this.locals, 0, this.locals = new verificationtypeinfo[resolvedposition + 1], 0, length);
}
this.locals[resolvedposition] = info;
}
}
public void addstackitem(verificationtypeinfo info) {
if (info == null) {
throw new illegalargumentexception("info cannot be null"); //$non-nls-1$
}
if (this.stackitems == null) {
this.stackitems = new verificationtypeinfo[1];
this.stackitems[0] = info;
this.numberofstackitems = 1;
} else {
final int length = this.stackitems.length;
if (this.numberofstackitems == length) {
system.arraycopy(this.stackitems, 0, this.stackitems = new verificationtypeinfo[length + 1], 0, length);
}
this.stackitems[this.numberofstackitems++] = info;
}
}
public void addstackitem(typebinding binding) {
if (this.stackitems == null) {
this.stackitems = new verificationtypeinfo[1];
this.stackitems[0] = new verificationtypeinfo(binding);
this.numberofstackitems = 1;
} else {
final int length = this.stackitems.length;
if (this.numberofstackitems == length) {
system.arraycopy(this.stackitems, 0, this.stackitems = new verificationtypeinfo[length + 1], 0, length);
}
this.stackitems[this.numberofstackitems++] = new verificationtypeinfo(binding);
}
}
public stackmapframe duplicate() {
int length = this.locals.length;
stackmapframe result = new stackmapframe(length);
result.numberoflocals = -1;
result.numberofdifferentlocals = -1;
result.pc = this.pc;
result.numberofstackitems = this.numberofstackitems;

if (length != 0) {
result.locals = new verificationtypeinfo[length];
for (int i = 0; i < length; i++) {
final verificationtypeinfo verificationtypeinfo = this.locals[i];
if (verificationtypeinfo != null) {
result.locals[i] = verificationtypeinfo.duplicate();
}
}
}
length = this.numberofstackitems;
if (length != 0) {
result.stackitems = new verificationtypeinfo[length];
for (int i = 0; i < length; i++) {
result.stackitems[i] = this.stackitems[i].duplicate();
}
}
return result;
}
public int numberofdifferentlocals(stackmapframe prevframe) {
if (this.numberofdifferentlocals != -1) return this.numberofdifferentlocals;
if (prevframe == null) {
this.numberofdifferentlocals = 0;
return 0;
}
verificationtypeinfo[] prevlocals = prevframe.locals;
verificationtypeinfo[] currentlocals = this.locals;
int prevlocalslength = prevlocals == null ? 0 : prevlocals.length;
int currentlocalslength = currentlocals == null ? 0 : currentlocals.length;
int prevnumberoflocals = prevframe.getnumberoflocals();
int currentnumberoflocals = getnumberoflocals();

int result = 0;
if (prevnumberoflocals == 0) {
if (currentnumberoflocals != 0) {
// need to check if there is a hole in the locals
result = currentnumberoflocals; // append if no hole and currentnumberoflocals <= 3
int counter = 0;
for(int i = 0; i < currentlocalslength && counter < currentnumberoflocals; i++) {
if (currentlocals[i] != null) {
switch(currentlocals[i].id()) {
case typeids.t_double :
case typeids.t_long :
i++;
}
counter++;
} else {
result = integer.max_value;
this.numberofdifferentlocals = result;
return result;
}
}
}
} else if (currentnumberoflocals == 0) {
// need to check if there is a hole in the prev locals
int counter = 0;
result = -prevnumberoflocals; // chop frame if no hole and prevnumberoflocals <= 3
for(int i = 0; i < prevlocalslength && counter < prevnumberoflocals; i++) {
if (prevlocals[i] != null) {
switch(prevlocals[i].id()) {
case typeids.t_double :
case typeids.t_long :
i++;
}
counter++;
} else {
result = integer.max_value;
this.numberofdifferentlocals = result;
return result;
}
}
} else {
// need to see if prevlocals matches with currentlocals
int indexinprevlocals = 0;
int indexincurrentlocals = 0;
int currentlocalscounter = 0;
int prevlocalscounter = 0;
currentlocalsloop: for (;indexincurrentlocals < currentlocalslength && currentlocalscounter < currentnumberoflocals; indexincurrentlocals++) {
verificationtypeinfo currentlocal = currentlocals[indexincurrentlocals];
if (currentlocal != null) {
currentlocalscounter++;
switch(currentlocal.id()) {
case typeids.t_double :
case typeids.t_long :
indexincurrentlocals++; // next entry  is null
}
}
if (indexinprevlocals < prevlocalslength && prevlocalscounter < prevnumberoflocals) {
verificationtypeinfo prevlocal = prevlocals[indexinprevlocals];
if (prevlocal != null) {
prevlocalscounter++;
switch(prevlocal.id()) {
case typeids.t_double :
case typeids.t_long :
indexinprevlocals++; // next entry  is null
}
}
// now we need to check if prevlocal matches with currentlocal
// the index must be the same
if (equals(prevlocal, currentlocal) && indexinprevlocals == indexincurrentlocals) {
if (result != 0) {
result = integer.max_value;
this.numberofdifferentlocals = result;
return result;
}
} else {
// locals at the same location are not equals - this has to be a full frame
result = integer.max_value;
this.numberofdifferentlocals = result;
return result;
}
indexinprevlocals++;
continue currentlocalsloop;
}
// process remaining current locals
if (currentlocal != null) {
result++;
} else {
result = integer.max_value;
this.numberofdifferentlocals = result;
return result;
}
indexincurrentlocals++;
break currentlocalsloop;
}
if (currentlocalscounter < currentnumberoflocals) {
for(;indexincurrentlocals < currentlocalslength && currentlocalscounter < currentnumberoflocals; indexincurrentlocals++) {
verificationtypeinfo currentlocal = currentlocals[indexincurrentlocals];
if (currentlocal == null) {
result = integer.max_value;
this.numberofdifferentlocals = result;
return result;
}
result++;
currentlocalscounter++;
switch(currentlocal.id()) {
case typeids.t_double :
case typeids.t_long :
indexincurrentlocals++; // next entry  is null
}
}
} else if (prevlocalscounter < prevnumberoflocals) {
result = -result;
// process possible remaining prev locals
for(; indexinprevlocals < prevlocalslength && prevlocalscounter < prevnumberoflocals; indexinprevlocals++) {
verificationtypeinfo prevlocal = prevlocals[indexinprevlocals];
if (prevlocal == null) {
result = integer.max_value;
this.numberofdifferentlocals = result;
return result;
}
result--;
prevlocalscounter++;
switch(prevlocal.id()) {
case typeids.t_double :
case typeids.t_long :
indexinprevlocals++; // next entry  is null
}
}
}
}
this.numberofdifferentlocals = result;
return result;
}
public int getnumberoflocals() {
if (this.numberoflocals != -1) {
return this.numberoflocals;
}
int result = 0;
final int length = this.locals == null ? 0 : this.locals.length;
for(int i = 0; i < length; i++) {
if (this.locals[i] != null) {
switch(this.locals[i].id()) {
case typeids.t_double :
case typeids.t_long :
i++;
}
result++;
}
}
this.numberoflocals = result;
return result;
}
public int getoffsetdelta(stackmapframe prevframe) {
if (prevframe == null) return this.pc;
return prevframe.pc == -1 ? this.pc : this.pc - prevframe.pc - 1;
}
public string tostring() {
stringbuffer buffer = new stringbuffer();
printframe(buffer, this);
return string.valueof(buffer);
}
private void printframe(stringbuffer buffer, stackmapframe frame) {
string pattern = "[pc : {0} locals: {1} stack items: {2}\nlocals: {3}\nstack: {4}\n]"; //$non-nls-1$
int localslength = frame.locals == null ? 0 : frame.locals.length;
buffer.append(messageformat.format(
pattern,
new string[] {
integer.tostring(frame.pc),
integer.tostring(frame.getnumberoflocals()),
integer.tostring(frame.numberofstackitems),
print(frame.locals, localslength),
print(frame.stackitems, frame.numberofstackitems)
}
));
}
private string print(verificationtypeinfo[] infos, int length) {
stringbuffer buffer = new stringbuffer();
buffer.append('[');
if (infos != null) {
for (int i = 0; i < length; i++) {
if (i != 0) buffer.append(',');
verificationtypeinfo verificationtypeinfo = infos[i];
if (verificationtypeinfo == null) {
buffer.append("top"); //$non-nls-1$
continue;
}
buffer.append(verificationtypeinfo);
}
}
buffer.append(']');
return string.valueof(buffer);
}
public void putlocal(int resolvedposition, verificationtypeinfo info) {
if (this.locals == null) {
this.locals = new verificationtypeinfo[resolvedposition + 1];
this.locals[resolvedposition] = info;
} else {
final int length = this.locals.length;
if (resolvedposition >= length) {
system.arraycopy(this.locals, 0, this.locals = new verificationtypeinfo[resolvedposition + 1], 0, length);
}
this.locals[resolvedposition] = info;
}
}
public void replacewithelementtype() {
verificationtypeinfo info = this.stackitems[this.numberofstackitems - 1];
verificationtypeinfo info2 = info.duplicate();
info2.replacewithelementtype();
this.stackitems[this.numberofstackitems - 1] = info2;
}
public int getindexofdifferentlocals(int differentlocalscount) {
for (int i = this.locals.length - 1; i >= 0; i--) {
verificationtypeinfo currentlocal = this.locals[i];
if (currentlocal == null) {
// check the previous slot
continue;
} else {
differentlocalscount--;
}
if (differentlocalscount == 0) {
return i;
}
}
return 0;
}
private boolean equals(verificationtypeinfo info, verificationtypeinfo info2) {
if (info == null) {
return info2 == null;
}
if (info2 == null) return false;
return info.equals(info2);
}
}
