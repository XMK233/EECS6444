/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typevariablebinding;

public class typeparameter extends abstractvariabledeclaration {

public typevariablebinding binding;
public typereference[] bounds;

/**
* @@see org.eclipse.jdt.internal.compiler.ast.abstractvariabledeclaration#getkind()
*/
public int getkind() {
return type_parameter;
}

public void checkbounds(scope scope) {

if (this.type != null) {
this.type.checkbounds(scope);
}
if (this.bounds != null) {
for (int i = 0, length = this.bounds.length; i < length; i++) {
this.bounds[i].checkbounds(scope);
}
}
}

private void internalresolve(scope scope, boolean staticcontext) {
// detect variable/type name collisions
if (this.binding != null) {
binding existingtype = scope.parent.getbinding(this.name, binding.type, this, false/*do not resolve hidden field*/);
if (existingtype != null
&& this.binding != existingtype
&& existingtype.isvalidbinding()
&& (existingtype.kind() != binding.type_parameter || !staticcontext)) {
scope.problemreporter().typehiding(this, existingtype);
}
}
}

public void resolve(blockscope scope) {
internalresolve(scope, scope.methodscope().isstatic);
}

public void resolve(classscope scope) {
internalresolve(scope, scope.enclosingsourcetype().isstatic());
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#print(int, java.lang.stringbuffer)
*/
public stringbuffer printstatement(int indent, stringbuffer output) {
output.append(this.name);
if (this.type != null) {
output.append(" extends "); //$non-nls-1$
this.type.print(0, output);
}
if (this.bounds != null){
for (int i = 0; i < this.bounds.length; i++) {
output.append(" & "); //$non-nls-1$
this.bounds[i].print(0, output);
}
}
return output;
}

public void generatecode(blockscope currentscope, codestream codestream) {
// nothing to do
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.type != null) {
this.type.traverse(visitor, scope);
}
if (this.bounds != null) {
int boundslength = this.bounds.length;
for (int i = 0; i < boundslength; i++) {
this.bounds[i].traverse(visitor, scope);
}
}
}
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {
if (visitor.visit(this, scope)) {
if (this.type != null) {
this.type.traverse(visitor, scope);
}
if (this.bounds != null) {
int boundslength = this.bounds.length;
for (int i = 0; i < boundslength; i++) {
this.bounds[i].traverse(visitor, scope);
}
}
}
visitor.endvisit(this, scope);
}
}
