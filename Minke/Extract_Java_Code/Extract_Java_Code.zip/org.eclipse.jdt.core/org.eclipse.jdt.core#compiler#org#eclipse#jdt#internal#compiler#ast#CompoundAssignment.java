/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class compoundassignment extends assignment implements operatorids {
public int operator;
public int preassignimplicitconversion;

//  var op exp is equivalent to var = (vartype) var op exp
// assignmentimplicitconversion stores the cast needed for the assignment

public compoundassignment(expression lhs, expression expression,int operator, int sourceend) {
//lhs is always a reference by construction ,
//but is build as an expression ==> the checkcast cannot fail

super(lhs, expression, sourceend);
lhs.bits &= ~isstrictlyassigned; // tag lhs as non assigned - it is also a read access
lhs.bits |= iscompoundassigned; // tag lhs as assigned by compound
this.operator = operator ;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext,
flowinfo flowinfo) {
// record setting a variable: various scenarii are possible, setting an array reference,
// a field reference, a blank final field reference, a field of an enclosing instance or
// just a local variable.
if (this.resolvedtype.id != t_javalangstring) {
this.lhs.checknpe(currentscope, flowcontext, flowinfo);
}
return  ((reference) this.lhs).analyseassignment(currentscope, flowcontext, flowinfo, this, true).unconditionalinits();
}

public boolean checkcastcompatibility() {
return true;
}
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {

// various scenarii are possible, setting an array reference,
// a field reference, a blank final field reference, a field of an enclosing instance or
// just a local variable.

int pc = codestream.position;
((reference) this.lhs).generatecompoundassignment(currentscope, codestream, this.expression, this.operator, this.preassignimplicitconversion, valuerequired);
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public int nullstatus(flowinfo flowinfo) {
return flowinfo.non_null;
// we may have complained on checknpe, but we avoid duplicate error
}

public string operatortostring() {
switch (this.operator) {
case plus :
return "+="; //$non-nls-1$
case minus :
return "-="; //$non-nls-1$
case multiply :
return "*="; //$non-nls-1$
case divide :
return "/="; //$non-nls-1$
case and :
return "&="; //$non-nls-1$
case or :
return "|="; //$non-nls-1$
case xor :
return "^="; //$non-nls-1$
case remainder :
return "%="; //$non-nls-1$
case left_shift :
return "<<="; //$non-nls-1$
case right_shift :
return ">>="; //$non-nls-1$
case unsigned_right_shift :
return ">>>="; //$non-nls-1$
}
return "unknown operator"; //$non-nls-1$
}

public stringbuffer printexpressionnoparenthesis(int indent, stringbuffer output) {

this.lhs.printexpression(indent, output).append(' ').append(operatortostring()).append(' ');
return this.expression.printexpression(0, output) ;
}

public typebinding resolvetype(blockscope scope) {
this.constant = constant.notaconstant;
if (!(this.lhs instanceof reference) || this.lhs.isthis()) {
scope.problemreporter().expressionshouldbeavariable(this.lhs);
return null;
}
boolean expressioniscast = this.expression instanceof castexpression;
if (expressioniscast)
this.expression.bits |= astnode.disableunnecessarycastcheck; // will check later on
typebinding originallhstype = this.lhs.resolvetype(scope);
typebinding originalexpressiontype = this.expression.resolvetype(scope);
if (originallhstype == null || originalexpressiontype == null)
return null;

// autoboxing support
lookupenvironment env = scope.environment();
typebinding lhstype = originallhstype, expressiontype = originalexpressiontype;
boolean use15specifics = scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
boolean unboxedlhs = false;
if (use15specifics) {
if (!lhstype.isbasetype() && expressiontype.id != t_javalangstring && expressiontype.id != t_null) {
typebinding unboxedtype = env.computeboxingtype(lhstype);
if (unboxedtype != lhstype) {
lhstype = unboxedtype;
unboxedlhs = true;
}
}
if (!expressiontype.isbasetype() && lhstype.id != t_javalangstring  && lhstype.id != t_null) {
expressiontype = env.computeboxingtype(expressiontype);
}
}

if (restrainusagetonumerictypes() && !lhstype.isnumerictype()) {
scope.problemreporter().operatoronlyvalidonnumerictype(this, lhstype, expressiontype);
return null;
}
int lhsid = lhstype.id;
int expressionid = expressiontype.id;
if (lhsid > 15 || expressionid > 15) {
if (lhsid != t_javalangstring) { // string += thread is valid whereas thread += string  is not
scope.problemreporter().invalidoperator(this, lhstype, expressiontype);
return null;
}
expressionid = t_javalangobject; // use the object has tag table
}

// the code is an int
// (cast)  left   op (cast)  rigth --> result
//  0000   0000       0000   0000      0000
//  <<16   <<12       <<8     <<4        <<0

// the conversion is stored into the reference (info needed for the code gen)
int result = operatorexpression.operatorsignatures[this.operator][ (lhsid << 4) + expressionid];
if (result == t_undefined) {
scope.problemreporter().invalidoperator(this, lhstype, expressiontype);
return null;
}
if (this.operator == plus){
if(lhsid == t_javalangobject && (scope.compileroptions().compliancelevel < classfileconstants.jdk1_7)) {
// <object> += <string> is illegal (39248) for compliance < 1.7
scope.problemreporter().invalidoperator(this, lhstype, expressiontype);
return null;
} else {
// <int | boolean> += <string> is illegal
if ((lhstype.isnumerictype() || lhsid == t_boolean) && !expressiontype.isnumerictype()){
scope.problemreporter().invalidoperator(this, lhstype, expressiontype);
return null;
}
}
}
typebinding resulttype = typebinding.wellknowntype(scope, result & 0x0000f);
if (checkcastcompatibility()) {
if (originallhstype.id != t_javalangstring && resulttype.id != t_javalangstring) {
if (!checkcasttypescompatibility(scope, originallhstype, resulttype, null)) {
scope.problemreporter().invalidoperator(this, originallhstype, expressiontype);
return null;
}
}
}
this.lhs.computeconversion(scope, typebinding.wellknowntype(scope, (result >>> 16) & 0x0000f), originallhstype);
this.expression.computeconversion(scope, typebinding.wellknowntype(scope, (result >>> 8) & 0x0000f), originalexpressiontype);
this.preassignimplicitconversion =  (unboxedlhs ? boxing : 0) | (lhsid << 4) | (result & 0x0000f);
if (unboxedlhs) scope.problemreporter().autoboxing(this, lhstype, originallhstype);
if (expressioniscast)
castexpression.checkneedforargumentcasts(scope, this.operator, result, this.lhs, originallhstype.id, false, this.expression, originalexpressiontype.id, true);
return this.resolvedtype = originallhstype;
}

public boolean restrainusagetonumerictypes(){
return false ;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
this.lhs.traverse(visitor, scope);
this.expression.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
