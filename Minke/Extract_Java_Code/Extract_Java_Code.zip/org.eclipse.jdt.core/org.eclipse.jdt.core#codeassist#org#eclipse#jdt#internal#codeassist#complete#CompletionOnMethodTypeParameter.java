/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.ast.methoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.typeparameter;

public class completiononmethodtypeparameter extends methoddeclaration {
public completiononmethodtypeparameter(typeparameter[] typeparameters, compilationresult compilationresult){
super(compilationresult);
this.selector = charoperation.no_char;
this.typeparameters = typeparameters;
this.sourcestart = typeparameters[0].sourcestart;
this.sourceend = typeparameters[typeparameters.length - 1].sourceend;
}

public void resolvestatements() {
throw new completionnodefound(this, this.scope);
}

public stringbuffer print(int tab, stringbuffer output) {
printindent(tab, output);
output.append('<');
int max = this.typeparameters.length - 1;
for (int j = 0; j < max; j++) {
this.typeparameters[j].print(0, output);
output.append(", ");//$non-nls-1$
}
this.typeparameters[max].print(0, output);
output.append('>');
return output;
}

}
