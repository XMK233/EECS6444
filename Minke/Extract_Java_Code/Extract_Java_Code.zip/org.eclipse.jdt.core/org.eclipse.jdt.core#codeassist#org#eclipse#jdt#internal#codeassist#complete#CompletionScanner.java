/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* scanner aware of a cursor location so as to discard trailing portions of identifiers
* containing the cursor location.
*
* cursor location denotes the position of the last character behind which completion
* got requested:
*  -1 means completion at the very beginning of the source
*	0  means completion behind the first character
*  n  means completion behind the n-th character
*/
import org.eclipse.jdt.core.compiler.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.parser.scanner;
import org.eclipse.jdt.internal.compiler.parser.scannerhelper;

public class completionscanner extends scanner {

public char[] completionidentifier;
public int cursorlocation;
public int endofemptytoken = -1;

/* source positions of the completedidentifier
* if inside actual identifier, end goes to the actual identifier
* end, in other words, beyond cursor location
*/
public int completedidentifierstart = 0;
public int completedidentifierend = -1;
public int unicodecharsize;

public static final char[] emptycompletionidentifier = {};

public completionscanner(long sourcelevel) {
super(
false /*comment*/,
false /*whitespace*/,
false /*nls*/,
sourcelevel,
null /*tasktags*/,
null/*taskpriorities*/,
true/*taskcasesensitive*/);
}
/*
* truncate the current identifier if it is containing the cursor location. since completion is performed
* on an identifier prefix.
*
*/
public char[] getcurrentidentifiersource() {

if (this.completionidentifier == null){
if (this.cursorlocation < this.startposition && this.currentposition == this.startposition){ // fake empty identifier got issued
// remember actual identifier positions
this.completedidentifierstart = this.startposition;
this.completedidentifierend = this.completedidentifierstart - 1;
return this.completionidentifier = emptycompletionidentifier;
}
if (this.cursorlocation+1 >= this.startposition && this.cursorlocation < this.currentposition){
// remember actual identifier positions
this.completedidentifierstart = this.startposition;
this.completedidentifierend = this.currentposition - 1;
if (this.withoutunicodeptr != 0){			// check unicode scenario
int length = this.cursorlocation + 1 - this.startposition - this.unicodecharsize;
system.arraycopy(this.withoutunicodebuffer, 1, this.completionidentifier = new char[length], 0, length);
} else {
// no char[] sharing around completionidentifier, we want it to be unique so as to use identity checks
int length = this.cursorlocation + 1 - this.startposition;
system.arraycopy(this.source, this.startposition, (this.completionidentifier = new char[length]), 0, length);
}
return this.completionidentifier;
}
}
return super.getcurrentidentifiersource();
}

public char[] getcurrenttokensourcestring() {
if (this.completionidentifier == null){
if (this.cursorlocation+1 >= this.startposition && this.cursorlocation < this.currentposition){
// remember actual identifier positions
this.completedidentifierstart = this.startposition;
this.completedidentifierend = this.currentposition - 1;
if (this.withoutunicodeptr != 0){			// check unicode scenario
int length = this.cursorlocation - this.startposition - this.unicodecharsize;
system.arraycopy(this.withoutunicodebuffer, 2, this.completionidentifier = new char[length], 0, length);
} else {
// no char[] sharing around completionidentifier, we want it to be unique so as to use identity checks
int length = this.cursorlocation - this.startposition;
system.arraycopy(this.source, this.startposition + 1, (this.completionidentifier = new char[length]), 0, length);
}
return this.completionidentifier;
}
}
return super.getcurrenttokensourcestring();
}
public int getnexttoken() throws invalidinputexception {

this.wasacr = false;
this.unicodecharsize = 0;
if (this.diet) {
jumpovermethodbody();
this.diet = false;
return this.currentposition > this.eofposition ? tokennameeof : tokennamerbrace;
}
int whitestart = 0;
try {
while (true) { //loop for jumping over comments
this.withoutunicodeptr = 0;
//start with a new token (even comment written with unicode )

// ---------consume white space and handles start position---------
whitestart = this.currentposition;
boolean iswhitespace, haswhitespaces = false;
int offset = 0;
do {
this.startposition = this.currentposition;
boolean checkifunicode = false;
try {
checkifunicode = ((this.currentcharacter = this.source[this.currentposition++]) == '\\')
&& (this.source[this.currentposition] == 'u');
} catch(indexoutofboundsexception e) {
if (this.tokenizewhitespace && (whitestart != this.currentposition - 1)) {
// reposition scanner in case we are interested by spaces as tokens
this.currentposition--;
this.startposition = whitestart;
return tokennamewhitespace;
}
if (this.currentposition > this.eofposition) {
/* might be completing at eof (e.g. behind a dot) */
if (this.completionidentifier == null &&
this.startposition == this.cursorlocation + 1){
this.currentposition = this.startposition; // for being detected as empty free identifier
return tokennameidentifier;
}
return tokennameeof;
}
}
if (checkifunicode) {
iswhitespace = jumpoverunicodewhitespace();
offset = 6;
} else {
offset = 1;
if ((this.currentcharacter == '\r') || (this.currentcharacter == '\n')) {
//checknonexternalizedstring();
if (this.recordlineseparator) {
pushlineseparator();
}
}
iswhitespace =
(this.currentcharacter == ' ') || charoperation.iswhitespace(this.currentcharacter);
}
if (iswhitespace) {
haswhitespaces = true;
}
/* completion requesting strictly inside blanks */
if ((whitestart != this.currentposition)
//&& (previoustoken == tokennamedot)
&& (this.completionidentifier == null)
&& (whitestart <= this.cursorlocation+1)
&& (this.cursorlocation < this.startposition)
&& !scannerhelper.isjavaidentifierstart(this.currentcharacter)){
this.currentposition = this.startposition; // for next token read
return tokennameidentifier;
}
} while (iswhitespace);
if (this.tokenizewhitespace && haswhitespaces) {
// reposition scanner in case we are interested by spaces as tokens
this.currentposition-=offset;
this.startposition = whitestart;
return tokennamewhitespace;
}
//little trick to get out in the middle of a source computation
if (this.currentposition > this.eofposition){
/* might be completing at eof (e.g. behind a dot) */
if (this.completionidentifier == null &&
this.startposition == this.cursorlocation + 1){
// compute end of empty identifier.
// if the empty identifier is at the start of a next token the end of
// empty identifier is the end of the next token (e.g. "<empty token>next").
int temp = this.eofposition;
this.eofposition = this.source.length;
while(getnextcharasjavaidentifierpart()){/*empty*/}
this.eofposition = temp;
this.endofemptytoken = this.currentposition - 1;
this.currentposition = this.startposition; // for being detected as empty free identifier
return tokennameidentifier;
}
return tokennameeof;
}

// ---------identify the next token-------------

switch (this.currentcharacter) {
case '@@' :
return tokennameat;
case '(' :
return tokennamelparen;
case ')' :
return tokennamerparen;
case '{' :
return tokennamelbrace;
case '}' :
return tokennamerbrace;
case '[' :
return tokennamelbracket;
case ']' :
return tokennamerbracket;
case ';' :
return tokennamesemicolon;
case ',' :
return tokennamecomma;
case '.' :
if (this.startposition <= this.cursorlocation
&& this.cursorlocation < this.currentposition){
return tokennamedot; // completion inside .<|>12
}
if (getnextcharasdigit()) {
return scannumber(true);
}
int temp = this.currentposition;
if (getnextchar('.')) {
if (getnextchar('.')) {
return tokennameellipsis;
} else {
this.currentposition = temp;
return tokennamedot;
}
} else {
this.currentposition = temp;
return tokennamedot;
}
case '+' :
{
int test;
if ((test = getnextchar('+', '=')) == 0)
return tokennameplus_plus;
if (test > 0)
return tokennameplus_equal;
return tokennameplus;
}
case '-' :
{
int test;
if ((test = getnextchar('-', '=')) == 0)
return tokennameminus_minus;
if (test > 0)
return tokennameminus_equal;
return tokennameminus;
}
case '~' :
return tokennametwiddle;
case '!' :
if (getnextchar('='))
return tokennamenot_equal;
return tokennamenot;
case '*' :
if (getnextchar('='))
return tokennamemultiply_equal;
return tokennamemultiply;
case '%' :
if (getnextchar('='))
return tokennameremainder_equal;
return tokennameremainder;
case '<' :
{
int test;
if ((test = getnextchar('=', '<')) == 0)
return tokennameless_equal;
if (test > 0) {
if (getnextchar('='))
return tokennameleft_shift_equal;
return tokennameleft_shift;
}
return tokennameless;
}
case '>' :
{
int test;
if (this.returnonlygreater) {
return tokennamegreater;
}
if ((test = getnextchar('=', '>')) == 0)
return tokennamegreater_equal;
if (test > 0) {
if ((test = getnextchar('=', '>')) == 0)
return tokennameright_shift_equal;
if (test > 0) {
if (getnextchar('='))
return tokennameunsigned_right_shift_equal;
return tokennameunsigned_right_shift;
}
return tokennameright_shift;
}
return tokennamegreater;
}
case '=' :
if (getnextchar('='))
return tokennameequal_equal;
return tokennameequal;
case '&' :
{
int test;
if ((test = getnextchar('&', '=')) == 0)
return tokennameand_and;
if (test > 0)
return tokennameand_equal;
return tokennameand;
}
case '|' :
{
int test;
if ((test = getnextchar('|', '=')) == 0)
return tokennameor_or;
if (test > 0)
return tokennameor_equal;
return tokennameor;
}
case '^' :
if (getnextchar('='))
return tokennamexor_equal;
return tokennamexor;
case '?' :
return tokennamequestion;
case ':' :
return tokennamecolon;
case '\'' :
{
int test;
if ((test = getnextchar('\n', '\r')) == 0) {
throw new invalidinputexception(invalid_character_constant);
}
if (test > 0) {
// relocate if finding another quote fairly close: thus unicode '/u000d' will be fully consumed
for (int lookahead = 0; lookahead < 3; lookahead++) {
if (this.currentposition + lookahead == this.eofposition)
break;
if (this.source[this.currentposition + lookahead] == '\n')
break;
if (this.source[this.currentposition + lookahead] == '\'') {
this.currentposition += lookahead + 1;
break;
}
}
throw new invalidinputexception(invalid_character_constant);
}
}
if (getnextchar('\'')) {
// relocate if finding another quote fairly close: thus unicode '/u000d' will be fully consumed
for (int lookahead = 0; lookahead < 3; lookahead++) {
if (this.currentposition + lookahead == this.eofposition)
break;
if (this.source[this.currentposition + lookahead] == '\n')
break;
if (this.source[this.currentposition + lookahead] == '\'') {
this.currentposition += lookahead + 1;
break;
}
}
throw new invalidinputexception(invalid_character_constant);
}
if (getnextchar('\\')) {
if (this.unicodeasbackslash) {
// consume next character
this.unicodeasbackslash = false;
if (((this.currentcharacter = this.source[this.currentposition++]) == '\\') && (this.source[this.currentposition] == 'u')) {
getnextunicodechar();
} else {
if (this.withoutunicodeptr != 0) {
unicodestore();
}
}
} else {
this.currentcharacter = this.source[this.currentposition++];
}
scanescapecharacter();
} else { // consume next character
this.unicodeasbackslash = false;
boolean checkifunicode = false;
try {
checkifunicode = ((this.currentcharacter = this.source[this.currentposition++]) == '\\')
&& (this.source[this.currentposition] == 'u');
} catch(indexoutofboundsexception e) {
this.currentposition--;
throw new invalidinputexception(invalid_character_constant);
}
if (checkifunicode) {
getnextunicodechar();
} else {
if (this.withoutunicodeptr != 0) {
unicodestore();
}
}
}
if (getnextchar('\''))
return tokennamecharacterliteral;
// relocate if finding another quote fairly close: thus unicode '/u000d' will be fully consumed
for (int lookahead = 0; lookahead < 20; lookahead++) {
if (this.currentposition + lookahead == this.eofposition)
break;
if (this.source[this.currentposition + lookahead] == '\n')
break;
if (this.source[this.currentposition + lookahead] == '\'') {
this.currentposition += lookahead + 1;
break;
}
}
throw new invalidinputexception(invalid_character_constant);
case '"' :
try {
// consume next character
this.unicodeasbackslash = false;
boolean isunicode = false;
if (((this.currentcharacter = this.source[this.currentposition++]) == '\\')
&& (this.source[this.currentposition] == 'u')) {
getnextunicodechar();
isunicode = true;
} else {
if (this.withoutunicodeptr != 0) {
unicodestore();
}
}

while (this.currentcharacter != '"') {
/**** \r and \n are not valid in string literals ****/
if ((this.currentcharacter == '\n') || (this.currentcharacter == '\r')) {
if (isunicode) {
int start = this.currentposition - 5;
while(this.source[start] != '\\') {
start--;
}
if(this.startposition <= this.cursorlocation
&& this.cursorlocation <= this.currentposition-1) {
this.currentposition = start;
// complete inside a string literal
return tokennamestringliteral;
}
start = this.currentposition;
for (int lookahead = 0; lookahead < 50; lookahead++) {
if (this.currentposition >= this.eofposition) {
this.currentposition = start;
break;
}
if (((this.currentcharacter = this.source[this.currentposition++]) == '\\') && (this.source[this.currentposition] == 'u')) {
isunicode = true;
getnextunicodechar();
} else {
isunicode = false;
}
if (!isunicode && this.currentcharacter == '\n') {
this.currentposition--; // set current position on new line character
break;
}
if (this.currentcharacter == '\"') {
throw new invalidinputexception(invalid_char_in_string);
}
}
} else {
this.currentposition--; // set current position on new line character
if(this.startposition <= this.cursorlocation
&& this.cursorlocation <= this.currentposition-1) {
// complete inside a string literal
return tokennamestringliteral;
}
}
throw new invalidinputexception(invalid_char_in_string);
}
if (this.currentcharacter == '\\') {
if (this.unicodeasbackslash) {
this.withoutunicodeptr--;
// consume next character
this.unicodeasbackslash = false;
if (((this.currentcharacter = this.source[this.currentposition++]) == '\\') && (this.source[this.currentposition] == 'u')) {
getnextunicodechar();
isunicode = true;
this.withoutunicodeptr--;
} else {
isunicode = false;
}
} else {
if (this.withoutunicodeptr == 0) {
unicodeinitializebuffer(this.currentposition - this.startposition);
}
this.withoutunicodeptr --;
this.currentcharacter = this.source[this.currentposition++];
}
// we need to compute the escape character in a separate buffer
scanescapecharacter();
if (this.withoutunicodeptr != 0) {
unicodestore();
}
}
// consume next character
this.unicodeasbackslash = false;
if (((this.currentcharacter = this.source[this.currentposition++]) == '\\')
&& (this.source[this.currentposition] == 'u')) {
getnextunicodechar();
isunicode = true;
} else {
isunicode = false;
if (this.withoutunicodeptr != 0) {
unicodestore();
}
}

}
} catch (indexoutofboundsexception e) {
this.currentposition--;
if(this.startposition <= this.cursorlocation
&& this.cursorlocation < this.currentposition) {
// complete inside a string literal
return tokennamestringliteral;
}
throw new invalidinputexception(unterminated_string);
} catch (invalidinputexception e) {
if (e.getmessage().equals(invalid_escape)) {
// relocate if finding another quote fairly close: thus unicode '/u000d' will be fully consumed
for (int lookahead = 0; lookahead < 50; lookahead++) {
if (this.currentposition + lookahead == this.eofposition)
break;
if (this.source[this.currentposition + lookahead] == '\n')
break;
if (this.source[this.currentposition + lookahead] == '\"') {
this.currentposition += lookahead + 1;
break;
}
}

}
throw e; // rethrow
}
return tokennamestringliteral;
case '/' :
{
int test;
if ((test = getnextchar('/', '*')) == 0) { //line comment
this.lastcommentlineposition = this.currentposition;
try { //get the next char
if (((this.currentcharacter = this.source[this.currentposition++]) == '\\')
&& (this.source[this.currentposition] == 'u')) {
//-------------unicode traitement ------------
int c1 = 0, c2 = 0, c3 = 0, c4 = 0;
this.currentposition++;
while (this.source[this.currentposition] == 'u') {
this.currentposition++;
}
if ((c1 = scannerhelper.getnumericvalue(this.source[this.currentposition++])) > 15
|| c1 < 0
|| (c2 = scannerhelper.getnumericvalue(this.source[this.currentposition++])) > 15
|| c2 < 0
|| (c3 = scannerhelper.getnumericvalue(this.source[this.currentposition++])) > 15
|| c3 < 0
|| (c4 = scannerhelper.getnumericvalue(this.source[this.currentposition++])) > 15
|| c4 < 0) {
throw new invalidinputexception(invalid_unicode_escape);
} else {
this.currentcharacter = (char) (((c1 * 16 + c2) * 16 + c3) * 16 + c4);
}
}

//handle the \\u case manually into comment
if (this.currentcharacter == '\\') {
if (this.source[this.currentposition] == '\\')
this.currentposition++;
} //jump over the \\
boolean isunicode = false;
while (this.currentcharacter != '\r' && this.currentcharacter != '\n') {
this.lastcommentlineposition = this.currentposition;
//get the next char
isunicode = false;
if (((this.currentcharacter = this.source[this.currentposition++]) == '\\')
&& (this.source[this.currentposition] == 'u')) {
isunicode = true;
//-------------unicode traitement ------------
int c1 = 0, c2 = 0, c3 = 0, c4 = 0;
this.currentposition++;
while (this.source[this.currentposition] == 'u') {
this.currentposition++;
}
if ((c1 = scannerhelper.getnumericvalue(this.source[this.currentposition++])) > 15
|| c1 < 0
|| (c2 = scannerhelper.getnumericvalue(this.source[this.currentposition++])) > 15
|| c2 < 0
|| (c3 = scannerhelper.getnumericvalue(this.source[this.currentposition++])) > 15
|| c3 < 0
|| (c4 = scannerhelper.getnumericvalue(this.source[this.currentposition++])) > 15
|| c4 < 0) {
throw new invalidinputexception(invalid_unicode_escape);
} else {
this.currentcharacter = (char) (((c1 * 16 + c2) * 16 + c3) * 16 + c4);
}
}
//handle the \\u case manually into comment
if (this.currentcharacter == '\\') {
if (this.source[this.currentposition] == '\\')
this.currentposition++;
} //jump over the \\
}
/*
* we need to completely consume the line break
*/
if (this.currentcharacter == '\r'
&& this.eofposition > this.currentposition) {
if (this.source[this.currentposition] == '\n') {
this.currentposition++;
this.currentcharacter = '\n';
} else if ((this.source[this.currentposition] == '\\')
&& (this.source[this.currentposition + 1] == 'u')) {
isunicode = true;
char unicodechar;
int index = this.currentposition + 1;
index++;
while (this.source[index] == 'u') {
index++;
}
//-------------unicode traitement ------------
int c1 = 0, c2 = 0, c3 = 0, c4 = 0;
if ((c1 = scannerhelper.getnumericvalue(this.source[index++])) > 15
|| c1 < 0
|| (c2 = scannerhelper.getnumericvalue(this.source[index++])) > 15
|| c2 < 0
|| (c3 = scannerhelper.getnumericvalue(this.source[index++])) > 15
|| c3 < 0
|| (c4 = scannerhelper.getnumericvalue(this.source[index++])) > 15
|| c4 < 0) {
this.currentposition = index;
throw new invalidinputexception(invalid_unicode_escape);
} else {
unicodechar = (char) (((c1 * 16 + c2) * 16 + c3) * 16 + c4);
}
if (unicodechar == '\n') {
this.currentposition = index;
this.currentcharacter = '\n';
}
}
}
recordcomment(tokennamecomment_line);
if (this.startposition <= this.cursorlocation && this.cursorlocation < this.currentposition-1){
throw new invalidcursorlocation(invalidcursorlocation.no_completion_inside_comment);
}
if (this.tasktags != null) checktasktag(this.startposition, this.currentposition);
if ((this.currentcharacter == '\r') || (this.currentcharacter == '\n')) {
//checknonexternalizedstring();
if (this.recordlineseparator) {
if (isunicode) {
pushunicodelineseparator();
} else {
pushlineseparator();
}
}
}
if (this.tokenizecomments) {
return tokennamecomment_line;
}
} catch (indexoutofboundsexception e) {
this.currentposition--;
recordcomment(tokennamecomment_line);
if (this.tasktags != null) checktasktag(this.startposition, this.currentposition);
if (this.tokenizecomments) {
return tokennamecomment_line;
} else {
this.currentposition++;
}
}
break;
}
if (test > 0) { //traditional and javadoc comment
try { //get the next char
boolean isjavadoc = false, star = false;
boolean isunicode = false;
int previous;
// consume next character
this.unicodeasbackslash = false;
if (((this.currentcharacter = this.source[this.currentposition++]) == '\\')
&& (this.source[this.currentposition] == 'u')) {
getnextunicodechar();
isunicode = true;
} else {
isunicode = false;
if (this.withoutunicodeptr != 0) {
unicodestore();
}
}

if (this.currentcharacter == '*') {
isjavadoc = true;
star = true;
}
if ((this.currentcharacter == '\r') || (this.currentcharacter == '\n')) {
//checknonexternalizedstring();
if (this.recordlineseparator) {
if (!isunicode) {
pushlineseparator();
}
}
}
isunicode = false;
previous = this.currentposition;
if (((this.currentcharacter = this.source[this.currentposition++]) == '\\')
&& (this.source[this.currentposition] == 'u')) {
//-------------unicode traitement ------------
getnextunicodechar();
isunicode = true;
} else {
isunicode = false;
}
//handle the \\u case manually into comment
if (this.currentcharacter == '\\') {
if (this.source[this.currentposition] == '\\')
this.currentposition++;
} //jump over the \\
// empty comment is not a javadoc /**/
if (this.currentcharacter == '/') {
isjavadoc = false;
}
//loop until end of comment */
int firsttag = 0;
while ((this.currentcharacter != '/') || (!star)) {
if ((this.currentcharacter == '\r') || (this.currentcharacter == '\n')) {
//checknonexternalizedstring();
if (this.recordlineseparator) {
if (!isunicode) {
pushlineseparator();
}
}
}
switch (this.currentcharacter) {
case '*':
star = true;
break;
case '@@':
if (firsttag == 0 && this.isfirsttag()) {
firsttag = previous;
}
//$fall-through$ default case to set star to false
default:
star = false;
}
//get next char
previous = this.currentposition;
if (((this.currentcharacter = this.source[this.currentposition++]) == '\\')
&& (this.source[this.currentposition] == 'u')) {
//-------------unicode traitement ------------
getnextunicodechar();
isunicode = true;
} else {
isunicode = false;
}
//handle the \\u case manually into comment
if (this.currentcharacter == '\\') {
if (this.source[this.currentposition] == '\\')
this.currentposition++;
} //jump over the \\
}
int token = isjavadoc ? tokennamecomment_javadoc : tokennamecomment_block;
recordcomment(token);
this.commenttagstarts[this.commentptr] = firsttag;
if (!isjavadoc && this.startposition <= this.cursorlocation && this.cursorlocation < this.currentposition-1){
throw new invalidcursorlocation(invalidcursorlocation.no_completion_inside_comment);
}
if (this.tasktags != null) checktasktag(this.startposition, this.currentposition);
if (this.tokenizecomments) {
/*
if (isjavadoc)
return tokennamecomment_javadoc;
return tokennamecomment_block;
*/
return token;
}
} catch (indexoutofboundsexception e) {
this.currentposition--;
throw new invalidinputexception(unterminated_comment);
}
break;
}
if (getnextchar('='))
return tokennamedivide_equal;
return tokennamedivide;
}
case '\u001a' :
if (atend())
return tokennameeof;
//the atend may not be <this.currentposition == this.source.length> if source is only some part of a real (external) stream
throw new invalidinputexception("ctrl-z"); //$non-nls-1$

default :
char c = this.currentcharacter;
if (c < scannerhelper.max_obvious) {
if ((scannerhelper.obvious_ident_char_natures[c] & scannerhelper.c_ident_start) != 0) {
return scanidentifierorkeyword();
} else if ((scannerhelper.obvious_ident_char_natures[c] & scannerhelper.c_digit) != 0) {
return scannumber(false);
} else {
return tokennameerror;
}
}
boolean isjavaidstart;
if (c >= high_surrogate_min_value && c <= high_surrogate_max_value) {
if (this.compliancelevel < classfileconstants.jdk1_5) {
throw new invalidinputexception(invalid_unicode_escape);
}
// unicode 4 detection
char low = (char) getnextchar();
if (low < low_surrogate_min_value || low > low_surrogate_max_value) {
// illegal low surrogate
throw new invalidinputexception(invalid_low_surrogate);
}
isjavaidstart = scannerhelper.isjavaidentifierstart(c, low);
}
else if (c >= low_surrogate_min_value && c <= low_surrogate_max_value) {
if (this.compliancelevel < classfileconstants.jdk1_5) {
throw new invalidinputexception(invalid_unicode_escape);
}
throw new invalidinputexception(invalid_high_surrogate);
} else {
// optimized case already checked
isjavaidstart = character.isjavaidentifierstart(c);
}
if (isjavaidstart)
return scanidentifierorkeyword();
if (scannerhelper.isdigit(this.currentcharacter)) {
return scannumber(false);
}
return tokennameerror;
}
}
} //-----------------end switch while try--------------------
catch (indexoutofboundsexception e) {
if (this.tokenizewhitespace && (whitestart != this.currentposition - 1)) {
// reposition scanner in case we are interested by spaces as tokens
this.currentposition--;
this.startposition = whitestart;
return tokennamewhitespace;
}
}
/* might be completing at very end of file (e.g. behind a dot) */
if (this.completionidentifier == null &&
this.startposition == this.cursorlocation + 1){
this.currentposition = this.startposition; // for being detected as empty free identifier
return tokennameidentifier;
}
return tokennameeof;
}
public final void getnextunicodechar() throws invalidinputexception {
int temp = this.currentposition; // the \ is already read
super.getnextunicodechar();
if(this.cursorlocation > temp) {
this.unicodecharsize += (this.currentposition - temp);
}
if (temp < this.cursorlocation && this.cursorlocation < this.currentposition-1){
throw new invalidcursorlocation(invalidcursorlocation.no_completion_inside_unicode);
}
}
protected boolean isfirsttag() {
return
getnextchar('d') &&
getnextchar('e') &&
getnextchar('p') &&
getnextchar('r') &&
getnextchar('e') &&
getnextchar('c') &&
getnextchar('a') &&
getnextchar('t') &&
getnextchar('e') &&
getnextchar('d');
}
public final void jumpoverblock() {
jumpovermethodbody();
}
///*
// * in case we actually read a keyword, but the cursor is located inside,
// * we pretend we read an identifier.
// */
public int scanidentifierorkeyword() {

int id = super.scanidentifierorkeyword();

if (this.startposition <= this.cursorlocation+1
&& this.cursorlocation < this.currentposition){

// extends the end of the completion token even if the end is after eofposition
if (this.cursorlocation+1 == this.eofposition) {
int temp = this.eofposition;
this.eofposition = this.source.length;
while(getnextcharasjavaidentifierpart()){/*empty*/}
this.eofposition = temp;
}
// convert completed keyword into an identifier
return tokennameidentifier;
}
return id;
}

public int scannumber(boolean dotprefix) throws invalidinputexception {

int token = super.scannumber(dotprefix);

// consider completion just before a number to be ok, will insert before it
if (this.startposition <= this.cursorlocation && this.cursorlocation < this.currentposition){
throw new invalidcursorlocation(invalidcursorlocation.no_completion_inside_number);
}
return token;
}
}
