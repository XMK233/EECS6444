/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.codegen.exceptionlabel;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;

/**
* extra behavior for statements which are generating subroutines
*/
public abstract class subroutinestatement extends statement {

public static void reenterallexceptionhandlers(subroutinestatement[] subroutines, int max, codestream codestream) {
if (subroutines == null) return;
if (max < 0) max = subroutines.length;
for (int i = 0; i < max; i++) {
subroutinestatement sub = subroutines[i];
sub.enteranyexceptionhandler(codestream);
sub.enterdeclaredexceptionhandlers(codestream);
}
}

exceptionlabel anyexceptionlabel;

public exceptionlabel enteranyexceptionhandler(codestream codestream) {

if (this.anyexceptionlabel == null) {
this.anyexceptionlabel = new exceptionlabel(codestream, null /*any exception*/);
}
this.anyexceptionlabel.placestart();
return this.anyexceptionlabel;
}

public void enterdeclaredexceptionhandlers(codestream codestream) {
// do nothing by default
}

public void exitanyexceptionhandler() {
if (this.anyexceptionlabel != null) {
this.anyexceptionlabel.placeend();
}
}

public void exitdeclaredexceptionhandlers(codestream codestream) {
// do nothing by default
}


/**
* generate an invocation of a subroutine (e.g. jsr finally) in current context.
* @@param currentscope
* @@param codestream
* @@param targetlocation
* @@param stateindex
* @@param secretlocal
* @@return boolean, <code>true</code> if the generated code will abrupt completion
*/
public abstract boolean generatesubroutineinvocation(blockscope currentscope, codestream codestream, object targetlocation, int stateindex, localvariablebinding secretlocal);

public abstract boolean issubroutineescaping();

public void placeallanyexceptionhandler() {
this.anyexceptionlabel.place();
}
}
