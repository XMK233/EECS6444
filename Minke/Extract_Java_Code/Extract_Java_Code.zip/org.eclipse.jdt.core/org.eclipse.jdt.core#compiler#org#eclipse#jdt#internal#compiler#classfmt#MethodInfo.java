/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.codegen.attributenamesconstants;
import org.eclipse.jdt.internal.compiler.codegen.constantpool;
import org.eclipse.jdt.internal.compiler.env.ibinaryannotation;
import org.eclipse.jdt.internal.compiler.env.ibinarymethod;
import org.eclipse.jdt.internal.compiler.util.util;

public class methodinfo extends classfilestruct implements ibinarymethod, comparable {
static private final char[][] noexception = charoperation.no_char_char;
static private final char[][] noargumentnames = charoperation.no_char_char;
protected int accessflags;
protected int attributebytes;
protected char[] descriptor;
protected char[][] exceptionnames;
protected char[] name;
protected char[] signature;
protected int signatureutf8offset;
protected long tagbits;
protected char[][] argumentnames;
protected int argumentnamesindex;

public static methodinfo createmethod(byte classfilebytes[], int offsets[], int offset) {
methodinfo methodinfo = new methodinfo(classfilebytes, offsets, offset);
int attributescount = methodinfo.u2at(6);
int readoffset = 8;
annotationinfo[] annotations = null;
annotationinfo[][] parameterannotations = null;
for (int i = 0; i < attributescount; i++) {
// check the name of each attribute
int utf8offset = methodinfo.constantpooloffsets[methodinfo.u2at(readoffset)] - methodinfo.structoffset;
char[] attributename = methodinfo.utf8at(utf8offset + 3, methodinfo.u2at(utf8offset + 1));
if (attributename.length > 0) {
switch(attributename[0]) {
case 's' :
if (charoperation.equals(attributenamesconstants.signaturename, attributename))
methodinfo.signatureutf8offset = methodinfo.constantpooloffsets[methodinfo.u2at(readoffset + 6)] - methodinfo.structoffset;
break;
case 'r' :
annotationinfo[] methodannotations = null;
annotationinfo[][] paramannotations = null;
if (charoperation.equals(attributename, attributenamesconstants.runtimevisibleannotationsname)) {
methodannotations = decodemethodannotations(readoffset, true, methodinfo);
} else if (charoperation.equals(attributename, attributenamesconstants.runtimeinvisibleannotationsname)) {
methodannotations = decodemethodannotations(readoffset, false, methodinfo);
} else if (charoperation.equals(attributename, attributenamesconstants.runtimevisibleparameterannotationsname)) {
paramannotations = decodeparamannotations(readoffset, true, methodinfo);
} else if (charoperation.equals(attributename, attributenamesconstants.runtimeinvisibleparameterannotationsname)) {
paramannotations = decodeparamannotations(readoffset, false, methodinfo);
}
if (methodannotations != null) {
if (annotations == null) {
annotations = methodannotations;
} else {
int length = annotations.length;
annotationinfo[] newannotations = new annotationinfo[length + methodannotations.length];
system.arraycopy(annotations, 0, newannotations, 0, length);
system.arraycopy(methodannotations, 0, newannotations, length, methodannotations.length);
annotations = newannotations;
}
} else if (paramannotations != null) {
int numberofparameters = paramannotations.length;
if (parameterannotations == null) {
parameterannotations = paramannotations;
} else {
for (int p = 0; p < numberofparameters; p++) {
int numberofannotations = paramannotations[p] == null ? 0 : paramannotations[p].length;
if (numberofannotations > 0) {
if (parameterannotations[p] == null) {
parameterannotations[p] = paramannotations[p];
} else {
int length = parameterannotations[p].length;
annotationinfo[] newannotations = new annotationinfo[length + numberofannotations];
system.arraycopy(parameterannotations[p], 0, newannotations, 0, length);
system.arraycopy(paramannotations[p], 0, newannotations, length, numberofannotations);
parameterannotations[p] = newannotations;
}
}
}
}
}
break;
}
}
readoffset += (6 + methodinfo.u4at(readoffset + 2));
}
methodinfo.attributebytes = readoffset;

if (parameterannotations != null)
return new methodinfowithparameterannotations(methodinfo, annotations, parameterannotations);
if (annotations != null)
return new methodinfowithannotations(methodinfo, annotations);
return methodinfo;
}
static annotationinfo[] decodeannotations(int offset, boolean runtimevisible, int numberofannotations, methodinfo methodinfo) {
annotationinfo[] result = new annotationinfo[numberofannotations];
int readoffset = offset;
for (int i = 0; i < numberofannotations; i++) {
result[i] = new annotationinfo(methodinfo.reference, methodinfo.constantpooloffsets,
readoffset + methodinfo.structoffset, runtimevisible, false);
readoffset += result[i].readoffset;
}
return result;
}
static annotationinfo[] decodemethodannotations(int offset, boolean runtimevisible, methodinfo methodinfo) {
int numberofannotations = methodinfo.u2at(offset + 6);
if (numberofannotations > 0) {
annotationinfo[] annos = decodeannotations(offset + 8, runtimevisible, numberofannotations, methodinfo);
if (runtimevisible){
int numstandardannotations = 0;
for( int i=0; i<numberofannotations; i++ ){
long standardannotagbits = annos[i].standardannotationtagbits;
methodinfo.tagbits |= standardannotagbits;
if(standardannotagbits != 0){
annos[i] = null;
numstandardannotations ++;
}
}

if( numstandardannotations != 0 ){
if( numstandardannotations == numberofannotations )
return null;

// need to resize
annotationinfo[] temp = new annotationinfo[numberofannotations - numstandardannotations ];
int tmpindex = 0;
for (int i = 0; i < numberofannotations; i++)
if (annos[i] != null)
temp[tmpindex ++] = annos[i];
annos = temp;
}
}
return annos;
}
return null;
}
static annotationinfo[][] decodeparamannotations(int offset, boolean runtimevisible, methodinfo methodinfo) {
annotationinfo[][] allparamannotations = null;
int numberofparameters = methodinfo.u1at(offset + 6);
if (numberofparameters > 0) {
// u2 attribute_name_index + u4 attribute_length + u1 num_parameters
int readoffset = offset + 7;
for (int i=0 ; i < numberofparameters; i++) {
int numberofannotations = methodinfo.u2at(readoffset);
readoffset += 2;
if (numberofannotations > 0) {
if (allparamannotations == null)
allparamannotations = new annotationinfo[numberofparameters][];
annotationinfo[] annos = decodeannotations(readoffset, runtimevisible, numberofannotations, methodinfo);
allparamannotations[i] = annos;
for (int aindex = 0; aindex < annos.length; aindex++)
readoffset += annos[aindex].readoffset;
}
}
}
return allparamannotations;
}

/**
* @@param classfilebytes byte[]
* @@param offsets int[]
* @@param offset int
*/
protected methodinfo (byte classfilebytes[], int offsets[], int offset) {
super(classfilebytes, offsets, offset);
this.accessflags = -1;
this.signatureutf8offset = -1;
}
public int compareto(object o) {
methodinfo othermethod = (methodinfo) o;
int result = new string(getselector()).compareto(new string(othermethod.getselector()));
if (result != 0) return result;
return new string(getmethoddescriptor()).compareto(new string(othermethod.getmethoddescriptor()));
}
public boolean equals(object o) {
if (!(o instanceof methodinfo)) {
return false;
}
methodinfo othermethod = (methodinfo) o;
return charoperation.equals(getselector(), othermethod.getselector())
&& charoperation.equals(getmethoddescriptor(), othermethod.getmethoddescriptor());
}
public int hashcode() {
return charoperation.hashcode(getselector()) + charoperation.hashcode(getmethoddescriptor());
}
/**
* @@return the annotations or null if there is none.
*/
public ibinaryannotation[] getannotations() {
return null;
}
/**
* @@see org.eclipse.jdt.internal.compiler.env.igenericmethod#getargumentnames()
*/
public char[][] getargumentnames() {
if (this.argumentnames == null) {
readcodeattribute();
}
return this.argumentnames;
}
public object getdefaultvalue() {
return null;
}
/**
* answer the resolved names of the exception types in the
* class file format as specified in section 4.2 of the java 2 vm spec
* or null if the array is empty.
*
* for example, java.lang.string is java/lang/string.
* @@return char[][]
*/
public char[][] getexceptiontypenames() {
if (this.exceptionnames == null) {
readexceptionattributes();
}
return this.exceptionnames;
}
public char[] getgenericsignature() {
if (this.signatureutf8offset != -1) {
if (this.signature == null) {
// decode the signature
this.signature = utf8at(this.signatureutf8offset + 3, u2at(this.signatureutf8offset + 1));
}
return this.signature;
}
return null;
}
/**
* answer the receiver's method descriptor which describes the parameter &
* return types as specified in section 4.3.3 of the java 2 vm spec.
*
* for example:
*   - int foo(string) is (ljava/lang/string;)i
*   - void foo(object[]) is (i)[ljava/lang/object;
* @@return char[]
*/
public char[] getmethoddescriptor() {
if (this.descriptor == null) {
// read the name
int utf8offset = this.constantpooloffsets[u2at(4)] - this.structoffset;
this.descriptor = utf8at(utf8offset + 3, u2at(utf8offset + 1));
}
return this.descriptor;
}
/**
* answer an int whose bits are set according the access constants
* defined by the vm spec.
* set the accdeprecated and accsynthetic bits if necessary
* @@return int
*/
public int getmodifiers() {
if (this.accessflags == -1) {
// compute the accessflag. don't forget the deprecated attribute
this.accessflags = u2at(0);
readmodifierrelatedattributes();
}
return this.accessflags;
}
public ibinaryannotation[] getparameterannotations(int index) {
return null;
}
/**
* answer the name of the method.
*
* for a constructor, answer <init> & <clinit> for a clinit method.
* @@return char[]
*/
public char[] getselector() {
if (this.name == null) {
// read the name
int utf8offset = this.constantpooloffsets[u2at(2)] - this.structoffset;
this.name = utf8at(utf8offset + 3, u2at(utf8offset + 1));
}
return this.name;
}
public long gettagbits() {
return this.tagbits;
}
/**
* this method is used to fully initialize the contents of the receiver. all methodinfos, fields infos
* will be therefore fully initialized and we can get rid of the bytes.
*/
protected void initialize() {
getmodifiers();
getselector();
getmethoddescriptor();
getexceptiontypenames();
getgenericsignature();
getargumentnames();
reset();
}
/**
* answer true if the method is a class initializer, false otherwise.
* @@return boolean
*/
public boolean isclinit() {
char[] selector = getselector();
return selector[0] == '<' && selector.length == 8; // can only match <clinit>
}
/**
* answer true if the method is a constructor, false otherwise.
* @@return boolean
*/
public boolean isconstructor() {
char[] selector = getselector();
return selector[0] == '<' && selector.length == 6; // can only match <init>
}
/**
* return true if the field is a synthetic method, false otherwise.
* @@return boolean
*/
public boolean issynthetic() {
return (getmodifiers() & classfileconstants.accsynthetic) != 0;
}
private void readexceptionattributes() {
int attributescount = u2at(6);
int readoffset = 8;
for (int i = 0; i < attributescount; i++) {
int utf8offset = this.constantpooloffsets[u2at(readoffset)] - this.structoffset;
char[] attributename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
if (charoperation.equals(attributename, attributenamesconstants.exceptionsname)) {
// read the number of exception entries
int entriesnumber = u2at(readoffset + 6);
// place the readoffset at the beginning of the exceptions table
readoffset += 8;
if (entriesnumber == 0) {
this.exceptionnames = noexception;
} else {
this.exceptionnames = new char[entriesnumber][];
for (int j = 0; j < entriesnumber; j++) {
utf8offset =
this.constantpooloffsets[u2at(
this.constantpooloffsets[u2at(readoffset)] - this.structoffset + 1)]
- this.structoffset;
this.exceptionnames[j] = utf8at(utf8offset + 3, u2at(utf8offset + 1));
readoffset += 2;
}
}
} else {
readoffset += (6 + u4at(readoffset + 2));
}
}
if (this.exceptionnames == null) {
this.exceptionnames = noexception;
}
}
private void readmodifierrelatedattributes() {
int attributescount = u2at(6);
int readoffset = 8;
for (int i = 0; i < attributescount; i++) {
int utf8offset = this.constantpooloffsets[u2at(readoffset)] - this.structoffset;
char[] attributename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
// test added for obfuscated .class file. see 79772
if (attributename.length != 0) {
switch(attributename[0]) {
case 'd' :
if (charoperation.equals(attributename, attributenamesconstants.deprecatedname))
this.accessflags |= classfileconstants.accdeprecated;
break;
case 's' :
if (charoperation.equals(attributename, attributenamesconstants.syntheticname))
this.accessflags |= classfileconstants.accsynthetic;
break;
case 'a' :
if (charoperation.equals(attributename, attributenamesconstants.annotationdefaultname))
this.accessflags |= classfileconstants.accannotationdefault;
break;
case 'v' :
if (charoperation.equals(attributename, attributenamesconstants.varargsname))
this.accessflags |= classfileconstants.accvarargs;
}
}
readoffset += (6 + u4at(readoffset + 2));
}
}
/**
* answer the size of the receiver in bytes.
*
* @@return int
*/
public int sizeinbytes() {
return this.attributebytes;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
tostring(buffer);
return buffer.tostring();
}
void tostring(stringbuffer buffer) {
buffer.append(getclass().getname());
tostringcontent(buffer);
}
protected void tostringcontent(stringbuffer buffer) {
int modifiers = getmodifiers();
char[] desc = getgenericsignature();
if (desc == null)
desc = getmethoddescriptor();
buffer
.append('{')
.append(
((modifiers & classfileconstants.accdeprecated) != 0 ? "deprecated " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0001) == 1 ? "public " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0002) == 0x0002 ? "private " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0004) == 0x0004 ? "protected " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0008) == 0x000008 ? "static " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0010) == 0x0010 ? "final " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0040) == 0x0040 ? "bridge " : util.empty_string) //$non-nls-1$
+ ((modifiers & 0x0080) == 0x0080 ? "varargs " : util.empty_string)) //$non-nls-1$
.append(getselector())
.append(desc)
.append('}');
}
private void readcodeattribute() {
int attributescount = u2at(6);
int readoffset = 8;
if (attributescount != 0) {
for (int i = 0; i < attributescount; i++) {
int utf8offset = this.constantpooloffsets[u2at(readoffset)] - this.structoffset;
char[] attributename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
if (charoperation.equals(attributename, attributenamesconstants.codename)) {
decodecodeattribute(readoffset);
if (this.argumentnames == null) {
this.argumentnames = noargumentnames;
}
return;
} else {
readoffset += (6 + u4at(readoffset + 2));
}
}
}
this.argumentnames = noargumentnames;
}
private void decodecodeattribute(int offset) {
int readoffset = offset + 10;
int codelength = (int) u4at(readoffset);
readoffset += (4 + codelength);
int exceptiontablelength = u2at(readoffset);
readoffset += 2;
if (exceptiontablelength != 0) {
for (int i = 0; i < exceptiontablelength; i++) {
readoffset += 8;
}
}
int attributescount = u2at(readoffset);
readoffset += 2;
for (int i = 0; i < attributescount; i++) {
int utf8offset = this.constantpooloffsets[u2at(readoffset)] - this.structoffset;
char[] attributename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
if (charoperation.equals(attributename, attributenamesconstants.localvariabletablename)) {
decodelocalvariableattribute(readoffset, codelength);
}
readoffset += (6 + u4at(readoffset + 2));
}
}
private void decodelocalvariableattribute(int offset, int codelength) {
int readoffset = offset + 6;
final int length = u2at(readoffset);
if (length != 0) {
readoffset += 2;
this.argumentnames = new char[length][];
this.argumentnamesindex = 0;
for (int i = 0; i < length; i++) {
int startpc = u2at(readoffset);
if (startpc == 0) {
int nameindex = u2at(4 + readoffset);
int utf8offset = this.constantpooloffsets[nameindex] - this.structoffset;
char[] localvariablename = utf8at(utf8offset + 3, u2at(utf8offset + 1));
if (!charoperation.equals(localvariablename, constantpool.this)) {
this.argumentnames[this.argumentnamesindex++] = localvariablename;
}
} else {
break;
}
readoffset += 10;
}
if (this.argumentnamesindex != this.argumentnames.length) {
// resize
system.arraycopy(this.argumentnames, 0, (this.argumentnames = new char[this.argumentnamesindex][]), 0, this.argumentnamesindex);
}
}
}
}
