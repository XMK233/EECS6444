/*******************************************************************************
* copyright (c) 2000, 2006 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

public interface isourcefield extends igenericfield {
/**
* answer the source end position of the field's declaration.
*/
int getdeclarationsourceend();

/**
* answer the source start position of the field's declaration.
*/
int getdeclarationsourcestart();

/**
* answer the initialization source for this constant field.
* answer null if the field is not a constant or if it has no initialization.
*/
char[] getinitializationsource();

/**
* answer the source end position of the field's name.
*/
int getnamesourceend();

/**
* answer the source start position of the field's name.
*/
int getnamesourcestart();

/**
* answer the type name of the field.
*
* the name is a simple name or a qualified, dot separated name.
* for example, hashtable or java.util.hashtable.
*/
char[] gettypename();
}
