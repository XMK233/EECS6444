/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

public class floatcache {
private float keytable[];
private int valuetable[];
private int elementsize;
/**
* constructs a new, empty hashtable. a default capacity and
* load factor is used. note that the hashtable will automatically
* grow when it gets full.
*/
public floatcache() {
this(13);
}
/**
* constructs a new, empty hashtable with the specified initial
* capacity.
* @@param initialcapacity int
*  the initial number of buckets
*/
public floatcache(int initialcapacity) {
this.elementsize = 0;
this.keytable = new float[initialcapacity];
this.valuetable = new int[initialcapacity];
}
/**
* clears the hash table so that it has no more elements in it.
*/
public void clear() {
for (int i = this.keytable.length; --i >= 0;) {
this.keytable[i] = 0.0f;
this.valuetable[i] = 0;
}
this.elementsize = 0;
}
/** returns true if the collection contains an element for the key.
*
* @@param key <code>float</code> the key that we are looking for
* @@return boolean
*/
public boolean containskey(float key) {
if (key == 0.0f) {
for (int i = 0, max = this.elementsize; i < max; i++) {
if (this.keytable[i] == 0.0f) {
int value1 = float.floattointbits(key);
int value2 = float.floattointbits(this.keytable[i]);
if (value1 == -2147483648 && value2 == -2147483648)
return true;
if (value1 == 0 && value2 == 0)
return true;
}
}
} else {
for (int i = 0, max = this.elementsize; i < max; i++) {
if (this.keytable[i] == key) {
return true;
}
}
}
return false;
}
/**
* puts the specified element into the hashtable, using the specified
* key.  the element may be retrieved by doing a get() with the same key.
*
* @@param key <code>float</code> the specified key in the hashtable
* @@param value <code>int</code> the specified element
* @@return int value
*/
public int put(float key, int value) {
if (this.elementsize == this.keytable.length) {
// resize
system.arraycopy(this.keytable, 0, (this.keytable = new float[this.elementsize * 2]), 0, this.elementsize);
system.arraycopy(this.valuetable, 0, (this.valuetable = new int[this.elementsize * 2]), 0, this.elementsize);
}
this.keytable[this.elementsize] = key;
this.valuetable[this.elementsize] = value;
this.elementsize++;
return value;
}
/**
* puts the specified element into the hashtable, using the specified
* key.  the element may be retrieved by doing a get() with the same key.
*
* @@param key <code>float</code> the specified key in the hashtable
* @@param value <code>int</code> the specified element
* @@return int value
*/
public int putifabsent(float key, int value) {
if (key == 0.0f) {
for (int i = 0, max = this.elementsize; i < max; i++) {
if (this.keytable[i] == 0.0f) {
int value1 = float.floattointbits(key);
int value2 = float.floattointbits(this.keytable[i]);
if (value1 == -2147483648 && value2 == -2147483648)
return this.valuetable[i];
if (value1 == 0 && value2 == 0)
return this.valuetable[i];
}
}
} else {
for (int i = 0, max = this.elementsize; i < max; i++) {
if (this.keytable[i] == key) {
return this.valuetable[i];
}
}
}
if (this.elementsize == this.keytable.length) {
// resize
system.arraycopy(this.keytable, 0, (this.keytable = new float[this.elementsize * 2]), 0, this.elementsize);
system.arraycopy(this.valuetable, 0, (this.valuetable = new int[this.elementsize * 2]), 0, this.elementsize);
}
this.keytable[this.elementsize] = key;
this.valuetable[this.elementsize] = value;
this.elementsize++;
return -value; // negative when added, assumes value is > 0
}
/**
* converts to a rather lengthy string.
*
* @@return string the ascii representation of the receiver
*/
public string tostring() {
int max = this.elementsize;
stringbuffer buf = new stringbuffer();
buf.append("{"); //$non-nls-1$
for (int i = 0; i < max; ++i) {
if ((this.keytable[i] != 0) || ((this.keytable[i] == 0) && (this.valuetable[i] != 0))) {
buf.append(this.keytable[i]).append("->").append(this.valuetable[i]); //$non-nls-1$
}
if (i < max) {
buf.append(", "); //$non-nls-1$
}
}
buf.append("}"); //$non-nls-1$
return buf.tostring();
}
}
