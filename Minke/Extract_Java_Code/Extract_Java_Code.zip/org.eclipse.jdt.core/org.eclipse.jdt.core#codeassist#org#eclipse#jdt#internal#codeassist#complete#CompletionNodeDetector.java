/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.*;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

/**
* detect the presence of a node in expression
*/
public class completionnodedetector extends astvisitor {
private astnode searchednode;
private astnode parent;
private boolean result;

public completionnodedetector(astnode searchednode, astnode visitedast){
this.searchednode = searchednode;
this.result = false;

if(searchednode != null && visitedast != null) {
visitedast.traverse(this, null);
}
}

public boolean containscompletionnode() {
return this.result;
}

public astnode getcompletionnodeparent() {
return this.parent;
}
public void endvisit(allocationexpression allocationexpression, blockscope scope) {
endvisit(allocationexpression);
}
public void endvisit(and_and_expression and_and_expression, blockscope scope) {
endvisit(and_and_expression);
}
public void endvisit(arrayallocationexpression arrayallocationexpression, blockscope scope) {
endvisit(arrayallocationexpression);
}
public void endvisit(arrayinitializer arrayinitializer, blockscope scope) {
endvisit(arrayinitializer);
}
public void endvisit(arrayqualifiedtypereference arrayqualifiedtypereference, blockscope scope) {
endvisit(arrayqualifiedtypereference);
}
public void endvisit(arrayqualifiedtypereference arrayqualifiedtypereference, classscope scope) {
endvisit(arrayqualifiedtypereference);
}
public void endvisit(arrayreference arrayreference, blockscope scope) {
endvisit(arrayreference);
}
public void endvisit(arraytypereference arraytypereference, blockscope scope) {
endvisit(arraytypereference);
}
public void endvisit(arraytypereference arraytypereference, classscope scope) {
endvisit(arraytypereference);
}
public void endvisit(assignment assignment, blockscope scope) {
endvisit(assignment);
}
public void endvisit(binaryexpression binaryexpression, blockscope scope) {
endvisit(binaryexpression);
}
public void endvisit(castexpression castexpression, blockscope scope) {
endvisit(castexpression);
}
public void endvisit(compoundassignment compoundassignment, blockscope scope) {
endvisit(compoundassignment);
}
public void endvisit(conditionalexpression conditionalexpression, blockscope scope) {
endvisit(conditionalexpression);
}
public void endvisit(equalexpression equalexpression, blockscope scope) {
endvisit(equalexpression);
}
public void endvisit(explicitconstructorcall explicitconstructor, blockscope scope) {
endvisit(explicitconstructor);
}
public void endvisit(fieldreference fieldreference, blockscope scope) {
endvisit(fieldreference);
}
public void endvisit(instanceofexpression instanceofexpression, blockscope scope) {
endvisit(instanceofexpression);
}
public void endvisit(messagesend messagesend, blockscope scope) {
endvisit(messagesend);
}
public void endvisit(or_or_expression or_or_expression, blockscope scope) {
endvisit(or_or_expression);
}
public void endvisit(parameterizedqualifiedtypereference parameterizedqualifiedtypereference, blockscope scope) {
endvisit(parameterizedqualifiedtypereference);
}
public void endvisit(parameterizedqualifiedtypereference parameterizedqualifiedtypereference, classscope scope) {
endvisit(parameterizedqualifiedtypereference);
}
public void endvisit(parameterizedsingletypereference parameterizedsingletypereference, blockscope scope) {
endvisit(parameterizedsingletypereference);
}
public void endvisit(parameterizedsingletypereference parameterizedsingletypereference, classscope scope) {
endvisit(parameterizedsingletypereference);
}
public void endvisit(postfixexpression postfixexpression, blockscope scope) {
endvisit(postfixexpression);
}
public void endvisit(prefixexpression prefixexpression, blockscope scope) {
endvisit(prefixexpression);
}
public void endvisit(qualifiedallocationexpression qualifiedallocationexpression, blockscope scope) {
endvisit(qualifiedallocationexpression);
}
public void endvisit(qualifiednamereference qualifiednamereference, blockscope scope) {
endvisit(qualifiednamereference);
}
public void endvisit(qualifiedsuperreference qualifiedsuperreference, blockscope scope) {
endvisit(qualifiedsuperreference);
}
public void endvisit(qualifiedthisreference qualifiedthisreference, blockscope scope) {
endvisit(qualifiedthisreference);
}
public void endvisit(qualifiedtypereference qualifiedtypereference, blockscope scope) {
endvisit(qualifiedtypereference);
}
public void endvisit(qualifiedtypereference qualifiedtypereference, classscope scope) {
endvisit(qualifiedtypereference);
}
public void endvisit(singlenamereference singlenamereference, blockscope scope) {
endvisit(singlenamereference);
}
public void endvisit(singletypereference singletypereference, blockscope scope) {
endvisit(singletypereference);
}
public void endvisit(singletypereference singletypereference, classscope scope) {
endvisit(singletypereference);
}
public void endvisit(superreference superreference, blockscope scope) {
endvisit(superreference);
}
public void endvisit(thisreference thisreference, blockscope scope) {
endvisit(thisreference);
}
public void endvisit(unaryexpression unaryexpression, blockscope scope) {
endvisit(unaryexpression);
}
public void endvisit(membervaluepair pair, blockscope scope) {
endvisit(pair);
}
public void endvisit(membervaluepair pair, compilationunitscope scope) {
endvisit(pair);
}
public boolean visit(allocationexpression allocationexpression, blockscope scope) {
return this.visit(allocationexpression);
}
public boolean visit(and_and_expression and_and_expression, blockscope scope) {
return this.visit(and_and_expression);
}
public boolean visit(arrayallocationexpression arrayallocationexpression, blockscope scope) {
return this.visit(arrayallocationexpression);
}
public boolean visit(arrayinitializer arrayinitializer, blockscope scope) {
return this.visit(arrayinitializer);
}
public boolean visit(arrayqualifiedtypereference arrayqualifiedtypereference, blockscope scope) {
return this.visit(arrayqualifiedtypereference);
}
public boolean visit(arrayqualifiedtypereference arrayqualifiedtypereference, classscope scope) {
return this.visit(arrayqualifiedtypereference);
}
public boolean visit(arrayreference arrayreference, blockscope scope) {
return this.visit(arrayreference);
}
public boolean visit(arraytypereference arraytypereference, blockscope scope) {
return this.visit(arraytypereference);
}
public boolean visit(arraytypereference arraytypereference, classscope scope) {
return this.visit(arraytypereference);
}
public boolean visit(assignment assignment, blockscope scope) {
return this.visit(assignment);
}
public boolean visit(binaryexpression binaryexpression, blockscope scope) {
return this.visit(binaryexpression);
}
public boolean visit(castexpression castexpression, blockscope scope) {
return this.visit(castexpression);
}
public boolean visit(compoundassignment compoundassignment, blockscope scope) {
return this.visit(compoundassignment);
}
public boolean visit(conditionalexpression conditionalexpression, blockscope scope) {
return this.visit(conditionalexpression);
}
public boolean visit(equalexpression equalexpression, blockscope scope) {
return this.visit(equalexpression);
}
public boolean visit(explicitconstructorcall explicitconstructor, blockscope scope) {
return this.visit(explicitconstructor);
}
public boolean visit(fieldreference fieldreference, blockscope scope) {
return this.visit(fieldreference);
}
public boolean visit(instanceofexpression instanceofexpression, blockscope scope) {
return this.visit(instanceofexpression);
}
public boolean visit(messagesend messagesend, blockscope scope) {
return this.visit(messagesend);
}
public boolean visit(or_or_expression or_or_expression, blockscope scope) {
return this.visit(or_or_expression);
}
public boolean visit(parameterizedqualifiedtypereference parameterizedqualifiedtypereference, blockscope scope) {
return this.visit(parameterizedqualifiedtypereference);
}
public boolean visit(parameterizedqualifiedtypereference parameterizedqualifiedtypereference, classscope scope) {
return this.visit(parameterizedqualifiedtypereference);
}
public boolean visit(parameterizedsingletypereference parameterizedsingletypereference, blockscope scope) {
return this.visit(parameterizedsingletypereference);
}
public boolean visit(parameterizedsingletypereference parameterizedsingletypereference, classscope scope) {
return this.visit(parameterizedsingletypereference);
}
public boolean visit(postfixexpression postfixexpression, blockscope scope) {
return this.visit(postfixexpression);
}
public boolean visit(prefixexpression prefixexpression, blockscope scope) {
return this.visit(prefixexpression);
}
public boolean visit(qualifiedallocationexpression qualifiedallocationexpression, blockscope scope) {
return this.visit(qualifiedallocationexpression);
}
public boolean visit(qualifiednamereference qualifiednamereference, blockscope scope) {
return this.visit(qualifiednamereference);
}
public boolean visit(qualifiedsuperreference qualifiedsuperreference, blockscope scope) {
return this.visit(qualifiedsuperreference);
}
public boolean visit(qualifiedthisreference qualifiedthisreference, blockscope scope) {
return this.visit(qualifiedthisreference);
}
public boolean visit(qualifiedtypereference qualifiedtypereference, blockscope scope) {
return this.visit(qualifiedtypereference);
}
public boolean visit(qualifiedtypereference qualifiedtypereference, classscope scope) {
return this.visit(qualifiedtypereference);
}
public boolean visit(singlenamereference singlenamereference, blockscope scope) {
return this.visit(singlenamereference);
}
public boolean visit(singletypereference singletypereference, blockscope scope) {
return this.visit(singletypereference);
}
public boolean visit(singletypereference singletypereference, classscope scope) {
return this.visit(singletypereference);
}
public boolean visit(stringliteral stringliteral, blockscope scope) {
return this.visit(stringliteral);
}
public boolean visit(superreference superreference, blockscope scope) {
return this.visit(superreference);
}
public boolean visit(thisreference thisreference, blockscope scope) {
return this.visit(thisreference);
}
public boolean visit(unaryexpression unaryexpression, blockscope scope) {
return this.visit(unaryexpression);
}
public boolean visit(membervaluepair pair, blockscope scope) {
return this.visit(pair);
}
public boolean visit(membervaluepair pair, compilationunitscope scope) {
return this.visit(pair);
}
private void endvisit(astnode astnode) {
if(this.result && this.parent == null && astnode != this.searchednode) {
if(!(astnode instanceof allocationexpression && ((allocationexpression) astnode).type == this.searchednode)
&& !(astnode instanceof conditionalexpression && ((conditionalexpression) astnode).valueiftrue == this.searchednode)
&& !(astnode instanceof conditionalexpression && ((conditionalexpression) astnode).valueiffalse == this.searchednode)) {
this.parent = astnode;
}
}
}
private boolean visit(astnode astnode) {
if(astnode == this.searchednode) {
this.result = true;
}
return !this.result;
}
}
