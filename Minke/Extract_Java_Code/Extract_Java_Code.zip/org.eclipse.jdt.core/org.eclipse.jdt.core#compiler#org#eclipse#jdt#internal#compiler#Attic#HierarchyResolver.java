package org.eclipse.jdt.internal.compiler;

/*
* (c) copyright ibm corp. 2000, 2001.
* all rights reserved.
*/
/**
* this is the public entry point to resolve type hierarchies.
*
* when requesting additional types from the name environment, the resolver
* accepts all forms (binary, source & compilation unit) for additional types.
*
* side notes: binary types already know their resolved supertypes so this
* only makes sense for source types. even though the compiler finds all binary
* types to complete the hierarchy of a given source type, is there any reason
* why the requestor should be informed that binary type x subclasses y &
* implements i & j?
*/

import org.eclipse.jdt.internal.compiler.env.*;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.*;
import org.eclipse.jdt.internal.compiler.problem.*;
import org.eclipse.jdt.internal.compiler.util.*;

import java.util.locale;
import java.util.map;

public class hierarchyresolver implements ityperequestor {
ihierarchyrequestor requestor;
lookupenvironment lookupenvironment;

private int typeindex;
private igenerictype[] typemodels;
private referencebinding[] typebindings;
private referencebinding focustype;
private compileroptions options;

/**
* a wrapper around the simple name of a type that is missing.
*/
public class missingtype implements igenerictype {
public string simplename;

public missingtype(string simplename) {
this.simplename = simplename;
}

/*
* @@see igenerictype#getmodifiers()
*/
public int getmodifiers() {
return 0;
}

/*
* @@see igenerictype#isbinarytype()
*/
public boolean isbinarytype() {
return false;
}

/*
* @@see igenerictype#isclass()
*/
public boolean isclass() {
return false;
}

/*
* @@see igenerictype#isinterface()
*/
public boolean isinterface() {
return false;
}

/*
* @@see idependent#getfilename()
*/
public char[] getfilename() {
return null;
}

public string tostring() {
return "missing type: " + this.simplename; //$non-nls-1$
}

}

public hierarchyresolver(
inameenvironment nameenvironment,
ierrorhandlingpolicy policy,
map settings,
ihierarchyrequestor requestor,
iproblemfactory problemfactory) {

// create a problem handler given a handling policy
options = settings == null ? new compileroptions() : new compileroptions(settings);
problemreporter problemreporter = new problemreporter(policy, options, problemfactory);
this.lookupenvironment = new lookupenvironment(this, options, problemreporter, nameenvironment);
this.requestor = requestor;

this.typeindex = -1;
this.typemodels = new igenerictype[5];
this.typebindings = new referencebinding[5];
}
public hierarchyresolver(inameenvironment nameenvironment, map settings, ihierarchyrequestor requestor, iproblemfactory problemfactory) {
this(
nameenvironment,
defaulterrorhandlingpolicies.exitafterallproblems(),
settings,
requestor,
problemfactory);
}
/**
* add an additional binary type
*/

public void accept(ibinarytype binarytype, packagebinding packagebinding) {
binarytypebinding typebinding = lookupenvironment.createbinarytypefrom(binarytype, packagebinding);
try {
this.remember(binarytype, typebinding);
} catch (abortcompilation e) {
}
}
/**
* add an additional compilation unit.
*/

public void accept(icompilationunit sourceunit) {
//system.out.println("cannot accept compilation units inside the hierarchyresolver.");
lookupenvironment.problemreporter.abortduetointernalerror(
new stringbuffer(util.bind("accept.cannot")) //$non-nls-1$
.append(sourceunit.getfilename())
.tostring());
}
/**
* add additional source types
*/
public void accept(isourcetype[] sourcetypes, packagebinding packagebinding) {
// find most enclosing type first (needed when explicit askfortype(...) is done
// with a member type (e.g. p.a$b))
isourcetype sourcetype = sourcetypes[0];
while (sourcetype.getenclosingtype() != null)
sourcetype = sourcetype.getenclosingtype();

// build corresponding compilation unit
compilationresult result = new compilationresult(sourcetype.getfilename(), 1, 1);
compilationunitdeclaration unit =
sourcetypeconverter.buildcompilationunit(new isourcetype[] {sourcetype}, false, true, lookupenvironment.problemreporter, result);

// build bindings
if (unit != null) {
try {
lookupenvironment.buildtypebindings(unit);
rememberwithmembertypes(sourcetype, unit.types[0].binding);
lookupenvironment.completetypebindings(unit, false);
} catch (abortcompilation e) {
// missing 'java.lang' package: ignore
}
}
}
/*
* find the super class of the given type in the cache.
* returns a missingtype if the class is not found,
* or null if type has no super class.
*/
private igenerictype findsuperclass(igenerictype type, referencebinding typebinding) {
referencebinding superbinding = typebinding.superclass();
if (superbinding != null) {
if (superbinding.id == typeids.t_javalangobject && typebinding.ishierarchyinconsistent()) {
char[] superclassname;
char separator;
if (type instanceof ibinarytype) {
superclassname = ((ibinarytype)type).getsuperclassname();
separator = '/';
} else if (type instanceof isourcetype) {
superclassname = ((isourcetype)type).getsuperclassname();
separator = '.';
} else if (type instanceof hierarchytype) {
superclassname = ((hierarchytype)type).superclassname;
separator = '.';
} else {
return null;
}
if (superclassname == null) return null;
int lastseparator = charoperation.lastindexof(separator, superclassname);
char[] simplename = lastseparator == -1 ? superclassname : charoperation.subarray(superclassname, lastseparator+1, superclassname.length);
return new missingtype(new string(simplename));
} else {
for (int t = typeindex; t >= 0; t--) {
if (typebindings[t] == superbinding) {
return typemodels[t];
}
}
}
}
return null;
}
/*
* find the super interfaces of the given type in the cache.
* returns a missingtype if the interface is not found.
*/
private igenerictype[] findsuperinterfaces(igenerictype type, referencebinding typebinding) {
char[][] superinterfacenames;
char separator;
if (type instanceof ibinarytype) {
superinterfacenames = ((ibinarytype)type).getinterfacenames();
separator = '/';
} else if (type instanceof isourcetype) {
superinterfacenames = ((isourcetype)type).getinterfacenames();
separator = '.';
} else if (type instanceof hierarchytype) {
superinterfacenames = ((hierarchytype)type).superinterfacenames;
separator = '.';
} else{
return null;
}

referencebinding[] interfacebindings = typebinding.superinterfaces();
int bindingindex = 0;
int bindinglength = interfacebindings == null ? 0 : interfacebindings.length;
int length = superinterfacenames == null ? 0 : superinterfacenames.length;
igenerictype[] superinterfaces = new igenerictype[length];
next : for (int i = 0; i < length; i++) {
char[] superinterfacename = superinterfacenames[i];
int lastseparator = charoperation.lastindexof(separator, superinterfacename);
char[] simplename = lastseparator == -1 ? superinterfacename : charoperation.subarray(superinterfacename, lastseparator+1, superinterfacename.length);
if (bindingindex < bindinglength) {
referencebinding interfacebinding = interfacebindings[bindingindex];

// ensure that the binding corresponds to the interface defined by the user
char[][] compoundname = interfacebinding.compoundname;
if (charoperation.equals(simplename, compoundname[compoundname.length-1])) {
bindingindex++;
for (int t = typeindex; t >= 0; t--) {
if (typebindings[t] == interfacebinding) {
superinterfaces[i] = typemodels[t];
continue next;
}
}
}
}
superinterfaces[i] = new missingtype(new string(simplename));
}
return superinterfaces;
}
private void remember(igenerictype suppliedtype, referencebinding typebinding) {
if (typebinding == null) return;

if (suppliedtype.isbinarytype()) {
// fault in its hierarchy...
// nb: abortcompilation is handled by caller
typebinding.superclass();
typebinding.superinterfaces();
}

if (++typeindex == typemodels.length) {
system.arraycopy(typemodels, 0, typemodels = new igenerictype[typeindex * 2], 0, typeindex);
system.arraycopy(typebindings, 0, typebindings = new referencebinding[typeindex * 2], 0, typeindex);
}
typemodels[typeindex] = suppliedtype;
typebindings[typeindex] = typebinding;
}
private void rememberwithmembertypes(typedeclaration typedeclaration, hierarchytype enclosingtype, icompilationunit unit) {

if (typedeclaration.binding == null) return;

// simple super class name
char[] superclassname = null;
typereference superclass = typedeclaration.superclass;
if (superclass != null) {
char[][] typename = superclass.gettypename();
superclassname = typename == null ? null : typename[typename.length-1];
}

// simple super interface names
char[][] superinterfacenames = null;
typereference[] superinterfaces = typedeclaration.superinterfaces;
if (superinterfaces != null) {
int length = superinterfaces.length;
superinterfacenames = new char[length][];
for (int i = 0; i < length; i++) {
typereference superinterface = superinterfaces[i];
char[][] typename = superinterface.gettypename();
superinterfacenames[i] = typename[typename.length-1];
}
}

hierarchytype hierarchytype = new hierarchytype(
enclosingtype,
!typedeclaration.isinterface(),
typedeclaration.name,
typedeclaration.binding.modifiers,
superclassname,
superinterfacenames,
unit);
remember(hierarchytype, typedeclaration.binding);

// propagate into member types
if (typedeclaration.membertypes == null) return;
membertypedeclaration[] membertypes = typedeclaration.membertypes;
for (int i = 0, max = membertypes.length; i < max; i++){
rememberwithmembertypes(membertypes[i], hierarchytype, unit);
}
}
private void rememberwithmembertypes(isourcetype suppliedtype, referencebinding typebinding) {
if (typebinding == null) return;

remember(suppliedtype, typebinding);

isourcetype[] membertypes = suppliedtype.getmembertypes();
if (membertypes == null) return;
for (int m = membertypes.length; --m >= 0;) {
isourcetype membertype = membertypes[m];
rememberwithmembertypes(membertype, typebinding.getmembertype(membertype.getname()));
}
}
private void reporthierarchy() {
for (int current = typeindex; current >= 0; current--) {
igenerictype suppliedtype = typemodels[current];
referencebinding typebinding = typebindings[current];

if (!suborsuperoffocus(typebinding)) {
continue; // ignore types outside of hierarchy
}

igenerictype superclass;
if (typebinding.isinterface()){ // do not connect interfaces to object
superclass = null;
} else {
superclass = this.findsuperclass(suppliedtype, typebinding);
}
igenerictype[] superinterfaces = this.findsuperinterfaces(suppliedtype, typebinding);

requestor.connect(suppliedtype, superclass, superinterfaces);
}
}
private void reset(){
lookupenvironment.reset();

this.typeindex = -1;
this.typemodels = new igenerictype[5];
this.typebindings = new referencebinding[5];
}
/**
* resolve the supertypes for the supplied source types.
* inform the requestor of the resolved supertypes for each
* supplied source type using:
*    connect(isourcetype suppliedtype, igenerictype superclass, igenerictype[] superinterfaces)
*
* also inform the requestor of the supertypes of each
* additional requested super type which is also a source type
* instead of a binary type.
*/

public void resolve(igenerictype[] suppliedtypes) {
resolve(suppliedtypes, null);
}
/**
* resolve the supertypes for the supplied source types.
* inform the requestor of the resolved supertypes for each
* supplied source type using:
*    connect(isourcetype suppliedtype, igenerictype superclass, igenerictype[] superinterfaces)
*
* also inform the requestor of the supertypes of each
* additional requested super type which is also a source type
* instead of a binary type.
*/

public void resolve(igenerictype[] suppliedtypes, icompilationunit[] sourceunits) {
try {
int suppliedlength = suppliedtypes == null ? 0 : suppliedtypes.length;
int sourcelength = sourceunits == null ? 0 : sourceunits.length;
compilationunitdeclaration[] units = new compilationunitdeclaration[suppliedlength + sourcelength];

// build type bindings
for (int i = 0; i < suppliedlength; i++) {
if (suppliedtypes[i].isbinarytype()) {
ibinarytype binarytype = (ibinarytype) suppliedtypes[i];
try {
remember(binarytype, lookupenvironment.cachebinarytype(binarytype, false));
} catch (abortcompilation e) {
// classpath problem for this type: ignore
}
} else {
// must start with the top level type
isourcetype topleveltype = (isourcetype) suppliedtypes[i];
while (topleveltype.getenclosingtype() != null)
topleveltype = topleveltype.getenclosingtype();
compilationresult result = new compilationresult(topleveltype.getfilename(), i, suppliedlength);
units[i] = sourcetypeconverter.buildcompilationunit(new isourcetype[]{topleveltype}, false, true, lookupenvironment.problemreporter, result);
if (units[i] != null) {
try {
lookupenvironment.buildtypebindings(units[i]);
} catch (abortcompilation e) {
// classpath problem for this type: ignore
}
}
}
}
for (int i = 0; i < sourcelength; i++){
icompilationunit sourceunit = sourceunits[i];
compilationresult unitresult = new compilationresult(sourceunit, suppliedlength+i, suppliedlength+sourcelength);
parser parser = new parser(lookupenvironment.problemreporter, true, options.assertmode);
compilationunitdeclaration parsedunit = parser.dietparse(sourceunit, unitresult);
if (parsedunit != null) {
units[suppliedlength+i] = parsedunit;
lookupenvironment.buildtypebindings(parsedunit);
}
}

// complete type bindings (ie. connect super types) and remember them
for (int i = 0; i < suppliedlength; i++) {
if (!suppliedtypes[i].isbinarytype()) { // note that binary types have already been remembered above
compilationunitdeclaration parsedunit = units[i];
if (parsedunit != null) {
// must start with the top level type
isourcetype topleveltype = (isourcetype) suppliedtypes[i];
suppliedtypes[i] = null; // no longer needed pass this point
while (topleveltype.getenclosingtype() != null)
topleveltype = topleveltype.getenclosingtype();
try {
lookupenvironment.completetypebindings(parsedunit, false);
rememberwithmembertypes(topleveltype, parsedunit.types[0].binding);
} catch (abortcompilation e) {
// classpath problem for this type: ignore
}
}
}
}
for (int i = 0; i < sourcelength; i++) {
compilationunitdeclaration parsedunit = units[suppliedlength+i];
if (parsedunit != null) {
lookupenvironment.completetypebindings(parsedunit, false);
int typecount = parsedunit.types == null ? 0 : parsedunit.types.length;
icompilationunit sourceunit = sourceunits[i];
sourceunits[i] = null; // no longer needed pass this point
for (int j = 0; j < typecount; j++){
rememberwithmembertypes(parsedunit.types[j], null, sourceunit);
}
}
}

reporthierarchy();

} catch (classcastexception e){ // work-around for 1gf5w1s - can happen in case duplicates are fed to the hierarchy with binaries hiding sources
} catch (abortcompilation e) { // ignore this exception for now since it typically means we cannot find java.lang.object
} finally {
reset();
}
}
/**
* resolve the supertypes for the supplied source type.
* inform the requestor of the resolved supertypes using:
*    connect(isourcetype suppliedtype, igenerictype superclass, igenerictype[] superinterfaces)
*/

public void resolve(igenerictype suppliedtype) {
try {
if (suppliedtype.isbinarytype()) {
remember(suppliedtype, lookupenvironment.cachebinarytype((ibinarytype) suppliedtype));
} else {
// must start with the top level type
isourcetype topleveltype = (isourcetype) suppliedtype;
while (topleveltype.getenclosingtype() != null)
topleveltype = topleveltype.getenclosingtype();
compilationresult result = new compilationresult(topleveltype.getfilename(), 1, 1);
compilationunitdeclaration unit =
sourcetypeconverter.buildcompilationunit(new isourcetype[]{topleveltype}, false, true, lookupenvironment.problemreporter, result);

if (unit != null) {
lookupenvironment.buildtypebindings(unit);
rememberwithmembertypes(topleveltype, unit.types[0].binding);

lookupenvironment.completetypebindings(unit, false);
}
}
reporthierarchy();
} catch (abortcompilation e) { // ignore this exception for now since it typically means we cannot find java.lang.object
} finally {
reset();
}
}
/**
* set the focus type (ie. the type that this resolver is computing the hierarch for.
* returns the binding of this focus type or null if it could not be found.
*/
public referencebinding setfocustype(char[][] compoundname) {
if (compoundname == null || this.lookupenvironment == null) return null;
this.focustype = this.lookupenvironment.askfortype(compoundname);
return this.focustype;
}
private boolean suborsuperoffocus(referencebinding typebinding) {
if (this.focustype == null) return true; // accept all types (case of hierarchy in a region)
if (this.subtypeoftype(this.focustype, typebinding)) return true;
if (this.subtypeoftype(typebinding, this.focustype)) return true;
return false;
}
private boolean subtypeoftype(referencebinding subtype, referencebinding typebinding) {
if (typebinding == null || subtype == null) return false;
if (subtype == typebinding) return true;
referencebinding superclass = subtype.superclass();
if (superclass != null && superclass.id == typeids.t_javalangobject && subtype.ishierarchyinconsistent()) return false;
if (this.subtypeoftype(superclass, typebinding)) return true;
referencebinding[] superinterfaces = subtype.superinterfaces();
if (superinterfaces != null) {
for (int i = 0, length = superinterfaces.length; i < length; i++) {
if (this.subtypeoftype(superinterfaces[i], typebinding)) return true;
}
}
return false;
}
}
