/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import java.util.arraylist;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.branchlabel;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.arraybinding;
import org.eclipse.jdt.internal.compiler.lookup.basetypebinding;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.lookup.typevariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.wildcardbinding;
import org.eclipse.jdt.internal.compiler.problem.shouldnotimplement;
import org.eclipse.jdt.internal.compiler.util.messages;

public abstract class expression extends statement {

public constant constant;

public int statementend = -1;

//some expression may not be used - from a java semantic point
//of view only - as statements. other may. in order to avoid the creation
//of wrappers around expression in order to tune them as expression
//expression is a subclass of statement. see the message isvalidjavastatement()

public int implicitconversion;
public typebinding resolvedtype;

public static final boolean isconstantvaluerepresentable(constant constant, int constanttypeid, int targettypeid) {
//true if there is no loss of precision while casting.
// constanttypeid == constant.typeid
if (targettypeid == constanttypeid)
return true;
switch (targettypeid) {
case t_char :
switch (constanttypeid) {
case t_char :
return true;
case t_double :
return constant.doublevalue() == constant.charvalue();
case t_float :
return constant.floatvalue() == constant.charvalue();
case t_int :
return constant.intvalue() == constant.charvalue();
case t_short :
return constant.shortvalue() == constant.charvalue();
case t_byte :
return constant.bytevalue() == constant.charvalue();
case t_long :
return constant.longvalue() == constant.charvalue();
default :
return false;//boolean
}

case t_float :
switch (constanttypeid) {
case t_char :
return constant.charvalue() == constant.floatvalue();
case t_double :
return constant.doublevalue() == constant.floatvalue();
case t_float :
return true;
case t_int :
return constant.intvalue() == constant.floatvalue();
case t_short :
return constant.shortvalue() == constant.floatvalue();
case t_byte :
return constant.bytevalue() == constant.floatvalue();
case t_long :
return constant.longvalue() == constant.floatvalue();
default :
return false;//boolean
}

case t_double :
switch (constanttypeid) {
case t_char :
return constant.charvalue() == constant.doublevalue();
case t_double :
return true;
case t_float :
return constant.floatvalue() == constant.doublevalue();
case t_int :
return constant.intvalue() == constant.doublevalue();
case t_short :
return constant.shortvalue() == constant.doublevalue();
case t_byte :
return constant.bytevalue() == constant.doublevalue();
case t_long :
return constant.longvalue() == constant.doublevalue();
default :
return false; //boolean
}

case t_byte :
switch (constanttypeid) {
case t_char :
return constant.charvalue() == constant.bytevalue();
case t_double :
return constant.doublevalue() == constant.bytevalue();
case t_float :
return constant.floatvalue() == constant.bytevalue();
case t_int :
return constant.intvalue() == constant.bytevalue();
case t_short :
return constant.shortvalue() == constant.bytevalue();
case t_byte :
return true;
case t_long :
return constant.longvalue() == constant.bytevalue();
default :
return false; //boolean
}

case t_short :
switch (constanttypeid) {
case t_char :
return constant.charvalue() == constant.shortvalue();
case t_double :
return constant.doublevalue() == constant.shortvalue();
case t_float :
return constant.floatvalue() == constant.shortvalue();
case t_int :
return constant.intvalue() == constant.shortvalue();
case t_short :
return true;
case t_byte :
return constant.bytevalue() == constant.shortvalue();
case t_long :
return constant.longvalue() == constant.shortvalue();
default :
return false; //boolean
}

case t_int :
switch (constanttypeid) {
case t_char :
return constant.charvalue() == constant.intvalue();
case t_double :
return constant.doublevalue() == constant.intvalue();
case t_float :
return constant.floatvalue() == constant.intvalue();
case t_int :
return true;
case t_short :
return constant.shortvalue() == constant.intvalue();
case t_byte :
return constant.bytevalue() == constant.intvalue();
case t_long :
return constant.longvalue() == constant.intvalue();
default :
return false; //boolean
}

case t_long :
switch (constanttypeid) {
case t_char :
return constant.charvalue() == constant.longvalue();
case t_double :
return constant.doublevalue() == constant.longvalue();
case t_float :
return constant.floatvalue() == constant.longvalue();
case t_int :
return constant.intvalue() == constant.longvalue();
case t_short :
return constant.shortvalue() == constant.longvalue();
case t_byte :
return constant.bytevalue() == constant.longvalue();
case t_long :
return true;
default :
return false; //boolean
}

default :
return false; //boolean
}
}

public expression() {
super();
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
return flowinfo;
}

/**
* more sophisticated for of the flow analysis used for analyzing expressions, and be able to optimize out
* portions of expressions where no actual value is required.
*
* @@param currentscope
* @@param flowcontext
* @@param flowinfo
* @@param valuerequired
* @@return the state of initialization after the analysis of the current expression
*/
public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo, boolean valuerequired) {
return analysecode(currentscope, flowcontext, flowinfo);
}

/**
* returns false if cast is not legal.
*/
public final boolean checkcasttypescompatibility(scope scope, typebinding casttype, typebinding expressiontype, expression expression) {
// see specifications 5.5
// handle errors and process constant when needed

// if either one of the type is null ==>
// some error has been already reported some where ==>
// we then do not report an obvious-cascade-error.

if (casttype == null || expressiontype == null) return true;

// identity conversion cannot be performed upfront, due to side-effects
// like constant propagation
boolean use15specifics = scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
if (casttype.isbasetype()) {
if (expressiontype.isbasetype()) {
if (expressiontype == casttype) {
if (expression != null) {
this.constant = expression.constant; //use the same constant
}
tagasunnecessarycast(scope, casttype);
return true;
}
boolean necessary = false;
if (expressiontype.iscompatiblewith(casttype)
|| (necessary = basetypebinding.isnarrowing(casttype.id, expressiontype.id))) {
if (expression != null) {
expression.implicitconversion = (casttype.id << 4) + expressiontype.id;
if (expression.constant != constant.notaconstant) {
this.constant = expression.constant.castto(expression.implicitconversion);
}
}
if (!necessary) tagasunnecessarycast(scope, casttype);
return true;

}
} else if (use15specifics
&& scope.environment().computeboxingtype(expressiontype).iscompatiblewith(casttype)) { // unboxing - only widening match is allowed
tagasunnecessarycast(scope, casttype);
return true;
}
return false;
} else if (use15specifics
&& expressiontype.isbasetype()
&& scope.environment().computeboxingtype(expressiontype).iscompatiblewith(casttype)) { // boxing - only widening match is allowed
tagasunnecessarycast(scope, casttype);
return true;
}

switch(expressiontype.kind()) {
case binding.base_type :
//-----------cast to something which is not a base type--------------------------
if (expressiontype == typebinding.null) {
tagasunnecessarycast(scope, casttype);
return true; //null is compatible with every thing
}
return false;

case binding.array_type :
if (casttype == expressiontype) {
tagasunnecessarycast(scope, casttype);
return true; // identity conversion
}
switch (casttype.kind()) {
case binding.array_type :
// ( array ) array
typebinding castelementtype = ((arraybinding) casttype).elementstype();
typebinding exprelementtype = ((arraybinding) expressiontype).elementstype();
if (exprelementtype.isbasetype() || castelementtype.isbasetype()) {
if (castelementtype == exprelementtype) {
tagasneedcheckcast();
return true;
}
return false;
}
// recurse on array type elements
return checkcasttypescompatibility(scope, castelementtype, exprelementtype, expression);

case binding.type_parameter :
// ( type_parameter ) array
typebinding match = expressiontype.findsupertypeoriginatingfrom(casttype);
if (match == null) {
checkunsafecast(scope, casttype, expressiontype, null /*no match*/, true);
}
// recurse on the type variable upper bound
return checkcasttypescompatibility(scope, ((typevariablebinding)casttype).upperbound(), expressiontype, expression);

default:
// ( class/interface ) array
switch (casttype.id) {
case t_javalangcloneable :
case t_javaioserializable :
tagasneedcheckcast();
return true;
case t_javalangobject :
tagasunnecessarycast(scope, casttype);
return true;
default :
return false;
}
}

case binding.type_parameter :
typebinding match = expressiontype.findsupertypeoriginatingfrom(casttype);
if (match != null) {
return checkunsafecast(scope, casttype, expressiontype, match, false);
}
// recursively on the type variable upper bound
return checkcasttypescompatibility(scope, casttype, ((typevariablebinding)expressiontype).upperbound(), expression);

case binding.wildcard_type :
case binding.intersection_type :
match = expressiontype.findsupertypeoriginatingfrom(casttype);
if (match != null) {
return checkunsafecast(scope, casttype, expressiontype, match, false);
}
// recursively on the type variable upper bound
return checkcasttypescompatibility(scope, casttype, ((wildcardbinding)expressiontype).bound, expression);

default:
if (expressiontype.isinterface()) {
switch (casttype.kind()) {
case binding.array_type :
// ( array ) interface
switch (expressiontype.id) {
case t_javalangcloneable :
case t_javaioserializable :
tagasneedcheckcast();
return true;
default :
return false;
}

case binding.type_parameter :
// ( interface ) type_parameter
match = expressiontype.findsupertypeoriginatingfrom(casttype);
if (match == null) {
checkunsafecast(scope, casttype, expressiontype, null /*no match*/, true);
}
// recurse on the type variable upper bound
return checkcasttypescompatibility(scope, ((typevariablebinding)casttype).upperbound(), expressiontype, expression);

default :
if (casttype.isinterface()) {
// ( interface ) interface
referencebinding interfacetype = (referencebinding) expressiontype;
match = interfacetype.findsupertypeoriginatingfrom(casttype);
if (match != null) {
return checkunsafecast(scope, casttype, interfacetype, match, false);
}
tagasneedcheckcast();
match = casttype.findsupertypeoriginatingfrom(interfacetype);
if (match != null) {
return checkunsafecast(scope, casttype, interfacetype, match, true);
}
if (use15specifics) {
checkunsafecast(scope, casttype, expressiontype, null /*no match*/, true);
// ensure there is no collision between both interfaces: i.e. i1 extends list<string>, i2 extends list<object>
if (interfacetype.hasincompatiblesupertype((referencebinding)casttype))
return false;
} else {
// pre1.5 semantics - no covariance allowed (even if 1.5 compliant, but 1.4 source)
methodbinding[] casttypemethods = getallinheritedmethods((referencebinding) casttype);
methodbinding[] expressiontypemethods = getallinheritedmethods((referencebinding) expressiontype);
int exprmethodslength = expressiontypemethods.length;
for (int i = 0, castmethodslength = casttypemethods.length; i < castmethodslength; i++) {
for (int j = 0; j < exprmethodslength; j++) {
if ((casttypemethods[i].returntype != expressiontypemethods[j].returntype)
&& (charoperation.equals(casttypemethods[i].selector, expressiontypemethods[j].selector))
&& casttypemethods[i].areparametersequal(expressiontypemethods[j])) {
return false;

}
}
}
}
return true;
} else {
// ( class ) interface
if (casttype.id == typeids.t_javalangobject) { // no runtime error
tagasunnecessarycast(scope, casttype);
return true;
}
// can only be a downcast
tagasneedcheckcast();
match = casttype.findsupertypeoriginatingfrom(expressiontype);
if (match != null) {
return checkunsafecast(scope, casttype, expressiontype, match, true);
}
if (((referencebinding) casttype).isfinal()) {
// no subclass for casttype, thus compile-time check is invalid
return false;
}
if (use15specifics) {
checkunsafecast(scope, casttype, expressiontype, null /*no match*/, true);
// ensure there is no collision between both interfaces: i.e. i1 extends list<string>, i2 extends list<object>
if (((referencebinding)casttype).hasincompatiblesupertype((referencebinding) expressiontype)) {
return false;
}
}
return true;
}
}
} else {
switch (casttype.kind()) {
case binding.array_type :
// ( array ) class
if (expressiontype.id == typeids.t_javalangobject) { // potential runtime error
if (use15specifics) checkunsafecast(scope, casttype, expressiontype, expressiontype, true);
tagasneedcheckcast();
return true;
}
return false;

case binding.type_parameter :
// ( type_parameter ) class
match = expressiontype.findsupertypeoriginatingfrom(casttype);
if (match == null) {
checkunsafecast(scope, casttype, expressiontype, null, true);
}
// recurse on the type variable upper bound
return checkcasttypescompatibility(scope, ((typevariablebinding)casttype).upperbound(), expressiontype, expression);

default :
if (casttype.isinterface()) {
// ( interface ) class
referencebinding refexprtype = (referencebinding) expressiontype;
match = refexprtype.findsupertypeoriginatingfrom(casttype);
if (match != null) {
return checkunsafecast(scope, casttype, expressiontype, match, false);
}
// unless final a subclass may implement the interface ==> no check at compile time
if (refexprtype.isfinal()) {
return false;
}
tagasneedcheckcast();
match = casttype.findsupertypeoriginatingfrom(expressiontype);
if (match != null) {
return checkunsafecast(scope, casttype, expressiontype, match, true);
}
if (use15specifics) {
checkunsafecast(scope, casttype, expressiontype, null /*no match*/, true);
// ensure there is no collision between both interfaces: i.e. i1 extends list<string>, i2 extends list<object>
if (refexprtype.hasincompatiblesupertype((referencebinding) casttype))
return false;
}
return true;
} else {
// ( class ) class
match = expressiontype.findsupertypeoriginatingfrom(casttype);
if (match != null) {
if (expression != null && casttype.id == typeids.t_javalangstring) this.constant = expression.constant; // (string) cst is still a constant
return checkunsafecast(scope, casttype, expressiontype, match, false);
}
match = casttype.findsupertypeoriginatingfrom(expressiontype);
if (match != null) {
tagasneedcheckcast();
return checkunsafecast(scope, casttype, expressiontype, match, true);
}
return false;
}
}
}
}
}

/**
* check the local variable of this expression, if any, against potential npes
* given a flow context and an upstream flow info. if so, report the risk to
* the context. marks the local as checked, which affects the flow info.
* @@param scope the scope of the analysis
* @@param flowcontext the current flow context
* @@param flowinfo the upstream flow info; caveat: may get modified
*/
public void checknpe(blockscope scope, flowcontext flowcontext, flowinfo flowinfo) {
localvariablebinding local = localvariablebinding();
if (local != null &&
(local.type.tagbits & tagbits.isbasetype) == 0) {
if ((this.bits & astnode.isnonnull) == 0) {
flowcontext.recordusingnullreference(scope, local, this,
flowcontext.may_null, flowinfo);
}
flowinfo.markascomparedequaltononnull(local);
// from thereon it is set
if (flowcontext.initsonfinally != null) {
flowcontext.initsonfinally.markascomparedequaltononnull(local);
}
}
}

public boolean checkunsafecast(scope scope, typebinding casttype, typebinding expressiontype, typebinding match, boolean isnarrowing) {
if (match == casttype) {
if (!isnarrowing) tagasunnecessarycast(scope, casttype);
return true;
}
if (match != null && (!casttype.isreifiable() || !expressiontype.isreifiable())) {
if(isnarrowing
? match.isprovablydistinct(expressiontype)
: casttype.isprovablydistinct(match)) {
return false;
}
}
if (!isnarrowing) tagasunnecessarycast(scope, casttype);
return true;
}

/**
* base types need that the widening is explicitly done by the compiler using some bytecode like i2f.
* also check unsafe type operations.
*/
public void computeconversion(scope scope, typebinding runtimetype, typebinding compiletimetype) {
if (runtimetype == null || compiletimetype == null)
return;
if (this.implicitconversion != 0) return; // already set independantly

// it is possible for a byte to be unboxed to a byte & then converted to an int
// but it is not possible for a byte to become byte & then assigned to an integer,
// or to become an int before boxed into an integer
if (runtimetype != typebinding.null && runtimetype.isbasetype()) {
if (!compiletimetype.isbasetype()) {
typebinding unboxedtype = scope.environment().computeboxingtype(compiletimetype);
this.implicitconversion = typeids.unboxing;
scope.problemreporter().autoboxing(this, compiletimetype, runtimetype);
compiletimetype = unboxedtype;
}
} else if (compiletimetype != typebinding.null && compiletimetype.isbasetype()) {
typebinding boxedtype = scope.environment().computeboxingtype(runtimetype);
if (boxedtype == runtimetype) // object o = 12;
boxedtype = compiletimetype;
this.implicitconversion = typeids.boxing | (boxedtype.id << 4) + compiletimetype.id;
scope.problemreporter().autoboxing(this, compiletimetype, scope.environment().computeboxingtype(boxedtype));
return;
} else if (this.constant != constant.notaconstant && this.constant.typeid() != typeids.t_javalangstring) {
this.implicitconversion = typeids.boxing;
return;
}
int compiletimetypeid, runtimetypeid;
if ((compiletimetypeid = compiletimetype.id) == typeids.noid) { // e.g. ? extends string  ==> string (103227)
compiletimetypeid = compiletimetype.erasure().id == typeids.t_javalangstring ? typeids.t_javalangstring : typeids.t_javalangobject;
}
switch (runtimetypeid = runtimetype.id) {
case t_byte :
case t_short :
case t_char :
this.implicitconversion |= (typeids.t_int << 4) + compiletimetypeid;
break;
case t_javalangstring :
case t_float :
case t_boolean :
case t_double :
case t_int : //implicitconversion may result in i2i which will result in no code gen
case t_long :
this.implicitconversion |= (runtimetypeid << 4) + compiletimetypeid;
break;
default : // regular object ref
//				if (compiletimetype.israwtype() && runtimetimetype.isboundparameterizedtype()) {
//				    scope.problemreporter().unsaferawexpression(this, compiletimetype, runtimetimetype);
//				}
}
}

/**
* expression statements are plain expressions, however they generate like
* normal expressions with no value required.
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & astnode.isreachable) == 0) {
return;
}
generatecode(currentscope, codestream, false);
}

/**
* every expression is responsible for generating its implicit conversion when necessary.
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
if (this.constant != constant.notaconstant) {
// generate a constant expression
int pc = codestream.position;
codestream.generateconstant(this.constant, this.implicitconversion);
codestream.recordpositionsfrom(pc, this.sourcestart);
} else {
// actual non-constant code generation
throw new shouldnotimplement(messages.ast_missingcode);
}
}

/**
* default generation of a boolean value
* @@param currentscope
* @@param codestream
* @@param truelabel
* @@param falselabel
* @@param valuerequired
*/
public void generateoptimizedboolean(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {
// a label valued to nil means: by default we fall through the case...
// both nil means we leave the value on the stack

constant cst = optimizedbooleanconstant();
generatecode(currentscope, codestream, valuerequired && cst == constant.notaconstant);
if ((cst != constant.notaconstant) && (cst.typeid() == typeids.t_boolean)) {
int pc = codestream.position;
if (cst.booleanvalue() == true) {
// constant == true
if (valuerequired) {
if (falselabel == null) {
// implicit falling through the false case
if (truelabel != null) {
codestream.goto_(truelabel);
}
}
}
} else {
if (valuerequired) {
if (falselabel != null) {
// implicit falling through the true case
if (truelabel == null) {
codestream.goto_(falselabel);
}
}
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
// branching
int position = codestream.position;
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
codestream.ifne(truelabel);
}
} else {
if (truelabel == null) {
// implicit falling through the true case
codestream.ifeq(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, position);
}

/* optimized (java) code generation for string concatenations that involve stringbuffer
* creation: going through this path means that there is no need for a new stringbuffer
* creation, further operands should rather be only appended to the current one.
* by default: no optimization.
*/
public void generateoptimizedstringconcatenation(blockscope blockscope, codestream codestream, int typeid) {
if (typeid == typeids.t_javalangstring && this.constant != constant.notaconstant && this.constant.stringvalue().length() == 0) {
return; // optimize str + ""
}
generatecode(blockscope, codestream, true);
codestream.invokestringconcatenationappendfortype(typeid);
}

/* optimized (java) code generation for string concatenations that involve stringbuffer
* creation: going through this path means that there is no need for a new stringbuffer
* creation, further operands should rather be only appended to the current one.
*/
public void generateoptimizedstringconcatenationcreation(blockscope blockscope, codestream codestream, int typeid) {
codestream.newstringcontatenation();
codestream.dup();
switch (typeid) {
case t_javalangobject :
case t_undefined :
// in the case the runtime value of valueof(object) returns null, we have to use append(object) instead of directly valueof(object)
// append(object) returns append(valueof(object)), which means that the null case is handled by the next case.
codestream.invokestringconcatenationdefaultconstructor();
generatecode(blockscope, codestream, true);
codestream.invokestringconcatenationappendfortype(typeids.t_javalangobject);
return;
case t_javalangstring :
case t_null :
if (this.constant != constant.notaconstant) {
string stringvalue = this.constant.stringvalue();
if (stringvalue.length() == 0) {  // optimize ""+<str>
codestream.invokestringconcatenationdefaultconstructor();
return;
}
codestream.ldc(stringvalue);
} else {
// null case is not a constant
generatecode(blockscope, codestream, true);
codestream.invokestringvalueof(typeids.t_javalangobject);
}
break;
default :
generatecode(blockscope, codestream, true);
codestream.invokestringvalueof(typeid);
}
codestream.invokestringconcatenationstringconstructor();
}

private methodbinding[] getallinheritedmethods(referencebinding binding) {
arraylist collector = new arraylist();
getallinheritedmethods0(binding, collector);
return (methodbinding[]) collector.toarray(new methodbinding[collector.size()]);
}

private void getallinheritedmethods0(referencebinding binding, arraylist collector) {
if (!binding.isinterface()) return;
methodbinding[] methodbindings = binding.methods();
for (int i = 0, max = methodbindings.length; i < max; i++) {
collector.add(methodbindings[i]);
}
referencebinding[] superinterfaces = binding.superinterfaces();
for (int i = 0, max = superinterfaces.length; i < max; i++) {
getallinheritedmethods0(superinterfaces[i], collector);
}
}

public static binding getdirectbinding(expression someexpression) {
if ((someexpression.bits & astnode.ignorenoeffectassigncheck) != 0) {
return null;
}
if (someexpression instanceof singlenamereference) {
return ((singlenamereference)someexpression).binding;
} else if (someexpression instanceof fieldreference) {
fieldreference fieldref = (fieldreference)someexpression;
if (fieldref.receiver.isthis() && !(fieldref.receiver instanceof qualifiedthisreference)) {
return fieldref.binding;
}
} else if (someexpression instanceof assignment) {
expression lhs = ((assignment)someexpression).lhs;
if ((lhs.bits & astnode.isstrictlyassigned) != 0) {
// i = i = ...; // eq to int i = ...;
return getdirectbinding (((assignment)someexpression).lhs);
} else if (someexpression instanceof prefixexpression) {
// i = i++; // eq to ++i;
return getdirectbinding (((assignment)someexpression).lhs);
}
} else if (someexpression instanceof qualifiednamereference) {
qualifiednamereference qualifiednamereference = (qualifiednamereference) someexpression;
if (qualifiednamereference.indexoffirstfieldbinding != 1
&& qualifiednamereference.otherbindings == null) {
// case where a static field is retrieved using classname.fieldname
return qualifiednamereference.binding;
}
} else if (someexpression.isthis()) { // https://bugs.eclipse.org/bugs/show_bug.cgi?id=276741
return someexpression.resolvedtype;
}
//		} else if (someexpression instanceof postfixexpression) { // recurse for postfix: i++ --> i
//			// note: "b = b++" is equivalent to doing nothing, not to "b++"
//			return getdirectbinding(((postfixexpression) someexpression).lhs);
return null;
}

public boolean iscompactableoperation() {
return false;
}

//return true if the conversion is done automatically by the vm
//while the javavm is an int based-machine, thus for example pushing
//a byte onto the stack , will automatically create an int on the stack
//(this request some work d be done by the vm on signed numbers)
public boolean isconstantvalueoftypeassignabletotype(typebinding constanttype, typebinding targettype) {

if (this.constant == constant.notaconstant)
return false;
if (constanttype == targettype)
return true;
//no free assignment conversion from anything but to integral ones.
if (basetypebinding.iswidening(typeids.t_int, constanttype.id)
&& (basetypebinding.isnarrowing(targettype.id, typeids.t_int))) {
//use current explicit conversion in order to get some new value to compare with current one
return isconstantvaluerepresentable(this.constant, constanttype.id, targettype.id);
}
return false;
}

public boolean istypereference() {
return false;
}

/**
* returns the local variable referenced by this node. can be a direct reference (singlenamereference)
* or thru a cast expression etc...
*/
public localvariablebinding localvariablebinding() {
return null;
}

/**
* mark this expression as being non null, per a specific tag in the
* source code.
*/
// this is no more called for now, waiting for inter procedural null reference analysis
public void markasnonnull() {
this.bits |= astnode.isnonnull;
}

public int nullstatus(flowinfo flowinfo) {

if (/* (this.bits & isnonnull) != 0 || */
this.constant != null && this.constant != constant.notaconstant)
return flowinfo.non_null; // constant expression cannot be null

localvariablebinding local = localvariablebinding();
if (local != null) {
if (flowinfo.isdefinitelynull(local))
return flowinfo.null;
if (flowinfo.isdefinitelynonnull(local))
return flowinfo.non_null;
return flowinfo.unknown;
}
return flowinfo.non_null;
}

/**
* constant usable for bytecode pattern optimizations, but cannot be inlined
* since it is not strictly equivalent to the definition of constant expressions.
* in particular, some side-effects may be required to occur (only the end value
* is known).
* @@return constant known to be of boolean type
*/
public constant optimizedbooleanconstant() {
return this.constant;
}

/**
* returns the type of the expression after required implicit conversions. when expression type gets promoted
* or inserted a generic cast, the converted type will differ from the resolved type (surface side-effects from
* #computeconversion(...)).
* @@return the type after implicit conversion
*/
public typebinding postconversiontype(scope scope) {
typebinding convertedtype = this.resolvedtype;
int runtimetype = (this.implicitconversion & typeids.implicit_conversion_mask) >> 4;
switch (runtimetype) {
case t_boolean :
convertedtype = typebinding.boolean;
break;
case t_byte :
convertedtype = typebinding.byte;
break;
case t_short :
convertedtype = typebinding.short;
break;
case t_char :
convertedtype = typebinding.char;
break;
case t_int :
convertedtype = typebinding.int;
break;
case t_float :
convertedtype = typebinding.float;
break;
case t_long :
convertedtype = typebinding.long;
break;
case t_double :
convertedtype = typebinding.double;
break;
default :
}
if ((this.implicitconversion & typeids.boxing) != 0) {
convertedtype = scope.environment().computeboxingtype(convertedtype);
}
return convertedtype;
}

public stringbuffer print(int indent, stringbuffer output) {
printindent(indent, output);
return printexpression(indent, output);
}

public abstract stringbuffer printexpression(int indent, stringbuffer output);

public stringbuffer printstatement(int indent, stringbuffer output) {
return print(indent, output).append(";"); //$non-nls-1$
}

public void resolve(blockscope scope) {
// drops the returning expression's type whatever the type is.
this.resolvetype(scope);
return;
}

/**
* resolve the type of this expression in the context of a blockscope
*
* @@param scope
* @@return
* 	return the actual type of this expression after resolution
*/
public typebinding resolvetype(blockscope scope) {
// by default... subclasses should implement a better tb if required.
return null;
}

/**
* resolve the type of this expression in the context of a classscope
*
* @@param scope
* @@return
* 	return the actual type of this expression after resolution
*/
public typebinding resolvetype(classscope scope) {
// by default... subclasses should implement a better tb if required.
return null;
}

public typebinding resolvetypeexpecting(blockscope scope, typebinding expectedtype) {
setexpectedtype(expectedtype); // needed in case of generic method invocation
typebinding expressiontype = this.resolvetype(scope);
if (expressiontype == null) return null;
if (expressiontype == expectedtype) return expressiontype;

if (!expressiontype.iscompatiblewith(expectedtype)) {
if (scope.isboxingcompatiblewith(expressiontype, expectedtype)) {
computeconversion(scope, expectedtype, expressiontype);
} else {
scope.problemreporter().typemismatcherror(expressiontype, expectedtype, this, null);
return null;
}
}
return expressiontype;
}

/**
* returns an object which can be used to identify identical jsr sequence targets
* (see trystatement subroutine codegen)
* or <code>null</null> if not reusable
*/
public object reusablejsrtarget() {
if (this.constant != constant.notaconstant)
return this.constant;
return null;
}

/**
* record the type expectation before this expression is typechecked.
* e.g. string s = foo();, foo() will be tagged as being expected of type string
* used to trigger proper inference of generic method invocations.
*
* @@param expectedtype
* 	the type denoting an expectation in the context of an assignment conversion
*/
public void setexpectedtype(typebinding expectedtype) {
// do nothing by default
}

public void tagasneedcheckcast() {
// do nothing by default
}

/**
* record the fact a cast expression got detected as being unnecessary.
*
* @@param scope
* @@param casttype
*/
public void tagasunnecessarycast(scope scope, typebinding casttype) {
// do nothing by default
}

public expression totypereference() {
//by default undefined

//this method is meanly used by the parser in order to transform
//an expression that is used as a type reference in a cast ....
//--appreciate the fact that castexpression and expressionwithparenthesis
//--starts with the same pattern.....

return this;
}

/**
* traverse an expression in the context of a blockscope
* @@param visitor
* @@param scope
*/
public void traverse(astvisitor visitor, blockscope scope) {
// nothing to do
}

/**
* traverse an expression in the context of a classscope
* @@param visitor
* @@param scope
*/
public void traverse(astvisitor visitor, classscope scope) {
// nothing to do
}
}
