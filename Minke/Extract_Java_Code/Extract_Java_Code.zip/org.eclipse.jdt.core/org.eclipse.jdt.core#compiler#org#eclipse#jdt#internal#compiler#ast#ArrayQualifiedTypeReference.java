/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.problem.abortcompilation;

public class arrayqualifiedtypereference extends qualifiedtypereference {
int dimensions;

public arrayqualifiedtypereference(char[][] sources , int dim, long[] poss) {

super( sources , poss);
this.dimensions = dim ;
}

public int dimensions() {

return this.dimensions;
}

/**
* @@return char[][]
*/
public char [][] getparameterizedtypename(){
int dim = this.dimensions;
char[] dimchars = new char[dim*2];
for (int i = 0; i < dim; i++) {
int index = i*2;
dimchars[index] = '[';
dimchars[index+1] = ']';
}
int length = this.tokens.length;
char[][] qparamname = new char[length][];
system.arraycopy(this.tokens, 0, qparamname, 0, length-1);
qparamname[length-1] = charoperation.concat(this.tokens[length-1], dimchars);
return qparamname;
}

protected typebinding gettypebinding(scope scope) {

if (this.resolvedtype != null)
return this.resolvedtype;
if (this.dimensions > 255) {
scope.problemreporter().toomanydimensions(this);
}
lookupenvironment env = scope.environment();
try {
env.missingclassfilelocation = this;
typebinding leafcomponenttype = super.gettypebinding(scope);
return this.resolvedtype = scope.createarraytype(leafcomponenttype, this.dimensions);
} catch (abortcompilation e) {
e.updatecontext(this, scope.referencecompilationunit().compilationresult);
throw e;
} finally {
env.missingclassfilelocation = null;
}
}

public stringbuffer printexpression(int indent, stringbuffer output){

super.printexpression(indent, output);
if ((this.bits & isvarargs) != 0) {
for (int i= 0 ; i < this.dimensions - 1; i++) {
output.append("[]"); //$non-nls-1$
}
output.append("..."); //$non-nls-1$
} else {
for (int i= 0 ; i < this.dimensions; i++) {
output.append("[]"); //$non-nls-1$
}
}
return output;
}

public void traverse(astvisitor visitor, blockscope scope) {

visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {

visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
