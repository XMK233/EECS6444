/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

public class problemmethodbinding extends methodbinding {

private int problemreason;
public methodbinding closestmatch; // todo (philippe) should rename into #alternatematch

public problemmethodbinding(char[] selector, typebinding[] args, int problemreason) {
this.selector = selector;
this.parameters = (args == null || args.length == 0) ? binding.no_parameters : args;
this.problemreason = problemreason;
this.thrownexceptions = binding.no_exceptions;
}
public problemmethodbinding(char[] selector, typebinding[] args, referencebinding declaringclass, int problemreason) {
this.selector = selector;
this.parameters = (args == null || args.length == 0) ? binding.no_parameters : args;
this.declaringclass = declaringclass;
this.problemreason = problemreason;
this.thrownexceptions = binding.no_exceptions;
}
public problemmethodbinding(methodbinding closestmatch, char[] selector, typebinding[] args, int problemreason) {
this(selector, args, problemreason);
this.closestmatch = closestmatch;
if (closestmatch != null && problemreason != problemreasons.ambiguous) this.declaringclass = closestmatch.declaringclass;
}
/* api
* answer the problem id associated with the receiver.
* noerror if the receiver is a valid binding.
*/

public final int problemid() {
return this.problemreason;
}
}
