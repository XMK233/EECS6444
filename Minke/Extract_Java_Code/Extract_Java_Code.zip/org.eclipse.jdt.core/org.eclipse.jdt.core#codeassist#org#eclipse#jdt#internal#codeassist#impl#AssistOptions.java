/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.impl;

import java.util.map;

import org.eclipse.jdt.core.compiler.charoperation;

public class assistoptions {
/**
* option ids
*/
public static final string option_performvisibilitycheck =
"org.eclipse.jdt.core.codecomplete.visibilitycheck"; 	//$non-nls-1$
public static final string option_performdeprecationcheck =
"org.eclipse.jdt.core.codecomplete.deprecationcheck"; 	//$non-nls-1$
public static final string option_forceimplicitqualification =
"org.eclipse.jdt.core.codecomplete.forceimplicitqualification"; 	//$non-nls-1$
public static final string option_fieldprefixes =
"org.eclipse.jdt.core.codecomplete.fieldprefixes"; 	//$non-nls-1$
public static final string option_staticfieldprefixes =
"org.eclipse.jdt.core.codecomplete.staticfieldprefixes"; 	//$non-nls-1$
public static final string option_staticfinalfieldprefixes =
"org.eclipse.jdt.core.codecomplete.staticfinalfieldprefixes"; 	//$non-nls-1$
public static final string option_localprefixes =
"org.eclipse.jdt.core.codecomplete.localprefixes"; 	//$non-nls-1$
public static final string option_argumentprefixes =
"org.eclipse.jdt.core.codecomplete.argumentprefixes"; 	//$non-nls-1$
public static final string option_fieldsuffixes =
"org.eclipse.jdt.core.codecomplete.fieldsuffixes"; 	//$non-nls-1$
public static final string option_staticfieldsuffixes =
"org.eclipse.jdt.core.codecomplete.staticfieldsuffixes"; 	//$non-nls-1$
public static final string option_staticfinalfieldsuffixes =
"org.eclipse.jdt.core.codecomplete.staticfinalfieldsuffixes"; 	//$non-nls-1$
public static final string option_localsuffixes =
"org.eclipse.jdt.core.codecomplete.localsuffixes"; 	//$non-nls-1$
public static final string option_argumentsuffixes =
"org.eclipse.jdt.core.codecomplete.argumentsuffixes"; 	//$non-nls-1$
public static final string option_performforbiddenreferencecheck =
"org.eclipse.jdt.core.codecomplete.forbiddenreferencecheck"; 	//$non-nls-1$
public static final string option_performdiscouragedreferencecheck =
"org.eclipse.jdt.core.codecomplete.discouragedreferencecheck"; 	//$non-nls-1$
public static final string option_camelcasematch =
"org.eclipse.jdt.core.codecomplete.camelcasematch"; 	//$non-nls-1$
public static final string option_suggeststaticimports =
"org.eclipse.jdt.core.codecomplete.suggeststaticimports"; 	//$non-nls-1$

public static final string enabled = "enabled"; //$non-nls-1$
public static final string disabled = "disabled"; //$non-nls-1$

public boolean checkvisibility = false;
public boolean checkdeprecation = false;
public boolean checkforbiddenreference = false;
public boolean checkdiscouragedreference = false;
public boolean forceimplicitqualification = false;
public boolean camelcasematch = true;
public boolean suggeststaticimport = true;
public char[][] fieldprefixes = null;
public char[][] staticfieldprefixes = null;
public char[][] staticfinalfieldprefixes = null;
public char[][] localprefixes = null;
public char[][] argumentprefixes = null;
public char[][] fieldsuffixes = null;
public char[][] staticfieldsuffixes = null;
public char[][] staticfinalfieldsuffixes = null;
public char[][] localsuffixes = null;
public char[][] argumentsuffixes = null;

/**
* initializing the assist options with default settings
*/
public assistoptions() {
// initializing the assist options with default settings
}

/**
* initializing the assist options with external settings
*/
public assistoptions(map settings) {
if (settings == null)
return;

set(settings);
}
public void set(map optionsmap) {

object optionvalue;
if ((optionvalue = optionsmap.get(option_performvisibilitycheck)) != null) {
if (enabled.equals(optionvalue)) {
this.checkvisibility = true;
} else if (disabled.equals(optionvalue)) {
this.checkvisibility = false;
}
}
if ((optionvalue = optionsmap.get(option_forceimplicitqualification)) != null) {
if (enabled.equals(optionvalue)) {
this.forceimplicitqualification = true;
} else if (disabled.equals(optionvalue)) {
this.forceimplicitqualification = false;
}
}
if ((optionvalue = optionsmap.get(option_fieldprefixes)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() > 0){
this.fieldprefixes = splitandtrimon(',', stringvalue.tochararray());
} else {
this.fieldprefixes = null;
}
}
}
if ((optionvalue = optionsmap.get(option_staticfieldprefixes)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() > 0){
this.staticfieldprefixes = splitandtrimon(',', stringvalue.tochararray());
} else {
this.staticfieldprefixes = null;
}
}
}
if ((optionvalue = optionsmap.get(option_staticfinalfieldprefixes)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() > 0){
this.staticfinalfieldprefixes = splitandtrimon(',', stringvalue.tochararray());
} else {
this.staticfinalfieldprefixes = null;
}
}
}
if ((optionvalue = optionsmap.get(option_localprefixes)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() > 0){
this.localprefixes = splitandtrimon(',', stringvalue.tochararray());
} else {
this.localprefixes = null;
}
}
}
if ((optionvalue = optionsmap.get(option_argumentprefixes)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() > 0){
this.argumentprefixes = splitandtrimon(',', stringvalue.tochararray());
} else {
this.argumentprefixes = null;
}
}
}
if ((optionvalue = optionsmap.get(option_fieldsuffixes)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() > 0){
this.fieldsuffixes = splitandtrimon(',', stringvalue.tochararray());
} else {
this.fieldsuffixes = null;
}
}
}
if ((optionvalue = optionsmap.get(option_staticfieldsuffixes)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() > 0){
this.staticfieldsuffixes = splitandtrimon(',', stringvalue.tochararray());
} else {
this.staticfieldsuffixes = null;
}
}
}
if ((optionvalue = optionsmap.get(option_staticfinalfieldsuffixes)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() > 0){
this.staticfinalfieldsuffixes = splitandtrimon(',', stringvalue.tochararray());
} else {
this.staticfinalfieldsuffixes = null;
}
}
}
if ((optionvalue = optionsmap.get(option_localsuffixes)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() > 0){
this.localsuffixes = splitandtrimon(',', stringvalue.tochararray());
} else {
this.localsuffixes = null;
}
}
}
if ((optionvalue = optionsmap.get(option_argumentsuffixes)) != null) {
if (optionvalue instanceof string) {
string stringvalue = (string) optionvalue;
if (stringvalue.length() > 0){
this.argumentsuffixes = splitandtrimon(',', stringvalue.tochararray());
} else {
this.argumentsuffixes = null;
}
}
}
if ((optionvalue = optionsmap.get(option_performforbiddenreferencecheck)) != null) {
if (enabled.equals(optionvalue)) {
this.checkforbiddenreference = true;
} else if (disabled.equals(optionvalue)) {
this.checkforbiddenreference = false;
}
}
if ((optionvalue = optionsmap.get(option_performdiscouragedreferencecheck)) != null) {
if (enabled.equals(optionvalue)) {
this.checkdiscouragedreference = true;
} else if (disabled.equals(optionvalue)) {
this.checkdiscouragedreference = false;
}
}
if ((optionvalue = optionsmap.get(option_camelcasematch)) != null) {
if (enabled.equals(optionvalue)) {
this.camelcasematch = true;
} else if (disabled.equals(optionvalue)) {
this.camelcasematch = false;
}
}
if ((optionvalue = optionsmap.get(option_performdeprecationcheck)) != null) {
if (enabled.equals(optionvalue)) {
this.checkdeprecation = true;
} else if (disabled.equals(optionvalue)) {
this.checkdeprecation = false;
}
}
if ((optionvalue = optionsmap.get(option_suggeststaticimports)) != null) {
if (enabled.equals(optionvalue)) {
this.suggeststaticimport = true;
} else if (disabled.equals(optionvalue)) {
this.suggeststaticimport = false;
}
}
}

private char[][] splitandtrimon(char divider, char[] arraytosplit) {
char[][] result = charoperation.splitandtrimon(',', arraytosplit);

int length = result.length;

int resultcount = 0;
for (int i = 0; i < length; i++) {
if(result[i].length != 0) {
result[resultcount++] = result[i];
}
}
if(resultcount != length) {
system.arraycopy(result, 0, result = new char[resultcount][], 0, resultcount);
}
return result;
}
}
