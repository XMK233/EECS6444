/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

/*
* a document element parser extracts structural information
* from a piece of source, providing detailed source positions info.
*
* also see @@idocumentelementrequestor
*
* the structural investigation includes:
* - the package statement
* - import statements
* - top-level types: package member, member types (member types of member types...)
* - fields
* - methods
*
* any (parsing) problem encountered is also provided.
*/
import org.eclipse.jdt.internal.compiler.env.*;

import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.core.compiler.*;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.parser.*;
import org.eclipse.jdt.internal.compiler.problem.*;

public class documentelementparser extends parser {
idocumentelementrequestor requestor;
private int localintptr;
private int lastfieldendposition;
private int lastfieldbodyendposition;
private int typestartposition;
private long selectorsourcepositions;
private int typedims;
private int extendsdim;
private int declarationsourcestart;

/* int[] stack for storing javadoc positions */
int[][] intarraystack;
int intarrayptr;

compileroptions options;

public documentelementparser(
final idocumentelementrequestor requestor,
iproblemfactory problemfactory,
compileroptions options) {
super(new problemreporter(
defaulterrorhandlingpolicies.exitafterallproblems(),
options,
problemfactory) {
public void record(iproblem problem, compilationresult unitresult) {
requestor.acceptproblem(problem);
}
},
false);
this.requestor = requestor;
intarraystack = new int[30][];
this.options = options;
this.javadocparser.checkdoccomment = false;
}

/*
*
* internal use-only
*/
protected void adjustinterfacemodifiers() {
intstack[intptr - 2] |= accinterface;
}
/*
* will clear the comment stack when looking
* for a potential javadoc which might contain @@deprecated.
*
* additionally, before investigating for @@deprecated, retrieve the positions
* of the javadoc comments so as to notify requestor with them.
*/
public void checkcomment() {

/* persisting javadoc positions */
pushonintarraystack(this.getjavadocpositions());
boolean deprecated = false;
int lastcommentindex = -1;
int commentptr = scanner.commentptr;

//since jdk1.2 look only in the last java doc comment...
nextcomment : for (lastcommentindex = scanner.commentptr; lastcommentindex >= 0; lastcommentindex--){
//look for @@deprecated into the first javadoc comment preceeding the declaration
int commentsourcestart = scanner.commentstarts[lastcommentindex];
// javadoc only (non javadoc comment have negative end positions.)
if (modifierssourcestart != -1 && modifierssourcestart < commentsourcestart) {
continue nextcomment;
}
if (scanner.commentstops[lastcommentindex] < 0) {
continue nextcomment;
}
int commentsourceend = scanner.commentstops[lastcommentindex] - 1; //stop is one over
deprecated =
this.javadocparser.checkdeprecation(
commentsourcestart,
commentsourceend);
break nextcomment;
}
if (deprecated) {
checkandsetmodifiers(accdeprecated);
}
// modify the modifier source start to point at the first comment
if (commentptr >= 0) {
declarationsourcestart = scanner.commentstarts[0];
}
}
/*
*
* internal use-only
*/
protected void consumeclassbodydeclaration() {
// classbodydeclaration ::= diet block
//push an initializer
//optimize the push/pop

super.consumeclassbodydeclaration();
initializer initializer = (initializer) aststack[astptr];
requestor.acceptinitializer(
initializer.declarationsourcestart,
initializer.declarationsourceend,
intarraystack[intarrayptr--],
0,
modifierssourcestart,
initializer.block.sourcestart,
initializer.block.sourceend);
}
/*
*
* internal use-only
*/
protected void consumeclassdeclaration() {
super.consumeclassdeclaration();
// we know that we have a typedeclaration on the top of the aststack
if (islocaldeclaration()) {
// we ignore the local variable declarations
return;
}
requestor.exitclass(endstatementposition, // '}' is the end of the body
((typedeclaration) aststack[astptr]).declarationsourceend);
}
/*
*
* internal use-only
*/
protected void consumeclassheader() {
//classheader ::= $empty
super.consumeclassheader();
if (islocaldeclaration()) {
// we ignore the local variable declarations
intarrayptr--;
return;
}
typedeclaration typedecl = (typedeclaration) aststack[astptr];
typereference[] superinterfaces = typedecl.superinterfaces;
char[][] interfacenames = null;
int[] interfacenamestarts = null;
int[] interfacenameends = null;
if (superinterfaces != null) {
int superinterfaceslength = superinterfaces.length;
interfacenames = new char[superinterfaceslength][];
interfacenamestarts = new int[superinterfaceslength];
interfacenameends = new int[superinterfaceslength];
for (int i = 0; i < superinterfaceslength; i++) {
typereference superinterface = superinterfaces[i];
interfacenames[i] = charoperation.concatwith(superinterface.gettypename(), '.');
interfacenamestarts[i] = superinterface.sourcestart;
interfacenameends[i] = superinterface.sourceend;
}
}
// flush the comments related to the class header
scanner.commentptr = -1;
typereference superclass = typedecl.superclass;
if (superclass == null) {
requestor.enterclass(
typedecl.declarationsourcestart,
intarraystack[intarrayptr--],
typedecl.modifiers,
typedecl.modifierssourcestart,
typestartposition,
typedecl.name,
typedecl.sourcestart,
typedecl.sourceend,
null,
-1,
-1,
interfacenames,
interfacenamestarts,
interfacenameends,
scanner.currentposition - 1);
} else {
requestor.enterclass(
typedecl.declarationsourcestart,
intarraystack[intarrayptr--],
typedecl.modifiers,
typedecl.modifierssourcestart,
typestartposition,
typedecl.name,
typedecl.sourcestart,
typedecl.sourceend,
charoperation.concatwith(superclass.gettypename(), '.'),
superclass.sourcestart,
superclass.sourceend,
interfacenames,
interfacenamestarts,
interfacenameends,
scanner.currentposition - 1);

}
}
protected void consumeclassheadername() {
// classheadername ::= modifiersopt 'class' 'identifier'
typedeclaration typedecl = new typedeclaration(this.compilationunit.compilationresult);
if (nestedmethod[nestedtype] == 0) {
if (nestedtype != 0) {
typedecl.bits |= astnode.ismembertypemask;
}
} else {
// record that the block has a declaration for local types
typedecl.bits |= astnode.islocaltypemask;
markenclosingmemberwithlocaltype();
blockreal();
}

//highlight the name of the type
long pos = identifierpositionstack[identifierptr];
typedecl.sourceend = (int) pos;
typedecl.sourcestart = (int) (pos >>> 32);
typedecl.name = identifierstack[identifierptr--];
identifierlengthptr--;

//compute the declaration source too
// 'class' and 'interface' push an int position
typestartposition = typedecl.declarationsourcestart = intstack[intptr--];
intptr--;
int declsourcestart = intstack[intptr--];
typedecl.modifierssourcestart = intstack[intptr--];
typedecl.modifiers = intstack[intptr--];
if (typedecl.declarationsourcestart > declsourcestart) {
typedecl.declarationsourcestart = declsourcestart;
}
typedecl.bodystart = typedecl.sourceend + 1;
pushonaststack(typedecl);
// javadoc
typedecl.javadoc = this.javadoc;
this.javadoc = null;
}
/*
*
* internal use-only
*/
protected void consumecompilationunit() {
// compilationunit ::= entercompilationunit packagedeclarationopt importdeclarationsopt
requestor.exitcompilationunit(scanner.source.length - 1);
}
/*
*
* internal use-only
*/
protected void consumeconstructordeclaration() {
// constructordeclaration ::= constructorheader constructorbody
super.consumeconstructordeclaration();
if (islocaldeclaration()) {
// we ignore the local variable declarations
return;
}
constructordeclaration cd = (constructordeclaration) aststack[astptr];
requestor.exitconstructor(endstatementposition, cd.declarationsourceend);
}
/*
*
* internal use-only
*/
protected void consumeconstructorheader() {
// constructorheader ::= constructorheadername methodheaderparameters methodheaderthrowsclauseopt
super.consumeconstructorheader();
if (islocaldeclaration()) {
// we ignore the local variable declarations
intarrayptr--;
return;
}
constructordeclaration cd = (constructordeclaration) aststack[astptr];
argument[] arguments = cd.arguments;
char[][] argumenttypes = null;
char[][] argumentnames = null;
int[] argumenttypestarts = null;
int[] argumenttypeends = null;
int[] argumentnamestarts = null;
int[] argumentnameends = null;
if (arguments != null) {
int argumentlength = arguments.length;
argumenttypes = new char[argumentlength][];
argumentnames = new char[argumentlength][];
argumentnamestarts = new int[argumentlength];
argumentnameends = new int[argumentlength];
argumenttypestarts = new int[argumentlength];
argumenttypeends = new int[argumentlength];
for (int i = 0; i < argumentlength; i++) {
argument argument = arguments[i];
typereference argumenttype = argument.type;
argumenttypes[i] = returntypename(argumenttype);
argumentnames[i] = argument.name;
argumentnamestarts[i] = argument.sourcestart;
argumentnameends[i] = argument.sourceend;
argumenttypestarts[i] = argumenttype.sourcestart;
argumenttypeends[i] = argumenttype.sourceend;
}
}
typereference[] thrownexceptions = cd.thrownexceptions;
char[][] exceptiontypes = null;
int[] exceptiontypestarts = null;
int[] exceptiontypeends = null;
if (thrownexceptions != null) {
int thrownexceptionlength = thrownexceptions.length;
exceptiontypes = new char[thrownexceptionlength][];
exceptiontypestarts = new int[thrownexceptionlength];
exceptiontypeends = new int[thrownexceptionlength];
for (int i = 0; i < thrownexceptionlength; i++) {
typereference exception = thrownexceptions[i];
exceptiontypes[i] = charoperation.concatwith(exception.gettypename(), '.');
exceptiontypestarts[i] = exception.sourcestart;
exceptiontypeends[i] = exception.sourceend;
}
}
requestor
.enterconstructor(
cd.declarationsourcestart,
intarraystack[intarrayptr--],
cd.modifiers,
cd.modifierssourcestart,
cd.selector,
cd.sourcestart,
(int) (selectorsourcepositions & 0xffffffffl),
// retrieve the source end of the name
argumenttypes,
argumenttypestarts,
argumenttypeends,
argumentnames,
argumentnamestarts,
argumentnameends,
rparenpos,
// right parenthesis
exceptiontypes,
exceptiontypestarts,
exceptiontypeends,
scanner.currentposition - 1);
}
protected void consumeconstructorheadername() {
// constructorheadername ::=  modifiersopt 'identifier' '('
constructordeclaration cd = new constructordeclaration(this.compilationunit.compilationresult);

//name -- this is not really revelant but we do .....
cd.selector = identifierstack[identifierptr];
selectorsourcepositions = identifierpositionstack[identifierptr--];
identifierlengthptr--;

//modifiers
cd.declarationsourcestart = intstack[intptr--];
cd.modifierssourcestart = intstack[intptr--];
cd.modifiers = intstack[intptr--];
// javadoc
cd.javadoc = this.javadoc;
this.javadoc = null;

//highlight starts at the selector starts
cd.sourcestart = (int) (selectorsourcepositions >>> 32);
pushonaststack(cd);

cd.sourceend = lparenpos;
cd.bodystart = lparenpos + 1;
}
protected void consumedefaultmodifiers() {
checkcomment(); // might update modifiers with accdeprecated
pushonintstack(modifiers); // modifiers
pushonintstack(-1);
pushonintstack(
declarationsourcestart >= 0 ? declarationsourcestart : scanner.startposition);
resetmodifiers();
}
protected void consumediet() {
// diet ::= $empty
super.consumediet();
/* persisting javadoc positions
* will be consume in consumeclassbodydeclaration
*/
pushonintarraystack(this.getjavadocpositions());
}
/*
*
* internal use-only
*/
protected void consumeentercompilationunit() {
// entercompilationunit ::= $empty
requestor.entercompilationunit();
}
/*
*
* internal use-only
*/
protected void consumeentervariable() {
// entervariable ::= $empty
boolean islocaldeclaration = islocaldeclaration();
if (!islocaldeclaration && (variablescounter[nestedtype] != 0)) {
requestor.exitfield(lastfieldbodyendposition, lastfieldendposition);
}
char[] varname = identifierstack[identifierptr];
long nameposition = identifierpositionstack[identifierptr--];
int extendedtypedimension = intstack[intptr--];

abstractvariabledeclaration declaration;
if (nestedmethod[nestedtype] != 0) {
// create the local variable declarations
declaration =
new localdeclaration(varname, (int) (nameposition >>> 32), (int) nameposition);
} else {
// create the field declaration
declaration =
new fielddeclaration(varname, (int) (nameposition >>> 32), (int) nameposition);
}
identifierlengthptr--;
typereference type;
int variableindex = variablescounter[nestedtype];
int typedim = 0;
if (variableindex == 0) {
// first variable of the declaration (fielddeclaration or localdeclaration)
if (nestedmethod[nestedtype] != 0) {
// local declaration
declaration.declarationsourcestart = intstack[intptr--];
declaration.modifierssourcestart = intstack[intptr--];
declaration.modifiers = intstack[intptr--];
type = gettypereference(typedim = intstack[intptr--]); // type dimension
pushonaststack(type);
} else {
// field declaration
type = gettypereference(typedim = intstack[intptr--]); // type dimension
pushonaststack(type);
declaration.declarationsourcestart = intstack[intptr--];
declaration.modifierssourcestart = intstack[intptr--];
declaration.modifiers = intstack[intptr--];
}
} else {
type = (typereference) aststack[astptr - variableindex];
typedim = type.dimensions();
abstractvariabledeclaration previousvariable =
(abstractvariabledeclaration) aststack[astptr];
declaration.declarationsourcestart = previousvariable.declarationsourcestart;
declaration.modifiers = previousvariable.modifiers;
declaration.modifierssourcestart = previousvariable.modifierssourcestart;
}

localintptr = intptr;

if (extendedtypedimension == 0) {
declaration.type = type;
} else {
int dimension = typedim + extendedtypedimension;
//on the identifierlengthstack there is the information about the type....
int basetype;
if ((basetype = identifierlengthstack[identifierlengthptr + 1]) < 0) {
//it was a basetype
declaration.type = typereference.basetypereference(-basetype, dimension);
declaration.type.sourcestart = type.sourcestart;
declaration.type.sourceend = type.sourceend;
} else {
declaration.type = this.copydims(type, dimension);
}
}
variablescounter[nestedtype]++;
nestedmethod[nestedtype]++;
pushonaststack(declaration);

int[] javadocpositions = intarraystack[intarrayptr];
if (!islocaldeclaration) {
requestor
.enterfield(
declaration.declarationsourcestart,
javadocpositions,
declaration.modifiers,
declaration.modifierssourcestart,
returntypename(declaration.type),
type.sourcestart,
type.sourceend,
typedims,
varname,
(int) (nameposition >>> 32),
(int) nameposition,
extendedtypedimension,
extendedtypedimension == 0 ? -1 : endposition);
}
}
/*
*
* internal use-only
*/
protected void consumeexitvariablewithinitialization() {
// exitvariablewithinitialization ::= $empty
// the scanner is located after the comma or the semi-colon.
// we want to include the comma or the semi-colon
super.consumeexitvariablewithinitialization();
nestedmethod[nestedtype]--;
lastfieldendposition = scanner.currentposition - 1;
lastfieldbodyendposition = 	((abstractvariabledeclaration) aststack[astptr]).initialization.sourceend;
}
protected void consumeexitvariablewithoutinitialization() {
// exitvariablewithoutinitialization ::= $empty
// do nothing by default
super.consumeexitvariablewithoutinitialization();
nestedmethod[nestedtype]--;
lastfieldendposition = scanner.currentposition - 1;
lastfieldbodyendposition = scanner.startposition - 1;
}
/*
*
* internal use-only
*/
protected void consumefielddeclaration() {
// see consumelocalvariabledeclarationdefaultmodifier() in case of change: duplicated code
// fielddeclaration ::= modifiersopt type variabledeclarators ';'
// the super.consumefielddeclaration will reinitialize the variablecounter[nestedtype]
int variableindex = variablescounter[nestedtype];
super.consumefielddeclaration();
intarrayptr--;
if (islocaldeclaration())
return;
if (variableindex != 0) {
requestor.exitfield(lastfieldbodyendposition, lastfieldendposition);
}
}
protected void consumeformalparameter() {
// formalparameter ::= type variabledeclaratorid ==> false
// formalparameter ::= modifiers type variabledeclaratorid ==> true
/*
aststack :
identifierstack : type identifier
intstack : dim dim
==>
aststack : argument
identifierstack :
intstack :
*/

identifierlengthptr--;
char[] parametername = identifierstack[identifierptr];
long namepositions = identifierpositionstack[identifierptr--];
typereference type = gettypereference(intstack[intptr--] + intstack[intptr--]);
intptr -= 3;
argument arg =
new argument(
parametername,
namepositions,
type,
intstack[intptr + 1]); // modifiers
pushonaststack(arg);
intarrayptr--;
}
/*
*
* internal use-only
*/
protected void consumeinterfacedeclaration() {
super.consumeinterfacedeclaration();
// we know that we have a typedeclaration on the top of the aststack
if (islocaldeclaration()) {
// we ignore the local variable declarations
return;
}
requestor.exitinterface(endstatementposition, // the '}' is the end of the body
((typedeclaration) aststack[astptr]).declarationsourceend);
}
/*
*
* internal use-only
*/
protected void consumeinterfaceheader() {
//interfaceheader ::= $empty
super.consumeinterfaceheader();
if (islocaldeclaration()) {
// we ignore the local variable declarations
intarrayptr--;
return;
}
typedeclaration typedecl = (typedeclaration) aststack[astptr];
typereference[] superinterfaces = typedecl.superinterfaces;
char[][] interfacenames = null;
int[] interfacenamestarts = null;
int[] interfacenameends = null;
int superinterfaceslength = 0;
if (superinterfaces != null) {
superinterfaceslength = superinterfaces.length;
interfacenames = new char[superinterfaceslength][];
interfacenamestarts = new int[superinterfaceslength];
interfacenameends = new int[superinterfaceslength];
}
if (superinterfaces != null) {
for (int i = 0; i < superinterfaceslength; i++) {
typereference superinterface = superinterfaces[i];
interfacenames[i] = charoperation.concatwith(superinterface.gettypename(), '.');
interfacenamestarts[i] = superinterface.sourcestart;
interfacenameends[i] = superinterface.sourceend;
}
}
// flush the comments related to the interface header
scanner.commentptr = -1;
requestor.enterinterface(
typedecl.declarationsourcestart,
intarraystack[intarrayptr--],
typedecl.modifiers,
typedecl.modifierssourcestart,
typestartposition,
typedecl.name,
typedecl.sourcestart,
typedecl.sourceend,
interfacenames,
interfacenamestarts,
interfacenameends,
scanner.currentposition - 1);
}
protected void consumeinterfaceheadername() {
// interfaceheadername ::= modifiersopt 'interface' 'identifier'
typedeclaration typedecl = new typedeclaration(this.compilationunit.compilationresult);
if (nestedmethod[nestedtype] == 0) {
if (nestedtype != 0) {
typedecl.bits |= astnode.ismembertypemask;
}
} else {
// record that the block has a declaration for local types
typedecl.bits |= astnode.islocaltypemask;
markenclosingmemberwithlocaltype();
blockreal();
}

//highlight the name of the type
long pos = identifierpositionstack[identifierptr];
typedecl.sourceend = (int) pos;
typedecl.sourcestart = (int) (pos >>> 32);
typedecl.name = identifierstack[identifierptr--];
identifierlengthptr--;

//compute the declaration source too
// 'class' and 'interface' push an int position
typestartposition = typedecl.declarationsourcestart = intstack[intptr--];
intptr--;
int declsourcestart = intstack[intptr--];
typedecl.modifierssourcestart = intstack[intptr--];
typedecl.modifiers = intstack[intptr--];
if (typedecl.declarationsourcestart > declsourcestart) {
typedecl.declarationsourcestart = declsourcestart;
}
typedecl.bodystart = typedecl.sourceend + 1;
pushonaststack(typedecl);
// javadoc
typedecl.javadoc = this.javadoc;
this.javadoc = null;
}
/*
*
* internal use-only
*/
protected void consumelocalvariabledeclaration() {
// see consumelocalvariabledeclarationdefaultmodifier() in case of change: duplicated code
// fielddeclaration ::= modifiersopt type variabledeclarators ';'

super.consumelocalvariabledeclaration();
intarrayptr--;
}
/*
*
* internal use-only
*/
protected void consumemethoddeclaration(boolean isnotabstract) {
// methoddeclaration ::= methodheader methodbody
// abstractmethoddeclaration ::= methodheader ';'
super.consumemethoddeclaration(isnotabstract);
if (islocaldeclaration()) {
// we ignore the local variable declarations
return;
}
methoddeclaration md = (methoddeclaration) aststack[astptr];
requestor.exitmethod(endstatementposition, md.declarationsourceend);
}
/*
*
* internal use-only
*/
protected void consumemethodheader() {
// methodheader ::= methodheadername methodheaderparameters methodheaderextendeddims throwsclauseopt
super.consumemethodheader();
if (islocaldeclaration()) {
// we ignore the local variable declarations
intarrayptr--;
return;
}
methoddeclaration md = (methoddeclaration) aststack[astptr];

typereference returntype = md.returntype;
char[] returntypename = returntypename(returntype);
argument[] arguments = md.arguments;
char[][] argumenttypes = null;
char[][] argumentnames = null;
int[] argumenttypestarts = null;
int[] argumenttypeends = null;
int[] argumentnamestarts = null;
int[] argumentnameends = null;
if (arguments != null) {
int argumentlength = arguments.length;
argumenttypes = new char[argumentlength][];
argumentnames = new char[argumentlength][];
argumentnamestarts = new int[argumentlength];
argumentnameends = new int[argumentlength];
argumenttypestarts = new int[argumentlength];
argumenttypeends = new int[argumentlength];
for (int i = 0; i < argumentlength; i++) {
argument argument = arguments[i];
typereference argumenttype = argument.type;
argumenttypes[i] = returntypename(argumenttype);
argumentnames[i] = argument.name;
argumentnamestarts[i] = argument.sourcestart;
argumentnameends[i] = argument.sourceend;
argumenttypestarts[i] = argumenttype.sourcestart;
argumenttypeends[i] = argumenttype.sourceend;
}
}
typereference[] thrownexceptions = md.thrownexceptions;
char[][] exceptiontypes = null;
int[] exceptiontypestarts = null;
int[] exceptiontypeends = null;
if (thrownexceptions != null) {
int thrownexceptionlength = thrownexceptions.length;
exceptiontypestarts = new int[thrownexceptionlength];
exceptiontypeends = new int[thrownexceptionlength];
exceptiontypes = new char[thrownexceptionlength][];
for (int i = 0; i < thrownexceptionlength; i++) {
typereference exception = thrownexceptions[i];
exceptiontypes[i] = charoperation.concatwith(exception.gettypename(), '.');
exceptiontypestarts[i] = exception.sourcestart;
exceptiontypeends[i] = exception.sourceend;
}
}
requestor
.entermethod(
md.declarationsourcestart,
intarraystack[intarrayptr--],
md.modifiers,
md.modifierssourcestart,
returntypename,
returntype.sourcestart,
returntype.sourceend,
typedims,
md.selector,
md.sourcestart,
(int) (selectorsourcepositions & 0xffffffffl),
argumenttypes,
argumenttypestarts,
argumenttypeends,
argumentnames,
argumentnamestarts,
argumentnameends,
rparenpos,
extendsdim,
extendsdim == 0 ? -1 : endposition,
exceptiontypes,
exceptiontypestarts,
exceptiontypeends,
scanner.currentposition - 1);
}
protected void consumemethodheaderextendeddims() {
// methodheaderextendeddims ::= dimsopt
// now we update the returntype of the method
methoddeclaration md = (methoddeclaration) aststack[astptr];
int extendeddims = intstack[intptr--];
extendsdim = extendeddims;
if (extendeddims != 0) {
typereference returntype = md.returntype;
md.sourceend = endposition;
int dims = returntype.dimensions() + extendeddims;
int basetype;
if ((basetype = identifierlengthstack[identifierlengthptr + 1]) < 0) {
//it was a basetype
int sourcestart = returntype.sourcestart;
int sourceend = returntype.sourceend;
returntype = typereference.basetypereference(-basetype, dims);
returntype.sourcestart = sourcestart;
returntype.sourceend = sourceend;
md.returntype = returntype;
} else {
md.returntype = this.copydims(md.returntype, dims);
}
if (currenttoken == tokennamelbrace) {
md.bodystart = endposition + 1;
}
}
}
protected void consumemethodheadername() {
// methodheadername ::= modifiersopt type 'identifier' '('
methoddeclaration md = new methoddeclaration(this.compilationunit.compilationresult);

//name
md.selector = identifierstack[identifierptr];
selectorsourcepositions = identifierpositionstack[identifierptr--];
identifierlengthptr--;
//type
md.returntype = gettypereference(typedims = intstack[intptr--]);
//modifiers
md.declarationsourcestart = intstack[intptr--];
md.modifierssourcestart = intstack[intptr--];
md.modifiers = intstack[intptr--];
// javadoc
md.javadoc = this.javadoc;
this.javadoc = null;

//highlight starts at selector start
md.sourcestart = (int) (selectorsourcepositions >>> 32);
pushonaststack(md);
md.bodystart = scanner.currentposition-1;
}
protected void consumemodifiers() {
checkcomment(); // might update modifiers with accdeprecated
pushonintstack(modifiers); // modifiers
pushonintstack(modifierssourcestart);
pushonintstack(
declarationsourcestart >= 0 ? declarationsourcestart : modifierssourcestart);
resetmodifiers();
}
/*
*
* internal use-only
*/
protected void consumepackagedeclarationname() {
/* persisting javadoc positions */
pushonintarraystack(this.getjavadocpositions());

super.consumepackagedeclarationname();
importreference importreference = compilationunit.currentpackage;

requestor.acceptpackage(
importreference.declarationsourcestart,
importreference.declarationsourceend,
intarraystack[intarrayptr--],
charoperation.concatwith(importreference.getimportname(), '.'),
importreference.sourcestart);
}
protected void consumepushmodifiers() {
checkcomment(); // might update modifiers with accdeprecated
pushonintstack(modifiers); // modifiers
if (modifierssourcestart < 0) {
pushonintstack(-1);
pushonintstack(
declarationsourcestart >= 0 ? declarationsourcestart : scanner.startposition);
} else {
pushonintstack(modifierssourcestart);
pushonintstack(
declarationsourcestart >= 0 ? declarationsourcestart : modifierssourcestart);
}
resetmodifiers();
}
/*
*
* internal use-only
*/
protected void consumesingletypeimportdeclarationname() {
// singletypeimportdeclarationname ::= 'import' name

/* persisting javadoc positions */
pushonintarraystack(this.getjavadocpositions());

super.consumesingletypeimportdeclarationname();
importreference importreference = (importreference) aststack[astptr];
requestor.acceptimport(
importreference.declarationsourcestart,
importreference.declarationsourceend,
intarraystack[intarrayptr--],
charoperation.concatwith(importreference.getimportname(), '.'),
importreference.sourcestart,
false);
}
/*
*
* internal use-only
*/
protected void consumestaticinitializer() {
// staticinitializer ::=  staticonly block
//push an initializer
//optimize the push/pop
super.consumestaticinitializer();
initializer initializer = (initializer) aststack[astptr];
requestor.acceptinitializer(
initializer.declarationsourcestart,
initializer.declarationsourceend,
intarraystack[intarrayptr--],
accstatic,
intstack[intptr--],
initializer.block.sourcestart,
initializer.declarationsourceend);
}
protected void consumestaticonly() {
// staticonly ::= 'static'
checkcomment(); // might update declaration source start
pushonintstack(modifierssourcestart);
pushonintstack(scanner.currentposition);
pushonintstack(
declarationsourcestart >= 0 ? declarationsourcestart : modifierssourcestart);
jumpovermethodbody();
nestedmethod[nestedtype]++;
resetmodifiers();
}
/*
*
* internal use-only
*/
protected void consumetypeimportondemanddeclarationname() {
// typeimportondemanddeclarationname ::= 'import' name '.' '*'

/* persisting javadoc positions */
pushonintarraystack(this.getjavadocpositions());

super.consumetypeimportondemanddeclarationname();
importreference importreference = (importreference) aststack[astptr];
requestor.acceptimport(
importreference.declarationsourcestart,
importreference.declarationsourceend,
intarraystack[intarrayptr--],
charoperation.concatwith(importreference.getimportname(), '.'),
importreference.sourcestart,
true);
}
public compilationunitdeclaration endparse(int act) {
if (scanner.recordlineseparator) {
requestor.acceptlineseparatorpositions(scanner.getlineends());
}
return super.endparse(act);
}
/*
* flush javadocs defined prior to a given positions.
*
* note: javadocs are stacked in syntactical order
*
* either answer given <position>, or the end position of a comment line
* immediately following the <position> (same line)
*
* e.g.
* void foo(){
* } // end of method foo
*/

public int flushcommentsdefinedpriorto(int position) {

return lastfieldendposition = super.flushcommentsdefinedpriorto(position);
}
protected typereference gettypereference(int dim) { /* build a reference on a variable that may be qualified or not
this variable is a type reference and dim will be its dimensions*/

int length;
typereference ref;
if ((length = identifierlengthstack[identifierlengthptr--]) == 1) {
// single variable reference
if (dim == 0) {
ref =
new singletypereference(
identifierstack[identifierptr],
identifierpositionstack[identifierptr--]);
} else {
ref =
new arraytypereference(
identifierstack[identifierptr],
dim,
identifierpositionstack[identifierptr--]);
ref.sourceend = endposition;
}
} else {
if (length < 0) { //flag for precompiled type reference on base types
ref = typereference.basetypereference(-length, dim);
ref.sourcestart = intstack[intptr--];
if (dim == 0) {
ref.sourceend = intstack[intptr--];
} else {
intptr--;
ref.sourceend = endposition;
}
} else { //qualified variable reference
char[][] tokens = new char[length][];
identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(identifierstack, identifierptr + 1, tokens, 0, length);
system.arraycopy(
identifierpositionstack,
identifierptr + 1,
positions,
0,
length);
if (dim == 0) {
ref = new qualifiedtypereference(tokens, positions);
} else {
ref = new arrayqualifiedtypereference(tokens, dim, positions);
ref.sourceend = endposition;
}
}
}
return ref;
}
public void initialize() {
//positionning the parser for a new compilation unit
//avoiding stack reallocation and all that....
super.initialize();
intarrayptr = -1;
}
/*
*
* internal use-only
*/
private boolean islocaldeclaration() {
int nesteddepth = nestedtype;
while (nesteddepth >= 0) {
if (nestedmethod[nesteddepth] != 0) {
return true;
}
nesteddepth--;
}
return false;
}
/*
* investigate one entire unit.
*/
public void parsecompilationunit(icompilationunit unit) {
char[] regionsource = unit.getcontents();
try {
initialize();
goforcompilationunit();
referencecontext =
compilationunit =
compilationunit =
new compilationunitdeclaration(
problemreporter(),
new compilationresult(unit, 0, 0, this.options.maxproblemsperunit),
regionsource.length);
scanner.resetto(0, regionsource.length);
scanner.setsource(regionsource);
parse();
} catch (abortcompilation ex) {
// ignore this exception
}
}
/*
* investigate one constructor declaration.
*/
public void parseconstructor(char[] regionsource) {
try {
initialize();
goforclassbodydeclarations();
referencecontext =
compilationunit =
compilationunit =
new compilationunitdeclaration(
problemreporter(),
new compilationresult(regionsource, 0, 0, this.options.maxproblemsperunit),
regionsource.length);
scanner.resetto(0, regionsource.length);
scanner.setsource(regionsource);
parse();
} catch (abortcompilation ex) {
// ignore this exception
}
}
/*
* investigate one field declaration statement (might have multiple declarations in it).
*/
public void parsefield(char[] regionsource) {
try {
initialize();
goforfielddeclaration();
referencecontext =
compilationunit =
compilationunit =
new compilationunitdeclaration(
problemreporter(),
new compilationresult(regionsource, 0, 0, this.options.maxproblemsperunit),
regionsource.length);
scanner.resetto(0, regionsource.length);
scanner.setsource(regionsource);
parse();
} catch (abortcompilation ex) {
// ignore this exception
}

}
/*
* investigate one import statement declaration.
*/
public void parseimport(char[] regionsource) {
try {
initialize();
goforimportdeclaration();
referencecontext =
compilationunit =
compilationunit =
new compilationunitdeclaration(
problemreporter(),
new compilationresult(regionsource, 0, 0, this.options.maxproblemsperunit),
regionsource.length);
scanner.resetto(0, regionsource.length);
scanner.setsource(regionsource);
parse();
} catch (abortcompilation ex) {
// ignore this exception
}

}
/*
* investigate one initializer declaration.
* regionsource need to content exactly an initializer declaration.
* e.g: static { i = 4; }
* { name = "test"; }
*/
public void parseinitializer(char[] regionsource) {
try {
initialize();
goforinitializer();
referencecontext =
compilationunit =
compilationunit =
new compilationunitdeclaration(
problemreporter(),
new compilationresult(regionsource, 0, 0, this.options.maxproblemsperunit),
regionsource.length);
scanner.resetto(0, regionsource.length);
scanner.setsource(regionsource);
parse();
} catch (abortcompilation ex) {
// ignore this exception
}

}
/*
* investigate one method declaration.
*/
public void parsemethod(char[] regionsource) {
try {
initialize();
goforgenericmethoddeclaration();
referencecontext =
compilationunit =
compilationunit =
new compilationunitdeclaration(
problemreporter(),
new compilationresult(regionsource, 0, 0, this.options.maxproblemsperunit),
regionsource.length);
scanner.resetto(0, regionsource.length);
scanner.setsource(regionsource);
parse();
} catch (abortcompilation ex) {
// ignore this exception
}

}
/*
* investigate one package statement declaration.
*/
public void parsepackage(char[] regionsource) {
try {
initialize();
goforpackagedeclaration();
referencecontext =
compilationunit =
compilationunit =
new compilationunitdeclaration(
problemreporter(),
new compilationresult(regionsource, 0, 0, this.options.maxproblemsperunit),
regionsource.length);
scanner.resetto(0, regionsource.length);
scanner.setsource(regionsource);
parse();
} catch (abortcompilation ex) {
// ignore this exception
}

}
/*
* investigate one type declaration, its fields, methods and member types.
*/
public void parsetype(char[] regionsource) {
try {
initialize();
gofortypedeclaration();
referencecontext =
compilationunit =
compilationunit =
new compilationunitdeclaration(
problemreporter(),
new compilationresult(regionsource, 0, 0, this.options.maxproblemsperunit),
regionsource.length);
scanner.resetto(0, regionsource.length);
scanner.setsource(regionsource);
parse();
} catch (abortcompilation ex) {
// ignore this exception
}

}
/**
* returns this parser's problem reporter initialized with its reference context.
* also it is assumed that a problem is going to be reported, so initializes
* the compilation result's line positions.
*
* @@return problemreporter
*/
public problemreporter problemreporter() {
problemreporter.referencecontext = referencecontext;
return problemreporter;
}
protected void pushonintarraystack(int[] positions) {

try {
intarraystack[++intarrayptr] = positions;
} catch (indexoutofboundsexception e) {
//intptr is correct
int oldstacklength = intarraystack.length;
int oldstack[][] = intarraystack;
intarraystack = new int[oldstacklength + stackincrement][];
system.arraycopy(oldstack, 0, intarraystack, 0, oldstacklength);
intarraystack[intarrayptr] = positions;
}
}
protected void resetmodifiers() {
super.resetmodifiers();
declarationsourcestart = -1;
}
/*
* syntax error was detected. will attempt to perform some recovery action in order
* to resume to the regular parse loop.
*/
protected boolean resumeonsyntaxerror() {
return false;
}
/*
* answer a char array representation of the type name formatted like:
* - type name + dimensions
* example:
* "a[][]".tochararray()
* "java.lang.string".tochararray()
*/
private char[] returntypename(typereference type) {
int dimension = type.dimensions();
if (dimension != 0) {
char[] dimensionsarray = new char[dimension * 2];
for (int i = 0; i < dimension; i++) {
dimensionsarray[i*2] = '[';
dimensionsarray[(i*2) + 1] = ']';
}
return charoperation.concat(
charoperation.concatwith(type.gettypename(), '.'),
dimensionsarray);
}
return charoperation.concatwith(type.gettypename(), '.');
}
public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append("intarrayptr = " + intarrayptr + "\n"); //$non-nls-1$ //$non-nls-2$
buffer.append(super.tostring());
return buffer.tostring();
}
/*
*
* internal use only
*/
protected typereference typereference(
int dim,
int localidentifierptr,
int localidentifierlengthptr) {
/* build a reference on a variable that may be qualified or not
* this variable is a type reference and dim will be its dimensions.
* we don't have any side effect on the stacks' pointers.
*/

int length;
typereference ref;
if ((length = identifierlengthstack[localidentifierlengthptr]) == 1) {
// single variable reference
if (dim == 0) {
ref =
new singletypereference(
identifierstack[localidentifierptr],
identifierpositionstack[localidentifierptr--]);
} else {
ref =
new arraytypereference(
identifierstack[localidentifierptr],
dim,
identifierpositionstack[localidentifierptr--]);
ref.sourceend = endposition;
}
} else {
if (length < 0) { //flag for precompiled type reference on base types
ref = typereference.basetypereference(-length, dim);
ref.sourcestart = intstack[localintptr--];
if (dim == 0) {
ref.sourceend = intstack[localintptr--];
} else {
localintptr--;
ref.sourceend = endposition;
}
} else { //qualified variable reference
char[][] tokens = new char[length][];
localidentifierptr -= length;
long[] positions = new long[length];
system.arraycopy(identifierstack, localidentifierptr + 1, tokens, 0, length);
system.arraycopy(
identifierpositionstack,
localidentifierptr + 1,
positions,
0,
length);
if (dim == 0)
ref = new qualifiedtypereference(tokens, positions);
else
ref = new arrayqualifiedtypereference(tokens, dim, positions);
}
}
return ref;
}
}
