/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;


public class annotationreturnstatement extends returnstatement {
public char[] description;

public annotationreturnstatement(int s, int e, char[] descr) {
super(null, s, e);
this.description = descr;
this.bits |= insideannotation;
}

public void resolve(blockscope scope) {
methodscope methodscope = scope.methodscope();
methodbinding methodbinding;
typebinding methodtype =
(methodscope.referencecontext instanceof abstractmethoddeclaration)
? ((methodbinding = ((abstractmethoddeclaration) methodscope.referencecontext).binding) == null
? null
: methodbinding.returntype)
: voidbinding;
if (methodtype == voidbinding) {
if (this.description != null) {
scope.problemreporter().annotationunexpectedtag(this.sourcestart, this.sourceend);
}
}
else{
if (this.description == null) {
scope.problemreporter().annotationinvalidreturntag(this.sourcestart, this.sourceend, true);
}
}
}

/* (non-javadoc)
* redefine to capture annotation specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(iabstractsyntaxtreevisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
