/**********************************************************************
copyright (c) 2002 ibm corp. and others.
all rights reserved.  this program and the accompanying materials
are made available under the terms of the common public license v1.0
which accompanies this distribution, and is available at
http://www.eclipse.org/legal/cpl-v10.html

contributors:
ibm corporation - initial api and implementation
ibm corporation - added getrawtokensource()
**********************************************************************/

package org.eclipse.jdt.core.compiler;

/**
* definition of a java scanner, as returned by the <code>toolfactory</code>.
* the scanner is responsible for tokenizing a given source, providing information about
* the nature of the token read, its positions and source equivalent.
*
* when the scanner has finished tokenizing, it answers an eof token (<code>
* iterminalsymbols#tokennameeof</code>.
*
* when encountering lexical errors, an <code>invalidinputexception</code> is thrown.
*
* @@see org.eclipse.jdt.core.toolfactory
* @@see iterminalsymbols
* @@since 2.0
*/
public interface iscanner {

/**
* answers the current identifier source, after unicode escape sequences have
* been translated into unicode characters.
* e.g. if original source was <code>\\u0061bc</code> then it will answer <code>abc</code>.
*
* @@return the current identifier source, after unicode escape sequences have
* been translated into unicode characters
*/
char[] getcurrenttokensource();

/**
* answers the current identifier source, before unicode escape sequences have
* been translated into unicode characters.
* e.g. if original source was <code>\\u0061bc</code> then it will answer <code>\\u0061bc</code>.
*
* @@return the current identifier source, before unicode escape sequences have
* been translated into unicode characters
* @@since 2.1
*/
char[] getrawtokensource();

/**
* answers the starting position of the current token inside the original source.
* this position is zero-based and inclusive. it corresponds to the position of the first character
* which is part of this token. if this character was a unicode escape sequence, it points at the first
* character of this sequence.
*
* @@return the starting position of the current token inside the original source
*/
int getcurrenttokenstartposition();

/**
* answers the ending position of the current token inside the original source.
* this position is zero-based and inclusive. it corresponds to the position of the last character
* which is part of this token. if this character was a unicode escape sequence, it points at the last
* character of this sequence.
*
* @@return the ending position of the current token inside the original source
*/
int getcurrenttokenendposition();

/**
* answers the starting position of a given line number. this line has to have been encountered
* already in the tokenization process (i.e. it cannot be used to compute positions of lines beyond
* current token). once the entire source has been processed, it can be used without any limit.
* line starting positions are zero-based, and start immediately after the previous line separator (if any).
*
* @@param linenumber the given line number
* @@return the starting position of a given line number
*/
int getlinestart(int linenumber);

/**
* answers the ending position of a given line number. this line has to have been encountered
* already in the tokenization process (i.e. it cannot be used to compute positions of lines beyond
* current token). once the entire source has been processed, it can be used without any limit.
* line ending positions are zero-based, and correspond to the last character of the line separator
* (in case multi-character line separators).
*
* @@param linenumber the given line number
* @@return the ending position of a given line number
**/
int getlineend(int linenumber);

/**
* answers an array of the ending positions of the lines encountered so far. line ending positions
* are zero-based, and correspond to the last character of the line separator (in case multi-character
* line separators).
*
* @@return an array of the ending positions of the lines encountered so far
*/
int[] getlineends();

/**
* answers a 1-based line number using the lines which have been encountered so far. if the position
* is located beyond the current scanned line, then the last line number will be answered.
*
* @@param charposition the given character position
* @@return a 1-based line number using the lines which have been encountered so far
*/
int getlinenumber(int charposition);

/**
* read the next token in the source, and answers its id as specified by <code>iterminalsymbols</code>.
* note that the actual token id values are subject to change if new keywords were added to the language
* (i.e. 'assert' keyword in 1.4).
*
* @@throws invalidinputexception - in case a lexical error was detected while reading the current token
*/
int getnexttoken() throws invalidinputexception;

/**
* answers the original source being processed (not a copy of it).
*
* @@return the original source being processed
*/
char[] getsource();

/**
* reposition the scanner on some portion of the original source. once reaching the given <code>endposition</code>
* it will answer eof tokens (<code>iterminalsymbols.tokennameeof</code>).
*
* @@param startposition the given start position
* @@param endposition the given end position
*/
void resetto(int startposition, int endposition);

/**
* set the scanner source to process. by default, the scanner will consider starting at the beginning of the
* source until it reaches its end.
*
* @@param source the given source
*/
void setsource(char[] source);
}
