/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import java.util.locale;
import java.util.map;

import org.eclipse.core.resources.ifile;
import org.eclipse.core.runtime.iprogressmonitor;
import org.eclipse.core.runtime.operationcanceledexception;
import org.eclipse.jdt.core.itype;
import org.eclipse.jdt.core.javamodelexception;
import org.eclipse.jdt.core.signature;
import org.eclipse.jdt.core.workingcopyowner;
import org.eclipse.jdt.core.compiler.*;
import org.eclipse.jdt.core.search.ijavasearchconstants;
import org.eclipse.jdt.core.search.ijavasearchscope;
import org.eclipse.jdt.core.search.searchpattern;
import org.eclipse.jdt.core.search.typenamematch;
import org.eclipse.jdt.core.search.typenamematchrequestor;
import org.eclipse.jdt.internal.codeassist.impl.*;
import org.eclipse.jdt.internal.codeassist.select.*;
import org.eclipse.jdt.internal.compiler.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.classfmt.classfilereader;
import org.eclipse.jdt.internal.compiler.env.*;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.*;
import org.eclipse.jdt.internal.compiler.problem.*;
import org.eclipse.jdt.internal.compiler.util.hashtableofobject;
import org.eclipse.jdt.internal.compiler.util.objectvector;
import org.eclipse.jdt.internal.core.binarytypeconverter;
import org.eclipse.jdt.internal.core.classfile;
import org.eclipse.jdt.internal.core.javamodelmanager;
import org.eclipse.jdt.internal.core.searchableenvironment;
import org.eclipse.jdt.internal.core.selectionrequestor;
import org.eclipse.jdt.internal.core.sourcetype;
import org.eclipse.jdt.internal.core.sourcetypeelementinfo;
import org.eclipse.jdt.internal.core.search.basicsearchengine;
import org.eclipse.jdt.internal.core.search.typenamematchrequestorwrapper;
import org.eclipse.jdt.internal.core.util.astnodefinder;
import org.eclipse.jdt.internal.core.util.hashsetofchararrayarray;

/**
* the selection engine is intended to infer the nature of a selected name in some
* source code. this name can be qualified.
*
* selection is resolving context using a name environment (no need to search), assuming
* the source where selection occurred is correct and will not perform any completion
* attempt. if this was the desired behavior, a call to the completionengine should be
* performed instead.
*/
public final class selectionengine extends engine implements isearchrequestor {

private static class selectiontypenamematchrequestorwrapper extends typenamematchrequestorwrapper {

class acceptedtype {
public int modifiers;
public char[] packagename;
public char[] simpletypename;
public string path;
public accessrestriction access;

public acceptedtype(int modifiers, char[] packagename, char[] simpletypename, string path, accessrestriction access) {
this.modifiers = modifiers;
this.packagename = packagename;
this.simpletypename = simpletypename;
this.path = path;
this.access = access;
}
}

private importreference[] importreferences;

private boolean importcachesnodeinitialized = false;
private importreference[] ondemandimportsnodecache;
private int ondemandimportsnodecachecount;
private char[][][] importsnodecache;
private int importsnodecachecount;

private hashtableofobject ondemandfound = new hashtableofobject();
private objectvector notimportedfound = new objectvector();

public selectiontypenamematchrequestorwrapper(typenamematchrequestor requestor, ijavasearchscope scope, importreference[] importreferences) {
super(requestor, scope);
this.importreferences = importreferences;
}

public void accepttype(int modifiers, char[] packagename, char[] simpletypename, char[][] enclosingtypenames, string path, accessrestriction access) {
if (enclosingtypenames != null && enclosingtypenames.length > 0) return;

if (!this.importcachesnodeinitialized) initializeimportnodecaches();

char[] fullyqualifiedtypename = charoperation.concat(packagename, simpletypename, '.');

for (int i = 0; i < this.importsnodecachecount; i++) {
char[][] importname = this.importsnodecache[i];
if (charoperation.equals(importname[0], simpletypename)) {

if(charoperation.equals(importname[1], fullyqualifiedtypename)) {
super.accepttype(modifiers, packagename, simpletypename, enclosingtypenames, path, access);
}
return;
}
}

for (int i = 0; i < this.ondemandimportsnodecachecount; i++) {
char[][] importname = this.ondemandimportsnodecache[i].tokens;
char[] importflatname = charoperation.concatwith(importname, '.');

if (charoperation.equals(importflatname, packagename)) {

this.ondemandfound.put(simpletypename, simpletypename);
super.accepttype(modifiers, packagename, simpletypename, enclosingtypenames, path, access);
return;
}
}


this.notimportedfound.add(new acceptedtype(modifiers, packagename, simpletypename, path, access));
}

public void acceptnotimported() {
int size = this.notimportedfound.size();
for (int i = 0; i < size; i++) {
acceptedtype acceptedtype = (acceptedtype)this.notimportedfound.elementat(i);

if (this.ondemandfound.get(acceptedtype.simpletypename) == null) {
super.accepttype(
acceptedtype.modifiers,
acceptedtype.packagename,
acceptedtype.simpletypename,
null,
acceptedtype.path,
acceptedtype.access);
}
}
}

public void initializeimportnodecaches() {
int length = this.importreferences == null ? 0 : this.importreferences.length;

for (int i = 0; i < length; i++) {
importreference importreference = this.importreferences[i];
if((importreference.bits & astnode.ondemand) != 0) {
if(this.ondemandimportsnodecache == null) {
this.ondemandimportsnodecache = new importreference[length - i];
}
this.ondemandimportsnodecache[this.ondemandimportsnodecachecount++] =
importreference;
} else {
if(this.importsnodecache == null) {
this.importsnodecache = new char[length - i][][];
}


this.importsnodecache[this.importsnodecachecount++] = new char[][]{
importreference.tokens[importreference.tokens.length - 1],
charoperation.concatwith(importreference.tokens, '.')
};
}
}

this.importcachesnodeinitialized = true;
}
}

public static boolean debug = false;
public static boolean perf = false;

selectionparser parser;
iselectionrequestor requestor;
workingcopyowner owner;

boolean acceptedanswer;

private int actualselectionstart;
private int actualselectionend;
private char[] selectedidentifier;

private char[][][] acceptedclasses;
private int[] acceptedclassesmodifiers;
private char[][][] acceptedinterfaces;
private int[] acceptedinterfacesmodifiers;
private char[][][] acceptedenums;
private int[] acceptedenumsmodifiers;
private char[][][] acceptedannotations;
private int[] acceptedannotationsmodifiers;
int acceptedclassescount;
int acceptedinterfacescount;
int acceptedenumscount;
int acceptedannotationscount;

boolean noproposal = true;
categorizedproblem problem = null;

/**
* the selectionengine is responsible for computing the selected object.
*
* it requires a searchable name environment, which supports some
* specific search apis, and a requestor to feed back the results to a ui.
*
*  @@param nameenvironment org.eclipse.jdt.internal.core.searchableenvironment
*      used to resolve type/package references and search for types/packages
*      based on partial names.
*
*  @@param requestor org.eclipse.jdt.internal.codeassist.iselectionrequestor
*      since the engine might produce answers of various forms, the engine
*      is associated with a requestor able to accept all possible completions.
*
*  @@param settings java.util.map
*		set of options used to configure the code assist engine.
*/
public selectionengine(
searchableenvironment nameenvironment,
iselectionrequestor requestor,
map settings,
workingcopyowner owner) {

super(settings);

this.requestor = requestor;
this.nameenvironment = nameenvironment;

problemreporter problemreporter =
new problemreporter(
defaulterrorhandlingpolicies.proceedwithallproblems(),
this.compileroptions,
new defaultproblemfactory(locale.getdefault())) {

public categorizedproblem createproblem(
char[] filename,
int problemid,
string[] problemarguments,
string[] messagearguments,
int severity,
int problemstartposition,
int problemendposition,
int linenumber,
int columnnumber) {
categorizedproblem pb =  super.createproblem(
filename,
problemid,
problemarguments,
messagearguments,
severity,
problemstartposition,
problemendposition,
linenumber,
columnnumber);
if(selectionengine.this.problem == null && pb.iserror() && (pb.getid() & iproblem.syntax) == 0) {
selectionengine.this.problem = pb;
}

return pb;
}
};
this.lookupenvironment =
new lookupenvironment(this, this.compileroptions, problemreporter, nameenvironment);
this.parser = new selectionparser(problemreporter);
this.owner = owner;
}

public void acceptconstructor(
int modifiers,
char[] simpletypename,
int parametercount,
char[] signature,
char[][] parametertypes,
char[][] parameternames,
int typemodifiers,
char[] packagename,
int extraflags,
string path,
accessrestriction access) {
// constructors aren't searched
}

public void accepttype(char[] packagename, char[] simpletypename, char[][] enclosingtypenames, int modifiers, accessrestriction accessrestriction) {
char[] typename = enclosingtypenames == null ?
simpletypename :
charoperation.concat(
charoperation.concatwith(enclosingtypenames, '.'),
simpletypename,
'.');

if (charoperation.equals(simpletypename, this.selectedidentifier)) {
char[] flatenclosingtypenames =
enclosingtypenames == null || enclosingtypenames.length == 0 ?
null :
charoperation.concatwith(enclosingtypenames, '.');
if(mustqualifytype(packagename, simpletypename, flatenclosingtypenames, modifiers)) {
int length = 0;
int kind = modifiers & (classfileconstants.accinterface | classfileconstants.accenum | classfileconstants.accannotation);
switch (kind) {
case classfileconstants.accannotation:
case classfileconstants.accannotation | classfileconstants.accinterface:
char[][] acceptedannotation = new char[2][];
acceptedannotation[0] = packagename;
acceptedannotation[1] = typename;

if(this.acceptedannotations == null) {
this.acceptedannotations = new char[10][][];
this.acceptedannotationsmodifiers = new int[10];
this.acceptedannotationscount = 0;
}
length = this.acceptedannotations.length;
if(length == this.acceptedannotationscount) {
int newlength = (length + 1)* 2;
system.arraycopy(this.acceptedannotations, 0, this.acceptedannotations = new char[newlength][][], 0, length);
system.arraycopy(this.acceptedannotationsmodifiers, 0, this.acceptedannotationsmodifiers = new int[newlength], 0, length);
}
this.acceptedannotationsmodifiers[this.acceptedannotationscount] = modifiers;
this.acceptedannotations[this.acceptedannotationscount++] = acceptedannotation;
break;
case classfileconstants.accenum:
char[][] acceptedenum = new char[2][];
acceptedenum[0] = packagename;
acceptedenum[1] = typename;

if(this.acceptedenums == null) {
this.acceptedenums = new char[10][][];
this.acceptedenumsmodifiers = new int[10];
this.acceptedenumscount = 0;
}
length = this.acceptedenums.length;
if(length == this.acceptedenumscount) {
int newlength = (length + 1)* 2;
system.arraycopy(this.acceptedenums, 0, this.acceptedenums = new char[newlength][][], 0, length);
system.arraycopy(this.acceptedenumsmodifiers, 0, this.acceptedenumsmodifiers = new int[newlength], 0, length);
}
this.acceptedenumsmodifiers[this.acceptedenumscount] = modifiers;
this.acceptedenums[this.acceptedenumscount++] = acceptedenum;
break;
case classfileconstants.accinterface:
char[][] acceptedinterface= new char[2][];
acceptedinterface[0] = packagename;
acceptedinterface[1] = typename;

if(this.acceptedinterfaces == null) {
this.acceptedinterfaces = new char[10][][];
this.acceptedinterfacesmodifiers = new int[10];
this.acceptedinterfacescount = 0;
}
length = this.acceptedinterfaces.length;
if(length == this.acceptedinterfacescount) {
int newlength = (length + 1)* 2;
system.arraycopy(this.acceptedinterfaces, 0, this.acceptedinterfaces = new char[newlength][][], 0, length);
system.arraycopy(this.acceptedinterfacesmodifiers, 0, this.acceptedinterfacesmodifiers = new int[newlength], 0, length);
}
this.acceptedinterfacesmodifiers[this.acceptedinterfacescount] = modifiers;
this.acceptedinterfaces[this.acceptedinterfacescount++] = acceptedinterface;
break;
default:
char[][] acceptedclass = new char[2][];
acceptedclass[0] = packagename;
acceptedclass[1] = typename;

if(this.acceptedclasses == null) {
this.acceptedclasses = new char[10][][];
this.acceptedclassesmodifiers = new int[10];
this.acceptedclassescount = 0;
}
length = this.acceptedclasses.length;
if(length == this.acceptedclassescount) {
int newlength = (length + 1)* 2;
system.arraycopy(this.acceptedclasses, 0, this.acceptedclasses = new char[newlength][][], 0, length);
system.arraycopy(this.acceptedclassesmodifiers, 0, this.acceptedclassesmodifiers = new int[newlength], 0, length);
}
this.acceptedclassesmodifiers[this.acceptedclassescount] = modifiers;
this.acceptedclasses[this.acceptedclassescount++] = acceptedclass;
break;
}
} else {
this.noproposal = false;
this.requestor.accepttype(
packagename,
typename,
modifiers,
false,
null,
this.actualselectionstart,
this.actualselectionend);
this.acceptedanswer = true;
}
}
}

/**
* one result of the search consists of a new package.
* @@param packagename char[]
*
* note - all package names are presented in their readable form:
*    package names are in the form "a.b.c".
*    the default package is represented by an empty array.
*/
public void acceptpackage(char[] packagename) {
// implementation of interface method
}

private void acceptqualifiedtypes() {
if(this.acceptedclasses != null){
this.acceptedanswer = true;
for (int i = 0; i < this.acceptedclassescount; i++) {
this.noproposal = false;
this.requestor.accepttype(
this.acceptedclasses[i][0],
this.acceptedclasses[i][1],
this.acceptedclassesmodifiers[i],
false,
null,
this.actualselectionstart,
this.actualselectionend);
}
this.acceptedclasses = null;
this.acceptedclassesmodifiers = null;
this.acceptedclassescount = 0;
}
if(this.acceptedinterfaces != null){
this.acceptedanswer = true;
for (int i = 0; i < this.acceptedinterfacescount; i++) {
this.noproposal = false;
this.requestor.accepttype(
this.acceptedinterfaces[i][0],
this.acceptedinterfaces[i][1],
this.acceptedinterfacesmodifiers[i],
false,
null,
this.actualselectionstart,
this.actualselectionend);
}
this.acceptedinterfaces = null;
this.acceptedinterfacesmodifiers = null;
this.acceptedinterfacescount = 0;
}
if(this.acceptedannotations != null){
this.acceptedanswer = true;
for (int i = 0; i < this.acceptedannotationscount; i++) {
this.noproposal = false;
this.requestor.accepttype(
this.acceptedannotations[i][0],
this.acceptedannotations[i][1],
this.acceptedannotationsmodifiers[i],
false,
null,
this.actualselectionstart,
this.actualselectionend);
}
this.acceptedannotations = null;
this.acceptedannotationsmodifiers = null;
this.acceptedannotationscount = 0;
}
if(this.acceptedenums != null){
this.acceptedanswer = true;
for (int i = 0; i < this.acceptedenumscount; i++) {
this.noproposal = false;
this.requestor.accepttype(
this.acceptedenums[i][0],
this.acceptedenums[i][1],
this.acceptedenumsmodifiers[i],
false,
null,
this.actualselectionstart,
this.actualselectionend);
}
this.acceptedenums = null;
this.acceptedenumsmodifiers = null;
this.acceptedenumscount = 0;
}
}
private boolean checkselection(
char[] source,
int selectionstart,
int selectionend) {

scanner scanner =
new scanner(
false /*comment*/,
false /*whitespace*/,
false /*nls*/,
this.compileroptions.sourcelevel,
this.compileroptions.compliancelevel,
null/*tasktag*/,
null/*taskpriorities*/,
true /*taskcasesensitive*/);
scanner.setsource(source);

int lastidentifierstart = -1;
int lastidentifierend = -1;
char[] lastidentifier = null;
int token;

if(selectionstart > selectionend){
int end = source.length - 1;

// compute start position of current line
int currentposition = selectionstart - 1;
int nextcharacterposition = selectionstart;
char currentcharacter = ' ';
try {
lineloop: while(currentposition > 0){

if(source[currentposition] == '\\' && source[currentposition+1] == 'u') {
int pos = currentposition + 2;
int c1 = 0, c2 = 0, c3 = 0, c4 = 0;
while (source[pos] == 'u') {
pos++;
}

int endofunicode = pos + 3;
if (end < endofunicode) {
if (endofunicode < source.length) {
end = endofunicode;
} else {
return false; // not enough characters to decode an unicode
}
}

if ((c1 = scannerhelper.getnumericvalue(source[pos++])) > 15
|| c1 < 0
|| (c2 = scannerhelper.getnumericvalue(source[pos++])) > 15
|| c2 < 0
|| (c3 = scannerhelper.getnumericvalue(source[pos++])) > 15
|| c3 < 0
|| (c4 = scannerhelper.getnumericvalue(source[pos++])) > 15
|| c4 < 0) {
return false;
} else {
currentcharacter = (char) (((c1 * 16 + c2) * 16 + c3) * 16 + c4);
nextcharacterposition = pos;
}
} else {
currentcharacter = source[currentposition];
nextcharacterposition = currentposition+1;
}

switch(currentcharacter) {
case '\r':
case '\n':
case '/':
case '"':
case '\'':
break lineloop;
}
currentposition--;
}
} catch (arrayindexoutofboundsexception e) {
return false;
}

// compute start and end of the last token
scanner.resetto(nextcharacterposition, end);
isolatelastname: do {
try {
token = scanner.getnexttoken();
} catch (invalidinputexception e) {
return false;
}
switch (token) {
case terminaltokens.tokennamethis:
case terminaltokens.tokennamesuper:
case terminaltokens.tokennameidentifier:
if (scanner.startposition <= selectionstart && selectionstart <= scanner.currentposition) {
if (scanner.currentposition == scanner.eofposition) {
int temp = scanner.eofposition;
scanner.eofposition = scanner.source.length;
while(scanner.getnextcharasjavaidentifierpart()){/*empty*/}
scanner.eofposition = temp;
}
lastidentifierstart = scanner.startposition;
lastidentifierend = scanner.currentposition - 1;
lastidentifier = scanner.getcurrenttokensource();
break isolatelastname;
}
break;
}
} while (token != terminaltokens.tokennameeof);
} else {
scanner.resetto(selectionstart, selectionend);

boolean expectingidentifier = true;
do {
try {
token = scanner.getnexttoken();
} catch (invalidinputexception e) {
return false;
}
switch (token) {
case terminaltokens.tokennamethis :
case terminaltokens.tokennamesuper :
case terminaltokens.tokennameidentifier :
if (!expectingidentifier)
return false;
lastidentifier = scanner.getcurrenttokensource();
lastidentifierstart = scanner.startposition;
lastidentifierend = scanner.currentposition - 1;
if(lastidentifierend > selectionend) {
lastidentifierend = selectionend;
lastidentifier = charoperation.subarray(lastidentifier, 0,lastidentifierend - lastidentifierstart + 1);
}
expectingidentifier = false;
break;
case terminaltokens.tokennamedot :
if (expectingidentifier)
return false;
expectingidentifier = true;
break;
case terminaltokens.tokennameeof :
if (expectingidentifier)
return false;
break;
case terminaltokens.tokennameless :
if(!checktypeargument(scanner))
return false;
break;
case terminaltokens.tokennameat:
if(scanner.startposition != scanner.initialposition)
return false;
break;
default :
return false;
}
} while (token != terminaltokens.tokennameeof);
}
if (lastidentifierstart > 0) {
this.actualselectionstart = lastidentifierstart;
this.actualselectionend = lastidentifierend;
this.selectedidentifier = lastidentifier;
return true;
}
return false;
}
private boolean checktypeargument(scanner scanner) {
int depth = 1;
int token;
stringbuffer buffer = new stringbuffer();
do {
try {
token = scanner.getnexttoken();
} catch (invalidinputexception e) {
return false;
}
switch(token) {
case terminaltokens.tokennameless :
depth++;
buffer.append(scanner.getcurrenttokensource());
break;
case terminaltokens.tokennamegreater :
depth--;
buffer.append(scanner.getcurrenttokensource());
break;
case terminaltokens.tokennameright_shift :
depth-=2;
buffer.append(scanner.getcurrenttokensource());
break;
case terminaltokens.tokennameunsigned_right_shift :
depth-=3;
buffer.append(scanner.getcurrenttokensource());
break;
case terminaltokens.tokennameextends :
case terminaltokens.tokennamesuper :
buffer.append(' ');
buffer.append(scanner.getcurrenttokensource());
buffer.append(' ');
break;
case terminaltokens.tokennamecomma :
if(depth == 1) {
int length = buffer.length();
char[] typeref = new char[length];
buffer.getchars(0, length, typeref, 0);
try {
signature.createtypesignature(typeref, true);
buffer = new stringbuffer();
} catch(illegalargumentexception e) {
return false;
}
}
break;
default :
buffer.append(scanner.getcurrenttokensource());
break;

}
if(depth < 0) {
return false;
}
} while (depth != 0 && token != terminaltokens.tokennameeof);

if(depth == 0) {
int length = buffer.length() - 1;
char[] typeref = new char[length];
buffer.getchars(0, length, typeref, 0);
try {
signature.createtypesignature(typeref, true);
return true;
} catch(illegalargumentexception e) {
return false;
}
}

return false;
}

/*
* find all types outside the project scope
*/
private void findalltypes(char[] prefix) {
try {
iprogressmonitor progressmonitor = new iprogressmonitor() {
boolean iscanceled = false;
public void begintask(string name, int totalwork) {
// implements interface method
}
public void done() {
// implements interface method
}
public void internalworked(double work) {
// implements interface method
}
public boolean iscanceled() {
return this.iscanceled;
}
public void setcanceled(boolean value) {
this.iscanceled = value;
}
public void settaskname(string name) {
// implements interface method
}
public void subtask(string name) {
// implements interface method
}
public void worked(int work) {
// implements interface method
}
};

typenamematchrequestor typenamematchrequestor = new typenamematchrequestor() {
public void accepttypenamematch(typenamematch match) {
if (selectionengine.this.requestor instanceof selectionrequestor) {
selectionengine.this.noproposal = false;
((selectionrequestor)selectionengine.this.requestor).accepttype(match.gettype());
}
}
};

ijavasearchscope scope = basicsearchengine.createworkspacescope();

selectiontypenamematchrequestorwrapper requestorwrapper =
new selectiontypenamematchrequestorwrapper(
typenamematchrequestor,
scope,
this.unitscope == null ? null : this.unitscope.referencecontext.imports);

org.eclipse.jdt.core.icompilationunit[] workingcopies = this.owner == null ? null : javamodelmanager.getjavamodelmanager().getworkingcopies(this.owner, true/*add primary wcs*/);

try {
new basicsearchengine(workingcopies).searchalltypenames(
null,
searchpattern.r_exact_match,
prefix,
searchpattern.r_exact_match | searchpattern.r_case_sensitive,
ijavasearchconstants.type,
scope,
requestorwrapper,
ijavasearchconstants.cancel_if_not_ready_to_search,
progressmonitor);
} catch (operationcanceledexception e) {
// do nothing
}
requestorwrapper.acceptnotimported();
} catch (javamodelexception e) {
// do nothing
}
}

public assistparser getparser() {
return this.parser;
}

/*
* returns whether the given binding is a local/anonymous reference binding, or if its declaring class is
* local.
*/
private boolean islocal(referencebinding binding) {
if(binding instanceof parameterizedtypebinding) {
return islocal(((parameterizedtypebinding)binding).generictype());
}
if (!(binding instanceof sourcetypebinding)) return false;
if (binding instanceof localtypebinding) return true;
if (binding instanceof membertypebinding) {
return islocal(((membertypebinding)binding).enclosingtype);
}
return false;
}

/**
* ask the engine to compute the selection at the specified position
* of the given compilation unit.

*  @@param sourceunit org.eclipse.jdt.internal.compiler.env.icompilationunit
*      the source of the current compilation unit.
*
*  @@param selectionsourcestart int
*  @@param selectionsourceend int
*      a range in the source where the selection is.
*/
public void select(
icompilationunit sourceunit,
int selectionsourcestart,
int selectionsourceend) {

char[] source = sourceunit.getcontents();

if(debug) {
system.out.print("selection in "); //$non-nls-1$
system.out.print(sourceunit.getfilename());
system.out.print(" from "); //$non-nls-1$
system.out.print(selectionsourcestart);
system.out.print(" to "); //$non-nls-1$
system.out.println(selectionsourceend);
system.out.println("selection - source :"); //$non-nls-1$
system.out.println(source);
}
if (!checkselection(source, selectionsourcestart, selectionsourceend)) {
return;
}
if (debug) {
system.out.print("selection - checked : \""); //$non-nls-1$
system.out.print(new string(source, this.actualselectionstart, this.actualselectionend-this.actualselectionstart+1));
system.out.println('"');
}
try {
this.acceptedanswer = false;
compilationresult result = new compilationresult(sourceunit, 1, 1, this.compileroptions.maxproblemsperunit);
compilationunitdeclaration parsedunit =
this.parser.dietparse(sourceunit, result, this.actualselectionstart, this.actualselectionend);

if (parsedunit != null) {
if(debug) {
system.out.println("selection - diet ast :"); //$non-nls-1$
system.out.println(parsedunit.tostring());
}

// scan the package & import statements first
if (parsedunit.currentpackage instanceof selectiononpackagereference) {
char[][] tokens =
((selectiononpackagereference) parsedunit.currentpackage).tokens;
this.noproposal = false;
this.requestor.acceptpackage(charoperation.concatwith(tokens, '.'));
return;
}
importreference[] imports = parsedunit.imports;
if (imports != null) {
for (int i = 0, length = imports.length; i < length; i++) {
importreference importreference = imports[i];
if (importreference instanceof selectiononimportreference) {
char[][] tokens = ((selectiononimportreference) importreference).tokens;
this.noproposal = false;
this.requestor.acceptpackage(charoperation.concatwith(tokens, '.'));
this.nameenvironment.findtypes(charoperation.concatwith(tokens, '.'), false, false, ijavasearchconstants.type, this);

this.lookupenvironment.buildtypebindings(parsedunit, null /*no access restriction*/);
if ((this.unitscope = parsedunit.scope) != null) {
int tokencount = tokens.length;
char[] lasttoken = tokens[tokencount - 1];
char[][] qualifiertokens = charoperation.subarray(tokens, 0, tokencount - 1);

if(qualifiertokens != null && qualifiertokens.length > 0) {
binding binding = this.unitscope.gettypeorpackage(qualifiertokens);
if(binding != null && binding instanceof referencebinding) {
referencebinding ref = (referencebinding) binding;
selectmembertypefromimport(parsedunit, lasttoken, ref, importreference.isstatic());
if(importreference.isstatic()) {
selectstaticfieldfromstaticimport(parsedunit, lasttoken, ref);
selectstaticmethodfromstaticimport(parsedunit, lasttoken, ref);
}
}
}
}

// accept qualified types only if no unqualified type was accepted
if(!this.acceptedanswer) {
acceptqualifiedtypes();
if (!this.acceptedanswer) {
this.nameenvironment.findtypes(this.selectedidentifier, false, false, ijavasearchconstants.type, this);
// try with simple type name
if(!this.acceptedanswer) {
acceptqualifiedtypes();
}
}
}
if(this.noproposal && this.problem != null) {
this.requestor.accepterror(this.problem);
}
return;
}
}
}
if (parsedunit.types != null || parsedunit.ispackageinfo()) {
if(selectdeclaration(parsedunit))
return;
this.lookupenvironment.buildtypebindings(parsedunit, null /*no access restriction*/);
if ((this.unitscope = parsedunit.scope)  != null) {
try {
this.lookupenvironment.completetypebindings(parsedunit, true);

compilationunitdeclaration previousunitbeingcompleted = this.lookupenvironment.unitbeingcompleted;
this.lookupenvironment.unitbeingcompleted = parsedunit;
parsedunit.scope.faultintypes();
this.lookupenvironment.unitbeingcompleted = previousunitbeingcompleted;
astnode node = null;
if (parsedunit.types != null)
node = parseblockstatements(parsedunit, selectionsourcestart);
if(debug) {
system.out.println("selection - ast :"); //$non-nls-1$
system.out.println(parsedunit.tostring());
}
parsedunit.resolve();
if (node != null) {
selectlocaldeclaration(node);
}
} catch (selectionnodefound e) {
if (e.binding != null) {
if(debug) {
system.out.println("selection - selection binding:"); //$non-nls-1$
system.out.println(e.binding.tostring());
}
// if null then we found a problem in the selection node
selectfrom(e.binding, parsedunit, e.isdeclaration);
}
}
}
}
}
// only reaches here if no selection could be derived from the parsed tree
// thus use the selected source and perform a textual type search
if (!this.acceptedanswer) {
this.nameenvironment.findtypes(this.selectedidentifier, false, false, ijavasearchconstants.type, this);

// accept qualified types only if no unqualified type was accepted
if(!this.acceptedanswer) {
acceptqualifiedtypes();

// accept types from all the workspace only if no type was found in the project scope
if (this.noproposal) {
findalltypes(this.selectedidentifier);
}
}
}
if(this.noproposal && this.problem != null) {
this.requestor.accepterror(this.problem);
}
} catch (indexoutofboundsexception e) { // work-around internal failure - 1gemf6d
if(debug) {
system.out.println("exception caught by selectionengine:"); //$non-nls-1$
e.printstacktrace(system.out);
}
} catch (abortcompilation e) { // ignore this exception for now since it typically means we cannot find java.lang.object
if(debug) {
system.out.println("exception caught by selectionengine:"); //$non-nls-1$
e.printstacktrace(system.out);
}
} finally {
reset(true);
}
}

private void selectmembertypefromimport(compilationunitdeclaration parsedunit, char[] lasttoken, referencebinding ref, boolean staticonly) {
int fieldlength = lasttoken.length;
referencebinding[] membertypes = ref.membertypes();
next : for (int j = 0; j < membertypes.length; j++) {
referencebinding membertype = membertypes[j];

if (fieldlength > membertype.sourcename.length)
continue next;

if (staticonly && !membertype.isstatic())
continue next;

if (!charoperation.equals(lasttoken, membertype.sourcename, true))
continue next;

selectfrom(membertype, parsedunit, false);
}
}

private void selectstaticfieldfromstaticimport(compilationunitdeclaration parsedunit, char[] lasttoken, referencebinding ref) {
int fieldlength = lasttoken.length;
fieldbinding[] fields = ref.availablefields();
next : for (int j = 0; j < fields.length; j++) {
fieldbinding field = fields[j];

if (fieldlength > field.name.length)
continue next;

if (field.issynthetic())
continue next;

if (!field.isstatic())
continue next;

if (!charoperation.equals(lasttoken, field.name, true))
continue next;

selectfrom(field, parsedunit, false);
}
}

private void selectstaticmethodfromstaticimport(compilationunitdeclaration parsedunit, char[] lasttoken, referencebinding ref) {
int methodlength = lasttoken.length;
methodbinding[] methods = ref.availablemethods();
next : for (int j = 0; j < methods.length; j++) {
methodbinding method = methods[j];

if (method.issynthetic()) continue next;

if (method.isdefaultabstract())	continue next;

if (method.isconstructor()) continue next;

if (!method.isstatic()) continue next;

if (methodlength > method.selector.length)
continue next;

if (!charoperation.equals(lasttoken, method.selector, true))
continue next;

selectfrom(method, parsedunit, false);
}
}

private void selectfrom(binding binding, compilationunitdeclaration parsedunit, boolean isdeclaration) {
if(binding instanceof typevariablebinding) {
typevariablebinding typevariablebinding = (typevariablebinding) binding;
binding enclosingelement = typevariablebinding.declaringelement;
this.noproposal = false;

if(enclosingelement instanceof sourcetypebinding) {
sourcetypebinding enclosingtype = (sourcetypebinding) enclosingelement;
if (islocal(enclosingtype) && this.requestor instanceof selectionrequestor) {
((selectionrequestor)this.requestor).acceptlocaltypeparameter(typevariablebinding);
} else {
this.requestor.accepttypeparameter(
enclosingtype.qualifiedpackagename(),
enclosingtype.qualifiedsourcename(),
typevariablebinding.sourcename(),
false,
this.actualselectionstart,
this.actualselectionend);
}
} else if(enclosingelement instanceof methodbinding) {
methodbinding enclosingmethod = (methodbinding) enclosingelement;
if (islocal(enclosingmethod.declaringclass) && this.requestor instanceof selectionrequestor) {
((selectionrequestor)this.requestor).acceptlocalmethodtypeparameter(typevariablebinding);
} else {
this.requestor.acceptmethodtypeparameter(
enclosingmethod.declaringclass.qualifiedpackagename(),
enclosingmethod.declaringclass.qualifiedsourcename(),
enclosingmethod.isconstructor()
? enclosingmethod.declaringclass.sourcename()
: enclosingmethod.selector,
enclosingmethod.sourcestart(),
enclosingmethod.sourceend(),
typevariablebinding.sourcename(),
false,
this.actualselectionstart,
this.actualselectionend);
}
}
this.acceptedanswer = true;
} else if (binding instanceof referencebinding) {
referencebinding typebinding = (referencebinding) binding;
if(typebinding instanceof problemreferencebinding) {
typebinding closestmatch = typebinding.closestmatch();
if (closestmatch instanceof referencebinding) {
typebinding = (referencebinding) closestmatch;
} else {
typebinding = null;
}
}
if (typebinding == null) return;
if (islocal(typebinding) && this.requestor instanceof selectionrequestor) {
this.noproposal = false;
((selectionrequestor)this.requestor).acceptlocaltype(typebinding);
} else {
this.noproposal = false;

this.requestor.accepttype(
typebinding.qualifiedpackagename(),
typebinding.qualifiedsourcename(),
typebinding.modifiers,
false,
typebinding.computeuniquekey(),
this.actualselectionstart,
this.actualselectionend);
}
this.acceptedanswer = true;
} else if (binding instanceof methodbinding) {
methodbinding methodbinding = (methodbinding) binding;
this.noproposal = false;

boolean isvaluesorvalueof = false;
if(binding instanceof syntheticmethodbinding) {
syntheticmethodbinding syntheticmethodbinding = (syntheticmethodbinding) binding;
if(syntheticmethodbinding.purpose  == syntheticmethodbinding.enumvalues
|| syntheticmethodbinding.purpose  == syntheticmethodbinding.enumvalueof) {
isvaluesorvalueof =  true;
}
}

if(!isvaluesorvalueof && !methodbinding.issynthetic()) {
typebinding[] parametertypes = methodbinding.original().parameters;
int length = parametertypes.length;
char[][] parameterpackagenames = new char[length][];
char[][] parametertypenames = new char[length][];
string[] parametersignatures = new string[length];
for (int i = 0; i < length; i++) {
parameterpackagenames[i] = parametertypes[i].qualifiedpackagename();
parametertypenames[i] = parametertypes[i].qualifiedsourcename();
parametersignatures[i] = new string(getsignature(parametertypes[i])).replace('/', '.');
}

typevariablebinding[] typevariables = methodbinding.original().typevariables;
length = typevariables == null ? 0 : typevariables.length;
char[][] typeparameternames = new char[length][];
char[][][] typeparameterboundnames = new char[length][][];
for (int i = 0; i < length; i++) {
typevariablebinding typevariable = typevariables[i];
typeparameternames[i] = typevariable.sourcename;
if (typevariable.firstbound == null) {
typeparameterboundnames[i] = new char[0][];
} else if (typevariable.firstbound == typevariable.superclass) {
int boundcount = 1 + (typevariable.superinterfaces == null ? 0 : typevariable.superinterfaces.length);
typeparameterboundnames[i] = new char[boundcount][];
typeparameterboundnames[i][0] = typevariable.superclass.sourcename;
for (int j = 1; j < boundcount; j++) {
typeparameterboundnames[i][j] = typevariables[i].superinterfaces[j - 1].sourcename;
}
} else {
int boundcount = typevariable.superinterfaces == null ? 0 : typevariable.superinterfaces.length;
typeparameterboundnames[i] = new char[boundcount][];
for (int j = 0; j < boundcount; j++) {
typeparameterboundnames[i][j] = typevariables[i].superinterfaces[j].sourcename;
}
}
}

referencebinding declaringclass = methodbinding.declaringclass;
if (islocal(declaringclass) && this.requestor instanceof selectionrequestor) {
((selectionrequestor)this.requestor).acceptlocalmethod(methodbinding);
} else {
this.requestor.acceptmethod(
declaringclass.qualifiedpackagename(),
declaringclass.qualifiedsourcename(),
declaringclass.enclosingtype() == null ? null : new string(getsignature(declaringclass.enclosingtype())),
methodbinding.isconstructor()
? declaringclass.sourcename()
: methodbinding.selector,
parameterpackagenames,
parametertypenames,
parametersignatures,
typeparameternames,
typeparameterboundnames,
methodbinding.isconstructor(),
isdeclaration,
methodbinding.computeuniquekey(),
this.actualselectionstart,
this.actualselectionend);
}
}
this.acceptedanswer = true;
} else if (binding instanceof fieldbinding) {
fieldbinding fieldbinding = (fieldbinding) binding;
referencebinding declaringclass = fieldbinding.declaringclass;
if (declaringclass != null) { // arraylength
this.noproposal = false;
if (islocal(declaringclass) && this.requestor instanceof selectionrequestor) {
((selectionrequestor)this.requestor).acceptlocalfield(fieldbinding);
} else {
// if the binding is a problem field binding, we want to make sure
// we can retrieve the closestmatch if the problem reason is notvisible
fieldbinding currentfieldbinding = fieldbinding;
while (currentfieldbinding instanceof problemfieldbinding) {
problemfieldbinding problemfieldbinding = (problemfieldbinding) currentfieldbinding;
if (problemfieldbinding.problemid() == problemreasons.notvisible) {
currentfieldbinding = problemfieldbinding.closestmatch;
} else {
currentfieldbinding = null;
}
}
char[] fieldname = null;
char[] key = null;
if (currentfieldbinding != null) {
fieldname = currentfieldbinding.name;
key = currentfieldbinding.computeuniquekey();
} else {
fieldname = fieldbinding.name;
key = fieldbinding.computeuniquekey();
}
this.requestor.acceptfield(
declaringclass.qualifiedpackagename(),
declaringclass.qualifiedsourcename(),
fieldname,
false,
key,
this.actualselectionstart,
this.actualselectionend);
}
this.acceptedanswer = true;
}
} else if (binding instanceof localvariablebinding) {
if (this.requestor instanceof selectionrequestor) {
((selectionrequestor)this.requestor).acceptlocalvariable((localvariablebinding)binding);
this.acceptedanswer = true;
} else {
// open on the type of the variable
selectfrom(((localvariablebinding) binding).type, parsedunit, false);
}
} else if (binding instanceof arraybinding) {
selectfrom(((arraybinding) binding).leafcomponenttype, parsedunit, false);
// open on the type of the array
} else if (binding instanceof packagebinding) {
packagebinding packagebinding = (packagebinding) binding;
this.noproposal = false;
this.requestor.acceptpackage(packagebinding.readablename());
this.acceptedanswer = true;
} else if(binding instanceof basetypebinding) {
this.acceptedanswer = true;
}
}
/*
* checks if a local declaration got selected in this method/initializer/field.
*/
private void selectlocaldeclaration(astnode node) {
// the selected identifier is not identical to the parser one (equals but not identical),
// for traversing the parse tree, the parser assist identifier is necessary for identitiy checks
final char[] assistidentifier = getparser().assistidentifier();
if (assistidentifier == null) return;

class visitor extends astvisitor {
public boolean visit(constructordeclaration constructordeclaration, classscope scope) {
if (constructordeclaration.selector == assistidentifier){
if (constructordeclaration.binding != null) {
throw new selectionnodefound(constructordeclaration.binding);
} else {
if (constructordeclaration.scope != null) {
throw new selectionnodefound(new methodbinding(constructordeclaration.modifiers, constructordeclaration.selector, null, null, null, constructordeclaration.scope.referencetype().binding));
}
}
}
return true;
}
public boolean visit(fielddeclaration fielddeclaration, methodscope scope) {
if (fielddeclaration.name == assistidentifier){
throw new selectionnodefound(fielddeclaration.binding);
}
return true;
}
public boolean visit(typedeclaration localtypedeclaration, blockscope scope) {
if (localtypedeclaration.name == assistidentifier) {
throw new selectionnodefound(localtypedeclaration.binding);
}
return true;
}
public boolean visit(typedeclaration membertypedeclaration, classscope scope) {
if (membertypedeclaration.name == assistidentifier) {
throw new selectionnodefound(membertypedeclaration.binding);
}
return true;
}
public boolean visit(methoddeclaration methoddeclaration, classscope scope) {
if (methoddeclaration.selector == assistidentifier){
if (methoddeclaration.binding != null) {
throw new selectionnodefound(methoddeclaration.binding);
} else {
if (methoddeclaration.scope != null) {
throw new selectionnodefound(new methodbinding(methoddeclaration.modifiers, methoddeclaration.selector, null, null, null, methoddeclaration.scope.referencetype().binding));
}
}
}
return true;
}
public boolean visit(typedeclaration typedeclaration, compilationunitscope scope) {
if (typedeclaration.name == assistidentifier) {
throw new selectionnodefound(typedeclaration.binding);
}
return true;
}
public boolean visit(typeparameter typeparameter, blockscope scope) {
if (typeparameter.name == assistidentifier) {
throw new selectionnodefound(typeparameter.binding);
}
return true;
}
public boolean visit(typeparameter typeparameter, classscope scope) {
if (typeparameter.name == assistidentifier) {
throw new selectionnodefound(typeparameter.binding);
}
return true;
}
}

if (node instanceof abstractmethoddeclaration) {
((abstractmethoddeclaration)node).traverse(new visitor(), (classscope)null);
} else {
((fielddeclaration)node).traverse(new visitor(), (methodscope)null);
}
}

/**
* asks the engine to compute the selection of the given type
* from the given context
*
*  @@param typename char[]
*      a type name which is to be resolved in the context of a compilation unit.
*		note: the type name is supposed to be correctly reduced (no whitespaces, no unicodes left)
*
*  @@param context org.eclipse.jdt.core.itype
*      the context in which code assist is invoked.
*/
public void selecttype(char[] typename, itype context) throws javamodelexception {
try {
this.acceptedanswer = false;

// only the type erasure are returned by itype.resolvedtype(...)
if (charoperation.indexof('<', typename) != -1) {
char[] typesig = signature.createchararraytypesignature(typename, false/*not resolved*/);
typesig = signature.gettypeerasure(typesig);
typename = signature.tochararray(typesig);
}

// find the outer most type
itype outertype = context;
itype parent = context.getdeclaringtype();
while (parent != null) {
outertype = parent;
parent = parent.getdeclaringtype();
}

// compute parse tree for this most outer type
compilationunitdeclaration parsedunit = null;
typedeclaration typedeclaration = null;
org.eclipse.jdt.core.icompilationunit cu = context.getcompilationunit();
if (cu != null) {
itype[] topleveltypes = cu.gettypes();
int length = topleveltypes.length;
sourcetypeelementinfo[] toplevelinfos = new sourcetypeelementinfo[length];
for (int i = 0; i < length; i++) {
toplevelinfos[i] = (sourcetypeelementinfo) ((sourcetype)topleveltypes[i]).getelementinfo();
}
isourcetype outertypeinfo = (isourcetype) ((sourcetype) outertype).getelementinfo();
compilationresult result = new compilationresult(outertypeinfo.getfilename(), 1, 1, this.compileroptions.maxproblemsperunit);
int flags = sourcetypeconverter.field_and_method | sourcetypeconverter.member_type;
if (context.isanonymous() || context.islocal())
flags |= sourcetypeconverter.local_type;
parsedunit =
sourcetypeconverter.buildcompilationunit(
toplevelinfos,
flags,
this.parser.problemreporter(),
result);
if (parsedunit != null && parsedunit.types != null) {
if(debug) {
system.out.println("selection - diet ast :"); //$non-nls-1$
system.out.println(parsedunit.tostring());
}
// find the type declaration that corresponds to the original source type
typedeclaration = new astnodefinder(parsedunit).findtype(context);
}
} else { // binary type
classfile classfile = (classfile) context.getclassfile();
classfilereader reader = (classfilereader) classfile.getbinarytypeinfo((ifile) classfile.resource(), false/*don't fully initialize so as to keep constant pool (used below)*/);
compilationresult result = new compilationresult(reader.getfilename(), 1, 1, this.compileroptions.maxproblemsperunit);
parsedunit = new compilationunitdeclaration(this.parser.problemreporter(), result, 0);
hashsetofchararrayarray typenames = new hashsetofchararrayarray();

binarytypeconverter converter = new binarytypeconverter(this.parser.problemreporter(), result, typenames);
typedeclaration = converter.buildtypedeclaration(context, parsedunit);
parsedunit.imports = converter.buildimports(reader);
}

if (typedeclaration != null) {

// add fake field with the type we're looking for
// note: since we didn't ask for fields above, there is no field defined yet
fielddeclaration field = new fielddeclaration();
int dot;
if ((dot = charoperation.lastindexof('.', typename)) == -1) {
this.selectedidentifier = typename;
field.type = new selectiononsingletypereference(typename, -1);
// position not used
} else {
char[][] previousidentifiers = charoperation.spliton('.', typename, 0, dot);
char[] selectionidentifier =
charoperation.subarray(typename, dot + 1, typename.length);
this.selectedidentifier = selectionidentifier;
field.type =
new selectiononqualifiedtypereference(
previousidentifiers,
selectionidentifier,
new long[previousidentifiers.length + 1]);
}
field.name = "<fakefield>".tochararray(); //$non-nls-1$
typedeclaration.fields = new fielddeclaration[] { field };

// build bindings
this.lookupenvironment.buildtypebindings(parsedunit, null /*no access restriction*/);
if ((this.unitscope = parsedunit.scope) != null) {
try {
// build fields
// note: this builds fields only in the parsed unit (the buildfieldsandmethods flag is not passed along)
this.lookupenvironment.completetypebindings(parsedunit, true);

// resolve
parsedunit.scope.faultintypes();
parsedunit.resolve();
} catch (selectionnodefound e) {
if (e.binding != null) {
if(debug) {
system.out.println("selection - selection binding :"); //$non-nls-1$
system.out.println(e.binding.tostring());
}
// if null then we found a problem in the selection node
selectfrom(e.binding, parsedunit, e.isdeclaration);
}
}
}
}
if(this.noproposal && this.problem != null) {
this.requestor.accepterror(this.problem);
}
} catch (abortcompilation e) { // ignore this exception for now since it typically means we cannot find java.lang.object
} finally {
reset(true);
}
}

// check if a declaration got selected in this unit
private boolean selectdeclaration(compilationunitdeclaration compilationunit){

// the selected identifier is not identical to the parser one (equals but not identical),
// for traversing the parse tree, the parser assist identifier is necessary for identitiy checks
char[] assistidentifier = getparser().assistidentifier();
if (assistidentifier == null) return false;

importreference currentpackage = compilationunit.currentpackage;
char[] packagename = currentpackage == null ? charoperation.no_char : charoperation.concatwith(currentpackage.tokens, '.');
// iterate over the types
typedeclaration[] types = compilationunit.types;
for (int i = 0, length = types == null ? 0 : types.length; i < length; i++){
if(selectdeclaration(types[i], assistidentifier, packagename))
return true;
}
return false;
}

// check if a declaration got selected in this type
private boolean selectdeclaration(typedeclaration typedeclaration, char[] assistidentifier, char[] packagename){

if (typedeclaration.name == assistidentifier){
char[] qualifiedsourcename = null;

typedeclaration enclosingtype = typedeclaration;
while(enclosingtype != null) {
qualifiedsourcename = charoperation.concat(enclosingtype.name, qualifiedsourcename, '.');
enclosingtype = enclosingtype.enclosingtype;
}
char[] uniquekey = typedeclaration.binding != null ? typedeclaration.binding.computeuniquekey() : null;

this.requestor.accepttype(
packagename,
qualifiedsourcename,
typedeclaration.modifiers,
true,
uniquekey,
this.actualselectionstart,
this.actualselectionend);

this.noproposal = false;
return true;
}
typedeclaration[] membertypes = typedeclaration.membertypes;
for (int i = 0, length = membertypes == null ? 0 : membertypes.length; i < length; i++){
if(selectdeclaration(membertypes[i], assistidentifier, packagename))
return true;
}
fielddeclaration[] fields = typedeclaration.fields;
for (int i = 0, length = fields == null ? 0 : fields.length; i < length; i++){
if (fields[i].name == assistidentifier){
char[] qualifiedsourcename = null;

typedeclaration enclosingtype = typedeclaration;
while(enclosingtype != null) {
qualifiedsourcename = charoperation.concat(enclosingtype.name, qualifiedsourcename, '.');
enclosingtype = enclosingtype.enclosingtype;
}
fielddeclaration field = fields[i];
this.requestor.acceptfield(
packagename,
qualifiedsourcename,
field.name,
true,
field.binding != null ? field.binding.computeuniquekey() : null,
this.actualselectionstart,
this.actualselectionend);

this.noproposal = false;
return true;
}
}
abstractmethoddeclaration[] methods = typedeclaration.methods;
for (int i = 0, length = methods == null ? 0 : methods.length; i < length; i++){
abstractmethoddeclaration method = methods[i];

if (method.selector == assistidentifier){
char[] qualifiedsourcename = null;

typedeclaration enclosingtype = typedeclaration;
while(enclosingtype != null) {
qualifiedsourcename = charoperation.concat(enclosingtype.name, qualifiedsourcename, '.');
enclosingtype = enclosingtype.enclosingtype;
}

this.requestor.acceptmethod(
packagename,
qualifiedsourcename,
null, // selectionrequestor does not need of declaring type signature for method declaration
method.selector,
null, // selectionrequestor does not need of parameters type for method declaration
null, // selectionrequestor does not need of parameters type for method declaration
null, // selectionrequestor does not need of parameters type for method declaration
null, // selectionrequestor does not need of type parameters name for method declaration
null, // selectionrequestor does not need of type parameters bounds for method declaration
method.isconstructor(),
true,
method.binding != null ? method.binding.computeuniquekey() : null,
this.actualselectionstart,
this.actualselectionend);

this.noproposal = false;
return true;
}

typeparameter[] methodtypeparameters = method.typeparameters();
for (int j = 0, length2 = methodtypeparameters == null ? 0 : methodtypeparameters.length; j < length2; j++){
typeparameter methodtypeparameter = methodtypeparameters[j];

if(methodtypeparameter.name == assistidentifier) {
char[] qualifiedsourcename = null;

typedeclaration enclosingtype = typedeclaration;
while(enclosingtype != null) {
qualifiedsourcename = charoperation.concat(enclosingtype.name, qualifiedsourcename, '.');
enclosingtype = enclosingtype.enclosingtype;
}

this.requestor.acceptmethodtypeparameter(
packagename,
qualifiedsourcename,
method.selector,
method.sourcestart,
method.sourceend,
methodtypeparameter.name,
true,
this.actualselectionstart,
this.actualselectionend);

this.noproposal = false;
return true;
}
}
}

typeparameter[] typeparameters = typedeclaration.typeparameters;
for (int i = 0, length = typeparameters == null ? 0 : typeparameters.length; i < length; i++){
typeparameter typeparameter = typeparameters[i];
if(typeparameter.name == assistidentifier) {
char[] qualifiedsourcename = null;

typedeclaration enclosingtype = typedeclaration;
while(enclosingtype != null) {
qualifiedsourcename = charoperation.concat(enclosingtype.name, qualifiedsourcename, '.');
enclosingtype = enclosingtype.enclosingtype;
}

this.requestor.accepttypeparameter(
packagename,
qualifiedsourcename,
typeparameter.name,
true,
this.actualselectionstart,
this.actualselectionend);

this.noproposal = false;
return true;
}
}

return false;
}
}
