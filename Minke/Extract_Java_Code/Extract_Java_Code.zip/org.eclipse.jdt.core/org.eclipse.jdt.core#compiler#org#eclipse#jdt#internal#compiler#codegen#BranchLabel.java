/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

import java.util.arrays;

import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;

public class branchlabel extends label {

private int[] forwardreferences = new int[10]; // add an overflow check here.
private int forwardreferencecount = 0;
branchlabel delegate; //

// label tagbits
public int tagbits;
public final static int wide = 1;
public final static int used = 2;

public branchlabel() {
// for creating labels ahead of code generation
}

/**
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public branchlabel(codestream codestream) {
super(codestream);
}

/**
* add a forward refrence for the array.
*/
void addforwardreference(int pos) {
if (this.delegate != null) {
this.delegate.addforwardreference(pos);
return;
}
final int count = this.forwardreferencecount;
if (count >= 1) {
int previousvalue = this.forwardreferences[count - 1];
if (previousvalue < pos) {
int length;
if (count >= (length = this.forwardreferences.length))
system.arraycopy(this.forwardreferences, 0, (this.forwardreferences = new int[2*length]), 0, length);
this.forwardreferences[this.forwardreferencecount++] = pos;
} else if (previousvalue > pos) {
int[] refs = this.forwardreferences;
// check for duplicates
for (int i = 0, max = this.forwardreferencecount; i < max; i++) {
if (refs[i] == pos) return; // already recorded
}
int length;
if (count >= (length = refs.length))
system.arraycopy(refs, 0, (this.forwardreferences = new int[2*length]), 0, length);
this.forwardreferences[this.forwardreferencecount++] = pos;
arrays.sort(this.forwardreferences, 0, this.forwardreferencecount);
}
} else {
int length;
if (count >= (length = this.forwardreferences.length))
system.arraycopy(this.forwardreferences, 0, (this.forwardreferences = new int[2*length]), 0, length);
this.forwardreferences[this.forwardreferencecount++] = pos;
}
}

/**
* makes the current label inline all references to the other label
*/
public void becomedelegatefor(branchlabel otherlabel) {
// other label is delegating to receiver from now on
otherlabel.delegate = this;

// all existing forward refs to other label are inlined into current label
final int othercount = otherlabel.forwardreferencecount;
if (othercount == 0) return;
// need to merge the two sorted arrays of forward references
int[] mergedforwardreferences = new int[this.forwardreferencecount + othercount];
int indexinmerge = 0;
int j = 0;
int i = 0;
int max = this.forwardreferencecount;
int max2 = otherlabel.forwardreferencecount;
loop1 : for (; i < max; i++) {
final int value1 = this.forwardreferences[i];
for (; j < max2; j++) {
final int value2 = otherlabel.forwardreferences[j];
if (value1 < value2) {
mergedforwardreferences[indexinmerge++] = value1;
continue loop1;
} else if (value1 == value2) {
mergedforwardreferences[indexinmerge++] = value1;
j++;
continue loop1;
} else {
mergedforwardreferences[indexinmerge++] = value2;
}
}
mergedforwardreferences[indexinmerge++] = value1;
}
for (; j < max2; j++) {
mergedforwardreferences[indexinmerge++] = otherlabel.forwardreferences[j];
}
this.forwardreferences = mergedforwardreferences;
this.forwardreferencecount = indexinmerge;
}

/*
* put down  a reference to the array at the location in the codestream.
*/
void branch() {
this.tagbits |= branchlabel.used;
if (this.delegate != null) {
this.delegate.branch();
return;
}
if (this.position == label.pos_not_set) {
addforwardreference(this.codestream.position);
// leave two bytes free to generate the jump afterwards
this.codestream.position += 2;
this.codestream.classfileoffset += 2;
} else {
/*
* position is set. write it if it is not a wide branch.
*/
this.codestream.writeposition(this);
}
}

/*
* no support for wide branches yet
*/
void branchwide() {
this.tagbits |= branchlabel.used;
if (this.delegate != null) {
this.delegate.branchwide();
return;
}
if (this.position == label.pos_not_set) {
addforwardreference(this.codestream.position);
// leave 4 bytes free to generate the jump offset afterwards
this.tagbits |= branchlabel.wide;
this.codestream.position += 4;
this.codestream.classfileoffset += 4;
} else { //position is set. write it!
this.codestream.writewideposition(this);
}
}

public int forwardreferencecount() {
if (this.delegate != null) this.delegate.forwardreferencecount();
return this.forwardreferencecount;
}
public int[] forwardreferences() {
if (this.delegate != null) this.delegate.forwardreferences();
return this.forwardreferences;
}
public void initialize(codestream stream) {
this.codestream = stream;
this.position = label.pos_not_set;
this.forwardreferencecount = 0;
this.delegate = null;
}
public boolean iscaselabel() {
return false;
}
public boolean isstandardlabel(){
return true;
}

/*
* place the label. if we have forward references resolve them.
*/
public void place() { // currently lacking wide support.
//	if ((this.tagbits & used) == 0 && this.forwardreferencecount == 0) {
//		return;
//	}

//todo how can position be set already ? cannot place more than once
if (this.position == label.pos_not_set) {
this.position = this.codestream.position;
this.codestream.addlabel(this);
int oldposition = this.position;
boolean isoptimizedbranch = false;
if (this.forwardreferencecount != 0) {
isoptimizedbranch = (this.forwardreferences[this.forwardreferencecount - 1] + 2 == this.position) && (this.codestream.bcodestream[this.codestream.classfileoffset - 3] == opcodes.opc_goto);
if (isoptimizedbranch) {
if (this.codestream.lastabruptcompletion == this.position) {
this.codestream.lastabruptcompletion = -1;
}
this.codestream.position = (this.position -= 3);
this.codestream.classfileoffset -= 3;
this.forwardreferencecount--;
if (this.codestream.lastentrypc == oldposition) {
this.codestream.lastentrypc = this.position;
}
// end of new code
if ((this.codestream.generateattributes & (classfileconstants.attr_vars | classfileconstants.attr_stack_map_table | classfileconstants.attr_stack_map)) != 0) {
localvariablebinding locals[] = this.codestream.locals;
for (int i = 0, max = locals.length; i < max; i++) {
localvariablebinding local = locals[i];
if ((local != null) && (local.initializationcount > 0)) {
if (local.initializationpcs[((local.initializationcount - 1) << 1) + 1] == oldposition) {
// we want to prevent interval of size 0 to have a negative size.
// see pr 1girqla: itpjcore:all - classformaterror for local variable attribute
local.initializationpcs[((local.initializationcount - 1) << 1) + 1] = this.position;
}
if (local.initializationpcs[(local.initializationcount - 1) << 1] == oldposition) {
local.initializationpcs[(local.initializationcount - 1) << 1] = this.position;
}
}
}
}
if ((this.codestream.generateattributes & classfileconstants.attr_lines) != 0) {
// we need to remove all entries that is beyond this.position inside the pctosourcermap table
this.codestream.removeunusedpctosourcemapentries();
}
}
}
for (int i = 0; i < this.forwardreferencecount; i++) {
this.codestream.writeposition(this, this.forwardreferences[i]);
}
// for all labels placed at that position we check if we need to rewrite the jump
// offset. it is the case each time a label had a forward reference to the current position.
// like we change the current position, we have to change the jump offset. see 1f4ird9 for more details.
if (isoptimizedbranch) {
this.codestream.optimizebranch(oldposition, this);
}
}
}

/**
* print out the receiver
*/
public string tostring() {
string basic = getclass().getname();
basic = basic.substring(basic.lastindexof('.')+1);
stringbuffer buffer = new stringbuffer(basic);
buffer.append('@@').append(integer.tohexstring(hashcode()));
buffer.append("(position=").append(this.position); //$non-nls-1$
if (this.delegate != null) buffer.append("delegate=").append(this.delegate); //$non-nls-1$
buffer.append(", forwards = ["); //$non-nls-1$
for (int i = 0; i < this.forwardreferencecount - 1; i++)
buffer.append(this.forwardreferences[i] + ", "); //$non-nls-1$
if (this.forwardreferencecount >= 1)
buffer.append(this.forwardreferences[this.forwardreferencecount-1]);
buffer.append("] )"); //$non-nls-1$
return buffer.tostring();
}
}
