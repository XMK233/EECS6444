/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.annotation;

/**
* represents jsr 175 annotation instances in the type-system.
*/
public class annotationbinding {
// do not access directly - use getters instead (unresolvedannotationbinding
// resolves types for type and pair contents just in time)
referencebinding type;
elementvaluepair[] pairs;

/**
* add the standard annotations encoded in the tag bits to the recorded annotations.
*
* @@param recordedannotations existing annotations already created
* @@param annotationtagbits
* @@param env
* @@return the combined list of annotations
*/
public static annotationbinding[] addstandardannotations(annotationbinding[] recordedannotations, long annotationtagbits, lookupenvironment env) {
// note: expect annotations to be requested just once so there is no need to store the standard annotations
// and all of the standard annotations created by this method are fully resolved since the sender is expected to use them immediately
int count = 0;
if ((annotationtagbits & tagbits.annotationtargetmask) != 0)
count++;
if ((annotationtagbits & tagbits.annotationretentionmask) != 0)
count++;
if ((annotationtagbits & tagbits.annotationdeprecated) != 0)
count++;
if ((annotationtagbits & tagbits.annotationdocumented) != 0)
count++;
if ((annotationtagbits & tagbits.annotationinherited) != 0)
count++;
if ((annotationtagbits & tagbits.annotationoverride) != 0)
count++;
if ((annotationtagbits & tagbits.annotationsuppresswarnings) != 0)
count++;
if (count == 0)
return recordedannotations;

int index = recordedannotations.length;
annotationbinding[] result = new annotationbinding[index + count];
system.arraycopy(recordedannotations, 0, result, 0, index);
if ((annotationtagbits & tagbits.annotationtargetmask) != 0)
result[index++] = buildtargetannotation(annotationtagbits, env);
if ((annotationtagbits & tagbits.annotationretentionmask) != 0)
result[index++] = buildretentionannotation(annotationtagbits, env);
if ((annotationtagbits & tagbits.annotationdeprecated) != 0)
result[index++] = buildmarkerannotation(typeconstants.java_lang_deprecated, env);
if ((annotationtagbits & tagbits.annotationdocumented) != 0)
result[index++] = buildmarkerannotation(typeconstants.java_lang_annotation_documented, env);
if ((annotationtagbits & tagbits.annotationinherited) != 0)
result[index++] = buildmarkerannotation(typeconstants.java_lang_annotation_inherited, env);
if ((annotationtagbits & tagbits.annotationoverride) != 0)
result[index++] = buildmarkerannotation(typeconstants.java_lang_override, env);
if ((annotationtagbits & tagbits.annotationsuppresswarnings) != 0)
result[index++] = buildmarkerannotation(typeconstants.java_lang_suppresswarnings, env);
return result;
}

private static annotationbinding buildmarkerannotation(char[][] compoundname, lookupenvironment env) {
referencebinding type = env.getresolvedtype(compoundname, null);
return env.createannotation(type, binding.no_element_value_pairs);
}

private static annotationbinding buildretentionannotation(long bits, lookupenvironment env) {
referencebinding retentionpolicy =
env.getresolvedtype(typeconstants.java_lang_annotation_retentionpolicy,
null);
object value = null;
if ((bits & tagbits.annotationruntimeretention) == tagbits.annotationruntimeretention) {
value = retentionpolicy.getfield(typeconstants.upper_runtime, true);
} else if ((bits & tagbits.annotationclassretention) != 0) {
value = retentionpolicy.getfield(typeconstants.upper_class, true);
} else if ((bits & tagbits.annotationsourceretention) != 0) {
value = retentionpolicy.getfield(typeconstants.upper_source, true);
}
return env.createannotation(
env.getresolvedtype(typeconstants.java_lang_annotation_retention, null),
new elementvaluepair[] {
new elementvaluepair(typeconstants.value, value, null)
});
}

private static annotationbinding buildtargetannotation(long bits, lookupenvironment env) {
referencebinding target = env.getresolvedtype(typeconstants.java_lang_annotation_target, null);
if ((bits & tagbits.annotationtarget) != 0)
return new annotationbinding(target, binding.no_element_value_pairs);

int arraysize = 0;
if ((bits & tagbits.annotationforannotationtype) != 0)
arraysize++;
if ((bits & tagbits.annotationforconstructor) != 0)
arraysize++;
if ((bits & tagbits.annotationforfield) != 0)
arraysize++;
if ((bits & tagbits.annotationforlocalvariable) != 0)
arraysize++;
if ((bits & tagbits.annotationformethod) != 0)
arraysize++;
if ((bits & tagbits.annotationforpackage) != 0)
arraysize++;
if ((bits & tagbits.annotationforparameter) != 0)
arraysize++;
if ((bits & tagbits.annotationfortype) != 0)
arraysize++;
object[] value = new object[arraysize];
if (arraysize > 0) {
referencebinding elementtype = env.getresolvedtype(typeconstants.java_lang_annotation_elementtype, null);
int index = 0;
if ((bits & tagbits.annotationforannotationtype) != 0)
value[index++] = elementtype.getfield(typeconstants.upper_annotation_type, true);
if ((bits & tagbits.annotationforconstructor) != 0)
value[index++] = elementtype.getfield(typeconstants.upper_constructor, true);
if ((bits & tagbits.annotationforfield) != 0)
value[index++] = elementtype.getfield(typeconstants.upper_field, true);
if ((bits & tagbits.annotationforlocalvariable) != 0)
value[index++] = elementtype.getfield(typeconstants.upper_local_variable, true);
if ((bits & tagbits.annotationformethod) != 0)
value[index++] = elementtype.getfield(typeconstants.upper_method, true);
if ((bits & tagbits.annotationforpackage) != 0)
value[index++] = elementtype.getfield(typeconstants.upper_package, true);
if ((bits & tagbits.annotationforparameter) != 0)
value[index++] = elementtype.getfield(typeconstants.upper_parameter, true);
if ((bits & tagbits.annotationfortype) != 0)
value[index++] = elementtype.getfield(typeconstants.type, true);
}
return env.createannotation(
target,
new elementvaluepair[] {
new elementvaluepair(typeconstants.value, value, null)
});
}

annotationbinding(referencebinding type, elementvaluepair[] pairs) {
this.type = type;
this.pairs = pairs;
}

annotationbinding(annotation astannotation) {
this((referencebinding) astannotation.resolvedtype, astannotation.computeelementvaluepairs());
}

/*
* computes a key that uniquely identifies this binding, using the given recipient's unique key.
* recipientkey @@ typekey
* @@myannot void bar() --> lp/x;.bar()v@@lp/myannot;
*/
public char[] computeuniquekey(char[] recipientkey) {
char[] typekey = this.type.computeuniquekey(false);
int recipientkeylength = recipientkey.length;
char[] uniquekey = new char[recipientkeylength+1+typekey.length];
system.arraycopy(recipientkey, 0, uniquekey, 0, recipientkeylength);
uniquekey[recipientkeylength] = '@@';
system.arraycopy(typekey, 0, uniquekey, recipientkeylength+1, typekey.length);
return uniquekey;
}

public referencebinding getannotationtype() {
return this.type;
}

public elementvaluepair[] getelementvaluepairs() {
return this.pairs;
}

public static void setmethodbindings(referencebinding type, elementvaluepair[] pairs) {
// set the method bindings of each element value pair
for (int i = pairs.length; --i >= 0;) {
elementvaluepair pair = pairs[i];
methodbinding[] methods = type.getmethods(pair.getname());
// there should be exactly one since the type is an annotation type.
if (methods != null && methods.length == 1)
pair.setmethodbinding(methods[0]);
}
}

public string tostring() {
stringbuffer buffer = new stringbuffer(5);
buffer.append('@@').append(this.type.sourcename);
if (this.pairs != null && this.pairs.length > 0) {
buffer.append("{ "); //$non-nls-1$
for (int i = 0, max = this.pairs.length; i < max; i++) {
if (i > 0) buffer.append(", "); //$non-nls-1$
buffer.append(this.pairs[i]);
}
buffer.append('}');
}
return buffer.tostring();
}
}
