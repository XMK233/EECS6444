/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.impl.irritantset;
import org.eclipse.jdt.internal.compiler.lookup.*;

/**
* annotation
*/
public abstract class annotation extends expression {

final static membervaluepair[] novaluepairs = new membervaluepair[0];
public int declarationsourceend;
public binding recipient;

public typereference type;
/**
*  the representation of this annotation in the type system.
*/
private annotationbinding compilerannotation = null;

public static long getretentionpolicy(char[] policyname) {
if (policyname == null || policyname.length == 0)
return 0;
switch(policyname[0]) {
case 'c' :
if (charoperation.equals(policyname, typeconstants.upper_class))
return tagbits.annotationclassretention;
break;
case 's' :
if (charoperation.equals(policyname, typeconstants.upper_source))
return tagbits.annotationsourceretention;
break;
case 'r' :
if (charoperation.equals(policyname, typeconstants.upper_runtime))
return tagbits.annotationruntimeretention;
break;
}
return 0; // unknown
}

public static long gettargetelementtype(char[] elementname) {
if (elementname == null || elementname.length == 0)
return 0;
switch(elementname[0]) {
case 'a' :
if (charoperation.equals(elementname, typeconstants.upper_annotation_type))
return tagbits.annotationforannotationtype;
break;
case 'c' :
if (charoperation.equals(elementname, typeconstants.upper_constructor))
return tagbits.annotationforconstructor;
break;
case 'f' :
if (charoperation.equals(elementname, typeconstants.upper_field))
return tagbits.annotationforfield;
break;
case 'l' :
if (charoperation.equals(elementname, typeconstants.upper_local_variable))
return tagbits.annotationforlocalvariable;
break;
case 'm' :
if (charoperation.equals(elementname, typeconstants.upper_method))
return tagbits.annotationformethod;
break;
case 'p' :
if (charoperation.equals(elementname, typeconstants.upper_parameter))
return tagbits.annotationforparameter;
else if (charoperation.equals(elementname, typeconstants.upper_package))
return tagbits.annotationforpackage;
break;
case 't' :
if (charoperation.equals(elementname, typeconstants.type))
return tagbits.annotationfortype;
break;
}
return 0; // unknown
}

public elementvaluepair[] computeelementvaluepairs() {
return binding.no_element_value_pairs;
}

/**
* compute the bit pattern for recognized standard annotations the compiler may need to act upon
*/
private long detectstandardannotation(scope scope, referencebinding annotationtype, membervaluepair valueattribute) {
long tagbits = 0;
switch (annotationtype.id) {
// retention annotation
case typeids.t_javalangannotationretention :
if (valueattribute != null) {
expression expr = valueattribute.value;
if ((expr.bits & binding.variable) == binding.field) {
fieldbinding field = ((reference)expr).fieldbinding();
if (field != null && field.declaringclass.id == t_javalangannotationretentionpolicy) {
tagbits |= getretentionpolicy(field.name);
}
}
}
break;
// target annotation
case typeids.t_javalangannotationtarget :
tagbits |= tagbits.annotationtarget; // target specified (could be empty)
if (valueattribute != null) {
expression expr = valueattribute.value;
if (expr instanceof arrayinitializer) {
arrayinitializer initializer = (arrayinitializer) expr;
final expression[] expressions = initializer.expressions;
if (expressions != null) {
for (int i = 0, length = expressions.length; i < length; i++) {
expression initexpr = expressions[i];
if ((initexpr.bits & binding.variable) == binding.field) {
fieldbinding field = ((reference) initexpr).fieldbinding();
if (field != null && field.declaringclass.id == t_javalangannotationelementtype) {
long element = gettargetelementtype(field.name);
if ((tagbits & element) != 0) {
scope.problemreporter().duplicatetargetintargetannotation(annotationtype, (namereference)initexpr);
} else {
tagbits |= element;
}
}
}
}
}
} else if ((expr.bits & binding.variable) == binding.field) {
fieldbinding field = ((reference) expr).fieldbinding();
if (field != null && field.declaringclass.id == t_javalangannotationelementtype) {
tagbits |= gettargetelementtype(field.name);
}
}
}
break;
// marker annotations
case typeids.t_javalangdeprecated :
tagbits |= tagbits.annotationdeprecated;
break;
case typeids.t_javalangannotationdocumented :
tagbits |= tagbits.annotationdocumented;
break;
case typeids.t_javalangannotationinherited :
tagbits |= tagbits.annotationinherited;
break;
case typeids.t_javalangoverride :
tagbits |= tagbits.annotationoverride;
break;
case typeids.t_javalangsuppresswarnings :
tagbits |= tagbits.annotationsuppresswarnings;
break;
}
return tagbits;
}

public annotationbinding getcompilerannotation() {
return this.compilerannotation;
}

public abstract membervaluepair[] membervaluepairs();

public stringbuffer printexpression(int indent, stringbuffer output) {
output.append('@@');
this.type.printexpression(0, output);
return output;
}

public void recordsuppresswarnings(scope scope, int startsuppresss, int endsuppress, boolean issuppressingwarnings) {
irritantset suppresswarningirritants = null;
membervaluepair[] pairs = membervaluepairs();
pairloop: for (int i = 0, length = pairs.length; i < length; i++) {
membervaluepair pair = pairs[i];
if (charoperation.equals(pair.name, typeconstants.value)) {
expression value = pair.value;
if (value instanceof arrayinitializer) {
arrayinitializer initializer = (arrayinitializer) value;
expression[] inits = initializer.expressions;
if (inits != null) {
for (int j = 0, initslength = inits.length; j < initslength; j++) {
constant cst = inits[j].constant;
if (cst != constant.notaconstant && cst.typeid() == t_javalangstring) {
irritantset irritants = compileroptions.warningtokentoirritants(cst.stringvalue());
if (irritants != null) {
if (suppresswarningirritants == null) {
suppresswarningirritants = new irritantset(irritants);
} else if (suppresswarningirritants.set(irritants) == null) {
scope.problemreporter().unusedwarningtoken(inits[j]);
}
} else {
scope.problemreporter().unhandledwarningtoken(inits[j]);
}
}
}
}
} else {
constant cst = value.constant;
if (cst != constant.notaconstant && cst.typeid() == t_javalangstring) {
irritantset irritants = compileroptions.warningtokentoirritants(cst.stringvalue());
if (irritants != null) {
suppresswarningirritants = new irritantset(irritants);
// todo: should check for unused warning token against enclosing annotation as well ?
} else {
scope.problemreporter().unhandledwarningtoken(value);
}
}
}
break pairloop;
}
}
if (issuppressingwarnings && suppresswarningirritants != null) {
scope.referencecompilationunit().recordsuppresswarnings(suppresswarningirritants, this, startsuppresss, endsuppress);
}
}

public typebinding resolvetype(blockscope scope) {

if (this.compilerannotation != null)
return this.resolvedtype;
this.constant = constant.notaconstant;

typebinding typebinding = this.type.resolvetype(scope);
if (typebinding == null) {
return null;
}
this.resolvedtype = typebinding;
// ensure type refers to an annotation type
if (!typebinding.isannotationtype() && typebinding.isvalidbinding()) {
scope.problemreporter().typemismatcherror(typebinding, scope.getjavalangannotationannotation(), this.type, null);
return null;
}

referencebinding annotationtype = (referencebinding) this.resolvedtype;
methodbinding[] methods = annotationtype.methods();
// clone valuepairs to keep track of unused ones
membervaluepair[] originalvaluepairs = membervaluepairs();
membervaluepair valueattribute = null; // remember the first 'value' pair
membervaluepair[] pairs;
int pairslength = originalvaluepairs.length;
if (pairslength > 0) {
system.arraycopy(originalvaluepairs, 0, pairs = new membervaluepair[pairslength], 0, pairslength);
} else {
pairs = originalvaluepairs;
}

nextmember: for (int i = 0, requiredlength = methods.length; i < requiredlength; i++) {
methodbinding method = methods[i];
char[] selector = method.selector;
boolean foundvalue = false;
nextpair: for (int j = 0; j < pairslength; j++) {
membervaluepair pair = pairs[j];
if (pair == null) continue nextpair;
char[] name = pair.name;
if (charoperation.equals(name, selector)) {
if (valueattribute == null && charoperation.equals(name, typeconstants.value)) {
valueattribute = pair;
}
pair.binding = method;
pair.resolvetypeexpecting(scope, method.returntype);
pairs[j] = null; // consumed
foundvalue = true;

// check duplicates
boolean foundduplicate = false;
for (int k = j+1; k < pairslength; k++) {
membervaluepair otherpair = pairs[k];
if (otherpair == null) continue;
if (charoperation.equals(otherpair.name, selector)) {
foundduplicate = true;
scope.problemreporter().duplicateannotationvalue(annotationtype, otherpair);
otherpair.binding = method;
otherpair.resolvetypeexpecting(scope, method.returntype);
pairs[k] = null;
}
}
if (foundduplicate) {
scope.problemreporter().duplicateannotationvalue(annotationtype, pair);
continue nextmember;
}
}
}
if (!foundvalue &&
(method.modifiers & classfileconstants.accannotationdefault) == 0 &&
(this.bits & isrecovered) == 0) {
scope.problemreporter().missingvalueforannotationmember(this, selector);
}
}
// check unused pairs
for (int i = 0; i < pairslength; i++) {
if (pairs[i] != null) {
scope.problemreporter().undefinedannotationvalue(annotationtype, pairs[i]);
pairs[i].resolvetypeexpecting(scope, null); // resilient
}
}
//		if (scope.compileroptions().storeannotations)
this.compilerannotation = scope.environment().createannotation((referencebinding) this.resolvedtype, computeelementvaluepairs());
// recognize standard annotations ?
long tagbits = detectstandardannotation(scope, annotationtype, valueattribute);

// record annotation positions in the compilation result
scope.referencecompilationunit().recordsuppresswarnings(irritantset.nls, null, this.sourcestart, this.declarationsourceend);
if (this.recipient != null) {
if (tagbits != 0) {
// tag bits onto recipient
switch (this.recipient.kind()) {
case binding.package :
((packagebinding)this.recipient).tagbits |= tagbits;
break;
case binding.type :
case binding.generic_type :
sourcetypebinding sourcetype = (sourcetypebinding) this.recipient;
sourcetype.tagbits |= tagbits;
if ((tagbits & tagbits.annotationsuppresswarnings) != 0) {
typedeclaration typedeclaration =  sourcetype.scope.referencecontext;
int start;
if (scope.referencecompilationunit().types[0] == typedeclaration) {
start = 0;
} else {
start = typedeclaration.declarationsourcestart;
}
recordsuppresswarnings(scope, start, typedeclaration.declarationsourceend, scope.compileroptions().suppresswarnings);
}
break;
case binding.method :
methodbinding sourcemethod = (methodbinding) this.recipient;
sourcemethod.tagbits |= tagbits;
if ((tagbits & tagbits.annotationsuppresswarnings) != 0) {
sourcetype = (sourcetypebinding) sourcemethod.declaringclass;
abstractmethoddeclaration methoddeclaration = sourcetype.scope.referencecontext.declarationof(sourcemethod);
recordsuppresswarnings(scope, methoddeclaration.declarationsourcestart, methoddeclaration.declarationsourceend, scope.compileroptions().suppresswarnings);
}
break;
case binding.field :
fieldbinding sourcefield = (fieldbinding) this.recipient;
sourcefield.tagbits |= tagbits;
if ((tagbits & tagbits.annotationsuppresswarnings) != 0) {
sourcetype = (sourcetypebinding) sourcefield.declaringclass;
fielddeclaration fielddeclaration = sourcetype.scope.referencecontext.declarationof(sourcefield);
recordsuppresswarnings(scope, fielddeclaration.declarationsourcestart, fielddeclaration.declarationsourceend, scope.compileroptions().suppresswarnings);
}
break;
case binding.local :
localvariablebinding variable = (localvariablebinding) this.recipient;
variable.tagbits |= tagbits;
if ((tagbits & tagbits.annotationsuppresswarnings) != 0) {
localdeclaration localdeclaration = variable.declaration;
recordsuppresswarnings(scope, localdeclaration.declarationsourcestart, localdeclaration.declarationsourceend, scope.compileroptions().suppresswarnings);
}
break;
}
}
// check (meta)target compatibility
checktargetcompatibility: {
long metatagbits = annotationtype.getannotationtagbits(); // could be forward reference
if ((metatagbits & tagbits.annotationtargetmask) == 0) // does not specify any target restriction
break checktargetcompatibility;

switch (this.recipient.kind()) {
case binding.package :
if ((metatagbits & tagbits.annotationforpackage) != 0)
break checktargetcompatibility;
break;
case binding.type :
case binding.generic_type :
if (((referencebinding)this.recipient).isannotationtype()) {
if ((metatagbits & (tagbits.annotationforannotationtype|tagbits.annotationfortype)) != 0)
break checktargetcompatibility;
} else if ((metatagbits & tagbits.annotationfortype) != 0) {
break checktargetcompatibility;
} else if ((metatagbits & tagbits.annotationforpackage) != 0) {
if (charoperation.equals(((referencebinding)this.recipient).sourcename, typeconstants.package_info_name))
break checktargetcompatibility;
}
break;
case binding.method :
if (((methodbinding)this.recipient).isconstructor()) {
if ((metatagbits & tagbits.annotationforconstructor) != 0)
break checktargetcompatibility;
} else 	if ((metatagbits & tagbits.annotationformethod) != 0)
break checktargetcompatibility;
break;
case binding.field :
if ((metatagbits & tagbits.annotationforfield) != 0)
break checktargetcompatibility;
break;
case binding.local :
if ((((localvariablebinding)this.recipient).tagbits & tagbits.isargument) != 0) {
if ((metatagbits & tagbits.annotationforparameter) != 0)
break checktargetcompatibility;
} else 	if ((annotationtype.tagbits & tagbits.annotationforlocalvariable) != 0)
break checktargetcompatibility;
break;
}
scope.problemreporter().disallowedtargetforannotation(this);
}
}
return this.resolvedtype;
}

public abstract void traverse(astvisitor visitor, blockscope scope);

}
