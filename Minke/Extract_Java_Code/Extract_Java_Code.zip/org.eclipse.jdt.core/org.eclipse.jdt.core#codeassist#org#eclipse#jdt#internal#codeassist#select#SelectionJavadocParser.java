/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

import java.util.list;

import org.eclipse.jdt.core.compiler.invalidinputexception;
import org.eclipse.jdt.internal.codeassist.selectionengine;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.parser.javadocparser;

/**
* parser specialized for decoding javadoc comments which includes code selection.
*/
public class selectionjavadocparser extends javadocparser {

int selectionstart;
int selectionend;
astnode selectednode;

public selectionjavadocparser(selectionparser sourceparser) {
super(sourceparser);
this.shouldreportproblems = false;
this.reportproblems = false;
this.kind = selection_parser | text_parse;
}

/*
* do not parse comment if selection is not included.
*/
public boolean checkdeprecation(int commentptr) {
this.selectionstart = ((selectionparser)this.sourceparser).selectionstart;
this.selectionend = ((selectionparser)this.sourceparser).selectionend;
this.javadocstart = this.sourceparser.scanner.commentstarts[commentptr];
this.javadocend = this.sourceparser.scanner.commentstops[commentptr];
if (this.javadocstart <= this.selectionstart && this.selectionend <= this.javadocend) {
if (selectionengine.debug) {
system.out.println("selection in javadoc:"); //$non-nls-1$
}
super.checkdeprecation(commentptr);
} else {
this.doccomment = null;
}
return false;
}

/*
* replace stored javadoc node with specific selection one.
*/
protected boolean commentparse() {
this.doccomment = new selectionjavadoc(this.javadocstart, this.javadocend);
return super.commentparse();
}

/*
* create argument expression and store it if it includes selection.
*/
protected object createargumentreference(char[] name, int dim, boolean isvarargs, object typeref, long[] dimpositions, long argnamepos) throws invalidinputexception {
// create argument as we may need it after
expression expression = (expression) super.createargumentreference(name, dim, isvarargs, typeref, dimpositions, argnamepos);
// see if selection is in argument
int start = ((typereference)typeref).sourcestart;
int end = ((typereference)typeref).sourceend;
if (start <= this.selectionstart && this.selectionend <= end) {
this.selectednode = expression;
this.abort = true;
if (selectionengine.debug) {
system.out.println("	selected argument="+this.selectednode); //$non-nls-1$
}
}
return expression;
}

/*
* verify if field identifier positions include selection.
* if so, create field reference, store it and abort comment parse.
* otherwise return null as we do not need this reference.
*/
protected object createfieldreference(object receiver) throws invalidinputexception {
int start = (int) (this.identifierpositionstack[0] >>> 32);
int end = (int) this.identifierpositionstack[0];
if (start <= this.selectionstart && this.selectionend <= end) {
this.selectednode = (astnode) super.createfieldreference(receiver);
this.abort = true;
if (selectionengine.debug) {
system.out.println("	selected field="+this.selectednode); //$non-nls-1$
}
}
return null;
}

/*
* verify if method identifier positions include selection.
* if so, create field reference, store it and abort comment parse.
* otherwise return null as we do not need this reference.
*/
protected object createmethodreference(object receiver, list arguments) throws invalidinputexception {
int memberptr = this.identifierlengthstack[0] - 1;	// may be > 0 for inner class constructor reference
int start = (int) (this.identifierpositionstack[memberptr] >>> 32);
int end = (int) this.identifierpositionstack[memberptr];
if (start <= this.selectionstart && this.selectionend <= end) {
this.selectednode = (astnode) super.createmethodreference(receiver, arguments);
this.abort = true;
if (selectionengine.debug) {
system.out.println("	selected method="+this.selectednode); //$non-nls-1$
}
}
return null;
}

/*
* create type reference and verify if it includes selection.
* if so, store it and abort comment parse.
* otherwise return null as we do not need this reference.
*/
protected object createtypereference(int primitivetoken) {
// need to create type ref in case it was needed by members
typereference typeref = (typereference) super.createtypereference(primitivetoken);

// see if node is concerned by selection
if (typeref.sourcestart <= this.selectionstart && this.selectionend <= typeref.sourceend) {
// see if selection is in one of tokens of qualification
if (typeref instanceof javadocqualifiedtypereference) {
javadocqualifiedtypereference qualifiedtyperef = (javadocqualifiedtypereference) typeref;
int size = qualifiedtyperef.tokens.length - 1;
for (int i=0; i<size; i++) {
int start = (int) (qualifiedtyperef.sourcepositions[i] >>> 32);
int end = (int) qualifiedtyperef.sourcepositions[i];
if (start <= this.selectionstart && this.selectionend <= end) {
int pos = i + 1;
char[][] tokens = new char[pos][];
int ptr = this.identifierptr - size;
system.arraycopy(this.identifierstack, ptr, tokens, 0, pos);
long[] positions = new long[pos];
system.arraycopy(this.identifierpositionstack, ptr, positions, 0, pos);
this.selectednode = new javadocqualifiedtypereference(tokens, positions, this.tagsourcestart, this.tagsourceend);
this.abort = true; // we got selected node => cancel parse
if (selectionengine.debug) {
system.out.println("	selected partial qualified type="+this.selectednode); //$non-nls-1$
}
return typeref;
}
}
// selection is in last token => we'll store type ref as this
}
// store type ref as selected node
this.selectednode = typeref;
this.abort = true; // we got selected node => cancel parse
if (selectionengine.debug) {
system.out.println("	selected type="+this.selectednode); //$non-nls-1$
}
}
return typeref;
}

/*
* push param reference and verify if it includes selection.
* if so, store it and abort comment parse.
*/
protected boolean pushparamname(boolean istypeparam) {
if (super.pushparamname(istypeparam)) {
expression expression = (expression) this.aststack[this.astptr--];
// see if expression is concerned by selection
if (expression.sourcestart <= this.selectionstart && this.selectionend <= expression.sourceend) {
this.selectednode = expression;
this.abort = true; // we got selected node => cancel parse
if (selectionengine.debug) {
system.out.println("	selected param="+this.selectednode); //$non-nls-1$
}
}
}
return false;
}

/*
* store selected node into doc comment.
*/
protected void updatedoccomment() {
if (this.selectednode instanceof expression) {
((selectionjavadoc) this.doccomment).selectednode = (expression) this.selectednode;
}
}
}
