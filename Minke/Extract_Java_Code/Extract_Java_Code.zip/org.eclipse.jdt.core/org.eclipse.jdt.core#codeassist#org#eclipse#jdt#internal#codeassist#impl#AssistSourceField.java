/*******************************************************************************
* copyright (c) 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.impl;

import java.util.map;

import org.eclipse.core.runtime.iprogressmonitor;
import org.eclipse.jdt.core.iannotation;
import org.eclipse.jdt.core.itype;
import org.eclipse.jdt.core.javamodelexception;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.core.javaelement;
import org.eclipse.jdt.internal.core.resolvedsourcefield;

public class assistsourcefield extends resolvedsourcefield {
private map bindingcache;
private map infocache;

private string uniquekey;
private boolean isresolved;

public assistsourcefield(javaelement parent, string name, map bindingcache, map infocache) {
super(parent, name, null);
this.bindingcache = bindingcache;
this.infocache = infocache;
}

public object getelementinfo(iprogressmonitor monitor) throws javamodelexception {
return this.infocache.get(this);
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.core.sourcefield#getkey()
*/
public string getkey() {
if (this.uniquekey == null) {
binding binding = (binding) this.bindingcache.get(this);
if (binding != null) {
this.isresolved = true;
this.uniquekey = new string(binding.computeuniquekey());
} else {
this.isresolved = false;
try {
this.uniquekey = getkey(this, false/*don't open*/);
} catch (javamodelexception e) {
// happen only if force open is true
return null;
}
}
}
return this.uniquekey;
}

public boolean isresolved() {
getkey();
return this.isresolved;
}

protected void tostringinfo(int tab, stringbuffer buffer, object info,boolean showresolvedinfo) {
super.tostringinfo(tab, buffer, info, showresolvedinfo && isresolved());
}

public iannotation getannotation(string annotationname) {
return new assistannotation(this, annotationname, this.infocache);
}

public itype gettype(string typename, int count) {
assistsourcetype type = new assistsourcetype(this, typename, this.bindingcache, this.infocache);
type.occurrencecount = count;
return type;
}
}
