/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.classfile;
import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.allocationexpression;
import org.eclipse.jdt.internal.compiler.ast.explicitconstructorcall;
import org.eclipse.jdt.internal.compiler.ast.expression;
import org.eclipse.jdt.internal.compiler.ast.operatorids;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.flow.unconditionalflowinfo;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.problem.abortmethod;
import org.eclipse.jdt.internal.compiler.util.util;

public class codestream {

// it will be responsible for the following items.
// -> tracking max stack.

public static fieldbinding[] implicitthis = new fieldbinding[] {};
public static final int labels_increment = 5;
// local variable attributes output
public static final int locals_increment = 10;
static exceptionlabel[] noexceptionhandlers = new exceptionlabel[labels_increment];
static branchlabel[] nolabels = new branchlabel[labels_increment];
static localvariablebinding[] nolocals = new localvariablebinding[locals_increment];
static localvariablebinding[] novisiblelocals = new localvariablebinding[locals_increment];
public static final compilationresult restart_in_wide_mode = new compilationresult((char[])null, 0, 0, 0);

public int alllocalscounter;
public byte[] bcodestream;
public classfile classfile; // the current classfile it is associated to.
public int classfileoffset;
public constantpool constantpool; // the constant pool used to generate bytecodes that need to store information into the constant pool
public int countlabels;
public exceptionlabel[] exceptionlabels = new exceptionlabel[labels_increment];
public int exceptionlabelscounter;
public int generateattributes;
// store all the labels placed at the current position to be able to optimize
// a jump to the next bytecode.
static final int l_unknown = 0, l_optimizable = 2, l_cannot_optimize = 4;
public branchlabel[] labels = new branchlabel[labels_increment];
public int lastentrypc; // last entry recorded
public int lastabruptcompletion; // position of last instruction which abrupts completion: goto/return/athrow

public int[] lineseparatorpositions;
// line number of the body start and the body end
public int linenumberstart;

public int linenumberend;
public localvariablebinding[] locals = new localvariablebinding[locals_increment];
public int maxfieldcount;
public int maxlocals;
public abstractmethoddeclaration methoddeclaration;
public int[] pctosourcemap = new int[24];
public int pctosourcemapsize;
public int position; // so when first set can be incremented
public boolean preserveunusedlocals;

public int stackdepth; // use ints to keep from using extra bc when adding

public int stackmax; // use ints to keep from using extra bc when adding
public int startingclassfileoffset; // i need to keep the starting point inside the byte array
// target level to manage different code generation between different target levels
protected long targetlevel;

public localvariablebinding[] visiblelocals = new localvariablebinding[locals_increment];

int visiblelocalscount;

// to handle goto_w
public boolean widemode = false;

public codestream(classfile givenclassfile) {
this.targetlevel = givenclassfile.targetjdk;
this.generateattributes = givenclassfile.produceattributes;
if ((givenclassfile.produceattributes & classfileconstants.attr_lines) != 0) {
this.lineseparatorpositions = givenclassfile.referencebinding.scope.referencecompilationunit().compilationresult.getlineseparatorpositions();
}
}
/**
* this methods searches for an existing entry inside the pctosourcemap table with a pc equals to @@pc.
* if there is an existing entry it returns -1 (no insertion required).
* otherwise it returns the index where the entry for the pc has to be inserted.
* this is based on the fact that the pctosourcemap table is sorted according to the pc.
*
* @@param pctosourcemap the given pctosourcemap array
* @@param length the given length
* @@param pc the given pc
* @@return int
*/
public static int insertionindex(int[] pctosourcemap, int length, int pc) {
int g = 0;
int d = length - 2;
int m = 0;
while (g <= d) {
m = (g + d) / 2;
// we search only on even indexes
if ((m & 1) != 0) // faster than ((m % 2) != 0)
m--;
int currentpc = pctosourcemap[m];
if (pc < currentpc) {
d = m - 2;
} else
if (pc > currentpc) {
g = m + 2;
} else {
return -1;
}
}
if (pc < pctosourcemap[m])
return m;
return m + 2;
}
public static final void sort(int[] tab, int lo0, int hi0, int[] result) {
int lo = lo0;
int hi = hi0;
int mid;
if (hi0 > lo0) {
/* arbitrarily establishing partition element as the midpoint of
* the array.
*/
mid = tab[lo0 + (hi0 - lo0) / 2];
// loop through the array until indices cross
while (lo <= hi) {
/* find the first element that is greater than or equal to
* the partition element starting from the left index.
*/
while ((lo < hi0) && (tab[lo] < mid))
++lo;
/* find an element that is smaller than or equal to
* the partition element starting from the right index.
*/
while ((hi > lo0) && (tab[hi] > mid))
--hi;
// if the indexes have not crossed, swap
if (lo <= hi) {
swap(tab, lo, hi, result);
++lo;
--hi;
}
}
/* if the right index has not reached the left side of array
* must now sort the left partition.
*/
if (lo0 < hi)
sort(tab, lo0, hi, result);
/* if the left index has not reached the right side of array
* must now sort the right partition.
*/
if (lo < hi0)
sort(tab, lo, hi0, result);
}
}


private static final void swap(int a[], int i, int j, int result[]) {
int t;
t = a[i];
a[i] = a[j];
a[j] = t;
t = result[j];
result[j] = result[i];
result[i] = t;
}

public void aaload() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_aaload;
}

public void aastore() {
this.countlabels = 0;
this.stackdepth -= 3;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_aastore;
}

public void aconst_null() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax) {
this.stackmax = this.stackdepth;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_aconst_null;
}

public void adddefinitelyassignedvariables(scope scope, int initstateindex) {
// required to fix 1pr0xvs: lfre:winnt - compiler: variable table for method appears incorrect
if ((this.generateattributes & (classfileconstants.attr_vars
| classfileconstants.attr_stack_map_table
| classfileconstants.attr_stack_map)) == 0)
return;
for (int i = 0; i < this.visiblelocalscount; i++) {
localvariablebinding localbinding = this.visiblelocals[i];
if (localbinding != null) {
// check if the local is definitely assigned
if (isdefinitelyassigned(scope, initstateindex, localbinding)) {
if ((localbinding.initializationcount == 0) || (localbinding.initializationpcs[((localbinding.initializationcount - 1) << 1) + 1] != -1)) {
/* there are two cases:
* 1) there is no initialization interval opened ==> add an opened interval
* 2) there is already some initialization intervals but the last one is closed ==> add an opened interval
* an opened interval means that the value at localbinding.initializationpcs[localbinding.initializationcount - 1][1]
* is equals to -1.
* initializationpcs is a collection of pairs of int:
* 	first value is the startpc and second value is the endpc. -1 one for the last value means that the interval
* 	is not closed yet.
*/
localbinding.recordinitializationstartpc(this.position);
}
}
}
}
}

public void addlabel(branchlabel alabel) {
if (this.countlabels == this.labels.length)
system.arraycopy(this.labels, 0, this.labels = new branchlabel[this.countlabels + labels_increment], 0, this.countlabels);
this.labels[this.countlabels++] = alabel;
}

public void addvariable(localvariablebinding localbinding) {
/* do nothing */
}

public void addvisiblelocalvariable(localvariablebinding localbinding) {
if ((this.generateattributes & (classfileconstants.attr_vars
| classfileconstants.attr_stack_map_table
| classfileconstants.attr_stack_map)) == 0)
return;

if (this.visiblelocalscount >= this.visiblelocals.length)
system.arraycopy(this.visiblelocals, 0, this.visiblelocals = new localvariablebinding[this.visiblelocalscount * 2], 0, this.visiblelocalscount);
this.visiblelocals[this.visiblelocalscount++] = localbinding;
}

public void aload(int iarg) {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.maxlocals <= iarg) {
this.maxlocals = iarg + 1;
}
if (iarg > 255) { // widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_aload;
writeunsignedshort(iarg);
} else {
// don't need to use the wide bytecode
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_aload;
this.bcodestream[this.classfileoffset++] = (byte) iarg;
}
}

public void aload_0() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax) {
this.stackmax = this.stackdepth;
}
if (this.maxlocals == 0) {
this.maxlocals = 1;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_aload_0;
}

public void aload_1() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.maxlocals <= 1) {
this.maxlocals = 2;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_aload_1;
}

public void aload_2() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.maxlocals <= 2) {
this.maxlocals = 3;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_aload_2;
}

public void aload_3() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.maxlocals <= 3) {
this.maxlocals = 4;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_aload_3;
}

public void anewarray(typebinding typebinding) {
this.countlabels = 0;
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_anewarray;
writeunsignedshort(this.constantpool.literalindexfortype(typebinding));
}

public void areturn() {
this.countlabels = 0;
this.stackdepth--;
// the stackdepth should be equal to 0
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_areturn;
this.lastabruptcompletion = this.position;
}

public void arrayat(int typebindingid) {
switch (typebindingid) {
case typeids.t_int :
iaload();
break;
case typeids.t_byte :
case typeids.t_boolean :
baload();
break;
case typeids.t_short :
saload();
break;
case typeids.t_char :
caload();
break;
case typeids.t_long :
laload();
break;
case typeids.t_float :
faload();
break;
case typeids.t_double :
daload();
break;
default :
aaload();
}
}

public void arrayatput(int elementtypeid, boolean valuerequired) {
switch (elementtypeid) {
case typeids.t_int :
if (valuerequired)
dup_x2();
iastore();
break;
case typeids.t_byte :
case typeids.t_boolean :
if (valuerequired)
dup_x2();
bastore();
break;
case typeids.t_short :
if (valuerequired)
dup_x2();
sastore();
break;
case typeids.t_char :
if (valuerequired)
dup_x2();
castore();
break;
case typeids.t_long :
if (valuerequired)
dup2_x2();
lastore();
break;
case typeids.t_float :
if (valuerequired)
dup_x2();
fastore();
break;
case typeids.t_double :
if (valuerequired)
dup2_x2();
dastore();
break;
default :
if (valuerequired)
dup_x2();
aastore();
}
}

public void arraylength() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_arraylength;
}

public void astore(int iarg) {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= iarg) {
this.maxlocals = iarg + 1;
}
if (iarg > 255) { // widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position+=2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_astore;
writeunsignedshort(iarg);
} else {
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position+=2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_astore;
this.bcodestream[this.classfileoffset++] = (byte) iarg;
}
}

public void astore_0() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals == 0) {
this.maxlocals = 1;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_astore_0;
}

public void astore_1() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= 1) {
this.maxlocals = 2;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_astore_1;
}

public void astore_2() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= 2) {
this.maxlocals = 3;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_astore_2;
}

public void astore_3() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= 3) {
this.maxlocals = 4;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_astore_3;
}

public void athrow() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_athrow;
this.lastabruptcompletion = this.position;
}

public void baload() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_baload;
}

public void bastore() {
this.countlabels = 0;
this.stackdepth -= 3;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_bastore;
}

public void bipush(byte b) {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_bipush;
this.bcodestream[this.classfileoffset++] = b;
}

public void caload() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_caload;
}

public void castore() {
this.countlabels = 0;
this.stackdepth -= 3;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_castore;
}

public void checkcast(int baseid) {
this.countlabels = 0;
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_checkcast;
switch (baseid) {
case typeids.t_byte :
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangbyteconstantpoolname));
break;
case typeids.t_short :
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangshortconstantpoolname));
break;
case typeids.t_char :
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangcharacterconstantpoolname));
break;
case typeids.t_int :
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangintegerconstantpoolname));
break;
case typeids.t_long :
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalanglongconstantpoolname));
break;
case typeids.t_float :
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangfloatconstantpoolname));
break;
case typeids.t_double :
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangdoubleconstantpoolname));
break;
case typeids.t_boolean :
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangbooleanconstantpoolname));
}
}

public void checkcast(typebinding typebinding) {
this.countlabels = 0;
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_checkcast;
writeunsignedshort(this.constantpool.literalindexfortype(typebinding));
}

public void d2f() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_d2f;
}

public void d2i() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_d2i;
}

public void d2l() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_d2l;
}

public void dadd() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dadd;
}

public void daload() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_daload;
}

public void dastore() {
this.countlabels = 0;
this.stackdepth -= 4;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dastore;
}

public void dcmpg() {
this.countlabels = 0;
this.stackdepth -= 3;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dcmpg;
}

public void dcmpl() {
this.countlabels = 0;
this.stackdepth -= 3;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dcmpl;
}

public void dconst_0() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dconst_0;
}

public void dconst_1() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dconst_1;
}

public void ddiv() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ddiv;
}

public void decrstacksize(int offset) {
this.stackdepth -= offset;
}

public void dload(int iarg) {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.maxlocals < iarg + 2) {
this.maxlocals = iarg + 2; // + 2 because it is a double
}
if (iarg > 255) { // widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dload;
writeunsignedshort(iarg);
} else {
// don't need to use the wide bytecode
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dload;
this.bcodestream[this.classfileoffset++] = (byte) iarg;
}
}

public void dload_0() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.maxlocals < 2) {
this.maxlocals = 2;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dload_0;
}

public void dload_1() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.maxlocals < 3) {
this.maxlocals = 3;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dload_1;
}

public void dload_2() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.maxlocals < 4) {
this.maxlocals = 4;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dload_2;
}

public void dload_3() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.maxlocals < 5) {
this.maxlocals = 5;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dload_3;
}

public void dmul() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dmul;
}

public void dneg() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dneg;
}

public void drem() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_drem;
}

public void dreturn() {
this.countlabels = 0;
this.stackdepth -= 2;
// the stackdepth should be equal to 0
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dreturn;
this.lastabruptcompletion = this.position;
}

public void dstore(int iarg) {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.maxlocals <= iarg + 1) {
this.maxlocals = iarg + 2;
}
if (iarg > 255) { // widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dstore;
writeunsignedshort(iarg);
} else {
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dstore;
this.bcodestream[this.classfileoffset++] = (byte) iarg;
}
}

public void dstore_0() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.maxlocals < 2) {
this.maxlocals = 2;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dstore_0;
}

public void dstore_1() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.maxlocals < 3) {
this.maxlocals = 3;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dstore_1;
}

public void dstore_2() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.maxlocals < 4) {
this.maxlocals = 4;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dstore_2;
}

public void dstore_3() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.maxlocals < 5) {
this.maxlocals = 5;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dstore_3;
}

public void dsub() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dsub;
}

public void dup() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax) {
this.stackmax = this.stackdepth;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dup;
}

public void dup_x1() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dup_x1;
}

public void dup_x2() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dup_x2;
}

public void dup2() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dup2;
}

public void dup2_x1() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dup2_x1;
}

public void dup2_x2() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_dup2_x2;
}

public void exituserscope(blockscope currentscope) {
// mark all the scope's locals as losing their definite assignment
if ((this.generateattributes & (classfileconstants.attr_vars
| classfileconstants.attr_stack_map_table
| classfileconstants.attr_stack_map)) == 0)
return;
int index = this.visiblelocalscount - 1;
while (index >= 0) {
localvariablebinding visiblelocal = this.visiblelocals[index];
if (visiblelocal == null || visiblelocal.declaringscope != currentscope) {
// left currentscope
index--;
continue;
}

// there may be some preserved locals never initialized
if (visiblelocal.initializationcount > 0) {
visiblelocal.recordinitializationendpc(this.position);
}
this.visiblelocals[index--] = null; // this variable is no longer visible afterwards
}
}

public void exituserscope(blockscope currentscope, localvariablebinding binding) {
// mark all the scope's locals as losing their definite assignment
if ((this.generateattributes & (classfileconstants.attr_vars
| classfileconstants.attr_stack_map_table
| classfileconstants.attr_stack_map)) == 0)
return;
int index = this.visiblelocalscount - 1;
while (index >= 0) {
localvariablebinding visiblelocal = this.visiblelocals[index];
if (visiblelocal == null || visiblelocal.declaringscope != currentscope || visiblelocal == binding) {
// left currentscope
index--;
continue;
}
// there may be some preserved locals never initialized
if (visiblelocal.initializationcount > 0) {
visiblelocal.recordinitializationendpc(this.position);
}
this.visiblelocals[index--] = null; // this variable is no longer visible afterwards
}
}

public void f2d() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_f2d;
}

public void f2i() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_f2i;
}

public void f2l() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_f2l;
}

public void fadd() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fadd;
}

public void faload() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_faload;
}

public void fastore() {
this.countlabels = 0;
this.stackdepth -= 3;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fastore;
}

public void fcmpg() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fcmpg;
}

public void fcmpl() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fcmpl;
}

public void fconst_0() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fconst_0;
}

public void fconst_1() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fconst_1;
}

public void fconst_2() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fconst_2;
}

public void fdiv() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fdiv;
}

public void fieldaccess(byte opcode, fieldbinding fieldbinding, typebinding declaringclass) {
if (declaringclass == null) declaringclass = fieldbinding.declaringclass;
if ((declaringclass.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(this.classfile, declaringclass);
}
typebinding returntype = fieldbinding.type;
int returntypesize;
switch (returntype.id) {
case typeids.t_long :
case typeids.t_double :
returntypesize = 2;
break;
default :
returntypesize = 1;
break;
}
this.fieldaccess(opcode, returntypesize, declaringclass.constantpoolname(), fieldbinding.name, returntype.signature());
}

private void fieldaccess(byte opcode, int returntypesize, char[] declaringclass, char[] fieldname, char[] signature) {
this.countlabels = 0;
switch(opcode) {
case opcodes.opc_getfield :
if (returntypesize == 2) {
this.stackdepth++;
}
break;
case opcodes.opc_getstatic :
if (returntypesize == 2) {
this.stackdepth += 2;
} else {
this.stackdepth++;
}
break;
case opcodes.opc_putfield :
if (returntypesize == 2) {
this.stackdepth -= 3;
} else {
this.stackdepth -= 2;
}
break;
case opcodes.opc_putstatic :
if (returntypesize == 2) {
this.stackdepth -= 2;
} else {
this.stackdepth--;
}
}
if (this.stackdepth > this.stackmax) {
this.stackmax = this.stackdepth;
}
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcode;
writeunsignedshort(this.constantpool.literalindexforfield(declaringclass, fieldname, signature));
}

public void fload(int iarg) {
this.countlabels = 0;
this.stackdepth++;
if (this.maxlocals <= iarg) {
this.maxlocals = iarg + 1;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (iarg > 255) { // widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fload;
writeunsignedshort(iarg);
} else {
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fload;
this.bcodestream[this.classfileoffset++] = (byte) iarg;
}
}

public void fload_0() {
this.countlabels = 0;
this.stackdepth++;
if (this.maxlocals == 0) {
this.maxlocals = 1;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fload_0;
}

public void fload_1() {
this.countlabels = 0;
this.stackdepth++;
if (this.maxlocals <= 1) {
this.maxlocals = 2;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fload_1;
}

public void fload_2() {
this.countlabels = 0;
this.stackdepth++;
if (this.maxlocals <= 2) {
this.maxlocals = 3;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fload_2;
}

public void fload_3() {
this.countlabels = 0;
this.stackdepth++;
if (this.maxlocals <= 3) {
this.maxlocals = 4;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fload_3;
}

public void fmul() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fmul;
}

public void fneg() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fneg;
}

public void frem() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_frem;
}

public void freturn() {
this.countlabels = 0;
this.stackdepth--;
// the stackdepth should be equal to 0
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_freturn;
this.lastabruptcompletion = this.position;
}

public void fstore(int iarg) {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= iarg) {
this.maxlocals = iarg + 1;
}
if (iarg > 255) { // widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fstore;
writeunsignedshort(iarg);
} else {
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fstore;
this.bcodestream[this.classfileoffset++] = (byte) iarg;
}
}

public void fstore_0() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals == 0) {
this.maxlocals = 1;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fstore_0;
}

public void fstore_1() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= 1) {
this.maxlocals = 2;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fstore_1;
}

public void fstore_2() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= 2) {
this.maxlocals = 3;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fstore_2;
}

public void fstore_3() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= 3) {
this.maxlocals = 4;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fstore_3;
}

public void fsub() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_fsub;
}

public void generateboxingconversion(int unboxedtypeid) {
switch (unboxedtypeid) {
case typeids.t_byte :
if (this.targetlevel >= classfileconstants.jdk1_5) {
// invokestatic: byte.valueof(byte)
invoke(
opcodes.opc_invokestatic,
1, // receiverandargssize
1, // return type size
constantpool.javalangbyteconstantpoolname,
constantpool.valueof,
constantpool.bytebytesignature);
} else {
// new byte( byte )
newwrapperfor(unboxedtypeid);
dup_x1();
swap();
invoke(
opcodes.opc_invokespecial,
2, // receiverandargssize
0, // return type size
constantpool.javalangbyteconstantpoolname,
constantpool.init,
constantpool.byteconstrsignature);
}
break;
case typeids.t_short :
if ( this.targetlevel >= classfileconstants.jdk1_5 ) {
// invokestatic: short.valueof(short)
invoke(
opcodes.opc_invokestatic,
1, // receiverandargssize
1, // return type size
constantpool.javalangshortconstantpoolname,
constantpool.valueof,
constantpool.shortshortsignature);
} else {
// new short(short)
newwrapperfor(unboxedtypeid);
dup_x1();
swap();
invoke(
opcodes.opc_invokespecial,
2, // receiverandargssize
0, // return type size
constantpool.javalangshortconstantpoolname,
constantpool.init,
constantpool.shortconstrsignature);
}
break;
case typeids.t_char :
if ( this.targetlevel >= classfileconstants.jdk1_5 ) {
// invokestatic: character.valueof(char)
invoke(
opcodes.opc_invokestatic,
1, // receiverandargssize
1, // return type size
constantpool.javalangcharacterconstantpoolname,
constantpool.valueof,
constantpool.charcharactersignature);
} else {
// new char( char )
newwrapperfor(unboxedtypeid);
dup_x1();
swap();
invoke(
opcodes.opc_invokespecial,
2, // receiverandargssize
0, // return type size
constantpool.javalangcharacterconstantpoolname,
constantpool.init,
constantpool.charconstrsignature);
}
break;
case typeids.t_int :
if (this.targetlevel >= classfileconstants.jdk1_5) {
// invokestatic: integer.valueof(int)
invoke(
opcodes.opc_invokestatic,
1, // receiverandargssize
1, // return type size
constantpool.javalangintegerconstantpoolname,
constantpool.valueof,
constantpool.intintegersignature);
} else {
// new integer(int)
newwrapperfor(unboxedtypeid);
dup_x1();
swap();
invoke(
opcodes.opc_invokespecial,
2, // receiverandargssize
0, // return type size
constantpool.javalangintegerconstantpoolname,
constantpool.init,
constantpool.intconstrsignature);
}
break;
case typeids.t_long :
if (this.targetlevel >= classfileconstants.jdk1_5) {
// invokestatic: long.valueof(long)
invoke(
opcodes.opc_invokestatic,
2, // receiverandargssize
1, // return type size
constantpool.javalanglongconstantpoolname,
constantpool.valueof,
constantpool.longlongsignature);
} else {
// new long( long )
newwrapperfor(unboxedtypeid);
dup_x2();
dup_x2();
pop();
invoke(
opcodes.opc_invokespecial,
3, // receiverandargssize
0, // return type size
constantpool.javalanglongconstantpoolname,
constantpool.init,
constantpool.longconstrsignature);
}
break;
case typeids.t_float :
if ( this.targetlevel >= classfileconstants.jdk1_5 ) {
// invokestatic: float.valueof(float)
invoke(
opcodes.opc_invokestatic,
1, // receiverandargssize
1, // return type size
constantpool.javalangfloatconstantpoolname,
constantpool.valueof,
constantpool.floatfloatsignature);
} else {
// new float(float)
newwrapperfor(unboxedtypeid);
dup_x1();
swap();
invoke(
opcodes.opc_invokespecial,
2, // receiverandargssize
0, // return type size
constantpool.javalangfloatconstantpoolname,
constantpool.init,
constantpool.floatconstrsignature);
}
break;
case typeids.t_double :
if ( this.targetlevel >= classfileconstants.jdk1_5 ) {
// invokestatic: double.valueof(double)
invoke(
opcodes.opc_invokestatic,
2, // receiverandargssize
1, // return type size
constantpool.javalangdoubleconstantpoolname,
constantpool.valueof,
constantpool.doubledoublesignature);
} else {
// new double( double )
newwrapperfor(unboxedtypeid);
dup_x2();
dup_x2();
pop();

invoke(
opcodes.opc_invokespecial,
3, // receiverandargssize
0, // return type size
constantpool.javalangdoubleconstantpoolname,
constantpool.init,
constantpool.doubleconstrsignature);
}

break;
case typeids.t_boolean :
if ( this.targetlevel >= classfileconstants.jdk1_5 ) {
// invokestatic: boolean.valueof(boolean)
invoke(
opcodes.opc_invokestatic,
1, // receiverandargssize
1, // return type size
constantpool.javalangbooleanconstantpoolname,
constantpool.valueof,
constantpool.booleanbooleansignature);
} else {
// new boolean(boolean)
newwrapperfor(unboxedtypeid);
dup_x1();
swap();
invoke(
opcodes.opc_invokespecial,
2, // receiverandargssize
0, // return type size
constantpool.javalangbooleanconstantpoolname,
constantpool.init,
constantpool.booleanconstrsignature);
}
}
}

/**
* macro for building a class descriptor object
*/
public void generateclassliteralaccessfortype(typebinding accessedtype, fieldbinding syntheticfieldbinding) {
if (accessedtype.isbasetype() && accessedtype != typebinding.null) {
gettype(accessedtype.id);
return;
}
if (this.targetlevel >= classfileconstants.jdk1_5) {
// generation using the new ldc_w bytecode
this.ldc(accessedtype);
} else {
branchlabel endlabel = new branchlabel(this);
if (syntheticfieldbinding != null) { // non interface case
fieldaccess(opcodes.opc_getstatic, syntheticfieldbinding, null /* default declaringclass */);
dup();
ifnonnull(endlabel);
pop();
}

/* macro for building a class descriptor object... using or not a field cache to store it into...
this sequence is responsible for building the actual class descriptor.

if the fieldcache is set, then it is supposed to be the body of a synthetic access method
factoring the actual descriptor creation out of the invocation site (saving space).
if the fieldcache is nil, then we are dumping the bytecode on the invocation site, since
we have no way to get a hand on the field cache to do better. */


// wrap the code in an exception handler to convert a classnotfoundexception into a noclassdeferror

exceptionlabel classnotfoundexceptionhandler = new exceptionlabel(this, typebinding.null /*represents classnotfoundexception*/);
classnotfoundexceptionhandler.placestart();
this.ldc(accessedtype == typebinding.null ? "java.lang.object" : string.valueof(accessedtype.constantpoolname()).replace('/', '.')); //$non-nls-1$
invokeclassforname();

/* see https://bugs.eclipse.org/bugs/show_bug.cgi?id=37565
if (accessedtype == basetypes.nullbinding) {
this.ldc("java.lang.object"); //$non-nls-1$
} else if (accessedtype.isarraytype()) {
this.ldc(string.valueof(accessedtype.constantpoolname()).replace('/', '.'));
} else {
// we make it an array type (to avoid class initialization)
this.ldc("[l" + string.valueof(accessedtype.constantpoolname()).replace('/', '.') + ";"); //$non-nls-1$//$non-nls-2$
}
this.invokeclassforname();
if (!accessedtype.isarraytype()) { // extract the component type, which doesn't initialize the class
this.invokejavalangclassgetcomponenttype();
}
*/
/* we need to protect the runtime code from binary inconsistencies
in case the accessedtype is missing, the classnotfoundexception has to be converted
into a noclassdeferror(old ex message), we thus need to build an exception handler for this one. */
classnotfoundexceptionhandler.placeend();

if (syntheticfieldbinding != null) { // non interface case
dup();
fieldaccess(opcodes.opc_putstatic, syntheticfieldbinding, null /* default declaringclass */);
}
goto_(endlabel);

int savedstackdepth = this.stackdepth;
// generate the body of the exception handler
/* classnotfoundexception on stack -- the class literal could be doing more things
on the stack, which means that the stack may not be empty at this point in the
above code gen. so we save its state and restart it from 1. */

pushexceptiononstack(typebinding.null);/*represents classnotfoundexception*/
classnotfoundexceptionhandler.place();

// transform the current exception, and repush and throw a
// noclassdeffounderror(classnotfound.getmessage())

newnoclassdeffounderror();
dup_x1();
this.swap();

// retrieve the message from the old exception
invokethrowablegetmessage();

// send the constructor taking a message string as an argument
invokenoclassdeffounderrorstringconstructor();
athrow();
endlabel.place();
this.stackdepth = savedstackdepth;
}
}

/**
* this method generates the code attribute bytecode
*/
final public void generatecodeattributeforproblemmethod(string problemmessage) {
newjavalangerror();
dup();
ldc(problemmessage);
invokejavalangerrorconstructor();
athrow();
}

public void generateconstant(constant constant, int implicitconversioncode) {
int targettypeid = (implicitconversioncode & typeids.implicit_conversion_mask) >> 4;
if (targettypeid == 0) targettypeid = constant.typeid(); // use default constant type
switch (targettypeid) {
case typeids.t_boolean :
generateinlinedvalue(constant.booleanvalue());
break;
case typeids.t_char :
generateinlinedvalue(constant.charvalue());
break;
case typeids.t_byte :
generateinlinedvalue(constant.bytevalue());
break;
case typeids.t_short :
generateinlinedvalue(constant.shortvalue());
break;
case typeids.t_int :
generateinlinedvalue(constant.intvalue());
break;
case typeids.t_long :
generateinlinedvalue(constant.longvalue());
break;
case typeids.t_float :
generateinlinedvalue(constant.floatvalue());
break;
case typeids.t_double :
generateinlinedvalue(constant.doublevalue());
break;
case typeids.t_javalangstring :
ldc(constant.stringvalue());
}
if ((implicitconversioncode & typeids.boxing) != 0) {
// need boxing
generateboxingconversion(targettypeid);
}
}

public void generateemulatedreadaccessforfield(fieldbinding fieldbinding) {
generateemulationforfield(fieldbinding);
// swap  the field with the receiver
this.swap();
invokejavalangreflectfieldgetter(fieldbinding.type.id);
if (!fieldbinding.type.isbasetype()) {
this.checkcast(fieldbinding.type);
}
}

public void generateemulatedwriteaccessforfield(fieldbinding fieldbinding) {
invokejavalangreflectfieldsetter(fieldbinding.type.id);
}

public void generateemulationforconstructor(scope scope, methodbinding methodbinding) {
// leave a java.lang.reflect.field object on the stack
this.ldc(string.valueof(methodbinding.declaringclass.constantpoolname()).replace('/', '.'));
invokeclassforname();
int paramlength = methodbinding.parameters.length;
this.generateinlinedvalue(paramlength);
newarray(scope.createarraytype(scope.gettype(typeconstants.java_lang_class, 3), 1));
if (paramlength > 0) {
dup();
for (int i = 0; i < paramlength; i++) {
this.generateinlinedvalue(i);
typebinding parameter = methodbinding.parameters[i];
if (parameter.isbasetype()) {
gettype(parameter.id);
} else if (parameter.isarraytype()) {
arraybinding array = (arraybinding)parameter;
if (array.leafcomponenttype.isbasetype()) {
gettype(array.leafcomponenttype.id);
} else {
this.ldc(string.valueof(array.leafcomponenttype.constantpoolname()).replace('/', '.'));
invokeclassforname();
}
int dimensions = array.dimensions;
this.generateinlinedvalue(dimensions);
newarray(typeids.t_int);
invokearraynewinstance();
invokeobjectgetclass();
} else {
// parameter is a reference binding
this.ldc(string.valueof(methodbinding.declaringclass.constantpoolname()).replace('/', '.'));
invokeclassforname();
}
aastore();
if (i < paramlength - 1) {
dup();
}
}
}
invokeclassgetdeclaredconstructor();
dup();
iconst_1();
invokeaccessibleobjectsetaccessible();
}

public void generateemulationforfield(fieldbinding fieldbinding) {
// leave a java.lang.reflect.field object on the stack
this.ldc(string.valueof(fieldbinding.declaringclass.constantpoolname()).replace('/', '.'));
invokeclassforname();
this.ldc(string.valueof(fieldbinding.name));
invokeclassgetdeclaredfield();
dup();
iconst_1();
invokeaccessibleobjectsetaccessible();
}

public void generateemulationformethod(scope scope, methodbinding methodbinding) {
// leave a java.lang.reflect.field object on the stack
this.ldc(string.valueof(methodbinding.declaringclass.constantpoolname()).replace('/', '.'));
invokeclassforname();
this.ldc(string.valueof(methodbinding.selector));
int paramlength = methodbinding.parameters.length;
this.generateinlinedvalue(paramlength);
newarray(scope.createarraytype(scope.gettype(typeconstants.java_lang_class, 3), 1));
if (paramlength > 0) {
dup();
for (int i = 0; i < paramlength; i++) {
this.generateinlinedvalue(i);
typebinding parameter = methodbinding.parameters[i];
if (parameter.isbasetype()) {
gettype(parameter.id);
} else if (parameter.isarraytype()) {
arraybinding array = (arraybinding)parameter;
if (array.leafcomponenttype.isbasetype()) {
gettype(array.leafcomponenttype.id);
} else {
this.ldc(string.valueof(array.leafcomponenttype.constantpoolname()).replace('/', '.'));
invokeclassforname();
}
int dimensions = array.dimensions;
this.generateinlinedvalue(dimensions);
newarray(typeids.t_int);
invokearraynewinstance();
invokeobjectgetclass();
} else {
// parameter is a reference binding
this.ldc(string.valueof(methodbinding.declaringclass.constantpoolname()).replace('/', '.'));
invokeclassforname();
}
aastore();
if (i < paramlength - 1) {
dup();
}
}
}
invokeclassgetdeclaredmethod();
dup();
iconst_1();
invokeaccessibleobjectsetaccessible();
}

/**
* generates the sequence of instructions which will perform the conversion of the expression
* on the stack into a different type (e.g. long l = someint; --> i2l must be inserted).
* @@param implicitconversioncode int
*/
public void generateimplicitconversion(int implicitconversioncode) {
if ((implicitconversioncode & typeids.unboxing) != 0) {
final int typeid = implicitconversioncode & typeids.compile_type_mask;
generateunboxingconversion(typeid);
// unboxing can further involve base type conversions
}
switch (implicitconversioncode & typeids.implicit_conversion_mask) {
case typeids.float2char :
f2i();
i2c();
break;
case typeids.double2char :
d2i();
i2c();
break;
case typeids.int2char :
case typeids.short2char :
case typeids.byte2char :
i2c();
break;
case typeids.long2char :
l2i();
i2c();
break;
case typeids.char2float :
case typeids.short2float :
case typeids.int2float :
case typeids.byte2float :
i2f();
break;
case typeids.double2float :
d2f();
break;
case typeids.long2float :
l2f();
break;
case typeids.float2byte :
f2i();
i2b();
break;
case typeids.double2byte :
d2i();
i2b();
break;
case typeids.int2byte :
case typeids.short2byte :
case typeids.char2byte :
i2b();
break;
case typeids.long2byte :
l2i();
i2b();
break;
case typeids.byte2double :
case typeids.char2double :
case typeids.short2double :
case typeids.int2double :
i2d();
break;
case typeids.float2double :
f2d();
break;
case typeids.long2double :
l2d();
break;
case typeids.byte2short :
case typeids.char2short :
case typeids.int2short :
i2s();
break;
case typeids.double2short :
d2i();
i2s();
break;
case typeids.long2short :
l2i();
i2s();
break;
case typeids.float2short :
f2i();
i2s();
break;
case typeids.double2int :
d2i();
break;
case typeids.float2int :
f2i();
break;
case typeids.long2int :
l2i();
break;
case typeids.int2long :
case typeids.char2long :
case typeids.byte2long :
case typeids.short2long :
i2l();
break;
case typeids.double2long :
d2l();
break;
case typeids.float2long :
f2l();
}
if ((implicitconversioncode & typeids.boxing) != 0) {
// need to unbox/box the constant
final int typeid = (implicitconversioncode & typeids.implicit_conversion_mask) >> 4;
generateboxingconversion(typeid);
}
}

public void generateinlinedvalue(boolean inlinedvalue) {
if (inlinedvalue)
iconst_1();
else
iconst_0();
}

public void generateinlinedvalue(byte inlinedvalue) {
switch (inlinedvalue) {
case -1 :
iconst_m1();
break;
case 0 :
iconst_0();
break;
case 1 :
iconst_1();
break;
case 2 :
iconst_2();
break;
case 3 :
iconst_3();
break;
case 4 :
iconst_4();
break;
case 5 :
iconst_5();
break;
default :
if ((-128 <= inlinedvalue) && (inlinedvalue <= 127)) {
bipush(inlinedvalue);
return;
}
}
}

public void generateinlinedvalue(char inlinedvalue) {
switch (inlinedvalue) {
case 0 :
iconst_0();
break;
case 1 :
iconst_1();
break;
case 2 :
iconst_2();
break;
case 3 :
iconst_3();
break;
case 4 :
iconst_4();
break;
case 5 :
iconst_5();
break;
default :
if ((6 <= inlinedvalue) && (inlinedvalue <= 127)) {
bipush((byte) inlinedvalue);
return;
}
if ((128 <= inlinedvalue) && (inlinedvalue <= 32767)) {
sipush(inlinedvalue);
return;
}
this.ldc(inlinedvalue);
}
}

public void generateinlinedvalue(double inlinedvalue) {
if (inlinedvalue == 0.0) {
if (double.doubletolongbits(inlinedvalue) != 0l)
this.ldc2_w(inlinedvalue);
else
dconst_0();
return;
}
if (inlinedvalue == 1.0) {
dconst_1();
return;
}
this.ldc2_w(inlinedvalue);
}

public void generateinlinedvalue(float inlinedvalue) {
if (inlinedvalue == 0.0f) {
if (float.floattointbits(inlinedvalue) != 0)
this.ldc(inlinedvalue);
else
fconst_0();
return;
}
if (inlinedvalue == 1.0f) {
fconst_1();
return;
}
if (inlinedvalue == 2.0f) {
fconst_2();
return;
}
this.ldc(inlinedvalue);
}

public void generateinlinedvalue(int inlinedvalue) {
switch (inlinedvalue) {
case -1 :
iconst_m1();
break;
case 0 :
iconst_0();
break;
case 1 :
iconst_1();
break;
case 2 :
iconst_2();
break;
case 3 :
iconst_3();
break;
case 4 :
iconst_4();
break;
case 5 :
iconst_5();
break;
default :
if ((-128 <= inlinedvalue) && (inlinedvalue <= 127)) {
bipush((byte) inlinedvalue);
return;
}
if ((-32768 <= inlinedvalue) && (inlinedvalue <= 32767)) {
sipush(inlinedvalue);
return;
}
this.ldc(inlinedvalue);
}
}

public void generateinlinedvalue(long inlinedvalue) {
if (inlinedvalue == 0) {
lconst_0();
return;
}
if (inlinedvalue == 1) {
lconst_1();
return;
}
this.ldc2_w(inlinedvalue);
}

public void generateinlinedvalue(short inlinedvalue) {
switch (inlinedvalue) {
case -1 :
iconst_m1();
break;
case 0 :
iconst_0();
break;
case 1 :
iconst_1();
break;
case 2 :
iconst_2();
break;
case 3 :
iconst_3();
break;
case 4 :
iconst_4();
break;
case 5 :
iconst_5();
break;
default :
if ((-128 <= inlinedvalue) && (inlinedvalue <= 127)) {
bipush((byte) inlinedvalue);
return;
}
sipush(inlinedvalue);
}
}

public void generateouteraccess(object[] mappingsequence, astnode invocationsite, binding target, scope scope) {
if (mappingsequence == null) {
if (target instanceof localvariablebinding) {
scope.problemreporter().needimplementation(invocationsite); //todo (philippe) should improve local emulation failure reporting
} else {
scope.problemreporter().nosuchenclosinginstance((referencebinding)target, invocationsite, false);
}
return;
}
if (mappingsequence == blockscope.noenclosinginstanceinconstructorcall) {
scope.problemreporter().nosuchenclosinginstance((referencebinding)target, invocationsite, true);
return;
} else if (mappingsequence == blockscope.noenclosinginstanceinstaticcontext) {
scope.problemreporter().nosuchenclosinginstance((referencebinding)target, invocationsite, false);
return;
}

if (mappingsequence == blockscope.emulationpathtoimplicitthis) {
aload_0();
return;
} else if (mappingsequence[0] instanceof fieldbinding) {
fieldbinding fieldbinding = (fieldbinding) mappingsequence[0];
aload_0();
fieldaccess(opcodes.opc_getfield, fieldbinding, null /* default declaringclass */);
} else {
load((localvariablebinding) mappingsequence[0]);
}
for (int i = 1, length = mappingsequence.length; i < length; i++) {
if (mappingsequence[i] instanceof fieldbinding) {
fieldbinding fieldbinding = (fieldbinding) mappingsequence[i];
fieldaccess(opcodes.opc_getfield, fieldbinding, null /* default declaringclass */);
} else {
invoke(opcodes.opc_invokestatic, (methodbinding) mappingsequence[i], null /* default declaringclass */);
}
}
}

public void generatereturnbytecode(expression expression) {
if (expression == null) {
return_();
} else {
final int implicitconversion = expression.implicitconversion;
if ((implicitconversion & typeids.boxing) != 0) {
areturn();
return;
}
int runtimetype = (implicitconversion & typeids.implicit_conversion_mask) >> 4;
switch (runtimetype) {
case typeids.t_boolean :
case typeids.t_int :
ireturn();
break;
case typeids.t_float :
freturn();
break;
case typeids.t_long :
lreturn();
break;
case typeids.t_double :
dreturn();
break;
default :
areturn();
}
}
}

/**
* the equivalent code performs a string conversion:
*
* @@param blockscope the given blockscope
* @@param oper1 the first expression
* @@param oper2 the second expression
*/
public void generatestringconcatenationappend(blockscope blockscope, expression oper1, expression oper2) {
int pc;
if (oper1 == null) {
/* operand is already on the stack, and maybe nil:
note type1 is always to  java.lang.string here.*/
newstringcontatenation();
dup_x1();
this.swap();
// if argument is reference type, need to transform it
// into a string (handles null case)
invokestringvalueof(typeids.t_javalangobject);
invokestringconcatenationstringconstructor();
} else {
pc = this.position;
oper1.generateoptimizedstringconcatenationcreation(blockscope, this, oper1.implicitconversion & typeids.compile_type_mask);
this.recordpositionsfrom(pc, oper1.sourcestart);
}
pc = this.position;
oper2.generateoptimizedstringconcatenation(blockscope, this, oper2.implicitconversion & typeids.compile_type_mask);
this.recordpositionsfrom(pc, oper2.sourcestart);
invokestringconcatenationtostring();
}

/**
* @@param accessbinding the access method binding to generate
*/
public void generatesyntheticbodyforconstructoraccess(syntheticmethodbinding accessbinding) {
initializemaxlocals(accessbinding);
methodbinding constructorbinding = accessbinding.targetmethod;
typebinding[] parameters = constructorbinding.parameters;
int length = parameters.length;
int resolvedposition = 1;
aload_0();
// special name&ordinal argument generation for enum constructors
typebinding declaringclass = constructorbinding.declaringclass;
if (declaringclass.erasure().id == typeids.t_javalangenum || declaringclass.isenum()) {
aload_1(); // pass along name param as name arg
iload_2(); // pass along ordinal param as ordinal arg
resolvedposition += 2;
}
if (declaringclass.isnestedtype()) {
nestedtypebinding nestedtype = (nestedtypebinding) declaringclass;
syntheticargumentbinding[] syntheticarguments = nestedtype.syntheticenclosinginstances();
for (int i = 0; i < (syntheticarguments == null ? 0 : syntheticarguments.length); i++) {
typebinding type;
load((type = syntheticarguments[i].type), resolvedposition);
switch(type.id) {
case typeids.t_long :
case typeids.t_double :
resolvedposition += 2;
break;
default :
resolvedposition++;
break;
}
}
}
for (int i = 0; i < length; i++) {
typebinding parameter;
load(parameter = parameters[i], resolvedposition);
switch(parameter.id) {
case typeids.t_long :
case typeids.t_double :
resolvedposition += 2;
break;
default :
resolvedposition++;
break;
}
}

if (declaringclass.isnestedtype()) {
nestedtypebinding nestedtype = (nestedtypebinding) declaringclass;
syntheticargumentbinding[] syntheticarguments = nestedtype.syntheticouterlocalvariables();
for (int i = 0; i < (syntheticarguments == null ? 0 : syntheticarguments.length); i++) {
typebinding type;
load(type = syntheticarguments[i].type, resolvedposition);
switch(type.id) {
case typeids.t_long :
case typeids.t_double :
resolvedposition += 2;
break;
default :
resolvedposition++;
break;
}
}
}
invoke(opcodes.opc_invokespecial, constructorbinding, null /* default declaringclass */);
return_();
}

//static x valueof(string name) {
// return (x) enum.valueof(x.class, name);
//}
public void generatesyntheticbodyforenumvalueof(syntheticmethodbinding methodbinding) {
initializemaxlocals(methodbinding);
final referencebinding declaringclass = methodbinding.declaringclass;
generateclassliteralaccessfortype(declaringclass, null);
aload_0();
invokejavalangenumvalueof(declaringclass);
this.checkcast(declaringclass);
areturn();
}

//static x[] values() {
// x[] values;
// int length;
// x[] result;
// system.arraycopy(values = $values, 0, result = new x[length= values.length], 0, length)
// return result;
//}
public void generatesyntheticbodyforenumvalues(syntheticmethodbinding methodbinding) {
classscope scope = ((sourcetypebinding)methodbinding.declaringclass).scope;
initializemaxlocals(methodbinding);
typebinding enumarray = methodbinding.returntype;
fieldaccess(opcodes.opc_getstatic, scope.referencecontext.enumvaluessyntheticfield, null /* default declaringclass */);
dup();
astore_0();
iconst_0();
aload_0();
arraylength();
dup();
istore_1();
newarray((arraybinding) enumarray);
dup();
astore_2();
iconst_0();
iload_1();
invokesystemarraycopy();
aload_2();
areturn();
}

public void generatesyntheticbodyforfieldreadaccess(syntheticmethodbinding accessmethod) {
initializemaxlocals(accessmethod);
fieldbinding fieldbinding = accessmethod.targetreadfield;
// target method declaring class may not be accessible (247953);
typebinding declaringclass = accessmethod.purpose == syntheticmethodbinding.superfieldreadaccess
? accessmethod.declaringclass.superclass()
: accessmethod.declaringclass;
if (fieldbinding.isstatic()) {
fieldaccess(opcodes.opc_getstatic, fieldbinding, declaringclass);
} else {
aload_0();
fieldaccess(opcodes.opc_getfield, fieldbinding, declaringclass);
}
switch (fieldbinding.type.id) {
//		case t_void :
//			this.return_();
//			break;
case typeids.t_boolean :
case typeids.t_byte :
case typeids.t_char :
case typeids.t_short :
case typeids.t_int :
ireturn();
break;
case typeids.t_long :
lreturn();
break;
case typeids.t_float :
freturn();
break;
case typeids.t_double :
dreturn();
break;
default :
areturn();
}
}

public void generatesyntheticbodyforfieldwriteaccess(syntheticmethodbinding accessmethod) {
initializemaxlocals(accessmethod);
fieldbinding fieldbinding = accessmethod.targetwritefield;
// target method declaring class may not be accessible (247953);
typebinding declaringclass = accessmethod.purpose == syntheticmethodbinding.superfieldwriteaccess
? accessmethod.declaringclass.superclass()
: accessmethod.declaringclass;
if (fieldbinding.isstatic()) {
load(fieldbinding.type, 0);
fieldaccess(opcodes.opc_putstatic, fieldbinding, declaringclass);
} else {
aload_0();
load(fieldbinding.type, 1);
fieldaccess(opcodes.opc_putfield, fieldbinding, declaringclass);
}
return_();
}

public void generatesyntheticbodyformethodaccess(syntheticmethodbinding accessmethod) {
initializemaxlocals(accessmethod);
methodbinding targetmethod = accessmethod.targetmethod;
typebinding[] parameters = targetmethod.parameters;
int length = parameters.length;
typebinding[] arguments = accessmethod.purpose == syntheticmethodbinding.bridgemethod
? accessmethod.parameters
: null;
int resolvedposition;
if (targetmethod.isstatic())
resolvedposition = 0;
else {
aload_0();
resolvedposition = 1;
}
for (int i = 0; i < length; i++) {
typebinding parameter = parameters[i];
if (arguments != null) { // for bridge methods
typebinding argument = arguments[i];
load(argument, resolvedposition);
if (argument != parameter)
checkcast(parameter);
} else {
load(parameter, resolvedposition);
}
switch(parameter.id) {
case typeids.t_long :
case typeids.t_double :
resolvedposition += 2;
break;
default :
resolvedposition++;
break;
}
}
if (targetmethod.isstatic())
invoke(opcodes.opc_invokestatic, targetmethod, accessmethod.declaringclass); // target method declaring class may not be accessible (128563)
else {
if (targetmethod.isconstructor()
|| targetmethod.isprivate()
// qualified super "x.super.foo()" targets methods from superclass
|| accessmethod.purpose == syntheticmethodbinding.supermethodaccess){
// target method declaring class may not be accessible (247953);
typebinding declaringclass = accessmethod.purpose == syntheticmethodbinding.supermethodaccess
? accessmethod.declaringclass.superclass()
: accessmethod.declaringclass;
invoke(opcodes.opc_invokespecial, targetmethod, declaringclass);
} else {
if (targetmethod.declaringclass.isinterface()) { // interface or annotation type
invoke(opcodes.opc_invokeinterface, targetmethod, null /* default declaringclass */);
} else {
invoke(opcodes.opc_invokevirtual, targetmethod, accessmethod.declaringclass); // target method declaring class may not be accessible (128563)
}
}
}
switch (targetmethod.returntype.id) {
case typeids.t_void :
return_();
break;
case typeids.t_boolean :
case typeids.t_byte :
case typeids.t_char :
case typeids.t_short :
case typeids.t_int :
ireturn();
break;
case typeids.t_long :
lreturn();
break;
case typeids.t_float :
freturn();
break;
case typeids.t_double :
dreturn();
break;
default :
typebinding accesserasure = accessmethod.returntype.erasure();
typebinding match = targetmethod.returntype.findsupertypeoriginatingfrom(accesserasure);
if (match == null) {
this.checkcast(accesserasure); // for bridge methods
}
areturn();
}
}

public void generatesyntheticbodyforswitchtable(syntheticmethodbinding methodbinding) {
classscope scope = ((sourcetypebinding)methodbinding.declaringclass).scope;
initializemaxlocals(methodbinding);
final branchlabel nulllabel = new branchlabel(this);
fieldbinding syntheticfieldbinding = methodbinding.targetreadfield;
fieldaccess(opcodes.opc_getstatic, syntheticfieldbinding, null /* default declaringclass */);
dup();
ifnull(nulllabel);
areturn();
pushonstack(syntheticfieldbinding.type);
nulllabel.place();
pop();
referencebinding enumbinding = (referencebinding) methodbinding.targetenumtype;
arraybinding arraybinding = scope.createarraytype(enumbinding, 1);
invokejavalangenumvalues(enumbinding, arraybinding);
arraylength();
newarray(classfileconstants.int_array);
astore_0();
localvariablebinding localvariablebinding = new localvariablebinding(" tab".tochararray(), scope.createarraytype(typebinding.int, 1), 0, false); //$non-nls-1$
addvariable(localvariablebinding);
final fieldbinding[] fields = enumbinding.fields();
if (fields != null) {
for (int i = 0, max = fields.length; i < max; i++) {
fieldbinding fieldbinding = fields[i];
if ((fieldbinding.getaccessflags() & classfileconstants.accenum) != 0) {
final branchlabel endlabel = new branchlabel(this);
final exceptionlabel anyexceptionhandler = new exceptionlabel(this, typebinding.long /* represents nosuchfielderror*/);
anyexceptionhandler.placestart();
aload_0();
fieldaccess(opcodes.opc_getstatic, fieldbinding, null /* default declaringclass */);
invokeenumordinal(enumbinding.constantpoolname());
this.generateinlinedvalue(fieldbinding.id + 1); // zero should not be returned see bug 141810
iastore();
anyexceptionhandler.placeend();
goto_(endlabel);
// generate the body of the exception handler
pushexceptiononstack(typebinding.long /*represents nosuchfielderror*/);
anyexceptionhandler.place();
pop(); // we don't use it so we can pop it
endlabel.place();
}
}
}
aload_0();
dup();
fieldaccess(opcodes.opc_putstatic, syntheticfieldbinding, null /* default declaringclass */);
areturn();
removevariable(localvariablebinding);
}

/**
* code responsible to generate the suitable code to supply values for the synthetic enclosing
* instance arguments of a constructor invocation of a nested type.
*/
public void generatesyntheticenclosinginstancevalues(blockscope currentscope, referencebinding targettype, expression enclosinginstance, astnode invocationsite) {
// supplying enclosing instance for the anonymous type's superclass
referencebinding checkedtargettype = targettype.isanonymoustype() ? (referencebinding)targettype.superclass().erasure() : targettype;
boolean hasextraenclosinginstance = enclosinginstance != null;
if (hasextraenclosinginstance
&& (!checkedtargettype.isnestedtype() || checkedtargettype.isstatic())) {
currentscope.problemreporter().unnecessaryenclosinginstancespecification(enclosinginstance, checkedtargettype);
return;
}

// perform some emulation work in case there is some and we are inside a local type only
referencebinding[] syntheticargumenttypes;
if ((syntheticargumenttypes = targettype.syntheticenclosinginstancetypes()) != null) {

referencebinding targetenclosingtype = checkedtargettype.enclosingtype();
long compliance = currentscope.compileroptions().compliancelevel;

// deny access to enclosing instance argument for allocation and super constructor call (if 1.4)
// always consider it if complying to 1.5
boolean denyenclosingarginconstructorcall;
if (compliance <= classfileconstants.jdk1_3) {
denyenclosingarginconstructorcall = invocationsite instanceof allocationexpression;
} else if (compliance == classfileconstants.jdk1_4){
denyenclosingarginconstructorcall = invocationsite instanceof allocationexpression
|| invocationsite instanceof explicitconstructorcall && ((explicitconstructorcall)invocationsite).issuperaccess();
} else {
//compliance >= jdk1_5
denyenclosingarginconstructorcall = (invocationsite instanceof allocationexpression
|| invocationsite instanceof explicitconstructorcall && ((explicitconstructorcall)invocationsite).issuperaccess())
&& !targettype.islocaltype();
}

boolean complyto14 = compliance >= classfileconstants.jdk1_4;
for (int i = 0, max = syntheticargumenttypes.length; i < max; i++) {
referencebinding syntheticargtype = syntheticargumenttypes[i];
if (hasextraenclosinginstance && syntheticargtype == targetenclosingtype) {
hasextraenclosinginstance = false;
enclosinginstance.generatecode(currentscope, this, true);
if (complyto14){
dup();
invokeobjectgetclass(); // will perform null check
pop();
}
} else {
object[] emulationpath = currentscope.getemulationpath(
syntheticargtype,
false /*not only exact match (that is, allow compatible)*/,
denyenclosingarginconstructorcall);
generateouteraccess(emulationpath, invocationsite, syntheticargtype, currentscope);
}
}
if (hasextraenclosinginstance){
currentscope.problemreporter().unnecessaryenclosinginstancespecification(enclosinginstance, checkedtargettype);
}
}
}

/**
* code responsible to generate the suitable code to supply values for the synthetic outer local
* variable arguments of a constructor invocation of a nested type.
* (bug 26122) - synthetic values for outer locals must be passed after user arguments, e.g. new x(i = 1){}
*/
public void generatesyntheticouterargumentvalues(blockscope currentscope, referencebinding targettype, astnode invocationsite) {
// generate the synthetic outer arguments then
syntheticargumentbinding syntheticarguments[];
if ((syntheticarguments = targettype.syntheticouterlocalvariables()) != null) {
for (int i = 0, max = syntheticarguments.length; i < max; i++) {
localvariablebinding targetvariable = syntheticarguments[i].actualouterlocalvariable;
variablebinding[] emulationpath = currentscope.getemulationpath(targetvariable);
generateouteraccess(emulationpath, invocationsite, targetvariable, currentscope);
}
}
}

public void generateunboxingconversion(int unboxedtypeid) {
switch (unboxedtypeid) {
case typeids.t_byte :
// invokevirtual: bytevalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangbyteconstantpoolname,
constantpool.bytevalue_byte_method_name,
constantpool.bytevalue_byte_method_signature);
break;
case typeids.t_short :
// invokevirtual: shortvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangshortconstantpoolname,
constantpool.shortvalue_short_method_name,
constantpool.shortvalue_short_method_signature);
break;
case typeids.t_char :
// invokevirtual: charvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangcharacterconstantpoolname,
constantpool.charvalue_character_method_name,
constantpool.charvalue_character_method_signature);
break;
case typeids.t_int :
// invokevirtual: intvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangintegerconstantpoolname,
constantpool.intvalue_integer_method_name,
constantpool.intvalue_integer_method_signature);
break;
case typeids.t_long :
// invokevirtual: longvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
2, // return type size
constantpool.javalanglongconstantpoolname,
constantpool.longvalue_long_method_name,
constantpool.longvalue_long_method_signature);
break;
case typeids.t_float :
// invokevirtual: floatvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangfloatconstantpoolname,
constantpool.floatvalue_float_method_name,
constantpool.floatvalue_float_method_signature);
break;
case typeids.t_double :
// invokevirtual: doublevalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
2, // return type size
constantpool.javalangdoubleconstantpoolname,
constantpool.doublevalue_double_method_name,
constantpool.doublevalue_double_method_signature);
break;
case typeids.t_boolean :
// invokevirtual: booleanvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangbooleanconstantpoolname,
constantpool.booleanvalue_boolean_method_name,
constantpool.booleanvalue_boolean_method_signature);
}
}

/*
* wide conditional branch compare, improved by swapping comparison opcode
*   ifeq widetarget
* becomes
*    ifne intermediate
*    gotow widetarget
*    intermediate:
*/
public void generatewiderevertedconditionalbranch(byte revertedopcode, branchlabel widetarget) {
branchlabel intermediate = new branchlabel(this);
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = revertedopcode;
intermediate.branch();
goto_w(widetarget);
intermediate.place();
}

public void getbasetypevalue(int basetypeid) {
switch (basetypeid) {
case typeids.t_byte :
// invokevirtual: bytevalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangbyteconstantpoolname,
constantpool.bytevalue_byte_method_name,
constantpool.bytevalue_byte_method_signature);
break;
case typeids.t_short :
// invokevirtual: shortvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangshortconstantpoolname,
constantpool.shortvalue_short_method_name,
constantpool.shortvalue_short_method_signature);
break;
case typeids.t_char :
// invokevirtual: charvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangcharacterconstantpoolname,
constantpool.charvalue_character_method_name,
constantpool.charvalue_character_method_signature);
break;
case typeids.t_int :
// invokevirtual: intvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangintegerconstantpoolname,
constantpool.intvalue_integer_method_name,
constantpool.intvalue_integer_method_signature);
break;
case typeids.t_long :
// invokevirtual: longvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
2, // return type size
constantpool.javalanglongconstantpoolname,
constantpool.longvalue_long_method_name,
constantpool.longvalue_long_method_signature);
break;
case typeids.t_float :
// invokevirtual: floatvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangfloatconstantpoolname,
constantpool.floatvalue_float_method_name,
constantpool.floatvalue_float_method_signature);
break;
case typeids.t_double :
// invokevirtual: doublevalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
2, // return type size
constantpool.javalangdoubleconstantpoolname,
constantpool.doublevalue_double_method_name,
constantpool.doublevalue_double_method_signature);
break;
case typeids.t_boolean :
// invokevirtual: booleanvalue()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangbooleanconstantpoolname,
constantpool.booleanvalue_boolean_method_name,
constantpool.booleanvalue_boolean_method_signature);
}
}

final public byte[] getcontents() {
byte[] contents;
system.arraycopy(this.bcodestream, 0, contents = new byte[this.position], 0, this.position);
return contents;
}

/**
* returns the type that should be substituted to original binding declaring class as the proper receiver type
* @@param currentscope
* @@param codegenbinding
* @@param actualreceivertype
* @@param isimplicitthisreceiver
* @@return the receiver type to use in constant pool
*/
public static typebinding getconstantpooldeclaringclass(scope currentscope, fieldbinding codegenbinding, typebinding actualreceivertype, boolean isimplicitthisreceiver) {
referencebinding constantpooldeclaringclass = codegenbinding.declaringclass;
// if the binding declaring class is not visible, need special action
// for runtime compatibility on 1.2 vms : change the declaring class of the binding
// note: from target 1.2 on, field's declaring class is touched if any different from receiver type
// and not from object or implicit static field access.
if (constantpooldeclaringclass != actualreceivertype.erasure()
&& !actualreceivertype.isarraytype()
&& constantpooldeclaringclass != null // array.length
&& codegenbinding.constant() == constant.notaconstant) {
compileroptions options = currentscope.compileroptions();
if ((options.targetjdk >= classfileconstants.jdk1_2
&& (options.compliancelevel >= classfileconstants.jdk1_4 || !(isimplicitthisreceiver && codegenbinding.isstatic()))
&& constantpooldeclaringclass.id != typeids.t_javalangobject) // no change for object fields
|| !constantpooldeclaringclass.canbeseenby(currentscope)) {

return actualreceivertype.erasure();
}
}
return constantpooldeclaringclass;
}

/**
* returns the type that should be substituted to original binding declaring class as the proper receiver type
* @@param currentscope
* @@param codegenbinding
* @@param actualreceivertype
* @@param isimplicitthisreceiver
* @@return the receiver type to use in constant pool
*/
public static typebinding getconstantpooldeclaringclass(scope currentscope, methodbinding codegenbinding, typebinding actualreceivertype, boolean isimplicitthisreceiver) {
typebinding constantpooldeclaringclass = codegenbinding.declaringclass;
// post 1.4.0 target, array clone() invocations are qualified with array type
// this is handled in array type #clone method binding resolution (see scope and updatedmethodbinding)
if (codegenbinding == currentscope.environment().arrayclone) {
compileroptions options = currentscope.compileroptions();
if (options.sourcelevel > classfileconstants.jdk1_4 ) {
constantpooldeclaringclass = actualreceivertype.erasure();
}
} else {
// if the binding declaring class is not visible, need special action
// for runtime compatibility on 1.2 vms : change the declaring class of the binding
// note: from target 1.2 on, method's declaring class is touched if any different from receiver type
// and not from object or implicit static method call.
if (constantpooldeclaringclass != actualreceivertype.erasure() && !actualreceivertype.isarraytype()) {
compileroptions options = currentscope.compileroptions();
if ((options.targetjdk >= classfileconstants.jdk1_2
&& (options.compliancelevel >= classfileconstants.jdk1_4 || !(isimplicitthisreceiver && codegenbinding.isstatic()))
&& codegenbinding.declaringclass.id != typeids.t_javalangobject) // no change for object methods
|| !codegenbinding.declaringclass.canbeseenby(currentscope)) {
constantpooldeclaringclass = actualreceivertype.erasure();
}
}
}
return constantpooldeclaringclass;
}
protected int getposition() {
return this.position;
}

public void gettype(int basetypeid) {
this.countlabels = 0;
switch (basetypeid) {
case typeids.t_byte :
// getstatic: java.lang.byte.type
fieldaccess(
opcodes.opc_getstatic,
1, // return type size
constantpool.javalangbyteconstantpoolname,
constantpool.type,
constantpool.javalangclasssignature);
break;
case typeids.t_short :
// getstatic: java.lang.short.type
fieldaccess(
opcodes.opc_getstatic,
1, // return type size
constantpool.javalangshortconstantpoolname,
constantpool.type,
constantpool.javalangclasssignature);
break;
case typeids.t_char :
// getstatic: java.lang.character.type
fieldaccess(
opcodes.opc_getstatic,
1, // return type size
constantpool.javalangcharacterconstantpoolname,
constantpool.type,
constantpool.javalangclasssignature);
break;
case typeids.t_int :
// getstatic: java.lang.integer.type
fieldaccess(
opcodes.opc_getstatic,
1, // return type size
constantpool.javalangintegerconstantpoolname,
constantpool.type,
constantpool.javalangclasssignature);
break;
case typeids.t_long :
// getstatic: java.lang.long.type
fieldaccess(
opcodes.opc_getstatic,
1, // return type size
constantpool.javalanglongconstantpoolname,
constantpool.type,
constantpool.javalangclasssignature);
break;
case typeids.t_float :
// getstatic: java.lang.float.type
fieldaccess(
opcodes.opc_getstatic,
1, // return type size
constantpool.javalangfloatconstantpoolname,
constantpool.type,
constantpool.javalangclasssignature);
break;
case typeids.t_double :
// getstatic: java.lang.double.type
fieldaccess(
opcodes.opc_getstatic,
1, // return type size
constantpool.javalangdoubleconstantpoolname,
constantpool.type,
constantpool.javalangclasssignature);
break;
case typeids.t_boolean :
// getstatic: java.lang.boolean.type
fieldaccess(
opcodes.opc_getstatic,
1, // return type size
constantpool.javalangbooleanconstantpoolname,
constantpool.type,
constantpool.javalangclasssignature);
break;
case typeids.t_void :
// getstatic: java.lang.void.type
fieldaccess(
opcodes.opc_getstatic,
1, // return type size
constantpool.javalangvoidconstantpoolname,
constantpool.type,
constantpool.javalangclasssignature);
break;
}
}

/**
* we didn't call it goto, because there is a conflit with the goto keyword
*/
public void goto_(branchlabel label) {
if (this.widemode) {
goto_w(label);
return;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
boolean chained = inlineforwardreferencesfromlabelstargeting(label, this.position);
/*
possible optimization for code such as:
public object foo() {
boolean b = true;
if (b) {
if (b)
return null;
} else {
if (b) {
return null;
}
}
return null;
}
the goto around the else block for the first if will
be unreachable, because the thenclause of the second if
returns. also see 114894
}*/
if (chained && this.lastabruptcompletion == this.position) {
if (label.position != label.pos_not_set) { // ensure existing forward references are updated
int[] forwardrefs = label.forwardreferences();
for (int i = 0, max = label.forwardreferencecount(); i < max; i++) {
this.writeposition(label, forwardrefs[i]);
}
this.countlabels = 0; // backward jump, no further chaining allowed
}
return;
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_goto;
label.branch();
this.lastabruptcompletion = this.position;
}

public void goto_w(branchlabel label) {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_goto_w;
label.branchwide();
this.lastabruptcompletion = this.position;
}

public void i2b() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_i2b;
}

public void i2c() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_i2c;
}

public void i2d() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_i2d;
}

public void i2f() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_i2f;
}

public void i2l() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_i2l;
}

public void i2s() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_i2s;
}

public void iadd() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iadd;
}

public void iaload() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iaload;
}

public void iand() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iand;
}

public void iastore() {
this.countlabels = 0;
this.stackdepth -= 3;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iastore;
}

public void iconst_0() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iconst_0;
}

public void iconst_1() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iconst_1;
}

public void iconst_2() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iconst_2;
}
public void iconst_3() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iconst_3;
}

public void iconst_4() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iconst_4;
}

public void iconst_5() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iconst_5;
}

public void iconst_m1() {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iconst_m1;
}

public void idiv() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_idiv;
}

public void if_acmpeq(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth-=2;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_if_acmpne, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_if_acmpeq;
lbl.branch();
}
}

public void if_acmpne(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth-=2;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_if_acmpeq, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_if_acmpne;
lbl.branch();
}
}

public void if_icmpeq(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_if_icmpne, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_if_icmpeq;
lbl.branch();
}
}

public void if_icmpge(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_if_icmplt, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_if_icmpge;
lbl.branch();
}
}

public void if_icmpgt(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_if_icmple, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_if_icmpgt;
lbl.branch();
}
}

public void if_icmple(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_if_icmpgt, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_if_icmple;
lbl.branch();
}
}

public void if_icmplt(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_if_icmpge, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_if_icmplt;
lbl.branch();
}
}

public void if_icmpne(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_if_icmpeq, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_if_icmpne;
lbl.branch();
}
}

public void ifeq(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth--;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_ifne, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ifeq;
lbl.branch();
}
}

public void ifge(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth--;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_iflt, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ifge;
lbl.branch();
}
}

public void ifgt(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth--;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_ifle, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ifgt;
lbl.branch();
}
}

public void ifle(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth--;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_ifgt, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ifle;
lbl.branch();
}
}

public void iflt(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth--;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_ifge, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iflt;
lbl.branch();
}
}

public void ifne(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth--;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_ifeq, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ifne;
lbl.branch();
}
}

public void ifnonnull(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth--;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_ifnull, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ifnonnull;
lbl.branch();
}
}

public void ifnull(branchlabel lbl) {
this.countlabels = 0;
this.stackdepth--;
if (this.widemode) {
generatewiderevertedconditionalbranch(opcodes.opc_ifnonnull, lbl);
} else {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ifnull;
lbl.branch();
}
}

final public void iinc(int index, int value) {
this.countlabels = 0;
if ((index > 255) || (value < -128 || value > 127)) { // have to widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iinc;
writeunsignedshort(index);
writesignedshort(value);
} else {
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 3;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iinc;
this.bcodestream[this.classfileoffset++] = (byte) index;
this.bcodestream[this.classfileoffset++] = (byte) value;
}
}

public void iload(int iarg) {
this.countlabels = 0;
this.stackdepth++;
if (this.maxlocals <= iarg) {
this.maxlocals = iarg + 1;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (iarg > 255) { // widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iload;
writeunsignedshort(iarg);
} else {
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iload;
this.bcodestream[this.classfileoffset++] = (byte) iarg;
}
}

public void iload_0() {
this.countlabels = 0;
this.stackdepth++;
if (this.maxlocals <= 0) {
this.maxlocals = 1;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iload_0;
}

public void iload_1() {
this.countlabels = 0;
this.stackdepth++;
if (this.maxlocals <= 1) {
this.maxlocals = 2;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iload_1;
}

public void iload_2() {
this.countlabels = 0;
this.stackdepth++;
if (this.maxlocals <= 2) {
this.maxlocals = 3;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iload_2;
}

public void iload_3() {
this.countlabels = 0;
this.stackdepth++;
if (this.maxlocals <= 3) {
this.maxlocals = 4;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iload_3;
}

public void imul() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_imul;
}

public int indexofsamelineentrysincepc(int pc, int line) {
for (int index = pc, max = this.pctosourcemapsize; index < max; index+=2) {
if (this.pctosourcemap[index+1] == line)
return index;
}
return -1;
}

public void ineg() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ineg;
}

public void init(classfile targetclassfile) {
this.classfile = targetclassfile;
this.constantpool = targetclassfile.constantpool;
this.bcodestream = targetclassfile.contents;
this.classfileoffset = targetclassfile.contentsoffset;
this.startingclassfileoffset = this.classfileoffset;
this.pctosourcemapsize = 0;
this.lastentrypc = 0;
int length = this.visiblelocals.length;
if (novisiblelocals.length < length) {
novisiblelocals = new localvariablebinding[length];
}
system.arraycopy(novisiblelocals, 0, this.visiblelocals, 0, length);
this.visiblelocalscount = 0;

length = this.locals.length;
if (nolocals.length < length) {
nolocals = new localvariablebinding[length];
}
system.arraycopy(nolocals, 0, this.locals, 0, length);
this.alllocalscounter = 0;

length = this.exceptionlabels.length;
if (noexceptionhandlers.length < length) {
noexceptionhandlers = new exceptionlabel[length];
}
system.arraycopy(noexceptionhandlers, 0, this.exceptionlabels, 0, length);
this.exceptionlabelscounter = 0;

length = this.labels.length;
if (nolabels.length < length) {
nolabels = new branchlabel[length];
}
system.arraycopy(nolabels, 0, this.labels, 0, length);
this.countlabels = 0;
this.lastabruptcompletion = -1;

this.stackmax = 0;
this.stackdepth = 0;
this.maxlocals = 0;
this.position = 0;
}

/**
* @@param methodbinding the given method binding to initialize the max locals
*/
public void initializemaxlocals(methodbinding methodbinding) {
if (methodbinding == null) {
this.maxlocals = 0;
return;
}
this.maxlocals = methodbinding.isstatic() ? 0 : 1;
referencebinding declaringclass = methodbinding.declaringclass;
// take into account enum constructor synthetic name+ordinal
if (methodbinding.isconstructor() && declaringclass.isenum()) {
this.maxlocals += 2; // string and int (enum constant name+ordinal)
}

// take into account the synthetic parameters
if (methodbinding.isconstructor() && declaringclass.isnestedtype()) {
this.maxlocals += declaringclass.getenclosinginstancesslotsize();
this.maxlocals += declaringclass.getouterlocalvariablesslotsize();
}
typebinding[] parametertypes;
if ((parametertypes = methodbinding.parameters) != null) {
for (int i = 0, max = parametertypes.length; i < max; i++) {
switch (parametertypes[i].id) {
case typeids.t_long :
case typeids.t_double :
this.maxlocals += 2;
break;
default:
this.maxlocals++;
}
}
}
}

/**
* some placed labels might be branching to a goto bytecode which we can optimize better.
*/
public boolean inlineforwardreferencesfromlabelstargeting(branchlabel targetlabel, int gotolocation) {
if (targetlabel.delegate != null) return false; // already inlined
int chaining = l_unknown;
for (int i = this.countlabels - 1; i >= 0; i--) {
branchlabel currentlabel = this.labels[i];
if (currentlabel.position != gotolocation) break;
if (currentlabel == targetlabel) {
chaining |= l_cannot_optimize; // recursive
continue;
}
if (currentlabel.isstandardlabel()) {
if (currentlabel.delegate != null) continue; // ignore since already inlined
targetlabel.becomedelegatefor(currentlabel);
chaining |= l_optimizable; // optimizable, providing no vetoing
continue;
}
// case label
chaining |= l_cannot_optimize;
}
return (chaining & (l_optimizable|l_cannot_optimize)) == l_optimizable; // check was some standards, and no case/recursive
}

/**
* we didn't call it instanceof because there is a conflit with the
* instanceof keyword
*/
public void instance_of(typebinding typebinding) {
this.countlabels = 0;
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_instanceof;
writeunsignedshort(this.constantpool.literalindexfortype(typebinding));
}

protected void invoke(byte opcode, int receiverandargssize, int returntypesize, char[] declaringclass, char[] selector, char[] signature) {
this.countlabels = 0;
if (opcode == opcodes.opc_invokeinterface) {
// invokeinterface
if (this.classfileoffset + 4 >= this.bcodestream.length) {
resizebytearray();
}
this.position +=3;
this.bcodestream[this.classfileoffset++] = opcode;
writeunsignedshort(this.constantpool.literalindexformethod(declaringclass, selector, signature, true));
this.bcodestream[this.classfileoffset++] = (byte) receiverandargssize;
this.bcodestream[this.classfileoffset++] = 0;
} else {
// invokespecial
// invokestatic
// invokevirtual
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcode;
writeunsignedshort(this.constantpool.literalindexformethod(declaringclass, selector, signature, false));
}
this.stackdepth += returntypesize - receiverandargssize;
if (this.stackdepth > this.stackmax) {
this.stackmax = this.stackdepth;
}
}

public void invoke(byte opcode, methodbinding methodbinding, typebinding declaringclass) {
if (declaringclass == null) declaringclass = methodbinding.declaringclass;
if ((declaringclass.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(this.classfile, declaringclass);
}
// compute receiverandargssize
int receiverandargssize;
switch(opcode) {
case opcodes.opc_invokestatic :
receiverandargssize = 0; // no receiver
break;
case opcodes.opc_invokeinterface :
case opcodes.opc_invokevirtual :
receiverandargssize = 1; // receiver
break;
case opcodes.opc_invokespecial :
receiverandargssize = 1; // receiver
if (methodbinding.isconstructor()) {
if (declaringclass.isnestedtype()) {
referencebinding nestedtype = (referencebinding) declaringclass;
// enclosing instances
receiverandargssize += nestedtype.getenclosinginstancesslotsize();
// outer local variables
syntheticargumentbinding[] syntheticarguments = nestedtype.syntheticouterlocalvariables();
if (syntheticarguments != null) {
for (int i = 0, max = syntheticarguments.length; i < max; i++) {
switch (syntheticarguments[i].id)  {
case typeids.t_double :
case typeids.t_long :
receiverandargssize += 2;
break;
default:
receiverandargssize++;
break;
}
}
}
}
if (declaringclass.isenum()) {
// adding string (name) and int (ordinal)
receiverandargssize += 2;
}
}
break;
default :
return; // should not occur

}
for (int i = methodbinding.parameters.length - 1; i >= 0; i--) {
switch (methodbinding.parameters[i].id) {
case typeids.t_double :
case typeids.t_long :
receiverandargssize += 2;
break;
default :
receiverandargssize ++;
break;
}
}
// compute return type size
int returntypesize;
switch (methodbinding.returntype.id) {
case typeids.t_double :
case typeids.t_long :
returntypesize = 2;
break;
case typeids.t_void :
returntypesize = 0;
break;
default :
returntypesize = 1;
break;
}
invoke(
opcode,
receiverandargssize,
returntypesize,
declaringclass.constantpoolname(),
methodbinding.selector,
methodbinding.signature(this.classfile));
}

protected void invokeaccessibleobjectsetaccessible() {
// invokevirtual: java.lang.reflect.accessibleobject.setaccessible(z)v;
invoke(
opcodes.opc_invokevirtual,
2, // receiverandargssize
0, // return type size
constantpool.javalangreflectaccessibleobject_constantpoolname,
constantpool.setaccessible_name,
constantpool.setaccessible_signature);
}

protected void invokearraynewinstance() {
// invokestatic: java.lang.reflect.array.newinstance(ljava.lang.class;int[])ljava.lang.object;
invoke(
opcodes.opc_invokestatic,
2, // receiverandargssize
1, // return type size
constantpool.javalangreflectarray_constantpoolname,
constantpool.newinstance,
constantpool.newinstancesignature);
}
public void invokeclassforname() {
// invokestatic: java.lang.class.forname(ljava.lang.string;)ljava.lang.class;
invoke(
opcodes.opc_invokestatic,
1, // receiverandargssize
1, // return type size
constantpool.javalangclassconstantpoolname,
constantpool.forname,
constantpool.fornamesignature);
}

protected void invokeclassgetdeclaredconstructor() {
// invokevirtual: java.lang.class getdeclaredconstructor([ljava.lang.class)ljava.lang.reflect.constructor;
invoke(
opcodes.opc_invokevirtual,
2, // receiverandargssize
1, // return type size
constantpool.javalangclassconstantpoolname,
constantpool.getdeclaredconstructor_name,
constantpool.getdeclaredconstructor_signature);
}

protected void invokeclassgetdeclaredfield() {
// invokevirtual: java.lang.class.getdeclaredfield(ljava.lang.string)ljava.lang.reflect.field;
invoke(
opcodes.opc_invokevirtual,
2, // receiverandargssize
1, // return type size
constantpool.javalangclassconstantpoolname,
constantpool.getdeclaredfield_name,
constantpool.getdeclaredfield_signature);
}

protected void invokeclassgetdeclaredmethod() {
// invokevirtual: java.lang.class getdeclaredmethod(ljava.lang.string, [ljava.lang.class)ljava.lang.reflect.method;
invoke(
opcodes.opc_invokevirtual,
3, // receiverandargssize
1, // return type size
constantpool.javalangclassconstantpoolname,
constantpool.getdeclaredmethod_name,
constantpool.getdeclaredmethod_signature);
}

public void invokeenumordinal(char[] enumtypeconstantpoolname) {
// invokevirtual: <enumconstantpoolname>.ordinal()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
enumtypeconstantpoolname,
constantpool.ordinal,
constantpool.ordinalsignature);
}

public void invokeiterableiterator(typebinding iterablereceivertype) {
// invokevirtual/interface: <iterablereceivertype>.iterator()
if ((iterablereceivertype.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(this.classfile, iterablereceivertype);
}
invoke(
iterablereceivertype.isinterface() ? opcodes.opc_invokeinterface : opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // returntypesize
iterablereceivertype.constantpoolname(),
constantpool.iterator_name,
constantpool.iterator_signature);
}

public void invokejavalangassertionerrorconstructor(int typebindingid) {
// invokespecial: java.lang.assertionerror.<init>(typebindingid)v
int receiverandargssize;
char[] signature;
switch (typebindingid) {
case typeids.t_int :
case typeids.t_byte :
case typeids.t_short :
signature = constantpool.intconstrsignature;
receiverandargssize = 2;
break;
case typeids.t_long :
signature = constantpool.longconstrsignature;
receiverandargssize = 3;
break;
case typeids.t_float :
signature = constantpool.floatconstrsignature;
receiverandargssize = 2;
break;
case typeids.t_double :
signature = constantpool.doubleconstrsignature;
receiverandargssize = 3;
break;
case typeids.t_char :
signature = constantpool.charconstrsignature;
receiverandargssize = 2;
break;
case typeids.t_boolean :
signature = constantpool.booleanconstrsignature;
receiverandargssize = 2;
break;
case typeids.t_javalangobject :
case typeids.t_javalangstring :
case typeids.t_null :
signature = constantpool.objectconstrsignature;
receiverandargssize = 2;
break;
default:
return; // should not occur
}
invoke(
opcodes.opc_invokespecial,
receiverandargssize,
0, // return type size
constantpool.javalangassertionerrorconstantpoolname,
constantpool.init,
signature);
}

public void invokejavalangassertionerrordefaultconstructor() {
// invokespecial: java.lang.assertionerror.<init>()v
invoke(
opcodes.opc_invokespecial,
1, // receiverandargssize
0, // return type size
constantpool.javalangassertionerrorconstantpoolname,
constantpool.init,
constantpool.defaultconstructorsignature);
}

public void invokejavalangclassdesiredassertionstatus() {
// invokevirtual: java.lang.class.desiredassertionstatus()z;
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangclassconstantpoolname,
constantpool.desiredassertionstatus,
constantpool.desiredassertionstatussignature);
}

public void invokejavalangenumvalueof(referencebinding binding) {
// invokestatic: java.lang.enum.valueof(class,string)
invoke(
opcodes.opc_invokestatic,
2, // receiverandargssize
1, // return type size
constantpool.javalangenumconstantpoolname,
constantpool.valueof,
constantpool.valueofstringclasssignature);
}

public void invokejavalangenumvalues(typebinding enumbinding, arraybinding arraybinding) {
char[] signature = "()".tochararray(); //$non-nls-1$
signature = charoperation.concat(signature, arraybinding.constantpoolname());
invoke(
opcodes.opc_invokestatic,
0,  // receiverandargssize
1,  // return type size
enumbinding.constantpoolname(),
typeconstants.values,
signature);
}

public void invokejavalangerrorconstructor() {
// invokespecial: java.lang.error<init>(ljava.lang.string;)v
invoke(
opcodes.opc_invokespecial,
2, // receiverandargssize
0, // return type size
constantpool.javalangerrorconstantpoolname,
constantpool.init,
constantpool.stringconstructorsignature);
}

public void invokejavalangreflectconstructornewinstance() {
// invokevirtual: java.lang.reflect.constructor.newinstance([ljava.lang.object;)ljava.lang.object;
invoke(
opcodes.opc_invokevirtual,
2, // receiverandargssize
1, // return type size
constantpool.javalangreflectconstructorconstantpoolname,
constantpool.newinstance,
constantpool.javalangreflectconstructornewinstancesignature);
}

protected void invokejavalangreflectfieldgetter(int typeid) {
char[] selector;
char[] signature;
int returntypesize;
switch (typeid) {
case typeids.t_int :
selector = constantpool.get_int_method_name;
signature = constantpool.get_int_method_signature;
returntypesize = 1;
break;
case typeids.t_byte :
selector = constantpool.get_byte_method_name;
signature = constantpool.get_byte_method_signature;
returntypesize = 1;
break;
case typeids.t_short :
selector = constantpool.get_short_method_name;
signature = constantpool.get_short_method_signature;
returntypesize = 1;
break;
case typeids.t_long :
selector = constantpool.get_long_method_name;
signature = constantpool.get_long_method_signature;
returntypesize = 2;
break;
case typeids.t_float :
selector = constantpool.get_float_method_name;
signature = constantpool.get_float_method_signature;
returntypesize = 1;
break;
case typeids.t_double :
selector = constantpool.get_double_method_name;
signature = constantpool.get_double_method_signature;
returntypesize = 2;
break;
case typeids.t_char :
selector = constantpool.get_char_method_name;
signature = constantpool.get_char_method_signature;
returntypesize = 1;
break;
case typeids.t_boolean :
selector = constantpool.get_boolean_method_name;
signature = constantpool.get_boolean_method_signature;
returntypesize = 1;
break;
default :
selector = constantpool.get_object_method_name;
signature = constantpool.get_object_method_signature;
returntypesize = 1;
break;
}
invoke(
opcodes.opc_invokevirtual,
2, // receiverandargssize
returntypesize, // return type size
constantpool.javalangreflectfield_constantpoolname,
selector,
signature);
}

protected void invokejavalangreflectfieldsetter(int typeid) {
char[] selector;
char[] signature;
int receiverandargssize;
switch (typeid) {
case typeids.t_int :
selector = constantpool.set_int_method_name;
signature = constantpool.set_int_method_signature;
receiverandargssize = 3;
break;
case typeids.t_byte :
selector = constantpool.set_byte_method_name;
signature = constantpool.set_byte_method_signature;
receiverandargssize = 3;
break;
case typeids.t_short :
selector = constantpool.set_short_method_name;
signature = constantpool.set_short_method_signature;
receiverandargssize = 3;
break;
case typeids.t_long :
selector = constantpool.set_long_method_name;
signature = constantpool.set_long_method_signature;
receiverandargssize = 4;
break;
case typeids.t_float :
selector = constantpool.set_float_method_name;
signature = constantpool.set_float_method_signature;
receiverandargssize = 3;
break;
case typeids.t_double :
selector = constantpool.set_double_method_name;
signature = constantpool.set_double_method_signature;
receiverandargssize = 4;
break;
case typeids.t_char :
selector = constantpool.set_char_method_name;
signature = constantpool.set_char_method_signature;
receiverandargssize = 3;
break;
case typeids.t_boolean :
selector = constantpool.set_boolean_method_name;
signature = constantpool.set_boolean_method_signature;
receiverandargssize = 3;
break;
default :
selector = constantpool.set_object_method_name;
signature = constantpool.set_object_method_signature;
receiverandargssize = 3;
break;
}
invoke(
opcodes.opc_invokevirtual,
receiverandargssize,
0, // return type size
constantpool.javalangreflectfield_constantpoolname,
selector,
signature);
}

public void invokejavalangreflectmethodinvoke() {
// invokevirtual: java.lang.reflect.method.invoke(ljava.lang.object;[ljava.lang.object;)ljava.lang.object;
invoke(
opcodes.opc_invokevirtual,
3, // receiverandargssize
1, // return type size
constantpool.javalangreflectmethod_constantpoolname,
constantpool.invoke_method_method_name,
constantpool.invoke_method_method_signature);
}

public void invokejavautiliteratorhasnext() {
// invokeinterface java.util.iterator.hasnext()z
invoke(
opcodes.opc_invokeinterface,
1, // receiverandargssize
1, // return type size
constantpool.javautiliteratorconstantpoolname,
constantpool.hasnext,
constantpool.hasnextsignature);
}

public void invokejavautiliteratornext() {
// invokeinterface java.util.iterator.next()java.lang.object
invoke(
opcodes.opc_invokeinterface,
1, // receiverandargssize
1, // return type size
constantpool.javautiliteratorconstantpoolname,
constantpool.next,
constantpool.nextsignature);
}

public void invokenoclassdeffounderrorstringconstructor() {
// invokespecial: java.lang.noclassdeffounderror.<init>(ljava.lang.string;)v
invoke(
opcodes.opc_invokespecial,
2, // receiverandargssize
0, // return type size
constantpool.javalangnoclassdeffounderrorconstantpoolname,
constantpool.init,
constantpool.stringconstructorsignature);
}

public void invokeobjectgetclass() {
// invokevirtual: java.lang.object.getclass()ljava.lang.class;
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangobjectconstantpoolname,
constantpool.getclass,
constantpool.getclasssignature);
}

/**
* the equivalent code performs a string conversion of the tos
* @@param typeid <code>int</code>
*/
public void invokestringconcatenationappendfortype(int typeid) {
int receiverandargssize;
char[] declaringclass = null;
char[] selector = constantpool.append;
char[] signature = null;
switch (typeid) {
case typeids.t_int :
case typeids.t_byte :
case typeids.t_short :
if (this.targetlevel >= classfileconstants.jdk1_5) {
declaringclass = constantpool.javalangstringbuilderconstantpoolname;
signature = constantpool.stringbuilderappendintsignature;
} else {
declaringclass = constantpool.javalangstringbufferconstantpoolname;
signature = constantpool.stringbufferappendintsignature;
}
receiverandargssize = 2;
break;
case typeids.t_long :
if (this.targetlevel >= classfileconstants.jdk1_5) {
declaringclass = constantpool.javalangstringbuilderconstantpoolname;
signature = constantpool.stringbuilderappendlongsignature;
} else {
declaringclass = constantpool.javalangstringbufferconstantpoolname;
signature = constantpool.stringbufferappendlongsignature;
}
receiverandargssize = 3;
break;
case typeids.t_float :
if (this.targetlevel >= classfileconstants.jdk1_5) {
declaringclass = constantpool.javalangstringbuilderconstantpoolname;
signature = constantpool.stringbuilderappendfloatsignature;
} else {
declaringclass = constantpool.javalangstringbufferconstantpoolname;
signature = constantpool.stringbufferappendfloatsignature;
}
receiverandargssize = 2;
break;
case typeids.t_double :
if (this.targetlevel >= classfileconstants.jdk1_5) {
declaringclass = constantpool.javalangstringbuilderconstantpoolname;
signature = constantpool.stringbuilderappenddoublesignature;
} else {
declaringclass = constantpool.javalangstringbufferconstantpoolname;
signature = constantpool.stringbufferappenddoublesignature;
}
receiverandargssize = 3;
break;
case typeids.t_char :
if (this.targetlevel >= classfileconstants.jdk1_5) {
declaringclass = constantpool.javalangstringbuilderconstantpoolname;
signature = constantpool.stringbuilderappendcharsignature;
} else {
declaringclass = constantpool.javalangstringbufferconstantpoolname;
signature = constantpool.stringbufferappendcharsignature;
}
receiverandargssize = 2;
break;
case typeids.t_boolean :
if (this.targetlevel >= classfileconstants.jdk1_5) {
declaringclass = constantpool.javalangstringbuilderconstantpoolname;
signature = constantpool.stringbuilderappendbooleansignature;
} else {
declaringclass = constantpool.javalangstringbufferconstantpoolname;
signature = constantpool.stringbufferappendbooleansignature;
}
receiverandargssize = 2;
break;
case typeids.t_javalangstring :
if (this.targetlevel >= classfileconstants.jdk1_5) {
declaringclass = constantpool.javalangstringbuilderconstantpoolname;
signature = constantpool.stringbuilderappendstringsignature;
} else {
declaringclass = constantpool.javalangstringbufferconstantpoolname;
signature = constantpool.stringbufferappendstringsignature;
}
receiverandargssize = 2;
break;
default :
if (this.targetlevel >= classfileconstants.jdk1_5) {
declaringclass = constantpool.javalangstringbuilderconstantpoolname;
signature = constantpool.stringbuilderappendobjectsignature;
} else {
declaringclass = constantpool.javalangstringbufferconstantpoolname;
signature = constantpool.stringbufferappendobjectsignature;
}
receiverandargssize = 2;
break;
}
invoke(
opcodes.opc_invokevirtual,
receiverandargssize,
1, // return type size
declaringclass,
selector,
signature);
}

public void invokestringconcatenationdefaultconstructor() {
// invokespecial: java.lang.stringbuffer.<init>()v
// or invokespecial: java.lang.stringbuilder.<init>()v
char[] declaringclass;
if (this.targetlevel < classfileconstants.jdk1_5) {
declaringclass = constantpool.javalangstringbufferconstantpoolname;
} else {
declaringclass = constantpool.javalangstringbuilderconstantpoolname;
}
invoke(
opcodes.opc_invokespecial,
1, // receiverandargssize
0, // return type size
declaringclass,
constantpool.init,
constantpool.defaultconstructorsignature);
}

public void invokestringconcatenationstringconstructor() {
// invokespecial: java.lang.stringbuffer.<init>(java.lang.string)v
// or invokespecial: java.lang.stringbuilder.<init>(java.lang.string)v
char[] declaringclass;
if (this.targetlevel < classfileconstants.jdk1_5) {
// invokespecial: java.lang.stringbuffer.<init>()v
declaringclass = constantpool.javalangstringbufferconstantpoolname;
} else {
// invokespecial: java.lang.stringstringbuilder.<init>(java.langstring)v
declaringclass = constantpool.javalangstringbuilderconstantpoolname;
}
invoke(
opcodes.opc_invokespecial,
2, // receiverandargssize
0, // return type size
declaringclass,
constantpool.init,
constantpool.stringconstructorsignature);
}

public void invokestringconcatenationtostring() {
// invokespecial: java.lang.stringbuffer.tostring()java.lang.string
// or invokespecial: java.lang.stringbuilder.tostring()java.lang.string
char[] declaringclass;
if (this.targetlevel < classfileconstants.jdk1_5) {
// invokespecial: java.lang.stringbuffer.<init>()v
declaringclass = constantpool.javalangstringbufferconstantpoolname;
} else {
// invokespecial: java.lang.stringstringbuilder.<init>(java.langstring)v
declaringclass = constantpool.javalangstringbuilderconstantpoolname;
}
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
declaringclass,
constantpool.tostring,
constantpool.tostringsignature);
}

public void invokestringintern() {
// invokevirtual: java.lang.string.intern()
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangstringconstantpoolname,
constantpool.intern,
constantpool.internsignature);
}

public void invokestringvalueof(int typeid) {
// invokestatic: java.lang.string.valueof(argumenttype)
char[] signature;
int receiverandargssize;
switch (typeid) {
case typeids.t_int :
case typeids.t_byte :
case typeids.t_short :
signature = constantpool.valueofintsignature;
receiverandargssize = 1;
break;
case typeids.t_long :
signature = constantpool.valueoflongsignature;
receiverandargssize = 2;
break;
case typeids.t_float :
signature = constantpool.valueoffloatsignature;
receiverandargssize = 1;
break;
case typeids.t_double :
signature = constantpool.valueofdoublesignature;
receiverandargssize = 2;
break;
case typeids.t_char :
signature = constantpool.valueofcharsignature;
receiverandargssize = 1;
break;
case typeids.t_boolean :
signature = constantpool.valueofbooleansignature;
receiverandargssize = 1;
break;
case typeids.t_javalangobject :
case typeids.t_javalangstring :
case typeids.t_null :
case typeids.t_undefined :
signature = constantpool.valueofobjectsignature;
receiverandargssize = 1;
break;
default :
return; // should not occur
}
invoke(
opcodes.opc_invokestatic,
receiverandargssize, // receiverandargssize
1, // return type size
constantpool.javalangstringconstantpoolname,
constantpool.valueof,
signature);
}

public void invokesystemarraycopy() {
// invokestatic #21 <method java/lang/system.arraycopy(ljava/lang/object;iljava/lang/object;ii)v>
invoke(
opcodes.opc_invokestatic,
5, // receiverandargssize
0, // return type size
constantpool.javalangsystemconstantpoolname,
constantpool.arraycopy,
constantpool.arraycopysignature);
}

public void invokethrowablegetmessage() {
// invokevirtual: java.lang.throwable.getmessage()ljava.lang.string;
invoke(
opcodes.opc_invokevirtual,
1, // receiverandargssize
1, // return type size
constantpool.javalangthrowableconstantpoolname,
constantpool.getmessage,
constantpool.getmessagesignature);
}

public void ior() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ior;
}

public void irem() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_irem;
}

public void ireturn() {
this.countlabels = 0;
this.stackdepth--;
// the stackdepth should be equal to 0
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ireturn;
this.lastabruptcompletion = this.position;
}

public boolean isdefinitelyassigned(scope scope, int initstateindex, localvariablebinding local) {
// mirror of unconditionalflowinfo.isdefinitelyassigned(..)
if ((local.tagbits & tagbits.isargument) != 0) {
return true;
}
if (initstateindex == -1)
return false;
int localposition = local.id + this.maxfieldcount;
methodscope methodscope = scope.methodscope();
// id is zero-based
if (localposition < unconditionalflowinfo.bitcachesize) {
return (methodscope.definiteinits[initstateindex] & (1l << localposition)) != 0; // use bits
}
// use extra vector
long[] extrainits = methodscope.extradefiniteinits[initstateindex];
if (extrainits == null)
return false; // if vector not yet allocated, then not initialized
int vectorindex;
if ((vectorindex = (localposition / unconditionalflowinfo.bitcachesize) - 1) >= extrainits.length)
return false; // if not enough room in vector, then not initialized
return ((extrainits[vectorindex]) & (1l << (localposition % unconditionalflowinfo.bitcachesize))) != 0;
}

public void ishl() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ishl;
}

public void ishr() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ishr;
}

public void istore(int iarg) {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= iarg) {
this.maxlocals = iarg + 1;
}
if (iarg > 255) { // widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_istore;
writeunsignedshort(iarg);
} else {
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_istore;
this.bcodestream[this.classfileoffset++] = (byte) iarg;
}
}

public void istore_0() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals == 0) {
this.maxlocals = 1;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_istore_0;
}

public void istore_1() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= 1) {
this.maxlocals = 2;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_istore_1;
}

public void istore_2() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= 2) {
this.maxlocals = 3;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_istore_2;
}

public void istore_3() {
this.countlabels = 0;
this.stackdepth--;
if (this.maxlocals <= 3) {
this.maxlocals = 4;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_istore_3;
}

public void isub() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_isub;
}

public void iushr() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_iushr;
}

public void ixor() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ixor;
}

final public void jsr(branchlabel lbl) {
if (this.widemode) {
jsr_w(lbl);
return;
}
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_jsr;
lbl.branch();
}

final public void jsr_w(branchlabel lbl) {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_jsr_w;
lbl.branchwide();
}

public void l2d() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_l2d;
}

public void l2f() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_l2f;
}

public void l2i() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_l2i;
}

public void ladd() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ladd;
}

public void laload() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_laload;
}

public void land() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_land;
}

public void lastore() {
this.countlabels = 0;
this.stackdepth -= 4;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lastore;
}

public void lcmp() {
this.countlabels = 0;
this.stackdepth -= 3;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lcmp;
}

public void lconst_0() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lconst_0;
}

public void lconst_1() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lconst_1;
}

public void ldc(float constant) {
this.countlabels = 0;
int index = this.constantpool.literalindex(constant);
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (index > 255) {
// generate a ldc_w
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ldc_w;
writeunsignedshort(index);
} else {
// generate a ldc
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ldc;
this.bcodestream[this.classfileoffset++] = (byte) index;
}
}

public void ldc(int constant) {
this.countlabels = 0;
int index = this.constantpool.literalindex(constant);
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (index > 255) {
// generate a ldc_w
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ldc_w;
writeunsignedshort(index);
} else {
// generate a ldc
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ldc;
this.bcodestream[this.classfileoffset++] = (byte) index;
}
}

public void ldc(string constant) {
this.countlabels = 0;
int currentcodestreamposition = this.position;
char[] constantchars = constant.tochararray();
int index = this.constantpool.literalindexforldc(constantchars);
if (index > 0) {
// the string already exists inside the constant pool
// we reuse the same index
ldcforindex(index);
} else {
// the string is too big to be utf8-encoded in one pass.
// we have to split it into different pieces.
// first we clean all side-effects due to the code above
// this case is very rare, so we can afford to lose time to handle it
this.position = currentcodestreamposition;
int i = 0;
int length = 0;
int constantlength = constant.length();
byte[] utf8encoding = new byte[math.min(constantlength + 100, 65535)];
int utf8encodinglength = 0;
while ((length < 65532) && (i < constantlength)) {
char current = constantchars[i];
// we resize the byte array immediately if necessary
if (length + 3 > (utf8encodinglength = utf8encoding.length)) {
system.arraycopy(utf8encoding, 0, utf8encoding = new byte[math.min(utf8encodinglength + 100, 65535)], 0, length);
}
if ((current >= 0x0001) && (current <= 0x007f)) {
// we only need one byte: ascii table
utf8encoding[length++] = (byte) current;
} else {
if (current > 0x07ff) {
// we need 3 bytes
utf8encoding[length++] = (byte) (0xe0 | ((current >> 12) & 0x0f)); // 0xe0 = 1110 0000
utf8encoding[length++] = (byte) (0x80 | ((current >> 6) & 0x3f)); // 0x80 = 1000 0000
utf8encoding[length++] = (byte) (0x80 | (current & 0x3f)); // 0x80 = 1000 0000
} else {
// we can be 0 or between 0x0080 and 0x07ff
// in that case we only need 2 bytes
utf8encoding[length++] = (byte) (0xc0 | ((current >> 6) & 0x1f)); // 0xc0 = 1100 0000
utf8encoding[length++] = (byte) (0x80 | (current & 0x3f)); // 0x80 = 1000 0000
}
}
i++;
}
// check if all the string is encoded (pr 1pr2dwj)
// the string is too big to be encoded in one pass
newstringcontatenation();
dup();
// write the first part
char[] subchars = new char[i];
system.arraycopy(constantchars, 0, subchars, 0, i);
system.arraycopy(utf8encoding, 0, utf8encoding = new byte[length], 0, length);
index = this.constantpool.literalindex(subchars, utf8encoding);
ldcforindex(index);
// write the remaining part
invokestringconcatenationstringconstructor();
while (i < constantlength) {
length = 0;
utf8encoding = new byte[math.min(constantlength - i + 100, 65535)];
int startindex = i;
while ((length < 65532) && (i < constantlength)) {
char current = constantchars[i];
// we resize the byte array immediately if necessary
if (length + 3 > (utf8encodinglength = utf8encoding.length)) {
system.arraycopy(utf8encoding, 0, utf8encoding = new byte[math.min(utf8encodinglength + 100, 65535)], 0, length);
}
if ((current >= 0x0001) && (current <= 0x007f)) {
// we only need one byte: ascii table
utf8encoding[length++] = (byte) current;
} else {
if (current > 0x07ff) {
// we need 3 bytes
utf8encoding[length++] = (byte) (0xe0 | ((current >> 12) & 0x0f)); // 0xe0 = 1110 0000
utf8encoding[length++] = (byte) (0x80 | ((current >> 6) & 0x3f)); // 0x80 = 1000 0000
utf8encoding[length++] = (byte) (0x80 | (current & 0x3f)); // 0x80 = 1000 0000
} else {
// we can be 0 or between 0x0080 and 0x07ff
// in that case we only need 2 bytes
utf8encoding[length++] = (byte) (0xc0 | ((current >> 6) & 0x1f)); // 0xc0 = 1100 0000
utf8encoding[length++] = (byte) (0x80 | (current & 0x3f)); // 0x80 = 1000 0000
}
}
i++;
}
// the next part is done
int newcharlength = i - startindex;
subchars = new char[newcharlength];
system.arraycopy(constantchars, startindex, subchars, 0, newcharlength);
system.arraycopy(utf8encoding, 0, utf8encoding = new byte[length], 0, length);
index = this.constantpool.literalindex(subchars, utf8encoding);
ldcforindex(index);
// now on the stack it should be a stringbuffer and a string.
invokestringconcatenationappendfortype(typeids.t_javalangstring);
}
invokestringconcatenationtostring();
invokestringintern();
}
}

public void ldc(typebinding typebinding) {
this.countlabels = 0;
int index = this.constantpool.literalindexfortype(typebinding);
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (index > 255) {
// generate a ldc_w
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ldc_w;
writeunsignedshort(index);
} else {
// generate a ldc
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ldc;
this.bcodestream[this.classfileoffset++] = (byte) index;
}
}

public void ldc2_w(double constant) {
this.countlabels = 0;
int index = this.constantpool.literalindex(constant);
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
// generate a ldc2_w
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ldc2_w;
writeunsignedshort(index);
}

public void ldc2_w(long constant) {
this.countlabels = 0;
int index = this.constantpool.literalindex(constant);
this.stackdepth += 2;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
// generate a ldc2_w
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ldc2_w;
writeunsignedshort(index);
}

public void ldcforindex(int index) {
this.stackdepth++;
if (this.stackdepth > this.stackmax) {
this.stackmax = this.stackdepth;
}
if (index > 255) {
// generate a ldc_w
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ldc_w;
writeunsignedshort(index);
} else {
// generate a ldc
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ldc;
this.bcodestream[this.classfileoffset++] = (byte) index;
}
}

public void ldiv() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ldiv;
}

public void lload(int iarg) {
this.countlabels = 0;
this.stackdepth += 2;
if (this.maxlocals <= iarg + 1) {
this.maxlocals = iarg + 2;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (iarg > 255) { // widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lload;
writeunsignedshort(iarg);
} else {
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lload;
this.bcodestream[this.classfileoffset++] = (byte) iarg;
}
}

public void lload_0() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.maxlocals < 2) {
this.maxlocals = 2;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lload_0;
}

public void lload_1() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.maxlocals < 3) {
this.maxlocals = 3;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lload_1;
}

public void lload_2() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.maxlocals < 4) {
this.maxlocals = 4;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lload_2;
}

public void lload_3() {
this.countlabels = 0;
this.stackdepth += 2;
if (this.maxlocals < 5) {
this.maxlocals = 5;
}
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lload_3;
}

public void lmul() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lmul;
}

public void lneg() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lneg;
}

public final void load(localvariablebinding localbinding) {
load(localbinding.type, localbinding.resolvedposition);
}

protected final void load(typebinding typebinding, int resolvedposition) {
this.countlabels = 0;
// using dedicated int bytecode
switch(typebinding.id) {
case typeids.t_int :
case typeids.t_byte :
case typeids.t_char :
case typeids.t_boolean :
case typeids.t_short :
switch (resolvedposition) {
case 0 :
iload_0();
break;
case 1 :
iload_1();
break;
case 2 :
iload_2();
break;
case 3 :
iload_3();
break;
//case -1 :
// internal failure: trying to load variable not supposed to be generated
//	break;
default :
iload(resolvedposition);
}
break;
case typeids.t_float :
switch (resolvedposition) {
case 0 :
fload_0();
break;
case 1 :
fload_1();
break;
case 2 :
fload_2();
break;
case 3 :
fload_3();
break;
default :
fload(resolvedposition);
}
break;
case typeids.t_long :
switch (resolvedposition) {
case 0 :
lload_0();
break;
case 1 :
lload_1();
break;
case 2 :
lload_2();
break;
case 3 :
lload_3();
break;
default :
lload(resolvedposition);
}
break;
case typeids.t_double :
switch (resolvedposition) {
case 0 :
dload_0();
break;
case 1 :
dload_1();
break;
case 2 :
dload_2();
break;
case 3 :
dload_3();
break;
default :
dload(resolvedposition);
}
break;
default :
switch (resolvedposition) {
case 0 :
aload_0();
break;
case 1 :
aload_1();
break;
case 2 :
aload_2();
break;
case 3 :
aload_3();
break;
default :
aload(resolvedposition);
}
}
}

public void lookupswitch(caselabel defaultlabel, int[] keys, int[] sortedindexes, caselabel[] caseslabel) {
this.countlabels = 0;
this.stackdepth--;
int length = keys.length;
int pos = this.position;
defaultlabel.placeinstruction();
for (int i = 0; i < length; i++) {
caseslabel[i].placeinstruction();
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lookupswitch;
for (int i = (3 - (pos & 3)); i > 0; i--) { // faster than % 4
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = 0;
}
defaultlabel.branch();
writesignedword(length);
for (int i = 0; i < length; i++) {
writesignedword(keys[sortedindexes[i]]);
caseslabel[sortedindexes[i]].branch();
}
}

public void lor() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lor;
}

public void lrem() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lrem;
}

public void lreturn() {
this.countlabels = 0;
this.stackdepth -= 2;
// the stackdepth should be equal to 0
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lreturn;
this.lastabruptcompletion = this.position;
}

public void lshl() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lshl;
}

public void lshr() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lshr;
}

public void lstore(int iarg) {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.maxlocals <= iarg + 1) {
this.maxlocals = iarg + 2;
}
if (iarg > 255) { // widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lstore;
writeunsignedshort(iarg);
} else {
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lstore;
this.bcodestream[this.classfileoffset++] = (byte) iarg;
}
}

public void lstore_0() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.maxlocals < 2) {
this.maxlocals = 2;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lstore_0;
}

public void lstore_1() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.maxlocals < 3) {
this.maxlocals = 3;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lstore_1;
}

public void lstore_2() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.maxlocals < 4) {
this.maxlocals = 4;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lstore_2;
}

public void lstore_3() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.maxlocals < 5) {
this.maxlocals = 5;
}
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lstore_3;
}

public void lsub() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lsub;
}

public void lushr() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lushr;
}

public void lxor() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_lxor;
}

public void monitorenter() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_monitorenter;
}

public void monitorexit() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_monitorexit;
}

public void multianewarray(typebinding typebinding, int dimensions) {
this.countlabels = 0;
this.stackdepth += (1 - dimensions);
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_multianewarray;
writeunsignedshort(this.constantpool.literalindexfortype(typebinding));
this.bcodestream[this.classfileoffset++] = (byte) dimensions;
}

// we didn't call it new, because there is a conflit with the new keyword
public void new_(typebinding typebinding) {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_new;
writeunsignedshort(this.constantpool.literalindexfortype(typebinding));
}

public void newarray(int array_type) {
this.countlabels = 0;
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_newarray;
this.bcodestream[this.classfileoffset++] = (byte) array_type;
}

public void newarray(arraybinding arraybinding) {
typebinding component = arraybinding.elementstype();
switch (component.id) {
case typeids.t_int :
newarray(classfileconstants.int_array);
break;
case typeids.t_byte :
newarray(classfileconstants.byte_array);
break;
case typeids.t_boolean :
newarray(classfileconstants.boolean_array);
break;
case typeids.t_short :
newarray(classfileconstants.short_array);
break;
case typeids.t_char :
newarray(classfileconstants.char_array);
break;
case typeids.t_long :
newarray(classfileconstants.long_array);
break;
case typeids.t_float :
newarray(classfileconstants.float_array);
break;
case typeids.t_double :
newarray(classfileconstants.double_array);
break;
default :
anewarray(component);
}
}

public void newjavalangassertionerror() {
// new: java.lang.assertionerror
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_new;
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangassertionerrorconstantpoolname));
}

public void newjavalangerror() {
// new: java.lang.error
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_new;
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangerrorconstantpoolname));
}

public void newnoclassdeffounderror() {
// new: java.lang.noclassdeffounderror
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_new;
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangnoclassdeffounderrorconstantpoolname));
}

public void newstringcontatenation() {
// new: java.lang.stringbuffer
// new: java.lang.stringbuilder
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax) {
this.stackmax = this.stackdepth;
}
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_new;
if (this.targetlevel >= classfileconstants.jdk1_5) {
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangstringbuilderconstantpoolname));
} else {
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangstringbufferconstantpoolname));
}
}

public void newwrapperfor(int typeid) {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset + 2 >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_new;
switch (typeid) {
case typeids.t_int : // new: java.lang.integer
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangintegerconstantpoolname));
break;
case typeids.t_boolean : // new: java.lang.boolean
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangbooleanconstantpoolname));
break;
case typeids.t_byte : // new: java.lang.byte
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangbyteconstantpoolname));
break;
case typeids.t_char : // new: java.lang.character
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangcharacterconstantpoolname));
break;
case typeids.t_float : // new: java.lang.float
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangfloatconstantpoolname));
break;
case typeids.t_double : // new: java.lang.double
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangdoubleconstantpoolname));
break;
case typeids.t_short : // new: java.lang.short
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangshortconstantpoolname));
break;
case typeids.t_long : // new: java.lang.long
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalanglongconstantpoolname));
break;
case typeids.t_void : // new: java.lang.void
writeunsignedshort(this.constantpool.literalindexfortype(constantpool.javalangvoidconstantpoolname));
}
}

public void nop() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_nop;
}

public void optimizebranch(int oldposition, branchlabel lbl) {
for (int i = 0; i < this.countlabels; i++) {
branchlabel label = this.labels[i];
if (oldposition == label.position) {
label.position = this.position;
if (label instanceof caselabel) {
int offset = this.position - ((caselabel) label).instructionposition;
int[] forwardrefs = label.forwardreferences();
for (int j = 0, length = label.forwardreferencecount(); j < length; j++) {
int forwardref = forwardrefs[j];
this.writesignedword(forwardref, offset);
}
} else {
int[] forwardrefs = label.forwardreferences();
for (int j = 0, length = label.forwardreferencecount(); j < length; j++) {
final int forwardref = forwardrefs[j];
this.writeposition(lbl, forwardref);
}
}
}
}
}

public void pop() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_pop;
}

public void pop2() {
this.countlabels = 0;
this.stackdepth -= 2;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_pop2;
}

public void pushexceptiononstack(typebinding binding) {
this.stackdepth = 1;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
}

public void pushonstack(typebinding binding) {
if (++this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
}

public void record(localvariablebinding local) {
if ((this.generateattributes & (classfileconstants.attr_vars
| classfileconstants.attr_stack_map_table
| classfileconstants.attr_stack_map)) == 0)
return;
if (this.alllocalscounter == this.locals.length) {
// resize the collection
system.arraycopy(this.locals, 0, this.locals = new localvariablebinding[this.alllocalscounter + locals_increment], 0, this.alllocalscounter);
}
this.locals[this.alllocalscounter++] = local;
local.initializationpcs = new int[4];
local.initializationcount = 0;
}

public void recordexpressiontype(typebinding typebinding) {
// nothing to do
}

public void recordpositionsfrom(int startpc, int sourcepos) {
this.recordpositionsfrom(startpc, sourcepos, false);
}

public void recordpositionsfrom(int startpc, int sourcepos, boolean widen) {
/* record positions in the table, only if nothing has
* already been recorded. since we output them on the way
* up (children first for more specific info)
* the pctosourcemap table is always sorted.
*/
if ((this.generateattributes & classfileconstants.attr_lines) == 0
|| sourcepos == 0
|| (startpc == this.position && !widen))
return;

// widening an existing entry that already has the same source positions
if (this.pctosourcemapsize + 4 > this.pctosourcemap.length) {
// resize the array pctosourcemap
system.arraycopy(this.pctosourcemap, 0, this.pctosourcemap = new int[this.pctosourcemapsize << 1], 0, this.pctosourcemapsize);
}
// lastentrypc represents the endpc of the lastentry.
if (this.pctosourcemapsize > 0) {
int linenumber;
int previouslinenumber = this.pctosourcemap[this.pctosourcemapsize - 1];
if (this.linenumberstart == this.linenumberend) {
// method on one line
linenumber = this.linenumberstart;
} else {
// check next line number if this is the one we are looking for
int[] lineseparatorpositions2 = this.lineseparatorpositions;
int length = lineseparatorpositions2.length;
if (previouslinenumber == 1) {
if (sourcepos < lineseparatorpositions2[0]) {
linenumber = 1;
/* the last recorded entry is on the same line. but it could be relevant to widen this entry.
we want to extend this entry forward in case we generated some bytecode before the last entry that are not related to any statement
*/
if (startpc < this.pctosourcemap[this.pctosourcemapsize - 2]) {
int insertionindex = insertionindex(this.pctosourcemap, this.pctosourcemapsize, startpc);
if (insertionindex != -1) {
// widen the existing entry
// we have to figure out if we need to move the last entry at another location to keep a sorted table
/* first we need to check if at the insertion position there is not an existing entry
* that includes the one we want to insert. this is the case if pctosourcemap[insertionindex - 1] == newline.
* in this case we don't want to change the table. if not, we want to insert a new entry. prior to insertion
* we want to check if it is worth doing an arraycopy. if not we simply update the recorded pc.
*/
if (!((insertionindex > 1) && (this.pctosourcemap[insertionindex - 1] == linenumber))) {
if ((this.pctosourcemapsize > 4) && (this.pctosourcemap[this.pctosourcemapsize - 4] > startpc)) {
system.arraycopy(this.pctosourcemap, insertionindex, this.pctosourcemap, insertionindex + 2, this.pctosourcemapsize - 2 - insertionindex);
this.pctosourcemap[insertionindex++] = startpc;
this.pctosourcemap[insertionindex] = linenumber;
} else {
this.pctosourcemap[this.pctosourcemapsize - 2] = startpc;
}
}
}
}
this.lastentrypc = this.position;
return;
} else if (length == 1 || sourcepos < lineseparatorpositions2[1]) {
linenumber = 2;
if (startpc <= this.lastentrypc) {
// we forgot to add an entry.
// search if an existing entry exists for startpc
int insertionindex = insertionindex(this.pctosourcemap, this.pctosourcemapsize, startpc);
if (insertionindex != -1) {
// there is no existing entry starting with startpc.
int existingentryindex = indexofsamelineentrysincepc(startpc, linenumber); // index for pc
/* the existingentryindex corresponds to an entry with the same line and a pc >= startpc.
in this case it is relevant to widen this entry instead of creating a new one.
line1: this(a,
b,
c);
with this code we generate each argument. we generate a aload0 to invoke the constructor. there is no entry for this
aload0 bytecode. the first entry is the one for the argument a.
but we want the constructor call to start at the aload0 pc and not just at the pc of the first argument.
so we widen the existing entry (if there is one) or we create a new entry with the startpc.
*/
if (existingentryindex != -1) {
// widen existing entry
this.pctosourcemap[existingentryindex] = startpc;
} else if (insertionindex < 1 || this.pctosourcemap[insertionindex - 1] != linenumber) {
// we have to add an entry that won't be sorted. so we sort the pctosourcemap.
system.arraycopy(this.pctosourcemap, insertionindex, this.pctosourcemap, insertionindex + 2, this.pctosourcemapsize - insertionindex);
this.pctosourcemap[insertionindex++] = startpc;
this.pctosourcemap[insertionindex] = linenumber;
this.pctosourcemapsize += 2;
}
} else if (this.position != this.lastentrypc) { // no bytecode since last entry pc
if (this.lastentrypc == startpc || this.lastentrypc == this.pctosourcemap[this.pctosourcemapsize - 2]) {
this.pctosourcemap[this.pctosourcemapsize - 1] = linenumber;
} else {
this.pctosourcemap[this.pctosourcemapsize++] = this.lastentrypc;
this.pctosourcemap[this.pctosourcemapsize++] = linenumber;
}
} else if (this.pctosourcemap[this.pctosourcemapsize - 1] < linenumber && widen) {
// see if we can widen the existing entry
this.pctosourcemap[this.pctosourcemapsize - 1] = linenumber;
}
} else {
// we can safely add the new entry. the endpc of the previous entry is not in conflit with the startpc of the new entry.
this.pctosourcemap[this.pctosourcemapsize++] = startpc;
this.pctosourcemap[this.pctosourcemapsize++] = linenumber;
}
this.lastentrypc = this.position;
return;
} else {
// since lineseparatorpositions is zero-based, we pass this.linenumberstart - 1 and this.linenumberend - 1
linenumber = util.getlinenumber(sourcepos, this.lineseparatorpositions, this.linenumberstart - 1, this.linenumberend - 1);
}
} else if (previouslinenumber < length) {
if (lineseparatorpositions2[previouslinenumber - 2] < sourcepos) {
if (sourcepos < lineseparatorpositions2[previouslinenumber - 1]) {
linenumber = previouslinenumber;
/* the last recorded entry is on the same line. but it could be relevant to widen this entry.
we want to extend this entry forward in case we generated some bytecode before the last entry that are not related to any statement
*/
if (startpc < this.pctosourcemap[this.pctosourcemapsize - 2]) {
int insertionindex = insertionindex(this.pctosourcemap, this.pctosourcemapsize, startpc);
if (insertionindex != -1) {
// widen the existing entry
// we have to figure out if we need to move the last entry at another location to keep a sorted table
/* first we need to check if at the insertion position there is not an existing entry
* that includes the one we want to insert. this is the case if pctosourcemap[insertionindex - 1] == newline.
* in this case we don't want to change the table. if not, we want to insert a new entry. prior to insertion
* we want to check if it is worth doing an arraycopy. if not we simply update the recorded pc.
*/
if (!((insertionindex > 1) && (this.pctosourcemap[insertionindex - 1] == linenumber))) {
if ((this.pctosourcemapsize > 4) && (this.pctosourcemap[this.pctosourcemapsize - 4] > startpc)) {
system.arraycopy(this.pctosourcemap, insertionindex, this.pctosourcemap, insertionindex + 2, this.pctosourcemapsize - 2 - insertionindex);
this.pctosourcemap[insertionindex++] = startpc;
this.pctosourcemap[insertionindex] = linenumber;
} else {
this.pctosourcemap[this.pctosourcemapsize - 2] = startpc;
}
}
}
}
this.lastentrypc = this.position;
return;
} else if (sourcepos < lineseparatorpositions2[previouslinenumber]) {
linenumber = previouslinenumber + 1;
if (startpc <= this.lastentrypc) {
// we forgot to add an entry.
// search if an existing entry exists for startpc
int insertionindex = insertionindex(this.pctosourcemap, this.pctosourcemapsize, startpc);
if (insertionindex != -1) {
// there is no existing entry starting with startpc.
int existingentryindex = indexofsamelineentrysincepc(startpc, linenumber); // index for pc
/* the existingentryindex corresponds to an entry with the same line and a pc >= startpc.
in this case it is relevant to widen this entry instead of creating a new one.
line1: this(a,
b,
c);
with this code we generate each argument. we generate a aload0 to invoke the constructor. there is no entry for this
aload0 bytecode. the first entry is the one for the argument a.
but we want the constructor call to start at the aload0 pc and not just at the pc of the first argument.
so we widen the existing entry (if there is one) or we create a new entry with the startpc.
*/
if (existingentryindex != -1) {
// widen existing entry
this.pctosourcemap[existingentryindex] = startpc;
} else if (insertionindex < 1 || this.pctosourcemap[insertionindex - 1] != linenumber) {
// we have to add an entry that won't be sorted. so we sort the pctosourcemap.
system.arraycopy(this.pctosourcemap, insertionindex, this.pctosourcemap, insertionindex + 2, this.pctosourcemapsize - insertionindex);
this.pctosourcemap[insertionindex++] = startpc;
this.pctosourcemap[insertionindex] = linenumber;
this.pctosourcemapsize += 2;
}
} else if (this.position != this.lastentrypc) { // no bytecode since last entry pc
if (this.lastentrypc == startpc || this.lastentrypc == this.pctosourcemap[this.pctosourcemapsize - 2]) {
this.pctosourcemap[this.pctosourcemapsize - 1] = linenumber;
} else {
this.pctosourcemap[this.pctosourcemapsize++] = this.lastentrypc;
this.pctosourcemap[this.pctosourcemapsize++] = linenumber;
}
} else if (this.pctosourcemap[this.pctosourcemapsize - 1] < linenumber && widen) {
// see if we can widen the existing entry
this.pctosourcemap[this.pctosourcemapsize - 1] = linenumber;
}
} else {
// we can safely add the new entry. the endpc of the previous entry is not in conflit with the startpc of the new entry.
this.pctosourcemap[this.pctosourcemapsize++] = startpc;
this.pctosourcemap[this.pctosourcemapsize++] = linenumber;
}
this.lastentrypc = this.position;
return;
} else {
// since lineseparatorpositions is zero-based, we pass this.linenumberstart - 1 and this.linenumberend - 1
linenumber = util.getlinenumber(sourcepos, this.lineseparatorpositions, this.linenumberstart - 1, this.linenumberend - 1);
}
} else {
// since lineseparatorpositions is zero-based, we pass this.linenumberstart - 1 and this.linenumberend - 1
linenumber = util.getlinenumber(sourcepos, this.lineseparatorpositions, this.linenumberstart - 1, this.linenumberend - 1);
}
} else if (lineseparatorpositions2[length - 1] < sourcepos) {
linenumber = length + 1;
if (startpc <= this.lastentrypc) {
// we forgot to add an entry.
// search if an existing entry exists for startpc
int insertionindex = insertionindex(this.pctosourcemap, this.pctosourcemapsize, startpc);
if (insertionindex != -1) {
// there is no existing entry starting with startpc.
int existingentryindex = indexofsamelineentrysincepc(startpc, linenumber); // index for pc
/* the existingentryindex corresponds to an entry with the same line and a pc >= startpc.
in this case it is relevant to widen this entry instead of creating a new one.
line1: this(a,
b,
c);
with this code we generate each argument. we generate a aload0 to invoke the constructor. there is no entry for this
aload0 bytecode. the first entry is the one for the argument a.
but we want the constructor call to start at the aload0 pc and not just at the pc of the first argument.
so we widen the existing entry (if there is one) or we create a new entry with the startpc.
*/
if (existingentryindex != -1) {
// widen existing entry
this.pctosourcemap[existingentryindex] = startpc;
} else if (insertionindex < 1 || this.pctosourcemap[insertionindex - 1] != linenumber) {
// we have to add an entry that won't be sorted. so we sort the pctosourcemap.
system.arraycopy(this.pctosourcemap, insertionindex, this.pctosourcemap, insertionindex + 2, this.pctosourcemapsize - insertionindex);
this.pctosourcemap[insertionindex++] = startpc;
this.pctosourcemap[insertionindex] = linenumber;
this.pctosourcemapsize += 2;
}
} else if (this.position != this.lastentrypc) { // no bytecode since last entry pc
if (this.lastentrypc == startpc || this.lastentrypc == this.pctosourcemap[this.pctosourcemapsize - 2]) {
this.pctosourcemap[this.pctosourcemapsize - 1] = linenumber;
} else {
this.pctosourcemap[this.pctosourcemapsize++] = this.lastentrypc;
this.pctosourcemap[this.pctosourcemapsize++] = linenumber;
}
} else if (this.pctosourcemap[this.pctosourcemapsize - 1] < linenumber && widen) {
// see if we can widen the existing entry
this.pctosourcemap[this.pctosourcemapsize - 1] = linenumber;
}
} else {
// we can safely add the new entry. the endpc of the previous entry is not in conflit with the startpc of the new entry.
this.pctosourcemap[this.pctosourcemapsize++] = startpc;
this.pctosourcemap[this.pctosourcemapsize++] = linenumber;
}
this.lastentrypc = this.position;
return;
} else {
// since lineseparatorpositions is zero-based, we pass this.linenumberstart - 1 and this.linenumberend - 1
linenumber = util.getlinenumber(sourcepos, this.lineseparatorpositions, this.linenumberstart - 1, this.linenumberend - 1);
}
}
// in this case there is already an entry in the table
if (previouslinenumber != linenumber) {
if (startpc <= this.lastentrypc) {
// we forgot to add an entry.
// search if an existing entry exists for startpc
int insertionindex = insertionindex(this.pctosourcemap, this.pctosourcemapsize, startpc);
if (insertionindex != -1) {
// there is no existing entry starting with startpc.
int existingentryindex = indexofsamelineentrysincepc(startpc, linenumber); // index for pc
/* the existingentryindex corresponds to an entry with the same line and a pc >= startpc.
in this case it is relevant to widen this entry instead of creating a new one.
line1: this(a,
b,
c);
with this code we generate each argument. we generate a aload0 to invoke the constructor. there is no entry for this
aload0 bytecode. the first entry is the one for the argument a.
but we want the constructor call to start at the aload0 pc and not just at the pc of the first argument.
so we widen the existing entry (if there is one) or we create a new entry with the startpc.
*/
if (existingentryindex != -1) {
// widen existing entry
this.pctosourcemap[existingentryindex] = startpc;
} else if (insertionindex < 1 || this.pctosourcemap[insertionindex - 1] != linenumber) {
// we have to add an entry that won't be sorted. so we sort the pctosourcemap.
system.arraycopy(this.pctosourcemap, insertionindex, this.pctosourcemap, insertionindex + 2, this.pctosourcemapsize - insertionindex);
this.pctosourcemap[insertionindex++] = startpc;
this.pctosourcemap[insertionindex] = linenumber;
this.pctosourcemapsize += 2;
}
} else if (this.position != this.lastentrypc) { // no bytecode since last entry pc
if (this.lastentrypc == startpc || this.lastentrypc == this.pctosourcemap[this.pctosourcemapsize - 2]) {
this.pctosourcemap[this.pctosourcemapsize - 1] = linenumber;
} else {
this.pctosourcemap[this.pctosourcemapsize++] = this.lastentrypc;
this.pctosourcemap[this.pctosourcemapsize++] = linenumber;
}
} else if (this.pctosourcemap[this.pctosourcemapsize - 1] < linenumber && widen) {
// see if we can widen the existing entry
this.pctosourcemap[this.pctosourcemapsize - 1] = linenumber;
}
} else {
// we can safely add the new entry. the endpc of the previous entry is not in conflit with the startpc of the new entry.
this.pctosourcemap[this.pctosourcemapsize++] = startpc;
this.pctosourcemap[this.pctosourcemapsize++] = linenumber;
}
} else {
/* the last recorded entry is on the same line. but it could be relevant to widen this entry.
we want to extend this entry forward in case we generated some bytecode before the last entry that are not related to any statement
*/
if (startpc < this.pctosourcemap[this.pctosourcemapsize - 2]) {
int insertionindex = insertionindex(this.pctosourcemap, this.pctosourcemapsize, startpc);
if (insertionindex != -1) {
// widen the existing entry
// we have to figure out if we need to move the last entry at another location to keep a sorted table
/* first we need to check if at the insertion position there is not an existing entry
* that includes the one we want to insert. this is the case if pctosourcemap[insertionindex - 1] == newline.
* in this case we don't want to change the table. if not, we want to insert a new entry. prior to insertion
* we want to check if it is worth doing an arraycopy. if not we simply update the recorded pc.
*/
if (!((insertionindex > 1) && (this.pctosourcemap[insertionindex - 1] == linenumber))) {
if ((this.pctosourcemapsize > 4) && (this.pctosourcemap[this.pctosourcemapsize - 4] > startpc)) {
system.arraycopy(this.pctosourcemap, insertionindex, this.pctosourcemap, insertionindex + 2, this.pctosourcemapsize - 2 - insertionindex);
this.pctosourcemap[insertionindex++] = startpc;
this.pctosourcemap[insertionindex] = linenumber;
} else {
this.pctosourcemap[this.pctosourcemapsize - 2] = startpc;
}
}
}
}
}
this.lastentrypc = this.position;
} else {
int linenumber = 0;
if (this.linenumberstart == this.linenumberend) {
// method on one line
linenumber = this.linenumberstart;
} else {
// since lineseparatorpositions is zero-based, we pass this.linenumberstart - 1 and this.linenumberend - 1
linenumber = util.getlinenumber(sourcepos, this.lineseparatorpositions, this.linenumberstart - 1, this.linenumberend - 1);
}
// record the first entry
this.pctosourcemap[this.pctosourcemapsize++] = startpc;
this.pctosourcemap[this.pctosourcemapsize++] = linenumber;
this.lastentrypc = this.position;
}
}

/**
* @@param anexceptionlabel org.eclipse.jdt.internal.compiler.codegen.exceptionlabel
*/
public void registerexceptionhandler(exceptionlabel anexceptionlabel) {
int length;
if (this.exceptionlabelscounter == (length = this.exceptionlabels.length)) {
// resize the exception handlers table
system.arraycopy(this.exceptionlabels, 0, this.exceptionlabels = new exceptionlabel[length + labels_increment], 0, length);
}
// no need to resize. so just add the new exception label
this.exceptionlabels[this.exceptionlabelscounter++] = anexceptionlabel;
}

public void removenotdefinitelyassignedvariables(scope scope, int initstateindex) {
// given some flow info, make sure we did not loose some variables initialization
// if this happens, then we must update their pc entries to reflect it in debug attributes
if ((this.generateattributes & (classfileconstants.attr_vars
| classfileconstants.attr_stack_map_table
| classfileconstants.attr_stack_map)) == 0)
return;
for (int i = 0; i < this.visiblelocalscount; i++) {
localvariablebinding localbinding = this.visiblelocals[i];
if (localbinding != null && !isdefinitelyassigned(scope, initstateindex, localbinding) && localbinding.initializationcount > 0) {
localbinding.recordinitializationendpc(this.position);
}
}
}

/**
* remove all entries in pctosourcemap table that are beyond this.position
*/
public void removeunusedpctosourcemapentries() {
if (this.pctosourcemapsize != 0) {
while (this.pctosourcemapsize >= 2 && this.pctosourcemap[this.pctosourcemapsize - 2] > this.position) {
this.pctosourcemapsize -= 2;
}
}
}
public void removevariable(localvariablebinding localbinding) {
if (localbinding == null) return;
if (localbinding.initializationcount > 0) {
localbinding.recordinitializationendpc(this.position);
}
for (int i = this.visiblelocalscount - 1; i >= 0; i--) {
localvariablebinding visiblelocal = this.visiblelocals[i];
if (visiblelocal == localbinding){
this.visiblelocals[i] = null; // this variable is no longer visible afterwards
return;
}
}
}

/**
* @@param referencemethod org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration
* @@param targetclassfile org.eclipse.jdt.internal.compiler.codegen.classfile
*/
public void reset(abstractmethoddeclaration referencemethod, classfile targetclassfile) {
init(targetclassfile);
this.methoddeclaration = referencemethod;
int[] lineseparatorpositions2 = this.lineseparatorpositions;
if (lineseparatorpositions2 != null) {
int length = lineseparatorpositions2.length;
int lineseparatorpositionsend = length - 1;
if (referencemethod.isclinit()
|| referencemethod.isconstructor()) {
this.linenumberstart = 1;
this.linenumberend = length == 0 ? 1 : length;
} else {
int start = util.getlinenumber(referencemethod.bodystart, lineseparatorpositions2, 0, lineseparatorpositionsend);
this.linenumberstart = start;
if (start > lineseparatorpositionsend) {
this.linenumberend = start;
} else {
int end = util.getlinenumber(referencemethod.bodyend, lineseparatorpositions2, start - 1, lineseparatorpositionsend);
if (end >= lineseparatorpositionsend) {
end = length;
}
this.linenumberend = end == 0 ? 1 : end;
}
}
}
this.preserveunusedlocals = referencemethod.scope.compileroptions().preservealllocalvariables;
initializemaxlocals(referencemethod.binding);
}

public void reset(classfile givenclassfile) {
this.targetlevel = givenclassfile.targetjdk;
int produceattributes = givenclassfile.produceattributes;
this.generateattributes = produceattributes;
if ((produceattributes & classfileconstants.attr_lines) != 0) {
this.lineseparatorpositions = givenclassfile.referencebinding.scope.referencecompilationunit().compilationresult.getlineseparatorpositions();
} else {
this.lineseparatorpositions = null;
}
}

/**
* @@param targetclassfile the given classfile to reset the code stream
*/
public void resetforproblemclinit(classfile targetclassfile) {
init(targetclassfile);
initializemaxlocals(null);
}

public void resetinwidemode() {
this.widemode = true;
}

private final void resizebytearray() {
int length = this.bcodestream.length;
int requiredsize = length + length;
if (this.classfileoffset >= requiredsize) {
// must be sure to grow enough
requiredsize = this.classfileoffset + length;
}
system.arraycopy(this.bcodestream, 0, this.bcodestream = new byte[requiredsize], 0, length);
}

final public void ret(int index) {
this.countlabels = 0;
if (index > 255) { // widen
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_wide;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ret;
writeunsignedshort(index);
} else { // don't widen
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = opcodes.opc_ret;
this.bcodestream[this.classfileoffset++] = (byte) index;
}
}

public void return_() {
this.countlabels = 0;
// the stackdepth should be equal to 0
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_return;
this.lastabruptcompletion = this.position;
}

public void saload() {
this.countlabels = 0;
this.stackdepth--;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_saload;
}

public void sastore() {
this.countlabels = 0;
this.stackdepth -= 3;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_sastore;
}

/**
* @@param operatorconstant int
* @@param type_id int
*/
public void sendoperator(int operatorconstant, int type_id) {
switch (type_id) {
case typeids.t_int :
case typeids.t_boolean :
case typeids.t_char :
case typeids.t_byte :
case typeids.t_short :
switch (operatorconstant) {
case operatorids.plus :
iadd();
break;
case operatorids.minus :
isub();
break;
case operatorids.multiply :
imul();
break;
case operatorids.divide :
idiv();
break;
case operatorids.remainder :
irem();
break;
case operatorids.left_shift :
ishl();
break;
case operatorids.right_shift :
ishr();
break;
case operatorids.unsigned_right_shift :
iushr();
break;
case operatorids.and :
iand();
break;
case operatorids.or :
ior();
break;
case operatorids.xor :
ixor();
break;
}
break;
case typeids.t_long :
switch (operatorconstant) {
case operatorids.plus :
ladd();
break;
case operatorids.minus :
lsub();
break;
case operatorids.multiply :
lmul();
break;
case operatorids.divide :
ldiv();
break;
case operatorids.remainder :
lrem();
break;
case operatorids.left_shift :
lshl();
break;
case operatorids.right_shift :
lshr();
break;
case operatorids.unsigned_right_shift :
lushr();
break;
case operatorids.and :
land();
break;
case operatorids.or :
lor();
break;
case operatorids.xor :
lxor();
break;
}
break;
case typeids.t_float :
switch (operatorconstant) {
case operatorids.plus :
fadd();
break;
case operatorids.minus :
fsub();
break;
case operatorids.multiply :
fmul();
break;
case operatorids.divide :
fdiv();
break;
case operatorids.remainder :
frem();
}
break;
case typeids.t_double :
switch (operatorconstant) {
case operatorids.plus :
dadd();
break;
case operatorids.minus :
dsub();
break;
case operatorids.multiply :
dmul();
break;
case operatorids.divide :
ddiv();
break;
case operatorids.remainder :
drem();
}
}
}

public void sipush(int s) {
this.countlabels = 0;
this.stackdepth++;
if (this.stackdepth > this.stackmax)
this.stackmax = this.stackdepth;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_sipush;
writesignedshort(s);
}

public void store(localvariablebinding localbinding, boolean valuerequired) {
int localposition = localbinding.resolvedposition;
// using dedicated int bytecode
switch(localbinding.type.id) {
case typeids.t_int :
case typeids.t_char :
case typeids.t_byte :
case typeids.t_short :
case typeids.t_boolean :
if (valuerequired)
dup();
switch (localposition) {
case 0 :
istore_0();
break;
case 1 :
istore_1();
break;
case 2 :
istore_2();
break;
case 3 :
istore_3();
break;
//case -1 :
// internal failure: trying to store into variable not supposed to be generated
//	break;
default :
istore(localposition);
}
break;
case typeids.t_float :
if (valuerequired)
dup();
switch (localposition) {
case 0 :
fstore_0();
break;
case 1 :
fstore_1();
break;
case 2 :
fstore_2();
break;
case 3 :
fstore_3();
break;
default :
fstore(localposition);
}
break;
case typeids.t_double :
if (valuerequired)
dup2();
switch (localposition) {
case 0 :
dstore_0();
break;
case 1 :
dstore_1();
break;
case 2 :
dstore_2();
break;
case 3 :
dstore_3();
break;
default :
dstore(localposition);
}
break;
case typeids.t_long :
if (valuerequired)
dup2();
switch (localposition) {
case 0 :
lstore_0();
break;
case 1 :
lstore_1();
break;
case 2 :
lstore_2();
break;
case 3 :
lstore_3();
break;
default :
lstore(localposition);
}
break;
default:
// reference object
if (valuerequired)
dup();
switch (localposition) {
case 0 :
astore_0();
break;
case 1 :
astore_1();
break;
case 2 :
astore_2();
break;
case 3 :
astore_3();
break;
default :
astore(localposition);
}
}
}

public void swap() {
this.countlabels = 0;
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_swap;
}

public void tableswitch(caselabel defaultlabel, int low, int high, int[] keys, int[] sortedindexes, caselabel[] caseslabel) {
this.countlabels = 0;
this.stackdepth--;
int length = caseslabel.length;
int pos = this.position;
defaultlabel.placeinstruction();
for (int i = 0; i < length; i++)
caseslabel[i].placeinstruction();
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = opcodes.opc_tableswitch;
// padding
for (int i = (3 - (pos & 3)); i > 0; i--) {
if (this.classfileoffset >= this.bcodestream.length) {
resizebytearray();
}
this.position++;
this.bcodestream[this.classfileoffset++] = 0;
}
defaultlabel.branch();
writesignedword(low);
writesignedword(high);
int i = low, j = low;
// the index j is used to know if the index i is one of the missing entries in case of an
// optimized tableswitch
while (true) {
int index;
int key = keys[index = sortedindexes[j - low]];
if (key == i) {
caseslabel[index].branch();
j++;
if (i == high) break; // if high is maxint, then avoids wrapping to minint.
} else {
defaultlabel.branch();
}
i++;
}
}

public void throwanyexception(localvariablebinding anyexceptionvariable) {
this.load(anyexceptionvariable);
athrow();
}

public string tostring() {
stringbuffer buffer = new stringbuffer("( position:"); //$non-nls-1$
buffer.append(this.position);
buffer.append(",\nstackdepth:"); //$non-nls-1$
buffer.append(this.stackdepth);
buffer.append(",\nmaxstack:"); //$non-nls-1$
buffer.append(this.stackmax);
buffer.append(",\nmaxlocals:"); //$non-nls-1$
buffer.append(this.maxlocals);
buffer.append(")"); //$non-nls-1$
return buffer.tostring();
}

/**
* note: it will walk the locals table and extend the end range for all matching ones, no matter if
* visible or not.
* {  int i = 0;
*    {  int j = 1; }
* }   <== would process both 'i' and 'j'
* processing non-visible ones is mandated in some cases (include goto instruction after if-then block)
*/
public void updatelastrecordedendpc(scope scope, int pos) {

/* tune positions in the table, this is due to some
* extra bytecodes being
* added to some user code (jumps). */
/** old code
if (!generatelinenumberattributes)
return;
pctosourcemap[pctosourcemapsize - 1][1] = position;
// need to update the initialization endpc in case of generation of local variable attributes.
updatelocalvariablesattribute(pos);
*/

if ((this.generateattributes & classfileconstants.attr_lines) != 0) {
this.lastentrypc = pos;
}
// need to update the initialization endpc in case of generation of local variable attributes.
if ((this.generateattributes & (classfileconstants.attr_vars
| classfileconstants.attr_stack_map_table
| classfileconstants.attr_stack_map)) != 0) {
for (int i = 0, max = this.locals.length; i < max; i++) {
localvariablebinding local = this.locals[i];
if (local != null && local.declaringscope == scope && local.initializationcount > 0) {
if (local.initializationpcs[((local.initializationcount - 1) << 1) + 1] == pos) {
local.initializationpcs[((local.initializationcount - 1) << 1) + 1] = this.position;
}
}
}
}
}

protected void writeposition(branchlabel label) {
int offset = label.position - this.position + 1;
if (math.abs(offset) > 0x7fff && !this.widemode) {
throw new abortmethod(codestream.restart_in_wide_mode, null);
}
this.writesignedshort(offset);
int[] forwardrefs = label.forwardreferences();
for (int i = 0, max = label.forwardreferencecount(); i < max; i++) {
this.writeposition(label, forwardrefs[i]);
}
}

protected void writeposition(branchlabel label, int forwardreference) {
final int offset = label.position - forwardreference + 1;
if (math.abs(offset) > 0x7fff && !this.widemode) {
throw new abortmethod(codestream.restart_in_wide_mode, null);
}
if (this.widemode) {
if ((label.tagbits & branchlabel.wide) != 0) {
this.writesignedword(forwardreference, offset);
} else {
this.writesignedshort(forwardreference, offset);
}
} else {
this.writesignedshort(forwardreference, offset);
}
}

/**
* write a signed 16 bits value into the byte array
* @@param value the signed short
*/
private final void writesignedshort(int value) {
// we keep the resize in here because it is used outside the code stream
if (this.classfileoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 2;
this.bcodestream[this.classfileoffset++] = (byte) (value >> 8);
this.bcodestream[this.classfileoffset++] = (byte) value;
}

private final void writesignedshort(int pos, int value) {
int currentoffset = this.startingclassfileoffset + pos;
if (currentoffset + 1 >= this.bcodestream.length) {
resizebytearray();
}
this.bcodestream[currentoffset] = (byte) (value >> 8);
this.bcodestream[currentoffset + 1] = (byte) value;
}

protected final void writesignedword(int value) {
// we keep the resize in here because it is used outside the code stream
if (this.classfileoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.position += 4;
this.bcodestream[this.classfileoffset++] = (byte) ((value & 0xff000000) >> 24);
this.bcodestream[this.classfileoffset++] = (byte) ((value & 0xff0000) >> 16);
this.bcodestream[this.classfileoffset++] = (byte) ((value & 0xff00) >> 8);
this.bcodestream[this.classfileoffset++] = (byte) (value & 0xff);
}

protected void writesignedword(int pos, int value) {
int currentoffset = this.startingclassfileoffset + pos;
if (currentoffset + 3 >= this.bcodestream.length) {
resizebytearray();
}
this.bcodestream[currentoffset++] = (byte) ((value & 0xff000000) >> 24);
this.bcodestream[currentoffset++] = (byte) ((value & 0xff0000) >> 16);
this.bcodestream[currentoffset++] = (byte) ((value & 0xff00) >> 8);
this.bcodestream[currentoffset++] = (byte) (value & 0xff);
}

/**
* write a unsigned 16 bits value into the byte array
* @@param value the unsigned short
*/
private final void writeunsignedshort(int value) {
// no bound check since used only from within codestream where already checked
this.position += 2;
this.bcodestream[this.classfileoffset++] = (byte) (value >>> 8);
this.bcodestream[this.classfileoffset++] = (byte) value;
}

protected void writewideposition(branchlabel label) {
int labelpos = label.position;
int offset = labelpos - this.position + 1;
this.writesignedword(offset);
int[] forwardrefs = label.forwardreferences();
for (int i = 0, max = label.forwardreferencecount(); i < max; i++) {
int forward = forwardrefs[i];
offset = labelpos - forward + 1;
this.writesignedword(forward, offset);
}
}
}
