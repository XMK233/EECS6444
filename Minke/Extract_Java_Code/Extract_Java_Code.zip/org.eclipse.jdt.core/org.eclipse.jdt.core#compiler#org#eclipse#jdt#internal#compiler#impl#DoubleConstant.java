/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.impl;

public class doubleconstant extends constant {

private double value;

public static constant fromvalue(double value) {
return new doubleconstant(value);
}

private doubleconstant(double value) {
this.value = value;
}

public byte bytevalue() {
return (byte) this.value;
}

public char charvalue() {
return (char) this.value;
}

public double doublevalue() {
return this.value;
}

public float floatvalue() {
return (float) this.value;
}

public int intvalue() {
return (int) this.value;
}

public long longvalue() {
return (long) this.value;
}

public short shortvalue() {
return (short) this.value;
}

public string stringvalue() {
return string.valueof(this.value);
}

public string tostring() {
if (this == notaconstant)
return "(constant) notaconstant"; //$non-nls-1$
return "(double)" + this.value;  //$non-nls-1$
}

public int typeid() {
return t_double;
}
}
