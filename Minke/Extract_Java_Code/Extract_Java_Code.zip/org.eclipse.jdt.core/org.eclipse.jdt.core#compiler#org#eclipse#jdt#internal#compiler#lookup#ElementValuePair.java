/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.constant;

public class elementvaluepair {
char[] name;
public object value;
public methodbinding binding;

public static object getvalue(expression expression) {
if (expression == null)
return null;
constant constant = expression.constant;
// literals would hit this case.
if (constant != null && constant != constant.notaconstant)
return constant;

if (expression instanceof annotation)
return ((annotation) expression).getcompilerannotation();
if (expression instanceof arrayinitializer) {
expression[] exprs = ((arrayinitializer) expression).expressions;
int length = exprs == null ? 0 : exprs.length;
object[] values = new object[length];
for (int i = 0; i < length; i++)
values[i] = getvalue(exprs[i]);
return values;
}
if (expression instanceof classliteralaccess)
return ((classliteralaccess) expression).targettype;
if (expression instanceof reference) {
fieldbinding fieldbinding = null;
if (expression instanceof fieldreference) {
fieldbinding = ((fieldreference) expression).fieldbinding();
} else if (expression instanceof namereference) {
binding binding = ((namereference) expression).binding;
if (binding != null && binding.kind() == binding.field)
fieldbinding = (fieldbinding) binding;
}
if (fieldbinding != null && (fieldbinding.modifiers & classfileconstants.accenum) > 0)
return fieldbinding;
}
// something that isn't a compile time constant.
return null;
}

public elementvaluepair(char[] name, expression expression, methodbinding binding) {
this(name, elementvaluepair.getvalue(expression), binding);
}

public elementvaluepair(char[] name, object value, methodbinding binding) {
this.name = name;
this.value = value;
this.binding = binding;
}

/**
* @@return the name of the element value pair.
*/
public char[] getname() {
return this.name;
}

/**
* @@return the method binding that defined this member value pair or null if no such binding exists.
*/
public methodbinding getmethodbinding() {
return this.binding;
}

/**
* return {@@link typebinding} for member value of type {@@link java.lang.class}
* return {@@link org.eclipse.jdt.internal.compiler.impl.constant} for member of primitive type or string
* return {@@link fieldbinding} for enum constant
* return {@@link annotationbinding} for annotation instance
* return <code>object[]</code> for member value of array type.
* @@return the value of this member value pair or null if the value is missing or is not a compile-time constant
*/
public object getvalue() {
return this.value;
}

void setmethodbinding(methodbinding binding) {
// lazily set after annotation type was resolved
this.binding = binding;
}

void setvalue(object value) {
// can be modified after the initialization if holding an unresolved ref
this.value = value;
}

public string tostring() {
stringbuffer buffer = new stringbuffer(5);
buffer.append(this.name).append(" = "); //$non-nls-1$
buffer.append(this.value);
return buffer.tostring();
}
}
