/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.wildcard;

/**
* binding denoting a method after type parameter substitutions got performed.
* on parameterized type bindings, all methods got substituted, regardless whether
* their signature did involve generics or not, so as to get the proper declaringclass for
* these methods.
*/
public class parameterizedmethodbinding extends methodbinding {

protected methodbinding originalmethod;

/**
* create method of parameterized type, substituting original parameters/exception/return type with type arguments.
*/
public parameterizedmethodbinding(final parameterizedtypebinding parameterizeddeclaringclass, methodbinding originalmethod) {
super(
originalmethod.modifiers,
originalmethod.selector,
originalmethod.returntype,
originalmethod.parameters,
originalmethod.thrownexceptions,
parameterizeddeclaringclass);
this.originalmethod = originalmethod;
this.tagbits = originalmethod.tagbits;

final typevariablebinding[] originalvariables = originalmethod.typevariables;
substitution substitution = null;
final int length = originalvariables.length;
final boolean isstatic = originalmethod.isstatic();
if (length == 0) {
this.typevariables = binding.no_type_variables;
if (!isstatic) substitution = parameterizeddeclaringclass;
} else {
// at least fix up the declaringelement binding + bound substitution if non static
final typevariablebinding[] substitutedvariables = new typevariablebinding[length];
for (int i = 0; i < length; i++) { // copy original type variable to relocate
typevariablebinding originalvariable = originalvariables[i];
substitutedvariables[i] = new typevariablebinding(originalvariable.sourcename, this, originalvariable.rank, parameterizeddeclaringclass.environment);
}
this.typevariables = substitutedvariables;

// need to substitute old var refs with new ones (double substitution: declaringclass + new type variables)
substitution = new substitution() {
public lookupenvironment environment() {
return parameterizeddeclaringclass.environment;
}
public boolean israwsubstitution() {
return !isstatic && parameterizeddeclaringclass.israwsubstitution();
}
public typebinding substitute(typevariablebinding typevariable) {
// check this variable can be substituted given copied variables
if (typevariable.rank < length && originalvariables[typevariable.rank] == typevariable) {
return substitutedvariables[typevariable.rank];
}
if (!isstatic)
return parameterizeddeclaringclass.substitute(typevariable);
return typevariable;
}
};

// initialize new variable bounds
for (int i = 0; i < length; i++) {
typevariablebinding originalvariable = originalvariables[i];
typevariablebinding substitutedvariable = substitutedvariables[i];
typebinding substitutedsuperclass = scope.substitute(substitution, originalvariable.superclass);
referencebinding[] substitutedinterfaces = scope.substitute(substitution, originalvariable.superinterfaces);
if (originalvariable.firstbound != null) {
substitutedvariable.firstbound = originalvariable.firstbound == originalvariable.superclass
? substitutedsuperclass // could be array type or interface
: substitutedinterfaces[0];
}
switch (substitutedsuperclass.kind()) {
case binding.array_type :
substitutedvariable.superclass = parameterizeddeclaringclass.environment.getresolvedtype(typeconstants.java_lang_object, null);
substitutedvariable.superinterfaces = substitutedinterfaces;
break;
default:
if (substitutedsuperclass.isinterface()) {
substitutedvariable.superclass = parameterizeddeclaringclass.environment.getresolvedtype(typeconstants.java_lang_object, null);
int interfacecount = substitutedinterfaces.length;
system.arraycopy(substitutedinterfaces, 0, substitutedinterfaces = new referencebinding[interfacecount+1], 1, interfacecount);
substitutedinterfaces[0] = (referencebinding) substitutedsuperclass;
substitutedvariable.superinterfaces = substitutedinterfaces;
} else {
substitutedvariable.superclass = (referencebinding) substitutedsuperclass; // typevar was extending other typevar which got substituted with interface
substitutedvariable.superinterfaces = substitutedinterfaces;
}
}
}
}
if (substitution != null) {
this.returntype = scope.substitute(substitution, this.returntype);
this.parameters = scope.substitute(substitution, this.parameters);
this.thrownexceptions = scope.substitute(substitution, this.thrownexceptions);
// error case where exception type variable would have been substituted by a non-reference type (207573)
if (this.thrownexceptions == null) this.thrownexceptions = binding.no_exceptions;
}
checkmissingtype: {
if ((this.tagbits & tagbits.hasmissingtype) != 0)
break checkmissingtype;
if ((this.returntype.tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
for (int i = 0, max = this.parameters.length; i < max; i++) {
if ((this.parameters[i].tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
}
for (int i = 0, max = this.thrownexceptions.length; i < max; i++) {
if ((this.thrownexceptions[i].tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
}
}
}

/**
* create method of parameterized type, substituting original parameters/exception/return type with type arguments.
* this is a code assist method only.
*/
public parameterizedmethodbinding(final referencebinding declaringclass, methodbinding originalmethod, char[][] alternateparamaternames, final lookupenvironment environment) {
super(
originalmethod.modifiers,
originalmethod.selector,
originalmethod.returntype,
originalmethod.parameters,
originalmethod.thrownexceptions,
declaringclass);
this.originalmethod = originalmethod;
this.tagbits = originalmethod.tagbits;

final typevariablebinding[] originalvariables = originalmethod.typevariables;
substitution substitution = null;
final int length = originalvariables.length;
if (length == 0) {
this.typevariables = binding.no_type_variables;
} else {
// at least fix up the declaringelement binding + bound substitution if non static
final typevariablebinding[] substitutedvariables = new typevariablebinding[length];
for (int i = 0; i < length; i++) { // copy original type variable to relocate
typevariablebinding originalvariable = originalvariables[i];
substitutedvariables[i] = new typevariablebinding(
alternateparamaternames == null ?
originalvariable.sourcename :
alternateparamaternames[i],
this,
originalvariable.rank,
environment);
}
this.typevariables = substitutedvariables;

// need to substitute old var refs with new ones (double substitution: declaringclass + new type variables)
substitution = new substitution() {
public lookupenvironment environment() {
return environment;
}
public boolean israwsubstitution() {
return false;
}
public typebinding substitute(typevariablebinding typevariable) {
// check this variable can be substituted given copied variables
if (typevariable.rank < length && originalvariables[typevariable.rank] == typevariable) {
return substitutedvariables[typevariable.rank];
}
return typevariable;
}
};

// initialize new variable bounds
for (int i = 0; i < length; i++) {
typevariablebinding originalvariable = originalvariables[i];
typevariablebinding substitutedvariable = substitutedvariables[i];
typebinding substitutedsuperclass = scope.substitute(substitution, originalvariable.superclass);
referencebinding[] substitutedinterfaces = scope.substitute(substitution, originalvariable.superinterfaces);
if (originalvariable.firstbound != null) {
substitutedvariable.firstbound = originalvariable.firstbound == originalvariable.superclass
? substitutedsuperclass // could be array type or interface
: substitutedinterfaces[0];
}
switch (substitutedsuperclass.kind()) {
case binding.array_type :
substitutedvariable.superclass = environment.getresolvedtype(typeconstants.java_lang_object, null);
substitutedvariable.superinterfaces = substitutedinterfaces;
break;
default:
if (substitutedsuperclass.isinterface()) {
substitutedvariable.superclass = environment.getresolvedtype(typeconstants.java_lang_object, null);
int interfacecount = substitutedinterfaces.length;
system.arraycopy(substitutedinterfaces, 0, substitutedinterfaces = new referencebinding[interfacecount+1], 1, interfacecount);
substitutedinterfaces[0] = (referencebinding) substitutedsuperclass;
substitutedvariable.superinterfaces = substitutedinterfaces;
} else {
substitutedvariable.superclass = (referencebinding) substitutedsuperclass; // typevar was extending other typevar which got substituted with interface
substitutedvariable.superinterfaces = substitutedinterfaces;
}
}
}
}
if (substitution != null) {
this.returntype = scope.substitute(substitution, this.returntype);
this.parameters = scope.substitute(substitution, this.parameters);
this.thrownexceptions = scope.substitute(substitution, this.thrownexceptions);
// error case where exception type variable would have been substituted by a non-reference type (207573)
if (this.thrownexceptions == null) this.thrownexceptions = binding.no_exceptions;
}
checkmissingtype: {
if ((this.tagbits & tagbits.hasmissingtype) != 0)
break checkmissingtype;
if ((this.returntype.tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
for (int i = 0, max = this.parameters.length; i < max; i++) {
if ((this.parameters[i].tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
}
for (int i = 0, max = this.thrownexceptions.length; i < max; i++) {
if ((this.thrownexceptions[i].tagbits & tagbits.hasmissingtype) != 0) {
this.tagbits |=  tagbits.hasmissingtype;
break checkmissingtype;
}
}
}
}

public parameterizedmethodbinding() {
// no init
}

/**
* the type of x.getclass() is substituted from 'class<? extends object>' into: 'class<? extends raw(x)>
*/
public static parameterizedmethodbinding instantiategetclass(typebinding receivertype, methodbinding originalmethod, scope scope) {
parameterizedmethodbinding method = new parameterizedmethodbinding();
method.modifiers = originalmethod.modifiers;
method.selector = originalmethod.selector;
method.declaringclass = originalmethod.declaringclass;
method.typevariables = binding.no_type_variables;
method.originalmethod = originalmethod;
method.parameters = originalmethod.parameters;
method.thrownexceptions = originalmethod.thrownexceptions;
method.tagbits = originalmethod.tagbits;
referencebinding genericclasstype = scope.getjavalangclass();
lookupenvironment environment = scope.environment();
typebinding rawtype = environment.converttorawtype(receivertype.erasure(), false /*do not force conversion of enclosing types*/);
method.returntype = environment.createparameterizedtype(
genericclasstype,
new typebinding[] {  environment.createwildcard(genericclasstype, 0, rawtype, null /*no extra bound*/, wildcard.extends) },
null);
if ((method.returntype.tagbits & tagbits.hasmissingtype) != 0) {
method.tagbits |=  tagbits.hasmissingtype;
}
return method;
}

/**
* returns true if some parameters got substituted.
*/
public boolean hassubstitutedparameters() {
return this.parameters != this.originalmethod.parameters;
}

/**
* returns true if the return type got substituted.
*/
public boolean hassubstitutedreturntype() {
return this.returntype != this.originalmethod.returntype;
}

/**
* returns the original method (as opposed to parameterized instances)
*/
public methodbinding original() {
return this.originalmethod.original();
}
}
