/*******************************************************************************
* copyright (c) 2005, 2009 bea systems, inc.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*    tyeung@@bea.com - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.codegen.attributenamesconstants;

public class annotationmethodinfo extends methodinfo {
protected object defaultvalue = null;

public static methodinfo createannotationmethod(byte classfilebytes[], int offsets[], int offset) {
methodinfo methodinfo = new methodinfo(classfilebytes, offsets, offset);
int attributescount = methodinfo.u2at(6);
int readoffset = 8;
annotationinfo[] annotations = null;
object defaultvalue = null;
for (int i = 0; i < attributescount; i++) {
// check the name of each attribute
int utf8offset = methodinfo.constantpooloffsets[methodinfo.u2at(readoffset)] - methodinfo.structoffset;
char[] attributename = methodinfo.utf8at(utf8offset + 3, methodinfo.u2at(utf8offset + 1));
if (attributename.length > 0) {
switch(attributename[0]) {
case 'a':
if (charoperation.equals(attributename, attributenamesconstants.annotationdefaultname)) {
// readoffset + 6 so the offset is at the start of the 'member_value' entry
// u2 attribute_name_index + u4 attribute_length = + 6
annotationinfo info =
new annotationinfo(methodinfo.reference, methodinfo.constantpooloffsets, readoffset + 6 + methodinfo.structoffset);
defaultvalue = info.decodedefaultvalue();
}
break;
case 's' :
if (charoperation.equals(attributenamesconstants.signaturename, attributename))
methodinfo.signatureutf8offset = methodinfo.constantpooloffsets[methodinfo.u2at(readoffset + 6)] - methodinfo.structoffset;
break;
case 'r' :
annotationinfo[] methodannotations = null;
if (charoperation.equals(attributename, attributenamesconstants.runtimevisibleannotationsname)) {
methodannotations = decodemethodannotations(readoffset, true, methodinfo);
} else if (charoperation.equals(attributename, attributenamesconstants.runtimeinvisibleannotationsname)) {
methodannotations = decodemethodannotations(readoffset, false, methodinfo);
}
if (methodannotations != null) {
if (annotations == null) {
annotations = methodannotations;
} else {
int length = annotations.length;
annotationinfo[] newannotations = new annotationinfo[length + methodannotations.length];
system.arraycopy(annotations, 0, newannotations, 0, length);
system.arraycopy(methodannotations, 0, newannotations, length, methodannotations.length);
annotations = newannotations;
}
}
break;
}
}
readoffset += (6 + methodinfo.u4at(readoffset + 2));
}
methodinfo.attributebytes = readoffset;

if (defaultvalue != null) {
if (annotations != null) {
return new annotationmethodinfowithannotations(methodinfo, defaultvalue, annotations);
}
return new annotationmethodinfo(methodinfo, defaultvalue);
}
if (annotations != null)
return new methodinfowithannotations(methodinfo, annotations);
return methodinfo;
}

annotationmethodinfo(methodinfo methodinfo, object defaultvalue) {
super(methodinfo.reference, methodinfo.constantpooloffsets, methodinfo.structoffset);
this.defaultvalue = defaultvalue;

this.accessflags = methodinfo.accessflags;
this.attributebytes = methodinfo.attributebytes;
this.descriptor = methodinfo.descriptor;
this.exceptionnames = methodinfo.exceptionnames;
this.name = methodinfo.name;
this.signature = methodinfo.signature;
this.signatureutf8offset = methodinfo.signatureutf8offset;
this.tagbits = methodinfo.tagbits;
}
public object getdefaultvalue() {
return this.defaultvalue;
}
protected void tostringcontent(stringbuffer buffer) {
super.tostringcontent(buffer);
if (this.defaultvalue != null) {
buffer.append(" default "); //$non-nls-1$
if (this.defaultvalue instanceof object[]) {
buffer.append('{');
object[] elements = (object[]) this.defaultvalue;
for (int i = 0, len = elements.length; i < len; i++) {
if (i > 0)
buffer.append(", "); //$non-nls-1$
buffer.append(elements[i]);
}
buffer.append('}');
} else {
buffer.append(this.defaultvalue);
}
buffer.append('\n');
}
}
}
