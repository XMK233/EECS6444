/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.expression;
import org.eclipse.jdt.internal.compiler.ast.labeledstatement;
import org.eclipse.jdt.internal.compiler.ast.reference;
import org.eclipse.jdt.internal.compiler.ast.subroutinestatement;
import org.eclipse.jdt.internal.compiler.ast.trystatement;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.codegen.branchlabel;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeconstants;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.lookup.variablebinding;

/**
* reflects the context of code analysis, keeping track of enclosing
*	try statements, exception handlers, etc...
*/
public class flowcontext implements typeconstants {

// preempt marks looping contexts
public final static flowcontext notcontinuablecontext = new flowcontext(null, null);
public astnode associatednode;
public flowcontext parent;
public nullinforegistry initsonfinally;
// only used within try blocks; remembers upstream flow info mergedwith
// any null related operation happening within the try block

public int tagbits;
public static final int defer_null_diagnostic = 0x1;
public static final int preempt_null_diagnostic = 0x2;
/**
* used to hide null comparison related warnings inside assert statements
*/
public static final int hide_null_comparison_warning = 0x4;

public static final int can_only_null_non_null = 0x0000;
//check against null and non null, with definite values -- comparisons
public static final int can_only_null = 0x0001;
//check against null, with definite values -- comparisons
public static final int can_only_non_null = 0x0002;
//check against non null, with definite values -- comparisons
public static final int may_null = 0x0003;
// check against null, with potential values -- npe guard
public static final int check_mask = 0x00ff;
public static final int in_comparison_null = 0x0100;
public static final int in_comparison_non_null = 0x0200;
// check happened in a comparison
public static final int in_assignment = 0x0300;
// check happened in an assignment
public static final int in_instanceof = 0x0400;
// check happened in an instanceof expression
public static final int context_mask = ~check_mask;

public flowcontext(flowcontext parent, astnode associatednode) {
this.parent = parent;
this.associatednode = associatednode;
if (parent != null) {
if ((parent.tagbits & (flowcontext.defer_null_diagnostic | flowcontext.preempt_null_diagnostic)) != 0) {
this.tagbits |= flowcontext.defer_null_diagnostic;
}
this.initsonfinally = parent.initsonfinally;
}
}

public branchlabel breaklabel() {
return null;
}

public void checkexceptionhandlers(typebinding raisedexception, astnode location, flowinfo flowinfo, blockscope scope) {
// light-version of the equivalent with an array of exceptions
// check that all the argument exception types are handled
// jdk compatible implementation - when an exception type is thrown,
// all related catch blocks are marked as reachable... instead of those only
// until the point where it is safely handled (smarter - see comment at the end)
flowcontext traversedcontext = this;
while (traversedcontext != null) {
subroutinestatement sub;
if (((sub = traversedcontext.subroutine()) != null) && sub.issubroutineescaping()) {
// traversing a non-returning subroutine means that all unhandled
// exceptions will actually never get sent...
return;
}

// filter exceptions that are locally caught from the innermost enclosing
// try statement to the outermost ones.
if (traversedcontext instanceof exceptionhandlingflowcontext) {
exceptionhandlingflowcontext exceptioncontext =
(exceptionhandlingflowcontext) traversedcontext;
referencebinding[] caughtexceptions;
if ((caughtexceptions = exceptioncontext.handledexceptions) != binding.no_exceptions) {
boolean definitelycaught = false;
for (int caughtindex = 0, caughtcount = caughtexceptions.length;
caughtindex < caughtcount;
caughtindex++) {
referencebinding caughtexception = caughtexceptions[caughtindex];
int state = caughtexception == null
? scope.equal_or_more_specific /* any exception */
: scope.comparetypes(raisedexception, caughtexception);
switch (state) {
case scope.equal_or_more_specific :
exceptioncontext.recordhandlingexception(
caughtexception,
flowinfo.unconditionalinits(),
raisedexception,
location,
definitelycaught);
// was it already definitely caught ?
definitelycaught = true;
break;
case scope.more_generic :
exceptioncontext.recordhandlingexception(
caughtexception,
flowinfo.unconditionalinits(),
raisedexception,
location,
false);
// was not caught already per construction
}
}
if (definitelycaught)
return;
}
// method treatment for unchecked exceptions
if (exceptioncontext.ismethodcontext) {
if (raisedexception.isuncheckedexception(false))
return;

// anonymous constructors are allowed to throw any exceptions (their thrown exceptions
// clause will be fixed up later as per jls 8.6).
if (exceptioncontext.associatednode instanceof abstractmethoddeclaration){
abstractmethoddeclaration method = (abstractmethoddeclaration)exceptioncontext.associatednode;
if (method.isconstructor() && method.binding.declaringclass.isanonymoustype()){

exceptioncontext.mergeunhandledexception(raisedexception);
return; // no need to complain, will fix up constructor exceptions
}
}
break; // not handled anywhere, thus jump to error handling
}
}

traversedcontext.recordreturnfrom(flowinfo.unconditionalinits());

if (traversedcontext instanceof insidesubroutineflowcontext) {
astnode node = traversedcontext.associatednode;
if (node instanceof trystatement) {
trystatement trystatement = (trystatement) node;
flowinfo.addinitializationsfrom(trystatement.subroutineinits); // collect inits
}
}
traversedcontext = traversedcontext.parent;
}
// if reaches this point, then there are some remaining unhandled exception types.
scope.problemreporter().unhandledexception(raisedexception, location);
}

public void checkexceptionhandlers(typebinding[] raisedexceptions, astnode location, flowinfo flowinfo, blockscope scope) {
// check that all the argument exception types are handled
// jdk compatible implementation - when an exception type is thrown,
// all related catch blocks are marked as reachable... instead of those only
// until the point where it is safely handled (smarter - see comment at the end)
int remainingcount; // counting the number of remaining unhandled exceptions
int raisedcount; // total number of exceptions raised
if ((raisedexceptions == null)
|| ((raisedcount = raisedexceptions.length) == 0))
return;
remainingcount = raisedcount;

// duplicate the array of raised exceptions since it will be updated
// (null replaces any handled exception)
system.arraycopy(
raisedexceptions,
0,
(raisedexceptions = new typebinding[raisedcount]),
0,
raisedcount);
flowcontext traversedcontext = this;

while (traversedcontext != null) {
subroutinestatement sub;
if (((sub = traversedcontext.subroutine()) != null) && sub.issubroutineescaping()) {
// traversing a non-returning subroutine means that all unhandled
// exceptions will actually never get sent...
return;
}
// filter exceptions that are locally caught from the innermost enclosing
// try statement to the outermost ones.
if (traversedcontext instanceof exceptionhandlingflowcontext) {
exceptionhandlingflowcontext exceptioncontext =
(exceptionhandlingflowcontext) traversedcontext;
referencebinding[] caughtexceptions;
if ((caughtexceptions = exceptioncontext.handledexceptions) != binding.no_exceptions) {
int caughtcount = caughtexceptions.length;
boolean[] locallycaught = new boolean[raisedcount]; // at most

for (int caughtindex = 0; caughtindex < caughtcount; caughtindex++) {
referencebinding caughtexception = caughtexceptions[caughtindex];
for (int raisedindex = 0; raisedindex < raisedcount; raisedindex++) {
typebinding raisedexception;
if ((raisedexception = raisedexceptions[raisedindex]) != null) {
int state = caughtexception == null
? scope.equal_or_more_specific /* any exception */
: scope.comparetypes(raisedexception, caughtexception);
switch (state) {
case scope.equal_or_more_specific :
exceptioncontext.recordhandlingexception(
caughtexception,
flowinfo.unconditionalinits(),
raisedexception,
location,
locallycaught[raisedindex]);
// was already definitely caught ?
if (!locallycaught[raisedindex]) {
locallycaught[raisedindex] = true;
// remember that this exception has been definitely caught
remainingcount--;
}
break;
case scope.more_generic :
exceptioncontext.recordhandlingexception(
caughtexception,
flowinfo.unconditionalinits(),
raisedexception,
location,
false);
// was not caught already per construction
}
}
}
}
// remove locally caught exceptions from the remaining ones
for (int i = 0; i < raisedcount; i++) {
if (locallycaught[i]) {
raisedexceptions[i] = null; // removed from the remaining ones.
}
}
}
// method treatment for unchecked exceptions
if (exceptioncontext.ismethodcontext) {
for (int i = 0; i < raisedcount; i++) {
typebinding raisedexception;
if ((raisedexception = raisedexceptions[i]) != null) {
if (raisedexception.isuncheckedexception(false)) {
remainingcount--;
raisedexceptions[i] = null;
}
}
}
// anonymous constructors are allowed to throw any exceptions (their thrown exceptions
// clause will be fixed up later as per jls 8.6).
if (exceptioncontext.associatednode instanceof abstractmethoddeclaration){
abstractmethoddeclaration method = (abstractmethoddeclaration)exceptioncontext.associatednode;
if (method.isconstructor() && method.binding.declaringclass.isanonymoustype()){

for (int i = 0; i < raisedcount; i++) {
typebinding raisedexception;
if ((raisedexception = raisedexceptions[i]) != null) {
exceptioncontext.mergeunhandledexception(raisedexception);
}
}
return; // no need to complain, will fix up constructor exceptions
}
}
break; // not handled anywhere, thus jump to error handling
}
}
if (remainingcount == 0)
return;

traversedcontext.recordreturnfrom(flowinfo.unconditionalinits());

if (traversedcontext instanceof insidesubroutineflowcontext) {
astnode node = traversedcontext.associatednode;
if (node instanceof trystatement) {
trystatement trystatement = (trystatement) node;
flowinfo.addinitializationsfrom(trystatement.subroutineinits); // collect inits
}
}
traversedcontext = traversedcontext.parent;
}
// if reaches this point, then there are some remaining unhandled exception types.
nextreport: for (int i = 0; i < raisedcount; i++) {
typebinding exception;
if ((exception = raisedexceptions[i]) != null) {
// only one complaint if same exception declared to be thrown more than once
for (int j = 0; j < i; j++) {
if (raisedexceptions[j] == exception) continue nextreport; // already reported
}
scope.problemreporter().unhandledexception(exception, location);
}
}
}

public branchlabel continuelabel() {
return null;
}

public flowinfo getinitsforfinalblankinitializationcheck(typebinding declaringtype, flowinfo flowinfo) {
flowcontext current = this;
flowinfo inits = flowinfo;
do {
if (current instanceof initializationflowcontext) {
initializationflowcontext initializationcontext = (initializationflowcontext) current;
if (((typedeclaration)initializationcontext.associatednode).binding == declaringtype) {
return inits;
}
inits = initializationcontext.initsbeforecontext;
current = initializationcontext.initializationparent;
} else if (current instanceof exceptionhandlingflowcontext) {
exceptionhandlingflowcontext exceptioncontext = (exceptionhandlingflowcontext) current;
current = exceptioncontext.initializationparent == null ? exceptioncontext.parent : exceptioncontext.initializationparent;
} else {
current = current.parent;
}
} while (current != null);
// not found
return null;
}

/*
* lookup through break labels
*/
public flowcontext gettargetcontextforbreaklabel(char[] labelname) {
flowcontext current = this, lastnonreturningsubroutine = null;
while (current != null) {
if (current.isnonreturningcontext()) {
lastnonreturningsubroutine = current;
}
char[] currentlabelname;
if (((currentlabelname = current.labelname()) != null)
&& charoperation.equals(currentlabelname, labelname)) {
((labeledstatement)current.associatednode).bits |= astnode.labelused;
if (lastnonreturningsubroutine == null)
return current;
return lastnonreturningsubroutine;
}
current = current.parent;
}
// not found
return null;
}

/*
* lookup through continue labels
*/
public flowcontext gettargetcontextforcontinuelabel(char[] labelname) {
flowcontext current = this;
flowcontext lastcontinuable = null;
flowcontext lastnonreturningsubroutine = null;

while (current != null) {
if (current.isnonreturningcontext()) {
lastnonreturningsubroutine = current;
} else {
if (current.iscontinuable()) {
lastcontinuable = current;
}
}

char[] currentlabelname;
if ((currentlabelname = current.labelname()) != null && charoperation.equals(currentlabelname, labelname)) {
((labeledstatement)current.associatednode).bits |= astnode.labelused;

// matching label found
if ((lastcontinuable != null)
&& (current.associatednode.concretestatement()	== lastcontinuable.associatednode)) {

if (lastnonreturningsubroutine == null) return lastcontinuable;
return lastnonreturningsubroutine;
}
// label is found, but not a continuable location
return flowcontext.notcontinuablecontext;
}
current = current.parent;
}
// not found
return null;
}

/*
* lookup a default break through breakable locations
*/
public flowcontext gettargetcontextfordefaultbreak() {
flowcontext current = this, lastnonreturningsubroutine = null;
while (current != null) {
if (current.isnonreturningcontext()) {
lastnonreturningsubroutine = current;
}
if (current.isbreakable() && current.labelname() == null) {
if (lastnonreturningsubroutine == null) return current;
return lastnonreturningsubroutine;
}
current = current.parent;
}
// not found
return null;
}

/*
* lookup a default continue amongst continuable locations
*/
public flowcontext gettargetcontextfordefaultcontinue() {
flowcontext current = this, lastnonreturningsubroutine = null;
while (current != null) {
if (current.isnonreturningcontext()) {
lastnonreturningsubroutine = current;
}
if (current.iscontinuable()) {
if (lastnonreturningsubroutine == null)
return current;
return lastnonreturningsubroutine;
}
current = current.parent;
}
// not found
return null;
}

public string individualtostring() {
return "flow context"; //$non-nls-1$
}

public flowinfo initsonbreak() {
return flowinfo.dead_end;
}

public unconditionalflowinfo initsonreturn() {
return flowinfo.dead_end;
}

public boolean isbreakable() {
return false;
}

public boolean iscontinuable() {
return false;
}

public boolean isnonreturningcontext() {
return false;
}

public boolean issubroutine() {
return false;
}

public char[] labelname() {
return null;
}

public void recordbreakfrom(flowinfo flowinfo) {
// default implementation: do nothing
}

public void recordbreakto(flowcontext targetcontext) {
// default implementation: do nothing
}

public void recordcontinuefrom(flowcontext innerflowcontext, flowinfo flowinfo) {
// default implementation: do nothing
}

protected boolean recordfinalassignment(variablebinding variable, reference finalreference) {
return true; // keep going
}

/**
* record a null reference for use by deferred checks. only looping or
* finally contexts really record that information.
* @@param local the local variable involved in the check
* @@param expression the expression within which local lays
* @@param status the status against which the check must be performed; one of
* 		{@@link #can_only_null can_only_null}, {@@link #can_only_null_non_null
* 		can_only_null_non_null}, {@@link #may_null may_null},
*      {@@link #can_only_non_null can_only_non_null}, potentially
*      combined with a context indicator (one of {@@link #in_comparison_null},
*      {@@link #in_comparison_non_null}, {@@link #in_assignment} or {@@link #in_instanceof})
*/
protected void recordnullreference(localvariablebinding local,
expression expression, int status) {
// default implementation: do nothing
}

public void recordreturnfrom(unconditionalflowinfo flowinfo) {
// default implementation: do nothing
}

public void recordsettingfinal(variablebinding variable, reference finalreference, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0)	{
// for initialization inside looping statement that effectively loops
flowcontext context = this;
while (context != null) {
if (!context.recordfinalassignment(variable, finalreference)) {
break; // no need to keep going
}
context = context.parent;
}
}
}

/**
* record a null reference for use by deferred checks. only looping or
* finally contexts really record that information. the context may
* emit an error immediately depending on the status of local against
* flowinfo and its nature (only looping of finally contexts defer part
* of the checks; nonetheless, contexts that are nested into a looping or a
* finally context get affected and delegate some checks to their enclosing
* context).
* @@param scope the scope into which the check is performed
* @@param local the local variable involved in the check
* @@param reference the expression within which local lies
* @@param checktype the status against which the check must be performed; one
* 		of {@@link #can_only_null can_only_null}, {@@link #can_only_null_non_null
* 		can_only_null_non_null}, {@@link #may_null may_null}, potentially
*      combined with a context indicator (one of {@@link #in_comparison_null},
*      {@@link #in_comparison_non_null}, {@@link #in_assignment} or {@@link #in_instanceof})
* @@param flowinfo the flow info at the check point; deferring contexts will
*  	perform supplementary checks against flow info instances that cannot
*  	be known at the time of calling this method (they are influenced by
* 		code that follows the current point)
*/
public void recordusingnullreference(scope scope, localvariablebinding local,
expression reference, int checktype, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) != 0 ||
flowinfo.isdefinitelyunknown(local)) {
return;
}
switch (checktype) {
case can_only_null_non_null | in_comparison_null:
case can_only_null_non_null | in_comparison_non_null:
if (flowinfo.isdefinitelynonnull(local)) {
if (checktype == (can_only_null_non_null | in_comparison_non_null)) {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnonnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhenfalse().setreachmode(flowinfo.unreachable);
}
} else {
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenonnullcomparedtonull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhentrue().setreachmode(flowinfo.unreachable);
}
}
return;
}
else if (flowinfo.cannotbedefinitelynullornonnull(local)) {
return;
}
//$fall-through$
case can_only_null | in_comparison_null:
case can_only_null | in_comparison_non_null:
case can_only_null | in_assignment:
case can_only_null | in_instanceof:
if (flowinfo.isdefinitelynull(local)) {
switch(checktype & context_mask) {
case flowcontext.in_comparison_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariableredundantcheckonnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhenfalse().setreachmode(flowinfo.unreachable);
}
return;
case flowcontext.in_comparison_non_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
if ((this.tagbits & flowcontext.hide_null_comparison_warning) == 0) {
scope.problemreporter().localvariablenullcomparedtononnull(local, reference);
}
if (!flowinfo.ismarkedasnullornonnullinassertexpression(local)) {
flowinfo.initswhentrue().setreachmode(flowinfo.unreachable);
}
return;
case flowcontext.in_assignment:
scope.problemreporter().localvariableredundantnullassignment(local, reference);
return;
case flowcontext.in_instanceof:
scope.problemreporter().localvariablenullinstanceof(local, reference);
return;
}
} else if (flowinfo.ispotentiallynull(local)) {
switch(checktype & context_mask) {
case flowcontext.in_comparison_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, reference);
return;
}
break;
case flowcontext.in_comparison_non_null:
if (((checktype & check_mask) == can_only_null) && (reference.implicitconversion & typeids.unboxing) != 0) { // check for auto-unboxing first and report appropriate warning
scope.problemreporter().localvariablepotentialnullreference(local, reference);
return;
}
break;
}
} else if (flowinfo.cannotbedefinitelynullornonnull(local)) {
return;
}
break;
case may_null :
if (flowinfo.isdefinitelynull(local)) {
scope.problemreporter().localvariablenullreference(local, reference);
return;
}
if (flowinfo.ispotentiallynull(local)) {
scope.problemreporter().localvariablepotentialnullreference(local, reference);
return;
}
break;
default:
// never happens
}
if (this.parent != null) {
this.parent.recordusingnullreference(scope, local, reference, checktype,
flowinfo);
}
}

void removefinalassignmentifany(reference reference) {
// default implementation: do nothing
}

public subroutinestatement subroutine() {
return null;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
flowcontext current = this;
int parentscount = 0;
while ((current = current.parent) != null) {
parentscount++;
}
flowcontext[] parents = new flowcontext[parentscount + 1];
current = this;
int index = parentscount;
while (index >= 0) {
parents[index--] = current;
current = current.parent;
}
for (int i = 0; i < parentscount; i++) {
for (int j = 0; j < i; j++)
buffer.append('\t');
buffer.append(parents[i].individualtostring()).append('\n');
}
buffer.append('*');
for (int j = 0; j < parentscount + 1; j++)
buffer.append('\t');
buffer.append(individualtostring()).append('\n');
return buffer.tostring();
}
}
