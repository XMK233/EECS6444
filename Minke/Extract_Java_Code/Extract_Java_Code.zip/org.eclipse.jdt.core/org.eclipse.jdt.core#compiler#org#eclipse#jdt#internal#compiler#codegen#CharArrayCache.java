/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

import org.eclipse.jdt.core.compiler.charoperation;

public class chararraycache {
// to avoid using enumerations, walk the individual tables skipping nulls
public char[] keytable[];
public int valuetable[];
int elementsize; // number of elements in the table
int threshold;
/**
* constructs a new, empty hashtable. a default capacity is used.
* note that the hashtable will automatically grow when it gets full.
*/
public chararraycache() {
this(9);
}
/**
* constructs a new, empty hashtable with the specified initial
* capacity.
* @@param initialcapacity int
*	the initial number of buckets; must be less than integer.max_value / 2
*/
public chararraycache(int initialcapacity) {
this.elementsize = 0;
this.threshold = (initialcapacity * 2) / 3; // faster than float operation
this.keytable = new char[initialcapacity][];
this.valuetable = new int[initialcapacity];
}
/**
* clears the hash table so that it has no more elements in it.
*/
public void clear() {
for (int i = this.keytable.length; --i >= 0;) {
this.keytable[i] = null;
this.valuetable[i] = 0;
}
this.elementsize = 0;
}
/** returns true if the collection contains an element for the key.
*
* @@param key char[] the key that we are looking for
* @@return boolean
*/
public boolean containskey(char[] key) {
int length = this.keytable.length, index = charoperation.hashcode(key) % length;
while (this.keytable[index] != null) {
if (charoperation.equals(this.keytable[index], key))
return true;
if (++index == length) { // faster than modulo
index = 0;
}
}
return false;
}
/** gets the object associated with the specified key in the
* hashtable.
* @@param key <code>char[]</code> the specified key
* @@return int the element for the key or -1 if the key is not
*	defined in the hash table.
*/
public int get(char[] key) {
int length = this.keytable.length, index = charoperation.hashcode(key) % length;
while (this.keytable[index] != null) {
if (charoperation.equals(this.keytable[index], key))
return this.valuetable[index];
if (++index == length) { // faster than modulo
index = 0;
}
}
return -1;
}
/**
* puts the specified element into the hashtable if it wasn't there already,
* using the specified key.  the element may be retrieved by doing a get() with the same key.
* the key and the element cannot be null.
*
* @@param key the given key in the hashtable
* @@param value the given value
* @@return int the old value of the key, or -value if it did not have one.
*/
public int putifabsent(char[] key, int value) {
int length = this.keytable.length, index = charoperation.hashcode(key) % length;
while (this.keytable[index] != null) {
if (charoperation.equals(this.keytable[index], key))
return this.valuetable[index];
if (++index == length) { // faster than modulo
index = 0;
}
}
this.keytable[index] = key;
this.valuetable[index] = value;

// assumes the threshold is never equal to the size of the table
if (++this.elementsize > this.threshold)
rehash();
return -value; // negative when added (value is assumed to be > 0)
}

/**
* puts the specified element into the hashtable, using the specified
* key.  the element may be retrieved by doing a get() with the same key.
* the key and the element cannot be null.
*
* @@param key <code>object</code> the specified key in the hashtable
* @@param value <code>int</code> the specified element
* @@return int the old value of the key, or -1 if it did not have one.
*/
private int put(char[] key, int value) {
int length = this.keytable.length, index = charoperation.hashcode(key) % length;
while (this.keytable[index] != null) {
if (charoperation.equals(this.keytable[index], key))
return this.valuetable[index] = value;
if (++index == length) { // faster than modulo
index = 0;
}
}
this.keytable[index] = key;
this.valuetable[index] = value;

// assumes the threshold is never equal to the size of the table
if (++this.elementsize > this.threshold)
rehash();
return value;
}
/**
* rehashes the content of the table into a bigger table.
* this method is called automatically when the hashtable's
* size exceeds the threshold.
*/
private void rehash() {
chararraycache newhashtable = new chararraycache(this.keytable.length * 2);
for (int i = this.keytable.length; --i >= 0;)
if (this.keytable[i] != null)
newhashtable.put(this.keytable[i], this.valuetable[i]);

this.keytable = newhashtable.keytable;
this.valuetable = newhashtable.valuetable;
this.threshold = newhashtable.threshold;
}
/** remove the object associated with the specified key in the
* hashtable.
* @@param key <code>char[]</code> the specified key
*/
public void remove(char[] key) {
int length = this.keytable.length, index = charoperation.hashcode(key) % length;
while (this.keytable[index] != null) {
if (charoperation.equals(this.keytable[index], key)) {
this.valuetable[index] = 0;
this.keytable[index] = null;
return;
}
if (++index == length) { // faster than modulo
index = 0;
}
}
}
/**
* returns the key corresponding to the value. returns null if the
* receiver doesn't contain the value.
* @@param value int the value that we are looking for
* @@return object
*/
public char[] returnkeyfor(int value) {
for (int i = this.keytable.length; i-- > 0;) {
if (this.valuetable[i] == value) {
return this.keytable[i];
}
}
return null;
}
/**
* returns the number of elements contained in the hashtable.
*
* @@return <code>int</code> the size of the table
*/
public int size() {
return this.elementsize;
}
/**
* converts to a rather lengthy string.
*
* return string the ascii representation of the receiver
*/
public string tostring() {
int max = size();
stringbuffer buf = new stringbuffer();
buf.append("{"); //$non-nls-1$
for (int i = 0; i < max; ++i) {
if (this.keytable[i] != null) {
buf.append(this.keytable[i]).append("->").append(this.valuetable[i]); //$non-nls-1$
}
if (i < max) {
buf.append(", "); //$non-nls-1$
}
}
buf.append("}"); //$non-nls-1$
return buf.tostring();
}
}
