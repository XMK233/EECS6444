/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

public interface basetypes {
final basetypebinding intbinding = new basetypebinding(typeids.t_int, typeconstants.int, new char[] {'i'});
final basetypebinding bytebinding = new basetypebinding(typeids.t_byte, typeconstants.byte, new char[] {'b'});
final basetypebinding shortbinding = new basetypebinding(typeids.t_short, typeconstants.short, new char[] {'s'});
final basetypebinding charbinding = new basetypebinding(typeids.t_char, typeconstants.char, new char[] {'c'});
final basetypebinding longbinding = new basetypebinding(typeids.t_long, typeconstants.long, new char[] {'j'});
final basetypebinding floatbinding = new basetypebinding(typeids.t_float, typeconstants.float, new char[] {'f'});
final basetypebinding doublebinding = new basetypebinding(typeids.t_double, typeconstants.double, new char[] {'d'});
final basetypebinding booleanbinding = new basetypebinding(typeids.t_boolean, typeconstants.boolean, new char[] {'z'});
final basetypebinding nullbinding = new basetypebinding(typeids.t_null, typeconstants.null, new char[] {'n'}); //n stands for null even if it is never internally used
final basetypebinding voidbinding = new basetypebinding(typeids.t_void, typeconstants.void, new char[] {'v'});
}
