/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.codegen;

public class caselabel extends branchlabel {

public int instructionposition = pos_not_set;

/**
* caselabel constructor comment.
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public caselabel(codestream codestream) {
super(codestream);
}

/*
* put down  a reference to the array at the location in the codestream.
* #placeinstruction() must be performed prior to any #branch()
*/
void branch() {
if (this.position == pos_not_set) {
addforwardreference(this.codestream.position);
// leave 4 bytes free to generate the jump offset afterwards
this.codestream.position += 4;
this.codestream.classfileoffset += 4;
} else { //position is set. write it!
/*
* position is set. write it if it is not a wide branch.
*/
this.codestream.writesignedword(this.position - this.instructionposition);
}
}

/*
* no support for wide branches yet
*/
void branchwide() {
branch(); // case label branch is already wide
}

public boolean iscaselabel() {
return true;
}
public boolean isstandardlabel(){
return false;
}
/*
* put down  a reference to the array at the location in the codestream.
*/
public void place() {
if ((this.tagbits & used) != 0) {
this.position = this.codestream.getposition();
} else {
this.position = this.codestream.position;
}
if (this.instructionposition != pos_not_set) {
int offset = this.position - this.instructionposition;
int[] forwardrefs = forwardreferences();
for (int i = 0, length = forwardreferencecount(); i < length; i++) {
this.codestream.writesignedword(forwardrefs[i], offset);
}
// add the label in the codestream labels collection
this.codestream.addlabel(this);
}
}

/*
* put down  a reference to the array at the location in the codestream.
*/
void placeinstruction() {
if (this.instructionposition == pos_not_set) {
this.instructionposition = this.codestream.position;
}
}
}
