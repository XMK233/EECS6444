/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

import org.eclipse.jdt.core.compiler.iproblem;

/**
* part of the source element parser responsible for building the output.
* it gets notified of structural information as they are detected, relying
* on the requestor to assemble them together, based on the notifications it got.
*
* the structural investigation includes:
* - package statement
* - import statements
* - top-level types: package member, member types (member types of member types...)
* - fields
* - methods
*
* if reference information is requested, then all source constructs are
* investigated and type, field & method references are provided as well.
*
* any (parsing) problem encountered is also provided.
*
* all positions are relative to the exact source fed to the parser.
*
* elements which are complex are notified in two steps:
* - enter<element> : once the element header has been identified
* - exit<element> : once the element has been fully consumed
*
* other simpler elements (package, import) are read all at once:
* - accept<element>
*/

public interface idocumentelementrequestor {
/**
* @@param declarationstart - a source position corresponding to the start of the package
*  declaration
* @@param declarationend - a source position corresponding to the end of the package
*  declaration
* @@param javadocpositions - answer back an array of sourcestart/sourceend
* positions of the available javadoc comments. the array is a flattened
* structure: 2*n entries with consecutives start and end positions.
* if no javadoc is available, then null is answered instead of an empty array.
* e.g. { 10, 20, 25, 45 }  --> javadoc1 from 10 to 20, javadoc2 from 25 to 45
* the array is equals to null if there are no javadoc comments
* @@param name - the name of the package
* @@param namestartposition - a source position corresponding to the first character of the
*  name
* @@param ondemand - a boolean equals to true if the import is an import on demand
*/
void acceptimport(
int declarationstart,
int declarationend,
int[] javadocpositions,
char[] name,
int namestartposition,
boolean ondemand);
/**
* @@param declarationstart - a source position corresponding to the start of the package
*  declaration
* @@param declarationend - a source position corresponding to the end of the package
*  declaration
* @@param javadocpositions - answer back an array of sourcestart/sourceend
* positions of the available javadoc comments. the array is a flattened
* structure: 2*n entries with consecutives start and end positions.
* if no javadoc is available, then null is answered instead of an empty array.
* e.g. { 10, 20, 25, 45 }  --> javadoc1 from 10 to 20, javadoc2 from 25 to 45
* the array is equals to null if there are no javadoc comments
* @@param modifiers - the modifiers for this initializer
* @@param modifiersstart - a source position corresponding to the start
*  of the textual modifiers, is < 0 if there are no textual modifiers
* @@param bodystart - the position of the '{'
* @@param bodyend - the position of the '}'
*/
void acceptinitializer(
int declarationstart,
int declarationend,
int[] javadocpositions,
int modifiers,
int modifiersstart,
int bodystart,
int bodyend);
/*
* table of line separator position. this table is passed once at the end
* of the parse action, so as to allow computation of normalized ranges.
*
* a line separator might corresponds to several characters in the source,
*
*/
void acceptlineseparatorpositions(int[] positions);
/**
* @@param declarationstart - a source position corresponding to the start of the package
*  declaration
* @@param declarationend - a source position corresponding to the end of the package
*  declaration
* @@param javadocpositions - answer back an array of sourcestart/sourceend
* positions of the available javadoc comments. the array is a flattened
* structure: 2*n entries with consecutives start and end positions.
* if no javadoc is available, then null is answered instead of an empty array.
* e.g. { 10, 20, 25, 45 }  --> javadoc1 from 10 to 20, javadoc2 from 25 to 45
* the array is equals to null if there are no javadoc comments
* @@param name - the name of the package
* @@param namestartposition - a source position corresponding to the first character of the
*  name
*/
void acceptpackage(
int declarationstart,
int declarationend,
int[] javadocpositions,
char[] name,
int namestartposition);
/**
* @@param problem - used to report a problem while running the jdom
*/
void acceptproblem(iproblem problem);
/**
* @@param declarationstart - a source position corresponding to the start
*  of this class.
* @@param javadocpositions - answer back an array of sourcestart/sourceend
* positions of the available javadoc comments. the array is a flattened
* structure: 2*n entries with consecutives start and end positions.
* if no javadoc is available, then null is answered instead of an empty array.
* e.g. { 10, 20, 25, 45 }  --> javadoc1 from 10 to 20, javadoc2 from 25 to 45
* the array is equals to null if there are no javadoc comments
* @@param modifiers - the modifiers for this class
* @@param modifiersstart - a source position corresponding to the start
*  of the textual modifiers, is < 0 if there are no textual modifiers
* @@param classstart - a source position corresponding to the start
*  of the keyword 'class'
* @@param name - the name of the class
* @@param namestart - a source position corresponding to the start of the name
* @@param nameend - a source position corresponding to the end of the name
* @@param superclass - the name of the superclass
* @@param superclassstart - a source position corresponding to the start
*  of the superclass name
* @@param superclassend - a source position corresponding to the end of the
*  superclass name
* @@param superinterfaces - the name of the superinterfaces
* @@param superinterfacestarts - an array of source positions corresponding
*  to the start of their respective superinterface names
* @@param superinterfaceends - an array of source positions corresponding
*  to the end of their respective superinterface names
* @@param bodystart - a source position corresponding to the open bracket
*  of the class body
*/
void enterclass(
int declarationstart,
int[] javadocpositions,
int modifiers,
int modifiersstart,
int classstart,
char[] name,
int namestart,
int nameend,
char[] superclass,
int superclassstart,
int superclassend,
char[][] superinterfaces,
int[] superinterfacestarts,
int[] superinterfaceends,
int bodystart);
void entercompilationunit();
/**
* @@param declarationstart - a source position corresponding to the first character
*  of this constructor declaration
* @@param javadocpositions - answer back an array of sourcestart/sourceend
* positions of the available javadoc comments. the array is a flattened
* structure: 2*n entries with consecutives start and end positions.
* if no javadoc is available, then null is answered instead of an empty array.
* e.g. { 10, 20, 25, 45 }  --> javadoc1 from 10 to 20, javadoc2 from 25 to 45
* the array is equals to null if there are no javadoc comments
* @@param modifiers - the modifiers for this constructor converted to a flag
* @@param modifiersstart - a source position corresponding to the first character of the
*  textual modifiers
* @@param name - the name of this constructor
* @@param namestart - a source position corresponding to the first character of the name
* @@param nameend - a source position corresponding to the last character of the name
* @@param parametertypes - a list of parameter type names
* @@param parametertypestarts - a list of source positions corresponding to the
*  first character of each parameter type name
* @@param parametertypeends - a list of source positions corresponding to the
*  last character of each parameter type name
* @@param parameternames - a list of the names of the parameters
* @@param parametersend - a source position corresponding to the last character of the
*  parameter list
* @@param exceptiontypes - a list of the exception types
* @@param exceptiontypestarts - a list of source positions corresponding to the first
*  character of the respective exception types
* @@param exceptiontypeends - a list of source positions corresponding to the last
*  character of the respective exception types
* @@param bodystart - a source position corresponding to the start of this
*  constructor's body
*/
void enterconstructor(
int declarationstart,
int[] javadocpositions,
int modifiers,
int modifiersstart,
char[] name,
int namestart,
int nameend,
char[][] parametertypes,
int [] parametertypestarts,
int [] parametertypeends,
char[][] parameternames,
int [] parameternamestarts,
int [] parameternameends,
int parametersend,
char[][] exceptiontypes,
int [] exceptiontypestarts,
int [] exceptiontypeends,
int bodystart);
/**
* @@param declarationstart - a source position corresponding to the first character
*  of this field
* @@param javadocpositions - answer back an array of sourcestart/sourceend
* positions of the available javadoc comments. the array is a flattened
* structure: 2*n entries with consecutives start and end positions.
* if no javadoc is available, then null is answered instead of an empty array.
* e.g. { 10, 20, 25, 45 }  --> javadoc1 from 10 to 20, javadoc2 from 25 to 45
* the array is equals to null if there are no javadoc comments
* @@param modifiers - the modifiers for this field converted to a flag
* @@param modifiersstart - a source position corresponding to the first character of the
*  textual modifiers
* @@param type - the name of the field type
* @@param typestart - a source position corresponding to the start of the fields type
* @@param typeend - a source position corresponding to the end of the fields type
* @@param typedimensioncount - the array dimension indicated on the type (for example, 'int[] v')
* @@param name - the name of this constructor
* @@param namestart - a source position corresponding to the first character of the name
* @@param nameend - a source position corresponding to the last character of the name
* @@param extendedtypedimensioncount - the array dimension indicated on the variable,
*  (for example, 'int v[]')
* @@param extendedtypedimnesionend - a source position corresponding to the end of
*  the extened type dimension. this position should be -1 in case there is no extended
*  dimension for the type.
*/
void enterfield(
int declarationstart,
int[] javadocpositions,
int modifiers,
int modifiersstart,
char[] type,
int typestart,
int typeend,
int typedimensioncount,
char[] name,
int namestart,
int nameend,
int extendedtypedimensioncount,
int extendedtypedimensionend);
/**
* @@param declarationstart - a source position corresponding to the start
*  of this class.
* @@param javadocpositions - answer back an array of sourcestart/sourceend
* positions of the available javadoc comments. the array is a flattened
* structure: 2*n entries with consecutives start and end positions.
* if no javadoc is available, then null is answered instead of an empty array.
* e.g. { 10, 20, 25, 45 }  --> javadoc1 from 10 to 20, javadoc2 from 25 to 45
* the array is equals to null if there are no javadoc comments
* @@param modifiers - the modifiers for this class
* @@param modifiersstart - a source position corresponding to the start
*  of the textual modifiers, is < 0 if there are no textual modifiers
* @@param interfacestart - a source position corresponding to the start
*  of the keyword 'interface'
* @@param name - the name of the class
* @@param namestart - a source position corresponding to the start of the name
* @@param nameend - a source position corresponding to the end of the name
* @@param superinterfaces - the name of the superinterfaces
* @@param superinterfacestarts - an array of source positions corresponding
*  to the start of their respective superinterface names
* @@param superinterfaceends - an array of source positions corresponding
*  to the end of their respective superinterface names
* @@param bodystart - a source position corresponding to the open bracket
*  of the class body
*/
void enterinterface(
int declarationstart,
int[] javadocpositions,
int modifiers,
int modifiersstart,
int interfacestart,
char[] name,
int namestart,
int nameend,
char[][] superinterfaces,
int[] superinterfacestarts,
int[] superinterfaceends,
int bodystart);
/**
* @@param declarationstart - a source position corresponding to the first character
*  of this constructor declaration
* @@param javadocpositions - answer back an array of sourcestart/sourceend
* positions of the available javadoc comments. the array is a flattened
* structure: 2*n entries with consecutives start and end positions.
* if no javadoc is available, then null is answered instead of an empty array.
* e.g. { 10, 20, 25, 45 }  --> javadoc1 from 10 to 20, javadoc2 from 25 to 45
* the array is equals to null if there are no javadoc comments
* @@param modifiers - the modifiers for this constructor converted to a flag
* @@param modifiersstart - a source position corresponding to the first character of the
*  textual modifiers
* @@param returntype - the name of the return type
* @@param returntypestart - a source position corresponding to the first character
*  of the return type
* @@param returntypeend - a source position corresponding to the last character
*  of the return type
* @@param returntypedimensioncount - the array dimension count as supplied on the
*  return type (for example, 'public int[] foo() {}')
* @@param name - the name of this constructor
* @@param namestart - a source position corresponding to the first character of the name
* @@param nameend - a source position corresponding to the last character of the name
* @@param parametertypes - a list of parameter type names
* @@param parametertypestarts - a list of source positions corresponding to the
*  first character of each parameter type name
* @@param parametertypeends - a list of source positions corresponding to the
*  last character of each parameter type name
* @@param parameternames - a list of the names of the parameters
* @@param parametersend - a source position corresponding to the last character of the
*  parameter list
* @@param extendedreturntypedimensioncount - the array dimension count as supplied on the
*  end of the parameter list (for example, 'public int foo()[] {}')
* @@param extendedreturntypedimensionend - a source position corresponding to the last character
*  of the extended return type dimension. this position should be -1 in case there is no extended
*  dimension for the type.
* @@param exceptiontypes - a list of the exception types
* @@param exceptiontypestarts - a list of source positions corresponding to the first
*  character of the respective exception types
* @@param exceptiontypeends - a list of source positions corresponding to the last
*  character of the respective exception types
* @@param bodystart - a source position corresponding to the start of this
*  method's body
*/
void entermethod(
int declarationstart,
int[] javadocpositions,
int modifiers,
int modifiersstart,
char[] returntype,
int returntypestart,
int returntypeend,
int returntypedimensioncount,
char[] name,
int namestart,
int nameend,
char[][] parametertypes,
int [] parametertypestarts,
int [] parametertypeends,
char[][] parameternames,
int [] parameternamestarts,
int [] parameternameends,
int parametersend,
int extendedreturntypedimensioncount,
int extendedreturntypedimensionend,
char[][] exceptiontypes,
int [] exceptiontypestarts,
int [] exceptiontypeends,
int bodystart);
/**
* @@param bodyend - a source position corresponding to the closing bracket of the class
* @@param declarationend - a source position corresponding to the end of the class
*  declaration.  this can include whitespace and comments following the closing bracket.
*/
void exitclass(
int bodyend,
int declarationend);
/**
* @@param declarationend - a source position corresponding to the end of the compilation unit
*/
void exitcompilationunit(
int declarationend);
/**
* @@param bodyend - a source position corresponding to the closing bracket of the method
* @@param declarationend - a source position corresponding to the end of the method
*  declaration.  this can include whitespace and comments following the closing bracket.
*/
void exitconstructor(
int bodyend,
int declarationend);
/**
* @@param bodyend - a source position corresponding to the end of the field.
* @@param declarationend - a source position corresponding to the end of the field.
*  this can include whitespace and comments following the semi-colon.
*/
void exitfield(
int bodyend,
int declarationend);
/**
* @@param bodyend - a source position corresponding to the closing bracket of the interface
* @@param declarationend - a source position corresponding to the end of the interface
*  declaration.  this can include whitespace and comments following the closing bracket.
*/
void exitinterface(
int bodyend,
int declarationend);
/**
* @@param bodyend - a source position corresponding to the closing bracket of the method
* @@param declarationend - a source position corresponding to the end of the method
*  declaration.  this can include whitespace and comments following the closing bracket.
*/
void exitmethod(
int bodyend,
int declarationend);
}
