/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.flow.unconditionalflowinfo;
import org.eclipse.jdt.internal.compiler.impl.referencecontext;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;

/**
* specific block scope used for methods, constructors or clinits, representing
* its outermost blockscope. note also that such a scope will be provided to enclose
* field initializers subscopes as well.
*/
public class methodscope extends blockscope {

public referencecontext referencecontext;
public boolean isstatic; // method modifier or initializer one

//fields used during name resolution
public boolean isconstructorcall = false;
public fieldbinding initializedfield; // the field being initialized
public int lastvisiblefieldid = -1; // the id of the last field which got declared
// note that #initializedfield can be null and lastvisiblefieldid >= 0, when processing instance field initializers.

// flow analysis
public int analysisindex; // for setting flow-analysis id
public boolean ispropagatinginnerclassemulation;

// for local variables table attributes
public int lastindex = 0;
public long[] definiteinits = new long[4];
public long[][] extradefiniteinits = new long[4][];

// annotation support
public boolean insidetypeannotation = false;

// inner-emulation
public syntheticargumentbinding[] extrasyntheticarguments;

public methodscope(classscope parent, referencecontext context, boolean isstatic) {
super(method_scope, parent);
this.locals = new localvariablebinding[5];
this.referencecontext = context;
this.isstatic = isstatic;
this.startindex = 0;
}

string basictostring(int tab) {
string newline = "\n"; //$non-nls-1$
for (int i = tab; --i >= 0;)
newline += "\t"; //$non-nls-1$

string s = newline + "--- method scope ---"; //$non-nls-1$
newline += "\t"; //$non-nls-1$
s += newline + "locals:"; //$non-nls-1$
for (int i = 0; i < this.localindex; i++)
s += newline + "\t" + this.locals[i].tostring(); //$non-nls-1$
s += newline + "startindex = " + this.startindex; //$non-nls-1$
s += newline + "isconstructorcall = " + this.isconstructorcall; //$non-nls-1$
s += newline + "initializedfield = " + this.initializedfield; //$non-nls-1$
s += newline + "lastvisiblefieldid = " + this.lastvisiblefieldid; //$non-nls-1$
s += newline + "referencecontext = " + this.referencecontext; //$non-nls-1$
return s;
}

/**
* spec : 8.4.3 & 9.4
*/
private void checkandsetmodifiersforconstructor(methodbinding methodbinding) {
int modifiers = methodbinding.modifiers;
final referencebinding declaringclass = methodbinding.declaringclass;
if ((modifiers & extracompilermodifiers.accalternatemodifierproblem) != 0)
problemreporter().duplicatemodifierformethod(declaringclass, (abstractmethoddeclaration) this.referencecontext);

if ((((constructordeclaration) this.referencecontext).bits & astnode.isdefaultconstructor) != 0) {
// certain flags are propagated from declaring class onto constructor
final int declaring_flags = classfileconstants.accenum|classfileconstants.accpublic|classfileconstants.accprotected;
final int visibility_flags = classfileconstants.accprivate|classfileconstants.accpublic|classfileconstants.accprotected;
int flags;
if ((flags = declaringclass.modifiers & declaring_flags) != 0) {
if ((flags & classfileconstants.accenum) != 0) {
modifiers &= ~visibility_flags;
modifiers |= classfileconstants.accprivate; // default constructor is implicitly private in enum
} else {
modifiers &= ~visibility_flags;
modifiers |= flags; // propagate public/protected
}
}
}

// after this point, tests on the 16 bits reserved.
int realmodifiers = modifiers & extracompilermodifiers.accjustflag;

// check for abnormal modifiers
final int unexpected_modifiers = ~(classfileconstants.accpublic | classfileconstants.accprivate | classfileconstants.accprotected | classfileconstants.accstrictfp);
if (declaringclass.isenum() && (((constructordeclaration) this.referencecontext).bits & astnode.isdefaultconstructor) == 0) {
final int unexpected_enum_constr_modifiers = ~(classfileconstants.accprivate | classfileconstants.accstrictfp);
if ((realmodifiers & unexpected_enum_constr_modifiers) != 0) {
problemreporter().illegalmodifierforenumconstructor((abstractmethoddeclaration) this.referencecontext);
modifiers &= ~extracompilermodifiers.accjustflag | ~unexpected_enum_constr_modifiers;
} else if ((((abstractmethoddeclaration) this.referencecontext).modifiers & classfileconstants.accstrictfp) != 0) {
// must check the parse node explicitly
problemreporter().illegalmodifierformethod((abstractmethoddeclaration) this.referencecontext);
}
modifiers |= classfileconstants.accprivate; // enum constructor is implicitly private
} else if ((realmodifiers & unexpected_modifiers) != 0) {
problemreporter().illegalmodifierformethod((abstractmethoddeclaration) this.referencecontext);
modifiers &= ~extracompilermodifiers.accjustflag | ~unexpected_modifiers;
} else if ((((abstractmethoddeclaration) this.referencecontext).modifiers & classfileconstants.accstrictfp) != 0) {
// must check the parse node explicitly
problemreporter().illegalmodifierformethod((abstractmethoddeclaration) this.referencecontext);
}

// check for incompatible modifiers in the visibility bits, isolate the visibility bits
int accessorbits = realmodifiers & (classfileconstants.accpublic | classfileconstants.accprotected | classfileconstants.accprivate);
if ((accessorbits & (accessorbits - 1)) != 0) {
problemreporter().illegalvisibilitymodifiercombinationformethod(declaringclass, (abstractmethoddeclaration) this.referencecontext);

// need to keep the less restrictive so disable protected/private as necessary
if ((accessorbits & classfileconstants.accpublic) != 0) {
if ((accessorbits & classfileconstants.accprotected) != 0)
modifiers &= ~classfileconstants.accprotected;
if ((accessorbits & classfileconstants.accprivate) != 0)
modifiers &= ~classfileconstants.accprivate;
} else if ((accessorbits & classfileconstants.accprotected) != 0 && (accessorbits & classfileconstants.accprivate) != 0) {
modifiers &= ~classfileconstants.accprivate;
}
}

//		// if the receiver's declaring class is a private nested type, then make sure the receiver is not private (causes problems for inner type emulation)
//		if (declaringclass.isprivate() && (modifiers & classfileconstants.accprivate) != 0)
//			modifiers &= ~classfileconstants.accprivate;

methodbinding.modifiers = modifiers;
}

/**
* spec : 8.4.3 & 9.4
*/
private void checkandsetmodifiersformethod(methodbinding methodbinding) {
int modifiers = methodbinding.modifiers;
final referencebinding declaringclass = methodbinding.declaringclass;
if ((modifiers & extracompilermodifiers.accalternatemodifierproblem) != 0)
problemreporter().duplicatemodifierformethod(declaringclass, (abstractmethoddeclaration) this.referencecontext);

// after this point, tests on the 16 bits reserved.
int realmodifiers = modifiers & extracompilermodifiers.accjustflag;

// set the requested modifiers for a method in an interface/annotation
if (declaringclass.isinterface()) {
if ((realmodifiers & ~(classfileconstants.accpublic | classfileconstants.accabstract)) != 0) {
if ((declaringclass.modifiers & classfileconstants.accannotation) != 0)
problemreporter().illegalmodifierforannotationmember((abstractmethoddeclaration) this.referencecontext);
else
problemreporter().illegalmodifierforinterfacemethod((abstractmethoddeclaration) this.referencecontext);
}
return;
}

// check for abnormal modifiers
final int unexpected_modifiers = ~(classfileconstants.accpublic | classfileconstants.accprivate | classfileconstants.accprotected
| classfileconstants.accabstract | classfileconstants.accstatic | classfileconstants.accfinal | classfileconstants.accsynchronized | classfileconstants.accnative | classfileconstants.accstrictfp);
if ((realmodifiers & unexpected_modifiers) != 0) {
problemreporter().illegalmodifierformethod((abstractmethoddeclaration) this.referencecontext);
modifiers &= ~extracompilermodifiers.accjustflag | ~unexpected_modifiers;
}

// check for incompatible modifiers in the visibility bits, isolate the visibility bits
int accessorbits = realmodifiers & (classfileconstants.accpublic | classfileconstants.accprotected | classfileconstants.accprivate);
if ((accessorbits & (accessorbits - 1)) != 0) {
problemreporter().illegalvisibilitymodifiercombinationformethod(declaringclass, (abstractmethoddeclaration) this.referencecontext);

// need to keep the less restrictive so disable protected/private as necessary
if ((accessorbits & classfileconstants.accpublic) != 0) {
if ((accessorbits & classfileconstants.accprotected) != 0)
modifiers &= ~classfileconstants.accprotected;
if ((accessorbits & classfileconstants.accprivate) != 0)
modifiers &= ~classfileconstants.accprivate;
} else if ((accessorbits & classfileconstants.accprotected) != 0 && (accessorbits & classfileconstants.accprivate) != 0) {
modifiers &= ~classfileconstants.accprivate;
}
}

// check for modifiers incompatible with abstract modifier
if ((modifiers & classfileconstants.accabstract) != 0) {
int incompatiblewithabstract = classfileconstants.accprivate | classfileconstants.accstatic | classfileconstants.accfinal | classfileconstants.accsynchronized | classfileconstants.accnative | classfileconstants.accstrictfp;
if ((modifiers & incompatiblewithabstract) != 0)
problemreporter().illegalabstractmodifiercombinationformethod(declaringclass, (abstractmethoddeclaration) this.referencecontext);
if (!methodbinding.declaringclass.isabstract())
problemreporter().abstractmethodinabstractclass((sourcetypebinding) declaringclass, (abstractmethoddeclaration) this.referencecontext);
}

/* disabled for backward compatibility with javac (if enabled should also mark private methods as final)
// methods from a final class are final : 8.4.3.3
if (methodbinding.declaringclass.isfinal())
modifiers |= accfinal;
*/
// native methods cannot also be tagged as strictfp
if ((modifiers & classfileconstants.accnative) != 0 && (modifiers & classfileconstants.accstrictfp) != 0)
problemreporter().nativemethodscannotbestrictfp(declaringclass, (abstractmethoddeclaration) this.referencecontext);

// static members are only authorized in a static member or top level type
if (((realmodifiers & classfileconstants.accstatic) != 0) && declaringclass.isnestedtype() && !declaringclass.isstatic())
problemreporter().unexpectedstaticmodifierformethod(declaringclass, (abstractmethoddeclaration) this.referencecontext);

methodbinding.modifiers = modifiers;
}

public void checkunusedparameters(methodbinding method) {
if (method.isabstract()
|| (method.isimplementing() && !compileroptions().reportunusedparameterwhenimplementingabstract)
|| (method.isoverriding() && !method.isimplementing() && !compileroptions().reportunusedparameterwhenoverridingconcrete)
|| method.ismain()) {
// do not want to check
return;
}
for (int i = 0, maxlocals = this.localindex; i < maxlocals; i++) {
localvariablebinding local = this.locals[i];
if (local == null || ((local.tagbits & tagbits.isargument) == 0)) {
break; // done with arguments
}
if (local.useflag == localvariablebinding.unused &&
// do not report fake used variable
((local.declaration.bits & astnode.islocaldeclarationreachable) != 0)) { // declaration is reachable
problemreporter().unusedargument(local.declaration);
}
}
}

/**
* compute variable positions in scopes given an initial position offset
* ignoring unused local variables.
*
* deal with arguments here, locals and subscopes are processed in blockscope method
*/
public void computelocalvariablepositions(int initoffset, codestream codestream) {
this.offset = initoffset;
this.maxoffset = initoffset;

// manage arguments
int ilocal = 0, maxlocals = this.localindex;
while (ilocal < maxlocals) {
localvariablebinding local = this.locals[ilocal];
if (local == null || ((local.tagbits & tagbits.isargument) == 0)) break; // done with arguments

// record user-defined argument for attribute generation
codestream.record(local);

// assign variable position
local.resolvedposition = this.offset;

if ((local.type == typebinding.long) || (local.type == typebinding.double)) {
this.offset += 2;
} else {
this.offset++;
}
// check for too many arguments/local variables
if (this.offset > 0xff) { // no more than 255 words of arguments
problemreporter().nomoreavailablespaceforargument(local, local.declaration);
}
ilocal++;
}

// sneak in extra argument before other local variables
if (this.extrasyntheticarguments != null) {
for (int iarg = 0, maxarguments = this.extrasyntheticarguments.length; iarg < maxarguments; iarg++){
syntheticargumentbinding argument = this.extrasyntheticarguments[iarg];
argument.resolvedposition = this.offset;
if ((argument.type == typebinding.long) || (argument.type == typebinding.double)){
this.offset += 2;
} else {
this.offset++;
}
if (this.offset > 0xff) { // no more than 255 words of arguments
problemreporter().nomoreavailablespaceforargument(argument, (astnode)this.referencecontext);
}
}
}
this.computelocalvariablepositions(ilocal, this.offset, codestream);
}

/**
* error management:
* 		keep null for all the errors that prevent the method to be created
* 		otherwise return a correct method binding (but without the element
*		that caused the problem) : i.e. incorrect thrown exception
*/
methodbinding createmethod(abstractmethoddeclaration method) {
// is necessary to ensure error reporting
this.referencecontext = method;
method.scope = this;
sourcetypebinding declaringclass = referencetype().binding;
int modifiers = method.modifiers | extracompilermodifiers.accunresolved;
if (method.isconstructor()) {
if (method.isdefaultconstructor())
modifiers |= extracompilermodifiers.accisdefaultconstructor;
method.binding = new methodbinding(modifiers, null, null, declaringclass);
checkandsetmodifiersforconstructor(method.binding);
} else {
if (declaringclass.isinterface()) // interface or annotation type
modifiers |= classfileconstants.accpublic | classfileconstants.accabstract;
method.binding =
new methodbinding(modifiers, method.selector, null, null, null, declaringclass);
checkandsetmodifiersformethod(method.binding);
}
this.isstatic = method.binding.isstatic();

argument[] argtypes = method.arguments;
int arglength = argtypes == null ? 0 : argtypes.length;
if (arglength > 0 && compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
if (argtypes[--arglength].isvarargs())
method.binding.modifiers |= classfileconstants.accvarargs;
while (--arglength >= 0) {
if (argtypes[arglength].isvarargs())
problemreporter().illegalvararg(argtypes[arglength], method);
}
}

typeparameter[] typeparameters = method.typeparameters();
// do not construct type variables if source < 1.5
if (typeparameters == null || compileroptions().sourcelevel < classfileconstants.jdk1_5) {
method.binding.typevariables = binding.no_type_variables;
} else {
method.binding.typevariables = createtypevariables(typeparameters, method.binding);
method.binding.modifiers |= extracompilermodifiers.accgenericsignature;
}
return method.binding;
}

/**
* overridden to detect the error case inside an explicit constructor call:
class x {
int i;
x myx;
x(x x) {
this(i, myx.i, x.i); // same for super calls... only the first 2 field accesses are errors
}
}
*/
public fieldbinding findfield(typebinding receivertype, char[] fieldname, invocationsite invocationsite, boolean needresolve) {

fieldbinding field = super.findfield(receivertype, fieldname, invocationsite, needresolve);
if (field == null)
return null;
if (!field.isvalidbinding())
return field; // answer the error field
if (field.isstatic())
return field; // static fields are always accessible

if (!this.isconstructorcall || receivertype != enclosingsourcetype())
return field;

if (invocationsite instanceof singlenamereference)
return new problemfieldbinding(
field, // closest match
field.declaringclass,
fieldname,
problemreasons.nonstaticreferenceinconstructorinvocation);
if (invocationsite instanceof qualifiednamereference) {
// look to see if the field is the first binding
qualifiednamereference name = (qualifiednamereference) invocationsite;
if (name.binding == null)
// only true when the field is the fieldbinding at the beginning of name's tokens
return new problemfieldbinding(
field, // closest match
field.declaringclass,
fieldname,
problemreasons.nonstaticreferenceinconstructorinvocation);
}
return field;
}

public boolean isinsideconstructor() {
return (this.referencecontext instanceof constructordeclaration);
}

public boolean isinsideinitializer() {
return (this.referencecontext instanceof typedeclaration);
}

public boolean isinsideinitializerorconstructor() {
return (this.referencecontext instanceof typedeclaration)
|| (this.referencecontext instanceof constructordeclaration);
}

/**
* answer the problem reporter to use for raising new problems.
*
* note that as a side-effect, this updates the current reference context
* (unit, type or method) in case the problem handler decides it is necessary
* to abort.
*/
public problemreporter problemreporter() {
methodscope outermethodscope;
if ((outermethodscope = outermostmethodscope()) == this) {
problemreporter problemreporter = referencecompilationunit().problemreporter;
problemreporter.referencecontext = this.referencecontext;
return problemreporter;
}
return outermethodscope.problemreporter();
}

public final int recordinitializationstates(flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) != 0) return -1;
unconditionalflowinfo unconditionalflowinfo = flowinfo.unconditionalinitswithoutsideeffect();
long[] extrainits = unconditionalflowinfo.extra == null ?
null : unconditionalflowinfo.extra[0];
long inits = unconditionalflowinfo.definiteinits;
checknextentry : for (int i = this.lastindex; --i >= 0;) {
if (this.definiteinits[i] == inits) {
long[] otherinits = this.extradefiniteinits[i];
if ((extrainits != null) && (otherinits != null)) {
if (extrainits.length == otherinits.length) {
int j, max;
for (j = 0, max = extrainits.length; j < max; j++) {
if (extrainits[j] != otherinits[j]) {
continue checknextentry;
}
}
return i;
}
} else {
if ((extrainits == null) && (otherinits == null)) {
return i;
}
}
}
}

// add a new entry
if (this.definiteinits.length == this.lastindex) {
// need a resize
system.arraycopy(
this.definiteinits,
0,
(this.definiteinits = new long[this.lastindex + 20]),
0,
this.lastindex);
system.arraycopy(
this.extradefiniteinits,
0,
(this.extradefiniteinits = new long[this.lastindex + 20][]),
0,
this.lastindex);
}
this.definiteinits[this.lastindex] = inits;
if (extrainits != null) {
this.extradefiniteinits[this.lastindex] = new long[extrainits.length];
system.arraycopy(
extrainits,
0,
this.extradefiniteinits[this.lastindex],
0,
extrainits.length);
}
return this.lastindex++;
}

/**
*  answer the reference method of this scope, or null if initialization scope.
*/
public abstractmethoddeclaration referencemethod() {
if (this.referencecontext instanceof abstractmethoddeclaration) return (abstractmethoddeclaration) this.referencecontext;
return null;
}

/**
*  answer the reference type of this scope.
* it is the nearest enclosing type of this scope.
*/
public typedeclaration referencetype() {
return ((classscope) this.parent).referencecontext;
}
}
