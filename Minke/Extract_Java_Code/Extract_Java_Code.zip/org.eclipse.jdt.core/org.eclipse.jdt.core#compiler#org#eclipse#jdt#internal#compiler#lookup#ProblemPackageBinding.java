/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

public class problempackagebinding extends packagebinding {
private int problemid;
// note: must only answer the subset of the name related to the problem

problempackagebinding(char[][] compoundname, int problemid) {
this.compoundname = compoundname;
this.problemid = problemid;
}
problempackagebinding(char[] name, int problemid) {
this(new char[][] {name}, problemid);
}
/* api
* answer the problem id associated with the receiver.
* noerror if the receiver is a valid binding.
*/

public final int problemid() {
return this.problemid;
}
}
