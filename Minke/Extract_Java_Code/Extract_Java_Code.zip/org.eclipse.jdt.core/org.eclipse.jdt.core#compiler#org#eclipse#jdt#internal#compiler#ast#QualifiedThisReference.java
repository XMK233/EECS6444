/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class qualifiedthisreference extends thisreference {

public typereference qualification;
referencebinding currentcompatibletype;

public qualifiedthisreference(typereference name, int sourcestart, int sourceend) {
super(sourcestart, sourceend);
this.qualification = name;
name.bits |= ignorerawtypecheck; // no need to worry about raw type usage
this.sourcestart = name.sourcestart;
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {

return flowinfo;
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo,
boolean valuerequired) {

return flowinfo;
}

/**
* code generation for qualifiedthisreference
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(
blockscope currentscope,
codestream codestream,
boolean valuerequired) {

int pc = codestream.position;
if (valuerequired) {
if ((this.bits & depthmask) != 0) {
object[] emulationpath =
currentscope.getemulationpath(this.currentcompatibletype, true /*only exact match*/, false/*consider enclosing arg*/);
codestream.generateouteraccess(emulationpath, this, this.currentcompatibletype, currentscope);
} else {
// nothing particular after all
codestream.aload_0();
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public typebinding resolvetype(blockscope scope) {

this.constant = constant.notaconstant;
// x.this is not a param/raw type as denoting enclosing instance
typebinding type = this.qualification.resolvetype(scope, true /* check bounds*/);
if (type == null || !type.isvalidbinding()) return null;
// x.this is not a param/raw type as denoting enclosing instance
type = type.erasure();

// resolvedtype needs to be converted to parameterized
if (type instanceof referencebinding) {
this.resolvedtype = scope.environment().converttoparameterizedtype((referencebinding) type);
} else {
// error case
this.resolvedtype = type;
}

// the qualification must exactly match some enclosing type name
// it is possible to qualify 'this' by the name of the current class
int depth = 0;
this.currentcompatibletype = scope.referencetype().binding;
while (this.currentcompatibletype != null && this.currentcompatibletype != type) {
depth++;
this.currentcompatibletype = this.currentcompatibletype.isstatic() ? null : this.currentcompatibletype.enclosingtype();
}
this.bits &= ~depthmask; // flush previous depth if any
this.bits |= (depth & 0xff) << depthshift; // encoded depth into 8 bits

if (this.currentcompatibletype == null) {
scope.problemreporter().nosuchenclosinginstance(type, this, false);
return this.resolvedtype;
}

// ensure one cannot write code like: b() { super(b.this); }
if (depth == 0) {
checkaccess(scope.methodscope());
} // if depth>0, path emulation will diagnose bad scenarii

return this.resolvedtype;
}

public stringbuffer printexpression(int indent, stringbuffer output) {

return this.qualification.print(0, output).append(".this"); //$non-nls-1$
}

public void traverse(
astvisitor visitor,
blockscope blockscope) {

if (visitor.visit(this, blockscope)) {
this.qualification.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}

public void traverse(
astvisitor visitor,
classscope blockscope) {

if (visitor.visit(this, blockscope)) {
this.qualification.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}
}
