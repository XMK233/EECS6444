/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

/**
* the name environment provides a callback api that the compiler
* can use to look up types, compilation units, and packages in the
* current environment.  the name environment is passed to the compiler
* on creation.
*/
public interface inameenvironment {
/**
* find a type with the given compound name.
* answer the binary form of the type if it is known to be consistent.
* otherwise, answer the compilation unit which defines the type
* or null if the type does not exist.
* types in the default package are specified as {{typename}}.
*
* it is unknown whether the package containing the type actually exists.
*
* note: this method can be used to find a member type using its
* internal name a$b, but the source file for a is answered if the binary
* file is inconsistent.
*/

nameenvironmentanswer findtype(char[][] compoundtypename);
/**
* find a type named <typename> in the package <packagename>.
* answer the binary form of the type if it is known to be consistent.
* otherwise, answer the compilation unit which defines the type
* or null if the type does not exist.
* the default package is indicated by char[0][].
*
* it is known that the package containing the type exists.
*
* note: this method can be used to find a member type using its
* internal name a$b, but the source file for a is answered if the binary
* file is inconsistent.
*/

nameenvironmentanswer findtype(char[] typename, char[][] packagename);
/**
* answer whether packagename is the name of a known subpackage inside
* the package parentpackagename. a top level package is found relative to null.
* the default package is always assumed to exist.
*
* for example:
*      ispackage({{java}, {awt}}, {event});
*      ispackage(null, {java});
*/

boolean ispackage(char[][] parentpackagename, char[] packagename);

/**
* this method cleans the environment uo. it is responsible for releasing the memory
* and freeing resources. passed that point, the name environment is no longer usable.
*
* a name environment can have a long life cycle, therefore it is the responsibility of
* the code which created it to decide when it is a good time to clean it up.
*/
void cleanup();

}
