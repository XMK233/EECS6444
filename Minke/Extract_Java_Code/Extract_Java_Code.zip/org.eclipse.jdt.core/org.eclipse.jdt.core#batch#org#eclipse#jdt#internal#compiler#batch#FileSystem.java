/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.batch;

import java.io.file;
import java.io.ioexception;
import java.util.arraylist;
import java.util.hashset;
import java.util.iterator;
import java.util.list;
import java.util.set;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.env.accessruleset;
import org.eclipse.jdt.internal.compiler.env.inameenvironment;
import org.eclipse.jdt.internal.compiler.env.nameenvironmentanswer;
import org.eclipse.jdt.internal.compiler.util.suffixconstants;
import org.eclipse.jdt.internal.compiler.util.util;

public class filesystem implements inameenvironment, suffixconstants {
public interface classpath {
char[][][] findtypenames(string qualifiedpackagename);
nameenvironmentanswer findclass(char[] typename, string qualifiedpackagename, string qualifiedbinaryfilename);
nameenvironmentanswer findclass(char[] typename, string qualifiedpackagename, string qualifiedbinaryfilename, boolean asbinaryonly);
boolean ispackage(string qualifiedpackagename);
/**
* return a list of the jar file names defined in the class-path section
* of the jar file manifest if any, null else. only classpathjar (and
* extending classes) instances may return a non-null result.
* @@param  problemreporter problem reporter with which potential
*         misconfiguration issues are raised
* @@return a list of the jar file names defined in the class-path
*         section of the jar file manifest if any
*/
list fetchlinkedjars(classpathsectionproblemreporter problemreporter);
/**
* this method resets the environment. the resulting state is equivalent to
* a new name environment without creating a new object.
*/
void reset();
/**
* return a normalized path for file based classpath entries. this is an
* absolute path in which file separators are transformed to the
* platform-agnostic '/', ending with a '/' for directories. this is an
* absolute path in which file separators are transformed to the
* platform-agnostic '/', deprived from the '.jar' (resp. '.zip')
* extension for jar (resp. zip) files.
* @@return a normalized path for file based classpath entries
*/
char[] normalizedpath();
/**
* return the path for file based classpath entries. this is an absolute path
* ending with a file separator for directories, an absolute path including the '.jar'
* (resp. '.zip') extension for jar (resp. zip) files.
* @@return the path for file based classpath entries
*/
string getpath();
/**
* initialize the entry
*/
void initialize() throws ioexception;
}
public interface classpathsectionproblemreporter {
void invalidclasspathsection(string jarfilepath);
void multipleclasspathsections(string jarfilepath);
}

/**
* this class is defined how to normalize the classpath entries.
* it removes duplicate entries.
*/
public static class classpathnormalizer {
/**
* returns the normalized classpath entries (no duplicate).
* <p>the given classpath entries are filesystem.classpath. we check the getpath() in order to find
* duplicate entries.</p>
*
* @@param classpaths the given classpath entries
* @@return the normalized classpath entries
*/
public static arraylist normalize(arraylist classpaths) {
arraylist normalizedclasspath = new arraylist();
hashset cache = new hashset();
for (iterator iterator = classpaths.iterator(); iterator.hasnext(); ) {
filesystem.classpath classpath = (filesystem.classpath) iterator.next();
string path = classpath.getpath();
if (!cache.contains(path)) {
normalizedclasspath.add(classpath);
cache.add(path);
}
}
return normalizedclasspath;
}
}

classpath[] classpaths;
set knownfilenames;

/*
classpathnames is a collection is strings representing the full path of each class path
initialfilenames is a collection is strings, the trailing '.java' will be removed if its not already.
*/
public filesystem(string[] classpathnames, string[] initialfilenames, string encoding) {
final int classpathsize = classpathnames.length;
this.classpaths = new classpath[classpathsize];
int counter = 0;
for (int i = 0; i < classpathsize; i++) {
classpath classpath = getclasspath(classpathnames[i], encoding, null);
try {
classpath.initialize();
this.classpaths[counter++] = classpath;
} catch (ioexception e) {
// ignore
}
}
if (counter != classpathsize) {
system.arraycopy(this.classpaths, 0, (this.classpaths = new classpath[counter]), 0, counter);
}
initializeknownfilenames(initialfilenames);
}
protected filesystem(classpath[] paths, string[] initialfilenames) {
final int length = paths.length;
int counter = 0;
this.classpaths = new filesystem.classpath[length];
for (int i = 0; i < length; i++) {
final classpath classpath = paths[i];
try {
classpath.initialize();
this.classpaths[counter++] = classpath;
} catch(ioexception exception) {
// ignore
}
}
if (counter != length) {
// should not happen
system.arraycopy(this.classpaths, 0, (this.classpaths = new filesystem.classpath[counter]), 0, counter);
}
initializeknownfilenames(initialfilenames);
}
public static classpath getclasspath(string classpathname, string encoding, accessruleset accessruleset) {
return getclasspath(classpathname, encoding, false, accessruleset, null);
}
public static classpath getclasspath(string classpathname, string encoding,
boolean issourceonly, accessruleset accessruleset,
string destinationpath) {
classpath result = null;
file file = new file(convertpathseparators(classpathname));
if (file.isdirectory()) {
if (file.exists()) {
result = new classpathdirectory(file, encoding,
issourceonly ? classpathlocation.source :
classpathlocation.source | classpathlocation.binary,
accessruleset,
destinationpath == null || destinationpath == main.none ?
destinationpath : // keep == comparison valid
convertpathseparators(destinationpath));
}
} else {
if (util.ispotentialziparchive(classpathname)) {
if (issourceonly) {
// source only mode
result = new classpathsourcejar(file, true, accessruleset,
encoding,
destinationpath == null || destinationpath == main.none ?
destinationpath : // keep == comparison valid
convertpathseparators(destinationpath));
} else if (destinationpath == null) {
// class file only mode
result = new classpathjar(file, true, accessruleset, null);
}
}
}
return result;
}
private void initializeknownfilenames(string[] initialfilenames) {
if (initialfilenames == null) {
this.knownfilenames = new hashset(0);
return;
}
this.knownfilenames = new hashset(initialfilenames.length * 2);
for (int i = initialfilenames.length; --i >= 0;) {
file compilationunitfile = new file(initialfilenames[i]);
char[] filename = null;
try {
filename = compilationunitfile.getcanonicalpath().tochararray();
} catch (ioexception e) {
// this should not happen as the file exists
continue;
}
char[] matchingpathname = null;
final int lastindexof = charoperation.lastindexof('.', filename);
if (lastindexof != -1) {
filename = charoperation.subarray(filename, 0, lastindexof);
}
charoperation.replace(filename, '\\', '/');
for (int j = 0, max = this.classpaths.length; j < max; j++) {
char[] matchcandidate = this.classpaths[j].normalizedpath();
if (this.classpaths[j] instanceof  classpathdirectory &&
charoperation.prefixequals(matchcandidate, filename) &&
(matchingpathname == null ||
matchcandidate.length < matchingpathname.length)) {
matchingpathname = matchcandidate;
}
}
if (matchingpathname == null) {
this.knownfilenames.add(new string(filename)); // leave as is...
} else {
this.knownfilenames.add(new string(charoperation.subarray(filename, matchingpathname.length, filename.length)));
}
matchingpathname = null;
}
}
public void cleanup() {
for (int i = 0, max = this.classpaths.length; i < max; i++)
this.classpaths[i].reset();
}
private static string convertpathseparators(string path) {
return file.separatorchar == '/'
? path.replace('\\', '/')
: path.replace('/', '\\');
}
private nameenvironmentanswer findclass(string qualifiedtypename, char[] typename, boolean asbinaryonly){
if (this.knownfilenames.contains(qualifiedtypename)) return null; // looking for a file which we know was provided at the beginning of the compilation

string qualifiedbinaryfilename = qualifiedtypename + suffix_string_class;
string qualifiedpackagename =
qualifiedtypename.length() == typename.length
? util.empty_string
: qualifiedbinaryfilename.substring(0, qualifiedtypename.length() - typename.length - 1);
string qp2 = file.separatorchar == '/' ? qualifiedpackagename : qualifiedpackagename.replace('/', file.separatorchar);
nameenvironmentanswer suggestedanswer = null;
if (qualifiedpackagename == qp2) {
for (int i = 0, length = this.classpaths.length; i < length; i++) {
nameenvironmentanswer answer = this.classpaths[i].findclass(typename, qualifiedpackagename, qualifiedbinaryfilename, asbinaryonly);
if (answer != null) {
if (!answer.ignoreifbetter()) {
if (answer.isbetter(suggestedanswer))
return answer;
} else if (answer.isbetter(suggestedanswer))
// remember suggestion and keep looking
suggestedanswer = answer;
}
}
} else {
string qb2 = qualifiedbinaryfilename.replace('/', file.separatorchar);
for (int i = 0, length = this.classpaths.length; i < length; i++) {
classpath p = this.classpaths[i];
nameenvironmentanswer answer = (p instanceof classpathjar)
? p.findclass(typename, qualifiedpackagename, qualifiedbinaryfilename, asbinaryonly)
: p.findclass(typename, qp2, qb2, asbinaryonly);
if (answer != null) {
if (!answer.ignoreifbetter()) {
if (answer.isbetter(suggestedanswer))
return answer;
} else if (answer.isbetter(suggestedanswer))
// remember suggestion and keep looking
suggestedanswer = answer;
}
}
}
if (suggestedanswer != null)
// no better answer was found
return suggestedanswer;
return null;
}
public nameenvironmentanswer findtype(char[][] compoundname) {
if (compoundname != null)
return findclass(
new string(charoperation.concatwith(compoundname, '/')),
compoundname[compoundname.length - 1],
false);
return null;
}
public char[][][] findtypenames(char[][] packagename) {
char[][][] result = null;
if (packagename != null) {
string qualifiedpackagename = new string(charoperation.concatwith(packagename, '/'));
string qualifiedpackagename2 = file.separatorchar == '/' ? qualifiedpackagename : qualifiedpackagename.replace('/', file.separatorchar);
if (qualifiedpackagename == qualifiedpackagename2) {
for (int i = 0, length = this.classpaths.length; i < length; i++) {
char[][][] answers = this.classpaths[i].findtypenames(qualifiedpackagename);
if (answers != null) {
// concat with previous answers
if (result == null) {
result = answers;
} else {
int resultlength = result.length;
int answerslength = answers.length;
system.arraycopy(result, 0, (result = new char[answerslength + resultlength][][]), 0, resultlength);
system.arraycopy(answers, 0, result, resultlength, answerslength);
}
}
}
} else {
for (int i = 0, length = this.classpaths.length; i < length; i++) {
classpath p = this.classpaths[i];
char[][][] answers = (p instanceof classpathjar)
? p.findtypenames(qualifiedpackagename)
: p.findtypenames(qualifiedpackagename2);
if (answers != null) {
// concat with previous answers
if (result == null) {
result = answers;
} else {
int resultlength = result.length;
int answerslength = answers.length;
system.arraycopy(result, 0, (result = new char[answerslength + resultlength][][]), 0, resultlength);
system.arraycopy(answers, 0, result, resultlength, answerslength);
}
}
}
}
}
return result;
}
public nameenvironmentanswer findtype(char[][] compoundname, boolean asbinaryonly) {
if (compoundname != null)
return findclass(
new string(charoperation.concatwith(compoundname, '/')),
compoundname[compoundname.length - 1],
asbinaryonly);
return null;
}
public nameenvironmentanswer findtype(char[] typename, char[][] packagename) {
if (typename != null)
return findclass(
new string(charoperation.concatwith(packagename, typename, '/')),
typename,
false);
return null;
}
public boolean ispackage(char[][] compoundname, char[] packagename) {
string qualifiedpackagename = new string(charoperation.concatwith(compoundname, packagename, '/'));
string qp2 = file.separatorchar == '/' ? qualifiedpackagename : qualifiedpackagename.replace('/', file.separatorchar);
if (qualifiedpackagename == qp2) {
for (int i = 0, length = this.classpaths.length; i < length; i++)
if (this.classpaths[i].ispackage(qualifiedpackagename))
return true;
} else {
for (int i = 0, length = this.classpaths.length; i < length; i++) {
classpath p = this.classpaths[i];
if ((p instanceof classpathjar) ? p.ispackage(qualifiedpackagename) : p.ispackage(qp2))
return true;
}
}
return false;
}
}
