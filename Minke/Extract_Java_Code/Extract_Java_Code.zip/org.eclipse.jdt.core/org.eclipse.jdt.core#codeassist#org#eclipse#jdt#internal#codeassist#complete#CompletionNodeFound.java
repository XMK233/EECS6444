/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.scope;

public class completionnodefound extends runtimeexception {

public astnode astnode;
public binding qualifiedbinding;
public scope scope;
public boolean insidetypeannotation = false;

private static final long serialversionuid = 6981437684184091462l; // backward compatible

public completionnodefound() {
this(null, null, null, false); // we found a problem in the completion node
}
public completionnodefound(astnode astnode, binding qualifiedbinding, scope scope) {
this(astnode, qualifiedbinding, scope, false);
}
public completionnodefound(astnode astnode, binding qualifiedbinding, scope scope, boolean insidetypeannotation) {
this.astnode = astnode;
this.qualifiedbinding = qualifiedbinding;
this.scope = scope;
this.insidetypeannotation = insidetypeannotation;
}
public completionnodefound(astnode astnode, scope scope) {
this(astnode, null, scope, false);
}
public completionnodefound(astnode astnode, scope scope, boolean insidetypeannotation) {
this(astnode, null, scope, insidetypeannotation);
}
}
