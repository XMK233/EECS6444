/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     nick teryaev - fix for bug (https://bugs.eclipse.org/bugs/show_bug.cgi?id=40752)
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.arraybinding;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.invocationsite;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.lookupenvironment;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.parameterizedgenericmethodbinding;
import org.eclipse.jdt.internal.compiler.lookup.parameterizedtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;

public class castexpression extends expression {

public expression expression;
public expression type;
public typebinding expectedtype; // when assignment conversion to a given expected type: string s = (string) t;

//expression.implicitconversion holds the cast for basetype casting
public castexpression(expression expression, expression type) {
this.expression = expression;
this.type = type;
type.bits |= astnode.ignorerawtypecheck; // no need to worry about raw type usage
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
return this.expression
.analysecode(currentscope, flowcontext, flowinfo)
.unconditionalinits();
}

/**
* complain if assigned expression is cast, but not actually used as such, e.g. object o = (list) object;
*/
public static void checkneedforassignedcast(blockscope scope, typebinding expectedtype, castexpression rhs) {
if (scope.compileroptions().getseverity(compileroptions.unnecessarytypecheck) == problemseverities.ignore) return;

typebinding castedexpressiontype = rhs.expression.resolvedtype;
//	int i = (byte) n; // cast still had side effect
// double d = (float) n; // cast to float is unnecessary
if (castedexpressiontype == null || rhs.resolvedtype.isbasetype()) return;
//if (castedexpressiontype.id == t_null) return; // tolerate null expression cast
if (castedexpressiontype.iscompatiblewith(expectedtype)) {
scope.problemreporter().unnecessarycast(rhs);
}
}


/**
* complain if cast expression is cast, but not actually needed, int i = (int)(integer) 12;
* note that this (int) cast is however needed:   integer i = 0;  char c = (char)((int) i);
*/
public static void checkneedforcastcast(blockscope scope, castexpression enclosingcast) {
if (scope.compileroptions().getseverity(compileroptions.unnecessarytypecheck) == problemseverities.ignore) return;

castexpression nestedcast = (castexpression) enclosingcast.expression;
if ((nestedcast.bits & astnode.unnecessarycast) == 0) return;
// check if could cast directly to enclosing cast type, without intermediate type cast
castexpression alternatecast = new castexpression(null, enclosingcast.type);
alternatecast.resolvedtype = enclosingcast.resolvedtype;
if (!alternatecast.checkcasttypescompatibility(scope, enclosingcast.resolvedtype, nestedcast.expression.resolvedtype, null /* no expr to avoid side-effects*/)) return;
scope.problemreporter().unnecessarycast(nestedcast);
}


/**
* casting an enclosing instance will considered as useful if removing it would actually bind to a different type
*/
public static void checkneedforenclosinginstancecast(blockscope scope, expression enclosinginstance, typebinding enclosinginstancetype, typebinding membertype) {
if (scope.compileroptions().getseverity(compileroptions.unnecessarytypecheck) == problemseverities.ignore) return;

typebinding castedexpressiontype = ((castexpression)enclosinginstance).expression.resolvedtype;
if (castedexpressiontype == null) return; // cannot do better
// obvious identity cast
if (castedexpressiontype == enclosinginstancetype) {
scope.problemreporter().unnecessarycast((castexpression)enclosinginstance);
} else if (castedexpressiontype == typebinding.null){
return; // tolerate null enclosing instance cast
} else {
typebinding alternateenclosinginstancetype = castedexpressiontype;
if (castedexpressiontype.isbasetype() || castedexpressiontype.isarraytype()) return; // error case
if (membertype == scope.getmembertype(membertype.sourcename(), (referencebinding) alternateenclosinginstancetype)) {
scope.problemreporter().unnecessarycast((castexpression)enclosinginstance);
}
}
}

/**
* only complain for identity cast, since other type of casts may be useful: e.g.  ~((~(long) 0) << 32)  is different from: ~((~0) << 32)
*/
public static void checkneedforargumentcast(blockscope scope, int operator, int operatorsignature, expression expression, int expressiontypeid) {
if (scope.compileroptions().getseverity(compileroptions.unnecessarytypecheck) == problemseverities.ignore) return;

// check need for left operand cast
if ((expression.bits & astnode.unnecessarycast) == 0 && expression.resolvedtype.isbasetype()) {
// narrowing conversion on base type may change value, thus necessary
return;
} else {
typebinding alternatelefttype = ((castexpression)expression).expression.resolvedtype;
if (alternatelefttype == null) return; // cannot do better
if (alternatelefttype.id == expressiontypeid) { // obvious identity cast
scope.problemreporter().unnecessarycast((castexpression)expression);
return;
}
}
}

/**
* cast expressions will considered as useful if removing them all would actually bind to a different method
* (no fine grain analysis on per casted argument basis, simply separate widening cast from narrowing ones)
*/
public static void checkneedforargumentcasts(blockscope scope, expression receiver, typebinding receivertype, methodbinding binding, expression[] arguments, typebinding[] argumenttypes, final invocationsite invocationsite) {
if (scope.compileroptions().getseverity(compileroptions.unnecessarytypecheck) == problemseverities.ignore) return;

int length = argumenttypes.length;

// iterate over arguments, and retrieve original argument types (before cast)
typebinding[] rawargumenttypes = argumenttypes;
for (int i = 0; i < length; i++) {
expression argument = arguments[i];
if (argument instanceof castexpression) {
// narrowing conversion on base type may change value, thus necessary
if ((argument.bits & astnode.unnecessarycast) == 0 && argument.resolvedtype.isbasetype()) {
continue;
}
typebinding castedexpressiontype = ((castexpression)argument).expression.resolvedtype;
if (castedexpressiontype == null) return; // cannot do better
// obvious identity cast
if (castedexpressiontype == argumenttypes[i]) {
scope.problemreporter().unnecessarycast((castexpression)argument);
} else if (castedexpressiontype == typebinding.null){
continue; // tolerate null argument cast
} else if ((argument.implicitconversion & typeids.boxing) != 0) {
continue; // boxing has a side effect: (int) char   is not boxed as simple char
} else {
if (rawargumenttypes == argumenttypes) {
system.arraycopy(rawargumenttypes, 0, rawargumenttypes = new typebinding[length], 0, length);
}
// retain original argument type
rawargumenttypes[i] = castedexpressiontype;
}
}
}
// perform alternate lookup with original types
if (rawargumenttypes != argumenttypes) {
checkalternatebinding(scope, receiver, receivertype, binding, arguments, argumenttypes, rawargumenttypes, invocationsite);
}
}

/**
* check binary operator casted arguments
*/
public static void checkneedforargumentcasts(blockscope scope, int operator, int operatorsignature, expression left, int lefttypeid, boolean leftiscast, expression right, int righttypeid, boolean rightiscast) {
if (scope.compileroptions().getseverity(compileroptions.unnecessarytypecheck) == problemseverities.ignore) return;

// check need for left operand cast
int alternatelefttypeid = lefttypeid;
if (leftiscast) {
if ((left.bits & astnode.unnecessarycast) == 0 && left.resolvedtype.isbasetype()) {
// narrowing conversion on base type may change value, thus necessary
leftiscast = false;
} else  {
typebinding alternatelefttype = ((castexpression)left).expression.resolvedtype;
if (alternatelefttype == null) return; // cannot do better
if ((alternatelefttypeid = alternatelefttype.id) == lefttypeid || scope.environment().computeboxingtype(alternatelefttype).id == lefttypeid) { // obvious identity cast
scope.problemreporter().unnecessarycast((castexpression)left);
leftiscast = false;
} else if (alternatelefttypeid == typeids.t_null) {
alternatelefttypeid = lefttypeid;  // tolerate null argument cast
leftiscast = false;
}
}
}
// check need for right operand cast
int alternaterighttypeid = righttypeid;
if (rightiscast) {
if ((right.bits & astnode.unnecessarycast) == 0 && right.resolvedtype.isbasetype()) {
// narrowing conversion on base type may change value, thus necessary
rightiscast = false;
} else {
typebinding alternaterighttype = ((castexpression)right).expression.resolvedtype;
if (alternaterighttype == null) return; // cannot do better
if ((alternaterighttypeid = alternaterighttype.id) == righttypeid || scope.environment().computeboxingtype(alternaterighttype).id == righttypeid) { // obvious identity cast
scope.problemreporter().unnecessarycast((castexpression)right);
rightiscast = false;
} else if (alternaterighttypeid == typeids.t_null) {
alternaterighttypeid = righttypeid;  // tolerate null argument cast
rightiscast = false;
}
}
}
if (leftiscast || rightiscast) {
if (alternatelefttypeid > 15 || alternaterighttypeid > 15) { // must convert string + object || object + string
if (alternatelefttypeid == typeids.t_javalangstring) {
alternaterighttypeid = typeids.t_javalangobject;
} else if (alternaterighttypeid == typeids.t_javalangstring) {
alternatelefttypeid = typeids.t_javalangobject;
} else {
return; // invalid operator
}
}
int alternateoperatorsignature = operatorexpression.operatorsignatures[operator][(alternatelefttypeid << 4) + alternaterighttypeid];
// (cast)  left   op (cast)  right --> result
//  1111   0000       1111   0000     1111
//  <<16   <<12       <<8    <<4       <<0
final int comparemask = (0xf<<16) + (0xf<<8) + 0xf; // mask hiding compile-time types
if ((operatorsignature & comparemask) == (alternateoperatorsignature & comparemask)) { // same promotions and result
if (leftiscast) scope.problemreporter().unnecessarycast((castexpression)left);
if (rightiscast) scope.problemreporter().unnecessarycast((castexpression)right);
}
}
}

private static void checkalternatebinding(blockscope scope, expression receiver, typebinding receivertype, methodbinding binding, expression[] arguments, typebinding[] originalargumenttypes, typebinding[] alternateargumenttypes, final invocationsite invocationsite) {
invocationsite fakeinvocationsite = new invocationsite(){
public typebinding[] generictypearguments() { return null; }
public boolean issuperaccess(){ return invocationsite.issuperaccess(); }
public boolean istypeaccess() { return invocationsite.istypeaccess(); }
public void setactualreceivertype(referencebinding actualreceivertype) { /* ignore */}
public void setdepth(int depth) { /* ignore */}
public void setfieldindex(int depth){ /* ignore */}
public int sourcestart() { return 0; }
public int sourceend() { return 0; }
};
methodbinding bindingifnocast;
if (binding.isconstructor()) {
bindingifnocast = scope.getconstructor((referencebinding)receivertype, alternateargumenttypes, fakeinvocationsite);
} else {
bindingifnocast = receiver.isimplicitthis()
? scope.getimplicitmethod(binding.selector, alternateargumenttypes, fakeinvocationsite)
: scope.getmethod(receivertype, binding.selector, alternateargumenttypes, fakeinvocationsite);
}
if (bindingifnocast == binding) {
int argumentlength = originalargumenttypes.length;
if (binding.isvarargs()) {
int paramlength = binding.parameters.length;
if (paramlength == argumentlength) {
int varargsindex = paramlength - 1;
arraybinding varargstype = (arraybinding) binding.parameters[varargsindex];
typebinding lastargtype = alternateargumenttypes[varargsindex];
// originaltype may be compatible already, but cast mandated
// to clarify between varargs/non-varargs call
if (varargstype.dimensions != lastargtype.dimensions()) {
return;
}
if (lastargtype.iscompatiblewith(varargstype.elementstype())
&& lastargtype.iscompatiblewith(varargstype)) {
return;
}
}
}
for (int i = 0; i < argumentlength; i++) {
if (originalargumenttypes[i] != alternateargumenttypes[i]
/*&& !originalargumenttypes[i].needsuncheckedconversion(alternateargumenttypes[i])*/) {
scope.problemreporter().unnecessarycast((castexpression)arguments[i]);
}
}
}
}

public boolean checkunsafecast(scope scope, typebinding casttype, typebinding expressiontype, typebinding match, boolean isnarrowing) {
if (match == casttype) {
if (!isnarrowing && match == this.resolvedtype.leafcomponenttype()) { // do not tag as unnecessary when recursing through upper bounds
tagasunnecessarycast(scope, casttype);
}
return true;
}
if (match != null) {
if (isnarrowing
? match.isprovablydistinct(expressiontype)
: casttype.isprovablydistinct(match)) {
return false;
}
}
switch (casttype.kind()) {
case binding.parameterized_type :
if (!casttype.isreifiable()) {
if (match == null) { // unrelated types
this.bits |= astnode.unsafecast;
return true;
}
switch (match.kind()) {
case binding.parameterized_type :
if (isnarrowing) {
// [jls 5.5] t <: s
if (expressiontype.israwtype() || !expressiontype.isequivalentto(match)) {
this.bits |= astnode.unsafecast;
return true;
}
// [jls 5.5] s has no subtype x != t, such that |x| == |t|
// if i2<t,u> extends i1<t>, then cast from i1<t> to i2<t,u> is unchecked
parameterizedtypebinding paramcasttype = (parameterizedtypebinding) casttype;
parameterizedtypebinding parammatch = (parameterizedtypebinding) match;
// easy case if less parameters on match
typebinding[] castarguments = paramcasttype.arguments;
int length = castarguments == null ? 0 : castarguments.length;
if (parammatch.arguments == null || length > parammatch.arguments.length) {
this.bits |= astnode.unsafecast;
} else if ((paramcasttype.tagbits & (tagbits.hasdirectwildcard|tagbits.hastypevariable)) != 0) {
// verify alternate cast type, substituting different type arguments
nextalternateargument: for (int i = 0; i < length; i++) {
switch (castarguments[i].kind()) {
case binding.wildcard_type :
case binding.type_parameter :
break; // check substituting with other
default:
continue nextalternateargument; // no alternative possible
}
typebinding[] alternatearguments;
// need to clone for each iteration to avoid env paramtype cache interference
system.arraycopy(paramcasttype.arguments, 0, alternatearguments = new typebinding[length], 0, length);
alternatearguments[i] = scope.getjavalangobject();
lookupenvironment environment = scope.environment();
parameterizedtypebinding alternatecasttype = environment.createparameterizedtype((referencebinding)casttype.erasure(), alternatearguments, casttype.enclosingtype());
if (alternatecasttype.findsupertypeoriginatingfrom(expressiontype) == match) {
this.bits |= astnode.unsafecast;
break;
}
}
}
return true;
} else {
// [jls 5.5] t >: s
if (!match.isequivalentto(casttype)) {
this.bits |= astnode.unsafecast;
return true;
}
}
break;
case binding.raw_type :
this.bits |= astnode.unsafecast; // upcast since casttype is known to be bound paramtype
return true;
default :
if (isnarrowing){
// match is not parameterized or raw, then any other subtype of match will erase  to |t|
this.bits |= astnode.unsafecast;
return true;
}
break;
}
}
break;
case binding.array_type :
typebinding leaftype = casttype.leafcomponenttype();
if (isnarrowing && (!leaftype.isreifiable() || leaftype.istypevariable())) {
this.bits |= astnode.unsafecast;
return true;
}
break;
case binding.type_parameter :
this.bits |= astnode.unsafecast;
return true;
//		(disabled) https://bugs.eclipse.org/bugs/show_bug.cgi?id=240807
//		case binding.type :
//			if (isnarrowing && match == null && expressiontype.isparameterizedtype()) {
//				this.bits |= astnode.unsafecast;
//				return true;
//			}
//			break;
}
if (!isnarrowing && match == this.resolvedtype.leafcomponenttype()) { // do not tag as unnecessary when recursing through upper bounds
tagasunnecessarycast(scope, casttype);
}
return true;
}

/**
* cast expression code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
boolean needruntimecheckcast = (this.bits & astnode.generatecheckcast) != 0;
if (this.constant != constant.notaconstant) {
if (valuerequired || needruntimecheckcast) { // added for: 1f1w9ig: ivjcom:winnt - compiler omits casting check
codestream.generateconstant(this.constant, this.implicitconversion);
if (needruntimecheckcast) {
codestream.checkcast(this.resolvedtype);
}
if (!valuerequired) {
// the resolvetype cannot be double or long
codestream.pop();
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
this.expression.generatecode(currentscope, codestream, valuerequired || needruntimecheckcast);
if (needruntimecheckcast && this.expression.postconversiontype(currentscope) != this.resolvedtype.erasure()) { // no need to issue a checkcast if already done as genericcast
codestream.checkcast(this.resolvedtype);
}
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
} else if (needruntimecheckcast) {
codestream.pop();
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public expression innermostcastedexpression(){
expression current = this.expression;
while (current instanceof castexpression) {
current = ((castexpression) current).expression;
}
return current;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#localvariablebinding()
*/
public localvariablebinding localvariablebinding() {
return this.expression.localvariablebinding();
}

public int nullstatus(flowinfo flowinfo) {
return this.expression.nullstatus(flowinfo);
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#optimizedbooleanconstant()
*/
public constant optimizedbooleanconstant() {
switch(this.resolvedtype.id) {
case t_boolean :
case t_javalangboolean :
return this.expression.optimizedbooleanconstant();
}
return constant.notaconstant;
}

public stringbuffer printexpression(int indent, stringbuffer output) {
output.append('(');
this.type.print(0, output).append(") "); //$non-nls-1$
return this.expression.printexpression(0, output);
}

public typebinding resolvetype(blockscope scope) {
// compute a new constant if the cast is effective

// due to the fact an expression may start with ( and that a cast can also start with (
// the field is an expression....it can be a typereference or a namereference or
// any kind of expression <-- this last one is invalid.......

this.constant = constant.notaconstant;
this.implicitconversion = typeids.t_undefined;

if ((this.type instanceof typereference) || (this.type instanceof namereference)
&& ((this.type.bits & astnode.parenthesizedmask) >> astnode.parenthesizedshift) == 0) { // no extra parenthesis around type: ((a))exp

boolean exprcontaincast = false;

typebinding casttype = this.resolvedtype = this.type.resolvetype(scope);
//expression.setexpectedtype(this.resolvedtype); // needed in case of generic method invocation
if (this.expression instanceof castexpression) {
this.expression.bits |= astnode.disableunnecessarycastcheck;
exprcontaincast = true;
}
typebinding expressiontype = this.expression.resolvetype(scope);
if (casttype != null) {
if (expressiontype != null) {
boolean islegal = checkcasttypescompatibility(scope, casttype, expressiontype, this.expression);
if (islegal) {
this.expression.computeconversion(scope, casttype, expressiontype);
if ((this.bits & astnode.unsafecast) != 0) { // unsafe cast
scope.problemreporter().unsafecast(this, scope);
} else {
if (casttype.israwtype() && scope.compileroptions().getseverity(compileroptions.rawtypereference) != problemseverities.ignore){
scope.problemreporter().rawtypereference(this.type, casttype);
}
if ((this.bits & (astnode.unnecessarycast|astnode.disableunnecessarycastcheck)) == astnode.unnecessarycast) { // unnecessary cast
if (!isindirectlyused()) // used for generic type inference or boxing ?
scope.problemreporter().unnecessarycast(this);
}
}
} else { // illegal cast
if ((casttype.tagbits & tagbits.hasmissingtype) == 0) { // no complaint if secondary error
scope.problemreporter().typecasterror(this, casttype, expressiontype);
}
this.bits |= astnode.disableunnecessarycastcheck; // disable further secondary diagnosis
}
}
this.resolvedtype = casttype.capture(scope, this.sourceend);
if (exprcontaincast) {
checkneedforcastcast(scope, this);
}
}
return this.resolvedtype;
} else { // expression as a cast
typebinding expressiontype = this.expression.resolvetype(scope);
if (expressiontype == null) return null;
scope.problemreporter().invalidtypereference(this.type);
return null;
}
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#setexpectedtype(org.eclipse.jdt.internal.compiler.lookup.typebinding)
*/
public void setexpectedtype(typebinding expectedtype) {
this.expectedtype = expectedtype;
}

/**
* determines whether apparent unnecessary cast wasn't actually used to
* perform return type inference of generic method invocation or boxing.
*/
private boolean isindirectlyused() {
if (this.expression instanceof messagesend) {
methodbinding method = ((messagesend)this.expression).binding;
if (method instanceof parameterizedgenericmethodbinding
&& ((parameterizedgenericmethodbinding)method).inferredreturntype) {
if (this.expectedtype == null)
return true;
if (this.resolvedtype != this.expectedtype)
return true;
}
}
if (this.expectedtype != null && this.resolvedtype.isbasetype() && !this.resolvedtype.iscompatiblewith(this.expectedtype)) {
// boxing: short s = (short) _byte
return true;
}
return false;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#tagasneedcheckcast()
*/
public void tagasneedcheckcast() {
this.bits |= astnode.generatecheckcast;
}

/**
* @@see org.eclipse.jdt.internal.compiler.ast.expression#tagasunnecessarycast(scope, typebinding)
*/
public void tagasunnecessarycast(scope scope, typebinding casttype) {
this.bits |= astnode.unnecessarycast;
}

public void traverse(astvisitor visitor, blockscope blockscope) {
if (visitor.visit(this, blockscope)) {
this.type.traverse(visitor, blockscope);
this.expression.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}
}
