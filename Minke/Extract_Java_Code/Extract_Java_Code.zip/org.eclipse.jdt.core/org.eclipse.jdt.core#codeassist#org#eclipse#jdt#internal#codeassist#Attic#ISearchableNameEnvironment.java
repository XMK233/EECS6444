/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import org.eclipse.jdt.internal.compiler.env.inameenvironment;

/**
* this interface defines the api that may be used to implement any
* search-based tool (such as a codeassist, a finder, ...).
* it is mainly used to hide from the search tool the implementation
* of the underlying environment and its constructions.
*/
public interface isearchablenameenvironment extends inameenvironment {

/**
* find the packages that start with the given prefix.
* a valid prefix is a qualified name separated by periods
* (ex. java.util).
* the packages found are passed to:
*    isearchrequestor.acceptpackage(char[][] packagename)
*/
void findpackages(char[] prefix, isearchrequestor requestor);

/**
* find the top-level types (classes and interfaces) that are defined
* in the current environment and whose name starts with the
* given prefix. the prefix is a qualified name separated by periods
* or a simple name (ex. java.util.v or v).
*
* the types found are passed to one of the following methods (if additional
* information is known about the types):
*    isearchrequestor.accepttype(char[][] packagename, char[] typename)
*    isearchrequestor.acceptclass(char[][] packagename, char[] typename, int modifiers)
*    isearchrequestor.acceptinterface(char[][] packagename, char[] typename, int modifiers)
*
* this method can not be used to find member types... member
* types are found relative to their enclosing type.
*/
void findtypes(char[] prefix, isearchrequestor requestor);
}
