/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.ast.javadocsinglenamereference;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class completiononjavadocparamnamereference extends javadocsinglenamereference implements completiononjavadoc {
public int completionflags = javadoc;
public char[][] missingparams;
public char[][] missingtypeparams;

public completiononjavadocparamnamereference(char[] name, long pos, int start, int end) {
super(name, pos, start, end);
}

public completiononjavadocparamnamereference(javadocsinglenamereference nameref) {
super(nameref.token, (((long)nameref.sourcestart)<<32)+nameref.sourceend, nameref.tagsourcestart, nameref.tagsourcestart);
}

/**
* @@param flags the completionflags to set.
*/
public void addcompletionflags(int flags) {
this.completionflags |= flags;
}

/**
* get completion node flags.
*
* @@return int flags of the javadoc completion node.
*/
public int getcompletionflags() {
return this.completionflags;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.allocationexpression#printexpression(int, java.lang.stringbuffer)
*/
public stringbuffer printexpression(int indent, stringbuffer output) {
output.append("<completiononjavadocparamnamereference:"); //$non-nls-1$
if (this.token != null) super.printexpression(indent, output);
return output.append('>');
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.singlenamereference#reporterror(org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public typebinding reporterror(blockscope scope) {
return null;
}
}
