/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.impl;

/*
* parser extension for code assist task
*
*/

import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.extracompilermodifiers;
import org.eclipse.jdt.internal.compiler.parser.parser;
import org.eclipse.jdt.internal.compiler.parser.recoveredblock;
import org.eclipse.jdt.internal.compiler.parser.recoveredelement;
import org.eclipse.jdt.internal.compiler.parser.recoveredfield;
import org.eclipse.jdt.internal.compiler.parser.recoveredinitializer;
import org.eclipse.jdt.internal.compiler.parser.recoveredmethod;
import org.eclipse.jdt.internal.compiler.parser.recoveredtype;
import org.eclipse.jdt.internal.compiler.parser.recoveredunit;
import org.eclipse.jdt.internal.compiler.problem.abortcompilation;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;

public abstract class assistparser extends parser {
public astnode assistnode;
public boolean isorphancompletionnode;
// last modifiers info
protected int lastmodifiers = classfileconstants.accdefault;
protected int lastmodifiersstart = -1;
/* recovery */
int[] blockstarts = new int[30];

// the previous token read by the scanner
protected int previoustoken;

// the index in the identifier stack of the previous identifier
protected int previousidentifierptr;

// depth of '(', '{' and '[]'
protected int bracketdepth;

// element stack
protected static final int elementstackincrement = 100;
protected int elementptr;
protected int[] elementkindstack = new int[elementstackincrement];
protected int[] elementinfostack = new int[elementstackincrement];
protected object[] elementobjectinfostack = new object[elementstackincrement];
protected int previouskind;
protected int previousinfo;
protected object previousobjectinfo;

// owner
protected static final int assist_parser = 512;

// kind : all values known by assistparser are between 513 and 1023
protected static final int k_selector = assist_parser + 1; // whether we are inside a message send
protected static final int k_type_delimiter = assist_parser + 2; // whether we are inside a type declaration
protected static final int k_method_delimiter = assist_parser + 3; // whether we are inside a method declaration
protected static final int k_field_initializer_delimiter = assist_parser + 4; // whether we are inside a field initializer
protected static final int k_attribute_value_delimiter = assist_parser + 5; // whether we are inside a annotation attribute valuer
protected static final int k_enum_constant_delimiter = assist_parser + 6; // whether we are inside a field initializer

// selector constants
protected static final int this_constructor = -1;
protected static final int super_constructor = -2;

// enum constant constants
protected static final int no_body = 0;
protected static final int with_body = 1;

protected boolean isfirst = false;

public assistparser(problemreporter problemreporter) {
super(problemreporter, true);
this.javadocparser.checkdoccomment = false;

setmethodsfullrecovery(false);
setstatementsrecovery(false);
}
public abstract char[] assistidentifier();

/**
* the parser become a simple parser which behave like a parser
* @@return the state of the assist parser to be able to restore the assist parser state
*/
public object becomesimpleparser() {
return null;
}
/**
* restore the parser as an assist parser
* @@param parserstate
*/
public void restoreassistparser(object parserstate) {
//do nothing
}
public int bodyend(abstractmethoddeclaration method){
return method.bodyend;
}
public int bodyend(initializer initializer){
return initializer.declarationsourceend;
}
/*
* build initial recovery state.
* recovery state is inferred from the current state of the parser (reduced node stack).
*/
public recoveredelement buildinitialrecoverystate(){
/* recovery in unit structure */
if (this.referencecontext instanceof compilationunitdeclaration){
recoveredelement element = super.buildinitialrecoverystate();
flushassiststate();
flushelementstack();
return element;
}

/* recovery in method body */
this.lastcheckpoint = 0;

recoveredelement element = null;
if (this.referencecontext instanceof abstractmethoddeclaration){
element = new recoveredmethod((abstractmethoddeclaration) this.referencecontext, null, 0, this);
this.lastcheckpoint = ((abstractmethoddeclaration) this.referencecontext).bodystart;
} else {
/* initializer bodies are parsed in the context of the type declaration, we must thus search it inside */
if (this.referencecontext instanceof typedeclaration){
typedeclaration type = (typedeclaration) this.referencecontext;
for (int i = 0; i < type.fields.length; i++){
fielddeclaration field = type.fields[i];
if (field != null
&& field.getkind() == abstractvariabledeclaration.initializer
&& field.declarationsourcestart <= this.scanner.initialposition
&& this.scanner.initialposition <= field.declarationsourceend
&& this.scanner.eofposition <= field.declarationsourceend+1){
element = new recoveredinitializer(field, null, 1, this);
this.lastcheckpoint = field.declarationsourcestart;
break;
}
}
}
}

if (element == null) return element;

/* add initial block */
block block = new block(0);
int laststart = this.blockstarts[0];
block.sourcestart = laststart;
element = element.add(block, 1);
int blockindex = 1;	// ignore first block start, since manually rebuilt here

for(int i = 0; i <= this.astptr; i++){
astnode node = this.aststack[i];

if(node instanceof foreachstatement && ((foreachstatement)node).action == null) {
node = ((foreachstatement)node).elementvariable;
}

/* check for intermediate block creation, so recovery can properly close them afterwards */
int nodestart = node.sourcestart;
for (int j = blockindex; j <= this.realblockptr; j++){
if (this.blockstarts[j] >= 0) {
if (this.blockstarts[j] > nodestart){
blockindex = j; // shift the index to the new block
break;
}
if (this.blockstarts[j] != laststart){ // avoid multiple block if at same position
block = new block(0);
block.sourcestart = laststart = this.blockstarts[j];
element = element.add(block, 1);
}
} else {
if (-this.blockstarts[j] > nodestart){
blockindex = j; // shift the index to the new block
break;
}
block = new block(0);
block.sourcestart = laststart = -this.blockstarts[j];
element = element.add(block, 1);
}
blockindex = j+1; // shift the index to the new block
}
if (node instanceof localdeclaration){
localdeclaration local = (localdeclaration) node;
if (local.declarationsourceend == 0){
element = element.add(local, 0);
if (local.initialization == null){
this.lastcheckpoint = local.sourceend + 1;
} else {
this.lastcheckpoint = local.initialization.sourceend + 1;
}
} else {
element = element.add(local, 0);
this.lastcheckpoint = local.declarationsourceend + 1;
}
continue;
}
if (node instanceof abstractmethoddeclaration){
abstractmethoddeclaration method = (abstractmethoddeclaration) node;
if (method.declarationsourceend == 0){
element = element.add(method, 0);
this.lastcheckpoint = method.bodystart;
} else {
element = element.add(method, 0);
this.lastcheckpoint = method.declarationsourceend + 1;
}
continue;
}
if (node instanceof initializer){
initializer initializer = (initializer) node;
if (initializer.declarationsourceend == 0){
element = element.add(initializer, 1);
this.lastcheckpoint = initializer.sourcestart;
} else {
element = element.add(initializer, 0);
this.lastcheckpoint = initializer.declarationsourceend + 1;
}
continue;
}
if (node instanceof fielddeclaration){
fielddeclaration field = (fielddeclaration) node;
if (field.declarationsourceend == 0){
element = element.add(field, 0);
if (field.initialization == null){
this.lastcheckpoint = field.sourceend + 1;
} else {
this.lastcheckpoint = field.initialization.sourceend + 1;
}
} else {
element = element.add(field, 0);
this.lastcheckpoint = field.declarationsourceend + 1;
}
continue;
}
if (node instanceof typedeclaration){
typedeclaration type = (typedeclaration) node;
if (type.declarationsourceend == 0){
element = element.add(type, 0);
this.lastcheckpoint = type.bodystart;
} else {
element = element.add(type, 0);
this.lastcheckpoint = type.declarationsourceend + 1;
}
continue;
}
if (node instanceof importreference){
importreference importref = (importreference) node;
element = element.add(importref, 0);
this.lastcheckpoint = importref.declarationsourceend + 1;
}
}
if (this.currenttoken == tokennamerbrace) {
this.currenttoken = 0; // closing brace has already been taken care of
}

/* might need some extra block (after the last reduced node) */
int pos = this.assistnode == null ? this.lastcheckpoint : this.assistnode.sourcestart;
for (int j = blockindex; j <= this.realblockptr; j++){
if (this.blockstarts[j] >= 0) {
if ((this.blockstarts[j] < pos) && (this.blockstarts[j] != laststart)){ // avoid multiple block if at same position
block = new block(0);
block.sourcestart = laststart = this.blockstarts[j];
element = element.add(block, 1);
}
} else {
if ((this.blockstarts[j] < pos)){ // avoid multiple block if at same position
block = new block(0);
block.sourcestart = laststart = -this.blockstarts[j];
element = element.add(block, 1);
}
}
}

return element;
}
protected void consumeannotationtypedeclarationheader() {
super.consumeannotationtypedeclarationheader();
pushonelementstack(k_type_delimiter);
}
protected void consumeclassbodydeclaration() {
popelement(k_method_delimiter);
super.consumeclassbodydeclaration();
}
protected void consumeclassbodyopt() {
super.consumeclassbodyopt();
popelement(k_selector);
}
protected void consumeclassheader() {
super.consumeclassheader();
pushonelementstack(k_type_delimiter);
}
protected void consumeconstructorbody() {
super.consumeconstructorbody();
popelement(k_method_delimiter);
}
protected void consumeconstructorheader() {
super.consumeconstructorheader();
pushonelementstack(k_method_delimiter);
}
protected void consumeenhancedforstatementheaderinit(boolean hasmodifiers) {
super.consumeenhancedforstatementheaderinit(hasmodifiers);

if (this.currentelement != null) {
localdeclaration localdecl = ((foreachstatement)this.aststack[this.astptr]).elementvariable;
this.lastcheckpoint = localdecl.sourceend + 1;
this.currentelement = this.currentelement.add(localdecl, 0);
}
}
protected void consumeenteranonymousclassbody(boolean qualified) {
super.consumeenteranonymousclassbody(qualified);
popelement(k_selector);
pushonelementstack(k_type_delimiter);
}
protected void consumeentermembervalue() {
super.consumeentermembervalue();
pushonelementstack(k_attribute_value_delimiter, this.identifierptr);
}
protected void consumeenumconstantheader() {
if(this.currenttoken == tokennamelbrace) {
popelement(k_enum_constant_delimiter);
pushonelementstack(k_enum_constant_delimiter, with_body);
pushonelementstack(k_field_initializer_delimiter);
pushonelementstack(k_type_delimiter);
}
super.consumeenumconstantheader();
}
protected void consumeenumconstantheadername() {
super.consumeenumconstantheadername();
pushonelementstack(k_enum_constant_delimiter);
}
protected void consumeenumconstantwithclassbody() {
popelement(k_type_delimiter);
popelement(k_field_initializer_delimiter);
popelement(k_enum_constant_delimiter);
super.consumeenumconstantwithclassbody();
}
protected void consumeenumconstantnoclassbody() {
popelement(k_enum_constant_delimiter);
super.consumeenumconstantnoclassbody();
}
protected void consumeenumheader() {
super.consumeenumheader();
pushonelementstack(k_type_delimiter);
}
protected void consumeexitmembervalue() {
super.consumeexitmembervalue();
popelement(k_attribute_value_delimiter);
}
protected void consumeexplicitconstructorinvocation(int flag, int recflag) {
super.consumeexplicitconstructorinvocation(flag, recflag);
popelement(k_selector);
}
protected void consumeforcenodiet() {
super.consumeforcenodiet();
// if we are not in a method (i.e. we are not in a local variable initializer)
// then we are entering a field initializer
if (!isinsidemethod()) {
if(topknownelementkind(assist_parser) != k_enum_constant_delimiter) {
if(topknownelementkind(assist_parser, 2) != k_enum_constant_delimiter) {
pushonelementstack(k_field_initializer_delimiter);
}
} else {
int info = topknownelementinfo(assist_parser);
if(info != no_body) {
pushonelementstack(k_field_initializer_delimiter);
}
}

}
}
protected void consumeinterfaceheader() {
super.consumeinterfaceheader();
pushonelementstack(k_type_delimiter);
}
protected void consumemethodbody() {
super.consumemethodbody();
popelement(k_method_delimiter);
}
protected void consumemethoddeclaration(boolean isnotabstract) {
if (!isnotabstract) {
popelement(k_method_delimiter);
}
super.consumemethoddeclaration(isnotabstract);
}
protected void consumemethodheader() {
super.consumemethodheader();
pushonelementstack(k_method_delimiter);
}
protected void consumemethodinvocationname() {
super.consumemethodinvocationname();
popelement(k_selector);
messagesend messagesend = (messagesend)this.expressionstack[this.expressionptr];
if (messagesend == this.assistnode){
this.lastcheckpoint = messagesend.sourceend + 1;
}
}
protected void consumemethodinvocationnamewithtypearguments() {
super.consumemethodinvocationnamewithtypearguments();
popelement(k_selector);
messagesend messagesend = (messagesend)this.expressionstack[this.expressionptr];
if (messagesend == this.assistnode){
this.lastcheckpoint = messagesend.sourceend + 1;
}
}
protected void consumemethodinvocationprimary() {
super.consumemethodinvocationprimary();
popelement(k_selector);
messagesend messagesend = (messagesend)this.expressionstack[this.expressionptr];
if (messagesend == this.assistnode){
this.lastcheckpoint = messagesend.sourceend + 1;
}
}
protected void consumemethodinvocationprimarywithtypearguments() {
super.consumemethodinvocationprimarywithtypearguments();
popelement(k_selector);
messagesend messagesend = (messagesend)this.expressionstack[this.expressionptr];
if (messagesend == this.assistnode){
this.lastcheckpoint = messagesend.sourceend + 1;
}
}
protected void consumemethodinvocationsuper() {
super.consumemethodinvocationsuper();
popelement(k_selector);
messagesend messagesend = (messagesend)this.expressionstack[this.expressionptr];
if (messagesend == this.assistnode){
this.lastcheckpoint = messagesend.sourceend + 1;
}
}
protected void consumemethodinvocationsuperwithtypearguments() {
super.consumemethodinvocationsuperwithtypearguments();
popelement(k_selector);
messagesend messagesend = (messagesend)this.expressionstack[this.expressionptr];
if (messagesend == this.assistnode){
this.lastcheckpoint = messagesend.sourceend + 1;
}
}
protected void consumenestedmethod() {
super.consumenestedmethod();
if(!isinsidemethod()) pushonelementstack(k_method_delimiter);
}
protected void consumeopenblock() {
// openblock ::= $empty

super.consumeopenblock();
int stacklength = this.blockstarts.length;
if (this.realblockptr >= stacklength) {
system.arraycopy(
this.blockstarts, 0,
this.blockstarts = new int[stacklength + stackincrement], 0,
stacklength);
}
this.blockstarts[this.realblockptr] = this.scanner.startposition;
}
protected void consumeopenfakeblock() {
// openblock ::= $empty

super.consumeopenblock();
int stacklength = this.blockstarts.length;
if (this.realblockptr >= stacklength) {
system.arraycopy(
this.blockstarts, 0,
this.blockstarts = new int[stacklength + stackincrement], 0,
stacklength);
}
this.blockstarts[this.realblockptr] = -this.scanner.startposition;
}
protected void consumepackagedeclarationname() {
// packagedeclarationname ::= 'package' name
/* build an importref build from the last name
stored in the identifier stack. */

int index;

/* no need to take action if not inside assist identifiers */
if ((index = indexofassistidentifier()) < 0) {
super.consumepackagedeclarationname();
return;
}
/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */
int length = this.identifierlengthstack[this.identifierlengthptr];
char[][] subset = identifiersubset(index+1); // include the assistidentifier
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist node on package statement */
importreference reference = createassistpackagereference(subset, positions);
this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;
this.compilationunit.currentpackage = reference;

if (this.currenttoken == tokennamesemicolon){
reference.declarationsourceend = this.scanner.currentposition - 1;
} else {
reference.declarationsourceend = (int) positions[length-1];
}
//endposition is just before the ;
reference.declarationsourcestart = this.intstack[this.intptr--];
// flush comments defined prior to import statements
reference.declarationsourceend = flushcommentsdefinedpriorto(reference.declarationsourceend);

// recovery
if (this.currentelement != null){
this.lastcheckpoint = reference.declarationsourceend+1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumepackagedeclarationnamewithmodifiers() {
// packagedeclarationname ::= modifiers 'package' pushrealmodifiers name
/* build an importref build from the last name
stored in the identifier stack. */

int index;

/* no need to take action if not inside assist identifiers */
if ((index = indexofassistidentifier()) < 0) {
super.consumepackagedeclarationnamewithmodifiers();
return;
}
/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */
int length = this.identifierlengthstack[this.identifierlengthptr];
char[][] subset = identifiersubset(index+1); // include the assistidentifier
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

this.intptr--; // we don't need the modifiers start
this.intptr--; // we don't need the package modifiers
importreference reference = createassistpackagereference(subset, positions);
// consume annotations
if ((length = this.expressionlengthstack[this.expressionlengthptr--]) != 0) {
system.arraycopy(
this.expressionstack,
(this.expressionptr -= length) + 1,
reference.annotations = new annotation[length],
0,
length);
}
/* build specific assist node on package statement */
this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;
this.compilationunit.currentpackage = reference;

if (this.currenttoken == tokennamesemicolon){
reference.declarationsourceend = this.scanner.currentposition - 1;
} else {
reference.declarationsourceend = (int) positions[length-1];
}
//endposition is just before the ;
reference.declarationsourcestart = this.intstack[this.intptr--];
// flush comments defined prior to import statements
reference.declarationsourceend = flushcommentsdefinedpriorto(reference.declarationsourceend);

// recovery
if (this.currentelement != null){
this.lastcheckpoint = reference.declarationsourceend+1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumerestorediet() {
super.consumerestorediet();
// if we are not in a method (i.e. we were not in a local variable initializer)
// then we are exiting a field initializer
if (!isinsidemethod()) {
popelement(k_field_initializer_delimiter);
}
}
protected void consumesinglestaticimportdeclarationname() {
// singletypeimportdeclarationname ::= 'import' 'static' name
/* push an importref build from the last name
stored in the identifier stack. */

int index;

/* no need to take action if not inside assist identifiers */
if ((index = indexofassistidentifier()) < 0) {
super.consumesinglestaticimportdeclarationname();
return;
}
/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */
int length = this.identifierlengthstack[this.identifierlengthptr];
char[][] subset = identifiersubset(index+1); // include the assistidentifier
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist node on import statement */
importreference reference = createassistimportreference(subset, positions, classfileconstants.accstatic);
this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;

pushonaststack(reference);

if (this.currenttoken == tokennamesemicolon){
reference.declarationsourceend = this.scanner.currentposition - 1;
} else {
reference.declarationsourceend = (int) positions[length-1];
}
//endposition is just before the ;
reference.declarationsourcestart = this.intstack[this.intptr--];
// flush annotations defined prior to import statements
reference.declarationsourceend = flushcommentsdefinedpriorto(reference.declarationsourceend);

// recovery
if (this.currentelement != null){
this.lastcheckpoint = reference.declarationsourceend+1;
this.currentelement = this.currentelement.add(reference, 0);
this.lastignoredtoken = -1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumesingletypeimportdeclarationname() {
// singletypeimportdeclarationname ::= 'import' name
/* push an importref build from the last name
stored in the identifier stack. */

int index;

/* no need to take action if not inside assist identifiers */
if ((index = indexofassistidentifier()) < 0) {
super.consumesingletypeimportdeclarationname();
return;
}
/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */
int length = this.identifierlengthstack[this.identifierlengthptr];
char[][] subset = identifiersubset(index+1); // include the assistidentifier
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist node on import statement */
importreference reference = createassistimportreference(subset, positions, classfileconstants.accdefault);
this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;

pushonaststack(reference);

if (this.currenttoken == tokennamesemicolon){
reference.declarationsourceend = this.scanner.currentposition - 1;
} else {
reference.declarationsourceend = (int) positions[length-1];
}
//endposition is just before the ;
reference.declarationsourcestart = this.intstack[this.intptr--];
// flush comments defined prior to import statements
reference.declarationsourceend = flushcommentsdefinedpriorto(reference.declarationsourceend);

// recovery
if (this.currentelement != null){
this.lastcheckpoint = reference.declarationsourceend+1;
this.currentelement = this.currentelement.add(reference, 0);
this.lastignoredtoken = -1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumestaticimportondemanddeclarationname() {
// typeimportondemanddeclarationname ::= 'import' 'static' name '.' '*'
/* push an importref build from the last name
stored in the identifier stack. */

int index;

/* no need to take action if not inside assist identifiers */
if ((index = indexofassistidentifier()) < 0) {
super.consumestaticimportondemanddeclarationname();
return;
}
/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */
int length = this.identifierlengthstack[this.identifierlengthptr];
char[][] subset = identifiersubset(index+1); // include the assistidentifier
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist node on import statement */
importreference reference = createassistimportreference(subset, positions, classfileconstants.accstatic);
reference.bits |= astnode.ondemand;
this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;

pushonaststack(reference);

if (this.currenttoken == tokennamesemicolon){
reference.declarationsourceend = this.scanner.currentposition - 1;
} else {
reference.declarationsourceend = (int) positions[length-1];
}
//endposition is just before the ;
reference.declarationsourcestart = this.intstack[this.intptr--];
// flush annotations defined prior to import statements
reference.declarationsourceend = flushcommentsdefinedpriorto(reference.declarationsourceend);

// recovery
if (this.currentelement != null){
this.lastcheckpoint = reference.declarationsourceend+1;
this.currentelement = this.currentelement.add(reference, 0);
this.lastignoredtoken = -1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
protected void consumestaticinitializer() {
super.consumestaticinitializer();
popelement(k_method_delimiter);
}
protected void consumestaticonly() {
super.consumestaticonly();
pushonelementstack(k_method_delimiter);
}
protected void consumetoken(int token) {
super.consumetoken(token);

if(this.isfirst) {
this.isfirst = false;
return;
}
// register message send selector only if inside a method or if looking at a field initializer
// and if the current token is an open parenthesis
if (isinsidemethod() || isinsidefieldinitialization() || isinsideattributevalue()) {
switch (token) {
case tokennamelparen :
this.bracketdepth++;
switch (this.previoustoken) {
case tokennameidentifier:
this.pushonelementstack(k_selector, this.identifierptr);
break;
case tokennamethis: // explicit constructor invocation, e.g. this(1, 2)
this.pushonelementstack(k_selector, this_constructor);
break;
case tokennamesuper: // explicit constructor invocation, e.g. super(1, 2)
this.pushonelementstack(k_selector, super_constructor);
break;
case tokennamegreater: // explicit constructor invocation, e.g. fred<x>[(]1, 2)
case tokennameright_shift: // or fred<x<x>>[(]1, 2)
case tokennameunsigned_right_shift: //or fred<x<x<x>>>[(]1, 2)
if(this.identifierptr > -1) {
this.pushonelementstack(k_selector, this.identifierptr);
}
break;
}
break;
case tokennamelbrace:
this.bracketdepth++;
break;
case tokennamelbracket:
this.bracketdepth++;
break;
case tokennamerbrace:
this.bracketdepth--;
break;
case tokennamerbracket:
this.bracketdepth--;
break;
case tokennamerparen:
this.bracketdepth--;
break;
}
} else {
switch (token) {
case tokennamerbrace :
if(topknownelementkind(assist_parser) == k_type_delimiter) {
popelement(k_type_delimiter);
}
break;
}
}
this.previoustoken = token;
if (token == tokennameidentifier) {
this.previousidentifierptr = this.identifierptr;
}
}
protected void consumetypeimportondemanddeclarationname() {
// typeimportondemanddeclarationname ::= 'import' name '.' '*'
/* push an importref build from the last name
stored in the identifier stack. */

int index;

/* no need to take action if not inside assist identifiers */
if ((index = indexofassistidentifier()) < 0) {
super.consumetypeimportondemanddeclarationname();
return;
}
/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */
int length = this.identifierlengthstack[this.identifierlengthptr];
char[][] subset = identifiersubset(index+1); // include the assistidentifier
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist node on import statement */
importreference reference = createassistimportreference(subset, positions, classfileconstants.accdefault);
reference.bits |= astnode.ondemand;
this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;

pushonaststack(reference);

if (this.currenttoken == tokennamesemicolon){
reference.declarationsourceend = this.scanner.currentposition - 1;
} else {
reference.declarationsourceend = (int) positions[length-1];
}
//endposition is just before the ;
reference.declarationsourcestart = this.intstack[this.intptr--];
// flush comments defined prior to import statements
reference.declarationsourceend = flushcommentsdefinedpriorto(reference.declarationsourceend);

// recovery
if (this.currentelement != null){
this.lastcheckpoint = reference.declarationsourceend+1;
this.currentelement = this.currentelement.add(reference, 0);
this.lastignoredtoken = -1;
this.restartrecovery = true; // used to avoid branching back into the regular automaton
}
}
public abstract importreference createassistimportreference(char[][] tokens, long[] positions, int mod);
public abstract importreference createassistpackagereference(char[][] tokens, long[] positions);
public abstract namereference createqualifiedassistnamereference(char[][] previousidentifiers, char[] assistname, long[] positions);
public abstract typereference createqualifiedassisttypereference(char[][] previousidentifiers, char[] assistname, long[] positions);
public abstract typereference createparameterizedqualifiedassisttypereference(char[][] previousidentifiers, typereference[][] typearguments, char[] asistidentifier, typereference[] assisttypearguments, long[] positions);
public abstract namereference createsingleassistnamereference(char[] assistname, long position);
public abstract typereference createsingleassisttypereference(char[] assistname, long position);
public abstract typereference createparameterizedsingleassisttypereference(typereference[] typearguments, char[] assistname, long position);
/*
* flush parser/scanner state regarding to code assist
*/
public void flushassiststate(){
this.assistnode = null;
this.isorphancompletionnode = false;
setassistidentifier(null);
}
protected void flushelementstack() {
for (int j = 0; j <= this.elementptr; j++) {
this.elementobjectinfostack[j] = null;
}

this.elementptr = -1;
this.previouskind = 0;
this.previousinfo = 0;
this.previousobjectinfo = null;
}
/*
* build specific type reference nodes in case the cursor is located inside the type reference
*/
protected typereference gettypereference(int dim) {

int index;

/* no need to take action if not inside completed identifiers */
if ((index = indexofassistidentifier(true)) < 0) {
return super.gettypereference(dim);
}
int length = this.identifierlengthstack[this.identifierlengthptr];
typereference reference;
int numberofidentifiers = this.genericsidentifierslengthstack[this.genericsidentifierslengthptr--];
if (length != numberofidentifiers || this.genericslengthstack[this.genericslengthptr] != 0) {
this.identifierlengthptr--;
// generic type
reference = getassisttypereferenceforgenerictype(dim, length, numberofidentifiers);
} else {
/* retrieve identifiers subset and whole positions, the assist node positions
should include the entire replaced source. */

char[][] subset = identifiersubset(index);
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific assist on type reference */

if (index == 0) {
//			genericsidentifierslengthptr--;
this.genericslengthptr--;
/* assist inside first identifier */
reference = createsingleassisttypereference(
assistidentifier(),
positions[0]);
} else {
//			genericsidentifierslengthptr--;
this.genericslengthptr--;
/* assist inside subsequent identifier */
reference =	createqualifiedassisttypereference(
subset,
assistidentifier(),
positions);
}
this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;
}
return reference;
}
protected typereference getassisttypereferenceforgenerictype(int dim, int identifierlength, int numberofidentifiers) {
/* no need to take action if not inside completed identifiers */
if (/*(indexofassistidentifier()) < 0 ||*/ (identifierlength == 1 && numberofidentifiers == 1)) {
int currenttypeargumentslength = this.genericslengthstack[this.genericslengthptr--];
typereference[] typearguments = new typereference[currenttypeargumentslength];
this.genericsptr -= currenttypeargumentslength;
system.arraycopy(this.genericsstack, this.genericsptr + 1, typearguments, 0, currenttypeargumentslength);
long[] positions = new long[identifierlength];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr,
positions,
0,
identifierlength);

this.identifierptr--;

typereference reference = createparameterizedsingleassisttypereference(
typearguments,
assistidentifier(),
positions[0]);

this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;
return reference;
}

typereference[][] typearguments = new typereference[numberofidentifiers][];
char[][] tokens = new char[numberofidentifiers][];
long[] positions = new long[numberofidentifiers];
int index = numberofidentifiers;
int currentidentifierslength = identifierlength;
while (index > 0) {
int currenttypeargumentslength = this.genericslengthstack[this.genericslengthptr--];
if (currenttypeargumentslength != 0) {
this.genericsptr -= currenttypeargumentslength;
system.arraycopy(this.genericsstack, this.genericsptr + 1, typearguments[index - 1] = new typereference[currenttypeargumentslength], 0, currenttypeargumentslength);
}
switch(currentidentifierslength) {
case 1 :
// we are in a case a<b>.c<d> or a<b>.c<d>
tokens[index - 1] = this.identifierstack[this.identifierptr];
positions[index - 1] = this.identifierpositionstack[this.identifierptr--];
break;
default:
// we are in a case a.b.c<b>.c<d> or a.b.c<b>...
this.identifierptr -= currentidentifierslength;
system.arraycopy(this.identifierstack, this.identifierptr + 1, tokens, index - currentidentifierslength, currentidentifierslength);
system.arraycopy(this.identifierpositionstack, this.identifierptr + 1, positions, index - currentidentifierslength, currentidentifierslength);
}
index -= currentidentifierslength;
if (index > 0) {
currentidentifierslength = this.identifierlengthstack[this.identifierlengthptr--];
}
}

// remove completion token
int reallength = numberofidentifiers;
for (int i = 0; i < numberofidentifiers; i++) {
if(tokens[i] == assistidentifier()) {
reallength = i;
}
}
typereference reference;
if(reallength == 0) {
if(typearguments[0] != null && typearguments[0].length > 0) {
reference = createparameterizedsingleassisttypereference(typearguments[0], assistidentifier(), positions[0]);
} else {
reference = createsingleassisttypereference(assistidentifier(), positions[0]);
}
} else {
typereference[] assisttypearguments = typearguments[reallength];
system.arraycopy(tokens, 0, tokens = new char[reallength][], 0, reallength);
system.arraycopy(typearguments, 0, typearguments = new typereference[reallength][], 0, reallength);

boolean isparameterized = false;
for (int i = 0; i < typearguments.length; i++) {
if(typearguments[i] != null) {
isparameterized = true;
}
}
if(isparameterized || (assisttypearguments != null && assisttypearguments.length > 0)) {
reference = createparameterizedqualifiedassisttypereference(tokens, typearguments, assistidentifier(), assisttypearguments, positions);
} else {
reference = createqualifiedassisttypereference(tokens, assistidentifier(), positions);
}
}

this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;
return reference;
}
/*
* copy of code from superclass with the following change:
* in the case of qualified name reference if the cursor location is on the
* qualified name reference, then create a completiononqualifiednamereference
* instead.
*/
protected namereference getunspecifiedreferenceoptimized() {

int completionindex;

/* no need to take action if not inside completed identifiers */
if ((completionindex = indexofassistidentifier()) < 0) {
return super.getunspecifiedreferenceoptimized();
}

/* retrieve identifiers subset and whole positions, the completion node positions
should include the entire replaced source. */
int length = this.identifierlengthstack[this.identifierlengthptr];
char[][] subset = identifiersubset(completionindex);
this.identifierlengthptr--;
this.identifierptr -= length;
long[] positions = new long[length];
system.arraycopy(
this.identifierpositionstack,
this.identifierptr + 1,
positions,
0,
length);

/* build specific completion on name reference */
namereference reference;
if (completionindex == 0) {
/* completion inside first identifier */
reference = createsingleassistnamereference(assistidentifier(), positions[0]);
} else {
/* completion inside subsequent identifier */
reference = createqualifiedassistnamereference(subset, assistidentifier(), positions);
}
reference.bits &= ~astnode.restrictiveflagmask;
reference.bits |= binding.local | binding.field;

this.assistnode = reference;
this.lastcheckpoint = reference.sourceend + 1;
return reference;
}
public void goforblockstatementsopt() {
super.goforblockstatementsopt();
this.isfirst = true;
}
public void goforheaders(){
super.goforheaders();
this.isfirst = true;
}
public void goforcompilationunit(){
super.goforcompilationunit();
this.isfirst = true;
}
public void goforblockstatementsorcatchheader() {
super.goforblockstatementsorcatchheader();
this.isfirst = true;
}
/*
* retrieve a partial subset of a qualified name reference up to the completion point.
* it does not pop the actual awaiting identifiers, so as to be able to retrieve position
* information afterwards.
*/
protected char[][] identifiersubset(int subsetlength){

if (subsetlength == 0) return null;

char[][] subset;
system.arraycopy(
this.identifierstack,
this.identifierptr - this.identifierlengthstack[this.identifierlengthptr] + 1,
(subset = new char[subsetlength][]),
0,
subsetlength);
return subset;
}

protected int indexofassistidentifier(){
return this.indexofassistidentifier(false);
}
/*
* iterate the most recent group of awaiting identifiers (grouped for qualified name reference (e.g. aa.bb.cc)
* so as to check whether one of them is the assist identifier.
* if so, then answer the index of the assist identifier (0 being the first identifier of the set).
*	e.g. aa(0).bb(1).cc(2)
* if no assist identifier was found, answers -1.
*/
protected int indexofassistidentifier(boolean usegenericsstack){

if (this.identifierlengthptr < 0){
return -1; // no awaiting identifier
}

char[] assistidentifier ;
if ((assistidentifier = assistidentifier()) == null){
return -1; // no assist identifier found yet
}

// iterate awaiting identifiers backwards
int length = this.identifierlengthstack[this.identifierlengthptr];
if(usegenericsstack && length > 0 && this.genericsidentifierslengthptr > -1 ) {
length = this.genericsidentifierslengthstack[this.genericsidentifierslengthptr];
}
for (int i = 0; i < length; i++){
if (this.identifierstack[this.identifierptr - i] == assistidentifier){
return length - i - 1;
}
}
// none of the awaiting identifiers is the completion one
return -1;
}
public void initialize() {
super.initialize();
flushassiststate();
flushelementstack();
this.previousidentifierptr = -1;
this.bracketdepth = 0;
}
public void initialize(boolean initializenls) {
super.initialize(initializenls);
flushassiststate();
flushelementstack();
this.previousidentifierptr = -1;
this.bracketdepth = 0;
}
public abstract void initializescanner();
protected boolean isindirectlyinsidefieldinitialization(){
int i = this.elementptr;
while(i > -1) {
if(this.elementkindstack[i] == k_field_initializer_delimiter)
return true;
i--;
}
return false;
}
protected boolean isindirectlyinsidemethod(){
int i = this.elementptr;
while(i > -1) {
if(this.elementkindstack[i] == k_method_delimiter)
return true;
i--;
}
return false;
}
protected boolean isindirectlyinsidetype(){
int i = this.elementptr;
while(i > -1) {
if(this.elementkindstack[i] == k_type_delimiter)
return true;
i--;
}
return false;
}
protected boolean isinsideattributevalue(){
int i = this.elementptr;
while(i > -1) {
switch (this.elementkindstack[i]) {
case k_type_delimiter : return false;
case k_method_delimiter : return false;
case k_field_initializer_delimiter : return false;
case k_attribute_value_delimiter : return true;
}
i--;
}
return false;
}
protected boolean isinsidefieldinitialization(){
int i = this.elementptr;
while(i > -1) {
switch (this.elementkindstack[i]) {
case k_type_delimiter : return false;
case k_method_delimiter : return false;
case k_field_initializer_delimiter : return true;
}
i--;
}
return false;
}
protected boolean isinsidemethod(){
int i = this.elementptr;
while(i > -1) {
switch (this.elementkindstack[i]) {
case k_type_delimiter : return false;
case k_method_delimiter : return true;
case k_field_initializer_delimiter : return false;
}
i--;
}
return false;
}
protected boolean isinsidetype(){
int i = this.elementptr;
while(i > -1) {
switch (this.elementkindstack[i]) {
case k_type_delimiter : return true;
case k_method_delimiter : return false;
case k_field_initializer_delimiter : return false;
}
i--;
}
return false;
}
protected int lastindexofelement(int kind) {
int i = this.elementptr;
while(i > -1) {
if(this.elementkindstack[i] == kind) return i;
i--;
}
return -1;
}
/**
* parse the block statements inside the given method declaration and try to complete at the
* cursor location.
*/
public void parseblockstatements(abstractmethoddeclaration md, compilationunitdeclaration unit) {
if (md instanceof methoddeclaration) {
parseblockstatements((methoddeclaration) md, unit);
} else if (md instanceof constructordeclaration) {
parseblockstatements((constructordeclaration) md, unit);
}
}
/**
* parse the block statements inside the given constructor declaration and try to complete at the
* cursor location.
*/
public void parseblockstatements(constructordeclaration cd, compilationunitdeclaration unit) {
//only parse the method body of cd
//fill out its statements

//convert bugs into parse error

initialize();
// set the lastmodifiers to reflect the modifiers of the constructor whose
// block statements are being parsed
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=202634
this.lastmodifiers = cd.modifiers;
this.lastmodifiersstart = cd.modifierssourcestart;
// simulate goforconstructorbody except that we don't want to balance brackets because they are not going to be balanced
goforblockstatementsopt();

this.referencecontext = cd;
this.compilationunit = unit;

this.scanner.resetto(cd.bodystart, bodyend(cd));
consumenestedmethod();
try {
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
}

if (this.lastact == error_action) {
cd.bits |= astnode.hassyntaxerrors;
return;
}

// attach the statements as we might be searching for a reference to a local type
cd.explicitdeclarations = this.realblockstack[this.realblockptr--];
int length;
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
this.astptr -= length;
if (this.aststack[this.astptr + 1] instanceof explicitconstructorcall)
//avoid a issomething that would only be used here but what is faster between two alternatives ?
{
system.arraycopy(
this.aststack,
this.astptr + 2,
cd.statements = new statement[length - 1],
0,
length - 1);
cd.constructorcall = (explicitconstructorcall) this.aststack[this.astptr + 1];
} else { //need to add explicitly the super();
system.arraycopy(
this.aststack,
this.astptr + 1,
cd.statements = new statement[length],
0,
length);
cd.constructorcall = superreference.implicitsuperconstructorcall();
}
} else {
cd.constructorcall = superreference.implicitsuperconstructorcall();
if (!containscomment(cd.bodystart, cd.bodyend)) {
cd.bits |= astnode.undocumentedemptyblock;
}
}

if (cd.constructorcall.sourceend == 0) {
cd.constructorcall.sourceend = cd.sourceend;
cd.constructorcall.sourcestart = cd.sourcestart;
}
}
/**
* parse the block statements inside the given initializer and try to complete at the
* cursor location.
*/
public void parseblockstatements(
initializer initializer,
typedeclaration type,
compilationunitdeclaration unit) {

initialize();
// set the lastmodifiers to reflect the modifiers of the initializer whose
// block statements are being parsed
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=202634
this.lastmodifiers = initializer.modifiers;
this.lastmodifiersstart = initializer.modifierssourcestart;
// simulate goforinitializer except that we don't want to balance brackets because they are not going to be balanced
goforblockstatementsopt();

this.referencecontext = type;
this.compilationunit = unit;

this.scanner.resetto(initializer.sourcestart, bodyend(initializer)); // just after the beginning {
consumenestedmethod();
try {
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
} finally {
this.nestedmethod[this.nestedtype]--;
}

if (this.lastact == error_action) {
initializer.bits |= astnode.hassyntaxerrors;
return;
}

// attach the statements as we might be searching for a reference to a local type
initializer.block.explicitdeclarations = this.realblockstack[this.realblockptr--];
int length;
if ((length = this.astlengthstack[this.astlengthptr--]) > 0) {
system.arraycopy(this.aststack, (this.astptr -= length) + 1, initializer.block.statements = new statement[length], 0, length);
} else {
// check whether this block at least contains some comment in it
if (!containscomment(initializer.block.sourcestart, initializer.block.sourceend)) {
initializer.block.bits |= astnode.undocumentedemptyblock;
}
}

// mark initializer with local type if one was found during parsing
if ((type.bits & astnode.haslocaltype) != 0) {
initializer.bits |= astnode.haslocaltype;
}
}
/**
* parse the block statements inside the given method declaration and try to complete at the
* cursor location.
*/
public void parseblockstatements(methoddeclaration md, compilationunitdeclaration unit) {
//only parse the method body of md
//fill out method statements

//convert bugs into parse error

if (md.isabstract())
return;
if (md.isnative())
return;
if ((md.modifiers & extracompilermodifiers.accsemicolonbody) != 0)
return;

initialize();
// set the lastmodifiers to reflect the modifiers of the method whose
// block statements are being parsed
// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=202634
this.lastmodifiers = md.modifiers;
this.lastmodifiersstart = md.modifierssourcestart;
// simulate goformethodbody except that we don't want to balance brackets because they are not going to be balanced
goforblockstatementsopt();

this.referencecontext = md;
this.compilationunit = unit;

this.scanner.resetto(md.bodystart, bodyend(md)); // reset the scanner to parser from { down to the cursor location
consumenestedmethod();
try {
parse();
} catch (abortcompilation ex) {
this.lastact = error_action;
} finally {
this.nestedmethod[this.nestedtype]--;
}

if (this.lastact == error_action) {
md.bits |= astnode.hassyntaxerrors;
return;
}

// attach the statements as we might be searching for a reference to a local type
md.explicitdeclarations = this.realblockstack[this.realblockptr--];
int length;
if ((length = this.astlengthstack[this.astlengthptr--]) != 0) {
system.arraycopy(
this.aststack,
(this.astptr -= length) + 1,
md.statements = new statement[length],
0,
length);
} else {
if (!containscomment(md.bodystart, md.bodyend)) {
md.bits |= astnode.undocumentedemptyblock;
}
}

}
protected void popelement(int kind){
if(this.elementptr < 0 || this.elementkindstack[this.elementptr] != kind) return;

this.previouskind = this.elementkindstack[this.elementptr];
this.previousinfo = this.elementinfostack[this.elementptr];
this.previousobjectinfo = this.elementobjectinfostack[this.elementptr];

this.elementobjectinfostack[this.elementptr] = null;

switch (kind) {
default :
this.elementptr--;
break;
}
}
protected void popuntilelement(int kind){
if(this.elementptr < 0) return;
int i = this.elementptr;
while (i >= 0 && this.elementkindstack[i] != kind) {
i--;
}
if(i >= 0) {
if(i < this.elementptr) {
this.previouskind = this.elementkindstack[i+1];
this.previousinfo = this.elementinfostack[i+1];
this.previousobjectinfo = this.elementobjectinfostack[i+1];

for (int j = i + 1; j <= this.elementptr; j++) {
this.elementobjectinfostack[j] = null;
}
}
this.elementptr = i;
}
}
/*
* prepares the state of the parser to go for blockstatements.
*/
protected void prepareforblockstatements() {
this.nestedmethod[this.nestedtype = 0] = 1;
this.variablescounter[this.nestedtype] = 0;
this.realblockstack[this.realblockptr = 1] = 0;

// initialize element stack
int fieldinitializerindex = lastindexofelement(k_field_initializer_delimiter);
int methodindex = lastindexofelement(k_method_delimiter);
if(methodindex == fieldinitializerindex) {
// there is no method and no field initializer
flushelementstack();
} else if(methodindex > fieldinitializerindex) {
popuntilelement(k_method_delimiter);
} else {
popuntilelement(k_field_initializer_delimiter);
}
}
/*
* prepares the state of the parser to go for headers.
*/
protected void prepareforheaders() {
this.nestedmethod[this.nestedtype = 0] = 0;
this.variablescounter[this.nestedtype] = 0;
this.realblockstack[this.realblockptr = 0] = 0;

popuntilelement(k_type_delimiter);

if(this.topknownelementkind(assist_parser) != k_type_delimiter) {
// is outside a type and inside a compilation unit.
// remove all elements.
flushelementstack();
}
}
protected void pushonelementstack(int kind){
this.pushonelementstack(kind, 0, null);
}
protected void pushonelementstack(int kind, int info){
this.pushonelementstack(kind, info, null);
}
protected void pushonelementstack(int kind, int info, object objectinfo){
if (this.elementptr < -1) return;

this.previouskind = 0;
this.previousinfo = 0;
this.previousobjectinfo = null;

int stacklength = this.elementkindstack.length;
if (++this.elementptr >= stacklength) {
system.arraycopy(
this.elementkindstack, 0,
this.elementkindstack = new int[stacklength + stackincrement], 0,
stacklength);
system.arraycopy(
this.elementinfostack, 0,
this.elementinfostack = new int[stacklength + stackincrement], 0,
stacklength);
system.arraycopy(
this.elementobjectinfostack, 0,
this.elementobjectinfostack = new object[stacklength + stackincrement], 0,
stacklength);
}
this.elementkindstack[this.elementptr] = kind;
this.elementinfostack[this.elementptr] = info;
this.elementobjectinfostack[this.elementptr] = objectinfo;
}
public void recoveryexitfromvariable() {
if(this.currentelement != null && this.currentelement instanceof recoveredfield
&& !(this.currentelement instanceof recoveredinitializer)) {
recoveredelement oldelement = this.currentelement;
super.recoveryexitfromvariable();
if(oldelement != this.currentelement) {
popelement(k_field_initializer_delimiter);
}
} else {
super.recoveryexitfromvariable();
}
}
public void recoverytokencheck() {
recoveredelement oldelement = this.currentelement;
switch (this.currenttoken) {
case tokennamelbrace :
super.recoverytokencheck();
if(this.currentelement instanceof recoveredinitializer) {
if(oldelement instanceof recoveredfield) {
popuntilelement(k_field_initializer_delimiter);
popelement(k_field_initializer_delimiter);
}
if(this.currentelement != oldelement
&& topknownelementkind(assist_parser) != k_method_delimiter) {
pushonelementstack(k_method_delimiter);
}
}
break;
case tokennamerbrace :
super.recoverytokencheck();
if(this.currentelement != oldelement && !isinsideattributevalue()) {
if(oldelement instanceof recoveredinitializer
|| oldelement instanceof recoveredmethod
|| (oldelement instanceof recoveredblock && oldelement.parent instanceof recoveredinitializer)
|| (oldelement instanceof recoveredblock && oldelement.parent instanceof recoveredmethod)) {
popuntilelement(k_method_delimiter);
popelement(k_method_delimiter);
} else if(oldelement instanceof recoveredtype) {
popuntilelement(k_type_delimiter);
if(!(this.referencecontext instanceof compilationunitdeclaration)
|| isindirectlyinsidefieldinitialization()
|| this.currentelement instanceof recoveredunit) {
popelement(k_type_delimiter);
}
}
}
break;
default :
super.recoverytokencheck();
break;
}
}
public void reset(){
flushassiststate();
}
/*
* reset context so as to resume to regular parse loop
* if unable to reset for resuming, answers false.
*
* move checkpoint location, reset internal stacks and
* decide which grammar goal is activated.
*/
protected boolean resumeafterrecovery() {

// reset internal stacks
this.astptr = -1;
this.astlengthptr = -1;
this.expressionptr = -1;
this.expressionlengthptr = -1;
this.identifierptr = -1;
this.identifierlengthptr	= -1;
this.intptr = -1;
this.dimensions = 0 ;
this.recoveredstaticinitializerstart = 0;

this.genericsidentifierslengthptr = -1;
this.genericslengthptr = -1;
this.genericsptr = -1;

this.modifiers = classfileconstants.accdefault;
this.modifierssourcestart = -1;

// if in diet mode, reset the diet counter because we're going to restart outside an initializer.
if (this.diet) this.dietint = 0;

/* attempt to move checkpoint location */
if (!moverecoverycheckpoint()) return false;

// only look for headers
if (this.referencecontext instanceof compilationunitdeclaration
|| this.assistnode != null){
if(isinsidemethod() &&
isindirectlyinsidefieldinitialization() &&
this.assistnode == null
){
prepareforblockstatements();
goforblockstatementsorcatchheader();
} else {
prepareforheaders();
goforheaders();
this.diet = true; // passed this point, will not consider method bodies
}
return true;
}
if (this.referencecontext instanceof abstractmethoddeclaration
|| this.referencecontext instanceof typedeclaration){

if (this.currentelement instanceof recoveredtype){
prepareforheaders();
goforheaders();
} else {
prepareforblockstatements();
goforblockstatementsorcatchheader();
}
return true;
}
// does not know how to restart
return false;
}
public abstract void setassistidentifier(char[] assistident);
protected int topknownelementinfo(int owner) {
return topknownelementinfo(owner, 0);
}
protected int topknownelementinfo(int owner, int offset) {
int i = this.elementptr;
while(i > -1) {
if((this.elementkindstack[i] & owner) != 0) {
if(offset <= 0) return this.elementinfostack[i];
offset--;
}
i--;
}
return 0;
}
protected int topknownelementkind(int owner) {
return topknownelementkind(owner, 0);
}
protected int topknownelementkind(int owner, int offset) {
int i = this.elementptr;
while(i > -1) {
if((this.elementkindstack[i] & owner) != 0) {
if(offset <= 0) return this.elementkindstack[i];
offset--;
}
i--;
}
return 0;
}
protected object topknownelementobjectinfo(int owner, int offset) {
int i = this.elementptr;
while(i > -1) {
if((this.elementkindstack[i] & owner) != 0) {
if(offset <= 0) return this.elementobjectinfostack[i];
offset--;
}
i--;
}
return null;
}
protected object topknownelementobjectinfo(int owner) {
return topknownelementobjectinfo(owner, 0);
}
/**
* if the given ast node is inside an explicit constructor call
* then wrap it with a fake constructor call.
* returns the wrapped completion node or the completion node itself.
*/
protected astnode wrapwithexplicitconstructorcallifneeded(astnode ast) {
int selector;
if (ast != null && topknownelementkind(assist_parser) == k_selector && ast instanceof expression &&
(((selector = topknownelementinfo(assist_parser)) == this_constructor) ||
(selector == super_constructor))) {
explicitconstructorcall call = new explicitconstructorcall(
(selector == this_constructor) ?
explicitconstructorcall.this :
explicitconstructorcall.super
);
call.arguments = new expression[] {(expression)ast};
call.sourcestart = ast.sourcestart;
call.sourceend = ast.sourceend;
return call;
} else {
return ast;
}
}
}
