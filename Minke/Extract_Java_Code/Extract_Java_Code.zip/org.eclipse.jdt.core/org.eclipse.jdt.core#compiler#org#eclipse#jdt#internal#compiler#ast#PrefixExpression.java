/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class prefixexpression extends compoundassignment {

/**
* prefixexpression constructor comment.
* @@param lhs org.eclipse.jdt.internal.compiler.ast.expression
* @@param expression org.eclipse.jdt.internal.compiler.ast.expression
* @@param operator int
*/
public prefixexpression(expression lhs, expression expression, int operator, int pos) {
super(lhs, expression, operator, lhs.sourceend);
this.sourcestart = pos;
this.sourceend = lhs.sourceend;
}
public boolean checkcastcompatibility() {
return false;
}
public string operatortostring() {
switch (this.operator) {
case plus :
return "++"; //$non-nls-1$
case minus :
return "--"; //$non-nls-1$
}
return "unknown operator"; //$non-nls-1$
}

public stringbuffer printexpressionnoparenthesis(int indent, stringbuffer output) {

output.append(operatortostring()).append(' ');
return this.lhs.printexpression(0, output);
}

public boolean restrainusagetonumerictypes() {
return true;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
this.lhs.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
