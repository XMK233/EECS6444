/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

public interface typeids {

//base type void null undefined object string
//should have an id that is 0<= id <= 15
// the ids below must be representable using 4 bits so as to fit in operator signatures.
final int t_undefined = 0; // should not be changed
final int t_javalangobject = 1;
final int t_char = 2;
final int t_byte = 3;
final int t_short = 4;
final int t_boolean = 5;
final int t_void = 6;
final int t_long = 7;
final int t_double = 8;
final int t_float = 9;
final int t_int = 10;
final int t_javalangstring = 11;
final int t_null = 12;

//=========end of 4 bits constraint===========

// well-known exception types
final int t_javalangclass = 16;
final int t_javalangstringbuffer = 17;
final int t_javalangsystem = 18;
final int t_javalangerror = 19;
final int t_javalangreflectconstructor = 20;
final int t_javalangthrowable = 21;
final int t_javalangnoclassdeferror = 22;
final int t_javalangclassnotfoundexception = 23;
final int t_javalangruntimeexception = 24;
final int t_javalangexception = 25;

// wrapper types
final int t_javalangbyte = 26;
final int t_javalangshort = 27;
final int t_javalangcharacter = 28;
final int t_javalanginteger = 29;
final int t_javalanglong = 30;
final int t_javalangfloat = 31;
final int t_javalangdouble = 32;
final int t_javalangboolean = 33;
final int t_javalangvoid = 34;

// 1.4 features
final int t_javalangassertionerror = 35;

// array interfaces
final int t_javalangcloneable = 36;
final int t_javaioserializable = 37;

// 1.5 features
final int t_javalangiterable = 38;
final int t_javautiliterator = 39;
final int t_javalangstringbuilder = 40;
final int t_javalangenum = 41;
final int t_javalangillegalargumentexception = 42;
final int t_javalangannotationannotation = 43;
final int t_javalangdeprecated = 44;
final int t_javalangannotationdocumented = 45;
final int t_javalangannotationinherited = 46;
final int t_javalangoverride = 47;
final int t_javalangannotationretention = 48;
final int t_javalangsuppresswarnings = 49;
final int t_javalangannotationtarget = 50;
final int t_javalangannotationretentionpolicy = 51;
final int t_javalangannotationelementtype = 52;

final int t_javaioprintstream = 53;

final int t_javalangreflectfield = 54;
final int t_javalangreflectmethod = 55;

final int t_javaioexternalizable = 56;
final int t_javaioobjectstreamexception = 57;
final int t_javaioexception = 58;

final int t_javautilcollection = 59;

final int noid = integer.max_value;

public static final int implicit_conversion_mask = 0xff;
public static final int compile_type_mask = 0xf;

// implicit conversions: <compiletype> to <runtimetype>  (note: booleans are integers at runtime)
final int boolean2int = t_boolean + (t_int << 4);
final int boolean2string = t_boolean + (t_javalangstring << 4);
final int boolean2boolean = t_boolean + (t_boolean << 4);
final int byte2byte = t_byte + (t_byte << 4);
final int byte2short = t_byte + (t_short << 4);
final int byte2char = t_byte + (t_char << 4);
final int byte2int = t_byte + (t_int << 4);
final int byte2long = t_byte + (t_long << 4);
final int byte2float = t_byte + (t_float << 4);
final int byte2double = t_byte + (t_double << 4);
final int byte2string = t_byte + (t_javalangstring << 4);
final int short2byte = t_short + (t_byte << 4);
final int short2short = t_short + (t_short << 4);
final int short2char = t_short + (t_char << 4);
final int short2int = t_short + (t_int << 4);
final int short2long = t_short + (t_long << 4);
final int short2float = t_short + (t_float << 4);
final int short2double = t_short + (t_double << 4);
final int short2string = t_short + (t_javalangstring << 4);
final int char2byte = t_char + (t_byte << 4);
final int char2short = t_char + (t_short << 4);
final int char2char = t_char + (t_char << 4);
final int char2int = t_char + (t_int << 4);
final int char2long = t_char + (t_long << 4);
final int char2float = t_char + (t_float << 4);
final int char2double = t_char + (t_double << 4);
final int char2string = t_char + (t_javalangstring << 4);
final int int2byte = t_int + (t_byte << 4);
final int int2short = t_int + (t_short << 4);
final int int2char = t_int + (t_char << 4);
final int int2int = t_int + (t_int << 4);
final int int2long = t_int + (t_long << 4);
final int int2float = t_int + (t_float << 4);
final int int2double = t_int + (t_double << 4);
final int int2string = t_int + (t_javalangstring << 4);
final int long2byte = t_long + (t_byte << 4);
final int long2short = t_long + (t_short << 4);
final int long2char = t_long + (t_char << 4);
final int long2int = t_long + (t_int << 4);
final int long2long = t_long + (t_long << 4);
final int long2float = t_long + (t_float << 4);
final int long2double = t_long + (t_double << 4);
final int long2string = t_long + (t_javalangstring << 4);
final int float2byte = t_float + (t_byte << 4);
final int float2short = t_float + (t_short << 4);
final int float2char = t_float + (t_char << 4);
final int float2int = t_float + (t_int << 4);
final int float2long = t_float + (t_long << 4);
final int float2float = t_float + (t_float << 4);
final int float2double = t_float + (t_double << 4);
final int float2string = t_float + (t_javalangstring << 4);
final int double2byte = t_double + (t_byte << 4);
final int double2short = t_double + (t_short << 4);
final int double2char = t_double + (t_char << 4);
final int double2int = t_double + (t_int << 4);
final int double2long = t_double + (t_long << 4);
final int double2float = t_double + (t_float << 4);
final int double2double = t_double + (t_double << 4);
final int double2string = t_double + (t_javalangstring << 4);
final int string2string = t_javalangstring + (t_javalangstring << 4);
final int object2string = t_javalangobject + (t_javalangstring << 4);
final int null2null = t_null + (t_null << 4);
final int null2string = t_null + (t_javalangstring << 4);
final int object2object = t_javalangobject + (t_javalangobject << 4);
final int boxing = 0x200;
final int unboxing = 0x400;
}
