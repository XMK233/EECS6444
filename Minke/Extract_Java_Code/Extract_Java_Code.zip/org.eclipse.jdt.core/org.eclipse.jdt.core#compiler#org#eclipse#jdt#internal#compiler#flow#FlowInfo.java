/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.flow;

import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;

public abstract class flowinfo {

public int tagbits; // reachable by default
public final static int reachable = 0;
public final static int unreachable = 1;
public final static int null_flag_mask = 2;

public final static int unknown = 0;
public final static int null = 1;
public final static int non_null = -1;

public static final unconditionalflowinfo dead_end; // represents a dead branch status of initialization
static {
dead_end = new unconditionalflowinfo();
dead_end.tagbits = unreachable;
}

/**
* add other inits to this flow info, then return this. the operation semantics
* are to match as closely as possible the application to this flow info of all
* the operations that resulted into otherinits.
* @@param otherinits other inits to add to this
* @@return this, modified according to otherinits information
*/
abstract public flowinfo addinitializationsfrom(flowinfo otherinits);


/**
* compose other inits over this flow info, then return this. the operation
* semantics are to wave into this flow info the consequences of a possible
* path into the operations that resulted into otherinits. the fact that this
* path may be left unexecuted under peculiar conditions results into less
* specific results than {@@link #addinitializationsfrom(flowinfo)
* addinitializationsfrom}.
* @@param otherinits other inits to compose over this
* @@return this, modified according to otherinits information
*/
abstract public flowinfo addpotentialinitializationsfrom(flowinfo otherinits);

public flowinfo asnegatedcondition() {

return this;
}

public static flowinfo conditional(flowinfo initswhentrue, flowinfo initswhenfalse){
if (initswhentrue == initswhenfalse) return initswhentrue;
// if (initswhentrue.equals(initswhenfalse)) return initswhentrue; -- could optimize if #equals is defined
return new conditionalflowinfo(initswhentrue, initswhenfalse);
}

/**
* check whether a given local variable is known to be unable to gain a definite
* non null or definite null status by the use of an enclosing flow info. the
* semantics are that if the current flow info marks the variable as potentially
* unknown or else as being both potentially null and potentially non null,
* then it won't ever be promoted as definitely null or definitely non null. (it
* could still get promoted to definite unknown).
* @@param local the variable to check
* @@return true iff this flow info prevents local from being promoted to
*         definite non null or definite null against an enclosing flow info
*/
public boolean cannotbedefinitelynullornonnull(localvariablebinding local) {
return ispotentiallyunknown(local) ||
ispotentiallynonnull(local) && ispotentiallynull(local);
}

/**
* check whether a given local variable is known to be non null, either because
* it is definitely non null, or because is has been tested against non null.
* @@param local the variable to ckeck
* @@return true iff local cannot be null for this flow info
*/
public boolean cannotbenull(localvariablebinding local) {
return isdefinitelynonnull(local) || isprotectednonnull(local);
}

/**
* check whether a given local variable is known to be null, either because it
* is definitely null, or because is has been tested against null.
* @@param local the variable to ckeck
* @@return true iff local can only be null for this flow info
*/
public boolean canonlybenull(localvariablebinding local) {
return isdefinitelynull(local) || isprotectednull(local);
}

/**
* return a deep copy of the current instance.
* @@return a deep copy of this flow info
*/
abstract public flowinfo copy();

public static unconditionalflowinfo initial(int maxfieldcount) {
unconditionalflowinfo info = new unconditionalflowinfo();
info.maxfieldcount = maxfieldcount;
return info;
}

/**
* return the flow info that would result from the path associated to the
* value false for the condition expression that generated this flow info.
* may be this flow info if it is not an instance of {@@link
* conditionalflowinfo}. may have a side effect on subparts of this flow
* info (subtrees get merged).
* @@return the flow info associated to the false branch of the condition
* 			that generated this flow info
*/
abstract public flowinfo initswhenfalse();

/**
* return the flow info that would result from the path associated to the
* value true for the condition expression that generated this flow info.
* may be this flow info if it is not an instance of {@@link
* conditionalflowinfo}. may have a side effect on subparts of this flow
* info (subtrees get merged).
* @@return the flow info associated to the true branch of the condition
* 			that generated this flow info
*/
abstract public flowinfo initswhentrue();

/**
* check status of definite assignment for a field.
*/
abstract public boolean isdefinitelyassigned(fieldbinding field);

/**
* check status of definite assignment for a local.
*/
public abstract boolean isdefinitelyassigned(localvariablebinding local);

/**
* check status of definite non-null value for a given local variable.
* @@param local the variable to ckeck
* @@return true iff local is definitely non null for this flow info
*/
public abstract boolean isdefinitelynonnull(localvariablebinding local);

/**
* check status of definite null value for a given local variable.
* @@param local the variable to ckeck
* @@return true iff local is definitely null for this flow info
*/
public abstract boolean isdefinitelynull(localvariablebinding local);

/**
* check status of definite unknown value for a given local variable.
* @@param local the variable to ckeck
* @@return true iff local is definitely unknown for this flow info
*/
public abstract boolean isdefinitelyunknown(localvariablebinding local);

/**
* check status of potential assignment for a field.
*/
abstract public boolean ispotentiallyassigned(fieldbinding field);

/**
* check status of potential assignment for a local variable.
*/

abstract public boolean ispotentiallyassigned(localvariablebinding field);

/**
* check status of potential null assignment for a local. return true if there
* is a reasonable expectation that the variable be non null at this point.
* @@param local localvariablebinding - the binding for the checked local
* @@return true if there is a reasonable expectation that local be non null at
* this point
*/
public abstract boolean ispotentiallynonnull(localvariablebinding local);

/**
* check status of potential null assignment for a local. return true if there
* is a reasonable expectation that the variable be null at this point. this
* includes the protected null case, so as to augment diagnostics, but does not
* really check that someone deliberately assigned to null on any specific
* path
* @@param local localvariablebinding - the binding for the checked local
* @@return true if there is a reasonable expectation that local be null at
* this point
*/
public abstract boolean ispotentiallynull(localvariablebinding local);

/**
* return true if the given local may have been assigned to an unknown value.
* @@param local the local to check
* @@return true if the given local may have been assigned to an unknown value
*/
public abstract boolean ispotentiallyunknown(localvariablebinding local);

/**
* return true if the given local is protected by a test against a non null
* value.
* @@param local the local to check
* @@return true if the given local is protected by a test against a non null
*/
public abstract boolean isprotectednonnull(localvariablebinding local);

/**
* return true if the given local is protected by a test against null.
* @@param local the local to check
* @@return true if the given local is protected by a test against null
*/
public abstract boolean isprotectednull(localvariablebinding local);

/**
* record that a local variable got checked to be non null.
* @@param local the checked local variable
*/
abstract public void markascomparedequaltononnull(localvariablebinding local);

/**
* record that a local variable got checked to be null.
* @@param local the checked local variable
*/
abstract public void markascomparedequaltonull(localvariablebinding local);

/**
* record a field got definitely assigned.
*/
abstract public void markasdefinitelyassigned(fieldbinding field);

/**
* record a local got definitely assigned to a non-null value.
*/
abstract public void markasdefinitelynonnull(localvariablebinding local);

/**
* record a local got definitely assigned to null.
*/
abstract public void markasdefinitelynull(localvariablebinding local);

/**
* record a local got definitely assigned.
*/
abstract public void markasdefinitelyassigned(localvariablebinding local);

/**
* record a local got definitely assigned to an unknown value.
*/
abstract public void markasdefinitelyunknown(localvariablebinding local);

/**
* merge branches using optimized boolean conditions
*/
public static unconditionalflowinfo mergedoptimizedbranches(
flowinfo initswhentrue, boolean isoptimizedtrue,
flowinfo initswhenfalse, boolean isoptimizedfalse,
boolean allowfakedeadbranch) {
unconditionalflowinfo mergedinfo;
if (isoptimizedtrue){
if (initswhentrue == flowinfo.dead_end && allowfakedeadbranch) {
mergedinfo = initswhenfalse.setreachmode(flowinfo.unreachable).
unconditionalinits();
}
else {
mergedinfo =
initswhentrue.addpotentialinitializationsfrom(initswhenfalse.
nullinfolessunconditionalcopy()).
unconditionalinits();
}
}
else if (isoptimizedfalse) {
if (initswhenfalse == flowinfo.dead_end && allowfakedeadbranch) {
mergedinfo = initswhentrue.setreachmode(flowinfo.unreachable).
unconditionalinits();
}
else {
mergedinfo =
initswhenfalse.addpotentialinitializationsfrom(initswhentrue.
nullinfolessunconditionalcopy()).
unconditionalinits();
}
}
else {
mergedinfo = initswhentrue.
mergedwith(initswhenfalse.unconditionalinits());
}
return mergedinfo;
}

/**
* merge if-else branches using optimized boolean conditions
*/
public static unconditionalflowinfo mergedoptimizedbranchesifelse(
flowinfo initswhentrue, boolean isoptimizedtrue,
flowinfo initswhenfalse, boolean isoptimizedfalse,
boolean allowfakedeadbranch, flowinfo flowinfo) {
unconditionalflowinfo mergedinfo;
if (isoptimizedtrue){
if (initswhentrue == flowinfo.dead_end && allowfakedeadbranch) {
mergedinfo = initswhenfalse.setreachmode(flowinfo.unreachable).
unconditionalinits();
}
else {
mergedinfo =
initswhentrue.addpotentialinitializationsfrom(initswhenfalse.
nullinfolessunconditionalcopy()).
unconditionalinits();
}
}
else if (isoptimizedfalse) {
if (initswhenfalse == flowinfo.dead_end && allowfakedeadbranch) {
mergedinfo = initswhentrue.setreachmode(flowinfo.unreachable).
unconditionalinits();
}
else {
mergedinfo =
initswhenfalse.addpotentialinitializationsfrom(initswhentrue.
nullinfolessunconditionalcopy()).
unconditionalinits();
}
}
else if ((flowinfo.tagbits & flowinfo.unreachable) == 0 &&
(initswhenfalse.tagbits & flowinfo.unreachable) != 0 &&
initswhentrue != flowinfo.dead_end &&
initswhenfalse != flowinfo.dead_end) {
// done when the then branch will always be executed but the condition does not have a boolean
// true or false (i.e if(true), etc) for sure
// we don't do this if both if and else branches themselves are in an unreachable code
// or if any of them is a dead_end (e.g. contains 'return' or 'throws')
mergedinfo =
initswhentrue.addpotentialinitializationsfrom(initswhenfalse.
nullinfolessunconditionalcopy()).
unconditionalinits();
// if a variable is only initialized in one branch and not initialized in the other,
// then we need to cast a doubt on its initialization in the merged info
mergedinfo.definiteinits &= initswhenfalse.unconditionalcopy().definiteinits;

}
else if ((flowinfo.tagbits & flowinfo.unreachable) == 0 &&
(initswhentrue.tagbits & flowinfo.unreachable) != 0 && initswhentrue != flowinfo.dead_end
&& initswhenfalse != flowinfo.dead_end) {
// done when the else branch will always be executed but the condition does not have a boolean
// true or false (i.e if(true), etc) for sure
// we don't do this if both if and else branches themselves are in an unreachable code
// or if any of them is a dead_end (e.g. contains 'return' or 'throws')
mergedinfo =
initswhenfalse.addpotentialinitializationsfrom(initswhentrue.
nullinfolessunconditionalcopy()).
unconditionalinits();
// if a variable is only initialized in one branch and not initialized in the other,
// then we need to cast a doubt on its initialization in the merged info
mergedinfo.definiteinits &= initswhentrue.unconditionalcopy().definiteinits;
}
else {
mergedinfo = initswhentrue.
mergedwith(initswhenfalse.unconditionalinits());
}
return mergedinfo;
}

/**
* return reachable if this flow info is reachable, unreachable
* else.
* @@return reachable if this flow info is reachable, unreachable
*         else
*/
public int reachmode() {
return this.tagbits & unreachable;
}

/**
* return a flow info that carries the same information as the result of
* {@@link #initswhentrue() initswhentrue}, but warrantied to be different
* from this.<br>
* caveat: side effects on the result may affect components of this.
* @@return the result of initswhentrue or a copy of it
*/
abstract public flowinfo safeinitswhentrue();

/**
* set this flow info reach mode and return this.
* @@param reachmode one of {@@link #reachable reachable} or {@@link #unreachable unreachable}
* @@return this, with the reach mode set to reachmode
*/
abstract public flowinfo setreachmode(int reachmode);

/**
* return the intersection of this and otherinits, that is
* one of:<ul>
*   <li>the receiver updated in the following way:<ul>
*     <li>intersection of definitely assigned variables,
*     <li>union of potentially assigned variables,
*     <li>similar operations for null,</ul>
*   <li>or the receiver or otherinits if the other one is non
*       reachable.</ul>
* otherinits is not affected, and is not returned either (no
* need to protect the result).
* @@param otherinits the flow info to merge with this
* @@return the intersection of this and otherinits.
*/
abstract public unconditionalflowinfo mergedwith(
unconditionalflowinfo otherinits);

/**
* return a copy of this unconditional flow info, deprived from its null
* info. {@@link #dead_end dead_end} is returned unmodified.
* @@return a copy of this unconditional flow info deprived from its null info
*/
abstract public unconditionalflowinfo nullinfolessunconditionalcopy();

public string tostring(){

if (this == dead_end){
return "flowinfo.dead_end"; //$non-nls-1$
}
return super.tostring();
}

/**
* return a new flow info that holds the same information as this would after
* a call to unconditionalinits, but leaving this info unaffected. moreover,
* the result can be modified without affecting this.
* @@return a new flow info carrying this unconditional flow info
*/
abstract public unconditionalflowinfo unconditionalcopy();

/**
* return a new flow info that holds the same information as this would after
* a call to {@@link #unconditionalinits() unconditionalinits} followed by the
* erasure of fields specific information, but leaving this flow info unaffected.
* @@return a new flow info carrying the unconditional flow info for local variables
*/
abstract public unconditionalflowinfo unconditionalfieldlesscopy();

/**
* return a flow info that merges the possible paths of execution described by
* this flow info. in case of an unconditional flow info, return this. in case
* of a conditional flow info, merge branches recursively. caveat: this may
* be affected, and modifying the result may affect this.
* @@return a flow info that merges the possible paths of execution described by
* 			this
*/
abstract public unconditionalflowinfo unconditionalinits();

/**
* return a new flow info that holds the same information as this would after
* a call to {@@link #unconditionalinits() unconditionalinits}, but leaving
* this info unaffected. side effects on the result might affect this though
* (consider it as read only).
* @@return a flow info carrying this unconditional flow info
*/
abstract public unconditionalflowinfo unconditionalinitswithoutsideeffect();

/**
* tell the flowinfo that a local variable got marked as non null or null
* due to comparison with null inside an assert expression.
* this is to prevent over-aggressive code generation for subsequent if statements
* where this variable is being checked against null
*/
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=303448
abstract public void markedasnullornonnullinassertexpression(localvariablebinding local);

/**
* returns true if the local variable being checked for was marked as null or not null
* inside an assert expression due to comparison against null.
*/
//https://bugs.eclipse.org/bugs/show_bug.cgi?id=303448
abstract public boolean ismarkedasnullornonnullinassertexpression(localvariablebinding local);
}
