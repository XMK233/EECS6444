/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

import org.eclipse.jdt.internal.compiler.ast.argument;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class selectiononargumentname extends argument {

public selectiononargumentname(char[] name , long posnom , typereference tr , int modifiers){

super(name, posnom, tr, modifiers);
}

public void bind(methodscope scope, typebinding typebinding, boolean used) {

super.bind(scope, typebinding, used);
throw new selectionnodefound(this.binding);
}

public stringbuffer print(int indent, stringbuffer output) {

printindent(indent, output);
output.append("<selectiononargumentname:"); //$non-nls-1$
if (this.type != null) this.type.print(0, output).append(' ');
output.append(this.name);
if (this.initialization != null) {
output.append(" = ");//$non-nls-1$
this.initialization.printexpression(0, output);
}
return output.append('>');
}

public void resolve(blockscope scope) {

super.resolve(scope);
throw new selectionnodefound(this.binding);
}
}
