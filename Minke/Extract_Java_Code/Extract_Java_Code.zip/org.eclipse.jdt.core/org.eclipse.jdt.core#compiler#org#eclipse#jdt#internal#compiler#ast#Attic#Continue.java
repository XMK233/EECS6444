/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.iabstractsyntaxtreevisitor;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class continue extends branchstatement {

public continue(char[] l, int s, int e) {

super(l, s, e);
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {

// here requires to generate a sequence of finally blocks invocations depending corresponding
// to each of the traversed try statements, so that execution will terminate properly.

// lookup the label, this should answer the returncontext
flowcontext targetcontext = (label == null)
? flowcontext.gettargetcontextfordefaultcontinue()
: flowcontext.gettargetcontextforcontinuelabel(label);

if (targetcontext == null) {
if (label == null) {
currentscope.problemreporter().invalidcontinue(this);
} else {
currentscope.problemreporter().undefinedlabel(this);
}
return flowinfo; // pretend it did not continue since no actual target
}

if (targetcontext == flowcontext.notcontinuablecontext) {
currentscope.problemreporter().invalidcontinue(this);
return flowinfo; // pretend it did not continue since no actual target
}
targetlabel = targetcontext.continuelabel();
flowcontext traversedcontext = flowcontext;
int subindex = 0, maxsub = 5;
subroutines = new astnode[maxsub];

do {
astnode sub;
if ((sub = traversedcontext.subroutine()) != null) {
if (subindex == maxsub) {
system.arraycopy(subroutines, 0, (subroutines = new astnode[maxsub*=2]), 0, subindex); // grow
}
subroutines[subindex++] = sub;
if (sub.cannotreturn()) {
break;
}
}
traversedcontext.recordreturnfrom(flowinfo.unconditionalinits());

astnode node;
if ((node = traversedcontext.associatednode) instanceof trystatement) {
trystatement trystatement = (trystatement) node;
flowinfo.addinitializationsfrom(trystatement.subroutineinits); // collect inits
} else if (traversedcontext == targetcontext) {
// only record continue info once accumulated through subroutines, and only against target context
targetcontext.recordcontinuefrom(flowinfo);
break;
}
} while ((traversedcontext = traversedcontext.parent) != null);

// resize subroutines
if (subindex != maxsub) {
system.arraycopy(subroutines, 0, (subroutines = new astnode[subindex]), 0, subindex);
}
return flowinfo.dead_end;
}

public string tostring(int tab) {

string s = tabstring(tab);
s += "continue "; //$non-nls-1$
if (label != null)
s += new string(label);
return s;
}

public void traverse(
iabstractsyntaxtreevisitor visitor,
blockscope blockscope) {

visitor.visit(this, blockscope);
visitor.endvisit(this, blockscope);
}
}
