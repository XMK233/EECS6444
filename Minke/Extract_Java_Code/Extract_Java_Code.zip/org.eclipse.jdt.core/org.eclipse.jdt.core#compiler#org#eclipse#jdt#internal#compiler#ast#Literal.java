/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public abstract class literal extends expression {

public literal(int s, int e) {

this.sourcestart = s;
this.sourceend = e;
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {

return flowinfo;
}

public abstract void computeconstant();

public abstract typebinding literaltype(blockscope scope);

public stringbuffer printexpression(int indent, stringbuffer output){

return output.append(source());
}

public typebinding resolvetype(blockscope scope) {
// compute the real value, which must range its type's range
this.resolvedtype = literaltype(scope);

// in case of error, constant did remain null
computeconstant();
if (this.constant == null) {
scope.problemreporter().constantoutofrange(this, this.resolvedtype);
this.constant = constant.notaconstant;
}
return this.resolvedtype;
}

public abstract char[] source();
}
