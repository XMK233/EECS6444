/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

/**
* this interface denotes a compilation unit, providing its name and content.
*/
public interface icompilationunit extends idependent {
/**
* answer the contents of the compilation unit.
*
* in normal use, the contents are requested twice.
* once during the initial lite parsing step, then again for the
* more detailed parsing step.
* implementors must never return null - return an empty char[] instead,
* charoperation.no_char being the candidate of choice.
*/
char[] getcontents();
/**
* answer the name of the top level public type.
* for example, {hashtable}.
*/
char[] getmaintypename();
/**
* answer the name of the package according to the directory structure
* or null if package consistency checks should be ignored.
* for example, {java, lang}.
*/
char[][] getpackagename();
}
