/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class qualifiedsuperreference extends qualifiedthisreference {

public qualifiedsuperreference(typereference name, int pos, int sourceend) {
super(name, pos, sourceend);
}

public boolean issuper() {
return true;
}

public boolean isthis() {
return false;
}

public stringbuffer printexpression(int indent, stringbuffer output) {
return this.qualification.print(0, output).append(".super"); //$non-nls-1$
}

public typebinding resolvetype(blockscope scope) {
if ((this.bits & parenthesizedmask) != 0) {
scope.problemreporter().invalidparenthesizedexpression(this);
return null;
}
super.resolvetype(scope);
if (this.currentcompatibletype == null)
return null; // error case

if (this.currentcompatibletype.id == t_javalangobject) {
scope.problemreporter().cannotusesuperinjavalangobject(this);
return null;
}
return this.resolvedtype = this.currentcompatibletype.superclass();
}

public void traverse(
astvisitor visitor,
blockscope blockscope) {

if (visitor.visit(this, blockscope)) {
this.qualification.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}
public void traverse(
astvisitor visitor,
classscope blockscope) {

if (visitor.visit(this, blockscope)) {
this.qualification.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}
}
