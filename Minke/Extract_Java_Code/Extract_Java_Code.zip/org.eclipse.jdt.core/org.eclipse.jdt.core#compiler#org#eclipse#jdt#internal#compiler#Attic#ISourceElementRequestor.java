/*******************************************************************************
* copyright (c) 2000, 2004 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

import org.eclipse.jdt.core.compiler.iproblem;

/*
* part of the source element parser responsible for building the output.
* it gets notified of structural information as they are detected, relying
* on the requestor to assemble them together, based on the notifications it got.
*
* the structural investigation includes:
* - package statement
* - import statements
* - top-level types: package member, member types (member types of member types...)
* - fields
* - methods
*
* if reference information is requested, then all source constructs are
* investigated and type, field & method references are provided as well.
*
* any (parsing) problem encountered is also provided.
*
* all positions are relative to the exact source fed to the parser.
*
* elements which are complex are notified in two steps:
* - enter<element> : once the element header has been identified
* - exit<element> : once the element has been fully consumed
*
* other simpler elements (package, import) are read all at once:
* - accept<element>
*/

public interface isourceelementrequestor {
void acceptconstructorreference(char[] typename, int argcount, int sourceposition);
void acceptfieldreference(char[] fieldname, int sourceposition);
/**
* @@param declarationstart this is the position of the first character of the
*		  				   import keyword.
* @@param declarationend this is the position of the ';' ending the import statement
*						 or the end of the comment following the import.
* @@param name this is the name of the import like specified in the source including the dots. the '.*'
*             is never included in the name.
* @@param ondemand set to true if the import is an import on demand (e.g. import java.io.*). false otherwise.
* @@param modifiers can be set to static from 1.5 on.
*/
void acceptimport(
int declarationstart,
int declarationend,
char[] name,
boolean ondemand,
int modifiers);
/*
* table of line separator position. this table is passed once at the end
* of the parse action, so as to allow computation of normalized ranges.
*
* a line separator might corresponds to several characters in the source,
*
*/
void acceptlineseparatorpositions(int[] positions);
void acceptmethodreference(char[] methodname, int argcount, int sourceposition);
void acceptpackage(
int declarationstart,
int declarationend,
char[] name);
void acceptproblem(iproblem problem);
void accepttypereference(char[][] typename, int sourcestart, int sourceend);
void accepttypereference(char[] typename, int sourceposition);
void acceptunknownreference(char[][] name, int sourcestart, int sourceend);
void acceptunknownreference(char[] name, int sourceposition);
void enterclass(
int declarationstart,
int modifiers,
char[] name,
int namesourcestart,
int namesourceend,
char[] superclass,
char[][] superinterfaces);
void entercompilationunit();
void enterconstructor(
int declarationstart,
int modifiers,
char[] name,
int namesourcestart,
int namesourceend,
char[][] parametertypes,
char[][] parameternames,
char[][] exceptiontypes);
void enterfield(
int declarationstart,
int modifiers,
char[] type,
char[] name,
int namesourcestart,
int namesourceend);
void enterinitializer(
int declarationstart,
int modifiers);
void enterinterface(
int declarationstart,
int modifiers,
char[] name,
int namesourcestart,
int namesourceend,
char[][] superinterfaces);
void entermethod(
int declarationstart,
int modifiers,
char[] returntype,
char[] name,
int namesourcestart,
int namesourceend,
char[][] parametertypes,
char[][] parameternames,
char[][] exceptiontypes);
void exitclass(int declarationend);
void exitcompilationunit(int declarationend);
void exitconstructor(int declarationend);
/*
* initializationstart denotes the source start of the expression used for initializing
* the field if any (-1 if no initialization).
*/
void exitfield(int initializationstart, int declarationend, int declarationsourceend);
void exitinitializer(int declarationend);
void exitinterface(int declarationend);
void exitmethod(int declarationend);
}
