/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.impl;

import org.eclipse.jdt.internal.compiler.env.accessrestriction;
import org.eclipse.jdt.internal.compiler.env.ibinarytype;
import org.eclipse.jdt.internal.compiler.env.icompilationunit;
import org.eclipse.jdt.internal.compiler.env.isourcetype;
import org.eclipse.jdt.internal.compiler.lookup.packagebinding;

public interface ityperequestor {

/**
* accept the resolved binary form for the requested type.
*/
void accept(ibinarytype binarytype, packagebinding packagebinding, accessrestriction accessrestriction);

/**
* accept the requested type's compilation unit.
*/
void accept(icompilationunit unit, accessrestriction accessrestriction);

/**
* accept the unresolved source forms for the requested type.
* note that the multiple source forms can be answered, in case the target compilation unit
* contains multiple types. the first one is then guaranteed to be the one corresponding to the
* requested type.
*/
void accept(isourcetype[] sourcetype, packagebinding packagebinding, accessrestriction accessrestriction);
}
