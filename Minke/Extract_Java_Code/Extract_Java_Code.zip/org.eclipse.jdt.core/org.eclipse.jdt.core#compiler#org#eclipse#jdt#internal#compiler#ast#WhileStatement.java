/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class whilestatement extends statement {

public expression condition;
public statement action;
private branchlabel breaklabel, continuelabel;
int precondinitstateindex = -1;
int condiftrueinitstateindex = -1;
int mergedinitstateindex = -1;

public whilestatement(expression condition, statement action, int s, int e) {

this.condition = condition;
this.action = action;
// remember useful empty statement
if (action instanceof emptystatement) action.bits |= isusefulemptystatement;
this.sourcestart = s;
this.sourceend = e;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {

this.breaklabel = new branchlabel();
this.continuelabel = new branchlabel();
int initialcomplaintlevel = (flowinfo.reachmode() & flowinfo.unreachable) != 0 ? statement.complained_fake_reachable : statement.not_complained;

constant cst = this.condition.constant;
boolean isconditiontrue = cst != constant.notaconstant && cst.booleanvalue() == true;
boolean isconditionfalse = cst != constant.notaconstant && cst.booleanvalue() == false;

cst = this.condition.optimizedbooleanconstant();
boolean isconditionoptimizedtrue = cst != constant.notaconstant && cst.booleanvalue() == true;
boolean isconditionoptimizedfalse = cst != constant.notaconstant && cst.booleanvalue() == false;

this.precondinitstateindex = currentscope.methodscope().recordinitializationstates(flowinfo);
loopingflowcontext condloopcontext;
flowinfo condinfo =	flowinfo.nullinfolessunconditionalcopy();

// we need to collect the contribution to nulls of the coming paths through the
// loop, be they falling through normally or branched to break, continue labels
// or catch blocks
condinfo = this.condition.analysecode(
currentscope,
(condloopcontext =
new loopingflowcontext(flowcontext, flowinfo, this, null,
null, currentscope)),
condinfo);

loopingflowcontext loopingcontext;
flowinfo actioninfo;
flowinfo exitbranch;
if (this.action == null
|| (this.action.isemptyblock() && currentscope.compileroptions().compliancelevel <= classfileconstants.jdk1_3)) {
condloopcontext.complainondeferredfinalchecks(currentscope,
condinfo);
condloopcontext.complainondeferrednullchecks(currentscope,
condinfo.unconditionalinits());
if (isconditiontrue) {
return flowinfo.dead_end;
} else {
flowinfo mergedinfo = flowinfo.copy().addinitializationsfrom(condinfo.initswhenfalse());
if (isconditionoptimizedtrue){
mergedinfo.setreachmode(flowinfo.unreachable);
}
this.mergedinitstateindex =
currentscope.methodscope().recordinitializationstates(mergedinfo);
return mergedinfo;
}
} else {
// in case the condition was inlined to false, record the fact that there is no way to reach any
// statement inside the looping action
loopingcontext =
new loopingflowcontext(
flowcontext,
flowinfo,
this,
this.breaklabel,
this.continuelabel,
currentscope);
if (isconditionfalse) {
actioninfo = flowinfo.dead_end;
} else {
actioninfo = condinfo.initswhentrue().copy();
if (isconditionoptimizedfalse){
actioninfo.setreachmode(flowinfo.unreachable);
}
}

// for computing local var attributes
this.condiftrueinitstateindex =
currentscope.methodscope().recordinitializationstates(
condinfo.initswhentrue());

if (this.action.complainifunreachable(actioninfo, currentscope, initialcomplaintlevel) < statement.complained_unreachable) {
actioninfo = this.action.analysecode(currentscope, loopingcontext, actioninfo);
}

// code generation can be optimized when no need to continue in the loop
exitbranch = flowinfo.copy();
// need to start over from flowinfo so as to get null inits

if ((actioninfo.tagbits &
loopingcontext.initsoncontinue.tagbits &
flowinfo.unreachable) != 0) {
this.continuelabel = null;
exitbranch.addinitializationsfrom(condinfo.initswhenfalse());
} else {
condloopcontext.complainondeferredfinalchecks(currentscope,
condinfo);
actioninfo = actioninfo.mergedwith(loopingcontext.initsoncontinue.unconditionalinits());
condloopcontext.complainondeferrednullchecks(currentscope,
actioninfo);
loopingcontext.complainondeferredfinalchecks(currentscope,
actioninfo);
loopingcontext.complainondeferrednullchecks(currentscope,
actioninfo);
exitbranch.
addpotentialinitializationsfrom(
actioninfo.unconditionalinits()).
addinitializationsfrom(condinfo.initswhenfalse());
}
}

// end of loop
flowinfo mergedinfo = flowinfo.mergedoptimizedbranches(
(loopingcontext.initsonbreak.tagbits &
flowinfo.unreachable) != 0 ?
loopingcontext.initsonbreak :
flowinfo.addinitializationsfrom(loopingcontext.initsonbreak), // recover upstream null info
isconditionoptimizedtrue,
exitbranch,
isconditionoptimizedfalse,
!isconditiontrue /*while(true); unreachable(); */);
this.mergedinitstateindex = currentscope.methodscope().recordinitializationstates(mergedinfo);
return mergedinfo;
}

/**
* while code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {

if ((this.bits & isreachable) == 0) {
return;
}
int pc = codestream.position;
constant cst = this.condition.optimizedbooleanconstant();
boolean isconditionoptimizedfalse = cst != constant.notaconstant && cst.booleanvalue() == false;
if (isconditionoptimizedfalse) {
this.condition.generatecode(currentscope, codestream, false);
// may loose some local variable initializations : affecting the local variable attributes
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}

this.breaklabel.initialize(codestream);

// generate condition
if (this.continuelabel == null) {
// no need to reverse condition
if (this.condition.constant == constant.notaconstant) {
this.condition.generateoptimizedboolean(
currentscope,
codestream,
null,
this.breaklabel,
true);
}
} else {
this.continuelabel.initialize(codestream);
if (!(((this.condition.constant != constant.notaconstant)
&& (this.condition.constant.booleanvalue() == true))
|| (this.action == null)
|| this.action.isemptyblock())) {
int jumppc = codestream.position;
codestream.goto_(this.continuelabel);
codestream.recordpositionsfrom(jumppc, this.condition.sourcestart);
}
}
// generate the action
branchlabel actionlabel = new branchlabel(codestream);
if (this.action != null) {
actionlabel.tagbits |= branchlabel.used;
// required to fix 1pr0xvs: lfre:winnt - compiler: variable table for method appears incorrect
if (this.condiftrueinitstateindex != -1) {
// insert all locals initialized inside the condition into the action generated prior to the condition
codestream.adddefinitelyassignedvariables(
currentscope,
this.condiftrueinitstateindex);
}
actionlabel.place();
this.action.generatecode(currentscope, codestream);
// may loose some local variable initializations : affecting the local variable attributes
if (this.precondinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.precondinitstateindex);
}
} else {
actionlabel.place();
}
// output condition and branch back to the beginning of the repeated action
if (this.continuelabel != null) {
this.continuelabel.place();
this.condition.generateoptimizedboolean(
currentscope,
codestream,
actionlabel,
null,
true);
}

// may loose some local variable initializations : affecting the local variable attributes
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
this.breaklabel.place();
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public void resolve(blockscope scope) {

typebinding type = this.condition.resolvetypeexpecting(scope, typebinding.boolean);
this.condition.computeconversion(scope, type, type);
if (this.action != null)
this.action.resolve(scope);
}

public stringbuffer printstatement(int tab, stringbuffer output) {

printindent(tab, output).append("while ("); //$non-nls-1$
this.condition.printexpression(0, output).append(')');
if (this.action == null)
output.append(';');
else
this.action.printstatement(tab + 1, output);
return output;
}

public void traverse(
astvisitor visitor,
blockscope blockscope) {

if (visitor.visit(this, blockscope)) {
this.condition.traverse(visitor, blockscope);
if (this.action != null)
this.action.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}
}
