/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.wildcard;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;

public class capturebinding extends typevariablebinding {

public typebinding lowerbound;
public wildcardbinding wildcard;
public int captureid;

/* information to compute unique binding key */
public referencebinding sourcetype;
public int position;

public capturebinding(wildcardbinding wildcard, referencebinding sourcetype, int position, int captureid) {
super(typeconstants.wildcard_capture_name_prefix, null, 0, wildcard.environment);
this.wildcard = wildcard;
this.modifiers = classfileconstants.accpublic | extracompilermodifiers.accgenericsignature; // treat capture as public
this.fpackage = wildcard.fpackage;
this.sourcetype = sourcetype;
this.position = position;
this.captureid = captureid;
}

/*
* sourcetypekey ! wildcardkey position semi-colon
* p.x { capture of ? } --> !*123; (lp/x; in declaring type except if leaf)
* p.x { capture of ? extends p.y } --> !+lp/y;123; (lp/x; in declaring type except if leaf)
*/
public char[] computeuniquekey(boolean isleaf) {
stringbuffer buffer = new stringbuffer();
if (isleaf) {
buffer.append(this.sourcetype.computeuniquekey(false/*not a leaf*/));
buffer.append('&');
}
buffer.append(typeconstants.wildcard_capture);
buffer.append(this.wildcard.computeuniquekey(false/*not a leaf*/));
buffer.append(this.position);
buffer.append(';');
int length = buffer.length();
char[] uniquekey = new char[length];
buffer.getchars(0, length, uniquekey, 0);
return uniquekey;
}

public string debugname() {

if (this.wildcard != null) {
stringbuffer buffer = new stringbuffer(10);
buffer
.append(typeconstants.wildcard_capture_name_prefix)
.append(this.captureid)
.append(typeconstants.wildcard_capture_name_suffix)
.append(this.wildcard.debugname());
return buffer.tostring();
}
return super.debugname();
}

public char[] generictypesignature() {
if (this.generictypesignature == null) {
this.generictypesignature = charoperation.concat(typeconstants.wildcard_capture, this.wildcard.generictypesignature());
}
return this.generictypesignature;
}

/**
* initialize capture bounds using substituted supertypes
* e.g. given x<u, v extends x<u, v>>,     capture(x<e,?>) = x<e,capture>, where capture extends x<e,capture>
*/
public void initializebounds(scope scope, parameterizedtypebinding capturedparameterizedtype) {
typevariablebinding wildcardvariable = this.wildcard.typevariable();
if (wildcardvariable == null) {
// error resilience when capturing zork<?>
// no substitution for wildcard bound (only formal bounds from type variables are to be substituted: 104082)
typebinding originalwildcardbound = this.wildcard.bound;
switch (this.wildcard.boundkind) {
case wildcard.extends :
// still need to capture bound supertype as well so as not to expose wildcards to the outside (111208)
typebinding capturedwildcardbound = originalwildcardbound.capture(scope, this.position);
if (originalwildcardbound.isinterface()) {
this.superclass = scope.getjavalangobject();
this.superinterfaces = new referencebinding[] { (referencebinding) capturedwildcardbound };
} else {
// the wildcard bound should be a subtype of variable superclass
// it may occur that the bound is less specific, then consider glb (202404)
if (capturedwildcardbound.isarraytype() || capturedwildcardbound == this) {
this.superclass = scope.getjavalangobject();
} else {
this.superclass = (referencebinding) capturedwildcardbound;
}
this.superinterfaces = binding.no_superinterfaces;
}
this.firstbound =  capturedwildcardbound;
if ((capturedwildcardbound.tagbits & tagbits.hastypevariable) == 0)
this.tagbits &= ~tagbits.hastypevariable;
break;
case wildcard.unbound :
this.superclass = scope.getjavalangobject();
this.superinterfaces = binding.no_superinterfaces;
this.tagbits &= ~tagbits.hastypevariable;
break;
case wildcard.super :
this.superclass = scope.getjavalangobject();
this.superinterfaces = binding.no_superinterfaces;
this.lowerbound = this.wildcard.bound;
if ((originalwildcardbound.tagbits & tagbits.hastypevariable) == 0)
this.tagbits &= ~tagbits.hastypevariable;
break;
}
return;
}
referencebinding originalvariablesuperclass = wildcardvariable.superclass;
referencebinding substitutedvariablesuperclass = (referencebinding) scope.substitute(capturedparameterizedtype, originalvariablesuperclass);
// prevent cyclic capture: given x<t>, capture(x<? extends t> could yield a circular type
if (substitutedvariablesuperclass == this) substitutedvariablesuperclass = originalvariablesuperclass;

referencebinding[] originalvariableinterfaces = wildcardvariable.superinterfaces();
referencebinding[] substitutedvariableinterfaces = scope.substitute(capturedparameterizedtype, originalvariableinterfaces);
if (substitutedvariableinterfaces != originalvariableinterfaces) {
// prevent cyclic capture: given x<t>, capture(x<? extends t> could yield a circular type
for (int i = 0, length = substitutedvariableinterfaces.length; i < length; i++) {
if (substitutedvariableinterfaces[i] == this) substitutedvariableinterfaces[i] = originalvariableinterfaces[i];
}
}
// no substitution for wildcard bound (only formal bounds from type variables are to be substituted: 104082)
typebinding originalwildcardbound = this.wildcard.bound;

switch (this.wildcard.boundkind) {
case wildcard.extends :
// still need to capture bound supertype as well so as not to expose wildcards to the outside (111208)
typebinding capturedwildcardbound = originalwildcardbound.capture(scope, this.position);
if (originalwildcardbound.isinterface()) {
this.superclass = substitutedvariablesuperclass;
// merge wildcard bound into variable superinterfaces using glb
if (substitutedvariableinterfaces == binding.no_superinterfaces) {
this.superinterfaces = new referencebinding[] { (referencebinding) capturedwildcardbound };
} else {
int length = substitutedvariableinterfaces.length;
system.arraycopy(substitutedvariableinterfaces, 0, substitutedvariableinterfaces = new referencebinding[length+1], 1, length);
substitutedvariableinterfaces[0] =  (referencebinding) capturedwildcardbound;
this.superinterfaces = scope.greaterlowerbound(substitutedvariableinterfaces);
}
} else {
// the wildcard bound should be a subtype of variable superclass
// it may occur that the bound is less specific, then consider glb (202404)
if (capturedwildcardbound.isarraytype() || capturedwildcardbound == this) {
this.superclass = substitutedvariablesuperclass;
} else {
this.superclass = (referencebinding) capturedwildcardbound;
if (this.superclass.issuperclassof(substitutedvariablesuperclass)) {
this.superclass = substitutedvariablesuperclass;
}
}
this.superinterfaces = substitutedvariableinterfaces;
}
this.firstbound =  capturedwildcardbound;
if ((capturedwildcardbound.tagbits & tagbits.hastypevariable) == 0)
this.tagbits &= ~tagbits.hastypevariable;
break;
case wildcard.unbound :
this.superclass = substitutedvariablesuperclass;
this.superinterfaces = substitutedvariableinterfaces;
this.tagbits &= ~tagbits.hastypevariable;
break;
case wildcard.super :
this.superclass = substitutedvariablesuperclass;
if (wildcardvariable.firstbound == substitutedvariablesuperclass || originalwildcardbound == substitutedvariablesuperclass) {
this.firstbound = substitutedvariablesuperclass;
}
this.superinterfaces = substitutedvariableinterfaces;
this.lowerbound = originalwildcardbound;
if ((originalwildcardbound.tagbits & tagbits.hastypevariable) == 0)
this.tagbits &= ~tagbits.hastypevariable;
break;
}
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.typebinding#iscapture()
*/
public boolean iscapture() {
return true;
}

/**
* @@see typebinding#isequivalentto(typebinding)
*/
public boolean isequivalentto(typebinding othertype) {
if (this == othertype) return true;
if (othertype == null) return false;
// capture of ? extends x[]
if (this.firstbound != null && this.firstbound.isarraytype()) {
if (this.firstbound.iscompatiblewith(othertype))
return true;
}
switch (othertype.kind()) {
case binding.wildcard_type :
case binding.intersection_type :
return ((wildcardbinding) othertype).boundcheck(this);
}
return false;
}

public char[] readablename() {
if (this.wildcard != null) {
stringbuffer buffer = new stringbuffer(10);
buffer
.append(typeconstants.wildcard_capture_name_prefix)
.append(this.captureid)
.append(typeconstants.wildcard_capture_name_suffix)
.append(this.wildcard.readablename());
int length = buffer.length();
char[] name = new char[length];
buffer.getchars(0, length, name, 0);
return name;
}
return super.readablename();
}

public char[] shortreadablename() {
if (this.wildcard != null) {
stringbuffer buffer = new stringbuffer(10);
buffer
.append(typeconstants.wildcard_capture_name_prefix)
.append(this.captureid)
.append(typeconstants.wildcard_capture_name_suffix)
.append(this.wildcard.shortreadablename());
int length = buffer.length();
char[] name = new char[length];
buffer.getchars(0, length, name, 0);
return name;
}
return super.shortreadablename();
}

public string tostring() {
if (this.wildcard != null) {
stringbuffer buffer = new stringbuffer(10);
buffer
.append(typeconstants.wildcard_capture_name_prefix)
.append(this.captureid)
.append(typeconstants.wildcard_capture_name_suffix)
.append(this.wildcard);
return buffer.tostring();
}
return super.tostring();
}
}
