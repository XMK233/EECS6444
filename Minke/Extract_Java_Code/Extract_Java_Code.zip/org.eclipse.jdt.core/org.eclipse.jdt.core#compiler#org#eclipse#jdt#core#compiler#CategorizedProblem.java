/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.core.compiler;

import org.eclipse.jdt.internal.compiler.problem.defaultproblem;

/**
* richer description of a java problem, as detected by the compiler or some of the underlying
* technology reusing the compiler. with the introduction of <code>org.eclipse.jdt.core.compiler.compilationparticipant</code>,
* the simpler problem interface {@@link iproblem} did not carry enough information to better
* separate and categorize java problems. in order to minimize impact on existing api, java problems
* are still passed around as {@@link iproblem}, though actual implementations should explicitly
* extend {@@link categorizedproblem}. participants can produce their own problem definitions,
* and given these are categorized problems, they can be better handled by clients (such as user
* interface).
* <p>
* a categorized problem provides access to:
* <ul>
* <li> its location (originating source file name, source position, line number), </li>
* <li> its message description and a predicate to check its severity (warning or error). </li>
* <li> its id : a number identifying the very nature of this problem. all possible ids for standard java
* problems are listed as constants on {@@link iproblem}, </li>
* <li> its marker type : a string identifying the problem creator. it corresponds to the marker type
* chosen if this problem was to be persisted. standard java problems are associated to marker
* type "org.eclipse.jdt.core.problem"), </li>
* <li> its category id : a number identifying the category this problem belongs to. all possible ids for
* standard java problem categories are listed in this class. </li>
* </ul>
* <p>
* note: the compiler produces iproblems internally, which are turned into markers by the javabuilder
* so as to persist problem descriptions. this explains why there is no api allowing to reach iproblem detected
* when compiling. however, the java problem markers carry equivalent information to iproblem, in particular
* their id (attribute "id") is set to one of the ids defined on this interface.
* <p>
* note: standard java problems produced by java default tooling will be subclasses of this class. technically, most
* api methods dealing with problems are referring to {@@link iproblem} for backward compatibility reason.
* it is intended that {@@link categorizedproblem} will be subclassed for custom problem implementation when
* participating in compilation operations, so as to allow participant to contribute their own marker types, and thus
* defining their own domain specific problem/category ids.
* <p>
* note: standard java problems produced by java default tooling will set the marker
* <code> imarker#source_id</code> attribute to
* <code> javabuilder#source_id</code>; compiler
* participants may specify the <code> imarker#source_id</code>
* attribute of their markers by adding it to the extra marker attributes of the problems they generate;
* markers resulting from compiler participants' problems that do not have the
* <code> imarker#source_id</code> extra attribute set do not have the
* <code> javabuilder#source_id</code> attribute set either.
*
* @@since 3.2
*/
public abstract class categorizedproblem implements iproblem {

/**
* list of standard category ids used by java problems, more categories will be added
* in the future.
*/
public static final int cat_unspecified = 0;
/** category for problems related to buildpath */
public static final int cat_buildpath = 10;
/** category for fatal problems related to syntax */
public static final int cat_syntax = 20;
/** category for fatal problems in import statements */
public static final int cat_import = 30;
/** category for fatal problems related to types, could be addressed by some type change */
public static final int cat_type = 40;
/** category for fatal problems related to type members, could be addressed by some field or method change */
public static final int cat_member = 50;
/** category for fatal problems which could not be addressed by external changes, but require an edit to be addressed */
public static final int cat_internal = 60;
/** category for optional problems in javadoc */
public static final int cat_javadoc = 70;
/** category for optional problems related to coding style practices */
public static final int cat_code_style = 80;
/** category for optional problems related to potential programming flaws */
public static final int cat_potential_programming_problem = 90;
/** category for optional problems related to naming conflicts */
public static final int cat_name_shadowing_conflict = 100;
/** category for optional problems related to deprecation */
public static final int cat_deprecation = 110;
/** category for optional problems related to unnecessary code */
public static final int cat_unnecessary_code = 120;
/** category for optional problems related to type safety in generics */
public static final int cat_unchecked_raw = 130;
/** category for optional problems related to internationalization of string literals */
public static final int cat_nls = 140;
/** category for optional problems related to access restrictions */
public static final int cat_restriction = 150;

/**
* returns an integer identifying the category of this problem. categories, like problem ids are
* defined in the context of some marker type. custom implementations of {@@link categorizedproblem}
* may choose arbitrary values for problem/category ids, as long as they are associated with a different
* marker type.
* standard java problem markers (i.e. marker type is "org.eclipse.jdt.core.problem") carry an
* attribute "categoryid" persisting the originating problem category id as defined by this method).
* @@return id - an integer identifying the category of this problem
*/
public abstract int getcategoryid();

/**
* returns the marker type associated to this problem, if it gets persisted into a marker by the javabuilder
* standard java problems are associated to marker type "org.eclipse.jdt.core.problem").
* note: problem markers are expected to extend "org.eclipse.core.resources.problemmarker" marker type.
* @@return the type of the marker which would be associated to the problem
*/
public abstract string getmarkertype();

/**
* returns the names of the extra marker attributes associated to this problem when persisted into a marker
* by the javabuilder. extra attributes are only optional, and are allowing client customization of generated
* markers. by default, no extra attributes is persisted, and a categorized problem only persists the following attributes:
* <ul>
* <li>	<code>imarker#message</code> -&gt; {@@link iproblem#getmessage()}</li>
* <li>	<code>imarker#severity</code> -&gt; <code> imarker#severity_error</code> or
*         <code>imarker#severity_warning</code> depending on {@@link iproblem#iserror()} or {@@link iproblem#iswarning()}</li>
* <li>	<code>ijavamodelmarker#id</code> -&gt; {@@link iproblem#getid()}</li>
* <li>	<code>imarker#char_start</code>  -&gt; {@@link iproblem#getsourcestart()}</li>
* <li>	<code>imarker#char_end</code>  -&gt; {@@link iproblem#getsourceend()}</li>
* <li>	<code>imarker#line_number</code>  -&gt; {@@link iproblem#getsourcelinenumber()}</li>
* <li>	<code>ijavamodelmarker#arguments</code>  -&gt; some <code>string[]</code> used to compute quickfixes </li>
* <li>	<code>ijavamodelmarker#category_id</code> -&gt; {@@link categorizedproblem#getcategoryid()}</li>
* </ul>
* the names must be eligible for marker creation, as defined by <code>imarker#setattributes(string[], object[])</code>,
* and there must be as many names as values according to {@@link #getextramarkerattributevalues()}.
* note that extra marker attributes will be inserted after default ones (as described in {@@link categorizedproblem#getmarkertype()},
* and thus could be used to override defaults.
* @@return the names of the corresponding marker attributes
*/
public string[] getextramarkerattributenames() {
return charoperation.no_strings;
}

/**
* returns the respective values for the extra marker attributes associated to this problem when persisted into
* a marker by the javabuilder. each value must correspond to a matching attribute name, as defined by
* {@@link #getextramarkerattributenames()}.
* the values must be eligible for marker creation, as defined by <code> imarker#setattributes(string[], object[])}.
* @@return the values of the corresponding extra marker attributes
*/
public object[] getextramarkerattributevalues() {
return defaultproblem.empty_values;
}
}
