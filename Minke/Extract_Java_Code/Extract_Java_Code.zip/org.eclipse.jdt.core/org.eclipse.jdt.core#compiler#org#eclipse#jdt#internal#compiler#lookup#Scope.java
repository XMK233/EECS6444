/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.util.*;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.referencecontext;
import org.eclipse.jdt.internal.compiler.problem.abortcompilation;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;
import org.eclipse.jdt.internal.compiler.util.hashtableofobject;
import org.eclipse.jdt.internal.compiler.util.objectvector;
import org.eclipse.jdt.internal.compiler.util.simpleset;

public abstract class scope {

/* scope kinds */
public final static int block_scope = 1;
public final static int class_scope = 3;
public final static int compilation_unit_scope = 4;
public final static int method_scope = 2;

/* argument compatibilities */
public final static int not_compatible = -1;
public final static int compatible = 0;
public final static int autobox_compatible = 1;
public final static int varargs_compatible = 2;

/* type compatibilities */
public static final int equal_or_more_specific = -1;
public static final int not_related = 0;
public static final int more_generic = 1;

public int kind;
public scope parent;

protected scope(int kind, scope parent) {
this.kind = kind;
this.parent = parent;
}

/* answer an int describing the relationship between the given types.
*
* 		not_related
* 		equal_or_more_specific : left is compatible with right
* 		more_generic : right is compatible with left
*/
public static int comparetypes(typebinding left, typebinding right) {
if (left.iscompatiblewith(right))
return scope.equal_or_more_specific;
if (right.iscompatiblewith(left))
return scope.more_generic;
return scope.not_related;
}

/**
* returns a type where either all variables or specific ones got discarded.
* e.g. list<e> (discarding <e extends enum<e>) will return:  list<? extends enum<?>>
*/
public static typebinding converteliminatingtypevariables(typebinding originaltype, referencebinding generictype, int rank, set eliminatedvariables) {
if ((originaltype.tagbits & tagbits.hastypevariable) != 0) {
switch (originaltype.kind()) {
case binding.array_type :
arraybinding originalarraytype = (arraybinding) originaltype;
typebinding originalleafcomponenttype = originalarraytype.leafcomponenttype;
typebinding substitute = converteliminatingtypevariables(originalleafcomponenttype, generictype, rank, eliminatedvariables); // substitute could itself be array type
if (substitute != originalleafcomponenttype) {
return originalarraytype.environment.createarraytype(substitute.leafcomponenttype(), substitute.dimensions() + originalarraytype.dimensions());
}
break;
case binding.parameterized_type :
parameterizedtypebinding paramtype = (parameterizedtypebinding) originaltype;
referencebinding originalenclosing = paramtype.enclosingtype();
referencebinding substitutedenclosing = originalenclosing;
if (originalenclosing != null) {
substitutedenclosing = (referencebinding) converteliminatingtypevariables(originalenclosing, generictype, rank, eliminatedvariables);
}
typebinding[] originalarguments = paramtype.arguments;
typebinding[] substitutedarguments = originalarguments;
for (int i = 0, length = originalarguments == null ? 0 : originalarguments.length; i < length; i++) {
typebinding originalargument = originalarguments[i];
typebinding substitutedargument = converteliminatingtypevariables(originalargument, paramtype.generictype(), i, eliminatedvariables);
if (substitutedargument != originalargument) {
if (substitutedarguments == originalarguments) {
system.arraycopy(originalarguments, 0, substitutedarguments = new typebinding[length], 0, i);
}
substitutedarguments[i] = substitutedargument;
} else 	if (substitutedarguments != originalarguments) {
substitutedarguments[i] = originalargument;
}
}
if (originalenclosing != substitutedenclosing || originalarguments != substitutedarguments) {
return paramtype.environment.createparameterizedtype(paramtype.generictype(), substitutedarguments, substitutedenclosing);
}
break;
case binding.type_parameter :
if (generictype == null) {
break;
}
typevariablebinding originalvariable = (typevariablebinding) originaltype;
if (eliminatedvariables != null && eliminatedvariables.contains(originaltype)) {
return originalvariable.environment.createwildcard(generictype, rank, null, null, wildcard.unbound);
}
typebinding originalupperbound = originalvariable.upperbound();
if (eliminatedvariables == null) {
eliminatedvariables = new hashset(2);
}
eliminatedvariables.add(originalvariable);
typebinding substitutedupperbound = converteliminatingtypevariables(originalupperbound, generictype, rank, eliminatedvariables);
eliminatedvariables.remove(originalvariable);
return originalvariable.environment.createwildcard(generictype, rank, substitutedupperbound, null, wildcard.extends);
case binding.raw_type :
break;
case binding.generic_type :
referencebinding currenttype = (referencebinding) originaltype;
originalenclosing = currenttype.enclosingtype();
substitutedenclosing = originalenclosing;
if (originalenclosing != null) {
substitutedenclosing = (referencebinding) converteliminatingtypevariables(originalenclosing, generictype, rank, eliminatedvariables);
}
originalarguments = currenttype.typevariables();
substitutedarguments = originalarguments;
for (int i = 0, length = originalarguments == null ? 0 : originalarguments.length; i < length; i++) {
typebinding originalargument = originalarguments[i];
typebinding substitutedargument = converteliminatingtypevariables(originalargument, currenttype, i, eliminatedvariables);
if (substitutedargument != originalargument) {
if (substitutedarguments == originalarguments) {
system.arraycopy(originalarguments, 0, substitutedarguments = new typebinding[length], 0, i);
}
substitutedarguments[i] = substitutedargument;
} else 	if (substitutedarguments != originalarguments) {
substitutedarguments[i] = originalargument;
}
}
if (originalenclosing != substitutedenclosing || originalarguments != substitutedarguments) {
return ((typevariablebinding)originalarguments[0]).environment.createparameterizedtype(generictype, substitutedarguments, substitutedenclosing);
}
break;
case binding.wildcard_type :
wildcardbinding wildcard = (wildcardbinding) originaltype;
typebinding originalbound = wildcard.bound;
typebinding substitutedbound = originalbound;
if (originalbound != null) {
substitutedbound = converteliminatingtypevariables(originalbound, generictype, rank, eliminatedvariables);
if (substitutedbound != originalbound) {
return wildcard.environment.createwildcard(wildcard.generictype, wildcard.rank, substitutedbound, null, wildcard.boundkind);
}
}
break;
case binding.intersection_type :
wildcardbinding intersection = (wildcardbinding) originaltype;
originalbound = intersection.bound;
substitutedbound = originalbound;
if (originalbound != null) {
substitutedbound = converteliminatingtypevariables(originalbound, generictype, rank, eliminatedvariables);
}
typebinding[] originalotherbounds = intersection.otherbounds;
typebinding[] substitutedotherbounds = originalotherbounds;
for (int i = 0, length = originalotherbounds == null ? 0 : originalotherbounds.length; i < length; i++) {
typebinding originalotherbound = originalotherbounds[i];
typebinding substitutedotherbound = converteliminatingtypevariables(originalotherbound, generictype, rank, eliminatedvariables);
if (substitutedotherbound != originalotherbound) {
if (substitutedotherbounds == originalotherbounds) {
system.arraycopy(originalotherbounds, 0, substitutedotherbounds = new typebinding[length], 0, i);
}
substitutedotherbounds[i] = substitutedotherbound;
} else 	if (substitutedotherbounds != originalotherbounds) {
substitutedotherbounds[i] = originalotherbound;
}
}
if (substitutedbound != originalbound || substitutedotherbounds != originalotherbounds) {
return intersection.environment.createwildcard(intersection.generictype, intersection.rank, substitutedbound, substitutedotherbounds, intersection.boundkind);
}
break;
}
}
return originaltype;
}

public static typebinding getbasetype(char[] name) {
// list should be optimized (with most often used first)
int length = name.length;
if (length > 2 && length < 8) {
switch (name[0]) {
case 'i' :
if (length == 3 && name[1] == 'n' && name[2] == 't')
return typebinding.int;
break;
case 'v' :
if (length == 4 && name[1] == 'o' && name[2] == 'i' && name[3] == 'd')
return typebinding.void;
break;
case 'b' :
if (length == 7
&& name[1] == 'o'
&& name[2] == 'o'
&& name[3] == 'l'
&& name[4] == 'e'
&& name[5] == 'a'
&& name[6] == 'n')
return typebinding.boolean;
if (length == 4 && name[1] == 'y' && name[2] == 't' && name[3] == 'e')
return typebinding.byte;
break;
case 'c' :
if (length == 4 && name[1] == 'h' && name[2] == 'a' && name[3] == 'r')
return typebinding.char;
break;
case 'd' :
if (length == 6
&& name[1] == 'o'
&& name[2] == 'u'
&& name[3] == 'b'
&& name[4] == 'l'
&& name[5] == 'e')
return typebinding.double;
break;
case 'f' :
if (length == 5
&& name[1] == 'l'
&& name[2] == 'o'
&& name[3] == 'a'
&& name[4] == 't')
return typebinding.float;
break;
case 'l' :
if (length == 4 && name[1] == 'o' && name[2] == 'n' && name[3] == 'g')
return typebinding.long;
break;
case 's' :
if (length == 5
&& name[1] == 'h'
&& name[2] == 'o'
&& name[3] == 'r'
&& name[4] == 't')
return typebinding.short;
}
}
return null;
}

// 5.1.10
public static referencebinding[] greaterlowerbound(referencebinding[] types) {
if (types == null) return null;
int length = types.length;
if (length == 0) return null;
referencebinding[] result = types;
int removed = 0;
for (int i = 0; i < length; i++) {
referencebinding itype = result[i];
if (itype == null) continue;
for (int j = 0; j < length; j++) {
if (i == j) continue;
referencebinding jtype = result[j];
if (jtype == null) continue;
if (itype.iscompatiblewith(jtype)) { // if vi <: vj, vj is removed
if (result == types) { // defensive copy
system.arraycopy(result, 0, result = new referencebinding[length], 0, length);
}
result[j] = null;
removed ++;
}
}
}
if (removed == 0) return result;
if (length == removed) return null;
referencebinding[] trimmedresult = new referencebinding[length - removed];
for (int i = 0, index = 0; i < length; i++) {
referencebinding itype = result[i];
if (itype != null) {
trimmedresult[index++] = itype;
}
}
return trimmedresult;
}

// 5.1.10
public static typebinding[] greaterlowerbound(typebinding[] types) {
if (types == null) return null;
int length = types.length;
if (length == 0) return null;
typebinding[] result = types;
int removed = 0;
for (int i = 0; i < length; i++) {
typebinding itype = result[i];
if (itype == null) continue;
for (int j = 0; j < length; j++) {
if (i == j) continue;
typebinding jtype = result[j];
if (jtype == null) continue;
if (itype.iscompatiblewith(jtype)) { // if vi <: vj, vj is removed
if (result == types) { // defensive copy
system.arraycopy(result, 0, result = new typebinding[length], 0, length);
}
result[j] = null;
removed ++;
}
}
}
if (removed == 0) return result;
if (length == removed) return null;
typebinding[] trimmedresult = new typebinding[length - removed];
for (int i = 0, index = 0; i < length; i++) {
typebinding itype = result[i];
if (itype != null) {
trimmedresult[index++] = itype;
}
}
return trimmedresult;
}

/**
* returns an array of types, where original types got substituted given a substitution.
* only allocate an array if anything is different.
*/
public static referencebinding[] substitute(substitution substitution, referencebinding[] originaltypes) {
if (originaltypes == null) return null;
referencebinding[] substitutedtypes = originaltypes;
for (int i = 0, length = originaltypes.length; i < length; i++) {
referencebinding originaltype = originaltypes[i];
typebinding substitutedtype = substitute(substitution, originaltype);
if (!(substitutedtype instanceof referencebinding)) {
return null; // impossible substitution
}
if (substitutedtype != originaltype) {
if (substitutedtypes == originaltypes) {
system.arraycopy(originaltypes, 0, substitutedtypes = new referencebinding[length], 0, i);
}
substitutedtypes[i] = (referencebinding)substitutedtype;
} else if (substitutedtypes != originaltypes) {
substitutedtypes[i] = originaltype;
}
}
return substitutedtypes;
}

/**
* returns a type, where original type was substituted using the receiver
* parameterized type.
* in raw mode, all parameterized type denoting same original type are converted
* to raw types. e.g.
* class x <t> {
*   x<t> foo;
*   x<string> bar;
* } when used in raw fashion, then type of both foo and bar is raw type x.
*
*/
public static typebinding substitute(substitution substitution, typebinding originaltype) {
if (originaltype == null) return null;
switch (originaltype.kind()) {

case binding.type_parameter:
return substitution.substitute((typevariablebinding) originaltype);

case binding.parameterized_type:
parameterizedtypebinding originalparameterizedtype = (parameterizedtypebinding) originaltype;
referencebinding originalenclosing = originaltype.enclosingtype();
referencebinding substitutedenclosing = originalenclosing;
if (originalenclosing != null) {
substitutedenclosing = (referencebinding) substitute(substitution, originalenclosing);
}
typebinding[] originalarguments = originalparameterizedtype.arguments;
typebinding[] substitutedarguments = originalarguments;
if (originalarguments != null) {
if (substitution.israwsubstitution()) {
return originalparameterizedtype.environment.createrawtype(originalparameterizedtype.generictype(), substitutedenclosing);
}
substitutedarguments = substitute(substitution, originalarguments);
}
if (substitutedarguments != originalarguments || substitutedenclosing != originalenclosing) {
return originalparameterizedtype.environment.createparameterizedtype(
originalparameterizedtype.generictype(), substitutedarguments, substitutedenclosing);
}
break;

case binding.array_type:
arraybinding originalarraytype = (arraybinding) originaltype;
typebinding originalleafcomponenttype = originalarraytype.leafcomponenttype;
typebinding substitute = substitute(substitution, originalleafcomponenttype); // substitute could itself be array type
if (substitute != originalleafcomponenttype) {
return originalarraytype.environment.createarraytype(substitute.leafcomponenttype(), substitute.dimensions() + originaltype.dimensions());
}
break;

case binding.wildcard_type:
case binding.intersection_type:
wildcardbinding wildcard = (wildcardbinding) originaltype;
if (wildcard.boundkind != wildcard.unbound) {
typebinding originalbound = wildcard.bound;
typebinding substitutedbound = substitute(substitution, originalbound);
typebinding[] originalotherbounds = wildcard.otherbounds;
typebinding[] substitutedotherbounds = substitute(substitution, originalotherbounds);
if (substitutedbound != originalbound || originalotherbounds != substitutedotherbounds) {
return wildcard.environment.createwildcard(wildcard.generictype, wildcard.rank, substitutedbound, substitutedotherbounds, wildcard.boundkind);
}
}
break;

case binding.type:
if (!originaltype.ismembertype()) break;
referencebinding originalreferencetype = (referencebinding) originaltype;
originalenclosing = originaltype.enclosingtype();
substitutedenclosing = originalenclosing;
if (originalenclosing != null) {
substitutedenclosing = (referencebinding) substitute(substitution, originalenclosing);
}

// treat as if parameterized with its type variables (non generic type gets 'null' arguments)
if (substitutedenclosing != originalenclosing) {
return substitution.israwsubstitution()
? substitution.environment().createrawtype(originalreferencetype, substitutedenclosing)
:  substitution.environment().createparameterizedtype(originalreferencetype, null, substitutedenclosing);
}
break;
case binding.generic_type:
originalreferencetype = (referencebinding) originaltype;
originalenclosing = originaltype.enclosingtype();
substitutedenclosing = originalenclosing;
if (originalenclosing != null) {
substitutedenclosing = (referencebinding) substitute(substitution, originalenclosing);
}

if (substitution.israwsubstitution()) {
return substitution.environment().createrawtype(originalreferencetype, substitutedenclosing);
}
// treat as if parameterized with its type variables (non generic type gets 'null' arguments)
originalarguments = originalreferencetype.typevariables();
substitutedarguments = substitute(substitution, originalarguments);
return substitution.environment().createparameterizedtype(originalreferencetype, substitutedarguments, substitutedenclosing);
}
return originaltype;
}

/**
* returns an array of types, where original types got substituted given a substitution.
* only allocate an array if anything is different.
*/
public static typebinding[] substitute(substitution substitution, typebinding[] originaltypes) {
if (originaltypes == null) return null;
typebinding[] substitutedtypes = originaltypes;
for (int i = 0, length = originaltypes.length; i < length; i++) {
typebinding originaltype = originaltypes[i];
typebinding substitutedparameter = substitute(substitution, originaltype);
if (substitutedparameter != originaltype) {
if (substitutedtypes == originaltypes) {
system.arraycopy(originaltypes, 0, substitutedtypes = new typebinding[length], 0, i);
}
substitutedtypes[i] = substitutedparameter;
} else if (substitutedtypes != originaltypes) {
substitutedtypes[i] = originaltype;
}
}
return substitutedtypes;
}

/*
* boxing primitive
*/
public typebinding boxing(typebinding type) {
if (type.isbasetype())
return environment().computeboxingtype(type);
return type;
}

public final classscope classscope() {
scope scope = this;
do {
if (scope instanceof classscope)
return (classscope) scope;
scope = scope.parent;
} while (scope != null);
return null;
}

public final compilationunitscope compilationunitscope() {
scope lastscope = null;
scope scope = this;
do {
lastscope = scope;
scope = scope.parent;
} while (scope != null);
return (compilationunitscope) lastscope;
}

/**
* finds the most specific compiler options
*/
public final compileroptions compileroptions() {

return compilationunitscope().environment.globaloptions;
}

/**
* internal use only
* given a method, returns null if arguments cannot be converted to parameters.
* will answer a subsituted method in case the method was generic and type inference got triggered;
* in case the method was originally compatible, then simply answer it back.
*/
protected final methodbinding computecompatiblemethod(methodbinding method, typebinding[] arguments, invocationsite invocationsite) {
typebinding[] generictypearguments = invocationsite.generictypearguments();
typebinding[] parameters = method.parameters;
typevariablebinding[] typevariables = method.typevariables;
if (parameters == arguments
&& (method.returntype.tagbits & tagbits.hastypevariable) == 0
&& generictypearguments == null
&& typevariables == binding.no_type_variables)
return method;

int arglength = arguments.length;
int paramlength = parameters.length;
boolean isvarargs = method.isvarargs();
if (arglength != paramlength)
if (!isvarargs || arglength < paramlength - 1)
return null; // incompatible

if (typevariables != binding.no_type_variables) { // generic method
typebinding[] newargs = null;
for (int i = 0; i < arglength; i++) {
typebinding param = i < paramlength ? parameters[i] : parameters[paramlength - 1];
if (arguments[i].isbasetype() != param.isbasetype()) {
if (newargs == null) {
newargs = new typebinding[arglength];
system.arraycopy(arguments, 0, newargs, 0, arglength);
}
newargs[i] = environment().computeboxingtype(arguments[i]);
}
}
if (newargs != null)
arguments = newargs;
method = parameterizedgenericmethodbinding.computecompatiblemethod(method, arguments, this, invocationsite);
if (method == null) return null; // incompatible
if (!method.isvalidbinding()) return method; // bound check issue is taking precedence
} else if (generictypearguments != null && compileroptions().compliancelevel < classfileconstants.jdk1_7) {
if (method instanceof parameterizedgenericmethodbinding) {
if (!((parameterizedgenericmethodbinding) method).wasinferred)
// attempt to invoke generic method of raw type with type hints <string>foo()
return new problemmethodbinding(method, method.selector, generictypearguments, problemreasons.typeargumentsforrawgenericmethod);
} else if (!method.isoverriding() || !isoverriddenmethodgeneric(method)) {
return new problemmethodbinding(method, method.selector, generictypearguments, problemreasons.typeparameteraritymismatch);
}
}

if (parametercompatibilitylevel(method, arguments) > not_compatible)
return method;
if (generictypearguments != null)
return new problemmethodbinding(method, method.selector, arguments, problemreasons.parameterizedmethodtypemismatch);
return null; // incompatible
}

/**
* connect type variable supertypes, and returns true if no problem was detected
* @@param typeparameters
* @@param checkforerasedcandidatecollisions
*/
protected boolean connecttypevariables(typeparameter[] typeparameters, boolean checkforerasedcandidatecollisions) {
if (typeparameters == null || compileroptions().sourcelevel < classfileconstants.jdk1_5) return true;
map invocations = new hashmap(2);
boolean noproblems = true;
// preinitializing each type variable
for (int i = 0, paramlength = typeparameters.length; i < paramlength; i++) {
typeparameter typeparameter = typeparameters[i];
typevariablebinding typevariable = typeparameter.binding;
if (typevariable == null) return false;

typevariable.superclass = getjavalangobject();
typevariable.superinterfaces = binding.no_superinterfaces;
// set firstbound to the binding of the first explicit bound in parameter declaration
typevariable.firstbound = null; // first bound used to compute erasure
}
nextvariable: for (int i = 0, paramlength = typeparameters.length; i < paramlength; i++) {
typeparameter typeparameter = typeparameters[i];
typevariablebinding typevariable = typeparameter.binding;
typereference typeref = typeparameter.type;
if (typeref == null)
continue nextvariable;
boolean isfirstboundtypevariable = false;
typebinding supertype = this.kind == method_scope
? typeref.resolvetype((blockscope)this, false/*no bound check*/)
: typeref.resolvetype((classscope)this);
if (supertype == null) {
typevariable.tagbits |= tagbits.hierarchyhasproblems;
} else {
typeref.resolvedtype = supertype; // hold onto the problem type
firstbound: {
switch (supertype.kind()) {
case binding.array_type :
problemreporter().boundcannotbearray(typeref, supertype);
typevariable.tagbits |= tagbits.hierarchyhasproblems;
break firstbound; // do not keep first bound
case binding.type_parameter :
isfirstboundtypevariable = true;
typevariablebinding varsupertype = (typevariablebinding) supertype;
if (varsupertype.rank >= typevariable.rank && varsupertype.declaringelement == typevariable.declaringelement) {
if (compileroptions().compliancelevel <= classfileconstants.jdk1_6) {
problemreporter().forwardtypevariablereference(typeparameter, varsupertype);
typevariable.tagbits |= tagbits.hierarchyhasproblems;
break firstbound; // do not keep first bound
}
}
break;
default :
if (((referencebinding) supertype).isfinal()) {
problemreporter().finalvariablebound(typevariable, typeref);
}
break;
}
referencebinding superreftype = (referencebinding) supertype;
if (!supertype.isinterface()) {
typevariable.superclass = superreftype;
} else {
typevariable.superinterfaces = new referencebinding[] {superreftype};
}
typevariable.tagbits |= supertype.tagbits & tagbits.containsnestedtypereferences;
typevariable.firstbound = superreftype; // first bound used to compute erasure
}
}
typereference[] boundrefs = typeparameter.bounds;
if (boundrefs != null) {
nextbound: for (int j = 0, boundlength = boundrefs.length; j < boundlength; j++) {
typeref = boundrefs[j];
supertype = this.kind == method_scope
? typeref.resolvetype((blockscope)this, false)
: typeref.resolvetype((classscope)this);
if (supertype == null) {
typevariable.tagbits |= tagbits.hierarchyhasproblems;
continue nextbound;
} else {
typevariable.tagbits |= supertype.tagbits & tagbits.containsnestedtypereferences;
boolean didalreadycomplain = !typeref.resolvedtype.isvalidbinding();
if (isfirstboundtypevariable && j == 0) {
problemreporter().noadditionalboundaftertypevariable(typeref);
typevariable.tagbits |= tagbits.hierarchyhasproblems;
didalreadycomplain = true;
//continue nextbound; - keep these bounds to minimize secondary errors
} else if (supertype.isarraytype()) {
if (!didalreadycomplain) {
problemreporter().boundcannotbearray(typeref, supertype);
typevariable.tagbits |= tagbits.hierarchyhasproblems;
}
continue nextbound;
} else {
if (!supertype.isinterface()) {
if (!didalreadycomplain) {
problemreporter().boundmustbeaninterface(typeref, supertype);
typevariable.tagbits |= tagbits.hierarchyhasproblems;
}
continue nextbound;
}
}
// check against superclass
if (checkforerasedcandidatecollisions && typevariable.firstbound == typevariable.superclass) {
if (haserasedcandidatescollisions(supertype, typevariable.superclass, invocations, typevariable, typeref)) {
continue nextbound;
}
}
// check against superinterfaces
referencebinding superreftype = (referencebinding) supertype;
for (int index = typevariable.superinterfaces.length; --index >= 0;) {
referencebinding previousinterface = typevariable.superinterfaces[index];
if (previousinterface == superreftype) {
problemreporter().duplicatebounds(typeref, supertype);
typevariable.tagbits |= tagbits.hierarchyhasproblems;
continue nextbound;
}
if (checkforerasedcandidatecollisions) {
if (haserasedcandidatescollisions(supertype, previousinterface, invocations, typevariable, typeref)) {
continue nextbound;
}
}
}
int size = typevariable.superinterfaces.length;
system.arraycopy(typevariable.superinterfaces, 0, typevariable.superinterfaces = new referencebinding[size + 1], 0, size);
typevariable.superinterfaces[size] = superreftype;
}
}
}
noproblems &= (typevariable.tagbits & tagbits.hierarchyhasproblems) == 0;
}
return noproblems;
}

public arraybinding createarraytype(typebinding type, int dimension) {
if (type.isvalidbinding())
return environment().createarraytype(type, dimension);
// do not cache obvious invalid types
return new arraybinding(type, dimension, environment());
}

public typevariablebinding[] createtypevariables(typeparameter[] typeparameters, binding declaringelement) {
// do not construct type variables if source < 1.5
if (typeparameters == null || compileroptions().sourcelevel < classfileconstants.jdk1_5)
return binding.no_type_variables;

packagebinding unitpackage = compilationunitscope().fpackage;
int length = typeparameters.length;
typevariablebinding[] typevariablebindings = new typevariablebinding[length];
int count = 0;
for (int i = 0; i < length; i++) {
typeparameter typeparameter = typeparameters[i];
typevariablebinding parameterbinding = new typevariablebinding(typeparameter.name, declaringelement, i, environment());
parameterbinding.fpackage = unitpackage;
typeparameter.binding = parameterbinding;

// detect duplicates, but keep each variable to reduce secondary errors with instantiating this generic type (assume number of variables is correct)
for (int j = 0; j < count; j++) {
typevariablebinding knownvar = typevariablebindings[j];
if (charoperation.equals(knownvar.sourcename, typeparameter.name))
problemreporter().duplicatetypeparameterintype(typeparameter);
}
typevariablebindings[count++] = parameterbinding;
//				todo should offer warnings to inform about hiding declaring, enclosing or member types
//				referencebinding type = sourcetype;
//				// check that the member does not conflict with an enclosing type
//				do {
//					if (charoperation.equals(type.sourcename, membercontext.name)) {
//						problemreporter().hidingenclosingtype(membercontext);
//						continue nextparameter;
//					}
//					type = type.enclosingtype();
//				} while (type != null);
//				// check that the member type does not conflict with another sibling member type
//				for (int j = 0; j < i; j++) {
//					if (charoperation.equals(referencecontext.membertypes[j].name, membercontext.name)) {
//						problemreporter().duplicatenestedtype(membercontext);
//						continue nextparameter;
//					}
//				}
}
if (count != length)
system.arraycopy(typevariablebindings, 0, typevariablebindings = new typevariablebinding[count], 0, count);
return typevariablebindings;
}

public final classscope enclosingclassscope() {
scope scope = this;
while ((scope = scope.parent) != null) {
if (scope instanceof classscope) return (classscope) scope;
}
return null; // may answer null if no type around
}

public final methodscope enclosingmethodscope() {
scope scope = this;
while ((scope = scope.parent) != null) {
if (scope instanceof methodscope) return (methodscope) scope;
}
return null; // may answer null if no method around
}

/* answer the scope receiver type (could be parameterized)
*/
public final referencebinding enclosingreceivertype() {
scope scope = this;
do {
if (scope instanceof classscope) {
return environment().converttoparameterizedtype(((classscope) scope).referencecontext.binding);
}
scope = scope.parent;
} while (scope != null);
return null;
}
/**
* returns the immediately enclosing reference context, starting from current scope parent.
* if starting on a class, it will skip current class. if starting on unitscope, returns null.
*/
public referencecontext enclosingreferencecontext() {
scope current = this;
while ((current = current.parent) != null) {
switch(current.kind) {
case method_scope :
return ((methodscope) current).referencecontext;
case class_scope :
return ((classscope) current).referencecontext;
case compilation_unit_scope :
return ((compilationunitscope) current).referencecontext;
}
}
return null;
}

/* answer the scope enclosing source type (could be generic)
*/
public final sourcetypebinding enclosingsourcetype() {
scope scope = this;
do {
if (scope instanceof classscope)
return ((classscope) scope).referencecontext.binding;
scope = scope.parent;
} while (scope != null);
return null;
}

public final lookupenvironment environment() {
scope scope, unitscope = this;
while ((scope = unitscope.parent) != null)
unitscope = scope;
return ((compilationunitscope) unitscope).environment;
}

// abstract method lookup lookup (since maybe missing default abstract methods)
protected methodbinding finddefaultabstractmethod(
referencebinding receivertype,
char[] selector,
typebinding[] argumenttypes,
invocationsite invocationsite,
referencebinding classhierarchystart,
objectvector found,
methodbinding concretematch) {

int startfoundsize = found.size;
referencebinding currenttype = classhierarchystart;
while (currenttype != null) {
findmethodinsuperinterfaces(currenttype, selector, found, invocationsite);
currenttype = currenttype.superclass();
}
methodbinding[] candidates = null;
int candidatescount = 0;
methodbinding problemmethod = null;
int foundsize = found.size;
if (foundsize > startfoundsize) {
// argument type compatibility check
for (int i = startfoundsize; i < foundsize; i++) {
methodbinding methodbinding = (methodbinding) found.elementat(i);
methodbinding compatiblemethod = computecompatiblemethod(methodbinding, argumenttypes, invocationsite);
if (compatiblemethod != null) {
if (compatiblemethod.isvalidbinding()) {
if (concretematch != null && environment().methodverifier().aremethodscompatible(concretematch, compatiblemethod))
continue; // can skip this method since concretematch overrides it
if (candidatescount == 0) {
candidates = new methodbinding[foundsize - startfoundsize + 1];
if (concretematch != null)
candidates[candidatescount++] = concretematch;
}
candidates[candidatescount++] = compatiblemethod;
} else if (problemmethod == null) {
problemmethod = compatiblemethod;
}
}
}
}

if (candidatescount < 2) {
if (concretematch == null) {
if (candidatescount == 0)
return problemmethod; // can be null
concretematch = candidates[0];
}
compilationunitscope().recordtypereferences(concretematch.thrownexceptions);
return concretematch;
}
// no need to check for visibility - interface methods are public
if (compileroptions().compliancelevel >= classfileconstants.jdk1_4)
return mostspecificmethodbinding(candidates, candidatescount, argumenttypes, invocationsite, receivertype);
return mostspecificinterfacemethodbinding(candidates, candidatescount, invocationsite);
}

// internal use only
public referencebinding finddirectmembertype(char[] typename, referencebinding enclosingtype) {
if ((enclosingtype.tagbits & tagbits.hasnomembertypes) != 0)
return null; // know it has no member types (nor inherited member types)

referencebinding enclosingreceivertype = enclosingreceivertype();
compilationunitscope unitscope = compilationunitscope();
unitscope.recordreference(enclosingtype, typename);
referencebinding membertype = enclosingtype.getmembertype(typename);
if (membertype != null) {
unitscope.recordtypereference(membertype);
if (enclosingreceivertype == null) {
if (membertype.canbeseenby(getcurrentpackage())) {
return membertype;
}
// maybe some type in the compilation unit is extending some class in some package
// and the selection is for some protected inner class of that superclass
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=235658
if (this instanceof compilationunitscope) {
typedeclaration[] types = ((compilationunitscope)this).referencecontext.types;
if (types != null) {
for (int i = 0, max = types.length; i < max; i++) {
if (membertype.canbeseenby(enclosingtype, types[i].binding)) {
return membertype;
}
}
}
}
} else if (membertype.canbeseenby(enclosingtype, enclosingreceivertype)) {
return membertype;
}
return new problemreferencebinding(new char[][]{typename}, membertype, problemreasons.notvisible);
}
return null;
}

// internal use only
public methodbinding findexactmethod(referencebinding receivertype, char[] selector, typebinding[] argumenttypes, invocationsite invocationsite) {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordtypereferences(argumenttypes);
methodbinding exactmethod = receivertype.getexactmethod(selector, argumenttypes, unitscope);
if (exactmethod != null && exactmethod.typevariables == binding.no_type_variables && !exactmethod.isbridge()) {
// in >= 1.5 mode, ensure the exactmatch did not match raw types
if (compileroptions().sourcelevel >= classfileconstants.jdk1_5)
for (int i = argumenttypes.length; --i >= 0;)
if (ispossiblesubtypeofrawtype(argumenttypes[i]))
return null;
// must find both methods for this case: <s extends a> void foo() {}  and  <n extends b> n foo() { return null; }
// or find an inherited method when the exact match is to a bridge method
unitscope.recordtypereferences(exactmethod.thrownexceptions);
if (exactmethod.isabstract() && exactmethod.thrownexceptions != binding.no_exceptions)
return null; // may need to merge exceptions with interface method
// special treatment for object.getclass() in 1.5 mode (substitute parameterized return type)
if (receivertype.isinterface() || exactmethod.canbeseenby(receivertype, invocationsite, this)) {
if (argumenttypes == binding.no_parameters
&& charoperation.equals(selector, typeconstants.getclass)
&& exactmethod.returntype.isparameterizedtype()/*1.5*/) {
return environment().creategetclassmethod(receivertype, exactmethod, this);
}
// targeting a generic method could find an exact match with variable return type
if (invocationsite.generictypearguments() != null) {
exactmethod = computecompatiblemethod(exactmethod, argumenttypes, invocationsite);
}
return exactmethod;
}
}
return null;
}

// internal use only
/*	answer the field binding that corresponds to fieldname.
start the lookup at the receivertype.
invocationsite implements
issuperaccess(); this is used to determine if the discovered field is visible.
only fields defined by the receivertype or its supertypes are answered;
a field of an enclosing type will not be found using this api.

if no visible field is discovered, null is answered.
*/
public fieldbinding findfield(typebinding receivertype, char[] fieldname, invocationsite invocationsite, boolean needresolve) {

compilationunitscope unitscope = compilationunitscope();
unitscope.recordtypereference(receivertype);

checkarrayfield: {
typebinding leaftype;
switch (receivertype.kind()) {
case binding.base_type :
return null;
case binding.wildcard_type :
case binding.intersection_type:
case binding.type_parameter : // capture
typebinding receivererasure = receivertype.erasure();
if (!receivererasure.isarraytype())
break checkarrayfield;
leaftype = receivererasure.leafcomponenttype();
break;
case binding.array_type :
leaftype = receivertype.leafcomponenttype();
break;
default:
break checkarrayfield;
}
if (leaftype instanceof referencebinding)
if (!((referencebinding) leaftype).canbeseenby(this))
return new problemfieldbinding((referencebinding)leaftype, fieldname, problemreasons.receivertypenotvisible);
if (charoperation.equals(fieldname, typeconstants.length)) {
if ((leaftype.tagbits & tagbits.hasmissingtype) != 0) {
return new problemfieldbinding(arraybinding.arraylength, null, fieldname, problemreasons.notfound);
}
return arraybinding.arraylength;
}
return null;
}

referencebinding currenttype = (referencebinding) receivertype;
if (!currenttype.canbeseenby(this))
return new problemfieldbinding(currenttype, fieldname, problemreasons.receivertypenotvisible);

currenttype.initializeforstaticimports();
fieldbinding field = currenttype.getfield(fieldname, needresolve);
if (field != null) {
if (invocationsite == null
? field.canbeseenby(getcurrentpackage())
: field.canbeseenby(currenttype, invocationsite, this))
return field;
return new problemfieldbinding(field /* closest match*/, field.declaringclass, fieldname, problemreasons.notvisible);
}
// collect all superinterfaces of receivertype until the field is found in a supertype
referencebinding[] interfacestovisit = null;
int nextposition = 0;
fieldbinding visiblefield = null;
boolean keeplooking = true;
fieldbinding notvisiblefield = null;
// we could hold onto the not visible field for extra error reporting
while (keeplooking) {
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
if ((currenttype = currenttype.superclass()) == null)
break;

unitscope.recordtypereference(currenttype);
currenttype.initializeforstaticimports();
currenttype = (referencebinding) currenttype.capture(this, invocationsite == null ? 0 : invocationsite.sourceend());
if ((field = currenttype.getfield(fieldname, needresolve)) != null) {
keeplooking = false;
if (field.canbeseenby(receivertype, invocationsite, this)) {
if (visiblefield == null)
visiblefield = field;
else
return new problemfieldbinding(visiblefield /* closest match*/, visiblefield.declaringclass, fieldname, problemreasons.ambiguous);
} else {
if (notvisiblefield == null)
notvisiblefield = field;
}
}
}

// walk all visible interfaces to find ambiguous references
if (interfacestovisit != null) {
problemfieldbinding ambiguous = null;
done : for (int i = 0; i < nextposition; i++) {
referencebinding aninterface = interfacestovisit[i];
unitscope.recordtypereference(aninterface);
// no need to capture rcv interface, since member field is going to be static anyway
if ((field = aninterface.getfield(fieldname, true /*resolve*/)) != null) {
if (visiblefield == null) {
visiblefield = field;
} else {
ambiguous = new problemfieldbinding(visiblefield /* closest match*/, visiblefield.declaringclass, fieldname, problemreasons.ambiguous);
break done;
}
} else {
referencebinding[] itsinterfaces = aninterface.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
if (ambiguous != null)
return ambiguous;
}

if (visiblefield != null)
return visiblefield;
if (notvisiblefield != null) {
return new problemfieldbinding(notvisiblefield, currenttype, fieldname, problemreasons.notvisible);
}
return null;
}

// internal use only
public referencebinding findmembertype(char[] typename, referencebinding enclosingtype) {
if ((enclosingtype.tagbits & tagbits.hasnomembertypes) != 0)
return null; // know it has no member types (nor inherited member types)

referencebinding enclosingsourcetype = enclosingsourcetype();
packagebinding currentpackage = getcurrentpackage();
compilationunitscope unitscope = compilationunitscope();
unitscope.recordreference(enclosingtype, typename);
referencebinding membertype = enclosingtype.getmembertype(typename);
if (membertype != null) {
unitscope.recordtypereference(membertype);
if (enclosingsourcetype == null || (this.parent == unitscope && (enclosingsourcetype.tagbits & tagbits.typevariablesareconnected) == 0)
? membertype.canbeseenby(currentpackage)
: membertype.canbeseenby(enclosingtype, enclosingsourcetype))
return membertype;
return new problemreferencebinding(new char[][]{typename}, membertype, problemreasons.notvisible);
}

// collect all superinterfaces of receivertype until the membertype is found in a supertype
referencebinding currenttype = enclosingtype;
referencebinding[] interfacestovisit = null;
int nextposition = 0;
referencebinding visiblemembertype = null;
boolean keeplooking = true;
referencebinding notvisible = null;
// we could hold onto the not visible field for extra error reporting
while (keeplooking) {
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces == null) { // needed for statically imported types which don't know their hierarchy yet
referencebinding sourcetype = currenttype.isparameterizedtype()
? ((parameterizedtypebinding) currenttype).generictype()
: currenttype;
if (sourcetype.ishierarchybeingconnected())
return null; // looking for an undefined member type in its own superclass ref
((sourcetypebinding) sourcetype).scope.connecttypehierarchy();
itsinterfaces = currenttype.superinterfaces();
}
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
if ((currenttype = currenttype.superclass()) == null)
break;

unitscope.recordreference(currenttype, typename);
if ((membertype = currenttype.getmembertype(typename)) != null) {
unitscope.recordtypereference(membertype);
keeplooking = false;
if (enclosingsourcetype == null
? membertype.canbeseenby(currentpackage)
: membertype.canbeseenby(enclosingtype, enclosingsourcetype)) {
if (visiblemembertype == null)
visiblemembertype = membertype;
else
return new problemreferencebinding(new char[][]{typename}, visiblemembertype, problemreasons.ambiguous);
} else {
notvisible = membertype;
}
}
}
// walk all visible interfaces to find ambiguous references
if (interfacestovisit != null) {
problemreferencebinding ambiguous = null;
done : for (int i = 0; i < nextposition; i++) {
referencebinding aninterface = interfacestovisit[i];
unitscope.recordreference(aninterface, typename);
if ((membertype = aninterface.getmembertype(typename)) != null) {
unitscope.recordtypereference(membertype);
if (visiblemembertype == null) {
visiblemembertype = membertype;
} else {
ambiguous = new problemreferencebinding(new char[][]{typename}, visiblemembertype, problemreasons.ambiguous);
break done;
}
} else {
referencebinding[] itsinterfaces = aninterface.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
if (ambiguous != null)
return ambiguous;
}
if (visiblemembertype != null)
return visiblemembertype;
if (notvisible != null)
return new problemreferencebinding(new char[][]{typename}, notvisible, problemreasons.notvisible);
return null;
}

// internal use only - use findmethod()
public methodbinding findmethod(referencebinding receivertype, char[] selector, typebinding[] argumenttypes, invocationsite invocationsite) {
return findmethod(receivertype, selector, argumenttypes, invocationsite, false);
}

// internal use only - use findmethod()
public methodbinding findmethod(referencebinding receivertype, char[] selector, typebinding[] argumenttypes, invocationsite invocationsite, boolean instaticcontext) {
referencebinding currenttype = receivertype;
boolean receivertypeisinterface = receivertype.isinterface();
objectvector found = new objectvector(3);
compilationunitscope unitscope = compilationunitscope();
unitscope.recordtypereferences(argumenttypes);

if (receivertypeisinterface) {
unitscope.recordtypereference(receivertype);
methodbinding[] receivermethods = receivertype.getmethods(selector, argumenttypes.length);
if (receivermethods.length > 0)
found.addall(receivermethods);
findmethodinsuperinterfaces(receivertype, selector, found, invocationsite);
currenttype = getjavalangobject();
}

// superclass lookup
long compliancelevel = compileroptions().compliancelevel;
boolean iscompliant14 = compliancelevel >= classfileconstants.jdk1_4;
boolean iscompliant15 = compliancelevel >= classfileconstants.jdk1_5;
referencebinding classhierarchystart = currenttype;
methodverifier verifier = environment().methodverifier();
while (currenttype != null) {
unitscope.recordtypereference(currenttype);
currenttype = (referencebinding) currenttype.capture(this, invocationsite == null ? 0 : invocationsite.sourceend());
methodbinding[] currentmethods = currenttype.getmethods(selector, argumenttypes.length);
int currentlength = currentmethods.length;
if (currentlength > 0) {
if (iscompliant14 && (receivertypeisinterface || found.size > 0)) {
nextmethod: for (int i = 0, l = currentlength; i < l; i++) { // currentlength can be modified inside the loop
methodbinding currentmethod = currentmethods[i];
if (currentmethod == null) continue nextmethod;
if (receivertypeisinterface && !currentmethod.ispublic()) { // only public methods from object are visible to interface receivertypes
currentlength--;
currentmethods[i] = null;
continue nextmethod;
}

// if 1.4 compliant, must filter out redundant protected methods from superclasses
// protected method need to be checked only - default access is already dealt with in #canbeseen implementation
// when checking that p.c -> q.b -> p.a cannot see default access members from a through b.
// if ((currentmethod.modifiers & accprotected) == 0) continue nextmethod;
// but we can also ignore any overridden method since we already know the better match (fixes 80028)
for (int j = 0, max = found.size; j < max; j++) {
methodbinding matchingmethod = (methodbinding) found.elementat(j);
methodbinding matchingoriginal = matchingmethod.original();
methodbinding currentoriginal = matchingoriginal.findoriginalinheritedmethod(currentmethod);
if (currentoriginal != null && verifier.isparametersubsignature(matchingoriginal, currentoriginal)) {
if (iscompliant15) {
if (matchingmethod.isbridge() && !currentmethod.isbridge())
continue nextmethod; // keep inherited methods to find concrete method over a bridge method
}
currentlength--;
currentmethods[i] = null;
continue nextmethod;
}
}
}
}

if (currentlength > 0) {
// append currentmethods, filtering out null entries
if (currentmethods.length == currentlength) {
found.addall(currentmethods);
} else {
for (int i = 0, max = currentmethods.length; i < max; i++) {
methodbinding currentmethod = currentmethods[i];
if (currentmethod != null)
found.add(currentmethod);
}
}
}
}
currenttype = currenttype.superclass();
}

// if found several candidates, then eliminate those not matching argument types
int foundsize = found.size;
methodbinding[] candidates = null;
int candidatescount = 0;
methodbinding problemmethod = null;
boolean searchfordefaultabstractmethod = iscompliant14 && ! receivertypeisinterface && (receivertype.isabstract() || receivertype.istypevariable());
if (foundsize > 0) {
// argument type compatibility check
for (int i = 0; i < foundsize; i++) {
methodbinding methodbinding = (methodbinding) found.elementat(i);
methodbinding compatiblemethod = computecompatiblemethod(methodbinding, argumenttypes, invocationsite);
if (compatiblemethod != null) {
if (compatiblemethod.isvalidbinding()) {
if (foundsize == 1 && compatiblemethod.canbeseenby(receivertype, invocationsite, this)) {
// return the single visible match now
if (searchfordefaultabstractmethod)
return finddefaultabstractmethod(receivertype, selector, argumenttypes, invocationsite, classhierarchystart, found, compatiblemethod);
unitscope.recordtypereferences(compatiblemethod.thrownexceptions);
return compatiblemethod;
}
if (candidatescount == 0)
candidates = new methodbinding[foundsize];
candidates[candidatescount++] = compatiblemethod;
} else if (problemmethod == null) {
problemmethod = compatiblemethod;
}
}
}
}

// no match was found
if (candidatescount == 0) {
if (problemmethod != null) {
switch (problemmethod.problemid()) {
case problemreasons.typeargumentsforrawgenericmethod :
case problemreasons.typeparameteraritymismatch :
return problemmethod;
}
}
// abstract classes may get a match in interfaces; for non abstract
// classes, reduces secondary errors since missing interface method
// error is already reported
methodbinding interfacemethod =
finddefaultabstractmethod(receivertype, selector, argumenttypes, invocationsite, classhierarchystart, found, null);
if (interfacemethod != null) return interfacemethod;
if (found.size == 0) return null;
if (problemmethod != null) return problemmethod;

// still no match; try to find a close match when the parameter
// order is wrong or missing some parameters

// see https://bugs.eclipse.org/bugs/show_bug.cgi?id=69471
// bad guesses are foo(), when argument types have been supplied
// and foo(x, y), when the argument types are (int, float, y)
// so answer the method with the most argtype matches and least parameter type mismatches
int bestargmatches = -1;
methodbinding bestguess = (methodbinding) found.elementat(0); // if no good match so just use the first one found
int arglength = argumenttypes.length;
foundsize = found.size;
nextmethod : for (int i = 0; i < foundsize; i++) {
methodbinding methodbinding = (methodbinding) found.elementat(i);
typebinding[] params = methodbinding.parameters;
int paramlength = params.length;
int argmatches = 0;
next: for (int a = 0; a < arglength; a++) {
typebinding arg = argumenttypes[a];
for (int p = a == 0 ? 0 : a - 1; p < paramlength && p < a + 1; p++) { // look one slot before & after to see if the type matches
if (params[p] == arg) {
argmatches++;
continue next;
}
}
}
if (argmatches < bestargmatches)
continue nextmethod;
if (argmatches == bestargmatches) {
int diff1 = paramlength < arglength ? 2 * (arglength - paramlength) : paramlength - arglength;
int bestlength = bestguess.parameters.length;
int diff2 = bestlength < arglength ? 2 * (arglength - bestlength) : bestlength - arglength;
if (diff1 >= diff2)
continue nextmethod;
}
bestargmatches = argmatches;
bestguess = methodbinding;
}
return new problemmethodbinding(bestguess, bestguess.selector, argumenttypes, problemreasons.notfound);
}

// tiebreak using visibility check
int visiblescount = 0;
if (receivertypeisinterface) {
if (candidatescount == 1) {
unitscope.recordtypereferences(candidates[0].thrownexceptions);
return candidates[0];
}
visiblescount = candidatescount;
} else {
for (int i = 0; i < candidatescount; i++) {
methodbinding methodbinding = candidates[i];
if (methodbinding.canbeseenby(receivertype, invocationsite, this)) {
if (visiblescount != i) {
candidates[i] = null;
candidates[visiblescount] = methodbinding;
}
visiblescount++;
}
}
switch (visiblescount) {
case 0 :
methodbinding interfacemethod =
finddefaultabstractmethod(receivertype, selector, argumenttypes, invocationsite, classhierarchystart, found, null);
if (interfacemethod != null) return interfacemethod;
return new problemmethodbinding(candidates[0], candidates[0].selector, candidates[0].parameters, problemreasons.notvisible);
case 1 :
if (searchfordefaultabstractmethod)
return finddefaultabstractmethod(receivertype, selector, argumenttypes, invocationsite, classhierarchystart, found, candidates[0]);
unitscope.recordtypereferences(candidates[0].thrownexceptions);
return candidates[0];
default :
break;
}
}

if (compliancelevel <= classfileconstants.jdk1_3) {
referencebinding declaringclass = candidates[0].declaringclass;
return !declaringclass.isinterface()
? mostspecificclassmethodbinding(candidates, visiblescount, invocationsite)
: mostspecificinterfacemethodbinding(candidates, visiblescount, invocationsite);
}

// check for duplicate parameterized methods
if (compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
for (int i = 0; i < visiblescount; i++) {
methodbinding candidate = candidates[i];
if (candidate instanceof parameterizedgenericmethodbinding)
candidate = ((parameterizedgenericmethodbinding) candidate).originalmethod;
if (candidate.hassubstitutedparameters()) {
for (int j = i + 1; j < visiblescount; j++) {
methodbinding othercandidate = candidates[j];
if (othercandidate.hassubstitutedparameters()) {
if (othercandidate == candidate
|| (candidate.declaringclass == othercandidate.declaringclass && candidate.areparametersequal(othercandidate))) {
return new problemmethodbinding(candidates[i], candidates[i].selector, candidates[i].parameters, problemreasons.ambiguous);
}
}
}
}
}
}
if (instaticcontext) {
methodbinding[] staticcandidates = new methodbinding[visiblescount];
int staticcount = 0;
for (int i = 0; i < visiblescount; i++)
if (candidates[i].isstatic())
staticcandidates[staticcount++] = candidates[i];
if (staticcount == 1)
return staticcandidates[0];
if (staticcount > 1)
return mostspecificmethodbinding(staticcandidates, staticcount, argumenttypes, invocationsite, receivertype);
}

methodbinding mostspecificmethod = mostspecificmethodbinding(candidates, visiblescount, argumenttypes, invocationsite, receivertype);
if (searchfordefaultabstractmethod) { // search interfaces for a better match
if (mostspecificmethod.isvalidbinding())
// see if there is a better match in the interfaces - see autoboxingtest 99, lookuptest#81
return finddefaultabstractmethod(receivertype, selector, argumenttypes, invocationsite, classhierarchystart, found, mostspecificmethod);
// see if there is a match in the interfaces - see lookuptest#84
methodbinding interfacemethod = finddefaultabstractmethod(receivertype, selector, argumenttypes, invocationsite, classhierarchystart, found, null);
if (interfacemethod != null && interfacemethod.isvalidbinding() /* else return the same error as before */)
return interfacemethod;
}
return mostspecificmethod;
}

// internal use only
public methodbinding findmethodforarray(
arraybinding receivertype,
char[] selector,
typebinding[] argumenttypes,
invocationsite invocationsite) {

typebinding leaftype = receivertype.leafcomponenttype();
if (leaftype instanceof referencebinding) {
if (!((referencebinding) leaftype).canbeseenby(this))
return new problemmethodbinding(selector, binding.no_parameters, (referencebinding)leaftype, problemreasons.receivertypenotvisible);
}

referencebinding object = getjavalangobject();
methodbinding methodbinding = object.getexactmethod(selector, argumenttypes, null);
if (methodbinding != null) {
// handle the method clone() specially... cannot be protected or throw exceptions
if (argumenttypes == binding.no_parameters) {
switch (selector[0]) {
case 'c':
if (charoperation.equals(selector, typeconstants.clone)) {
return environment().computearrayclone(methodbinding);
}
break;
case 'g':
if (charoperation.equals(selector, typeconstants.getclass) && methodbinding.returntype.isparameterizedtype()/*1.5*/) {
return environment().creategetclassmethod(receivertype, methodbinding, this);
}
break;
}
}
if (methodbinding.canbeseenby(receivertype, invocationsite, this))
return methodbinding;
}
methodbinding = findmethod(object, selector, argumenttypes, invocationsite);
if (methodbinding == null)
return new problemmethodbinding(selector, argumenttypes, problemreasons.notfound);
return methodbinding;
}

protected void findmethodinsuperinterfaces(referencebinding currenttype, char[] selector, objectvector found, invocationsite invocationsite) {
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
referencebinding[] interfacestovisit = itsinterfaces;
int nextposition = interfacestovisit.length;
for (int i = 0; i < nextposition; i++) {
currenttype = interfacestovisit[i];
compilationunitscope().recordtypereference(currenttype);
currenttype = (referencebinding) currenttype.capture(this, invocationsite == null ? 0 : invocationsite.sourceend());
methodbinding[] currentmethods = currenttype.getmethods(selector);
if (currentmethods.length > 0) {
int foundsize = found.size;
if (foundsize > 0) {
// its possible to walk the same superinterface from different classes in the hierarchy
next : for (int c = 0, l = currentmethods.length; c < l; c++) {
methodbinding current = currentmethods[c];
for (int f = 0; f < foundsize; f++)
if (current == found.elementat(f)) continue next;
found.add(current);
}
} else {
found.addall(currentmethods);
}
}
if ((itsinterfaces = currenttype.superinterfaces()) != null && itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
}

// internal use only
public referencebinding findtype(
char[] typename,
packagebinding declarationpackage,
packagebinding invocationpackage) {

compilationunitscope().recordreference(declarationpackage.compoundname, typename);
referencebinding typebinding = declarationpackage.gettype(typename);
if (typebinding == null)
return null;

if (typebinding.isvalidbinding()) {
if (declarationpackage != invocationpackage && !typebinding.canbeseenby(invocationpackage))
return new problemreferencebinding(new char[][]{typename}, typebinding, problemreasons.notvisible);
}
return typebinding;
}

public localvariablebinding findvariable(char[] variable) {

return null;
}

/* api
*
*	answer the binding that corresponds to the argument name.
*	flag is a mask of the following values variable (= field or local), type, package.
*	only bindings corresponding to the mask can be answered.
*
*	for example, getbinding("foo", variable, site) will answer
*	the binding for the field or local named "foo" (or an error binding if none exists).
*	if a type named "foo" exists, it will not be detected (and an error binding will be answered)
*
*	the variable mask has precedence over the type mask.
*
*	if the variable mask is not set, neither fields nor locals will be looked for.
*
*	invocationsite implements:
*		issuperaccess(); this is used to determine if the discovered field is visible.
*
*	limitations: cannot request field independently of local, or vice versa
*/
public binding getbinding(char[] name, int mask, invocationsite invocationsite, boolean needresolve) {
compilationunitscope unitscope = compilationunitscope();
lookupenvironment env = unitscope.environment;
try {
env.missingclassfilelocation = invocationsite;
binding binding = null;
fieldbinding problemfield = null;
if ((mask & binding.variable) != 0) {
boolean insidestaticcontext = false;
boolean insideconstructorcall = false;
boolean insidetypeannotation = false;

fieldbinding foundfield = null;
// can be a problem field which is answered if a valid field is not found
problemfieldbinding foundinsideproblem = null;
// inside constructor call or inside static context
scope scope = this;
int depth = 0;
int founddepth = 0;
referencebinding foundactualreceivertype = null;
done : while (true) { // done when a compilation_unit_scope is found
switch (scope.kind) {
case method_scope :
methodscope methodscope = (methodscope) scope;
insidestaticcontext |= methodscope.isstatic;
insideconstructorcall |= methodscope.isconstructorcall;
insidetypeannotation = methodscope.insidetypeannotation;

//$fall-through$ could duplicate the code below to save a cast - questionable optimization
case block_scope :
localvariablebinding variablebinding = scope.findvariable(name);
// looks in this scope only
if (variablebinding != null) {
if (foundfield != null && foundfield.isvalidbinding())
return new problemfieldbinding(
foundfield, // closest match
foundfield.declaringclass,
name,
problemreasons.inheritednamehidesenclosingname);
if (depth > 0)
invocationsite.setdepth(depth);
return variablebinding;
}
break;
case class_scope :
classscope classscope = (classscope) scope;
referencebinding receivertype = classscope.enclosingreceivertype();
if (!insidetypeannotation) {
fieldbinding fieldbinding = classscope.findfield(receivertype, name, invocationsite, needresolve);
// use next line instead if willing to enable protected access accross inner types
// fieldbinding fieldbinding = findfield(enclosingtype, name, invocationsite);

if (fieldbinding != null) { // skip it if we did not find anything
if (fieldbinding.problemid() == problemreasons.ambiguous) {
if (foundfield == null || foundfield.problemid() == problemreasons.notvisible)
// supercedes any potential inheritednamehidesenclosingname problem
return fieldbinding;
// make the user qualify the field, likely wants the first inherited field (javac generates an ambiguous error instead)
return new problemfieldbinding(
foundfield, // closest match
foundfield.declaringclass,
name,
problemreasons.inheritednamehidesenclosingname);
}

problemfieldbinding insideproblem = null;
if (fieldbinding.isvalidbinding()) {
if (!fieldbinding.isstatic()) {
if (insideconstructorcall) {
insideproblem =
new problemfieldbinding(
fieldbinding, // closest match
fieldbinding.declaringclass,
name,
problemreasons.nonstaticreferenceinconstructorinvocation);
} else if (insidestaticcontext) {
insideproblem =
new problemfieldbinding(
fieldbinding, // closest match
fieldbinding.declaringclass,
name,
problemreasons.nonstaticreferenceinstaticcontext);
}
}
if (receivertype == fieldbinding.declaringclass || compileroptions().compliancelevel >= classfileconstants.jdk1_4) {
// found a valid field in the 'immediate' scope (i.e. not inherited)
// or in 1.4 mode (inherited shadows enclosing)
if (foundfield == null) {
if (depth > 0){
invocationsite.setdepth(depth);
invocationsite.setactualreceivertype(receivertype);
}
// return the fieldbinding if it is not declared in a superclass of the scope's binding (that is, inherited)
return insideproblem == null ? fieldbinding : insideproblem;
}
if (foundfield.isvalidbinding())
// if a valid field was found, complain when another is found in an 'immediate' enclosing type (that is, not inherited)
if (foundfield.declaringclass != fieldbinding.declaringclass)
// i.e. have we found the same field - do not trust field identity yet
return new problemfieldbinding(
foundfield, // closest match
foundfield.declaringclass,
name,
problemreasons.inheritednamehidesenclosingname);
}
}

if (foundfield == null || (foundfield.problemid() == problemreasons.notvisible && fieldbinding.problemid() != problemreasons.notvisible)) {
// only remember the fieldbinding if its the first one found or the previous one was not visible & fieldbinding is...
founddepth = depth;
foundactualreceivertype = receivertype;
foundinsideproblem = insideproblem;
foundfield = fieldbinding;
}
}
}
insidetypeannotation = false;
depth++;
insidestaticcontext |= receivertype.isstatic();
// 1ex5i8z - accessing outer fields within a constructor call is permitted
// in order to do so, we change the flag as we exit from the type, not the method
// itself, because the class scope is used to retrieve the fields.
methodscope enclosingmethodscope = scope.methodscope();
insideconstructorcall = enclosingmethodscope == null ? false : enclosingmethodscope.isconstructorcall;
break;
case compilation_unit_scope :
break done;
}
scope = scope.parent;
}

if (foundinsideproblem != null)
return foundinsideproblem;
if (foundfield != null) {
if (foundfield.isvalidbinding()) {
if (founddepth > 0) {
invocationsite.setdepth(founddepth);
invocationsite.setactualreceivertype(foundactualreceivertype);
}
return foundfield;
}
problemfield = foundfield;
foundfield = null;
}

if (compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
// at this point the scope is a compilation unit scope & need to check for imported static fields
unitscope.faultinimports(); // ensure static imports are resolved
importbinding[] imports = unitscope.imports;
if (imports != null) {
// check single static imports
for (int i = 0, length = imports.length; i < length; i++) {
importbinding importbinding = imports[i];
if (importbinding.isstatic() && !importbinding.ondemand) {
if (charoperation.equals(importbinding.compoundname[importbinding.compoundname.length - 1], name)) {
if (unitscope.resolvesingleimport(importbinding, binding.type | binding.field | binding.method) != null && importbinding.resolvedimport instanceof fieldbinding) {
foundfield = (fieldbinding) importbinding.resolvedimport;
importreference importreference = importbinding.reference;
if (importreference != null && needresolve) {
importreference.bits |= astnode.used;
}
invocationsite.setactualreceivertype(foundfield.declaringclass);
if (foundfield.isvalidbinding()) {
return foundfield;
}
if (problemfield == null)
problemfield = foundfield;
}
}
}
}
// check on demand imports
boolean foundinimport = false;
for (int i = 0, length = imports.length; i < length; i++) {
importbinding importbinding = imports[i];
if (importbinding.isstatic() && importbinding.ondemand) {
binding resolvedimport = importbinding.resolvedimport;
if (resolvedimport instanceof referencebinding) {
fieldbinding temp = findfield((referencebinding) resolvedimport, name, invocationsite, needresolve);
if (temp != null) {
if (!temp.isvalidbinding()) {
if (problemfield == null)
problemfield = temp;
} else if (temp.isstatic()) {
if (foundfield == temp) continue;
importreference importreference = importbinding.reference;
if (importreference != null && needresolve) {
importreference.bits |= astnode.used;
}
if (foundinimport)
// answer error binding -- import on demand conflict; name found in two import on demand packages.
return new problemfieldbinding(
foundfield, // closest match
foundfield.declaringclass,
name,
problemreasons.ambiguous);
foundfield = temp;
foundinimport = true;
}
}
}
}
}
if (foundfield != null) {
invocationsite.setactualreceivertype(foundfield.declaringclass);
return foundfield;
}
}
}
}

// we did not find a local or instance variable.
if ((mask & binding.type) != 0) {
if ((binding = getbasetype(name)) != null)
return binding;
binding = gettypeorpackage(name, (mask & binding.package) == 0 ? binding.type : binding.type | binding.package, needresolve);
if (binding.isvalidbinding() || mask == binding.type)
return binding;
// answer the problem type binding if we are only looking for a type
} else if ((mask & binding.package) != 0) {
unitscope.recordsimplereference(name);
if ((binding = env.gettoplevelpackage(name)) != null)
return binding;
}
if (problemfield != null) return problemfield;
if (binding != null && binding.problemid() != problemreasons.notfound)
return binding; // answer the better problem binding
return new problembinding(name, enclosingsourcetype(), problemreasons.notfound);
} catch (abortcompilation e) {
e.updatecontext(invocationsite, referencecompilationunit().compilationresult);
throw e;
} finally {
env.missingclassfilelocation = null;
}
}

public methodbinding getconstructor(referencebinding receivertype, typebinding[] argumenttypes, invocationsite invocationsite) {
compilationunitscope unitscope = compilationunitscope();
lookupenvironment env = unitscope.environment;
try {
env.missingclassfilelocation = invocationsite;
unitscope.recordtypereference(receivertype);
unitscope.recordtypereferences(argumenttypes);
methodbinding methodbinding = receivertype.getexactconstructor(argumenttypes);
if (methodbinding != null && methodbinding.canbeseenby(invocationsite, this)) {
// targeting a non generic constructor with type arguments ?
if (invocationsite.generictypearguments() != null)
methodbinding = computecompatiblemethod(methodbinding, argumenttypes, invocationsite);
return methodbinding;
}
methodbinding[] methods = receivertype.getmethods(typeconstants.init, argumenttypes.length);
if (methods == binding.no_methods)
return new problemmethodbinding(
typeconstants.init,
argumenttypes,
problemreasons.notfound);

methodbinding[] compatible = new methodbinding[methods.length];
int compatibleindex = 0;
methodbinding problemmethod = null;
for (int i = 0, length = methods.length; i < length; i++) {
methodbinding compatiblemethod = computecompatiblemethod(methods[i], argumenttypes, invocationsite);
if (compatiblemethod != null) {
if (compatiblemethod.isvalidbinding())
compatible[compatibleindex++] = compatiblemethod;
else if (problemmethod == null)
problemmethod = compatiblemethod;
}
}
if (compatibleindex == 0) {
if (problemmethod == null)
return new problemmethodbinding(methods[0], typeconstants.init, argumenttypes, problemreasons.notfound);
return problemmethod;
}
// need a more descriptive error... cannot convert from x to y

methodbinding[] visible = new methodbinding[compatibleindex];
int visibleindex = 0;
for (int i = 0; i < compatibleindex; i++) {
methodbinding method = compatible[i];
if (method.canbeseenby(invocationsite, this))
visible[visibleindex++] = method;
}
if (visibleindex == 1) return visible[0];
if (visibleindex == 0)
return new problemmethodbinding(
compatible[0],
typeconstants.init,
compatible[0].parameters,
problemreasons.notvisible);
// all of visible are from the same declaringclass, even before 1.4 we can call this method instead of mostspecificclassmethodbinding
return mostspecificmethodbinding(visible, visibleindex, argumenttypes, invocationsite, receivertype);
} catch (abortcompilation e) {
e.updatecontext(invocationsite, referencecompilationunit().compilationresult);
throw e;
} finally {
env.missingclassfilelocation = null;
}
}

public final packagebinding getcurrentpackage() {
scope scope, unitscope = this;
while ((scope = unitscope.parent) != null)
unitscope = scope;
return ((compilationunitscope) unitscope).fpackage;
}

/**
* returns the modifiers of the innermost enclosing declaration.
* @@return modifiers
*/
public int getdeclarationmodifiers(){
switch(this.kind){
case scope.block_scope :
case scope.method_scope :
methodscope methodscope = methodscope();
if (!methodscope.isinsideinitializer()){
// check method modifiers to see if deprecated
methodbinding context = ((abstractmethoddeclaration)methodscope.referencecontext).binding;
if (context != null)
return context.modifiers;
} else {
sourcetypebinding type = ((blockscope) this).referencetype().binding;

// inside field declaration ? check field modifier to see if deprecated
if (methodscope.initializedfield != null)
return methodscope.initializedfield.modifiers;
if (type != null)
return type.modifiers;
}
break;
case scope.class_scope :
referencebinding context = ((classscope)this).referencetype().binding;
if (context != null)
return context.modifiers;
break;
}
return -1;
}

public fieldbinding getfield(typebinding receivertype, char[] fieldname, invocationsite invocationsite) {
lookupenvironment env = environment();
try {
env.missingclassfilelocation = invocationsite;
fieldbinding field = findfield(receivertype, fieldname, invocationsite, true /*resolve*/);
if (field != null) return field;

return new problemfieldbinding(
receivertype instanceof referencebinding ? (referencebinding) receivertype : null,
fieldname,
problemreasons.notfound);
} catch (abortcompilation e) {
e.updatecontext(invocationsite, referencecompilationunit().compilationresult);
throw e;
} finally {
env.missingclassfilelocation = null;
}
}

/* api
*
*	answer the method binding that corresponds to selector, argumenttypes.
*	start the lookup at the enclosing type of the receiver.
*	invocationsite implements
*		issuperaccess(); this is used to determine if the discovered method is visible.
*		setdepth(int); this is used to record the depth of the discovered method
*			relative to the enclosing type of the receiver. (if the method is defined
*			in the enclosing type of the receiver, the depth is 0; in the next enclosing
*			type, the depth is 1; and so on
*
*	if no visible method is discovered, an error binding is answered.
*/
public methodbinding getimplicitmethod(char[] selector, typebinding[] argumenttypes, invocationsite invocationsite) {

boolean insidestaticcontext = false;
boolean insideconstructorcall = false;
boolean insidetypeannotation = false;
methodbinding foundmethod = null;
methodbinding foundproblem = null;
boolean foundproblemvisible = false;
scope scope = this;
int depth = 0;
// in 1.4 mode (inherited visible shadows enclosing)
compileroptions options;
boolean inheritedhasprecedence = (options = compileroptions()).compliancelevel >= classfileconstants.jdk1_4;

done : while (true) { // done when a compilation_unit_scope is found
switch (scope.kind) {
case method_scope :
methodscope methodscope = (methodscope) scope;
insidestaticcontext |= methodscope.isstatic;
insideconstructorcall |= methodscope.isconstructorcall;
insidetypeannotation = methodscope.insidetypeannotation;
break;
case class_scope :
classscope classscope = (classscope) scope;
referencebinding receivertype = classscope.enclosingreceivertype();
if (!insidetypeannotation) {
// retrieve an exact visible match (if possible)
// compilationunitscope().recordtypereference(receivertype);   not needed since receiver is the source type
methodbinding methodbinding = classscope.findexactmethod(receivertype, selector, argumenttypes, invocationsite);
if (methodbinding == null)
methodbinding = classscope.findmethod(receivertype, selector, argumenttypes, invocationsite);
if (methodbinding != null) { // skip it if we did not find anything
if (foundmethod == null) {
if (methodbinding.isvalidbinding()) {
if (!methodbinding.isstatic() && (insideconstructorcall || insidestaticcontext)) {
if (foundproblem != null && foundproblem.problemid() != problemreasons.notvisible)
return foundproblem; // takes precedence
return new problemmethodbinding(
methodbinding, // closest match
methodbinding.selector,
methodbinding.parameters,
insideconstructorcall
? problemreasons.nonstaticreferenceinconstructorinvocation
: problemreasons.nonstaticreferenceinstaticcontext);
}
if (inheritedhasprecedence
|| receivertype == methodbinding.declaringclass
|| (receivertype.getmethods(selector)) != binding.no_methods) {
// found a valid method in the 'immediate' scope (i.e. not inherited)
// or in 1.4 mode (inherited visible shadows enclosing)
// or the receivertype implemented a method with the correct name
// return the methodbinding if it is not declared in a superclass of the scope's binding (that is, inherited)
if (foundproblemvisible) {
return foundproblem;
}
if (depth > 0) {
invocationsite.setdepth(depth);
invocationsite.setactualreceivertype(receivertype);
}
// special treatment for object.getclass() in 1.5 mode (substitute parameterized return type)
if (argumenttypes == binding.no_parameters
&& charoperation.equals(selector, typeconstants.getclass)
&& methodbinding.returntype.isparameterizedtype()/*1.5*/) {
return environment().creategetclassmethod(receivertype, methodbinding, this);
}
return methodbinding;
}

if (foundproblem == null || foundproblem.problemid() == problemreasons.notvisible) {
if (foundproblem != null) foundproblem = null;
// only remember the methodbinding if its the first one found
// remember that private methods are visible if defined directly by an enclosing class
if (depth > 0) {
invocationsite.setdepth(depth);
invocationsite.setactualreceivertype(receivertype);
}
foundmethod = methodbinding;
}
} else { // methodbinding is a problem method
if (methodbinding.problemid() != problemreasons.notvisible && methodbinding.problemid() != problemreasons.notfound)
return methodbinding; // return the error now
if (foundproblem == null) {
foundproblem = methodbinding; // hold onto the first not visible/found error and keep the second not found if first is not visible
}
if (! foundproblemvisible && methodbinding.problemid() == problemreasons.notfound) {
methodbinding closestmatch = ((problemmethodbinding) methodbinding).closestmatch;
if (closestmatch != null && closestmatch.canbeseenby(receivertype, invocationsite, this)) {
foundproblem = methodbinding; // hold onto the first not visible/found error and keep the second not found if first is not visible
foundproblemvisible = true;
}
}
}
} else { // found a valid method so check to see if this is a hiding case
if (methodbinding.problemid() == problemreasons.ambiguous
|| (foundmethod.declaringclass != methodbinding.declaringclass
&& (receivertype == methodbinding.declaringclass || receivertype.getmethods(selector) != binding.no_methods)))
// ambiguous case -> must qualify the method (javac generates an ambiguous error instead)
// otherwise if a method was found, complain when another is found in an 'immediate' enclosing type (that is, not inherited)
// note: unlike fields, a non visible method hides a visible method
return new problemmethodbinding(
methodbinding, // closest match
selector,
argumenttypes,
problemreasons.inheritednamehidesenclosingname);
}
}
}
insidetypeannotation = false;
depth++;
insidestaticcontext |= receivertype.isstatic();
// 1ex5i8z - accessing outer fields within a constructor call is permitted
// in order to do so, we change the flag as we exit from the type, not the method
// itself, because the class scope is used to retrieve the fields.
methodscope enclosingmethodscope = scope.methodscope();
insideconstructorcall = enclosingmethodscope == null ? false : enclosingmethodscope.isconstructorcall;
break;
case compilation_unit_scope :
break done;
}
scope = scope.parent;
}

if (insidestaticcontext && options.sourcelevel >= classfileconstants.jdk1_5) {
if (foundproblem != null) {
if (foundproblem.declaringclass != null && foundproblem.declaringclass.id == typeids.t_javalangobject)
return foundproblem; // static imports lose to methods from object
if (foundproblem.problemid() == problemreasons.notfound && foundproblemvisible) {
return foundproblem; // visible method selectors take precedence
}
}

// at this point the scope is a compilation unit scope & need to check for imported static methods
compilationunitscope unitscope = (compilationunitscope) scope;
unitscope.faultinimports(); // field constants can cause static imports to be accessed before they're resolved
importbinding[] imports = unitscope.imports;
if (imports != null) {
objectvector visible = null;
boolean skipondemand = false; // set to true when matched static import of method name so stop looking for on demand methods
for (int i = 0, length = imports.length; i < length; i++) {
importbinding importbinding = imports[i];
if (importbinding.isstatic()) {
binding resolvedimport = importbinding.resolvedimport;
methodbinding possible = null;
if (importbinding.ondemand) {
if (!skipondemand && resolvedimport instanceof referencebinding)
// answers closest approximation, may not check argumenttypes or visibility
possible = findmethod((referencebinding) resolvedimport, selector, argumenttypes, invocationsite, true);
} else {
if (resolvedimport instanceof methodbinding) {
methodbinding staticmethod = (methodbinding) resolvedimport;
if (charoperation.equals(staticmethod.selector, selector))
// answers closest approximation, may not check argumenttypes or visibility
possible = findmethod(staticmethod.declaringclass, selector, argumenttypes, invocationsite, true);
} else if (resolvedimport instanceof fieldbinding) {
// check to see if there are also methods with the same name
fieldbinding staticfield = (fieldbinding) resolvedimport;
if (charoperation.equals(staticfield.name, selector)) {
// must find the importref's type again since the field can be from an inherited type
char[][] importname = importbinding.reference.tokens;
typebinding referencedtype = gettype(importname, importname.length - 1);
if (referencedtype != null)
// answers closest approximation, may not check argumenttypes or visibility
possible = findmethod((referencebinding) referencedtype, selector, argumenttypes, invocationsite, true);
}
}
}
if (possible != null && possible != foundproblem) {
if (!possible.isvalidbinding()) {
if (foundproblem == null)
foundproblem = possible; // answer as error case match
} else if (possible.isstatic()) {
methodbinding compatiblemethod = computecompatiblemethod(possible, argumenttypes, invocationsite);
if (compatiblemethod != null) {
if (compatiblemethod.isvalidbinding()) {
if (compatiblemethod.canbeseenby(unitscope.fpackage)) {
if (visible == null || !visible.contains(compatiblemethod)) {
importreference importreference = importbinding.reference;
if (importreference != null) {
importreference.bits |= astnode.used;
}
if (!skipondemand && !importbinding.ondemand) {
visible = null; // forget previous matches from on demand imports
skipondemand = true;
}
if (visible == null)
visible = new objectvector(3);
visible.add(compatiblemethod);
}
} else if (foundproblem == null) {
foundproblem = new problemmethodbinding(compatiblemethod, selector, compatiblemethod.parameters, problemreasons.notvisible);
}
} else if (foundproblem == null) {
foundproblem = compatiblemethod;
}
} else if (foundproblem == null) {
foundproblem = new problemmethodbinding(possible, selector, argumenttypes, problemreasons.notfound);
}
}
}
}
}
if (visible != null) {
methodbinding[] temp = new methodbinding[visible.size];
visible.copyinto(temp);
foundmethod = mostspecificmethodbinding(temp, temp.length, argumenttypes, invocationsite, null);
}
}
}

if (foundmethod != null) {
invocationsite.setactualreceivertype(foundmethod.declaringclass);
return foundmethod;
}
if (foundproblem != null)
return foundproblem;

return new problemmethodbinding(selector, argumenttypes, problemreasons.notfound);
}

public final referencebinding getjavaioserializable() {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(typeconstants.java_io_serializable);
return unitscope.environment.getresolvedtype(typeconstants.java_io_serializable, this);
}

public final referencebinding getjavalangannotationannotation() {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(typeconstants.java_lang_annotation_annotation);
return unitscope.environment.getresolvedtype(typeconstants.java_lang_annotation_annotation, this);
}

public final referencebinding getjavalangassertionerror() {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(typeconstants.java_lang_assertionerror);
return unitscope.environment.getresolvedtype(typeconstants.java_lang_assertionerror, this);
}

public final referencebinding getjavalangclass() {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(typeconstants.java_lang_class);
return unitscope.environment.getresolvedtype(typeconstants.java_lang_class, this);
}

public final referencebinding getjavalangcloneable() {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(typeconstants.java_lang_cloneable);
return unitscope.environment.getresolvedtype(typeconstants.java_lang_cloneable, this);
}
public final referencebinding getjavalangenum() {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(typeconstants.java_lang_enum);
return unitscope.environment.getresolvedtype(typeconstants.java_lang_enum, this);
}

public final referencebinding getjavalangiterable() {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(typeconstants.java_lang_iterable);
return unitscope.environment.getresolvedtype(typeconstants.java_lang_iterable, this);
}
public final referencebinding getjavalangobject() {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(typeconstants.java_lang_object);
return unitscope.environment.getresolvedtype(typeconstants.java_lang_object, this);
}

public final referencebinding getjavalangstring() {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(typeconstants.java_lang_string);
return unitscope.environment.getresolvedtype(typeconstants.java_lang_string, this);
}

public final referencebinding getjavalangthrowable() {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(typeconstants.java_lang_throwable);
return unitscope.environment.getresolvedtype(typeconstants.java_lang_throwable, this);
}
public final referencebinding getjavautiliterator() {
compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(typeconstants.java_util_iterator);
return unitscope.environment.getresolvedtype(typeconstants.java_util_iterator, this);
}

/* answer the type binding corresponding to the typename argument, relative to the enclosingtype.
*/
public final referencebinding getmembertype(char[] typename, referencebinding enclosingtype) {
referencebinding membertype = findmembertype(typename, enclosingtype);
if (membertype != null) return membertype;
char[][] compoundname = new char[][] { typename };
return new problemreferencebinding(compoundname, null, problemreasons.notfound);
}

public methodbinding getmethod(typebinding receivertype, char[] selector, typebinding[] argumenttypes, invocationsite invocationsite) {
compilationunitscope unitscope = compilationunitscope();
lookupenvironment env = unitscope.environment;
try {
env.missingclassfilelocation = invocationsite;
switch (receivertype.kind()) {
case binding.base_type :
return new problemmethodbinding(selector, argumenttypes, problemreasons.notfound);
case binding.array_type :
unitscope.recordtypereference(receivertype);
return findmethodforarray((arraybinding) receivertype, selector, argumenttypes, invocationsite);
}
unitscope.recordtypereference(receivertype);

referencebinding currenttype = (referencebinding) receivertype;
if (!currenttype.canbeseenby(this))
return new problemmethodbinding(selector, argumenttypes, problemreasons.receivertypenotvisible);

// retrieve an exact visible match (if possible)
methodbinding methodbinding = findexactmethod(currenttype, selector, argumenttypes, invocationsite);
if (methodbinding != null) return methodbinding;

methodbinding = findmethod(currenttype, selector, argumenttypes, invocationsite);
if (methodbinding == null)
return new problemmethodbinding(selector, argumenttypes, problemreasons.notfound);
if (!methodbinding.isvalidbinding())
return methodbinding;

// special treatment for object.getclass() in 1.5 mode (substitute parameterized return type)
if (argumenttypes == binding.no_parameters
&& charoperation.equals(selector, typeconstants.getclass)
&& methodbinding.returntype.isparameterizedtype()/*1.5*/) {
return environment().creategetclassmethod(receivertype, methodbinding, this);
}
return methodbinding;
} catch (abortcompilation e) {
e.updatecontext(invocationsite, referencecompilationunit().compilationresult);
throw e;
} finally {
env.missingclassfilelocation = null;
}
}

/* answer the package from the compoundname or null if it begins with a type.
* intended to be used while resolving a qualified type name.
*
* note: if a problem binding is returned, senders should extract the compound name
* from the binding & not assume the problem applies to the entire compoundname.
*/
public final binding getpackage(char[][] compoundname) {
compilationunitscope().recordqualifiedreference(compoundname);
binding binding = gettypeorpackage(compoundname[0], binding.type | binding.package, true);
if (binding == null) {
char[][] qname = new char[][] { compoundname[0] };
return new problemreferencebinding(qname, environment().createmissingtype(null, compoundname), problemreasons.notfound);
}
if (!binding.isvalidbinding()) {
if (binding instanceof packagebinding) { /* missing package */
char[][] qname = new char[][] { compoundname[0] };
return new problemreferencebinding(qname, null /* no closest match since search for pkg*/, problemreasons.notfound);
}
return binding;
}
if (!(binding instanceof packagebinding)) return null; // compoundname does not start with a package

int currentindex = 1, length = compoundname.length;
packagebinding packagebinding = (packagebinding) binding;
while (currentindex < length) {
binding = packagebinding.gettypeorpackage(compoundname[currentindex++]);
if (binding == null) {
return new problemreferencebinding(charoperation.subarray(compoundname, 0, currentindex), null /* no closest match since search for pkg*/, problemreasons.notfound);
}
if (!binding.isvalidbinding())
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
binding instanceof referencebinding ? (referencebinding)((referencebinding)binding).closestmatch() : null,
binding.problemid());
if (!(binding instanceof packagebinding))
return packagebinding;
packagebinding = (packagebinding) binding;
}
return new problemreferencebinding(compoundname, null /* no closest match since search for pkg*/, problemreasons.notfound);
}

/* answer the type binding that corresponds the given name, starting the lookup in the receiver.
* the name provided is a simple source name (e.g., "object" , "point", ...)
*/
// the return type of this method could be referencebinding if we did not answer base types.
// note: we could support looking for base types last in the search, however any code using
// this feature would be extraordinarily slow.  therefore we don't do this
public final typebinding gettype(char[] name) {
// would like to remove this test and require senders to specially handle base types
typebinding binding = getbasetype(name);
if (binding != null) return binding;
return (referencebinding) gettypeorpackage(name, binding.type, true);
}

/* answer the type binding that corresponds to the given name, starting the lookup in the receiver
* or the packagebinding if provided.
* the name provided is a simple source name (e.g., "object" , "point", ...)
*/
public final typebinding gettype(char[] name, packagebinding packagebinding) {
if (packagebinding == null)
return gettype(name);

binding binding = packagebinding.gettypeorpackage(name);
if (binding == null) {
return new problemreferencebinding(
charoperation.arrayconcat(packagebinding.compoundname, name),
null,
problemreasons.notfound);
}
if (!binding.isvalidbinding()) {
return new problemreferencebinding(
binding instanceof referencebinding ? ((referencebinding)binding).compoundname : charoperation.arrayconcat(packagebinding.compoundname, name),
binding instanceof referencebinding ? (referencebinding)((referencebinding)binding).closestmatch() : null,
binding.problemid());
}
referencebinding typebinding = (referencebinding) binding;
if (!typebinding.canbeseenby(this))
return new problemreferencebinding(
typebinding.compoundname,
typebinding,
problemreasons.notvisible);
return typebinding;
}

/* answer the type binding corresponding to the compoundname.
*
* note: if a problem binding is returned, senders should extract the compound name
* from the binding & not assume the problem applies to the entire compoundname.
*/
public final typebinding gettype(char[][] compoundname, int typenamelength) {
if (typenamelength == 1) {
// would like to remove this test and require senders to specially handle base types
typebinding binding = getbasetype(compoundname[0]);
if (binding != null) return binding;
}

compilationunitscope unitscope = compilationunitscope();
unitscope.recordqualifiedreference(compoundname);
binding binding = gettypeorpackage(compoundname[0], typenamelength == 1 ? binding.type : binding.type | binding.package, true);
if (binding == null) {
char[][] qname = new char[][] { compoundname[0] };
return new problemreferencebinding(qname, environment().createmissingtype(compilationunitscope().getcurrentpackage(), qname), problemreasons.notfound);
}
if (!binding.isvalidbinding()) {
if (binding instanceof packagebinding) {
char[][] qname = new char[][] { compoundname[0] };
return new problemreferencebinding(
qname,
environment().createmissingtype(null, qname),
problemreasons.notfound);
}
return (referencebinding) binding;
}
int currentindex = 1;
boolean checkvisibility = false;
if (binding instanceof packagebinding) {
packagebinding packagebinding = (packagebinding) binding;
while (currentindex < typenamelength) {
binding = packagebinding.gettypeorpackage(compoundname[currentindex++]); // does not check visibility
if (binding == null) {
char[][] qname = charoperation.subarray(compoundname, 0, currentindex);
return new problemreferencebinding(
qname,
environment().createmissingtype(packagebinding, qname),
problemreasons.notfound);
}
if (!binding.isvalidbinding())
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
binding instanceof referencebinding ? (referencebinding)((referencebinding)binding).closestmatch() : null,
binding.problemid());
if (!(binding instanceof packagebinding))
break;
packagebinding = (packagebinding) binding;
}
if (binding instanceof packagebinding) {
char[][] qname = charoperation.subarray(compoundname, 0, currentindex);
return new problemreferencebinding(
qname,
environment().createmissingtype(null, qname),
problemreasons.notfound);
}
checkvisibility = true;
}

// binding is now a referencebinding
referencebinding typebinding = (referencebinding) binding;
unitscope.recordtypereference(typebinding);
if (checkvisibility) // handles the fall through case
if (!typebinding.canbeseenby(this))
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
typebinding,
problemreasons.notvisible);

while (currentindex < typenamelength) {
typebinding = getmembertype(compoundname[currentindex++], typebinding);
if (!typebinding.isvalidbinding()) {
if (typebinding instanceof problemreferencebinding) {
problemreferencebinding problembinding = (problemreferencebinding) typebinding;
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
problembinding.closestreferencematch(),
typebinding.problemid());
}
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
(referencebinding)((referencebinding)binding).closestmatch(),
typebinding.problemid());
}
}
return typebinding;
}

/* internal use only
*/
final binding gettypeorpackage(char[] name, int mask, boolean needresolve) {
scope scope = this;
referencebinding foundtype = null;
boolean insidestaticcontext = false;
boolean insidetypeannotation = false;
if ((mask & binding.type) == 0) {
scope next = scope;
while ((next = scope.parent) != null)
scope = next;
} else {
boolean inheritedhasprecedence = compileroptions().compliancelevel >= classfileconstants.jdk1_4;
done : while (true) { // done when a compilation_unit_scope is found
switch (scope.kind) {
case method_scope :
methodscope methodscope = (methodscope) scope;
abstractmethoddeclaration methoddecl = methodscope.referencemethod();
if (methoddecl != null) {
if (methoddecl.binding != null) {
typevariablebinding typevariable = methoddecl.binding.gettypevariable(name);
if (typevariable != null)
return typevariable;
} else {
// use the methoddecl's typeparameters to handle problem cases when the method binding doesn't exist
typeparameter[] params = methoddecl.typeparameters();
for (int i = params == null ? 0 : params.length; --i >= 0;)
if (charoperation.equals(params[i].name, name))
if (params[i].binding != null && params[i].binding.isvalidbinding())
return params[i].binding;
}
}
insidestaticcontext |= methodscope.isstatic;
insidetypeannotation = methodscope.insidetypeannotation;
//$fall-through$
case block_scope :
referencebinding localtype = ((blockscope) scope).findlocaltype(name); // looks in this scope only
if (localtype != null) {
if (foundtype != null && foundtype != localtype)
return new problemreferencebinding(new char[][]{name}, foundtype, problemreasons.inheritednamehidesenclosingname);
return localtype;
}
break;
case class_scope :
sourcetypebinding sourcetype = ((classscope) scope).referencecontext.binding;
if (scope == this && (sourcetype.tagbits & tagbits.typevariablesareconnected) == 0) {
// type variables take precedence over the source type, ex. class x <x> extends x == class x <y> extends y
// but not when we step out to the enclosing type
typevariablebinding typevariable = sourcetype.gettypevariable(name);
if (typevariable != null)
return typevariable;
if (charoperation.equals(name, sourcetype.sourcename))
return sourcetype;
insidestaticcontext |= sourcetype.isstatic();
break;
}
// member types take precedence over type variables
if (!insidetypeannotation) {
// 6.5.5.1 - member types have precedence over top-level type in same unit
referencebinding membertype = findmembertype(name, sourcetype);
if (membertype != null) { // skip it if we did not find anything
if (membertype.problemid() == problemreasons.ambiguous) {
if (foundtype == null || foundtype.problemid() == problemreasons.notvisible)
// supercedes any potential inheritednamehidesenclosingname problem
return membertype;
// make the user qualify the type, likely wants the first inherited type
return new problemreferencebinding(new char[][]{name}, foundtype, problemreasons.inheritednamehidesenclosingname);
}
if (membertype.isvalidbinding()) {
if (sourcetype == membertype.enclosingtype() || inheritedhasprecedence) {
if (insidestaticcontext && !membertype.isstatic() && sourcetype.isgenerictype())
return new problemreferencebinding(new char[][]{name}, membertype, problemreasons.nonstaticreferenceinstaticcontext);
// found a valid type in the 'immediate' scope (i.e. not inherited)
// or in 1.4 mode (inherited visible shadows enclosing)
if (foundtype == null || (inheritedhasprecedence && foundtype.problemid() == problemreasons.notvisible))
return membertype;
// if a valid type was found, complain when another is found in an 'immediate' enclosing type (i.e. not inherited)
if (foundtype.isvalidbinding() && foundtype != membertype)
return new problemreferencebinding(new char[][]{name}, foundtype, problemreasons.inheritednamehidesenclosingname);
}
}
if (foundtype == null || (foundtype.problemid() == problemreasons.notvisible && membertype.problemid() != problemreasons.notvisible))
// only remember the membertype if its the first one found or the previous one was not visible & membertype is...
foundtype = membertype;
}
}
typevariablebinding typevariable = sourcetype.gettypevariable(name);
if (typevariable != null) {
if (insidestaticcontext) // do not consider this type modifiers: access is legite within same type
return new problemreferencebinding(new char[][]{name}, typevariable, problemreasons.nonstaticreferenceinstaticcontext);
return typevariable;
}
insidestaticcontext |= sourcetype.isstatic();
insidetypeannotation = false;
if (charoperation.equals(sourcetype.sourcename, name)) {
if (foundtype != null && foundtype != sourcetype && foundtype.problemid() != problemreasons.notvisible)
return new problemreferencebinding(new char[][]{name}, foundtype, problemreasons.inheritednamehidesenclosingname);
return sourcetype;
}
break;
case compilation_unit_scope :
break done;
}
scope = scope.parent;
}
if (foundtype != null && foundtype.problemid() != problemreasons.notvisible)
return foundtype;
}

// at this point the scope is a compilation unit scope
compilationunitscope unitscope = (compilationunitscope) scope;
hashtableofobject typeorpackagecache = unitscope.typeorpackagecache;
if (typeorpackagecache != null) {
binding cachedbinding = (binding) typeorpackagecache.get(name);
if (cachedbinding != null) { // can also include notfound problemreferencebindings if we already know this name is not found
if (cachedbinding instanceof importbinding) { // single type import cached in faultinimports(), replace it in the cache with the type
importreference importreference = ((importbinding) cachedbinding).reference;
if (importreference != null) {
importreference.bits |= astnode.used;
}
if (cachedbinding instanceof importconflictbinding)
typeorpackagecache.put(name, cachedbinding = ((importconflictbinding) cachedbinding).conflictingtypebinding); // already know its visible
else
typeorpackagecache.put(name, cachedbinding = ((importbinding) cachedbinding).resolvedimport); // already know its visible
}
if ((mask & binding.type) != 0) {
if (foundtype != null && foundtype.problemid() != problemreasons.notvisible && cachedbinding.problemid() != problemreasons.ambiguous)
return foundtype; // problem type from above supercedes notfound type but not ambiguous import case
if (cachedbinding instanceof referencebinding)
return cachedbinding; // cached type found in previous walk below
}
if ((mask & binding.package) != 0 && cachedbinding instanceof packagebinding)
return cachedbinding; // cached package found in previous walk below
}
}

// ask for the imports + name
if ((mask & binding.type) != 0) {
importbinding[] imports = unitscope.imports;
if (imports != null && typeorpackagecache == null) { // walk single type imports since faultinimports() has not run yet
nextimport : for (int i = 0, length = imports.length; i < length; i++) {
importbinding importbinding = imports[i];
if (!importbinding.ondemand) {
if (charoperation.equals(importbinding.compoundname[importbinding.compoundname.length - 1], name)) {
binding resolvedimport = unitscope.resolvesingleimport(importbinding, binding.type);
if (resolvedimport == null) continue nextimport;
if (resolvedimport instanceof typebinding) {
importreference importreference = importbinding.reference;
if (importreference != null)
importreference.bits |= astnode.used;
return resolvedimport; // already know its visible
}
}
}
}
}

// check if the name is in the current package, skip it if its a sub-package
packagebinding currentpackage = unitscope.fpackage;
unitscope.recordreference(currentpackage.compoundname, name);
binding binding = currentpackage.gettypeorpackage(name);
if (binding instanceof referencebinding) {
referencebinding referencetype = (referencebinding) binding;
if ((referencetype.tagbits & tagbits.hasmissingtype) == 0) {
if (typeorpackagecache != null)
typeorpackagecache.put(name, referencetype);
return referencetype; // type is always visible to its own package
}
}

// check on demand imports
if (imports != null) {
boolean foundinimport = false;
referencebinding type = null;
for (int i = 0, length = imports.length; i < length; i++) {
importbinding someimport = imports[i];
if (someimport.ondemand) {
binding resolvedimport = someimport.resolvedimport;
referencebinding temp = null;
if (resolvedimport instanceof packagebinding) {
temp = findtype(name, (packagebinding) resolvedimport, currentpackage);
} else if (someimport.isstatic()) {
temp = findmembertype(name, (referencebinding) resolvedimport); // static imports are allowed to see inherited member types
if (temp != null && !temp.isstatic())
temp = null;
} else {
temp = finddirectmembertype(name, (referencebinding) resolvedimport);
}
if (temp != type && temp != null) {
if (temp.isvalidbinding()) {
importreference importreference = someimport.reference;
if (importreference != null) {
importreference.bits |= astnode.used;
}
if (foundinimport) {
// answer error binding -- import on demand conflict; name found in two import on demand packages.
temp = new problemreferencebinding(new char[][]{name}, type, problemreasons.ambiguous);
if (typeorpackagecache != null)
typeorpackagecache.put(name, temp);
return temp;
}
type = temp;
foundinimport = true;
} else if (foundtype == null) {
foundtype = temp;
}
}
}
}
if (type != null) {
if (typeorpackagecache != null)
typeorpackagecache.put(name, type);
return type;
}
}
}

unitscope.recordsimplereference(name);
if ((mask & binding.package) != 0) {
packagebinding packagebinding = unitscope.environment.gettoplevelpackage(name);
if (packagebinding != null) {
if (typeorpackagecache != null)
typeorpackagecache.put(name, packagebinding);
return packagebinding;
}
}

// answer error binding -- could not find name
if (foundtype == null) {
char[][] qname = new char[][] { name };
referencebinding closestmatch = null;
if ((mask & binding.package) != 0) {
if (needresolve) {
closestmatch = environment().createmissingtype(unitscope.fpackage, qname);
}
} else {
packagebinding packagebinding = unitscope.environment.gettoplevelpackage(name);
if (packagebinding == null || !packagebinding.isvalidbinding()) {
if (needresolve) {
closestmatch = environment().createmissingtype(unitscope.fpackage, qname);
}
}
}
foundtype = new problemreferencebinding(qname, closestmatch, problemreasons.notfound);
if (typeorpackagecache != null && (mask & binding.package) != 0) { // only put notfound type in cache if you know its not a package
typeorpackagecache.put(name, foundtype);
}
} else if ((foundtype.tagbits & tagbits.hasmissingtype) != 0) {
char[][] qname = new char[][] { name };
foundtype = new problemreferencebinding(qname, foundtype, problemreasons.notfound);
if (typeorpackagecache != null && (mask & binding.package) != 0) // only put notfound type in cache if you know its not a package
typeorpackagecache.put(name, foundtype);
}
return foundtype;
}

// added for code assist... not public api
// do not use to resolve import references since this method assumes 'a.b' is relative to a single type import of 'p1.a'
// when it may actually mean the type b in the package a
// use compilationunitscope.getimport(char[][]) instead
public final binding gettypeorpackage(char[][] compoundname) {
int namelength = compoundname.length;
if (namelength == 1) {
typebinding binding = getbasetype(compoundname[0]);
if (binding != null) return binding;
}
binding binding = gettypeorpackage(compoundname[0], binding.type | binding.package, true);
if (!binding.isvalidbinding()) return binding;

int currentindex = 1;
boolean checkvisibility = false;
if (binding instanceof packagebinding) {
packagebinding packagebinding = (packagebinding) binding;

while (currentindex < namelength) {
binding = packagebinding.gettypeorpackage(compoundname[currentindex++]);
if (binding == null)
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
null,
problemreasons.notfound);
if (!binding.isvalidbinding())
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
binding instanceof referencebinding ? (referencebinding)((referencebinding)binding).closestmatch() : null,
binding.problemid());
if (!(binding instanceof packagebinding))
break;
packagebinding = (packagebinding) binding;
}
if (binding instanceof packagebinding) return binding;
checkvisibility = true;
}
// binding is now a referencebinding
referencebinding typebinding = (referencebinding) binding;
referencebinding qualifiedtype = (referencebinding) environment().converttorawtype(typebinding, false /*do not force conversion of enclosing types*/);

if (checkvisibility) // handles the fall through case
if (!typebinding.canbeseenby(this))
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
typebinding,
problemreasons.notvisible);

while (currentindex < namelength) {
typebinding = getmembertype(compoundname[currentindex++], typebinding);
// checks visibility
if (!typebinding.isvalidbinding())
return new problemreferencebinding(
charoperation.subarray(compoundname, 0, currentindex),
(referencebinding)typebinding.closestmatch(),
typebinding.problemid());

if (typebinding.isgenerictype()) {
qualifiedtype = environment().createrawtype(typebinding, qualifiedtype);
} else {
qualifiedtype = (qualifiedtype != null && (qualifiedtype.israwtype() || qualifiedtype.isparameterizedtype()))
? environment().createparameterizedtype(typebinding, null, qualifiedtype)
: typebinding;
}
}
return qualifiedtype;
}

protected boolean haserasedcandidatescollisions(typebinding one, typebinding two, map invocations, referencebinding type, astnode typeref) {
invocations.clear();
typebinding[] mecs = minimalerasedcandidates(new typebinding[] {one, two}, invocations);
if (mecs != null) {
nextcandidate: for (int k = 0, max = mecs.length; k < max; k++) {
typebinding mec = mecs[k];
if (mec == null) continue nextcandidate;
object value = invocations.get(mec);
if (value instanceof typebinding[]) {
typebinding[] invalidinvocations = (typebinding[]) value;
problemreporter().superinterfacescollide(invalidinvocations[0].erasure(), typeref, invalidinvocations[0], invalidinvocations[1]);
type.tagbits |= tagbits.hierarchyhasproblems;
return true;
}
}
}
return false;
}

/**
* returns the immediately enclosing switchcase statement (carried by closest blockscope),
*/
public casestatement innermostswitchcase() {
scope scope = this;
do {
if (scope instanceof blockscope)
return ((blockscope) scope).enclosingcase;
scope = scope.parent;
} while (scope != null);
return null;
}

protected boolean isacceptablemethod(methodbinding one, methodbinding two) {
typebinding[] oneparams = one.parameters;
typebinding[] twoparams = two.parameters;
int oneparamslength = oneparams.length;
int twoparamslength = twoparams.length;
if (oneparamslength == twoparamslength) {
next : for (int i = 0; i < oneparamslength; i++) {
typebinding oneparam = oneparams[i];
typebinding twoparam = twoparams[i];
if (oneparam == twoparam || oneparam.iscompatiblewith(twoparam)) {
if (two.declaringclass.israwtype()) continue next;

typebinding originaltwoparam = two.original().parameters[i].leafcomponenttype();
switch (originaltwoparam.kind()) {
case binding.type_parameter :
if (((typevariablebinding) originaltwoparam).hasonlyrawbounds())
continue next;
//$fall-through$
case binding.wildcard_type :
case binding.intersection_type:
case binding.parameterized_type :
typebinding originaloneparam = one.original().parameters[i].leafcomponenttype();
switch (originaloneparam.kind()) {
case binding.type :
case binding.generic_type :
typebinding inheritedtwoparam = oneparam.findsupertypeoriginatingfrom(twoparam);
if (inheritedtwoparam == null || !inheritedtwoparam.leafcomponenttype().israwtype()) break;
return false;
case binding.type_parameter :
if (!((typevariablebinding) originaloneparam).upperbound().israwtype()) break;
return false;
case binding.raw_type:
// originaloneparam is raw so it cannot be more specific than a wildcard or parameterized type
return false;
}
}
} else {
if (i == oneparamslength - 1 && one.isvarargs() && two.isvarargs()) {
typebinding etype = ((arraybinding) twoparam).elementstype();
if (oneparam == etype || oneparam.iscompatiblewith(etype))
return true; // special case to choose between 2 varargs methods when the last arg is object[]
}
return false;
}
}
return true;
}

if (one.isvarargs() && two.isvarargs()) {
if (oneparamslength > twoparamslength) {
// special case when autoboxing makes (int, int...) better than (object...) but not (int...) or (integer, int...)
if (((arraybinding) twoparams[twoparamslength - 1]).elementstype().id != typeids.t_javalangobject)
return false;
}
// check that each parameter before the vararg parameters are compatible (no autoboxing allowed here)
for (int i = (oneparamslength > twoparamslength ? twoparamslength : oneparamslength) - 2; i >= 0; i--)
if (oneparams[i] != twoparams[i] && !oneparams[i].iscompatiblewith(twoparams[i]))
return false;
if (parametercompatibilitylevel(one, twoparams) == not_compatible
&& parametercompatibilitylevel(two, oneparams) == varargs_compatible)
return true;
}
return false;
}

public boolean isboxingcompatiblewith(typebinding expressiontype, typebinding targettype) {
lookupenvironment environment = environment();
if (environment.globaloptions.sourcelevel < classfileconstants.jdk1_5 || expressiontype.isbasetype() == targettype.isbasetype())
return false;

// check if autoboxed type is compatible
typebinding convertedtype = environment.computeboxingtype(expressiontype);
return convertedtype == targettype || convertedtype.iscompatiblewith(targettype);
}

/* answer true if the scope is nested inside a given field declaration.
* note: it works as long as the scope.fielddeclarationindex is reflecting the field being traversed
* e.g. during name resolution.
*/
public final boolean isdefinedinfield(fieldbinding field) {
scope scope = this;
do {
if (scope instanceof methodscope) {
methodscope methodscope = (methodscope) scope;
if (methodscope.initializedfield == field) return true;
}
scope = scope.parent;
} while (scope != null);
return false;
}

/* answer true if the scope is nested inside a given method declaration
*/
public final boolean isdefinedinmethod(methodbinding method) {
scope scope = this;
do {
if (scope instanceof methodscope) {
referencecontext refcontext = ((methodscope) scope).referencecontext;
if (refcontext instanceof abstractmethoddeclaration)
if (((abstractmethoddeclaration) refcontext).binding == method)
return true;
}
scope = scope.parent;
} while (scope != null);
return false;
}

/* answer whether the type is defined in the same compilation unit as the receiver
*/
public final boolean isdefinedinsameunit(referencebinding type) {
// find the outer most enclosing type
referencebinding enclosingtype = type;
while ((type = enclosingtype.enclosingtype()) != null)
enclosingtype = type;

// find the compilation unit scope
scope scope, unitscope = this;
while ((scope = unitscope.parent) != null)
unitscope = scope;

// test that the enclosingtype is not part of the compilation unit
sourcetypebinding[] topleveltypes = ((compilationunitscope) unitscope).topleveltypes;
for (int i = topleveltypes.length; --i >= 0;)
if (topleveltypes[i] == enclosingtype)
return true;
return false;
}

/* answer true if the scope is nested inside a given type declaration
*/
public final boolean isdefinedintype(referencebinding type) {
scope scope = this;
do {
if (scope instanceof classscope)
if (((classscope) scope).referencecontext.binding == type)
return true;
scope = scope.parent;
} while (scope != null);
return false;
}

/**
* returns true if the scope or one of its parent is associated to a given casestatement, denoting
* being part of a given switch case statement.
*/
public boolean isinsidecase(casestatement casestatement) {
scope scope = this;
do {
switch (scope.kind) {
case scope.block_scope :
if (((blockscope) scope).enclosingcase == casestatement) {
return true;
}
}
scope = scope.parent;
} while (scope != null);
return false;
}

public boolean isinsidedeprecatedcode(){
switch(this.kind){
case scope.block_scope :
case scope.method_scope :
methodscope methodscope = methodscope();
if (!methodscope.isinsideinitializer()){
// check method modifiers to see if deprecated
methodbinding context = ((abstractmethoddeclaration)methodscope.referencecontext).binding;
if (context != null && context.isviewedasdeprecated())
return true;
} else if (methodscope.initializedfield != null && methodscope.initializedfield.isviewedasdeprecated()) {
// inside field declaration ? check field modifier to see if deprecated
return true;
}
sourcetypebinding declaringtype = ((blockscope)this).referencetype().binding;
if (declaringtype != null) {
declaringtype.initializedeprecatedannotationtagbits(); // may not have been resolved until then
if (declaringtype.isviewedasdeprecated())
return true;
}
break;
case scope.class_scope :
referencebinding context = ((classscope)this).referencetype().binding;
if (context != null) {
context.initializedeprecatedannotationtagbits(); // may not have been resolved until then
if (context.isviewedasdeprecated())
return true;
}
break;
case scope.compilation_unit_scope :
// consider import as being deprecated if first type is itself deprecated (123522)
compilationunitdeclaration unit = referencecompilationunit();
if (unit.types != null && unit.types.length > 0) {
sourcetypebinding type = unit.types[0].binding;
if (type != null) {
type.initializedeprecatedannotationtagbits(); // may not have been resolved until then
if (type.isviewedasdeprecated())
return true;
}
}
}
return false;
}

private boolean isoverriddenmethodgeneric(methodbinding method) {
methodverifier verifier = environment().methodverifier();
referencebinding currenttype = method.declaringclass.superclass();
while (currenttype != null) {
methodbinding[] currentmethods = currenttype.getmethods(method.selector);
for (int i = 0, l = currentmethods.length; i < l; i++) {
methodbinding currentmethod = currentmethods[i];
if (currentmethod != null && currentmethod.original().typevariables != binding.no_type_variables)
if (verifier.doesmethodoverride(method, currentmethod))
return true;
}
currenttype = currenttype.superclass();
}
return false;
}

public boolean ispossiblesubtypeofrawtype(typebinding paramtype) {
typebinding t = paramtype.leafcomponenttype();
if (t.isbasetype()) return false;

referencebinding currenttype = (referencebinding) t;
referencebinding[] interfacestovisit = null;
int nextposition = 0;
do {
if (currenttype.israwtype()) return true;
if (!currenttype.ishierarchyconnected()) return true; // do not fault in super types right now, so assume one is a raw type

referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
} while ((currenttype = currenttype.superclass()) != null);

for (int i = 0; i < nextposition; i++) {
currenttype = interfacestovisit[i];
if (currenttype.israwtype()) return true;

referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
return false;
}

private typebinding leastcontaininginvocation(typebinding mec, object invocationdata, list lubstack) {
if (invocationdata == null) return mec; // no alternate invocation
if (invocationdata instanceof typebinding) { // only one invocation, simply return it (array only allocated if more than one)
return (typebinding) invocationdata;
}
typebinding[] invocations = (typebinding[]) invocationdata;

// if mec is an array type, intersect invocation leaf component types, then promote back to array
int dim = mec.dimensions();
mec = mec.leafcomponenttype();

int arglength = mec.typevariables().length;
if (arglength == 0) return mec; // should be caught by no invocation check

// infer proper parameterized type from invocations
typebinding[] bestarguments = new typebinding[arglength];
for (int i = 0, length = invocations.length; i < length; i++) {
typebinding invocation = invocations[i].leafcomponenttype();
switch (invocation.kind()) {
case binding.generic_type :
typevariablebinding[] invocationvariables = invocation.typevariables();
for (int j = 0; j < arglength; j++) {
typebinding bestargument = leastcontainingtypeargument(bestarguments[j], invocationvariables[j], (referencebinding) mec, j, lubstack);
if (bestargument == null) return null;
bestarguments[j] = bestargument;
}
break;
case binding.parameterized_type :
parameterizedtypebinding parameterizedtype = (parameterizedtypebinding)invocation;
for (int j = 0; j < arglength; j++) {
typebinding bestargument = leastcontainingtypeargument(bestarguments[j], parameterizedtype.arguments[j], (referencebinding) mec, j, lubstack);
if (bestargument == null) return null;
bestarguments[j] = bestargument;
}
break;
case binding.raw_type :
return dim == 0 ? invocation : environment().createarraytype(invocation, dim); // raw type is taking precedence
}
}
typebinding least = environment().createparameterizedtype((referencebinding) mec.erasure(), bestarguments, mec.enclosingtype());
return dim == 0 ? least : environment().createarraytype(least, dim);
}

// jls 15.12.2
private typebinding leastcontainingtypeargument(typebinding u, typebinding v, referencebinding generictype, int rank, list lubstack) {
if (u == null) return v;
if (u == v) return u;
if (v.iswildcard()) {
wildcardbinding wildv = (wildcardbinding) v;
if (u.iswildcard()) {
wildcardbinding wildu = (wildcardbinding) u;
switch (wildu.boundkind) {
// ? extends u
case wildcard.extends :
switch(wildv.boundkind) {
// ? extends u, ? extends v
case wildcard.extends :
typebinding lub = lowerupperbound(new typebinding[]{wildu.bound,wildv.bound}, lubstack);
if (lub == null) return null;
// int is returned to denote cycle detected in lub computation - stop recursion by answering unbound wildcard
if (lub == typebinding.int) return environment().createwildcard(generictype, rank, null, null /*no extra bound*/, wildcard.unbound);
return environment().createwildcard(generictype, rank, lub, null /*no extra bound*/, wildcard.extends);
// ? extends u, ? super v
case wildcard.super :
if (wildu.bound == wildv.bound) return wildu.bound;
return environment().createwildcard(generictype, rank, null, null /*no extra bound*/, wildcard.unbound);
}
break;
// ? super u
case wildcard.super :
// ? super u, ? super v
if (wildu.boundkind == wildcard.super) {
typebinding[] glb = greaterlowerbound(new typebinding[]{wildu.bound,wildv.bound});
if (glb == null) return null;
return environment().createwildcard(generictype, rank, glb[0], null /*no extra bound*/, wildcard.super);	// todo (philippe) need to capture entire bounds
}
}
} else {
switch (wildv.boundkind) {
// u, ? extends v
case wildcard.extends :
typebinding lub = lowerupperbound(new typebinding[]{u,wildv.bound}, lubstack);
if (lub == null) return null;
// int is returned to denote cycle detected in lub computation - stop recursion by answering unbound wildcard
if (lub == typebinding.int) return environment().createwildcard(generictype, rank, null, null /*no extra bound*/, wildcard.unbound);
return environment().createwildcard(generictype, rank, lub, null /*no extra bound*/, wildcard.extends);
// u, ? super v
case wildcard.super :
typebinding[] glb = greaterlowerbound(new typebinding[]{u,wildv.bound});
if (glb == null) return null;
return environment().createwildcard(generictype, rank, glb[0], null /*no extra bound*/, wildcard.super);	// todo (philippe) need to capture entire bounds
case wildcard.unbound :
}
}
} else if (u.iswildcard()) {
wildcardbinding wildu = (wildcardbinding) u;
switch (wildu.boundkind) {
// u, ? extends v
case wildcard.extends :
typebinding lub = lowerupperbound(new typebinding[]{wildu.bound, v}, lubstack);
if (lub == null) return null;
// int is returned to denote cycle detected in lub computation - stop recursion by answering unbound wildcard
if (lub == typebinding.int) return environment().createwildcard(generictype, rank, null, null /*no extra bound*/, wildcard.unbound);
return environment().createwildcard(generictype, rank, lub, null /*no extra bound*/, wildcard.extends);
// u, ? super v
case wildcard.super :
typebinding[] glb = greaterlowerbound(new typebinding[]{wildu.bound, v});
if (glb == null) return null;
return environment().createwildcard(generictype, rank, glb[0], null /*no extra bound*/, wildcard.super); // todo (philippe) need to capture entire bounds
case wildcard.unbound :
}
}
typebinding lub = lowerupperbound(new typebinding[]{u,v}, lubstack);
if (lub == null) return null;
// int is returned to denote cycle detected in lub computation - stop recursion by answering unbound wildcard
if (lub == typebinding.int) return environment().createwildcard(generictype, rank, null, null /*no extra bound*/, wildcard.unbound);
return environment().createwildcard(generictype, rank, lub, null /*no extra bound*/, wildcard.extends);
}

// 15.12.2
/**
* returns voidbinding if types have no intersection (e.g. 2 unrelated interfaces), or null if
* no common supertype (e.g. list<string> and list<exception>), or the intersection type if possible
*/
public typebinding lowerupperbound(typebinding[] types) {
int typelength = types.length;
if (typelength == 1) {
typebinding type = types[0];
return type == null ? typebinding.void : type;
}
return lowerupperbound(types, new arraylist(1));
}

// 15.12.2
private typebinding lowerupperbound(typebinding[] types, list lubstack) {

int typelength = types.length;
if (typelength == 1) {
typebinding type = types[0];
return type == null ? typebinding.void : type;
}
// cycle detection
int stacklength = lubstack.size();
nextlubcheck: for (int i = 0; i < stacklength; i++) {
typebinding[] lubtypes = (typebinding[])lubstack.get(i);
int lubtypelength = lubtypes.length;
if (lubtypelength < typelength) continue nextlubcheck;
nexttypecheck:	for (int j = 0; j < typelength; j++) {
typebinding type = types[j];
if (type == null) continue nexttypecheck; // ignore
for (int k = 0; k < lubtypelength; k++) {
typebinding lubtype = lubtypes[k];
if (lubtype == null) continue; // ignore
if (lubtype == type || lubtype.isequivalentto(type)) continue nexttypecheck; // type found, jump to next one
}
continue nextlubcheck; // type not found in current lubtypes
}
// all types are included in some lub, cycle detected - stop recursion by answering special value (int)
return typebinding.int;
}

lubstack.add(types);
map invocations = new hashmap(1);
typebinding[] mecs = minimalerasedcandidates(types, invocations);
if (mecs == null) return null;
int length = mecs.length;
if (length == 0) return typebinding.void;
int count = 0;
typebinding firstbound = null;
int commondim = -1;
for (int i = 0; i < length; i++) {
typebinding mec = mecs[i];
if (mec == null) continue;
mec = leastcontaininginvocation(mec, invocations.get(mec), lubstack);
if (mec == null) return null;
int dim = mec.dimensions();
if (commondim == -1) {
commondim = dim;
} else if (dim != commondim) { // not all types have same dimension
return null;
}
if (firstbound == null && !mec.leafcomponenttype().isinterface()) firstbound = mec.leafcomponenttype();
mecs[count++] = mec; // recompact them to the front
}
switch (count) {
case 0 : return typebinding.void;
case 1 : return mecs[0];
case 2 :
if ((commondim == 0 ? mecs[1].id : mecs[1].leafcomponenttype().id) == typeids.t_javalangobject) return mecs[0];
if ((commondim == 0 ? mecs[0].id : mecs[0].leafcomponenttype().id) == typeids.t_javalangobject) return mecs[1];
}
typebinding[] otherbounds = new typebinding[count - 1];
int rank = 0;
for (int i = 0; i < count; i++) {
typebinding mec = commondim == 0 ? mecs[i] : mecs[i].leafcomponenttype();
if (mec.isinterface()) {
otherbounds[rank++] = mec;
}
}
typebinding intersectiontype = environment().createwildcard(null, 0, firstbound, otherbounds, wildcard.extends);
return commondim == 0 ? intersectiontype : environment().createarraytype(intersectiontype, commondim);
}

public final methodscope methodscope() {
scope scope = this;
do {
if (scope instanceof methodscope)
return (methodscope) scope;
scope = scope.parent;
} while (scope != null);
return null;
}

/**
* returns the most specific set of types compatible with all given types.
* (i.e. most specific common super types)
* if no types is given, will return an empty array. if not compatible
* reference type is found, returns null. in other cases, will return an array
* of minimal erased types, where some nulls may appear (and must simply be
* ignored).
*/
protected typebinding[] minimalerasedcandidates(typebinding[] types, map allinvocations) {
int length = types.length;
int indexoffirst = -1, actuallength = 0;
for (int i = 0; i < length; i++) {
typebinding type = types[i];
if (type == null) continue;
if (type.isbasetype()) return null;
if (indexoffirst < 0) indexoffirst = i;
actuallength ++;
}
switch (actuallength) {
case 0: return binding.no_types;
case 1: return types;
}
typebinding firsttype = types[indexoffirst];
if (firsttype.isbasetype()) return null;

// record all supertypes of type
// intersect with all supertypes of othertype
arraylist typestovisit = new arraylist(5);

int dim = firsttype.dimensions();
typebinding leaftype = firsttype.leafcomponenttype();
// do not allow type variables/intersection types to match with erasures for free
typebinding firsterasure;
switch(leaftype.kind()) {
case binding.parameterized_type :
case binding.raw_type :
case binding.array_type :
firsterasure = firsttype.erasure();
break;
default :
firsterasure = firsttype;
break;
}
if (firsterasure != firsttype) {
allinvocations.put(firsterasure, firsttype);
}
typestovisit.add(firsttype);
int max = 1;
referencebinding currenttype;
for (int i = 0; i < max; i++) {
typebinding typetovisit = (typebinding) typestovisit.get(i);
dim = typetovisit.dimensions();
if (dim > 0) {
leaftype = typetovisit.leafcomponenttype();
switch(leaftype.id) {
case typeids.t_javalangobject:
if (dim > 1) { // object[][] supertype is object[]
typebinding elementtype = ((arraybinding)typetovisit).elementstype();
if (!typestovisit.contains(elementtype)) {
typestovisit.add(elementtype);
max++;
}
continue;
}
//$fall-through$
case typeids.t_byte:
case typeids.t_short:
case typeids.t_char:
case typeids.t_boolean:
case typeids.t_int:
case typeids.t_long:
case typeids.t_float:
case typeids.t_double:
typebinding supertype = getjavaioserializable();
if (!typestovisit.contains(supertype)) {
typestovisit.add(supertype);
max++;
}
supertype = getjavalangcloneable();
if (!typestovisit.contains(supertype)) {
typestovisit.add(supertype);
max++;
}
supertype = getjavalangobject();
if (!typestovisit.contains(supertype)) {
typestovisit.add(supertype);
max++;
}
continue;

default:
}
typetovisit = leaftype;
}
currenttype = (referencebinding) typetovisit;
if (currenttype.iscapture()) {
typebinding firstbound = ((capturebinding) currenttype).firstbound;
if (firstbound != null && firstbound.isarraytype()) {
typebinding supertype = dim == 0 ? firstbound : (typebinding)environment().createarraytype(firstbound, dim); // recreate array if needed
if (!typestovisit.contains(supertype)) {
typestovisit.add(supertype);
max++;
typebinding supertypeerasure = (firstbound.istypevariable() || firstbound.iswildcard() /*&& !itsinterface.iscapture()*/) ? supertype : supertype.erasure();
if (supertypeerasure != supertype) {
allinvocations.put(supertypeerasure, supertype);
}
}
continue;
}
}
// inject super interfaces prior to superclass
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null) { // can be null during code assist operations that use lookupenvironment.completetypebindings(parsedunit, buildfieldsandmethods)
for (int j = 0, count = itsinterfaces.length; j < count; j++) {
typebinding itsinterface = itsinterfaces[j];
typebinding supertype = dim == 0 ? itsinterface : (typebinding)environment().createarraytype(itsinterface, dim); // recreate array if needed
if (!typestovisit.contains(supertype)) {
typestovisit.add(supertype);
max++;
typebinding supertypeerasure = (itsinterface.istypevariable() || itsinterface.iswildcard() /*&& !itsinterface.iscapture()*/) ? supertype : supertype.erasure();
if (supertypeerasure != supertype) {
allinvocations.put(supertypeerasure, supertype);
}
}
}
}
typebinding itssuperclass = currenttype.superclass();
if (itssuperclass != null) {
typebinding supertype = dim == 0 ? itssuperclass : (typebinding)environment().createarraytype(itssuperclass, dim); // recreate array if needed
if (!typestovisit.contains(supertype)) {
typestovisit.add(supertype);
max++;
typebinding supertypeerasure = (itssuperclass.istypevariable() || itssuperclass.iswildcard() /*&& !itssuperclass.iscapture()*/) ? supertype : supertype.erasure();
if (supertypeerasure != supertype) {
allinvocations.put(supertypeerasure, supertype);
}
}
}
}
int superlength = typestovisit.size();
typebinding[] erasedsupertypes = new typebinding[superlength];
int rank = 0;
for (iterator iter = typestovisit.iterator(); iter.hasnext();) {
typebinding type = (typebinding)iter.next();
leaftype = type.leafcomponenttype();
erasedsupertypes[rank++] = (leaftype.istypevariable() || leaftype.iswildcard() /*&& !leaftype.iscapture()*/) ? type : type.erasure();
}
// intersecting first type supertypes with other types' ones, nullifying non matching supertypes
int remaining = superlength;
nextothertype: for (int i = indexoffirst+1; i < length; i++) {
typebinding othertype = types[i];
if (othertype == null) continue nextothertype;
if (othertype.isarraytype()) {
nextsupertype: for (int j = 0; j < superlength; j++) {
typebinding erasedsupertype = erasedsupertypes[j];
if (erasedsupertype == null || erasedsupertype == othertype) continue nextsupertype;
typebinding match;
if ((match = othertype.findsupertypeoriginatingfrom(erasedsupertype)) == null) {
erasedsupertypes[j] = null;
if (--remaining == 0) return null;
continue nextsupertype;
}
// record invocation
object invocationdata = allinvocations.get(erasedsupertype);
if (invocationdata == null) {
allinvocations.put(erasedsupertype, match); // no array for singleton
} else if (invocationdata instanceof typebinding) {
if (match != invocationdata) {
// using an array to record invocations in order (188103)
typebinding[] someinvocations = { (typebinding) invocationdata, match, };
allinvocations.put(erasedsupertype, someinvocations);
}
} else { // using an array to record invocations in order (188103)
typebinding[] someinvocations = (typebinding[]) invocationdata;
checkexisting: {
int invoclength = someinvocations.length;
for (int k = 0; k < invoclength; k++) {
if (someinvocations[k] == match) break checkexisting;
}
system.arraycopy(someinvocations, 0, someinvocations = new typebinding[invoclength+1], 0, invoclength);
allinvocations.put(erasedsupertype, someinvocations);
someinvocations[invoclength] = match;
}
}
}
continue nextothertype;
}
nextsupertype: for (int j = 0; j < superlength; j++) {
typebinding erasedsupertype = erasedsupertypes[j];
if (erasedsupertype == null) continue nextsupertype;
typebinding match;
if (erasedsupertype == othertype || erasedsupertype.id == typeids.t_javalangobject && othertype.isinterface()) {
match = erasedsupertype;
} else {
if (erasedsupertype.isarraytype()) {
match = null;
} else {
match = othertype.findsupertypeoriginatingfrom(erasedsupertype);
}
if (match == null) { // incompatible super type
erasedsupertypes[j] = null;
if (--remaining == 0) return null;
continue nextsupertype;
}
}
// record invocation
object invocationdata = allinvocations.get(erasedsupertype);
if (invocationdata == null) {
allinvocations.put(erasedsupertype, match); // no array for singleton
} else if (invocationdata instanceof typebinding) {
if (match != invocationdata) {
// using an array to record invocations in order (188103)
typebinding[] someinvocations = { (typebinding) invocationdata, match, };
allinvocations.put(erasedsupertype, someinvocations);
}
} else { // using an array to record invocations in order (188103)
typebinding[] someinvocations = (typebinding[]) invocationdata;
checkexisting: {
int invoclength = someinvocations.length;
for (int k = 0; k < invoclength; k++) {
if (someinvocations[k] == match) break checkexisting;
}
system.arraycopy(someinvocations, 0, someinvocations = new typebinding[invoclength+1], 0, invoclength);
allinvocations.put(erasedsupertype, someinvocations);
someinvocations[invoclength] = match;
}
}
}
}
// eliminate non minimal super types
if (remaining > 1) {
nexttype: for (int i = 0; i < superlength; i++) {
typebinding erasedsupertype = erasedsupertypes[i];
if (erasedsupertype == null) continue nexttype;
nextothertype: for (int j = 0; j < superlength; j++) {
if (i == j) continue nextothertype;
typebinding othertype = erasedsupertypes[j];
if (othertype == null) continue nextothertype;
if (erasedsupertype instanceof referencebinding) {
if (othertype.id == typeids.t_javalangobject && erasedsupertype.isinterface()) continue nextothertype; // keep object for an interface
if (erasedsupertype.findsupertypeoriginatingfrom(othertype) != null) {
erasedsupertypes[j] = null; // discard non minimal supertype
remaining--;
}
} else if (erasedsupertype.isarraytype()) {
if (othertype.isarraytype() // keep object[...] for an interface array (same dimensions)
&& othertype.leafcomponenttype().id == typeids.t_javalangobject
&& othertype.dimensions() == erasedsupertype.dimensions()
&& erasedsupertype.leafcomponenttype().isinterface()) continue nextothertype;
if (erasedsupertype.findsupertypeoriginatingfrom(othertype) != null) {
erasedsupertypes[j] = null; // discard non minimal supertype
remaining--;
}
}
}
}
}
return erasedsupertypes;
}

// internal use only
/* all methods in visible are acceptable matches for the method in question...
* the methods defined by the receiver type appear before those defined by its
* superclass and so on. we want to find the one which matches best.
*
* since the receiver type is a class, we know each method's declaring class is
* either the receiver type or one of its superclasses. it is an error if the best match
* is defined by a superclass, when a lesser match is defined by the receiver type
* or a closer superclass.
*/
protected final methodbinding mostspecificclassmethodbinding(methodbinding[] visible, int visiblesize, invocationsite invocationsite) {
methodbinding previous = null;
nextvisible : for (int i = 0; i < visiblesize; i++) {
methodbinding method = visible[i];
if (previous != null && method.declaringclass != previous.declaringclass)
break; // cannot answer a method farther up the hierarchy than the first method found

if (!method.isstatic()) previous = method; // no ambiguity for static methods
for (int j = 0; j < visiblesize; j++) {
if (i == j) continue;
if (!visible[j].areparameterscompatiblewith(method.parameters))
continue nextvisible;
}
compilationunitscope().recordtypereferences(method.thrownexceptions);
return method;
}
return new problemmethodbinding(visible[0], visible[0].selector, visible[0].parameters, problemreasons.ambiguous);
}

// internal use only
/* all methods in visible are acceptable matches for the method in question...
* since the receiver type is an interface, we ignore the possibility that 2 inherited
* but unrelated superinterfaces may define the same method in acceptable but
* not identical ways... we just take the best match that we find since any class which
* implements the receiver interface must implement all signatures for the method...
* in which case the best match is correct.
*
* note: this is different than javac... in the following example, the message send of
* bar(x) in class y is supposed to be ambiguous. but any class which implements the
* interface i must implement both signatures for bar. if this class was the receiver of
* the message send instead of the interface i, then no problem would be reported.
*
interface i1 {
void bar(j j);
}
interface i2 {
//	void bar(j j);
void bar(object o);
}
interface i extends i1, i2 {}
interface j {}

class x implements j {}

class y extends x {
public void foo(i i, x x) { i.bar(x); }
}
*/
protected final methodbinding mostspecificinterfacemethodbinding(methodbinding[] visible, int visiblesize, invocationsite invocationsite) {
nextvisible : for (int i = 0; i < visiblesize; i++) {
methodbinding method = visible[i];
for (int j = 0; j < visiblesize; j++) {
if (i == j) continue;
if (!visible[j].areparameterscompatiblewith(method.parameters))
continue nextvisible;
}
compilationunitscope().recordtypereferences(method.thrownexceptions);
return method;
}
return new problemmethodbinding(visible[0], visible[0].selector, visible[0].parameters, problemreasons.ambiguous);
}

// caveat: this is not a direct implementation of jls
protected final methodbinding mostspecificmethodbinding(methodbinding[] visible, int visiblesize, typebinding[] argumenttypes, final invocationsite invocationsite, referencebinding receivertype) {
int[] compatibilitylevels = new int[visiblesize];
for (int i = 0; i < visiblesize; i++)
compatibilitylevels[i] = parametercompatibilitylevel(visible[i], argumenttypes);

invocationsite tiebreakinvocationsite = new invocationsite() {
public typebinding[] generictypearguments() { return null; } // ignore generictypeargs
public boolean issuperaccess() { return invocationsite.issuperaccess(); }
public boolean istypeaccess() { return invocationsite.istypeaccess(); }
public void setactualreceivertype(referencebinding actualreceivertype) { /* ignore */}
public void setdepth(int depth) { /* ignore */}
public void setfieldindex(int depth) { /* ignore */}
public int sourcestart() { return invocationsite.sourcestart(); }
public int sourceend() { return invocationsite.sourcestart(); }
};
methodbinding[] morespecific = new methodbinding[visiblesize];
int count = 0;
for (int level = 0, max = varargs_compatible; level <= max; level++) {
nextvisible : for (int i = 0; i < visiblesize; i++) {
if (compatibilitylevels[i] != level) continue nextvisible;
max = level; // do not examine further categories, will either return mostspecific or report ambiguous case
methodbinding current = visible[i];
methodbinding original = current.original();
methodbinding tiebreakmethod = current.tiebreakmethod();
for (int j = 0; j < visiblesize; j++) {
if (i == j || compatibilitylevels[j] != level) continue;
methodbinding next = visible[j];
if (original == next.original()) {
// parameterized superclasses & interfaces may be walked twice from different paths so skip next from now on
compatibilitylevels[j] = -1;
continue;
}

methodbinding methodtotest = next;
if (next instanceof parameterizedgenericmethodbinding) {
parameterizedgenericmethodbinding pnext = (parameterizedgenericmethodbinding) next;
if (pnext.israw && !pnext.isstatic()) {
// hold onto the raw substituted method
} else {
methodtotest = pnext.originalmethod;
}
}
methodbinding acceptable = computecompatiblemethod(methodtotest, tiebreakmethod.parameters, tiebreakinvocationsite);
/* there are 4 choices to consider with current & next :
foo(b) & foo(a) where b extends a
1. the 2 methods are equal (both accept each others parameters) -> want to continue
2. current has more specific parameters than next (so acceptable is a valid method) -> want to continue
3. current has less specific parameters than next (so acceptable is null) -> go on to next
4. current and next are not compatible with each other (so acceptable is null) -> go on to next
*/
if (acceptable == null || !acceptable.isvalidbinding())
continue nextvisible;
if (!isacceptablemethod(tiebreakmethod, acceptable))
continue nextvisible;
// pick a concrete method over a bridge method when parameters are equal since the return type of the concrete method is more specific
if (current.isbridge() && !next.isbridge())
if (tiebreakmethod.areparametersequal(acceptable))
continue nextvisible; // skip current so acceptable wins over this bridge method
}
morespecific[i] = current;
count++;
}
}
if (count == 1) {
for (int i = 0; i < visiblesize; i++) {
if (morespecific[i] != null) {
compilationunitscope().recordtypereferences(visible[i].thrownexceptions);
return visible[i];
}
}
} else if (count == 0) {
return new problemmethodbinding(visible[0], visible[0].selector, visible[0].parameters, problemreasons.ambiguous);
}

// found several methods that are mutually acceptable -> must be equal
// so now with the first acceptable method, find the 'correct' inherited method for each other acceptable method and
// see if they are equal after substitution of type variables (do the type variables have to be equal to be considered an override???)
if (receivertype != null)
receivertype = receivertype instanceof capturebinding ? receivertype : (referencebinding) receivertype.erasure();
nextspecific : for (int i = 0; i < visiblesize; i++) {
methodbinding current = morespecific[i];
if (current != null) {
referencebinding[] mostspecificexceptions = null;
methodbinding original = current.original();
boolean shouldintersectexceptions = original.declaringclass.isabstract() && original.thrownexceptions != binding.no_exceptions; // only needed when selecting from interface methods
for (int j = 0; j < visiblesize; j++) {
methodbinding next = morespecific[j];
if (next == null || i == j) continue;
methodbinding original2 = next.original();
if (original.declaringclass == original2.declaringclass)
break nextspecific; // duplicates thru substitution

if (!original.isabstract()) {
if (original2.isabstract())
continue; // only compare current against other concrete methods

original2 = original.findoriginalinheritedmethod(original2);
if (original2 == null)
continue nextspecific; // current's declaringclass is not a subtype of next's declaringclass
if (current.hassubstitutedparameters() || original.typevariables != binding.no_type_variables) {
if (!environment().methodverifier().isparametersubsignature(original, original2))
continue nextspecific; // current does not override next
}
} else if (receivertype != null) { // should not be null if original isabstract, but be safe
typebinding supertype = receivertype.findsupertypeoriginatingfrom(original.declaringclass.erasure());
if (original.declaringclass == supertype || !(supertype instanceof referencebinding)) {
// keep original
} else {
// must find inherited method with the same substituted variables
methodbinding[] supermethods = ((referencebinding) supertype).getmethods(original.selector, argumenttypes.length);
for (int m = 0, l = supermethods.length; m < l; m++) {
if (supermethods[m].original() == original) {
original = supermethods[m];
break;
}
}
}
supertype = receivertype.findsupertypeoriginatingfrom(original2.declaringclass.erasure());
if (original2.declaringclass == supertype || !(supertype instanceof referencebinding)) {
// keep original2
} else {
// must find inherited method with the same substituted variables
methodbinding[] supermethods = ((referencebinding) supertype).getmethods(original2.selector, argumenttypes.length);
for (int m = 0, l = supermethods.length; m < l; m++) {
if (supermethods[m].original() == original2) {
original2 = supermethods[m];
break;
}
}
}
if (original.typevariables != binding.no_type_variables)
original2 = original.computesubstitutedmethod(original2, environment());
if (original2 == null || !original.areparametererasuresequal(original2))
continue nextspecific; // current does not override next
if (original.returntype != original2.returntype) {
if (next.original().typevariables != binding.no_type_variables) {
if (original.returntype.erasure().findsupertypeoriginatingfrom(original2.returntype.erasure()) == null)
continue nextspecific;
} else if (!current.returntype.iscompatiblewith(next.returntype)) {
continue nextspecific;
}
// continue with original 15.12.2.5
}
if (shouldintersectexceptions && original2.declaringclass.isinterface()) {
if (current.thrownexceptions != next.thrownexceptions) {
if (next.thrownexceptions == binding.no_exceptions) {
mostspecificexceptions = binding.no_exceptions;
} else {
if (mostspecificexceptions == null) {
mostspecificexceptions = current.thrownexceptions;
}
int mostspecificlength = mostspecificexceptions.length;
int nextlength = next.thrownexceptions.length;
simpleset temp = new simpleset(mostspecificlength);
boolean changed = false;
nextexception : for (int t = 0; t < mostspecificlength; t++) {
referencebinding exception = mostspecificexceptions[t];
for (int s = 0; s < nextlength; s++) {
referencebinding nextexception = next.thrownexceptions[s];
if (exception.iscompatiblewith(nextexception)) {
temp.add(exception);
continue nextexception;
} else if (nextexception.iscompatiblewith(exception)) {
temp.add(nextexception);
changed = true;
continue nextexception;
} else {
changed = true;
}
}
}
if (changed) {
mostspecificexceptions = temp.elementsize == 0 ? binding.no_exceptions : new referencebinding[temp.elementsize];
temp.asarray(mostspecificexceptions);
}
}
}
}
}
}
if (mostspecificexceptions != null && mostspecificexceptions != current.thrownexceptions) {
return new mostspecificexceptionmethodbinding(current, mostspecificexceptions);
}
return current;
}
}

// if all morespecific methods are equal then see if duplicates exist because of substitution
return new problemmethodbinding(visible[0], visible[0].selector, visible[0].parameters, problemreasons.ambiguous);
}

public final classscope outermostclassscope() {
classscope lastclassscope = null;
scope scope = this;
do {
if (scope instanceof classscope)
lastclassscope = (classscope) scope;
scope = scope.parent;
} while (scope != null);
return lastclassscope; // may answer null if no class around
}

public final methodscope outermostmethodscope() {
methodscope lastmethodscope = null;
scope scope = this;
do {
if (scope instanceof methodscope)
lastmethodscope = (methodscope) scope;
scope = scope.parent;
} while (scope != null);
return lastmethodscope; // may answer null if no method around
}

public int parametercompatibilitylevel(methodbinding method, typebinding[] arguments) {
typebinding[] parameters = method.parameters;
int paramlength = parameters.length;
int arglength = arguments.length;

if (compileroptions().sourcelevel < classfileconstants.jdk1_5) {
if (paramlength != arglength)
return not_compatible;
for (int i = 0; i < arglength; i++) {
typebinding param = parameters[i];
typebinding arg = arguments[i];
if (arg != param && !arg.iscompatiblewith(param))
return not_compatible;
}
return compatible;
}

int level = compatible; // no autoboxing or varargs support needed
int lastindex = arglength;
lookupenvironment env = environment();
if (method.isvarargs()) {
lastindex = paramlength - 1;
if (paramlength == arglength) { // accept x or x[] but not x[][]
typebinding param = parameters[lastindex]; // is an arraybinding by definition
typebinding arg = arguments[lastindex];
if (param != arg) {
level = parametercompatibilitylevel(arg, param, env);
if (level == not_compatible) {
// expect x[], is it called with x
param = ((arraybinding) param).elementstype();
if (parametercompatibilitylevel(arg, param, env) == not_compatible)
return not_compatible;
level = varargs_compatible; // varargs support needed
}
}
} else {
if (paramlength < arglength) { // all remaining argument types must be compatible with the elementstype of varargtype
typebinding param = ((arraybinding) parameters[lastindex]).elementstype();
for (int i = lastindex; i < arglength; i++) {
typebinding arg = arguments[i];
if (param != arg && parametercompatibilitylevel(arg, param, env) == not_compatible)
return not_compatible;
}
}  else if (lastindex != arglength) { // can call foo(int i, x ... x) with foo(1) but not foo();
return not_compatible;
}
level = varargs_compatible; // varargs support needed
}
} else if (paramlength != arglength) {
return not_compatible;
}
// now compare standard arguments from 0 to lastindex
for (int i = 0; i < lastindex; i++) {
typebinding param = parameters[i];
typebinding arg = arguments[i];
if (arg != param) {
int newlevel = parametercompatibilitylevel(arg, param, env);
if (newlevel == not_compatible)
return not_compatible;
if (newlevel > level)
level = newlevel;
}
}
return level;
}

private int parametercompatibilitylevel(typebinding arg, typebinding param, lookupenvironment env) {
// only called if env.options.sourcelevel >= classfileconstants.jdk1_5
if (arg.iscompatiblewith(param))
return compatible;
if (arg.isbasetype() != param.isbasetype()) {
typebinding convertedtype = env.computeboxingtype(arg);
if (convertedtype == param || convertedtype.iscompatiblewith(param))
return autobox_compatible;
}
return not_compatible;
}

public abstract problemreporter problemreporter();

public final compilationunitdeclaration referencecompilationunit() {
scope scope, unitscope = this;
while ((scope = unitscope.parent) != null)
unitscope = scope;
return ((compilationunitscope) unitscope).referencecontext;
}

/**
* returns the nearest reference context, starting from current scope.
* if starting on a class, it will return current class. if starting on unitscope, returns unit.
*/
public referencecontext referencecontext() {
scope current = this;
do {
switch(current.kind) {
case method_scope :
return ((methodscope) current).referencecontext;
case class_scope :
return ((classscope) current).referencecontext;
case compilation_unit_scope :
return ((compilationunitscope) current).referencecontext;
}
} while ((current = current.parent) != null);
return null;
}

public void deferboundcheck(typereference typeref) {
if (this.kind == class_scope) {
classscope classscope = (classscope) this;
if (classscope.deferredboundchecks == null) {
classscope.deferredboundchecks = new arraylist(3);
classscope.deferredboundchecks.add(typeref);
} else if (!classscope.deferredboundchecks.contains(typeref)) {
classscope.deferredboundchecks.add(typeref);
}
}
}

// start position in this scope - for ordering scopes vs. variables
int startindex() {
return 0;
}
}
