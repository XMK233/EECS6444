/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class postfixexpression extends compoundassignment {

public postfixexpression(expression lhs, expression expression, int operator, int pos) {
super(lhs, expression, operator, pos);
this.sourcestart = lhs.sourcestart;
this.sourceend = pos;
}
public boolean checkcastcompatibility() {
return false;
}
/**
* code generation for postfixexpression
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
// various scenarii are possible, setting an array reference,
// a field reference, a blank final field reference, a field of an enclosing instance or
// just a local variable.

int pc = codestream.position;
((reference) this.lhs).generatepostincrement(currentscope, codestream, this, valuerequired);
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public string operatortostring() {
switch (this.operator) {
case plus :
return "++"; //$non-nls-1$
case minus :
return "--"; //$non-nls-1$
}
return "unknown operator"; //$non-nls-1$
}

public stringbuffer printexpressionnoparenthesis(int indent, stringbuffer output) {
return this.lhs.printexpression(indent, output).append(' ').append(operatortostring());
}

public boolean restrainusagetonumerictypes() {
return true;
}

public void traverse(astvisitor visitor, blockscope scope) {

if (visitor.visit(this, scope)) {
this.lhs.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
