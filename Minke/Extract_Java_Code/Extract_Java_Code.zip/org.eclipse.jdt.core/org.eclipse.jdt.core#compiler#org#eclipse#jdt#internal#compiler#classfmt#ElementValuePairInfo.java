/*******************************************************************************
* copyright (c) 2005, 2007 bea systems, inc.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*    tyeung@@bea.com - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.classfmt;

public class elementvaluepairinfo implements org.eclipse.jdt.internal.compiler.env.ibinaryelementvaluepair {

static final elementvaluepairinfo[] nomembers = new elementvaluepairinfo[0];

private char[] name;
private object value;

elementvaluepairinfo(char[] name, object value) {
this.name = name;
this.value = value;
}
public char[] getname() {
return this.name;
}
public object getvalue() {
return this.value;
}
public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append(this.name);
buffer.append('=');
if (this.value instanceof object[]) {
final object[] values = (object[]) this.value;
buffer.append('{');
for (int i = 0, l = values.length; i < l; i++) {
if (i > 0)
buffer.append(", "); //$non-nls-1$
buffer.append(values[i]);
}
buffer.append('}');
} else {
buffer.append(this.value);
}
return buffer.tostring();
}
}
