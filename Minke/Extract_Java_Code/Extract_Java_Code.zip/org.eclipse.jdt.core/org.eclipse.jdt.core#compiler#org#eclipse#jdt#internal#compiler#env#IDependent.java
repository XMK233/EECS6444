/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

/**
* this represents the target file of a type dependency.
*
* all implementors of this interface are containers for types or types
* themselves which must be able to identify their source file name
* when file dependencies are collected.
*/
public interface idependent {
char jar_file_entry_separator = '|';
/**
* answer the file name which defines the type.
*
* the path part (optional) must be separated from the actual
* file proper name by a separator suitable for the type (java.io.file.separator for example),
* e.g.
*  "c:\\source\\com\\p\\x.java" or
*  "/com/p/y.java".
*
* the path to the zip or jar file (optional) must be separated
* from the actual path part by jar_file_entry_separator,
* e.g.
*  "c:\\lib\\some.jar|/com/p/x.class" or
*  "/lib/some.zip|/com/q/y.class".
*
* the proper file name includes the suffix extension (e.g.&nbsp;".java")
* e.g.&nbsp;"c:/org/eclipse/jdt/internal/compileri/env/idependent.java"
*
* return null if no file defines the type.
*/

char[] getfilename();
}
