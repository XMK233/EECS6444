/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser;

public class nlstag {

public int start;
public int end;
public int linenumber;
public int index;

public nlstag(int start, int end, int linenumber, int index) {
this.start = start;
this.end = end;
this.linenumber = linenumber;
this.index = index;
}

public string tostring() {
return "nlstag(" + this.start + "," + this.end + "," + this.linenumber + ")"; //$non-nls-1$//$non-nls-2$//$non-nls-3$//$non-nls-4$
}
}
