/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;

public class singletypereference extends typereference {

public char[] token;

public singletypereference(char[] source, long pos) {

this.token = source;
this.sourcestart = (int) (pos>>>32)  ;
this.sourceend = (int) (pos & 0x00000000ffffffffl) ;

}

public typereference copydims(int dim){
//return a type reference copy of me with some dimensions
//warning : the new type ref has a null binding

return new arraytypereference(this.token, dim,(((long)this.sourcestart)<<32)+this.sourceend);
}

public char[] getlasttoken() {
return this.token;
}
protected typebinding gettypebinding(scope scope) {
if (this.resolvedtype != null)
return this.resolvedtype;

this.resolvedtype = scope.gettype(this.token);

if (scope.kind == scope.class_scope && this.resolvedtype.isvalidbinding())
if (((classscope) scope).detecthierarchycycle(this.resolvedtype, this))
return null;
return this.resolvedtype;
}

public char [][] gettypename() {
return new char[][] { this.token };
}

public stringbuffer printexpression(int indent, stringbuffer output){

return output.append(this.token);
}

public typebinding resolvetypeenclosing(blockscope scope, referencebinding enclosingtype) {
typebinding membertype = this.resolvedtype = scope.getmembertype(this.token, enclosingtype);
boolean haserror = false;
if (!membertype.isvalidbinding()) {
haserror = true;
scope.problemreporter().invalidenclosingtype(this, membertype, enclosingtype);
membertype = ((referencebinding)membertype).closestmatch();
if (membertype == null) {
return null;
}
}
if (istypeusedeprecated(membertype, scope))
reportdeprecatedtype(membertype, scope);
membertype = scope.environment().converttorawtype(membertype, false /*do not force conversion of enclosing types*/);
if (membertype.israwtype()
&& (this.bits & ignorerawtypecheck) == 0
&& scope.compileroptions().getseverity(compileroptions.rawtypereference) != problemseverities.ignore){
scope.problemreporter().rawtypereference(this, membertype);
}
if (haserror) {
// do not store the computed type, keep the problem type instead
return membertype;
}
return this.resolvedtype = membertype;
}

public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
