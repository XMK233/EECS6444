/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public abstract class branchstatement extends statement {

public char[] label;
public branchlabel targetlabel;
public subroutinestatement[] subroutines;
public int initstateindex = -1;

/**
* branchstatement constructor comment.
*/
public branchstatement(char[] label, int sourcestart,int sourceend) {
this.label = label ;
this.sourcestart = sourcestart;
this.sourceend = sourceend;
}

/**
* branch code generation
*
*   generate the finallyinvocationsequence.
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & astnode.isreachable) == 0) {
return;
}
int pc = codestream.position;

// generation of code responsible for invoking the finally
// blocks in sequence
if (this.subroutines != null){
for (int i = 0, max = this.subroutines.length; i < max; i++){
subroutinestatement sub = this.subroutines[i];
boolean didescape = sub.generatesubroutineinvocation(currentscope, codestream, this.targetlabel, this.initstateindex, null);
if (didescape) {
codestream.recordpositionsfrom(pc, this.sourcestart);
subroutinestatement.reenterallexceptionhandlers(this.subroutines, i, codestream);
if (this.initstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.initstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.initstateindex);
}
return;
}
}
}
codestream.goto_(this.targetlabel);
codestream.recordpositionsfrom(pc, this.sourcestart);
subroutinestatement.reenterallexceptionhandlers(this.subroutines, -1, codestream);
if (this.initstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.initstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.initstateindex);
}
}

public void resolve(blockscope scope) {
// nothing to do during name resolution
}
}
