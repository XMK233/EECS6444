/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.caselabel;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.impl.intconstant;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class casestatement extends statement {

public expression constantexpression;
public caselabel targetlabel;

public casestatement(expression constantexpression, int sourceend, int sourcestart) {
this.constantexpression = constantexpression;
this.sourceend = sourceend;
this.sourcestart = sourcestart;
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {

if (this.constantexpression != null) {
if (this.constantexpression.constant == constant.notaconstant
&& !this.constantexpression.resolvedtype.isenum()) {
currentscope.problemreporter().caseexpressionmustbeconstant(this.constantexpression);
}
this.constantexpression.analysecode(currentscope, flowcontext, flowinfo);
}
return flowinfo;
}

public stringbuffer printstatement(int tab, stringbuffer output) {
printindent(tab, output);
if (this.constantexpression == null) {
output.append("default : "); //$non-nls-1$
} else {
output.append("case "); //$non-nls-1$
this.constantexpression.printexpression(0, output).append(" : "); //$non-nls-1$
}
return output.append(';');
}

/**
* case code generation
*
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & astnode.isreachable) == 0) {
return;
}
int pc = codestream.position;
this.targetlabel.place();
codestream.recordpositionsfrom(pc, this.sourcestart);
}

/**
* no-op : should use resolvecase(...) instead.
*/
public void resolve(blockscope scope) {
// no-op : should use resolvecase(...) instead.
}

/**
* returns the constant intvalue or ordinal for enum constants. if constant is notaconstant, then answers float.min_value
* @@see org.eclipse.jdt.internal.compiler.ast.statement#resolvecase(org.eclipse.jdt.internal.compiler.lookup.blockscope, org.eclipse.jdt.internal.compiler.lookup.typebinding, org.eclipse.jdt.internal.compiler.ast.switchstatement)
*/
public constant resolvecase(blockscope scope, typebinding switchexpressiontype, switchstatement switchstatement) {
// switchexpressiontype maybe null in error case
scope.enclosingcase = this; // record entering in a switch case block

if (this.constantexpression == null) {
// remember the default case into the associated switch statement
if (switchstatement.defaultcase != null)
scope.problemreporter().duplicatedefaultcase(this);

// on error the last default will be the selected one ...
switchstatement.defaultcase = this;
return constant.notaconstant;
}
// add into the collection of cases of the associated switch statement
switchstatement.cases[switchstatement.casecount++] = this;
// tag constant name with enum type for privileged access to its members
if (switchexpressiontype != null && switchexpressiontype.isenum() && (this.constantexpression instanceof singlenamereference)) {
((singlenamereference) this.constantexpression).setactualreceivertype((referencebinding)switchexpressiontype);
}
typebinding casetype = this.constantexpression.resolvetype(scope);
if (casetype == null || switchexpressiontype == null) return constant.notaconstant;
if (this.constantexpression.isconstantvalueoftypeassignabletotype(casetype, switchexpressiontype)
|| casetype.iscompatiblewith(switchexpressiontype)) {
if (casetype.isenum()) {
if (((this.constantexpression.bits & astnode.parenthesizedmask) >> astnode.parenthesizedshift) != 0) {
scope.problemreporter().enumconstantscannotbesurroundedbyparenthesis(this.constantexpression);
}

if (this.constantexpression instanceof namereference
&& (this.constantexpression.bits & astnode.restrictiveflagmask) == binding.field) {
namereference reference = (namereference) this.constantexpression;
fieldbinding field = reference.fieldbinding();
if ((field.modifiers & classfileconstants.accenum) == 0) {
scope.problemreporter().enumswitchcannottargetfield(reference, field);
} else 	if (reference instanceof qualifiednamereference) {
scope.problemreporter().cannotusequalifiedenumconstantincaselabel(reference, field);
}
return intconstant.fromvalue(field.original().id + 1); // (ordinal value + 1) zero should not be returned see bug 141810
}
} else {
return this.constantexpression.constant;
}
} else if (isboxingcompatible(casetype, switchexpressiontype, this.constantexpression, scope)) {
// constantexpression.computeconversion(scope, casetype, switchexpressiontype); - do not report boxing/unboxing conversion
return this.constantexpression.constant;
}
scope.problemreporter().typemismatcherror(casetype, switchexpressiontype, this.constantexpression, switchstatement.expression);
return constant.notaconstant;
}

public void traverse(astvisitor visitor, 	blockscope blockscope) {
if (visitor.visit(this, blockscope)) {
if (this.constantexpression != null) this.constantexpression.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}
}
