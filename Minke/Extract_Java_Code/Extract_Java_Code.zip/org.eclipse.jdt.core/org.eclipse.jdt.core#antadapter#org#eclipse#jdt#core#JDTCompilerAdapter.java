/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.core;

import java.io.file;
import java.io.ioexception;
import java.io.printwriter;
import java.lang.reflect.constructor;
import java.lang.reflect.invocationtargetexception;
import java.lang.reflect.method;
import java.util.arraylist;
import java.util.arrays;
import java.util.comparator;
import java.util.hashmap;
import java.util.list;
import java.util.map;

import org.apache.tools.ant.buildexception;
import org.apache.tools.ant.project;
import org.apache.tools.ant.taskdefs.javac;
import org.apache.tools.ant.taskdefs.compilers.defaultcompileradapter;
import org.apache.tools.ant.types.commandline;
import org.apache.tools.ant.types.path;
import org.apache.tools.ant.types.commandline.argument;
import org.apache.tools.ant.util.javaenvutils;
import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.antadapter.antadaptermessages;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.util.suffixconstants;
import org.eclipse.jdt.internal.compiler.util.util;

/**
* ant 1.5 compiler adapter for the eclipse java compiler. this adapter permits the
* eclipse java compiler to be used with the <code>javac</code> task in ant scripts. in order
* to use it, just set the property <code>build.compiler</code> as follows:
* <p>
* <code>&lt;property name="build.compiler" value="org.eclipse.jdt.core.jdtcompileradapter"/&gt;</code>
* </p>
* <p>
* for more information on ant check out the website at http://jakarta.apache.org/ant/ .
* </p>
*
* @@since 2.0
*/
public class jdtcompileradapter extends defaultcompileradapter {
private static final char[] separator_chars = new char[] { '/', '\\' };
private static final char[] adapter_prefix = "#adapter#".tochararray(); //$non-nls-1$
private static final char[] adapter_encoding = "encoding#".tochararray(); //$non-nls-1$
private static final char[] adapter_access = "access#".tochararray(); //$non-nls-1$
private static string compilerclass = "org.eclipse.jdt.internal.compiler.batch.main"; //$non-nls-1$
string logfilename;
map customdefaultoptions;
private map fileencodings = null;
private map direncodings = null;
private list accessrules = null;

/**
* performs a compile using the jdt batch compiler
* @@throws buildexception if anything wrong happen during the compilation
* @@return boolean true if the compilation is ok, false otherwise
*/
public boolean execute() throws buildexception {
this.attributes.log(antadaptermessages.getstring("ant.jdtadapter.info.usingjdtcompiler"), project.msg_verbose); //$non-nls-1$
commandline cmd = setupjavaccommand();

try {
class c = class.forname(compilerclass);
constructor batchcompilerconstructor = c.getconstructor(new class[] { printwriter.class, printwriter.class, boolean.type, map.class});
object batchcompilerinstance = batchcompilerconstructor.newinstance(new object[] {new printwriter(system.out), new printwriter(system.err), boolean.true, this.customdefaultoptions});
method compile = c.getmethod("compile", new class[] {string[].class}); //$non-nls-1$
object result = compile.invoke(batchcompilerinstance, new object[] { cmd.getarguments()});
final boolean resultvalue = ((boolean) result).booleanvalue();
if (!resultvalue && this.logfilename != null) {
this.attributes.log(antadaptermessages.getstring("ant.jdtadapter.error.compilationfailed", this.logfilename)); //$non-nls-1$
}
return resultvalue;
} catch (classnotfoundexception cnfe) {
throw new buildexception(antadaptermessages.getstring("ant.jdtadapter.error.cannotfindjdtcompiler")); //$non-nls-1$
} catch (exception ex) {
throw new buildexception(ex);
}
}


protected commandline setupjavaccommand() throws buildexception {
commandline cmd = new commandline();
this.customdefaultoptions = new compileroptions().getmap();

class javacclass = javac.class;

/*
* read in the compiler arguments first since we might need to modify
* the classpath if any access rules were specified
*/
string [] compilerargs = processcompilerarguments(javacclass);

/*
* this option is used to never exit at the end of the ant task.
*/
cmd.createargument().setvalue("-noexit"); //$non-nls-1$

if (this.bootclasspath != null) {
cmd.createargument().setvalue("-bootclasspath"); //$non-nls-1$
if (this.bootclasspath.size() != 0) {
/*
* set the bootclasspath for the eclipse compiler.
*/
cmd.createargument().setpath(this.bootclasspath);
} else {
cmd.createargument().setvalue(util.empty_string);
}
}

path classpath = new path(this.project);

/*
* eclipse compiler doesn't support -extdirs.
* it is emulated using the classpath. we add extdirs entries after the
* bootclasspath.
*/
if (this.extdirs != null) {
cmd.createargument().setvalue("-extdirs"); //$non-nls-1$
cmd.createargument().setpath(this.extdirs);
}

/*
* the java runtime is already handled, so we simply want to retrieve the
* ant runtime and the compile classpath.
*/
classpath.append(getcompileclasspath());

// for -sourcepath, use the "sourcepath" value if present.
// otherwise default to the "srcdir" value.
path sourcepath = null;

// retrieve the method getsourcepath() using reflect
// this is done to improve the compatibility to ant 1.5
method getsourcepathmethod = null;
try {
getsourcepathmethod = javacclass.getmethod("getsourcepath", null); //$non-nls-1$
} catch(nosuchmethodexception e) {
// if not found, then we cannot use this method (ant 1.5)
}
path compilesourcepath = null;
if (getsourcepathmethod != null) {
try {
compilesourcepath = (path) getsourcepathmethod.invoke(this.attributes, null);
} catch (illegalaccessexception e) {
// should never happen
} catch (invocationtargetexception e) {
// should never happen
}
}
if (compilesourcepath != null) {
sourcepath = compilesourcepath;
} else {
sourcepath = this.src;
}
classpath.append(sourcepath);
/*
* set the classpath for the eclipse compiler.
*/
cmd.createargument().setvalue("-classpath"); //$non-nls-1$
createclasspathargument(cmd, classpath);

final string javaversion = javaenvutils.getjavaversion();
string memoryparameterprefix = javaversion.equals(javaenvutils.java_1_1) ? "-j-" : "-j-x";//$non-nls-1$//$non-nls-2$
if (this.memoryinitialsize != null) {
if (!this.attributes.isforkedjavac()) {
this.attributes.log(antadaptermessages.getstring("ant.jdtadapter.info.ignoringmemoryinitialsize"), project.msg_warn); //$non-nls-1$
} else {
cmd.createargument().setvalue(memoryparameterprefix
+ "ms" + this.memoryinitialsize); //$non-nls-1$
}
}

if (this.memorymaximumsize != null) {
if (!this.attributes.isforkedjavac()) {
this.attributes.log(antadaptermessages.getstring("ant.jdtadapter.info.ignoringmemorymaximumsize"), project.msg_warn); //$non-nls-1$
} else {
cmd.createargument().setvalue(memoryparameterprefix
+ "mx" + this.memorymaximumsize); //$non-nls-1$
}
}

if (this.debug) {
// retrieve the method getsourcepath() using reflect
// this is done to improve the compatibility to ant 1.5
method getdebuglevelmethod = null;
try {
getdebuglevelmethod = javacclass.getmethod("getdebuglevel", null); //$non-nls-1$
} catch(nosuchmethodexception e) {
// if not found, then we cannot use this method (ant 1.5)
// debug level is only available with ant 1.5.x
}
string debuglevel = null;
if (getdebuglevelmethod != null) {
try {
debuglevel = (string) getdebuglevelmethod.invoke(this.attributes, null);
} catch (illegalaccessexception e) {
// should never happen
} catch (invocationtargetexception e) {
// should never happen
}
}
if (debuglevel != null) {
this.customdefaultoptions.put(compileroptions.option_localvariableattribute, compileroptions.do_not_generate);
this.customdefaultoptions.put(compileroptions.option_linenumberattribute, compileroptions.do_not_generate);
this.customdefaultoptions.put(compileroptions.option_sourcefileattribute , compileroptions.do_not_generate);
if (debuglevel.length() != 0) {
if (debuglevel.indexof("vars") != -1) {//$non-nls-1$
this.customdefaultoptions.put(compileroptions.option_localvariableattribute, compileroptions.generate);
}
if (debuglevel.indexof("lines") != -1) {//$non-nls-1$
this.customdefaultoptions.put(compileroptions.option_linenumberattribute, compileroptions.generate);
}
if (debuglevel.indexof("source") != -1) {//$non-nls-1$
this.customdefaultoptions.put(compileroptions.option_sourcefileattribute , compileroptions.generate);
}
}
} else {
this.customdefaultoptions.put(compileroptions.option_localvariableattribute, compileroptions.generate);
this.customdefaultoptions.put(compileroptions.option_linenumberattribute, compileroptions.generate);
this.customdefaultoptions.put(compileroptions.option_sourcefileattribute , compileroptions.generate);
}
} else {
this.customdefaultoptions.put(compileroptions.option_localvariableattribute, compileroptions.do_not_generate);
this.customdefaultoptions.put(compileroptions.option_linenumberattribute, compileroptions.do_not_generate);
this.customdefaultoptions.put(compileroptions.option_sourcefileattribute , compileroptions.do_not_generate);
}

/*
* handle the nowarn option. if none, then we generate all warnings.
*/
if (this.attributes.getnowarn()) {
// disable all warnings
object[] entries = this.customdefaultoptions.entryset().toarray();
for (int i = 0, max = entries.length; i < max; i++) {
map.entry entry = (map.entry) entries[i];
if (!(entry.getkey() instanceof string))
continue;
if (!(entry.getvalue() instanceof string))
continue;
if (((string) entry.getvalue()).equals(compileroptions.warning)) {
this.customdefaultoptions.put(entry.getkey(), compileroptions.ignore);
}
}
this.customdefaultoptions.put(compileroptions.option_tasktags, util.empty_string);
if (this.deprecation) {
this.customdefaultoptions.put(compileroptions.option_reportdeprecation, compileroptions.warning);
this.customdefaultoptions.put(compileroptions.option_reportdeprecationindeprecatedcode, compileroptions.enabled);
this.customdefaultoptions.put(compileroptions.option_reportdeprecationwhenoverridingdeprecatedmethod, compileroptions.enabled);
}
} else if (this.deprecation) {
this.customdefaultoptions.put(compileroptions.option_reportdeprecation, compileroptions.warning);
this.customdefaultoptions.put(compileroptions.option_reportdeprecationindeprecatedcode, compileroptions.enabled);
this.customdefaultoptions.put(compileroptions.option_reportdeprecationwhenoverridingdeprecatedmethod, compileroptions.enabled);
} else {
this.customdefaultoptions.put(compileroptions.option_reportdeprecation, compileroptions.ignore);
this.customdefaultoptions.put(compileroptions.option_reportdeprecationindeprecatedcode, compileroptions.disabled);
this.customdefaultoptions.put(compileroptions.option_reportdeprecationwhenoverridingdeprecatedmethod, compileroptions.disabled);
}

/*
* destdir option.
*/
if (this.destdir != null) {
cmd.createargument().setvalue("-d"); //$non-nls-1$
cmd.createargument().setfile(this.destdir.getabsolutefile());
}

/*
* verbose option
*/
if (this.verbose) {
cmd.createargument().setvalue("-verbose"); //$non-nls-1$
}

/*
* failnoerror option
*/
if (!this.attributes.getfailonerror()) {
cmd.createargument().setvalue("-proceedonerror"); //$non-nls-1$
}

/*
* target option.
*/
if (this.target != null) {
this.customdefaultoptions.put(compileroptions.option_targetplatform, this.target);
}

/*
* source option
*/
string source = this.attributes.getsource();
if (source != null) {
this.customdefaultoptions.put(compileroptions.option_source, source);
}

if (compilerargs != null) {
/*
* add extra argument on the command line
*/
final int length = compilerargs.length;
if (length != 0) {
for (int i = 0, max = length; i < max; i++) {
string arg = compilerargs[i];
if (this.logfilename == null && "-log".equals(arg) && ((i + 1) < max)) { //$non-nls-1$
this.logfilename = compilerargs[i + 1];
}
cmd.createargument().setvalue(arg);
}
}
}
/*
* encoding option. javac task encoding property must be the last encoding on the command
* line as compiler arg might also specify an encoding.
*/
if (this.encoding != null) {
cmd.createargument().setvalue("-encoding"); //$non-nls-1$
cmd.createargument().setvalue(this.encoding);
}

/*
* eclipse compiler doesn't have a -sourcepath option. this is
* handled through the javac task that collects all source files in
* srcdir option.
*/
logandaddfilestocompile(cmd);
return cmd;
}

/**
* get the compiler arguments
* @@param javacclass
* @@return string[] the array of arguments
*/
private string[] processcompilerarguments(class javacclass) {
// retrieve the method getcurrentcompilerargs() using reflect
// this is done to improve the compatibility to ant 1.5
method getcurrentcompilerargsmethod = null;
try {
getcurrentcompilerargsmethod = javacclass.getmethod("getcurrentcompilerargs", null); //$non-nls-1$
} catch (nosuchmethodexception e) {
// if not found, then we cannot use this method (ant 1.5)
// debug level is only available with ant 1.5.x
}
string[] compilerargs = null;
if (getcurrentcompilerargsmethod != null) {
try {
compilerargs = (string[]) getcurrentcompilerargsmethod.invoke(this.attributes, null);
} catch (illegalaccessexception e) {
// should never happen
} catch (invocationtargetexception e) {
// should never happen
}
}
//check the compiler arguments for anything requiring extra processing
if (compilerargs != null) checkcompilerargs(compilerargs);
return compilerargs;
}
/**
* check the compiler arguments.
* extract from files specified using @@, lines marked with adapter_prefix
* these lines specify information that needs to be interpreted by us.
* @@param args compiler arguments to process
*/
private void checkcompilerargs(string[] args) {
for (int i = 0; i < args.length; i++) {
if (args[i].charat(0) == '@@') {
try {
char[] content = util.getfilecharcontent(new file(args[i].substring(1)), null);
int offset = 0;
int prefixlength = adapter_prefix.length;
while ((offset = charoperation.indexof(adapter_prefix, content, true, offset)) > -1) {
int start = offset + prefixlength;
int end = charoperation.indexof('\n', content, start);
if (end == -1)
end = content.length;
while (charoperation.iswhitespace(content[end])) {
end--;
}

// end is inclusive, but in the api end is exclusive
if (charoperation.equals(adapter_encoding, content, start, start + adapter_encoding.length)) {
charoperation.replace(content, separator_chars, file.separatorchar, start, end + 1);
// file or folder level custom encoding
start += adapter_encoding.length;
int encodestart = charoperation.lastindexof('[', content, start, end);
if (start < encodestart && encodestart < end) {
boolean isfile = charoperation.equals(suffixconstants.suffix_java, content, encodestart - 5, encodestart, false);

string str = string.valueof(content, start, encodestart - start);
string enc = string.valueof(content, encodestart, end - encodestart + 1);
if (isfile) {
if (this.fileencodings == null)
this.fileencodings = new hashmap();
//use file to translate the string into a path with the correct file.seperator
this.fileencodings.put(str, enc);
} else {
if (this.direncodings == null)
this.direncodings = new hashmap();
this.direncodings.put(str, enc);
}
}
} else if (charoperation.equals(adapter_access, content, start, start + adapter_access.length)) {
// access rules for the classpath
start += adapter_access.length;
int accessstart = charoperation.indexof('[', content, start, end);
charoperation.replace(content, separator_chars, file.separatorchar, start, accessstart);
if (start < accessstart && accessstart < end) {
string path = string.valueof(content, start, accessstart - start);
string access = string.valueof(content, accessstart, end - accessstart + 1);
if (this.accessrules == null)
this.accessrules = new arraylist();
this.accessrules.add(path);
this.accessrules.add(access);
}
}
offset = end;
}
} catch (ioexception e) {
//ignore
}
}
}

}

/**
* copy the classpath to the command line with access rules included.
* @@param cmd the given command line
* @@param classpath the given classpath entry
*/
private void createclasspathargument(commandline cmd, path classpath) {
argument arg = cmd.createargument();
final string[] pathelements = classpath.list();

// empty path return empty string
if (pathelements.length == 0) {
arg.setvalue(util.empty_string);
return;
}

// no access rules, can set the path directly
if (this.accessrules == null) {
arg.setpath(classpath);
return;
}

int ruleslength = this.accessrules.size();
string[] rules = (string[]) this.accessrules.toarray(new string[ruleslength]);
int nextrule = 0;
final stringbuffer result = new stringbuffer();

//access rules are expected in the same order as the classpath, but there could
//be elements in the classpath not in the access rules or access rules not in the classpath
for (int i = 0, max = pathelements.length; i < max; i++) {
if (i > 0)
result.append(file.pathseparatorchar);
string pathelement = pathelements[i];
result.append(pathelement);
//the rules list is [path, rule, path, rule, ...]
for (int j = nextrule; j < ruleslength; j += 2) {
string rule = rules[j];
if (pathelement.endswith(rule)) {
result.append(rules[j + 1]);
nextrule = j + 2;
break;
}
// if the path doesn't match, it could be due to a trailing file separatorchar in the rule
if (rule.endswith(file.separator)) {
// rule ends with the file.separator, but pathelement might not
// otherwise it would match on the first endswith
int rulelength = rule.length();
if (pathelement.regionmatches(false, pathelement.length() - rulelength + 1, rule, 0, rulelength - 1)) {
result.append(rules[j + 1]);
nextrule = j + 2;
break;
}
} else if (pathelement.endswith(file.separator)) {
// rule doesn't end with the file.separator, but pathelement might
int rulelength = rule.length();
if (pathelement.regionmatches(false, pathelement.length() - rulelength - 1, rule, 0, rulelength)) {
result.append(rules[j + 1]);
nextrule = j + 2;
break;
}
}
}
}

arg.setvalue(result.tostring());
}
/**
* modified from base class, logs the compilation parameters, adds the files
* to compile and logs the &quot;nicesourcelist&quot;
* appends encoding information at the end of arguments
*
* @@param cmd the given command line
*/
protected void logandaddfilestocompile(commandline cmd) {
this.attributes.log("compilation " + cmd.describearguments(), //$non-nls-1$
project.msg_verbose);

stringbuffer nicesourcelist = new stringbuffer("file"); //$non-nls-1$
if (this.compilelist.length != 1) {
nicesourcelist.append("s"); //$non-nls-1$
}
nicesourcelist.append(" to be compiled:"); //$non-nls-1$
nicesourcelist.append(lsep);

string[] encodedfiles = null, encodeddirs = null;
int encodedfileslength = 0, encodeddirslength = 0;
if (this.fileencodings != null) {
encodedfileslength = this.fileencodings.size();
encodedfiles = new string[encodedfileslength];
this.fileencodings.keyset().toarray(encodedfiles);
}
if (this.direncodings != null) {
encodeddirslength = this.direncodings.size();
encodeddirs = new string[encodeddirslength];
this.direncodings.keyset().toarray(encodeddirs);
//we need the directories sorted, longest first,since sub directories can
//override encodings for their parent directories
comparator comparator = new comparator() {
public int compare(object o1, object o2) {
return ((string) o2).length() - ((string) o1).length();
}
};
arrays.sort(encodeddirs, comparator);
}

for (int i = 0; i < this.compilelist.length; i++) {
string arg = this.compilelist[i].getabsolutepath();
boolean encoded = false;
if (encodedfiles != null) {
//check for file level custom encoding
for (int j = 0; j < encodedfileslength; j++) {
if (arg.endswith(encodedfiles[j])) {
//found encoding, remove it from the list to speed things up next time around
arg = arg + (string) this.fileencodings.get(encodedfiles[j]);
if (j < encodedfileslength - 1) {
system.arraycopy(encodedfiles, j + 1, encodedfiles, j, encodedfileslength - j - 1);
}
encodedfiles[--encodedfileslength] = null;
encoded = true;
break;
}
}
}
if (!encoded && encodeddirs != null) {
//check folder level custom encoding
for (int j = 0; j < encodeddirslength; j++) {
if (arg.lastindexof(encodeddirs[j]) != -1) {
arg = arg + (string) this.direncodings.get(encodeddirs[j]);
break;
}
}
}
cmd.createargument().setvalue(arg);
nicesourcelist.append("    " + arg + lsep); //$non-nls-1$
}

this.attributes.log(nicesourcelist.tostring(), project.msg_verbose);
}
}
