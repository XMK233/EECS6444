/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.ast.singlenamereference;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class completiononkeyword3 extends singlenamereference implements completiononkeyword{
private char[][] possiblekeywords;
public completiononkeyword3(char[] token, long pos, char[] possiblekeyword) {
this(token, pos, new char[][]{possiblekeyword});
}
public completiononkeyword3(char[] token, long pos, char[][] possiblekeywords) {
super(token, pos);
this.token = token;
this.possiblekeywords = possiblekeywords;
}
public boolean cancompleteemptytoken() {
return false;
}
public char[] gettoken() {
return this.token;
}
public char[][] getpossiblekeywords() {
return this.possiblekeywords;
}
public stringbuffer printexpression(int indent, stringbuffer output) {

return output.append("<completeonkeyword:").append(this.token).append('>'); //$non-nls-1$
}
public typebinding resolvetype(blockscope scope) {
throw new completionnodefound(this, scope);
}
}
