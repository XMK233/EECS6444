/*******************************************************************************
* copyright (c) 2005, 2007 bea systems, inc.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*    tyeung@@bea.com - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.env;

/**
* represents a class reference in the class file.
* one of the possible results for the default value of an annotation method or an element value pair.
*/
public class classsignature {

char[] classname;

public classsignature(final char[] classname) {
this.classname = classname;
}

/**
* @@return name of the type in the class file format
*/
public char[] gettypename() {
return this.classname;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append(this.classname);
buffer.append(".class"); //$non-nls-1$
return buffer.tostring();
}
}@


1.1
log
@merged apt branch
