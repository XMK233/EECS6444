/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.parser;

import java.util.list;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.invalidinputexception;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.util.util;

/**
* parser specialized for decoding javadoc comments
*/
public class javadocparser extends abstractcommentparser {

// public fields
public javadoc doccomment;

// bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=51600
// store param references for tag with invalid syntax
private int invalidparamreferencesptr = -1;
private astnode[] invalidparamreferencesstack;

// bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=153399
// store value tag positions
private long validvaluepositions, invalidvaluepositions;

// returns whether this javadocparser should report errors or not (overrides reportproblems)
// see "https://bugs.eclipse.org/bugs/show_bug.cgi?id=192449"
public boolean shouldreportproblems = true;

// flag to let the parser know that the current tag is waiting for a description
// see "https://bugs.eclipse.org/bugs/show_bug.cgi?id=222900"
private int tagwaitingfordescription;

public javadocparser(parser sourceparser) {
super(sourceparser);
this.kind = compil_parser | text_verif;
}

/* (non-javadoc)
* returns true if tag @@deprecated is present in javadoc comment.
*
* if javadoc checking is enabled, will also construct an javadoc node, which will be stored into parser.javadoc
* slot for being consumed later on.
*/
public boolean checkdeprecation(int commentptr) {

// store javadoc positions
this.javadocstart = this.sourceparser.scanner.commentstarts[commentptr];
this.javadocend = this.sourceparser.scanner.commentstops[commentptr]-1;
this.firsttagposition = this.sourceparser.scanner.commenttagstarts[commentptr];
this.validvaluepositions = -1;
this.invalidvaluepositions = -1;
this.tagwaitingfordescription = no_tag_value;

// init javadoc if necessary
if (this.checkdoccomment) {
this.doccomment = new javadoc(this.javadocstart, this.javadocend);
} else {
this.doccomment = null;
}

// if there's no tag in javadoc, return without parsing it
if (this.firsttagposition == 0) {
switch (this.kind & parser_kind) {
case compil_parser:
case source_parser:
return false;
}
}

// parse
try {
this.source = this.sourceparser.scanner.source;
if (this.checkdoccomment) {
// initialization
this.scanner.lineends = this.sourceparser.scanner.lineends;
this.scanner.lineptr = this.sourceparser.scanner.lineptr;
this.lineends = this.scanner.lineends;
commentparse();
} else {

// parse comment
scanner sourcescanner = this.sourceparser.scanner;
int firstlinenumber = util.getlinenumber(this.javadocstart, sourcescanner.lineends, 0, sourcescanner.lineptr);
int lastlinenumber = util.getlinenumber(this.javadocend, sourcescanner.lineends, 0, sourcescanner.lineptr);
this.index = this.javadocstart +3;

// scan line per line, since tags must be at beginning of lines only
this.deprecated = false;
nextline : for (int line = firstlinenumber; line <= lastlinenumber; line++) {
int linestart = line == firstlinenumber
? this.javadocstart + 3 // skip leading /**
: this.sourceparser.scanner.getlinestart(line);
this.index = linestart;
this.lineend = line == lastlinenumber
? this.javadocend - 2 // remove trailing * /
: this.sourceparser.scanner.getlineend(line);
nextcharacter : while (this.index < this.lineend) {
char c = readchar(); // consider unicodes
switch (c) {
case '*' :
case '\u000c' :	/* form feed               */
case ' ' :			/* space                   */
case '\t' :			/* horizontal tabulation   */
case '\n' :			/* line feed   */
case '\r' :			/* cr */
// do nothing for space or '*' characters
continue nextcharacter;
case '@@' :
parsesimpletag();
if (this.tagvalue == tag_deprecated_value) {
if (this.abort) break nextcharacter;
}
}
continue nextline;
}
}
return this.deprecated;
}
} finally {
this.source = null; // release source as soon as finished
}
return this.deprecated;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#createargumentreference(char[], java.lang.object, int)
*/
protected object createargumentreference(char[] name, int dim, boolean isvarargs, object typeref, long[] dimpositions, long argnamepos) throws invalidinputexception {
try {
typereference argtyperef = (typereference) typeref;
if (dim > 0) {
long pos = (((long) argtyperef.sourcestart) << 32) + argtyperef.sourceend;
if (typeref instanceof javadocsingletypereference) {
javadocsingletypereference singleref = (javadocsingletypereference) typeref;
argtyperef = new javadocarraysingletypereference(singleref.token, dim, pos);
} else {
javadocqualifiedtypereference qualifref = (javadocqualifiedtypereference) typeref;
argtyperef = new javadocarrayqualifiedtypereference(qualifref, dim);
}
}
int argend = argtyperef.sourceend;
if (dim > 0) {
argend = (int) dimpositions[dim-1];
if (isvarargs) {
argtyperef.bits |= astnode.isvarargs; // set isvarargs
}
}
if (argnamepos >= 0) argend = (int) argnamepos;
return new javadocargumentexpression(name, argtyperef.sourcestart, argend, argtyperef);
}
catch (classcastexception ex) {
throw new invalidinputexception();
}
}
/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#createfieldreference()
*/
protected object createfieldreference(object receiver) throws invalidinputexception {
try {
// get receiver type
typereference typeref = (typereference) receiver;
if (typeref == null) {
char[] name = this.sourceparser.compilationunit.getmaintypename();
typeref = new javadocimplicittypereference(name, this.memberstart);
}
// create field
javadocfieldreference field = new javadocfieldreference(this.identifierstack[0], this.identifierpositionstack[0]);
field.receiver = typeref;
field.tagsourcestart = this.tagsourcestart;
field.tagsourceend = this.tagsourceend;
field.tagvalue = this.tagvalue;
return field;
}
catch (classcastexception ex) {
throw new invalidinputexception();
}
}
/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#createmethodreference(java.lang.object[])
*/
protected object createmethodreference(object receiver, list arguments) throws invalidinputexception {
try {
// get receiver type
typereference typeref = (typereference) receiver;
// decide whether we have a constructor or not
boolean isconstructor = false;
int length = this.identifierlengthstack[0];	// may be > 1 for member class constructor reference
if (typeref == null) {
char[] name = this.sourceparser.compilationunit.getmaintypename();
typedeclaration typedecl = getparsedtypedeclaration();
if (typedecl != null) {
name = typedecl.name;
}
isconstructor = charoperation.equals(this.identifierstack[length-1], name);
typeref = new javadocimplicittypereference(name, this.memberstart);
} else {
if (typeref instanceof javadocsingletypereference) {
char[] name = ((javadocsingletypereference)typeref).token;
isconstructor = charoperation.equals(this.identifierstack[length-1], name);
} else if (typeref instanceof javadocqualifiedtypereference) {
char[][] tokens = ((javadocqualifiedtypereference)typeref).tokens;
int last = tokens.length-1;
isconstructor = charoperation.equals(this.identifierstack[length-1], tokens[last]);
if (isconstructor) {
boolean valid = true;
if (valid) {
for (int i=0; i<length-1 && valid; i++) {
valid = charoperation.equals(this.identifierstack[i], tokens[i]);
}
}
if (!valid) {
if (this.reportproblems) {
this.sourceparser.problemreporter().javadocinvalidmembertypequalification((int)(this.identifierpositionstack[0]>>>32), (int)this.identifierpositionstack[length-1], -1);
}
return null;
}
}
} else {
throw new invalidinputexception();
}
}
// create node
if (arguments == null) {
if (isconstructor) {
javadocallocationexpression allocation = new javadocallocationexpression(this.identifierpositionstack[length-1]);
allocation.type = typeref;
allocation.tagvalue = this.tagvalue;
allocation.sourceend = this.scanner.getcurrenttokenendposition();
if (length == 1) {
allocation.qualification = new char[][] { this.identifierstack[0] };
} else {
system.arraycopy(this.identifierstack, 0, allocation.qualification = new char[length][], 0, length);
allocation.sourcestart = (int) (this.identifierpositionstack[0] >>> 32);
}
allocation.memberstart = this.memberstart;
return allocation;
} else {
javadocmessagesend msg = new javadocmessagesend(this.identifierstack[length-1], this.identifierpositionstack[length-1]);
msg.receiver = typeref;
msg.tagvalue = this.tagvalue;
msg.sourceend = this.scanner.getcurrenttokenendposition();
return msg;
}
} else {
javadocargumentexpression[] expressions = new javadocargumentexpression[arguments.size()];
arguments.toarray(expressions);
if (isconstructor) {
javadocallocationexpression allocation = new javadocallocationexpression(this.identifierpositionstack[length-1]);
allocation.arguments = expressions;
allocation.type = typeref;
allocation.tagvalue = this.tagvalue;
allocation.sourceend = this.scanner.getcurrenttokenendposition();
if (length == 1) {
allocation.qualification = new char[][] { this.identifierstack[0] };
} else {
system.arraycopy(this.identifierstack, 0, allocation.qualification = new char[length][], 0, length);
allocation.sourcestart = (int) (this.identifierpositionstack[0] >>> 32);
}
allocation.memberstart = this.memberstart;
return allocation;
} else {
javadocmessagesend msg = new javadocmessagesend(this.identifierstack[length-1], this.identifierpositionstack[length-1], expressions);
msg.receiver = typeref;
msg.tagvalue = this.tagvalue;
msg.sourceend = this.scanner.getcurrenttokenendposition();
return msg;
}
}
}
catch (classcastexception ex) {
throw new invalidinputexception();
}
}
/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#createreturnstatement()
*/
protected object createreturnstatement() {
return new javadocreturnstatement(this.scanner.getcurrenttokenstartposition(),
this.scanner.getcurrenttokenendposition());
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#parsetagname()
*/
protected void createtag() {
this.tagvalue = tag_others_value;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#createtypereference()
*/
protected object createtypereference(int primitivetoken) {
typereference typeref = null;
int size = this.identifierlengthstack[this.identifierlengthptr];
if (size == 1) { // single type ref
typeref = new javadocsingletypereference(
this.identifierstack[this.identifierptr],
this.identifierpositionstack[this.identifierptr],
this.tagsourcestart,
this.tagsourceend);
} else if (size > 1) { // qualified type ref
char[][] tokens = new char[size][];
system.arraycopy(this.identifierstack, this.identifierptr - size + 1, tokens, 0, size);
long[] positions = new long[size];
system.arraycopy(this.identifierpositionstack, this.identifierptr - size + 1, positions, 0, size);
typeref = new javadocqualifiedtypereference(tokens, positions, this.tagsourcestart, this.tagsourceend);
}
return typeref;
}

/*
* get current parsed type declaration.
*/
protected typedeclaration getparsedtypedeclaration() {
int ptr = this.sourceparser.astptr;
while (ptr >= 0) {
object node = this.sourceparser.aststack[ptr];
if (node instanceof typedeclaration) {
typedeclaration typedecl = (typedeclaration) node;
if (typedecl.bodyend == 0) { // type declaration currenly parsed
return typedecl;
}
}
ptr--;
}
return null;
}

/*
* parse @@throws tag declaration and flag missing description if corresponding option is enabled
*/
protected boolean parsethrows() {
boolean valid = super.parsethrows();
this.tagwaitingfordescription = valid && this.reportproblems ? tag_throws_value : no_tag_value;
return valid;
}

/*
* parse @@return tag declaration
*/
protected boolean parsereturn() {
if (this.returnstatement == null) {
this.returnstatement = createreturnstatement();
return true;
}
if (this.reportproblems) {
this.sourceparser.problemreporter().javadocduplicatedreturntag(
this.scanner.getcurrenttokenstartposition(),
this.scanner.getcurrenttokenendposition());
}
return false;
}


protected void parsesimpletag() {

// read first char
// readchar() code is inlined to balance additional method call in checkdeprectation(int)
char first = this.source[this.index++];
if (first == '\\' && this.source[this.index] == 'u') {
int c1, c2, c3, c4;
int pos = this.index;
this.index++;
while (this.source[this.index] == 'u')
this.index++;
if (!(((c1 = scannerhelper.getnumericvalue(this.source[this.index++])) > 15 || c1 < 0)
|| ((c2 = scannerhelper.getnumericvalue(this.source[this.index++])) > 15 || c2 < 0)
|| ((c3 = scannerhelper.getnumericvalue(this.source[this.index++])) > 15 || c3 < 0) || ((c4 = scannerhelper.getnumericvalue(this.source[this.index++])) > 15 || c4 < 0))) {
first = (char) (((c1 * 16 + c2) * 16 + c3) * 16 + c4);
} else {
this.index = pos;
}
}

// switch on first tag char
switch (first) {
case 'd':
if ((readchar() == 'e') &&
(readchar() == 'p') && (readchar() == 'r') &&
(readchar() == 'e') && (readchar() == 'c') &&
(readchar() == 'a') && (readchar() == 't') &&
(readchar() == 'e') && (readchar() == 'd')) {
// ensure the tag is properly ended: either followed by a space, a tab, line end or asterisk.
char c = readchar();
if (scannerhelper.iswhitespace(c) || c == '*') {
this.abort = true;
this.deprecated = true;
this.tagvalue = tag_deprecated_value;
}
}
break;
}
}

protected boolean parsetag(int previousposition) throws invalidinputexception {

// complain when tag is missing a description
// note that if the parse of an inline tag has already started, consider it
// as the expected description, hence do not report any warning
switch (this.tagwaitingfordescription) {
case tag_param_value:
case tag_throws_value:
if (!this.inlinetagstarted) {
int start = (int) (this.identifierpositionstack[0] >>> 32);
int end = (int) this.identifierpositionstack[this.identifierptr];
this.sourceparser.problemreporter().javadocmissingtagdescriptionafterreference(start, end, this.sourceparser.modifiers);
}
break;
case no_tag_value:
break;
default:
if (!this.inlinetagstarted) {
this.sourceparser.problemreporter().javadocmissingtagdescription(tag_names[this.tagwaitingfordescription], this.tagsourcestart, this.tagsourceend, this.sourceparser.modifiers);
}
break;
}
this.tagwaitingfordescription = no_tag_value;

// verify first character
this.tagsourcestart = this.index;
this.tagsourceend = previousposition;
this.scanner.startposition = this.index;
int currentposition = this.index;
char firstchar = readchar();
switch (firstchar) {
case ' ':
case '*':
case '}':
case '#':
// the first character is not valid, hence report invalid empty tag
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidtag(previousposition, currentposition);
if (this.textstart == -1) this.textstart = currentposition;
this.scanner.currentcharacter = firstchar;
return false;
default:
if (scannerhelper.iswhitespace(firstchar)) {
// the first character is not valid, hence report invalid empty tag
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidtag(previousposition, currentposition);
if (this.textstart == -1) this.textstart = currentposition;
this.scanner.currentcharacter = firstchar;
return false;
}
break;
}

// read tag name
char[] tagname = new char[32];
int length = 0;
char currentchar = firstchar;
int tagnamelength = tagname.length;
boolean validtag = true;
tagloop: while (true) {
if (length == tagnamelength) {
system.arraycopy(tagname, 0, tagname = new char[tagnamelength+32], 0, tagnamelength);
tagnamelength = tagname.length;
}
tagname[length++] = currentchar;
currentposition = this.index;
currentchar = readchar();
switch (currentchar) {
case ' ':
case '*':
case '}':
// these characters mark the end of the tag reading
break tagloop;
case '#':
// invalid tag character, mark the tag as invalid but continue until the end of the tag
validtag = false;
break;
default:
if (scannerhelper.iswhitespace(currentchar)) {
// whitespace characters mark the end of the tag reading
break tagloop;
}
break;
}
}

// init positions
this.tagsourceend = currentposition - 1;
this.scanner.currentcharacter = currentchar;
this.scanner.currentposition = currentposition;
this.index = this.tagsourceend+1;

// return if the tag is not valid
if (!validtag) {
if (this.reportproblems) this.sourceparser.problemreporter().javadocinvalidtag(this.tagsourcestart, this.tagsourceend);
if (this.textstart == -1) this.textstart = this.index;
this.scanner.currentcharacter = currentchar;
return false;
}

// decide which parse to perform depending on tag name
this.tagvalue = tag_others_value;
boolean valid = false;
switch (firstchar) {
case 'a':
if (length == tag_author_length && charoperation.equals(tag_author, tagname, 0, length)) {
this.tagvalue = tag_author_value;
this.tagwaitingfordescription = this.tagvalue;
}
break;
case 'c':
if (length == tag_category_length && charoperation.equals(tag_category, tagname, 0, length)) {
this.tagvalue = tag_category_value;
if (!this.inlinetagstarted) {
valid = parseidentifiertag(false); // todo (frederic) reconsider parameter value when @@category will be significant in spec
}
} else if (length == tag_code_length && this.inlinetagstarted && charoperation.equals(tag_code, tagname, 0, length)) {
this.tagvalue = tag_code_value;
this.tagwaitingfordescription = this.tagvalue;
}
break;
case 'd':
if (length == tag_deprecated_length && charoperation.equals(tag_deprecated, tagname, 0, length)) {
this.deprecated = true;
valid = true;
this.tagvalue = tag_deprecated_value;
this.tagwaitingfordescription = this.tagvalue;
} else if (length == tag_doc_root_length && charoperation.equals(tag_doc_root, tagname, 0, length)) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=227730
// identify @@docroot tag as a base tag that does not expect any argument
valid = true;
this.tagvalue = tag_doc_root_value;
}
break;
case 'e':
if (length == tag_exception_length && charoperation.equals(tag_exception, tagname, 0, length)) {
this.tagvalue = tag_exception_value;
if (!this.inlinetagstarted) {
valid = parsethrows();
}
}
break;
case 'i':
if (length == tag_inheritdoc_length && charoperation.equals(tag_inheritdoc, tagname, 0, length)) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=247037, @@inheritdoc usage is illegal
// outside of few block tags and the main description.
switch (this.lastblocktagvalue) {
case tag_return_value:
case tag_throws_value:
case tag_exception_value:
case tag_param_value:
case no_tag_value:     // still in main description
valid = true;
if (this.reportproblems) {
recordinheritedposition((((long) this.tagsourcestart) << 32) + this.tagsourceend);
}
break;
default:
valid = false;
if (this.reportproblems) {
this.sourceparser.problemreporter().javadocunexpectedtag(this.tagsourcestart,
this.tagsourceend);
}
}
this.tagvalue = tag_inheritdoc_value;
}
break;
case 'l':
if (length == tag_link_length && charoperation.equals(tag_link, tagname, 0, length)) {
this.tagvalue = tag_link_value;
if (this.inlinetagstarted || (this.kind & completion_parser) != 0) {
valid= parsereference();
}
} else if (length == tag_linkplain_length && charoperation.equals(tag_linkplain, tagname, 0, length)) {
this.tagvalue = tag_linkplain_value;
if (this.inlinetagstarted) {
valid = parsereference();
}
} else if (length == tag_literal_length && this.inlinetagstarted && charoperation.equals(tag_literal, tagname, 0, length)) {
this.tagvalue = tag_literal_value;
this.tagwaitingfordescription = this.tagvalue;
}
break;
case 'p':
if (length == tag_param_length && charoperation.equals(tag_param, tagname, 0, length)) {
this.tagvalue = tag_param_value;
if (!this.inlinetagstarted) {
valid = parseparam();
}
}
break;
case 'r':
if (length == tag_return_length && charoperation.equals(tag_return, tagname, 0, length)) {
this.tagvalue = tag_return_value;
if (!this.inlinetagstarted) {
valid = parsereturn();
}
}
break;
case 's':
if (length == tag_see_length && charoperation.equals(tag_see, tagname, 0, length)) {
this.tagvalue = tag_see_value;
if (!this.inlinetagstarted) {
valid = parsereference();
}
} else if (length == tag_serial_length && charoperation.equals(tag_serial, tagname, 0, length)) {
this.tagvalue = tag_serial_value;
this.tagwaitingfordescription = this.tagvalue;
} else if (length == tag_serial_data_length && charoperation.equals(tag_serial_data, tagname, 0, length)) {
this.tagvalue = tag_serial_data_value;
this.tagwaitingfordescription = this.tagvalue;
} else if (length == tag_serial_field_length && charoperation.equals(tag_serial_field, tagname, 0, length)) {
this.tagvalue = tag_serial_field_value;
this.tagwaitingfordescription = this.tagvalue;
} else if (length == tag_since_length && charoperation.equals(tag_since, tagname, 0, length)) {
this.tagvalue = tag_since_value;
this.tagwaitingfordescription = this.tagvalue;
}
break;
case 't':
if (length == tag_throws_length && charoperation.equals(tag_throws, tagname, 0, length)) {
this.tagvalue = tag_throws_value;
if (!this.inlinetagstarted) {
valid = parsethrows();
}
}
break;
case 'v':
if (length == tag_value_length && charoperation.equals(tag_value, tagname, 0, length)) {
this.tagvalue = tag_value_value;
if (this.sourcelevel >= classfileconstants.jdk1_5) {
if (this.inlinetagstarted) {
valid = parsereference();
}
} else {
if (this.validvaluepositions == -1) {
if (this.invalidvaluepositions != -1) {
if (this.reportproblems) this.sourceparser.problemreporter().javadocunexpectedtag((int) (this.invalidvaluepositions>>>32), (int) this.invalidvaluepositions);
}
if (valid) {
this.validvaluepositions = (((long) this.tagsourcestart) << 32) + this.tagsourceend;
this.invalidvaluepositions = -1;
} else {
this.invalidvaluepositions = (((long) this.tagsourcestart) << 32) + this.tagsourceend;
}
} else {
if (this.reportproblems) this.sourceparser.problemreporter().javadocunexpectedtag(this.tagsourcestart, this.tagsourceend);
}
}
} else if (length == tag_version_length && charoperation.equals(tag_version, tagname, 0, length)) {
this.tagvalue = tag_version_value;
this.tagwaitingfordescription = this.tagvalue;
} else {
createtag();
}
break;
default:
createtag();
break;
}
this.textstart = this.index;
if (this.tagvalue != tag_others_value) {
if (!this.inlinetagstarted) {
this.lastblocktagvalue = this.tagvalue;
}
// see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=267833
// report a problem if a block tag is being used in the context of an inline tag and vice versa.
if ((this.inlinetagstarted && javadoc_tag_type[this.tagvalue] == tag_type_block)
|| (!this.inlinetagstarted && javadoc_tag_type[this.tagvalue] == tag_type_inline)) {
valid = false;
this.tagvalue = tag_others_value;
this.tagwaitingfordescription = no_tag_value;
if (this.reportproblems) {
this.sourceparser.problemreporter().javadocunexpectedtag(this.tagsourcestart, this.tagsourceend);
}
}
}
return valid;
}

/*
* parse @@param tag declaration and flag missing description if corresponding option is enabled
*/
protected boolean parseparam() throws invalidinputexception {
boolean valid = super.parseparam();
this.tagwaitingfordescription = valid && this.reportproblems ? tag_param_value : no_tag_value;
return valid;
}

/*
* push a param name in ast node stack.
*/
protected boolean pushparamname(boolean istypeparam) {
// create param reference
astnode nameref = null;
if (istypeparam) {
javadocsingletypereference ref = new javadocsingletypereference(this.identifierstack[1],
this.identifierpositionstack[1],
this.tagsourcestart,
this.tagsourceend);
nameref = ref;
} else {
javadocsinglenamereference ref = new javadocsinglenamereference(this.identifierstack[0],
this.identifierpositionstack[0],
this.tagsourcestart,
this.tagsourceend);
nameref = ref;
}
// push ref on stack
if (this.astlengthptr == -1) { // first push
pushonaststack(nameref, true);
} else {
// verify that no @@throws has been declared before
if (!istypeparam) { // do not verify for type parameters as @@throws may be invalid tag (when declared in class)
for (int i=throws_tag_expected_order; i<=this.astlengthptr; i+=ordered_tags_number) {
if (this.astlengthstack[i] != 0) {
if (this.reportproblems) this.sourceparser.problemreporter().javadocunexpectedtag(this.tagsourcestart, this.tagsourceend);
// bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=51600
// store invalid param references in specific array
if (this.invalidparamreferencesptr == -1l) {
this.invalidparamreferencesstack = new javadocsinglenamereference[10];
}
int stacklength = this.invalidparamreferencesstack.length;
if (++this.invalidparamreferencesptr >= stacklength) {
system.arraycopy(
this.invalidparamreferencesstack, 0,
this.invalidparamreferencesstack = new javadocsinglenamereference[stacklength + ast_stack_increment], 0,
stacklength);
}
this.invalidparamreferencesstack[this.invalidparamreferencesptr] = nameref;
return false;
}
}
}
switch (this.astlengthptr % ordered_tags_number) {
case param_tag_expected_order :
// previous push was a @@param tag => push another param name
pushonaststack(nameref, false);
break;
case see_tag_expected_order :
// previous push was a @@see tag => push new param name
pushonaststack(nameref, true);
break;
default:
return false;
}
}
return true;
}

/*
* push a reference statement in ast node stack.
*/
protected boolean pushseeref(object statement) {
if (this.astlengthptr == -1) { // first push
pushonaststack(null, true);
pushonaststack(null, true);
pushonaststack(statement, true);
} else {
switch (this.astlengthptr % ordered_tags_number) {
case param_tag_expected_order :
// previous push was a @@param tag => push empty @@throws tag and new @@see tag
pushonaststack(null, true);
pushonaststack(statement, true);
break;
case throws_tag_expected_order :
// previous push was a @@throws tag => push new @@see tag
pushonaststack(statement, true);
break;
case see_tag_expected_order :
// previous push was a @@see tag => push another @@see tag
pushonaststack(statement, false);
break;
default:
return false;
}
}
return true;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#pushtext(int, int)
*/
protected void pushtext(int start, int end) {
// the tag gets its description => clear the flag
this.tagwaitingfordescription = no_tag_value;
}

/*
* push a throws type ref in ast node stack.
*/
protected boolean pushthrowname(object typeref) {
if (this.astlengthptr == -1) { // first push
pushonaststack(null, true);
pushonaststack(typeref, true);
} else {
switch (this.astlengthptr % ordered_tags_number) {
case param_tag_expected_order :
// previous push was a @@param tag => push new @@throws tag
pushonaststack(typeref, true);
break;
case throws_tag_expected_order :
// previous push was a @@throws tag => push another @@throws tag
pushonaststack(typeref, false);
break;
case see_tag_expected_order :
// previous push was a @@see tag => push empty @@param and new @@throws tags
pushonaststack(null, true);
pushonaststack(typeref, true);
break;
default:
return false;
}
}
return true;
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.parser.abstractcommentparser#refreshinlinetagposition(int)
*/
protected void refreshinlinetagposition(int previousposition) {

// signal tag missing description if necessary
if (this.tagwaitingfordescription!= no_tag_value) {
this.sourceparser.problemreporter().javadocmissingtagdescription(tag_names[this.tagwaitingfordescription], this.tagsourcestart, this.tagsourceend, this.sourceparser.modifiers);
this.tagwaitingfordescription = no_tag_value;
}
}

/*
* refresh return statement
*/
protected void refreshreturnstatement() {
((javadocreturnstatement) this.returnstatement).bits &= ~astnode.empty;
}

public string tostring() {
stringbuffer buffer = new stringbuffer();
buffer.append("check javadoc: ").append(this.checkdoccomment).append("\n");	//$non-nls-1$ //$non-nls-2$
buffer.append("javadoc: ").append(this.doccomment).append("\n");	//$non-nls-1$ //$non-nls-2$
buffer.append(super.tostring());
return buffer.tostring();
}

/*
* fill associated comment fields with ast nodes information stored in stack.
*/
protected void updatedoccomment() {

// complain when tag is missing a description
// note that if the parse of an inline tag has already started, consider it
// as the expected description, hence do not report any warning
switch (this.tagwaitingfordescription) {
case tag_param_value:
case tag_throws_value:
if (!this.inlinetagstarted) {
int start = (int) (this.identifierpositionstack[0] >>> 32);
int end = (int) this.identifierpositionstack[this.identifierptr];
this.sourceparser.problemreporter().javadocmissingtagdescriptionafterreference(start, end, this.sourceparser.modifiers);
}
break;
case no_tag_value:
break;
default:
if (!this.inlinetagstarted) {
this.sourceparser.problemreporter().javadocmissingtagdescription(tag_names[this.tagwaitingfordescription], this.tagsourcestart, this.tagsourceend, this.sourceparser.modifiers);
}
break;
}
this.tagwaitingfordescription = no_tag_value;

// set positions
if (this.inheritedpositions != null && this.inheritedpositionsptr != this.inheritedpositions.length) {
// compact array by shrinking.
system.arraycopy(this.inheritedpositions, 0,
this.inheritedpositions = new long[this.inheritedpositionsptr], 0, this.inheritedpositionsptr);
}
this.doccomment.inheritedpositions = this.inheritedpositions;
this.doccomment.valuepositions = this.validvaluepositions != -1 ? this.validvaluepositions : this.invalidvaluepositions;

// set return node if present
if (this.returnstatement != null) {
this.doccomment.returnstatement = (javadocreturnstatement) this.returnstatement;
}

// copy array of invalid syntax param tags
if (this.invalidparamreferencesptr >= 0) {
this.doccomment.invalidparameters = new javadocsinglenamereference[this.invalidparamreferencesptr+1];
system.arraycopy(this.invalidparamreferencesstack, 0, this.doccomment.invalidparameters, 0, this.invalidparamreferencesptr+1);
}

// if no nodes stored return
if (this.astlengthptr == -1) {
return;
}

// initialize arrays
int[] sizes = new int[ordered_tags_number];
for (int i=0; i<=this.astlengthptr; i++) {
sizes[i%ordered_tags_number] += this.astlengthstack[i];
}
this.doccomment.seereferences = new expression[sizes[see_tag_expected_order]];
this.doccomment.exceptionreferences = new typereference[sizes[throws_tag_expected_order]];
int paramrefptr = sizes[param_tag_expected_order];
this.doccomment.paramreferences = new javadocsinglenamereference[paramrefptr];
int paramtypeparamptr = sizes[param_tag_expected_order];
this.doccomment.paramtypeparameters = new javadocsingletypereference[paramtypeparamptr];

// store nodes in arrays
while (this.astlengthptr >= 0) {
int ptr = this.astlengthptr % ordered_tags_number;
// starting with the stack top, so get references (expression) coming from @@see declarations
switch(ptr) {
case see_tag_expected_order:
int size = this.astlengthstack[this.astlengthptr--];
for (int i=0; i<size; i++) {
this.doccomment.seereferences[--sizes[ptr]] = (expression) this.aststack[this.astptr--];
}
break;

// then continuing with class names (typereference) coming from @@throw/@@exception declarations
case throws_tag_expected_order:
size = this.astlengthstack[this.astlengthptr--];
for (int i=0; i<size; i++) {
this.doccomment.exceptionreferences[--sizes[ptr]] = (typereference) this.aststack[this.astptr--];
}
break;

// finally, finishing with parameters names (argument) coming from @@param declaration
case param_tag_expected_order:
size = this.astlengthstack[this.astlengthptr--];
for (int i=0; i<size; i++) {
expression reference = (expression) this.aststack[this.astptr--];
if (reference instanceof javadocsinglenamereference)
this.doccomment.paramreferences[--paramrefptr] = (javadocsinglenamereference) reference;
else if (reference instanceof javadocsingletypereference)
this.doccomment.paramtypeparameters[--paramtypeparamptr] = (javadocsingletypereference) reference;
}
break;
}
}

// resize param tag references arrays
if (paramrefptr == 0) { // there's no type parameters references
this.doccomment.paramtypeparameters = null;
} else if (paramtypeparamptr == 0) { // there's no names references
this.doccomment.paramreferences = null;
} else { // there both of references => resize arrays
int size = sizes[param_tag_expected_order];
system.arraycopy(this.doccomment.paramreferences, paramrefptr, this.doccomment.paramreferences = new javadocsinglenamereference[size - paramrefptr], 0, size - paramrefptr);
system.arraycopy(this.doccomment.paramtypeparameters, paramtypeparamptr, this.doccomment.paramtypeparameters = new javadocsingletypereference[size - paramtypeparamptr], 0, size - paramtypeparamptr);
}
}
}
