/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.ast.methoddeclaration;
import org.eclipse.jdt.internal.compiler.lookup.classscope;

public class completiononmethodname extends methoddeclaration {
public int selectorend;

public completiononmethodname(compilationresult compilationresult){
super(compilationresult);
}

public stringbuffer print(int indent, stringbuffer output) {

printindent(indent, output);
output.append("<completiononmethodname:"); //$non-nls-1$
printmodifiers(this.modifiers, output);
printreturntype(0, output);
output.append(this.selector).append('(');
if (this.arguments != null) {
for (int i = 0; i < this.arguments.length; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.arguments[i].print(0, output);
}
}
output.append(')');
if (this.thrownexceptions != null) {
output.append(" throws "); //$non-nls-1$
for (int i = 0; i < this.thrownexceptions.length; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.thrownexceptions[i].print(0, output);
}
}
return output.append('>');
}

public void resolve(classscope upperscope) {

super.resolve(upperscope);
throw new completionnodefound(this, upperscope);
}
}
