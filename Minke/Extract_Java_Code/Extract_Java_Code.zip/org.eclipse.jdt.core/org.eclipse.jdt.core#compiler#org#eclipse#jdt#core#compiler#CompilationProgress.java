/*******************************************************************************
* copyright (c) 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.core.compiler;

import org.eclipse.jdt.core.compiler.batch.batchcompiler;

/**
* a compilation progress is used by the {@@link batchcompiler} to report progress during compilation.
* it is also used to request cancellation of the compilation.
* clients of the {@@link batchcompiler} should subclass this class, instantiate the subclass and pass this instance to
* {@@link batchcompiler#compile(string, java.io.printwriter, java.io.printwriter, compilationprogress)}.
* <p>
* this class is intended to be instantiated and subclassed by clients.
* </p>
*
* @@since 3.4
*/

public abstract class compilationprogress {

/**
* notifies that the compilation is beginning. this is called exactly once per batch compilation.
* an estimated amount of remaining work is given. this amount will change as the compilation
* progresses. the new estimated amount of remaining work is reported using {@@link #worked(int, int)}.
* <p>
* clients should not call this method.
* </p>
*
* @@param remainingwork the estimated amount of remaining work.
*/
public abstract void begin(int remainingwork);

/**
* notifies that the work is done; that is, either the compilation is completed
* or a cancellation was requested. this is called exactly once per batch compilation.
* <p>
* clients should not call this method.
* </p>
*/
public abstract void done();

/**
* returns whether cancellation of the compilation has been requested.
*
* @@return <code>true</code> if cancellation has been requested,
*    and <code>false</code> otherwise
*/
public abstract boolean iscanceled();

/**
* reports the name (or description) of the current task.
* <p>
* clients should not call this method.
* </p>
*
* @@param name the name (or description) of the current task
*/
public abstract void settaskname(string name);


/**
* notifies that a given amount of work of the compilation
* has been completed. note that this amount represents an
* installment, as opposed to a cumulative amount of work done
* to date.
* also notifies an estimated amount of remaining work. note that this
* amount of remaining work  may be greater than the previous estimated
* amount as new compilation units are injected in the compile loop.
* <p>
* clients should not call this method.
* </p>
*
* @@param workincrement a non-negative amount of work just completed
* @@param remainingwork  a non-negative amount of estimated remaining work
*/
public abstract void worked(int workincrement, int remainingwork);


}
