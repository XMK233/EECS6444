/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.packagebinding;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;


public class javadocsingletypereference extends singletypereference {

public int tagsourcestart, tagsourceend;
public packagebinding packagebinding;

public javadocsingletypereference(char[] source, long pos, int tagstart, int tagend) {
super(source, pos);
this.tagsourcestart = tagstart;
this.tagsourceend = tagend;
this.bits |= astnode.insidejavadoc;
}

/*
* we need to modify resolving behavior to handle package references
*/
protected typebinding internalresolvetype(scope scope) {
// handle the error here
this.constant = constant.notaconstant;
if (this.resolvedtype != null) { // is a shared type reference which was already resolved
if (this.resolvedtype.isvalidbinding()) {
return this.resolvedtype;
} else {
switch (this.resolvedtype.problemid()) {
case problemreasons.notfound :
case problemreasons.notvisible :
case problemreasons.inheritednamehidesenclosingname :
typebinding type = this.resolvedtype.closestmatch();
return type;
default :
return null;
}
}
}
this.resolvedtype = gettypebinding(scope);
// end resolution when gettypebinding(scope) returns null. this may happen in
// certain circumstances, typically when an illegal access is done on a type
// variable (see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=204749)
if (this.resolvedtype == null) return null;

if (!this.resolvedtype.isvalidbinding()) {
char[][] tokens = { this.token };
binding binding = scope.gettypeorpackage(tokens);
if (binding instanceof packagebinding) {
this.packagebinding = (packagebinding) binding;
// valid package references are allowed in javadoc (https://bugs.eclipse.org/bugs/show_bug.cgi?id=281609)
} else {
if (this.resolvedtype.problemid() == problemreasons.nonstaticreferenceinstaticcontext) {
typebinding closestmatch = this.resolvedtype.closestmatch();
if (closestmatch != null && closestmatch.istypevariable()) {
this.resolvedtype = closestmatch; // ignore problem as we want report specific javadoc one instead
return this.resolvedtype;
}
}
reportinvalidtype(scope);
}
return null;
}
if (istypeusedeprecated(this.resolvedtype, scope))
reportdeprecatedtype(this.resolvedtype, scope);
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=209936
// raw convert all enclosing types when dealing with javadoc references
if (this.resolvedtype.isgenerictype() || this.resolvedtype.isparameterizedtype()) {
this.resolvedtype = scope.environment().converttorawtype(this.resolvedtype, true /*force the conversion of enclosing types*/);
}
return this.resolvedtype;
}
protected void reportdeprecatedtype(typebinding type, scope scope) {
scope.problemreporter().javadocdeprecatedtype(type, this, scope.getdeclarationmodifiers());
}

protected void reportinvalidtype(scope scope) {
scope.problemreporter().javadocinvalidtype(this, this.resolvedtype, scope.getdeclarationmodifiers());
}

/* (non-javadoc)
* redefine to capture javadoc specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.astvisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}

public void traverse(astvisitor visitor, classscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
