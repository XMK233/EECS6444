/*******************************************************************************
* copyright (c) 2004, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.complete;

/*
* completion node build by the parser in any case it was intending to
* reduce a type reference containing the completion identifier as part
* of a parameterized qualified name.
* e.g.
*
*	class x extends y<z>.w[cursor]
*
*	---> class x extends <completeontype:y<z>.w>
*
* the source range of the completion node denotes the source range
* which should be replaced by the completion.
*/

import org.eclipse.jdt.internal.compiler.ast.parameterizedqualifiedtypereference;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;


public class completiononparameterizedqualifiedtypereference extends parameterizedqualifiedtypereference {
public static final int k_type = 0;
public static final int k_class = 1;
public static final int k_interface = 2;
public static final int k_exception = 3;

private int kind = k_type;
public char[] completionidentifier;
/**
* @@param tokens
* @@param typearguments
* @@param positions
*/
public completiononparameterizedqualifiedtypereference(char[][] tokens,	typereference[][] typearguments, char[] completionidentifier, long[] positions) {
this(tokens, typearguments, completionidentifier, positions, k_type);
}

/**
* @@param tokens
* @@param typearguments
* @@param positions
* @@param kind
*/
public completiononparameterizedqualifiedtypereference(char[][] tokens,	typereference[][] typearguments, char[] completionidentifier, long[] positions, int kind) {
super(tokens, typearguments, 0, positions);
this.completionidentifier = completionidentifier;
this.kind = kind;
}

public boolean isclass(){
return this.kind == k_class;
}

public boolean isinterface(){
return this.kind == k_interface;
}

public boolean isexception(){
return this.kind == k_exception;
}

public boolean issupertype(){
return this.kind == k_class || this.kind == k_interface;
}

public typebinding resolvetype(blockscope scope, boolean checkbounds) {
super.resolvetype(scope, checkbounds);
throw new completionnodefound(this, this.resolvedtype, scope);
}

public typebinding resolvetype(classscope scope) {
super.resolvetype(scope);
throw new completionnodefound(this, this.resolvedtype, scope);
}

public stringbuffer printexpression(int indent, stringbuffer output) {
switch (this.kind) {
case k_class :
output.append("<completeonclass:");//$non-nls-1$
break;
case k_interface :
output.append("<completeoninterface:");//$non-nls-1$
break;
case k_exception :
output.append("<completeonexception:");//$non-nls-1$
break;
default :
output.append("<completeontype:");//$non-nls-1$
break;
}
int length = this.tokens.length;
for (int i = 0; i < length - 1; i++) {
output.append(this.tokens[i]);
typereference[] typeargument = this.typearguments[i];
if (typeargument != null) {
output.append('<');
int max = typeargument.length - 1;
for (int j = 0; j < max; j++) {
typeargument[j].print(0, output);
output.append(", ");//$non-nls-1$
}
typeargument[max].print(0, output);
output.append('>');
}
output.append('.');
}
output.append(this.tokens[length - 1]);
typereference[] typeargument = this.typearguments[length - 1];
if (typeargument != null) {
output.append('<');
int max = typeargument.length - 1;
for (int j = 0; j < max; j++) {
typeargument[j].print(0, output);
output.append(", ");//$non-nls-1$
}
typeargument[max].print(0, output);
output.append('>');
}
output.append('.').append(this.completionidentifier).append('>');
return output;
}
}
