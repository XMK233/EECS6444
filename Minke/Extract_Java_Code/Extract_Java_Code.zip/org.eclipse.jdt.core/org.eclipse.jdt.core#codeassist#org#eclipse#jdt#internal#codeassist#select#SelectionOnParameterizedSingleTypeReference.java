/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

import org.eclipse.jdt.internal.compiler.ast.parameterizedsingletypereference;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class selectiononparameterizedsingletypereference extends parameterizedsingletypereference {
public selectiononparameterizedsingletypereference(char[] name, typereference[] typearguments, long pos){
super(name, typearguments, 0, pos);
}

public typebinding resolvetype(blockscope scope, boolean checkbounds) {
super.resolvetype(scope, checkbounds);
throw new selectionnodefound(this.resolvedtype);
}

public typebinding resolvetype(classscope scope) {
super.resolvetype(scope);
throw new selectionnodefound(this.resolvedtype);
}

public stringbuffer printexpression(int indent, stringbuffer output){
output.append("<selectontype:");//$non-nls-1$
output.append(this.token);
output.append('<');
int max = this.typearguments.length - 1;
for (int i= 0; i < max; i++) {
this.typearguments[i].print(0, output);
output.append(", ");//$non-nls-1$
}
this.typearguments[max].print(0, output);
output.append('>');
output.append('>');
return output;
}
}
