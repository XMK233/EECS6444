/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.util.list;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.wildcard;

/*
* not all fields defined by this type (& its subclasses) are initialized when it is created.
* some are initialized only when needed.
*
* accessors have been provided for some public fields so all typebindings have the same api...
* but access public fields directly whenever possible.
* non-public fields have accessors which should be used everywhere you expect the field to be initialized.
*
* null is not a valid value for a non-public field... it just means the field is not initialized.
*/
abstract public class typebinding extends binding {

public int id = typeids.noid;
public long tagbits = 0; // see values in the interface tagbits below


/** base type definitions */
public final static basetypebinding int = new basetypebinding(
typeids.t_int, typeconstants.int, new char[] { 'i' });

public final static basetypebinding byte = new basetypebinding(
typeids.t_byte, typeconstants.byte, new char[] { 'b' });

public final static basetypebinding short = new basetypebinding(
typeids.t_short, typeconstants.short, new char[] { 's' });

public final static basetypebinding char = new basetypebinding(
typeids.t_char, typeconstants.char, new char[] { 'c' });

public final static basetypebinding long = new basetypebinding(
typeids.t_long, typeconstants.long, new char[] { 'j' });

public final static basetypebinding float = new basetypebinding(
typeids.t_float, typeconstants.float, new char[] { 'f' });

public final static basetypebinding double = new basetypebinding(
typeids.t_double, typeconstants.double, new char[] { 'd' });

public final static basetypebinding boolean = new basetypebinding(
typeids.t_boolean, typeconstants.boolean, new char[] { 'z' });

public final static basetypebinding null = new basetypebinding(
typeids.t_null, typeconstants.null, new char[] { 'n' }); //n stands for null even if it is never internally used

public final static basetypebinding void = new basetypebinding(
typeids.t_void, typeconstants.void, new char[] { 'v' });

/**
* match a well-known type id to its binding
*/
public static final typebinding wellknowntype(scope scope, int id) {
switch (id) {
case typeids.t_boolean:
return typebinding.boolean;
case typeids.t_byte:
return typebinding.byte;
case typeids.t_char:
return typebinding.char;
case typeids.t_short:
return typebinding.short;
case typeids.t_double:
return typebinding.double;
case typeids.t_float:
return typebinding.float;
case typeids.t_int:
return typebinding.int;
case typeids.t_long:
return typebinding.long;
case typeids.t_javalangobject:
return scope.getjavalangobject();
case typeids.t_javalangstring:
return scope.getjavalangstring();
default:
return null;
}
}

/* answer true if the receiver can be instantiated
*/
public boolean canbeinstantiated() {
return !isbasetype();
}

/**
* perform capture conversion on a given type (only effective on parameterized type with wildcards)
*/
public typebinding capture(scope scope, int position) {
return this;
}

/**
* in case of problems, returns the closest match found. it may not be perfect match, but the
* result of a best effort to improve fault-tolerance.
*/
public typebinding closestmatch() {
return this; // by default no better type
}

/**
* iterate through the type components to collect instances of leaf missing types
* @@param missingtypes
* @@return missing types
*/
public list collectmissingtypes(list missingtypes) {
return missingtypes;
}

/**
* collect the substitutes into a map for certain type variables inside the receiver type
* e.g.   collection<t>.findsubstitute(t, collection<list<x>>):   t --> list<x>
* constraints:
*   a << f   corresponds to:   f.collectsubstitutes(..., a, ..., constraint_extends (1))
*   a = f   corresponds to:      f.collectsubstitutes(..., a, ..., constraint_equal (0))
*   a >> f   corresponds to:   f.collectsubstitutes(..., a, ..., constraint_super (2))
*/
public void collectsubstitutes(scope scope, typebinding actualtype, inferencecontext inferencecontext, int constraint) {
// no substitute by default
}

/**
*  answer the receiver's constant pool name.
*  note: this method should only be used during/after code gen.
*  e.g. 'java/lang/object'
*/
public abstract char[] constantpoolname();

public string debugname() {
return new string(readablename());
}

/*
* answer the receiver's dimensions - 0 for non-array types
*/
public int dimensions() {
return 0;
}

/* answer the receiver's enclosing type... null if the receiver is a top level type.
*/
public referencebinding enclosingtype() {
return null;
}

public typebinding erasure() {
return this;
}

/**
* find supertype which originates from a given well-known type, or null if not found
* (using id avoids triggering the load of well-known type: 73740)
* note: only works for erasures of well-known types, as random other types may share
* same id though being distincts.
* @@see typeids
*/
public referencebinding findsupertypeoriginatingfrom(int wellknownoriginalid, boolean originalisclass) {

if (!(this instanceof referencebinding)) return null;
referencebinding reference = (referencebinding) this;

// do not allow type variables to match with erasures for free
if (reference.id == wellknownoriginalid || (original().id == wellknownoriginalid)) return reference;

referencebinding currenttype = reference;
// iterate superclass to avoid recording interfaces if searched supertype is class
if (originalisclass) {
while ((currenttype = currenttype.superclass()) != null) {
if (currenttype.id == wellknownoriginalid)
return currenttype;
if (currenttype.original().id == wellknownoriginalid)
return currenttype;
}
return null;
}
referencebinding[] interfacestovisit = null;
int nextposition = 0;
do {
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
} while ((currenttype = currenttype.superclass()) != null);

for (int i = 0; i < nextposition; i++) {
currenttype = interfacestovisit[i];
if (currenttype.id == wellknownoriginalid)
return currenttype;
if (currenttype.original().id == wellknownoriginalid)
return currenttype;
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
return null;
}

/**
* find supertype which originates from a given type, or null if not found
*/
public typebinding findsupertypeoriginatingfrom(typebinding othertype) {
if (this == othertype) return this;
if (othertype == null) return null;
switch(kind()) {
case binding.array_type :
arraybinding arraytype = (arraybinding) this;
int otherdim = othertype.dimensions();
if (arraytype.dimensions != otherdim) {
switch(othertype.id) {
case typeids.t_javalangobject :
case typeids.t_javaioserializable :
case typeids.t_javalangcloneable :
return othertype;
}
if (otherdim < arraytype.dimensions && othertype.leafcomponenttype().id == typeids.t_javalangobject) {
return othertype; // x[][] has object[] as an implicit supertype
}
return null;
}
if (!(arraytype.leafcomponenttype instanceof referencebinding)) return null;
typebinding leafsupertype = arraytype.leafcomponenttype.findsupertypeoriginatingfrom(othertype.leafcomponenttype());
if (leafsupertype == null) return null;
return arraytype.environment().createarraytype(leafsupertype, arraytype.dimensions);

case binding.type_parameter :
if (iscapture()) {
capturebinding capture = (capturebinding) this;
typebinding capturebound = capture.firstbound;
if (capturebound instanceof arraybinding) {
typebinding match = capturebound.findsupertypeoriginatingfrom(othertype);
if (match != null) return match;
}
}
//$fall-through$
case binding.type :
case binding.parameterized_type :
case binding.generic_type :
case binding.raw_type :
case binding.wildcard_type :
case binding.intersection_type:
// do not allow type variables/intersection types to match with erasures for free
othertype = othertype.original();
if (this == othertype)
return this;
if (original() == othertype)
return this;
referencebinding currenttype = (referencebinding)this;
if (!othertype.isinterface()) {
while ((currenttype = currenttype.superclass()) != null) {
if (currenttype == othertype)
return currenttype;
if (currenttype.original() == othertype)
return currenttype;
}
return null;
}
referencebinding[] interfacestovisit = null;
int nextposition = 0;
do {
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
} while ((currenttype = currenttype.superclass()) != null);

for (int i = 0; i < nextposition; i++) {
currenttype = interfacestovisit[i];
if (currenttype == othertype)
return currenttype;
if (currenttype.original() == othertype)
return currenttype;
referencebinding[] itsinterfaces = currenttype.superinterfaces();
if (itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}
return null;
}

/**
* returns the type to use for generic cast, or null if none required
*/
public typebinding genericcast(typebinding targettype) {
if (this == targettype)
return null;
typebinding targeterasure = targettype.erasure();
// type var get replaced by upper bound
if (erasure().findsupertypeoriginatingfrom(targeterasure) != null)
return null;
return targeterasure;
}

/**
* answer the receiver classfile signature.
* arrays & base types do not distinguish between signature() & constantpoolname().
* note: this method should only be used during/after code gen.
*/
public char[] generictypesignature() {
return signature();
}

/**
* return the supertype which would erase as a subtype of a given declaring class.
* if the receiver is already erasure compatible, then it will returned. if not, then will return the alternate lowest
* upper bound compatible with declaring class.
* note: the declaringclass is already know to be compatible with the receiver
* @@param declaringclass to look for
* @@return the lowest erasure compatible type (considering alternate bounds)
*/
public typebinding geterasurecompatibletype(typebinding declaringclass) {
switch(kind()) {
case binding.type_parameter :
typevariablebinding variable = (typevariablebinding) this;
if (variable.erasure().findsupertypeoriginatingfrom(declaringclass) != null) {
return this; // no need for alternate receiver type
}
if (variable.superclass != null && variable.superclass.findsupertypeoriginatingfrom(declaringclass) != null) {
return variable.superclass.geterasurecompatibletype(declaringclass);
}
for (int i = 0, otherlength = variable.superinterfaces.length; i < otherlength; i++) {
referencebinding superinterface = variable.superinterfaces[i];
if (superinterface.findsupertypeoriginatingfrom(declaringclass) != null) {
return superinterface.geterasurecompatibletype(declaringclass);
}
}
return this; // only occur if passed null declaringclass for arraylength
case binding.intersection_type :
wildcardbinding intersection = (wildcardbinding) this;
if (intersection.erasure().findsupertypeoriginatingfrom(declaringclass) != null) {
return this; // no need for alternate receiver type
}
if (intersection.superclass != null && intersection.superclass.findsupertypeoriginatingfrom(declaringclass) != null) {
return intersection.superclass.geterasurecompatibletype(declaringclass);
}
for (int i = 0, otherlength = intersection.superinterfaces.length; i < otherlength; i++) {
referencebinding superinterface = intersection.superinterfaces[i];
if (superinterface.findsupertypeoriginatingfrom(declaringclass) != null) {
return superinterface.geterasurecompatibletype(declaringclass);
}
}
return this; // only occur if passed null declaringclass for arraylength
default :
return this;
}
}

public abstract packagebinding getpackage();

void initializeforstaticimports() {
// only applicable to source types
}

public boolean isannotationtype() {
return false;
}

public final boolean isanonymoustype() {
return (this.tagbits & tagbits.isanonymoustype) != 0;
}

/* answer true if the receiver is an array
*/
public final boolean isarraytype() {
return (this.tagbits & tagbits.isarraytype) != 0;
}

/* answer true if the receiver is a base type
*/
public final boolean isbasetype() {
return (this.tagbits & tagbits.isbasetype) != 0;
}

/**
*  returns true if parameterized type and not of the form list<?>
*/
public boolean isboundparameterizedtype() {
return (this.tagbits & tagbits.isboundparameterizedtype) != 0;
}

/**
* returns true if the type is the capture of some wildcard
*/
public boolean iscapture() {
return false;
}

public boolean isclass() {
return false;
}

/* answer true if the receiver type can be assigned to the argument type (right)
*/
public abstract boolean iscompatiblewith(typebinding right);

public boolean isenum() {
return false;
}

/**
* returns true if a type is identical to another one,
* or for generic types, true if compared to its raw type.
*/
public boolean isequivalentto(typebinding othertype) {
if (this == othertype)
return true;
if (othertype == null)
return false;
switch (othertype.kind()) {
case binding.wildcard_type :
case binding.intersection_type :
return ((wildcardbinding) othertype).boundcheck(this);
}
return false;
}

public boolean isgenerictype() {
return false;
}

/* answer true if the receiver's hierarchy has problems (always false for arrays & base types)
*/
public final boolean ishierarchyinconsistent() {
return (this.tagbits & tagbits.hierarchyhasproblems) != 0;
}

public boolean isinterface() {
return false;
}

/**
* returns true if the current type denotes an intersection type: number & comparable<?>
*/
public boolean isintersectiontype() {
return false;
}

public final boolean islocaltype() {
return (this.tagbits & tagbits.islocaltype) != 0;
}

public final boolean ismembertype() {
return (this.tagbits & tagbits.ismembertype) != 0;
}

public final boolean isnestedtype() {
return (this.tagbits & tagbits.isnestedtype) != 0;
}

public final boolean isnumerictype() {
switch (this.id) {
case typeids.t_int:
case typeids.t_float:
case typeids.t_double:
case typeids.t_short:
case typeids.t_byte:
case typeids.t_long:
case typeids.t_char:
return true;
default:
return false;
}
}

/**
* returns true if the type is parameterized, e.g. list<string>.
* note that some instances of parameterizedtypebinding have no arguments, like for non-generic members
* of a parameterized type. use {@@link #isparameterizedtypewithactualarguments()} instead to find out.
*/
public final boolean isparameterizedtype() {
return kind() == binding.parameterized_type;
}

/**
* returns true if the type is parameterized, e.g. list<string>
* note that some instances of parameterizedtypebinding do answer false to {@@link #isparameterizedtype()}
* in case they have no arguments, like for non-generic members of a parameterized type.
* i.e. {@@link #isparameterizedtype()} is not equivalent to testing <code>type.kind() == binding.parameterized_type</code>
*/
public final boolean isparameterizedtypewithactualarguments() {
return (kind() == binding.parameterized_type)
&& ((parameterizedtypebinding) this).arguments != null;
}

/**
* returns true if the type is parameterized using its own type variables as arguments
*/
public boolean isparameterizedwithownvariables() {
if (kind() != binding.parameterized_type)
return false;
parameterizedtypebinding paramtype = (parameterizedtypebinding) this;
if (paramtype.arguments == null)
return false;
typevariablebinding[] variables = erasure().typevariables();
for (int i = 0, length = variables.length; i < length; i++) {
if (variables[i] != paramtype.arguments[i])
return false;
}
referencebinding enclosing = paramtype.enclosingtype();
if (enclosing != null && enclosing.erasure().isgenerictype()
&& !enclosing.isparameterizedwithownvariables()) {
return false;
}
return true;
}

private boolean isprovabledistinctsubtype(typebinding othertype) {
if (othertype.isinterface()) {
if (isinterface())
return false;
if (isarraytype()
|| ((this instanceof referencebinding) && ((referencebinding) this).isfinal())
|| (istypevariable() && ((typevariablebinding)this).superclass().isfinal())) {
return !iscompatiblewith(othertype);
}
return false;
} else {
if (isinterface()) {
if (othertype.isarraytype()
|| ((othertype instanceof referencebinding) && ((referencebinding) othertype).isfinal())
|| (othertype.istypevariable() && ((typevariablebinding)othertype).superclass().isfinal())) {
return !iscompatiblewith(othertype);
}
} else {
if (!istypevariable() && !othertype.istypevariable()) {
return !iscompatiblewith(othertype);
}
}
}
return false;
}

/**
* returns true if a type is provably distinct from another one,
*/
public boolean isprovablydistinct(typebinding othertype) {
if (this == othertype)
return false;
if (othertype == null)
return true;

switch (kind()) {

case binding.parameterized_type :
parameterizedtypebinding paramtype = (parameterizedtypebinding) this;
switch(othertype.kind()) {
case binding.parameterized_type :
parameterizedtypebinding otherparamtype = (parameterizedtypebinding) othertype;
if (paramtype.generictype() != otherparamtype.generictype())
return true;
if (!paramtype.isstatic()) { // static member types do not compare their enclosing
referencebinding enclosing = enclosingtype();
if (enclosing != null) {
referencebinding otherenclosing = otherparamtype.enclosingtype();
if (otherenclosing == null) return true;
if ((otherenclosing.tagbits & tagbits.hasdirectwildcard) == 0) {
if (enclosing.isprovablydistinct(otherenclosing)) return true; // https://bugs.eclipse.org/bugs/show_bug.cgi?id=302919
} else {
if (!enclosing.isequivalentto(otherparamtype.enclosingtype())) return true;
}
}
}
int length = paramtype.arguments == null ? 0 : paramtype.arguments.length;
typebinding[] otherarguments = otherparamtype.arguments;
int otherlength = otherarguments == null ? 0 : otherarguments.length;
if (otherlength != length)
return true;
for (int i = 0; i < length; i++) {
if (paramtype.arguments[i].isprovablydistincttypeargument(otherarguments[i], paramtype, i))
return true;
}
return false;

case binding.generic_type :
sourcetypebinding othergenerictype = (sourcetypebinding) othertype;
if (paramtype.generictype() != othergenerictype)
return true;
if (!paramtype.isstatic()) { // static member types do not compare their enclosing
referencebinding enclosing = enclosingtype();
if (enclosing != null) {
referencebinding otherenclosing = othergenerictype.enclosingtype();
if (otherenclosing == null) return true;
if ((otherenclosing.tagbits & tagbits.hasdirectwildcard) == 0) {
if (enclosing != otherenclosing) return true;
} else {
if (!enclosing.isequivalentto(othergenerictype.enclosingtype())) return true;
}
}
}
length = paramtype.arguments == null ? 0 : paramtype.arguments.length;
otherarguments = othergenerictype.typevariables();
otherlength = otherarguments == null ? 0 : otherarguments.length;
if (otherlength != length)
return true;
for (int i = 0; i < length; i++) {
if (paramtype.arguments[i].isprovablydistincttypeargument(otherarguments[i], paramtype, i))
return true;
}
return false;

case binding.raw_type :
return erasure() != othertype.erasure();
}
return true;

case binding.raw_type :

switch(othertype.kind()) {

case binding.generic_type :
case binding.parameterized_type :
case binding.raw_type :
return erasure() != othertype.erasure();
}
return true;

default :
break;
}
return true;
}

/**
* returns false if two given types could not intersect as argument types:
* list<throwable> & list<runnable> --> false
* list<? extends throwable> & list<? extends runnable> --> true
* list<? extends string> & list<? extends runnable> --> false
*/
private boolean isprovablydistincttypeargument(typebinding otherargument, final parameterizedtypebinding paramtype, final int rank) {
if (this == otherargument)
return false;

typebinding upperbound1 = null;
typebinding lowerbound1 = null;
switch (kind()) {
case binding.wildcard_type :
wildcardbinding wildcard = (wildcardbinding) this;
switch (wildcard.boundkind) {
case wildcard.extends:
upperbound1 = wildcard.bound;
break;
case wildcard.super:
lowerbound1 = wildcard.bound;
break;
case wildcard.unbound:
return false;
}
break;
case binding.intersection_type :
break;
case binding.type_parameter :
final typevariablebinding variable = (typevariablebinding) this;
if (variable.iscapture()) {
capturebinding capture = (capturebinding) variable;
switch (capture.wildcard.boundkind) {
case wildcard.extends:
upperbound1 = capture.wildcard.bound;
break;
case wildcard.super:
lowerbound1 = capture.wildcard.bound;
break;
case wildcard.unbound:
return false;
}
break;
}
if (variable.firstbound == null) // unbound variable
return false;
typebinding eliminatedtype = scope.converteliminatingtypevariables(variable, paramtype.generictype(), rank, null);
switch (eliminatedtype.kind()) {
case binding.wildcard_type :
case binding.intersection_type :
wildcard = (wildcardbinding) eliminatedtype;
switch (wildcard.boundkind) {
case wildcard.extends:
upperbound1 = wildcard.bound;
break;
case wildcard.super:
lowerbound1 = wildcard.bound;
break;
case wildcard.unbound:
return false;
}
break;
}
break;
}
typebinding upperbound2 = null;
typebinding lowerbound2 = null;
switch (otherargument.kind()) {
case binding.wildcard_type :
wildcardbinding otherwildcard = (wildcardbinding) otherargument;
switch (otherwildcard.boundkind) {
case wildcard.extends:
upperbound2 = otherwildcard.bound;
break;
case wildcard.super:
lowerbound2 = otherwildcard.bound;
break;
case wildcard.unbound:
return false;
}
break;
case binding.intersection_type :
break;
case binding.type_parameter :
typevariablebinding othervariable = (typevariablebinding) otherargument;
if (othervariable.iscapture()) {
capturebinding othercapture = (capturebinding) othervariable;
switch (othercapture.wildcard.boundkind) {
case wildcard.extends:
upperbound2 = othercapture.wildcard.bound;
break;
case wildcard.super:
lowerbound2 = othercapture.wildcard.bound;
break;
case wildcard.unbound:
return false;
}
break;
}
if (othervariable.firstbound == null) // unbound variable
return false;
typebinding othereliminatedtype = scope.converteliminatingtypevariables(othervariable, paramtype.generictype(), rank, null);
switch (othereliminatedtype.kind()) {
case binding.wildcard_type :
case binding.intersection_type :
otherwildcard = (wildcardbinding) othereliminatedtype;
switch (otherwildcard.boundkind) {
case wildcard.extends:
upperbound2 = otherwildcard.bound;
break;
case wildcard.super:
lowerbound2 = otherwildcard.bound;
break;
case wildcard.unbound:
return false;
}
break;
}			break;
}
if (lowerbound1 != null) {
if (lowerbound2 != null) {
return false; // object could always be a candidate

} else if (upperbound2 != null) {
if (lowerbound1.istypevariable() || upperbound2.istypevariable()) {
return false;
}
return !lowerbound1.iscompatiblewith(upperbound2);
} else {
if (lowerbound1.istypevariable() || otherargument.istypevariable()) {
return false;
}
return !lowerbound1.iscompatiblewith(otherargument);
}
} else if (upperbound1 != null) {
if (lowerbound2 != null) {
return !lowerbound2.iscompatiblewith(upperbound1);
} else if (upperbound2 != null) {
return upperbound1.isprovabledistinctsubtype(upperbound2)
&& upperbound2.isprovabledistinctsubtype(upperbound1);
} else {
return otherargument.isprovabledistinctsubtype(upperbound1);
}
} else {
if (lowerbound2 != null) {
if (lowerbound2.istypevariable() || istypevariable()) {
return false;
}
return !lowerbound2.iscompatiblewith(this);
} else if (upperbound2 != null) {
return isprovabledistinctsubtype(upperbound2);
} else {
return true; // ground types should have been the same
}
}
}

public final boolean israwtype() {
return kind() == binding.raw_type;
}
/**
* jls(3) 4.7.
* note: foo<?>.bar is also reifiable
*/
public boolean isreifiable() {
typebinding leaftype = leafcomponenttype();
if (!(leaftype instanceof referencebinding))
return true;
referencebinding current = (referencebinding) leaftype;
do {
switch (current.kind()) {
case binding.type_parameter:
case binding.wildcard_type:
case binding.intersection_type:
case binding.generic_type:
return false;
case binding.parameterized_type:
if (current.isboundparameterizedtype())
return false;
break;
case binding.raw_type:
return true;
}
if (current.isstatic()) {
return true;
}
if (current.islocaltype()) {
localtypebinding localtypebinding = (localtypebinding) current.erasure();
methodbinding enclosingmethod = localtypebinding.enclosingmethod;
if (enclosingmethod != null && enclosingmethod.isstatic()) {
return true;
}
}
} while ((current = current.enclosingtype()) != null);
return true;
}

/**
* returns true if a given type may be thrown
*/
public boolean isthrowable() {
return false;
}
// jls3: 4.5.1.1
public boolean istypeargumentcontainedby(typebinding othertype) {
if (this == othertype)
return true;
switch (othertype.kind()) {
// allow wildcard containment
case binding.wildcard_type:
case binding.intersection_type:

typebinding lowerbound = this;
typebinding upperbound = this;
switch (kind()) {
case binding.wildcard_type:
case binding.intersection_type:
wildcardbinding wildcard = (wildcardbinding) this;
switch (wildcard.boundkind) {
case wildcard.extends:
if (wildcard.otherbounds != null) // intersection type
break;
upperbound = wildcard.bound;
lowerbound = null;
break;
case wildcard.super:
upperbound = wildcard;
lowerbound = wildcard.bound;
break;
case wildcard.unbound:
upperbound = wildcard;
lowerbound = null;
}
break;
case binding.type_parameter:
if (iscapture()) {
capturebinding capture = (capturebinding) this;
if (capture.lowerbound != null)
lowerbound = capture.lowerbound;
}
}
wildcardbinding otherwildcard = (wildcardbinding) othertype;
if (otherwildcard.otherbounds != null)
return false; // not a true wildcard (intersection type)
typebinding otherbound = otherwildcard.bound;
switch (otherwildcard.boundkind) {
case wildcard.extends:
if (otherbound == this)
return true; // ? extends t  <=  ? extends ? extends t
if (upperbound == null)
return false;
typebinding match = upperbound.findsupertypeoriginatingfrom(otherbound);
if (match != null && (match = match.leafcomponenttype()).israwtype()) {
return match == otherbound.leafcomponenttype(); // forbide: collection <=  ? extends collection<?>
// forbide: collection[] <=  ? extends collection<?>[]
}
return upperbound.iscompatiblewith(otherbound);

case wildcard.super:
if (otherbound == this)
return true; // ? super t  <=  ? super ? super t
if (lowerbound == null)
return false;
match = otherbound.findsupertypeoriginatingfrom(lowerbound);
if (match != null && (match = match.leafcomponenttype()).israwtype()) {
return match == lowerbound.leafcomponenttype(); // forbide: collection <=  ? super collection<?>
// forbide: collection[] <=  ? super collection<?>[]
}
return otherbound.iscompatiblewith(lowerbound);

case wildcard.unbound:
default:
return true;
}
// allow list<?> to match list<? extends object> (and reciprocally)
case binding.parameterized_type:
if (!isparameterizedtype())
return false;
parameterizedtypebinding paramtype = (parameterizedtypebinding) this;
parameterizedtypebinding otherparamtype = (parameterizedtypebinding) othertype;
if (paramtype.actualtype() != otherparamtype.actualtype())
return false;
if (!paramtype.isstatic()) { // static member types do not compare their enclosing
referencebinding enclosing = enclosingtype();
if (enclosing != null) {
referencebinding otherenclosing = otherparamtype	.enclosingtype();
if (otherenclosing == null)
return false;
if ((otherenclosing.tagbits & tagbits.hasdirectwildcard) == 0) {
if (enclosing != otherenclosing)
return false;
} else {
if (!enclosing.isequivalentto(otherparamtype.enclosingtype()))
return false;
}
}
}
int length = paramtype.arguments == null ? 0 : paramtype.arguments.length;
typebinding[] otherarguments = otherparamtype.arguments;
int otherlength = otherarguments == null ? 0 : otherarguments.length;
if (otherlength != length)
return false;
nextargument: for (int i = 0; i < length; i++) {
typebinding argument = paramtype.arguments[i];
typebinding otherargument = otherarguments[i];
if (argument == otherargument)
continue nextargument;
int kind = argument.kind();
if (otherargument.kind() != kind)
return false;
switch (kind) {
case binding.parameterized_type:
if (argument.istypeargumentcontainedby(otherargument)) // recurse
continue nextargument;
break;
case binding.wildcard_type:
case binding.intersection_type:
wildcardbinding wildcard = (wildcardbinding) argument;
otherwildcard = (wildcardbinding) otherargument;
switch (wildcard.boundkind) {
case wildcard.extends:
// match "? extends <upperbound>" with "?"
if (otherwildcard.boundkind == wildcard.unbound
&& wildcard.bound == wildcard.typevariable().upperbound())
continue nextargument;
break;
case wildcard.super:
break;
case wildcard.unbound:
// match "?" with "? extends <upperbound>"
if (otherwildcard.boundkind == wildcard.extends
&& otherwildcard.bound == otherwildcard.typevariable().upperbound())
continue nextargument;
break;
}
break;
}
return false;
}
return true;
}
// (? super object) <= object
if (othertype.id == typeids.t_javalangobject) {
switch (kind()) {
case binding.wildcard_type:
wildcardbinding wildcard = (wildcardbinding) this;
if (wildcard.boundkind == wildcard.super && wildcard.bound.id == typeids.t_javalangobject) {
return true;
}
break;
}
}
return false;
}

/**
* returns true if the type was declared as a type variable
*/
public boolean istypevariable() {
return false;
}

/**
* returns true if wildcard type of the form '?' (no bound)
*/
public boolean isunboundwildcard() {
return false;
}

/**
* returns true if the type is a subclass of java.lang.error or java.lang.runtimeexception
*/
public boolean isuncheckedexception(boolean includesupertype) {
return false;
}

/**
* returns true if the type is a wildcard
*/
public boolean iswildcard() {
return false;
}

/* api
* answer the receiver's binding type from binding.bindingid.
*/
public int kind() {
return binding.type;
}

public typebinding leafcomponenttype() {
return this;
}

/**
* meant to be invoked on compatible types, to figure if unchecked conversion is necessary
*/
public boolean needsuncheckedconversion(typebinding targettype) {

if (this == targettype)
return false;
targettype = targettype.leafcomponenttype();
if (!(targettype instanceof referencebinding))
return false;

typebinding currenttype = leafcomponenttype();
typebinding match = currenttype.findsupertypeoriginatingfrom(targettype);
if (!(match instanceof referencebinding))
return false;
referencebinding compatible = (referencebinding) match;
while (compatible.israwtype()) {
if (targettype.isboundparameterizedtype())
return true;
if (compatible.isstatic())
break;
if ((compatible = compatible.enclosingtype()) == null)
break;
if ((targettype = targettype.enclosingtype()) == null)
break;
}
return false;
}

/**
* returns the orignal generic type instantiated by the receiver type, or itself if not.
* this is similar to erasure process, except it doesn't erase type variable, wildcard, intersection types etc...
*/
public typebinding original() {
switch(kind()) {
case binding.parameterized_type :
case binding.raw_type :
case binding.array_type :
return erasure();
default :
return this;
}
}

/**
* answer the qualified name of the receiver's package separated by periods
* or an empty string if its the default package.
*
* for example, {java.util}.
*/

public char[] qualifiedpackagename() {
packagebinding packagebinding = getpackage();
return packagebinding == null
|| packagebinding.compoundname == charoperation.no_char_char ? charoperation.no_char
: packagebinding.readablename();
}

/**
* answer the source name for the type.
* in the case of member types, as the qualified name from its top level type.
* for example, for a member type n defined inside m & a: "a.m.n".
*/

public abstract char[] qualifiedsourcename();

/**
* answer the receiver classfile signature.
* arrays & base types do not distinguish between signature() & constantpoolname().
* note: this method should only be used during/after code gen.
*/
public char[] signature() {
return constantpoolname();
}

public abstract char[] sourcename();

public void swapunresolved(unresolvedreferencebinding unresolvedtype,
referencebinding resolvedtype, lookupenvironment environment) {
// subclasses must override if they wrap another type binding
}

public typevariablebinding[] typevariables() {
return binding.no_type_variables;
}
}
