/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.lookup.*;
import org.eclipse.jdt.internal.compiler.parser.scannerhelper;

public class charliteral extends numberliteral {

char value;

public charliteral(char[] token, int s, int e) {
super(token, s, e);
computevalue();
}

public void computeconstant() {
//the source is a  char[3] first and last char are '
//this is true for both regular char and unicode char
//but not for escape char like '\b' which are char[4]....
this.constant = charconstant.fromvalue(this.value);
}

private void computevalue() {
//the source is a  char[3] first and last char are '
//this is true for both regular char and unicode char
//but not for escape char like '\b' which are char[4]....
if ((this.value = this.source[1]) != '\\')
return;
char digit;
switch (digit = this.source[2]) {
case 'b' :
this.value = '\b';
break;
case 't' :
this.value = '\t';
break;
case 'n' :
this.value = '\n';
break;
case 'f' :
this.value = '\f';
break;
case 'r' :
this.value = '\r';
break;
case '\"' :
this.value = '\"';
break;
case '\'' :
this.value = '\'';
break;
case '\\' :
this.value = '\\';
break;
default : //octal (well-formed: ended by a ' )
int number = scannerhelper.getnumericvalue(digit);
if ((digit = this.source[3]) != '\'')
number = (number * 8) + scannerhelper.getnumericvalue(digit);
else {
this.constant = charconstant.fromvalue(this.value = (char) number);
break;
}
if ((digit = this.source[4]) != '\'')
number = (number * 8) + scannerhelper.getnumericvalue(digit);
this.value = (char) number;
break;
}
}

/**
* charliteral code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {
int pc = codestream.position;
if (valuerequired) {
codestream.generateconstant(this.constant, this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public typebinding literaltype(blockscope scope) {
return typebinding.char;
}

public void traverse(astvisitor visitor, blockscope blockscope) {
visitor.visit(this, blockscope);
visitor.endvisit(this, blockscope);
}
}
