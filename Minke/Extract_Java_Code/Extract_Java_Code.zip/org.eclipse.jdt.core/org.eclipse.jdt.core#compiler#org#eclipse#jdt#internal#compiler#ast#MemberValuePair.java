/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.elementvaluepair;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

/**
* membervaluepair node
*/
public class membervaluepair extends astnode {

public char[] name;
public expression value;
public methodbinding binding;
/**
*  the representation of this pair in the type system.
*/
public elementvaluepair compilerelementpair = null;

public membervaluepair(char[] token, int sourcestart, int sourceend, expression value) {
this.name = token;
this.sourcestart = sourcestart;
this.sourceend = sourceend;
this.value = value;
if (value instanceof arrayinitializer) {
value.bits |= isannotationdefaultvalue;
}
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#print(int, java.lang.stringbuffer)
*/
public stringbuffer print(int indent, stringbuffer output) {
output
.append(this.name)
.append(" = "); //$non-nls-1$
this.value.print(0, output);
return output;
}

public void resolvetypeexpecting(blockscope scope, typebinding requiredtype) {

if (this.value == null) {
this.compilerelementpair = new elementvaluepair(this.name, this.value, this.binding);
return;
}
if (requiredtype == null) {
// fault tolerance: keep resolving
if (this.value instanceof arrayinitializer) {
this.value.resolvetypeexpecting(scope, null);
} else {
this.value.resolvetype(scope);
}
this.compilerelementpair = new elementvaluepair(this.name, this.value, this.binding);
return;
}

this.value.setexpectedtype(requiredtype); // needed in case of generic method invocation
typebinding valuetype;
if (this.value instanceof arrayinitializer) {
arrayinitializer initializer = (arrayinitializer) this.value;
valuetype = initializer.resolvetypeexpecting(scope, this.binding.returntype);
} else if (this.value instanceof arrayallocationexpression) {
scope.problemreporter().annotationvaluemustbearrayinitializer(this.binding.declaringclass, this.name, this.value);
this.value.resolvetype(scope);
valuetype = null; // no need to pursue
} else {
valuetype = this.value.resolvetype(scope);
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=248897
astvisitor visitor = new astvisitor() {
public boolean visit(singlenamereference reference, blockscope scop) {
if (reference.binding instanceof localvariablebinding) {
((localvariablebinding) reference.binding).useflag = localvariablebinding.used;
}
return true;
}
};
this.value.traverse(visitor, scope);
}
this.compilerelementpair = new elementvaluepair(this.name, this.value, this.binding);
if (valuetype == null)
return;

typebinding leaftype = requiredtype.leafcomponenttype();
if (!(this.value.isconstantvalueoftypeassignabletotype(valuetype, requiredtype)
|| valuetype.iscompatiblewith(requiredtype))) {

if (!(requiredtype.isarraytype()
&& requiredtype.dimensions() == 1
&& (this.value.isconstantvalueoftypeassignabletotype(valuetype, leaftype)
|| valuetype.iscompatiblewith(leaftype)))) {

if (leaftype.isannotationtype() && !valuetype.isannotationtype()) {
scope.problemreporter().annotationvaluemustbeannotation(this.binding.declaringclass, this.name, this.value, leaftype);
} else {
scope.problemreporter().typemismatcherror(valuetype, requiredtype, this.value, null);
}
return; // may allow to proceed to find more errors at once
}
} else {
scope.compilationunitscope().recordtypeconversion(requiredtype.leafcomponenttype(), valuetype.leafcomponenttype());
this.value.computeconversion(scope, requiredtype, valuetype);
}

// annotation methods can only return base types, string, class, enum type, annotation types and arrays of these
checkannotationmethodtype: {
switch (leaftype.erasure().id) {
case t_byte :
case t_short :
case t_char :
case t_int :
case t_long :
case t_float :
case t_double :
case t_boolean :
case t_javalangstring :
if (this.value instanceof arrayinitializer) {
arrayinitializer initializer = (arrayinitializer) this.value;
final expression[] expressions = initializer.expressions;
if (expressions != null) {
for (int i =0, max = expressions.length; i < max; i++) {
expression expression = expressions[i];
if (expression.resolvedtype == null) continue; // fault-tolerance
if (expression.constant == constant.notaconstant) {
scope.problemreporter().annotationvaluemustbeconstant(this.binding.declaringclass, this.name, expressions[i], false);
}
}
}
} else if (this.value.constant == constant.notaconstant) {
if (valuetype.isarraytype()) {
scope.problemreporter().annotationvaluemustbearrayinitializer(this.binding.declaringclass, this.name, this.value);
} else {
scope.problemreporter().annotationvaluemustbeconstant(this.binding.declaringclass, this.name, this.value, false);
}
}
break checkannotationmethodtype;
case t_javalangclass :
if (this.value instanceof arrayinitializer) {
arrayinitializer initializer = (arrayinitializer) this.value;
final expression[] expressions = initializer.expressions;
if (expressions != null) {
for (int i =0, max = expressions.length; i < max; i++) {
expression currentexpression = expressions[i];
if (!(currentexpression instanceof classliteralaccess)) {
scope.problemreporter().annotationvaluemustbeclassliteral(this.binding.declaringclass, this.name, currentexpression);
}
}
}
} else if (!(this.value instanceof classliteralaccess)) {
scope.problemreporter().annotationvaluemustbeclassliteral(this.binding.declaringclass, this.name, this.value);
}
break checkannotationmethodtype;
}
if (leaftype.isenum()) {
if (this.value instanceof nullliteral) {
scope.problemreporter().annotationvaluemustbeconstant(this.binding.declaringclass, this.name, this.value, true);
} else if (this.value instanceof arrayinitializer) {
arrayinitializer initializer = (arrayinitializer) this.value;
final expression[] expressions = initializer.expressions;
if (expressions != null) {
for (int i =0, max = expressions.length; i < max; i++) {
expression currentexpression = expressions[i];
if (currentexpression instanceof nullliteral) {
scope.problemreporter().annotationvaluemustbeconstant(this.binding.declaringclass, this.name, currentexpression, true);
} else if (currentexpression instanceof namereference) {
namereference namereference = (namereference) currentexpression;
final binding namereferencebinding = namereference.binding;
if (namereferencebinding.kind() == binding.field) {
fieldbinding fieldbinding = (fieldbinding) namereferencebinding;
if (!fieldbinding.declaringclass.isenum()) {
scope.problemreporter().annotationvaluemustbeconstant(this.binding.declaringclass, this.name, currentexpression, true);
}
}
}
}
}
} else if (this.value instanceof namereference) {
namereference namereference = (namereference) this.value;
final binding namereferencebinding = namereference.binding;
if (namereferencebinding.kind() == binding.field) {
fieldbinding fieldbinding = (fieldbinding) namereferencebinding;
if (!fieldbinding.declaringclass.isenum()) {
if (!fieldbinding.type.isarraytype()) {
scope.problemreporter().annotationvaluemustbeconstant(this.binding.declaringclass, this.name, this.value, true);
} else {
scope.problemreporter().annotationvaluemustbearrayinitializer(this.binding.declaringclass, this.name, this.value);
}
}
}
}  else {
scope.problemreporter().annotationvaluemustbeconstant(this.binding.declaringclass, this.name, this.value, true);
}
break checkannotationmethodtype;
}
if (leaftype.isannotationtype()) {
if (!valuetype.leafcomponenttype().isannotationtype()) { // check annotation type and also reject null literal
scope.problemreporter().annotationvaluemustbeannotation(this.binding.declaringclass, this.name, this.value, leaftype);
} else if (this.value instanceof arrayinitializer) {
arrayinitializer initializer = (arrayinitializer) this.value;
final expression[] expressions = initializer.expressions;
if (expressions != null) {
for (int i =0, max = expressions.length; i < max; i++) {
expression currentexpression = expressions[i];
if (currentexpression instanceof nullliteral || !(currentexpression instanceof annotation)) {
scope.problemreporter().annotationvaluemustbeannotation(this.binding.declaringclass, this.name, currentexpression, leaftype);
}
}
}
} else if (!(this.value instanceof annotation)) {
scope.problemreporter().annotationvaluemustbeannotation(this.binding.declaringclass, this.name, this.value, leaftype);
}
break checkannotationmethodtype;
}
}
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.value != null) {
this.value.traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
