/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;

/**
* flatten string literal
*/
public class stringliteralconcatenation extends stringliteral {
private static final int initial_size = 5;
public expression[] literals;
public int counter;
/**
* build a two-strings literal
* */
public stringliteralconcatenation(stringliteral str1, stringliteral str2) {
super(str1.sourcestart, str1.sourceend);
this.source = str1.source;
this.literals = new stringliteral[initial_size];
this.counter = 0;
this.literals[this.counter++] = str1;
extendswith(str2);
}

/**
*  add the lit source to mine, just as if it was mine
*/
public stringliteralconcatenation extendswith(stringliteral lit) {
this.sourceend = lit.sourceend;
final int literalslength = this.literals.length;
if (this.counter == literalslength) {
// resize
system.arraycopy(this.literals, 0, this.literals = new stringliteral[literalslength + initial_size], 0, literalslength);
}
//uddate the source
int length = this.source.length;
system.arraycopy(
this.source,
0,
this.source = new char[length + lit.source.length],
0,
length);
system.arraycopy(lit.source, 0, this.source, length, lit.source.length);
this.literals[this.counter++] = lit;
return this;
}

public stringbuffer printexpression(int indent, stringbuffer output) {
output.append("stringliteralconcatenation{"); //$non-nls-1$
for (int i = 0, max = this.counter; i < max; i++) {
this.literals[i].printexpression(indent, output);
output.append("+\n");//$non-nls-1$
}
return output.append('}');
}

public char[] source() {
return this.source;
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
for (int i = 0, max = this.counter; i < max; i++) {
this.literals[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
