/*******************************************************************************
* copyright (c) 2005, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import org.eclipse.jdt.core.completioncontext;
import org.eclipse.jdt.core.icompilationunit;
import org.eclipse.jdt.core.ifield;
import org.eclipse.jdt.core.ijavaelement;
import org.eclipse.jdt.core.ilocalvariable;
import org.eclipse.jdt.core.imember;
import org.eclipse.jdt.core.imethod;
import org.eclipse.jdt.core.ityperoot;
import org.eclipse.jdt.core.signature;
import org.eclipse.jdt.core.workingcopyowner;
import org.eclipse.jdt.internal.codeassist.complete.completiononjavadoc;
import org.eclipse.jdt.internal.codeassist.complete.completionparser;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.compilationunitdeclaration;
import org.eclipse.jdt.internal.compiler.lookup.lookupenvironment;
import org.eclipse.jdt.internal.compiler.lookup.scope;


/**
* internal completion context
* @@since 3.1
*/
public class internalcompletioncontext extends completioncontext {
protected char[][] expectedtypessignatures;
protected char[][] expectedtypeskeys;
protected int javadoc;

protected int offset = -1;
protected int tokenstart = -1;
protected int tokenend = -1;
protected char[] token = null;
protected int tokenkind;
protected int tokenlocation;

protected boolean isextended;
protected internalextendedcompletioncontext extendedcontext;

protected void setexpectedtypeskeys(char[][] expectedtypeskeys) {
this.expectedtypeskeys = expectedtypeskeys;
}

protected void setexpectedtypessignatures(char[][] expectedtypessignatures) {
this.expectedtypessignatures = expectedtypessignatures;
}

protected void setextended() {
this.isextended = true;
}

protected void setextendeddata(
ityperoot typeroot,
compilationunitdeclaration compilationunitdeclaration,
lookupenvironment lookupenvironment,
scope scope,
astnode astnode,
workingcopyowner owner,
completionparser parser) {
this.isextended = true;
this.extendedcontext =
new internalextendedcompletioncontext(
this,
typeroot,
compilationunitdeclaration,
lookupenvironment,
scope,
astnode,
owner,
parser);
}

protected void setjavadoc(int javadoc) {
this.javadoc = javadoc;
}

protected void setoffset(int offset) {
this.offset = offset;
}

protected void settoken(char[] token) {
this.token = token;
}

protected void settokenkind(int tokenkind) {
this.tokenkind = tokenkind;
}

protected void settokenlocation(int tokenlocation) {
this.tokenlocation = tokenlocation;
}

protected void settokenrange(int start, int end) {
this.settokenrange(start, end, -1);
}

protected void settokenrange(int start, int end, int endofemptytoken) {
this.tokenstart = start;
this.tokenend = endofemptytoken > end ? endofemptytoken : end;

// work around for bug 132558 (https://bugs.eclipse.org/bugs/show_bug.cgi?id=132558).
// completionlocation can be -1 if the completion occur at the start of a file or
// the start of a code snippet but this api isn't design to support negative position.
if(this.tokenend == -1) {
this.tokenend = 0;
}
}

/**
* returns the innermost enclosing java element which contains the completion location or <code>null</code> if this element cannot be computed.
* the returned java element and all java elements in the same compilation unit which can be navigated to from the returned java element are special java elements:
* <ul>
* <li>they are based on the current content of the compilation unit's buffer, they are not the result of a reconcile operation</li>
* <li>they are not updated if the buffer changes.</li>
* <li>they do not contain local types which are not visible from the completion location.</li>
* <li>they do not give information about categories. {@@link imember#getcategories()} will return an empty array</li>
* </ul>
*
* reasons for returning <code>null</code> include:
* <ul>
* <li>the compilation unit no longer exists</li>
* <li>the completion occurred in a binary type. however this restriction might be relaxed in the future.</li>
* </ul>
*
* @@return the innermost enclosing java element which contains the completion location or <code>null</code> if this element cannot be computed.
*
* @@exception unsupportedoperationexception if the context is not an extended context
*
* @@since 3.4
*/
public ijavaelement getenclosingelement() {
if (!this.isextended) throw new unsupportedoperationexception("operation only supported in extended context"); //$non-nls-1$

if (this.extendedcontext == null) return null;

return this.extendedcontext.getenclosingelement();
}

/**
* return keys of expected types of a potential completion proposal at the completion position.
*
* it's not mandatory to a completion proposal to respect this expectation.
*
* @@return keys of expected types of a potential completion proposal at the completion position or
* <code>null</code> if there is no expected types.
*
* @@see org.eclipse.jdt.core.dom.astparser#createasts(icompilationunit[], string[], org.eclipse.jdt.core.dom.astrequestor, org.eclipse.core.runtime.iprogressmonitor)
*/
public char[][] getexpectedtypeskeys() {
return this.expectedtypeskeys;
}

/**
* return signatures of expected types of a potential completion proposal at the completion position.
*
* it's not mandatory to a completion proposal to respect this expectation.
*
* @@return signatures expected types of a potential completion proposal at the completion position or
* <code>null</code> if there is no expected types.
*
* @@see signature
*/
public char[][] getexpectedtypessignatures() {
return this.expectedtypessignatures;
}

/**
* returns the offset position in the source file buffer
* after which code assist is requested.
*
* @@return offset position in the source file buffer
* @@since 3.2
*/
public int getoffset() {
return this.offset;
}

/**
* returns the completed token.
* this token is either the identifier or java language keyword
* or the string literal under, immediately preceding,
* the original request offset. if the original request offset
* is not within or immediately after an identifier or keyword or
* a string literal then the returned value is <code>null</code>.
*
* @@return completed token or <code>null</code>
* @@since 3.2
*/
public char[] gettoken() {
return this.token;
}

/**
* returns the character index of the end (exclusive) of the subrange
* in the source file buffer containing the
* relevant token. when there is no relevant token, the
* range is empty
* (<code>gettokenend() == gettokenstart() - 1</code>).
*
* @@return character index of token end position (exclusive)
* @@since 3.2
*/
// todo (david) https://bugs.eclipse.org/bugs/show_bug.cgi?id=132558
public int gettokenend() {
return this.tokenend;
}

/**
* returns the kind of completion token being proposed.
* <p>
* the set of different kinds of completion token is
* expected to change over time. it is strongly recommended
* that clients do <b>not</b> assume that the kind is one of the
* ones they know about, and code defensively for the
* possibility of unexpected future growth.
* </p>
*
* @@return the kind; one of the kind constants declared on
* this class whose name starts with <code>token_kind</code>,
* or possibly a kind unknown to the caller
* @@since 3.2
*/
public int gettokenkind() {
return this.tokenkind;
}

/**
* returns the location of completion token being proposed.
* the returned location is a bit mask which can contain some values
* of the constants declared on this class whose name starts with <code>tl</code>,
* or possibly values unknown to the caller.
*
* <p>
* the set of different location values is expected to change over time.
* it is strongly recommended that clients do <b>not</b> assume that
* the location contains only known value, and code defensively for
* the possibility of unexpected future growth.
* </p>
*
* @@return the location
*
* @@since 3.4
*/
public int gettokenlocation() {
return this.tokenlocation;
}

/**
* returns the character index of the start of the
* subrange in the source file buffer containing the
* relevant token being completed. this
* token is either the identifier or java language keyword
* under, or immediately preceding, the original request
* offset. if the original request offset is not within
* or immediately after an identifier or keyword, then the
* position returned is original request offset and the
* token range is empty.
*
* @@return character index of token start position (inclusive)
* @@since 3.2
*/
public int gettokenstart() {
return this.tokenstart;
}

/**
* return the elements which are visible from the completion location and which can be assigned to the given type.
* an element is assignable if its type can be assigned to a variable
* of the given type, as specified in section 5.2 of <em>the java language
* specification, third edition</em> (jls3).
* a visible element is either:
* <ul>
* <li>a {@@link ilocalvariable} - the element type is {@@link ilocalvariable#gettypesignature()}</li>
* <li>a {@@link ifield} - the element type is {@@link ifield#gettypesignature()}</li>
* <li>a {@@link imethod} - the element type is {@@link imethod#getreturntype()}</li>
* </ul>
*
* returned elements defined in the completed compilation unit are special java elements:
* <ul>
* <li>they are based on the current content of the compilation unit's buffer, they are not the result of a reconcile operation</li>
* <li>they are not updated if the buffer changes.</li>
* <li>they do not contain local types which are not visible from the completion location.</li>
* <li>they do not give information about categories. {@@link imember#getcategories()} will return an empty array</li>
* </ul>
*
* note the array can be empty if:
* <ul>
* <li>the compilation unit no longer exists</li>
* <li>the completion occurred in a binary type. however this restriction might be relaxed in the future.</li>
* </ul>
*
* @@param typesignature elements which can be assigned to this type are returned.
* 		if <code>null</code> there is no constraint on the type of the returned elements.
*
* @@return elements which are visible from the completion location and which can be assigned to the given type.
*
* @@exception unsupportedoperationexception if the context is not an extended context
*
* @@see #isextended()
*
* @@since 3.4
*/
public ijavaelement[] getvisibleelements(string typesignature) {
if (!this.isextended) throw new unsupportedoperationexception("operation only supported in extended context"); //$non-nls-1$

if (this.extendedcontext == null) return new ijavaelement[0];

return this.extendedcontext.getvisibleelements(typesignature);
}

/**
* returns whether this completion context is an extended context.
* some methods of this context can be used only if this context is an extended context but an extended context consumes more memory.
*
* @@return <code>true</code> if this completion context is an extended context.
*
* @@since 3.4
*/
public boolean isextended() {
return this.isextended;
}

/**
* tell user whether completion takes place in a javadoc comment or not.
*
* @@return boolean true if completion takes place in a javadoc comment, false otherwise.
* @@since 3.2
*/
public boolean isinjavadoc() {
return this.javadoc != 0;
}

/**
* tell user whether completion takes place in a formal reference of a javadoc tag or not.
* tags with formal reference are:
* <ul>
* 	<li>&#64;see</li>
* 	<li>&#64;throws</li>
* 	<li>&#64;exception</li>
* 	<li>{&#64;link object}</li>
* 	<li>{&#64;linkplain object}</li>
* 	<li>{&#64;value} when compiler compliance is set at leats to 1.5</li>
* </ul>
*
* @@return boolean true if completion takes place in formal reference of a javadoc tag, false otherwise.
* @@since 3.2
*/
public boolean isinjavadocformalreference() {
return (this.javadoc & completiononjavadoc.formal_reference) != 0;
}

/**
* tell user whether completion takes place in text area of a javadoc comment or not.
*
* @@return boolean true if completion takes place in a text area of a javadoc comment, false otherwise.
* @@since 3.2
*/
public boolean isinjavadoctext() {
return (this.javadoc & completiononjavadoc.text) != 0;
}
}
