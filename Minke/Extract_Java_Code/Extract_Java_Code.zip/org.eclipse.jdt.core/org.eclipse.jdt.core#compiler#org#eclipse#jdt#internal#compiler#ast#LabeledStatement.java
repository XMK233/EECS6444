/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class labeledstatement extends statement {

public statement statement;
public char[] label;
public branchlabel targetlabel;
public int labelend;

// for local variables table attributes
int mergedinitstateindex = -1;

/**
* labeledstatement constructor comment.
*/
public labeledstatement(char[] label, statement statement, long labelposition, int sourceend) {

this.statement = statement;
// remember useful empty statement
if (statement instanceof emptystatement) statement.bits |= isusefulemptystatement;
this.label = label;
this.sourcestart = (int)(labelposition >>> 32);
this.labelend = (int) labelposition;
this.sourceend = sourceend;
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {

// need to stack a context to store explicit label, answer inits in case of normal completion merged
// with those relative to the exit path from break statement occurring inside the labeled statement.
if (this.statement == null) {
return flowinfo;
} else {
labelflowcontext labelcontext;
flowinfo statementinfo, mergedinfo;
statementinfo = this.statement.analysecode(
currentscope,
(labelcontext =
new labelflowcontext(
flowcontext,
this,
this.label,
(this.targetlabel = new branchlabel()),
currentscope)),
flowinfo);
boolean reinjectnullinfo = (statementinfo.tagbits & flowinfo.unreachable) != 0 &&
(labelcontext.initsonbreak.tagbits & flowinfo.unreachable) == 0;
mergedinfo = statementinfo.mergedwith(labelcontext.initsonbreak);
if (reinjectnullinfo) {
// an embedded loop has had no chance to reinject forgotten null info
((unconditionalflowinfo)mergedinfo).addinitializationsfrom(flowinfo.unconditionalfieldlesscopy()).
addinitializationsfrom(labelcontext.initsonbreak.unconditionalfieldlesscopy());
}
this.mergedinitstateindex =
currentscope.methodscope().recordinitializationstates(mergedinfo);
if ((this.bits & astnode.labelused) == 0) {
currentscope.problemreporter().unusedlabel(this);
}
return mergedinfo;
}
}

public astnode concretestatement() {

// return statement.concretestatement(); // for supporting nested labels:   a:b:c: somestatement (see 21912)
return this.statement;
}

/**
* code generation for labeled statement
*
* may not need actual source positions recording
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {

if ((this.bits & isreachable) == 0) {
return;
}
int pc = codestream.position;
if (this.targetlabel != null) {
this.targetlabel.initialize(codestream);
if (this.statement != null) {
this.statement.generatecode(currentscope, codestream);
}
this.targetlabel.place();
}
// may loose some local variable initializations : affecting the local variable attributes
if (this.mergedinitstateindex != -1) {
codestream.removenotdefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
codestream.adddefinitelyassignedvariables(currentscope, this.mergedinitstateindex);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}

public stringbuffer printstatement(int tab, stringbuffer output) {

printindent(tab, output).append(this.label).append(": "); //$non-nls-1$
if (this.statement == null)
output.append(';');
else
this.statement.printstatement(0, output);
return output;
}

public void resolve(blockscope scope) {

if (this.statement != null) {
this.statement.resolve(scope);
}
}


public void traverse(
astvisitor visitor,
blockscope blockscope) {

if (visitor.visit(this, blockscope)) {
if (this.statement != null) this.statement.traverse(visitor, blockscope);
}
visitor.endvisit(this, blockscope);
}
}
