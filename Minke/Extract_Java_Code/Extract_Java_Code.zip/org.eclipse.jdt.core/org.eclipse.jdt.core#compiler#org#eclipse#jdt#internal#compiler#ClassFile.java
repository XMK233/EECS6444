/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler;

import java.util.arraylist;
import java.util.arrays;
import java.util.collections;
import java.util.comparator;
import java.util.hashset;
import java.util.list;
import java.util.set;

import org.eclipse.jdt.core.compiler.categorizedproblem;
import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.iproblem;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.annotation;
import org.eclipse.jdt.internal.compiler.ast.annotationmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.argument;
import org.eclipse.jdt.internal.compiler.ast.arrayinitializer;
import org.eclipse.jdt.internal.compiler.ast.classliteralaccess;
import org.eclipse.jdt.internal.compiler.ast.expression;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.ast.membervaluepair;
import org.eclipse.jdt.internal.compiler.ast.methoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.normalannotation;
import org.eclipse.jdt.internal.compiler.ast.qualifiednamereference;
import org.eclipse.jdt.internal.compiler.ast.singlememberannotation;
import org.eclipse.jdt.internal.compiler.ast.singlenamereference;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.attributenamesconstants;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.codegen.constantpool;
import org.eclipse.jdt.internal.compiler.codegen.exceptionlabel;
import org.eclipse.jdt.internal.compiler.codegen.opcodes;
import org.eclipse.jdt.internal.compiler.codegen.stackmapframe;
import org.eclipse.jdt.internal.compiler.codegen.stackmapframecodestream;
import org.eclipse.jdt.internal.compiler.codegen.verificationtypeinfo;
import org.eclipse.jdt.internal.compiler.codegen.stackmapframecodestream.exceptionmarker;
import org.eclipse.jdt.internal.compiler.codegen.stackmapframecodestream.stackdepthmarker;
import org.eclipse.jdt.internal.compiler.codegen.stackmapframecodestream.stackmarker;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.constant;
import org.eclipse.jdt.internal.compiler.impl.stringconstant;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.fieldbinding;
import org.eclipse.jdt.internal.compiler.lookup.localtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.localvariablebinding;
import org.eclipse.jdt.internal.compiler.lookup.lookupenvironment;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.nestedtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding;
import org.eclipse.jdt.internal.compiler.lookup.syntheticargumentbinding;
import org.eclipse.jdt.internal.compiler.lookup.syntheticmethodbinding;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeconstants;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.lookup.typevariablebinding;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;
import org.eclipse.jdt.internal.compiler.problem.shouldnotimplement;
import org.eclipse.jdt.internal.compiler.util.messages;
import org.eclipse.jdt.internal.compiler.util.util;

/**
* represents a class file wrapper on bytes, it is aware of its actual
* type name.
*
* public apis are listed below:
*
* byte[] getbytes();
*		answer the actual bytes of the class file
*
* char[][] getcompoundname();
* 		answer the compound name of the class file.
* 		for example, {{java}, {util}, {hashtable}}.
*
* byte[] getreducedbytes();
* 		answer a smaller byte format, which is only contains some structural
*      information. those bytes are decodable with a regular class file reader,
*      such as dietclassfilereader
*/
public class classfile implements typeconstants, typeids {

private byte[] bytes;
public codestream codestream;
public constantpool constantpool;

public int constantpooloffset;

// the header contains all the bytes till the end of the constant pool
public byte[] contents;

public int contentsoffset;

protected boolean creatingproblemtype;

public classfile enclosingclassfile;
public byte[] header;
// that collection contains all the remaining bytes of the .class file
public int headeroffset;
public set innerclassesbindings;
public int methodcount;
public int methodcountoffset;
// pool managment
boolean isshared = false;
// used to generate private access methods
// debug and stack map attributes
public int produceattributes;
public sourcetypebinding referencebinding;
public boolean isnestedtype;
public long targetjdk;

public list missingtypes = null;

public set visitedtypes;

public static final int initial_contents_size = 400;
public static final int initial_header_size = 1500;
public static final int inner_classes_size = 5;

/**
* internal use-only
* request the creation of a classfile compatible representation of a problematic type
*
* @@param typedeclaration org.eclipse.jdt.internal.compiler.ast.typedeclaration
* @@param unitresult org.eclipse.jdt.internal.compiler.compilationunitresult
*/
public static void createproblemtype(typedeclaration typedeclaration, compilationresult unitresult) {
sourcetypebinding typebinding = typedeclaration.binding;
classfile classfile = classfile.getnewinstance(typebinding);
classfile.initialize(typebinding, null, true);

if (typebinding.hasmembertypes()) {
// see bug 180109
referencebinding[] members = typebinding.membertypes;
for (int i = 0, l = members.length; i < l; i++)
classfile.recordinnerclasses(members[i]);
}
// todo (olivier) handle cases where a field cannot be generated (name too long)
// todo (olivier) handle too many methods
// inner attributes
if (typebinding.isnestedtype()) {
classfile.recordinnerclasses(typebinding);
}
typevariablebinding[] typevariables = typebinding.typevariables();
for (int i = 0, max = typevariables.length; i < max; i++) {
typevariablebinding typevariablebinding = typevariables[i];
if ((typevariablebinding.tagbits & tagbits.containsnestedtypereferences) != 0) {
util.recordnestedtype(classfile, typevariablebinding);
}
}
// add its fields
fieldbinding[] fields = typebinding.fields();
if ((fields != null) && (fields != binding.no_fields)) {
classfile.addfieldinfos();
} else {
// we have to set the number of fields to be equals to 0
classfile.contents[classfile.contentsoffset++] = 0;
classfile.contents[classfile.contentsoffset++] = 0;
}
// leave some space for the methodcount
classfile.setformethodinfos();
// add its user defined methods
int problemslength;
categorizedproblem[] problems = unitresult.geterrors();
if (problems == null) {
problems = new categorizedproblem[0];
}
categorizedproblem[] problemscopy = new categorizedproblem[problemslength = problems.length];
system.arraycopy(problems, 0, problemscopy, 0, problemslength);

abstractmethoddeclaration[] methoddecls = typedeclaration.methods;
if (methoddecls != null) {
if (typebinding.isinterface()) {
// we cannot create problem methods for an interface. so we have to generate a clinit
// which should contain all the problem
classfile.addproblemclinit(problemscopy);
for (int i = 0, length = methoddecls.length; i < length; i++) {
abstractmethoddeclaration methoddecl = methoddecls[i];
methodbinding method = methoddecl.binding;
if (method == null || method.isconstructor()) continue;
method.modifiers = classfileconstants.accpublic | classfileconstants.accabstract;
classfile.addabstractmethod(methoddecl, method);
}
} else {
for (int i = 0, length = methoddecls.length; i < length; i++) {
abstractmethoddeclaration methoddecl = methoddecls[i];
methodbinding method = methoddecl.binding;
if (method == null) continue;
if (method.isconstructor()) {
classfile.addproblemconstructor(methoddecl, method, problemscopy);
} else if (method.isabstract()) {
classfile.addabstractmethod(methoddecl, method);
} else {
classfile.addproblemmethod(methoddecl, method, problemscopy);
}
}
}
// add abstract methods
classfile.adddefaultabstractmethods();
}

// propagate generation of (problem) member types
if (typedeclaration.membertypes != null) {
for (int i = 0, max = typedeclaration.membertypes.length; i < max; i++) {
typedeclaration membertype = typedeclaration.membertypes[i];
if (membertype.binding != null) {
classfile.createproblemtype(membertype, unitresult);
}
}
}
classfile.addattributes();
unitresult.record(typebinding.constantpoolname(), classfile);
}
public static classfile getnewinstance(sourcetypebinding typebinding) {
lookupenvironment env = typebinding.scope.environment();
return env.classfilepool.acquire(typebinding);
}

/**
* internal use-only
* this methods creates a new instance of the receiver.
*/
protected classfile() {
// default constructor for subclasses
}

public classfile(sourcetypebinding typebinding) {
// default constructor for subclasses
this.constantpool = new constantpool(this);
final compileroptions options = typebinding.scope.compileroptions();
this.targetjdk = options.targetjdk;
this.produceattributes = options.producedebugattributes;
this.referencebinding = typebinding;
this.isnestedtype = typebinding.isnestedtype();
if (this.targetjdk >= classfileconstants.jdk1_6) {
this.produceattributes |= classfileconstants.attr_stack_map_table;
this.codestream = new stackmapframecodestream(this);
} else if (this.targetjdk == classfileconstants.cldc_1_1) {
this.targetjdk = classfileconstants.jdk1_1; // put back 45.3
this.produceattributes |= classfileconstants.attr_stack_map;
this.codestream = new stackmapframecodestream(this);
} else {
this.codestream = new codestream(this);
}
initbytearrays();
}

/**
* internal use-only
* generate the byte for a problem method info that correspond to a bogus method.
*
* @@param method org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration
* @@param methodbinding org.eclipse.jdt.internal.compiler.nameloopkup.methodbinding
*/
public void addabstractmethod(
abstractmethoddeclaration method,
methodbinding methodbinding) {

this.generatemethodinfoheader(methodbinding);
int methodattributeoffset = this.contentsoffset;
int attributenumber = this.generatemethodinfoattribute(methodbinding);
completemethodinfo(methodattributeoffset, attributenumber);
}

/**
* internal use-only
* this methods generate all the attributes for the receiver.
* for a class they could be:
* - source file attribute
* - inner classes attribute
* - deprecated attribute
*/
public void addattributes() {
// update the method count
this.contents[this.methodcountoffset++] = (byte) (this.methodcount >> 8);
this.contents[this.methodcountoffset] = (byte) this.methodcount;

int attributesnumber = 0;
// leave two bytes for the number of attributes and store the current offset
int attributeoffset = this.contentsoffset;
this.contentsoffset += 2;

// source attribute
if ((this.produceattributes & classfileconstants.attr_source) != 0) {
string fullfilename =
new string(this.referencebinding.scope.referencecompilationunit().getfilename());
fullfilename = fullfilename.replace('\\', '/');
int lastindex = fullfilename.lastindexof('/');
if (lastindex != -1) {
fullfilename = fullfilename.substring(lastindex + 1, fullfilename.length());
}
// check that there is enough space to write all the bytes for the field info corresponding
// to the @@fieldbinding
if (this.contentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int sourceattributenameindex =
this.constantpool.literalindex(attributenamesconstants.sourcename);
this.contents[this.contentsoffset++] = (byte) (sourceattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) sourceattributenameindex;
// the length of a source file attribute is 2. this is a fixed-length
// attribute
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 2;
// write the source file name
int filenameindex = this.constantpool.literalindex(fullfilename.tochararray());
this.contents[this.contentsoffset++] = (byte) (filenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) filenameindex;
attributesnumber++;
}
// deprecated attribute
if (this.referencebinding.isdeprecated()) {
// check that there is enough space to write all the bytes for the field info corresponding
// to the @@fieldbinding
if (this.contentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
int deprecatedattributenameindex =
this.constantpool.literalindex(attributenamesconstants.deprecatedname);
this.contents[this.contentsoffset++] = (byte) (deprecatedattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) deprecatedattributenameindex;
// the length of a deprecated attribute is equals to 0
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
attributesnumber++;
}
// add signature attribute
char[] genericsignature = this.referencebinding.genericsignature();
if (genericsignature != null) {
// check that there is enough space to write all the bytes for the field info corresponding
// to the @@fieldbinding
if (this.contentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int signatureattributenameindex =
this.constantpool.literalindex(attributenamesconstants.signaturename);
this.contents[this.contentsoffset++] = (byte) (signatureattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) signatureattributenameindex;
// the length of a signature attribute is equals to 2
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 2;
int signatureindex =
this.constantpool.literalindex(genericsignature);
this.contents[this.contentsoffset++] = (byte) (signatureindex >> 8);
this.contents[this.contentsoffset++] = (byte) signatureindex;
attributesnumber++;
}
if (this.targetjdk >= classfileconstants.jdk1_5
&& this.referencebinding.isnestedtype()
&& !this.referencebinding.ismembertype()) {
// add enclosing method attribute (1.5 mode only)
if (this.contentsoffset + 10 >= this.contents.length) {
resizecontents(10);
}
int enclosingmethodattributenameindex =
this.constantpool.literalindex(attributenamesconstants.enclosingmethodname);
this.contents[this.contentsoffset++] = (byte) (enclosingmethodattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) enclosingmethodattributenameindex;
// the length of a signature attribute is equals to 2
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 4;

int enclosingtypeindex = this.constantpool.literalindexfortype(this.referencebinding.enclosingtype().constantpoolname());
this.contents[this.contentsoffset++] = (byte) (enclosingtypeindex >> 8);
this.contents[this.contentsoffset++] = (byte) enclosingtypeindex;
byte methodindexbyte1 = 0;
byte methodindexbyte2 = 0;
if (this.referencebinding instanceof localtypebinding) {
methodbinding methodbinding = ((localtypebinding) this.referencebinding).enclosingmethod;
if (methodbinding != null) {
int enclosingmethodindex = this.constantpool.literalindexfornameandtype(methodbinding.selector, methodbinding.signature(this));
methodindexbyte1 = (byte) (enclosingmethodindex >> 8);
methodindexbyte2 = (byte) enclosingmethodindex;
}
}
this.contents[this.contentsoffset++] = methodindexbyte1;
this.contents[this.contentsoffset++] = methodindexbyte2;
attributesnumber++;
}
if (this.targetjdk >= classfileconstants.jdk1_4) {
typedeclaration typedeclaration = this.referencebinding.scope.referencecontext;
if (typedeclaration != null) {
final annotation[] annotations = typedeclaration.annotations;
if (annotations != null) {
attributesnumber += generateruntimeannotations(annotations);
}
}
}

if (this.referencebinding.ishierarchyinconsistent()) {
referencebinding superclass = this.referencebinding.superclass;
if (superclass != null) {
this.missingtypes = superclass.collectmissingtypes(this.missingtypes);
}
referencebinding[] superinterfaces = this.referencebinding.superinterfaces();
for (int i = 0, max = superinterfaces.length; i < max; i++) {
this.missingtypes = superinterfaces[i].collectmissingtypes(this.missingtypes);
}
// add an attribute for inconsistent hierarchy
if (this.contentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
int inconsistenthierarchynameindex =
this.constantpool.literalindex(attributenamesconstants.inconsistenthierarchy);
this.contents[this.contentsoffset++] = (byte) (inconsistenthierarchynameindex >> 8);
this.contents[this.contentsoffset++] = (byte) inconsistenthierarchynameindex;
// the length of an inconsistent hierarchy attribute is equals to 0
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
attributesnumber++;
}
// inner class attribute
int numberofinnerclasses = this.innerclassesbindings == null ? 0 : this.innerclassesbindings.size();
if (numberofinnerclasses != 0) {
referencebinding[] innerclasses = new referencebinding[numberofinnerclasses];
this.innerclassesbindings.toarray(innerclasses);
arrays.sort(innerclasses, new comparator() {
public int compare(object o1, object o2) {
typebinding binding1 = (typebinding) o1;
typebinding binding2 = (typebinding) o2;
return charoperation.compareto(binding1.constantpoolname(), binding2.constantpoolname());
}
});
// generate the inner class attribute
int exsize = 8 * numberofinnerclasses + 8;
if (exsize + this.contentsoffset >= this.contents.length) {
resizecontents(exsize);
}
// now we now the size of the attribute and the number of entries
// attribute name
int attributenameindex =
this.constantpool.literalindex(attributenamesconstants.innerclassname);
this.contents[this.contentsoffset++] = (byte) (attributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) attributenameindex;
int value = (numberofinnerclasses << 3) + 2;
this.contents[this.contentsoffset++] = (byte) (value >> 24);
this.contents[this.contentsoffset++] = (byte) (value >> 16);
this.contents[this.contentsoffset++] = (byte) (value >> 8);
this.contents[this.contentsoffset++] = (byte) value;
this.contents[this.contentsoffset++] = (byte) (numberofinnerclasses >> 8);
this.contents[this.contentsoffset++] = (byte) numberofinnerclasses;
for (int i = 0; i < numberofinnerclasses; i++) {
referencebinding innerclass = innerclasses[i];
int accessflags = innerclass.getaccessflags();
int innerclassindex = this.constantpool.literalindexfortype(innerclass.constantpoolname());
// inner class index
this.contents[this.contentsoffset++] = (byte) (innerclassindex >> 8);
this.contents[this.contentsoffset++] = (byte) innerclassindex;
// outer class index: anonymous and local have no outer class index
if (innerclass.ismembertype()) {
// member or member of local
int outerclassindex = this.constantpool.literalindexfortype(innerclass.enclosingtype().constantpoolname());
this.contents[this.contentsoffset++] = (byte) (outerclassindex >> 8);
this.contents[this.contentsoffset++] = (byte) outerclassindex;
} else {
// equals to 0 if the innerclass is not a member type
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
}
// name index
if (!innerclass.isanonymoustype()) {
int nameindex = this.constantpool.literalindex(innerclass.sourcename());
this.contents[this.contentsoffset++] = (byte) (nameindex >> 8);
this.contents[this.contentsoffset++] = (byte) nameindex;
} else {
// equals to 0 if the innerclass is an anonymous type
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
}
// access flag
if (innerclass.isanonymoustype()) {
accessflags &= ~classfileconstants.accfinal;
} else if (innerclass.ismembertype() && innerclass.isinterface()) {
accessflags |= classfileconstants.accstatic; // implicitely static
}
this.contents[this.contentsoffset++] = (byte) (accessflags >> 8);
this.contents[this.contentsoffset++] = (byte) accessflags;
}
attributesnumber++;
}
if (this.missingtypes != null) {
generatemissingtypesattribute();
attributesnumber++;
}
// update the number of attributes
if (attributeoffset + 2 >= this.contents.length) {
resizecontents(2);
}
this.contents[attributeoffset++] = (byte) (attributesnumber >> 8);
this.contents[attributeoffset] = (byte) attributesnumber;

// resynchronize all offsets of the classfile
this.header = this.constantpool.poolcontent;
this.headeroffset = this.constantpool.currentoffset;
int constantpoolcount = this.constantpool.currentindex;
this.header[this.constantpooloffset++] = (byte) (constantpoolcount >> 8);
this.header[this.constantpooloffset] = (byte) constantpoolcount;
}

/**
* internal use-only
* this methods generate all the default abstract method infos that correpond to
* the abstract methods inherited from superinterfaces.
*/
public void adddefaultabstractmethods() { // default abstract methods
methodbinding[] defaultabstractmethods =
this.referencebinding.getdefaultabstractmethods();
for (int i = 0, max = defaultabstractmethods.length; i < max; i++) {
generatemethodinfoheader(defaultabstractmethods[i]);
int methodattributeoffset = this.contentsoffset;
int attributenumber = generatemethodinfoattribute(defaultabstractmethods[i]);
completemethodinfo(methodattributeoffset, attributenumber);
}
}

private int addfieldattributes(fieldbinding fieldbinding, int fieldattributeoffset) {
int attributesnumber = 0;
// 4.7.2 only static constant fields get a constantattribute
// generate the constantvalueattribute
constant fieldconstant = fieldbinding.constant();
if (fieldconstant != constant.notaconstant){
if (this.contentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
// now we generate the constant attribute corresponding to the fieldbinding
int constantvaluenameindex =
this.constantpool.literalindex(attributenamesconstants.constantvaluename);
this.contents[this.contentsoffset++] = (byte) (constantvaluenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) constantvaluenameindex;
// the attribute length = 2 in case of a constantvalue attribute
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 2;
attributesnumber++;
// need to add the constant_value_index
switch (fieldconstant.typeid()) {
case t_boolean :
int booleanvalueindex =
this.constantpool.literalindex(fieldconstant.booleanvalue() ? 1 : 0);
this.contents[this.contentsoffset++] = (byte) (booleanvalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) booleanvalueindex;
break;
case t_byte :
case t_char :
case t_int :
case t_short :
int integervalueindex =
this.constantpool.literalindex(fieldconstant.intvalue());
this.contents[this.contentsoffset++] = (byte) (integervalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) integervalueindex;
break;
case t_float :
int floatvalueindex =
this.constantpool.literalindex(fieldconstant.floatvalue());
this.contents[this.contentsoffset++] = (byte) (floatvalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) floatvalueindex;
break;
case t_double :
int doublevalueindex =
this.constantpool.literalindex(fieldconstant.doublevalue());
this.contents[this.contentsoffset++] = (byte) (doublevalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) doublevalueindex;
break;
case t_long :
int longvalueindex =
this.constantpool.literalindex(fieldconstant.longvalue());
this.contents[this.contentsoffset++] = (byte) (longvalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) longvalueindex;
break;
case t_javalangstring :
int stringvalueindex =
this.constantpool.literalindex(
((stringconstant) fieldconstant).stringvalue());
if (stringvalueindex == -1) {
if (!this.creatingproblemtype) {
// report an error and abort: will lead to a problem type classfile creation
typedeclaration typedeclaration = this.referencebinding.scope.referencecontext;
fielddeclaration[] fielddecls = typedeclaration.fields;
for (int i = 0, max = fielddecls.length; i < max; i++) {
if (fielddecls[i].binding == fieldbinding) {
// problem should abort
typedeclaration.scope.problemreporter().stringconstantisexceedingutf8limit(
fielddecls[i]);
}
}
} else {
// already inside a problem type creation : no constant for this field
this.contentsoffset = fieldattributeoffset;
}
} else {
this.contents[this.contentsoffset++] = (byte) (stringvalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) stringvalueindex;
}
}
}
if (this.targetjdk < classfileconstants.jdk1_5 && fieldbinding.issynthetic()) {
if (this.contentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
int syntheticattributenameindex =
this.constantpool.literalindex(attributenamesconstants.syntheticname);
this.contents[this.contentsoffset++] = (byte) (syntheticattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) syntheticattributenameindex;
// the length of a synthetic attribute is equals to 0
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
attributesnumber++;
}
if (fieldbinding.isdeprecated()) {
if (this.contentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
int deprecatedattributenameindex =
this.constantpool.literalindex(attributenamesconstants.deprecatedname);
this.contents[this.contentsoffset++] = (byte) (deprecatedattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) deprecatedattributenameindex;
// the length of a deprecated attribute is equals to 0
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
attributesnumber++;
}
// add signature attribute
char[] genericsignature = fieldbinding.genericsignature();
if (genericsignature != null) {
// check that there is enough space to write all the bytes for the field info corresponding
// to the @@fieldbinding
if (this.contentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int signatureattributenameindex =
this.constantpool.literalindex(attributenamesconstants.signaturename);
this.contents[this.contentsoffset++] = (byte) (signatureattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) signatureattributenameindex;
// the length of a signature attribute is equals to 2
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 2;
int signatureindex =
this.constantpool.literalindex(genericsignature);
this.contents[this.contentsoffset++] = (byte) (signatureindex >> 8);
this.contents[this.contentsoffset++] = (byte) signatureindex;
attributesnumber++;
}
if (this.targetjdk >= classfileconstants.jdk1_4) {
fielddeclaration fielddeclaration = fieldbinding.sourcefield();
if (fielddeclaration != null) {
annotation[] annotations = fielddeclaration.annotations;
if (annotations != null) {
attributesnumber += generateruntimeannotations(annotations);
}
}
}
if ((fieldbinding.tagbits & tagbits.hasmissingtype) != 0) {
this.missingtypes = fieldbinding.type.collectmissingtypes(this.missingtypes);
}
return attributesnumber;
}

/**
* internal use-only
* this methods generates the bytes for the given field binding
* @@param fieldbinding the given field binding
*/
private void addfieldinfo(fieldbinding fieldbinding) {
// check that there is enough space to write all the bytes for the field info corresponding
// to the @@fieldbinding
if (this.contentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
// now we can generate all entries into the byte array
// first the accessflags
int accessflags = fieldbinding.getaccessflags();
if (this.targetjdk < classfileconstants.jdk1_5) {
// pre 1.5, synthetic was an attribute, not a modifier
accessflags &= ~classfileconstants.accsynthetic;
}
this.contents[this.contentsoffset++] = (byte) (accessflags >> 8);
this.contents[this.contentsoffset++] = (byte) accessflags;
// then the nameindex
int nameindex = this.constantpool.literalindex(fieldbinding.name);
this.contents[this.contentsoffset++] = (byte) (nameindex >> 8);
this.contents[this.contentsoffset++] = (byte) nameindex;
// then the descriptorindex
int descriptorindex = this.constantpool.literalindex(fieldbinding.type);
this.contents[this.contentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[this.contentsoffset++] = (byte) descriptorindex;
int fieldattributeoffset = this.contentsoffset;
int attributenumber = 0;
// leave some space for the number of attributes
this.contentsoffset += 2;
attributenumber += addfieldattributes(fieldbinding, fieldattributeoffset);
if (this.contentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
this.contents[fieldattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[fieldattributeoffset] = (byte) attributenumber;
}

/**
* internal use-only
* this methods generate all the fields infos for the receiver.
* this includes:
* - a field info for each defined field of that class
* - a field info for each synthetic field (e.g. this$0)
*/
/**
* internal use-only
* this methods generate all the fields infos for the receiver.
* this includes:
* - a field info for each defined field of that class
* - a field info for each synthetic field (e.g. this$0)
*/
public void addfieldinfos() {
sourcetypebinding currentbinding = this.referencebinding;
fieldbinding[] syntheticfields = currentbinding.syntheticfields();
int fieldcount = 	currentbinding.fieldcount() + (syntheticfields == null ? 0 : syntheticfields.length);

// write the number of fields
if (fieldcount > 0xffff) {
this.referencebinding.scope.problemreporter().toomanyfields(this.referencebinding.scope.referencetype());
}
this.contents[this.contentsoffset++] = (byte) (fieldcount >> 8);
this.contents[this.contentsoffset++] = (byte) fieldcount;

fielddeclaration[] fielddecls = currentbinding.scope.referencecontext.fields;
for (int i = 0, max = fielddecls == null ? 0 : fielddecls.length; i < max; i++) {
fielddeclaration fielddecl = fielddecls[i];
if (fielddecl.binding != null) {
addfieldinfo(fielddecl.binding);
}
}

if (syntheticfields != null) {
for (int i = 0, max = syntheticfields.length; i < max; i++) {
addfieldinfo(syntheticfields[i]);
}
}
}

private void addmissingabstractproblemmethod(methoddeclaration methoddeclaration, methodbinding methodbinding, categorizedproblem problem, compilationresult compilationresult) {
// always clear the strictfp/native/abstract bit for a problem method
generatemethodinfoheader(methodbinding, methodbinding.modifiers & ~(classfileconstants.accstrictfp | classfileconstants.accnative | classfileconstants.accabstract));
int methodattributeoffset = this.contentsoffset;
int attributenumber = generatemethodinfoattribute(methodbinding);

// code attribute
attributenumber++;

int codeattributeoffset = this.contentsoffset;
generatecodeattributeheader();
stringbuffer buffer = new stringbuffer(25);
buffer.append("\t"  + problem.getmessage() + "\n" ); //$non-nls-1$ //$non-nls-2$
buffer.insert(0, messages.compilation_unresolvedproblem);
string problemstring = buffer.tostring();

this.codestream.init(this);
this.codestream.preserveunusedlocals = true;
this.codestream.initializemaxlocals(methodbinding);

// return codestream.generatecodeattributeforproblemmethod(comp.options.runtimeexceptionnameforcompileerror, "")
this.codestream.generatecodeattributeforproblemmethod(problemstring);

completecodeattributeformissingabstractproblemmethod(
methodbinding,
codeattributeoffset,
compilationresult.getlineseparatorpositions(),
problem.getsourcelinenumber());

completemethodinfo(methodattributeoffset, attributenumber);
}

/**
* internal use-only
* generate the byte for a problem clinit method info that correspond to a boggus method.
*
* @@param problems org.eclipse.jdt.internal.compiler.problem.problem[]
*/
public void addproblemclinit(categorizedproblem[] problems) {
generatemethodinfoheaderforclinit();
// leave two spaces for the number of attributes
this.contentsoffset -= 2;
int attributeoffset = this.contentsoffset;
this.contentsoffset += 2;
int attributenumber = 0;

int codeattributeoffset = this.contentsoffset;
generatecodeattributeheader();
this.codestream.resetforproblemclinit(this);
string problemstring = "" ; //$non-nls-1$
int problemline = 0;
if (problems != null) {
int max = problems.length;
stringbuffer buffer = new stringbuffer(25);
int count = 0;
for (int i = 0; i < max; i++) {
categorizedproblem problem = problems[i];
if ((problem != null) && (problem.iserror())) {
buffer.append("\t"  +problem.getmessage() + "\n" ); //$non-nls-1$ //$non-nls-2$
count++;
if (problemline == 0) {
problemline = problem.getsourcelinenumber();
}
problems[i] = null;
}
} // insert the top line afterwards, once knowing how many problems we have to consider
if (count > 1) {
buffer.insert(0, messages.compilation_unresolvedproblems);
} else {
buffer.insert(0, messages.compilation_unresolvedproblem);
}
problemstring = buffer.tostring();
}

// return codestream.generatecodeattributeforproblemmethod(comp.options.runtimeexceptionnameforcompileerror, "")
this.codestream.generatecodeattributeforproblemmethod(problemstring);
attributenumber++; // code attribute
completecodeattributeforclinit(
codeattributeoffset,
problemline);
if (this.contentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
this.contents[attributeoffset++] = (byte) (attributenumber >> 8);
this.contents[attributeoffset] = (byte) attributenumber;
}
/**
* internal use-only
* generate the byte for a problem method info that correspond to a boggus constructor.
*
* @@param method org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration
* @@param methodbinding org.eclipse.jdt.internal.compiler.nameloopkup.methodbinding
* @@param problems org.eclipse.jdt.internal.compiler.problem.problem[]
*/
public void addproblemconstructor(
abstractmethoddeclaration method,
methodbinding methodbinding,
categorizedproblem[] problems) {

// always clear the strictfp/native/abstract bit for a problem method
generatemethodinfoheader(methodbinding, methodbinding.modifiers & ~(classfileconstants.accstrictfp | classfileconstants.accnative | classfileconstants.accabstract));
int methodattributeoffset = this.contentsoffset;
int attributenumber = generatemethodinfoattribute(methodbinding);

// code attribute
attributenumber++;
int codeattributeoffset = this.contentsoffset;
generatecodeattributeheader();
this.codestream.reset(method, this);
string problemstring = "" ; //$non-nls-1$
int problemline = 0;
if (problems != null) {
int max = problems.length;
stringbuffer buffer = new stringbuffer(25);
int count = 0;
for (int i = 0; i < max; i++) {
categorizedproblem problem = problems[i];
if ((problem != null) && (problem.iserror())) {
buffer.append("\t"  +problem.getmessage() + "\n" ); //$non-nls-1$ //$non-nls-2$
count++;
if (problemline == 0) {
problemline = problem.getsourcelinenumber();
}
}
} // insert the top line afterwards, once knowing how many problems we have to consider
if (count > 1) {
buffer.insert(0, messages.compilation_unresolvedproblems);
} else {
buffer.insert(0, messages.compilation_unresolvedproblem);
}
problemstring = buffer.tostring();
}

// return codestream.generatecodeattributeforproblemmethod(comp.options.runtimeexceptionnameforcompileerror, "")
this.codestream.generatecodeattributeforproblemmethod(problemstring);
completecodeattributeforproblemmethod(
method,
methodbinding,
codeattributeoffset,
((sourcetypebinding) methodbinding.declaringclass)
.scope
.referencecompilationunit()
.compilationresult
.getlineseparatorpositions(),
problemline);
completemethodinfo(methodattributeoffset, attributenumber);
}
/**
* internal use-only
* generate the byte for a problem method info that correspond to a boggus constructor.
* reset the position inside the contents byte array to the savedoffset.
*
* @@param method org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration
* @@param methodbinding org.eclipse.jdt.internal.compiler.nameloopkup.methodbinding
* @@param problems org.eclipse.jdt.internal.compiler.problem.problem[]
* @@param savedoffset <code>int</code>
*/
public void addproblemconstructor(
abstractmethoddeclaration method,
methodbinding methodbinding,
categorizedproblem[] problems,
int savedoffset) {
// we need to move back the contentsoffset to the value at the beginning of the method
this.contentsoffset = savedoffset;
this.methodcount--; // we need to remove the method that causes the problem
addproblemconstructor(method, methodbinding, problems);
}

/**
* internal use-only
* generate the byte for a problem method info that correspond to a boggus method.
*
* @@param method org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration
* @@param methodbinding org.eclipse.jdt.internal.compiler.nameloopkup.methodbinding
* @@param problems org.eclipse.jdt.internal.compiler.problem.problem[]
*/
public void addproblemmethod(
abstractmethoddeclaration method,
methodbinding methodbinding,
categorizedproblem[] problems) {
if (methodbinding.isabstract() && methodbinding.declaringclass.isinterface()) {
method.abort(problemseverities.aborttype, null);
}
// always clear the strictfp/native/abstract bit for a problem method
generatemethodinfoheader(methodbinding, methodbinding.modifiers & ~(classfileconstants.accstrictfp | classfileconstants.accnative | classfileconstants.accabstract));
int methodattributeoffset = this.contentsoffset;
int attributenumber = generatemethodinfoattribute(methodbinding);

// code attribute
attributenumber++;

int codeattributeoffset = this.contentsoffset;
generatecodeattributeheader();
this.codestream.reset(method, this);
string problemstring = "" ; //$non-nls-1$
int problemline = 0;
if (problems != null) {
int max = problems.length;
stringbuffer buffer = new stringbuffer(25);
int count = 0;
for (int i = 0; i < max; i++) {
categorizedproblem problem = problems[i];
if ((problem != null)
&& (problem.iserror())
&& (problem.getsourcestart() >= method.declarationsourcestart)
&& (problem.getsourceend() <= method.declarationsourceend)) {
buffer.append("\t"  +problem.getmessage() + "\n" ); //$non-nls-1$ //$non-nls-2$
count++;
if (problemline == 0) {
problemline = problem.getsourcelinenumber();
}
problems[i] = null;
}
} // insert the top line afterwards, once knowing how many problems we have to consider
if (count > 1) {
buffer.insert(0, messages.compilation_unresolvedproblems);
} else {
buffer.insert(0, messages.compilation_unresolvedproblem);
}
problemstring = buffer.tostring();
}

// return codestream.generatecodeattributeforproblemmethod(comp.options.runtimeexceptionnameforcompileerror, "")
this.codestream.generatecodeattributeforproblemmethod(problemstring);
completecodeattributeforproblemmethod(
method,
methodbinding,
codeattributeoffset,
((sourcetypebinding) methodbinding.declaringclass)
.scope
.referencecompilationunit()
.compilationresult
.getlineseparatorpositions(),
problemline);
completemethodinfo(methodattributeoffset, attributenumber);
}

/**
* internal use-only
* generate the byte for a problem method info that correspond to a boggus method.
* reset the position inside the contents byte array to the savedoffset.
*
* @@param method org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration
* @@param methodbinding org.eclipse.jdt.internal.compiler.nameloopkup.methodbinding
* @@param problems org.eclipse.jdt.internal.compiler.problem.problem[]
* @@param savedoffset <code>int</code>
*/
public void addproblemmethod(
abstractmethoddeclaration method,
methodbinding methodbinding,
categorizedproblem[] problems,
int savedoffset) {
// we need to move back the contentsoffset to the value at the beginning of the method
this.contentsoffset = savedoffset;
this.methodcount--; // we need to remove the method that causes the problem
addproblemmethod(method, methodbinding, problems);
}

/**
* internal use-only
* generate the byte for all the special method infos.
* they are:
* - synthetic access methods
* - default abstract methods
*/
public void addspecialmethods() {

// add all methods (default abstract methods and synthetic)

// default abstract methods
generatemissingabstractmethods(this.referencebinding.scope.referencetype().missingabstractmethods, this.referencebinding.scope.referencecompilationunit().compilationresult);

methodbinding[] defaultabstractmethods = this.referencebinding.getdefaultabstractmethods();
for (int i = 0, max = defaultabstractmethods.length; i < max; i++) {
generatemethodinfoheader(defaultabstractmethods[i]);
int methodattributeoffset = this.contentsoffset;
int attributenumber = generatemethodinfoattribute(defaultabstractmethods[i]);
completemethodinfo(methodattributeoffset, attributenumber);
}
// add synthetic methods infos
syntheticmethodbinding[] syntheticmethods = this.referencebinding.syntheticmethods();
if (syntheticmethods != null) {
for (int i = 0, max = syntheticmethods.length; i < max; i++) {
syntheticmethodbinding syntheticmethod = syntheticmethods[i];
switch (syntheticmethod.purpose) {
case syntheticmethodbinding.fieldreadaccess :
case syntheticmethodbinding.superfieldreadaccess :
// generate a method info to emulate an reading access to
// a non-accessible field
addsyntheticfieldreadaccessmethod(syntheticmethod);
break;
case syntheticmethodbinding.fieldwriteaccess :
case syntheticmethodbinding.superfieldwriteaccess :
// generate a method info to emulate an writing access to
// a non-accessible field
addsyntheticfieldwriteaccessmethod(syntheticmethod);
break;
case syntheticmethodbinding.methodaccess :
case syntheticmethodbinding.supermethodaccess :
case syntheticmethodbinding.bridgemethod :
// generate a method info to emulate an access to a non-accessible method / super-method or bridge method
addsyntheticmethodaccessmethod(syntheticmethod);
break;
case syntheticmethodbinding.constructoraccess :
// generate a method info to emulate an access to a non-accessible constructor
addsyntheticconstructoraccessmethod(syntheticmethod);
break;
case syntheticmethodbinding.enumvalues :
// generate a method info to define <enum>#values()
addsyntheticenumvaluesmethod(syntheticmethod);
break;
case syntheticmethodbinding.enumvalueof :
// generate a method info to define <enum>#valueof(string)
addsyntheticenumvalueofmethod(syntheticmethod);
break;
case syntheticmethodbinding.switchtable :
// generate a method info to define the switch table synthetic method
addsyntheticswitchtable(syntheticmethod);
}
}
}
}

/**
* internal use-only
* generate the bytes for a synthetic method that provides an access to a private constructor.
*
* @@param methodbinding org.eclipse.jdt.internal.compiler.nameloopkup.syntheticaccessmethodbinding
*/
public void addsyntheticconstructoraccessmethod(syntheticmethodbinding methodbinding) {
generatemethodinfoheader(methodbinding);
int methodattributeoffset = this.contentsoffset;
// this will add exception attribute, synthetic attribute, deprecated attribute,...
int attributenumber = generatemethodinfoattribute(methodbinding);
// code attribute
int codeattributeoffset = this.contentsoffset;
attributenumber++; // add code attribute
generatecodeattributeheader();
this.codestream.init(this);
this.codestream.generatesyntheticbodyforconstructoraccess(methodbinding);
completecodeattributeforsyntheticmethod(
methodbinding,
codeattributeoffset,
((sourcetypebinding) methodbinding.declaringclass)
.scope
.referencecompilationunit()
.compilationresult
.getlineseparatorpositions());
// update the number of attributes
this.contents[methodattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[methodattributeoffset] = (byte) attributenumber;
}

/**
* internal use-only
*  generate the bytes for a synthetic method that implements enum#valueof(string) for a given enum type
*
* @@param methodbinding org.eclipse.jdt.internal.compiler.nameloopkup.syntheticaccessmethodbinding
*/
public void addsyntheticenumvalueofmethod(syntheticmethodbinding methodbinding) {
generatemethodinfoheader(methodbinding);
int methodattributeoffset = this.contentsoffset;
// this will add exception attribute, synthetic attribute, deprecated attribute,...
int attributenumber = generatemethodinfoattribute(methodbinding);
// code attribute
int codeattributeoffset = this.contentsoffset;
attributenumber++; // add code attribute
generatecodeattributeheader();
this.codestream.init(this);
this.codestream.generatesyntheticbodyforenumvalueof(methodbinding);
completecodeattributeforsyntheticmethod(
methodbinding,
codeattributeoffset,
((sourcetypebinding) methodbinding.declaringclass)
.scope
.referencecompilationunit()
.compilationresult
.getlineseparatorpositions());
// update the number of attributes
this.contents[methodattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[methodattributeoffset] = (byte) attributenumber;
}

/**
* internal use-only
*  generate the bytes for a synthetic method that implements enum#values() for a given enum type
*
* @@param methodbinding org.eclipse.jdt.internal.compiler.nameloopkup.syntheticaccessmethodbinding
*/
public void addsyntheticenumvaluesmethod(syntheticmethodbinding methodbinding) {
generatemethodinfoheader(methodbinding);
int methodattributeoffset = this.contentsoffset;
// this will add exception attribute, synthetic attribute, deprecated attribute,...
int attributenumber = generatemethodinfoattribute(methodbinding);
// code attribute
int codeattributeoffset = this.contentsoffset;
attributenumber++; // add code attribute
generatecodeattributeheader();
this.codestream.init(this);
this.codestream.generatesyntheticbodyforenumvalues(methodbinding);
completecodeattributeforsyntheticmethod(
methodbinding,
codeattributeoffset,
((sourcetypebinding) methodbinding.declaringclass)
.scope
.referencecompilationunit()
.compilationresult
.getlineseparatorpositions());
// update the number of attributes
this.contents[methodattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[methodattributeoffset] = (byte) attributenumber;
}

/**
* internal use-only
* generate the byte for a problem method info that correspond to a synthetic method that
* generate an read access to a private field.
*
* @@param methodbinding org.eclipse.jdt.internal.compiler.nameloopkup.syntheticaccessmethodbinding
*/
public void addsyntheticfieldreadaccessmethod(syntheticmethodbinding methodbinding) {
generatemethodinfoheader(methodbinding);
int methodattributeoffset = this.contentsoffset;
// this will add exception attribute, synthetic attribute, deprecated attribute,...
int attributenumber = generatemethodinfoattribute(methodbinding);
// code attribute
int codeattributeoffset = this.contentsoffset;
attributenumber++; // add code attribute
generatecodeattributeheader();
this.codestream.init(this);
this.codestream.generatesyntheticbodyforfieldreadaccess(methodbinding);
completecodeattributeforsyntheticmethod(
methodbinding,
codeattributeoffset,
((sourcetypebinding) methodbinding.declaringclass)
.scope
.referencecompilationunit()
.compilationresult
.getlineseparatorpositions());
// update the number of attributes
this.contents[methodattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[methodattributeoffset] = (byte) attributenumber;
}

/**
* internal use-only
* generate the byte for a problem method info that correspond to a synthetic method that
* generate an write access to a private field.
*
* @@param methodbinding org.eclipse.jdt.internal.compiler.nameloopkup.syntheticaccessmethodbinding
*/
public void addsyntheticfieldwriteaccessmethod(syntheticmethodbinding methodbinding) {
generatemethodinfoheader(methodbinding);
int methodattributeoffset = this.contentsoffset;
// this will add exception attribute, synthetic attribute, deprecated attribute,...
int attributenumber = generatemethodinfoattribute(methodbinding);
// code attribute
int codeattributeoffset = this.contentsoffset;
attributenumber++; // add code attribute
generatecodeattributeheader();
this.codestream.init(this);
this.codestream.generatesyntheticbodyforfieldwriteaccess(methodbinding);
completecodeattributeforsyntheticmethod(
methodbinding,
codeattributeoffset,
((sourcetypebinding) methodbinding.declaringclass)
.scope
.referencecompilationunit()
.compilationresult
.getlineseparatorpositions());
// update the number of attributes
this.contents[methodattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[methodattributeoffset] = (byte) attributenumber;
}

/**
* internal use-only
* generate the bytes for a synthetic method that provides access to a private method.
*
* @@param methodbinding org.eclipse.jdt.internal.compiler.nameloopkup.syntheticaccessmethodbinding
*/
public void addsyntheticmethodaccessmethod(syntheticmethodbinding methodbinding) {
generatemethodinfoheader(methodbinding);
int methodattributeoffset = this.contentsoffset;
// this will add exception attribute, synthetic attribute, deprecated attribute,...
int attributenumber = generatemethodinfoattribute(methodbinding);
// code attribute
int codeattributeoffset = this.contentsoffset;
attributenumber++; // add code attribute
generatecodeattributeheader();
this.codestream.init(this);
this.codestream.generatesyntheticbodyformethodaccess(methodbinding);
completecodeattributeforsyntheticmethod(
methodbinding,
codeattributeoffset,
((sourcetypebinding) methodbinding.declaringclass)
.scope
.referencecompilationunit()
.compilationresult
.getlineseparatorpositions());
// update the number of attributes
this.contents[methodattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[methodattributeoffset] = (byte) attributenumber;
}

public void addsyntheticswitchtable(syntheticmethodbinding methodbinding) {
generatemethodinfoheader(methodbinding);
int methodattributeoffset = this.contentsoffset;
// this will add exception attribute, synthetic attribute, deprecated attribute,...
int attributenumber = generatemethodinfoattribute(methodbinding);
// code attribute
int codeattributeoffset = this.contentsoffset;
attributenumber++; // add code attribute
generatecodeattributeheader();
this.codestream.init(this);
this.codestream.generatesyntheticbodyforswitchtable(methodbinding);
completecodeattributeforsyntheticmethod(
true,
methodbinding,
codeattributeoffset,
((sourcetypebinding) methodbinding.declaringclass)
.scope
.referencecompilationunit()
.compilationresult
.getlineseparatorpositions());
// update the number of attributes
this.contents[methodattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[methodattributeoffset] = (byte) attributenumber;
}

/**
* internal use-only
* that method completes the creation of the code attribute by setting
* - the attribute_length
* - max_stack
* - max_locals
* - code_length
* - exception table
* - and debug attributes if necessary.
*
* @@param codeattributeoffset <code>int</code>
*/
public void completecodeattribute(int codeattributeoffset) {
// reinitialize the localcontents with the byte modified by the code stream
this.contents = this.codestream.bcodestream;
int localcontentsoffset = this.codestream.classfileoffset;
// codeattributeoffset is the position inside localcontents byte array before we started to write
// any information about the codeattribute
// that means that to write the attribute_length you need to offset by 2 the value of codeattributeoffset
// to get the right position, 6 for the max_stack etc...
int code_length = this.codestream.position;
if (code_length > 65535) {
this.codestream.methoddeclaration.scope.problemreporter().bytecodeexceeds64klimit(
this.codestream.methoddeclaration);
}
if (localcontentsoffset + 20 >= this.contents.length) {
resizecontents(20);
}
int max_stack = this.codestream.stackmax;
this.contents[codeattributeoffset + 6] = (byte) (max_stack >> 8);
this.contents[codeattributeoffset + 7] = (byte) max_stack;
int max_locals = this.codestream.maxlocals;
this.contents[codeattributeoffset + 8] = (byte) (max_locals >> 8);
this.contents[codeattributeoffset + 9] = (byte) max_locals;
this.contents[codeattributeoffset + 10] = (byte) (code_length >> 24);
this.contents[codeattributeoffset + 11] = (byte) (code_length >> 16);
this.contents[codeattributeoffset + 12] = (byte) (code_length >> 8);
this.contents[codeattributeoffset + 13] = (byte) code_length;

boolean addstackmaps = (this.produceattributes & classfileconstants.attr_stack_map_table) != 0;
// write the exception table
exceptionlabel[] exceptionlabels = this.codestream.exceptionlabels;
int exceptionhandlerscount = 0; // each label holds one handler per range (start/end contiguous)
for (int i = 0, length = this.codestream.exceptionlabelscounter; i < length; i++) {
exceptionhandlerscount += this.codestream.exceptionlabels[i].count / 2;
}
int exsize = exceptionhandlerscount * 8 + 2;
if (exsize + localcontentsoffset >= this.contents.length) {
resizecontents(exsize);
}
// there is no exception table, so we need to offset by 2 the current offset and move
// on the attribute generation
this.contents[localcontentsoffset++] = (byte) (exceptionhandlerscount >> 8);
this.contents[localcontentsoffset++] = (byte) exceptionhandlerscount;
for (int i = 0, max = this.codestream.exceptionlabelscounter; i < max; i++) {
exceptionlabel exceptionlabel = exceptionlabels[i];
if (exceptionlabel != null) {
int irange = 0, maxrange = exceptionlabel.count;
if ((maxrange & 1) != 0) {
this.codestream.methoddeclaration.scope.problemreporter().abortduetointernalerror(
messages.bind(messages.abort_invalidexceptionattribute, new string(this.codestream.methoddeclaration.selector)),
this.codestream.methoddeclaration);
}
while  (irange < maxrange) {
int start = exceptionlabel.ranges[irange++]; // even ranges are start positions
this.contents[localcontentsoffset++] = (byte) (start >> 8);
this.contents[localcontentsoffset++] = (byte) start;
int end = exceptionlabel.ranges[irange++]; // odd ranges are end positions
this.contents[localcontentsoffset++] = (byte) (end >> 8);
this.contents[localcontentsoffset++] = (byte) end;
int handlerpc = exceptionlabel.position;
if (addstackmaps) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.addframeposition(handlerpc);
//						stackmapframecodestream.addexceptionmarker(handlerpc, exceptionlabel.exceptiontype);
}
this.contents[localcontentsoffset++] = (byte) (handlerpc >> 8);
this.contents[localcontentsoffset++] = (byte) handlerpc;
if (exceptionlabel.exceptiontype == null) {
// any exception handler
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
} else {
int nameindex;
if (exceptionlabel.exceptiontype == typebinding.null) {
/* represents classnotfoundexception, see class literal access*/
nameindex = this.constantpool.literalindexfortype(constantpool.javalangclassnotfoundexceptionconstantpoolname);
} else {
nameindex = this.constantpool.literalindexfortype(exceptionlabel.exceptiontype);
}
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
}
}
}
}
// debug attributes
int codeattributeattributeoffset = localcontentsoffset;
int attributenumber = 0;
// leave two bytes for the attribute_length
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}

// first we handle the linenumber attribute
if ((this.produceattributes & classfileconstants.attr_lines) != 0) {
/* create and add the line number attribute (used for debugging)
* build the pairs of:
* 	(bytecodepc linenumber)
* according to the table of start line indexes and the pctosourcemap table
* contained into the codestream
*/
int[] pctosourcemaptable;
if (((pctosourcemaptable = this.codestream.pctosourcemap) != null)
&& (this.codestream.pctosourcemapsize != 0)) {
int linenumbernameindex =
this.constantpool.literalindex(attributenamesconstants.linenumbertablename);
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
this.contents[localcontentsoffset++] = (byte) (linenumbernameindex >> 8);
this.contents[localcontentsoffset++] = (byte) linenumbernameindex;
int linenumbertableoffset = localcontentsoffset;
localcontentsoffset += 6;
// leave space for attribute_length and line_number_table_length
int numberofentries = 0;
int length = this.codestream.pctosourcemapsize;
for (int i = 0; i < length;) {
// write the entry
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
int pc = pctosourcemaptable[i++];
this.contents[localcontentsoffset++] = (byte) (pc >> 8);
this.contents[localcontentsoffset++] = (byte) pc;
int linenumber = pctosourcemaptable[i++];
this.contents[localcontentsoffset++] = (byte) (linenumber >> 8);
this.contents[localcontentsoffset++] = (byte) linenumber;
numberofentries++;
}
// now we change the size of the line number attribute
int linenumberattr_length = numberofentries * 4 + 2;
this.contents[linenumbertableoffset++] = (byte) (linenumberattr_length >> 24);
this.contents[linenumbertableoffset++] = (byte) (linenumberattr_length >> 16);
this.contents[linenumbertableoffset++] = (byte) (linenumberattr_length >> 8);
this.contents[linenumbertableoffset++] = (byte) linenumberattr_length;
this.contents[linenumbertableoffset++] = (byte) (numberofentries >> 8);
this.contents[linenumbertableoffset++] = (byte) numberofentries;
attributenumber++;
}
}
// then we do the local variable attribute
if ((this.produceattributes & classfileconstants.attr_vars) != 0) {
int numberofentries = 0;
int localvariablenameindex =
this.constantpool.literalindex(attributenamesconstants.localvariabletablename);
final boolean methoddeclarationisstatic = this.codestream.methoddeclaration.isstatic();
int maxofentries = 8 + 10 * (methoddeclarationisstatic ? 0 : 1);
for (int i = 0; i < this.codestream.alllocalscounter; i++) {
localvariablebinding localvariablebinding = this.codestream.locals[i];
maxofentries += 10 * localvariablebinding.initializationcount;
}
// reserve enough space
if (localcontentsoffset + maxofentries >= this.contents.length) {
resizecontents(maxofentries);
}
this.contents[localcontentsoffset++] = (byte) (localvariablenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) localvariablenameindex;
int localvariabletableoffset = localcontentsoffset;
// leave space for attribute_length and local_variable_table_length
localcontentsoffset += 6;
int nameindex;
int descriptorindex;
sourcetypebinding declaringclassbinding = null;
if (!methoddeclarationisstatic) {
numberofentries++;
this.contents[localcontentsoffset++] = 0; // the startpc for this is always 0
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (code_length >> 8);
this.contents[localcontentsoffset++] = (byte) code_length;
nameindex = this.constantpool.literalindex(constantpool.this);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
declaringclassbinding = (sourcetypebinding) this.codestream.methoddeclaration.binding.declaringclass;
descriptorindex =
this.constantpool.literalindex(
declaringclassbinding.signature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
this.contents[localcontentsoffset++] = 0;// the resolved position for this is always 0
this.contents[localcontentsoffset++] = 0;
}
// used to remember the local variable with a generic type
int genericlocalvariablescounter = 0;
localvariablebinding[] genericlocalvariables = null;
int numberofgenericentries = 0;

for (int i = 0, max = this.codestream.alllocalscounter; i < max; i++) {
localvariablebinding localvariable = this.codestream.locals[i];
if (localvariable.declaration == null) continue;
final typebinding localvariabletypebinding = localvariable.type;
boolean isparameterizedtype = localvariabletypebinding.isparameterizedtype() || localvariabletypebinding.istypevariable();
if (localvariable.initializationcount != 0 && isparameterizedtype) {
if (genericlocalvariables == null) {
// we cannot have more than max locals
genericlocalvariables = new localvariablebinding[max];
}
genericlocalvariables[genericlocalvariablescounter++] = localvariable;
}
for (int j = 0; j < localvariable.initializationcount; j++) {
int startpc = localvariable.initializationpcs[j << 1];
int endpc = localvariable.initializationpcs[(j << 1) + 1];
if (startpc != endpc) { // only entries for non zero length
if (endpc == -1) {
localvariable.declaringscope.problemreporter().abortduetointernalerror(
messages.bind(messages.abort_invalidattribute, new string(localvariable.name)),
(astnode) localvariable.declaringscope.methodscope().referencecontext);
}
if (isparameterizedtype) {
numberofgenericentries++;
}
// now we can safely add the local entry
numberofentries++;
this.contents[localcontentsoffset++] = (byte) (startpc >> 8);
this.contents[localcontentsoffset++] = (byte) startpc;
int length = endpc - startpc;
this.contents[localcontentsoffset++] = (byte) (length >> 8);
this.contents[localcontentsoffset++] = (byte) length;
nameindex = this.constantpool.literalindex(localvariable.name);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
descriptorindex = this.constantpool.literalindex(localvariabletypebinding.signature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
int resolvedposition = localvariable.resolvedposition;
this.contents[localcontentsoffset++] = (byte) (resolvedposition >> 8);
this.contents[localcontentsoffset++] = (byte) resolvedposition;
}
}
}
int value = numberofentries * 10 + 2;
this.contents[localvariabletableoffset++] = (byte) (value >> 24);
this.contents[localvariabletableoffset++] = (byte) (value >> 16);
this.contents[localvariabletableoffset++] = (byte) (value >> 8);
this.contents[localvariabletableoffset++] = (byte) value;
this.contents[localvariabletableoffset++] = (byte) (numberofentries >> 8);
this.contents[localvariabletableoffset] = (byte) numberofentries;
attributenumber++;

final boolean currentinstanceisgeneric =
!methoddeclarationisstatic
&& declaringclassbinding != null
&& declaringclassbinding.typevariables != binding.no_type_variables;
if (genericlocalvariablescounter != 0 || currentinstanceisgeneric) {
// add the local variable type table attribute
numberofgenericentries += (currentinstanceisgeneric ? 1 : 0);
maxofentries = 8 + numberofgenericentries * 10;
// reserve enough space
if (localcontentsoffset + maxofentries >= this.contents.length) {
resizecontents(maxofentries);
}
int localvariabletypenameindex =
this.constantpool.literalindex(attributenamesconstants.localvariabletypetablename);
this.contents[localcontentsoffset++] = (byte) (localvariabletypenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) localvariabletypenameindex;
value = numberofgenericentries * 10 + 2;
this.contents[localcontentsoffset++] = (byte) (value >> 24);
this.contents[localcontentsoffset++] = (byte) (value >> 16);
this.contents[localcontentsoffset++] = (byte) (value >> 8);
this.contents[localcontentsoffset++] = (byte) value;
this.contents[localcontentsoffset++] = (byte) (numberofgenericentries >> 8);
this.contents[localcontentsoffset++] = (byte) numberofgenericentries;
if (currentinstanceisgeneric) {
this.contents[localcontentsoffset++] = 0; // the startpc for this is always 0
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (code_length >> 8);
this.contents[localcontentsoffset++] = (byte) code_length;
nameindex = this.constantpool.literalindex(constantpool.this);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
descriptorindex = this.constantpool.literalindex(declaringclassbinding.generictypesignature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
this.contents[localcontentsoffset++] = 0;// the resolved position for this is always 0
this.contents[localcontentsoffset++] = 0;
}

for (int i = 0; i < genericlocalvariablescounter; i++) {
localvariablebinding localvariable = genericlocalvariables[i];
for (int j = 0; j < localvariable.initializationcount; j++) {
int startpc = localvariable.initializationpcs[j << 1];
int endpc = localvariable.initializationpcs[(j << 1) + 1];
if (startpc != endpc) {
// only entries for non zero length
// now we can safely add the local entry
this.contents[localcontentsoffset++] = (byte) (startpc >> 8);
this.contents[localcontentsoffset++] = (byte) startpc;
int length = endpc - startpc;
this.contents[localcontentsoffset++] = (byte) (length >> 8);
this.contents[localcontentsoffset++] = (byte) length;
nameindex = this.constantpool.literalindex(localvariable.name);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
descriptorindex = this.constantpool.literalindex(localvariable.type.generictypesignature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
int resolvedposition = localvariable.resolvedposition;
this.contents[localcontentsoffset++] = (byte) (resolvedposition >> 8);
this.contents[localcontentsoffset++] = (byte) resolvedposition;
}
}
}
attributenumber++;
}
}

if (addstackmaps) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(this.codestream.methoddeclaration.binding, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, false);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmaptableattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmaptablename);
this.contents[localcontentsoffset++] = (byte) (stackmaptableattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmaptableattributenameindex;

int stackmaptableattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
stackmapframe prevframe = null;
for (int j = 1; j < numberofframes; j++) {
// select next frame
prevframe = currentframe;
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
int offsetdelta = currentframe.getoffsetdelta(prevframe);
switch (currentframe.getframetype(prevframe)) {
case stackmapframe.append_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
int numberofdifferentlocals = currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 + numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int index = currentframe.getindexofdifferentlocals(numberofdifferentlocals);
int numberoflocals = currentframe.getnumberoflocals();
for (int i = index; i < currentframe.locals.length && numberofdifferentlocals > 0; i++) {
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberofdifferentlocals--;
}
}
break;
case stackmapframe.same_frame :
if (localcontentsoffset + 1 >= this.contents.length) {
resizecontents(1);
}
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_frame_extended :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
this.contents[localcontentsoffset++] = (byte) 251;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.chop_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
numberofdifferentlocals = -currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 - numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_locals_1_stack_items :
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[localcontentsoffset++] = (byte) (offsetdelta + 64);
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
case stackmapframe.same_locals_1_stack_items_extended :
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
this.contents[localcontentsoffset++] = (byte) 247;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
default :
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) 255;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}
}

numberofframes--;
if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmaptableattributelengthoffset - 4;
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmaptableattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

if ((this.produceattributes & classfileconstants.attr_stack_map) != 0) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(this.codestream.methoddeclaration.binding, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, false);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmapattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmapname);
this.contents[localcontentsoffset++] = (byte) (stackmapattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmapattributenameindex;

int stackmapattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
for (int j = 1; j < numberofframes; j++) {
// select next frame
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
int frameoffset = currentframe.pc;
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) (frameoffset >> 8);
this.contents[localcontentsoffset++] = (byte) frameoffset;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
int numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}

numberofframes--;
if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmapattributelengthoffset - 4;
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmapattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

this.contents[codeattributeattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[codeattributeattributeoffset] = (byte) attributenumber;

// update the attribute length
int codeattributelength = localcontentsoffset - (codeattributeoffset + 6);
this.contents[codeattributeoffset + 2] = (byte) (codeattributelength >> 24);
this.contents[codeattributeoffset + 3] = (byte) (codeattributelength >> 16);
this.contents[codeattributeoffset + 4] = (byte) (codeattributelength >> 8);
this.contents[codeattributeoffset + 5] = (byte) codeattributelength;
this.contentsoffset = localcontentsoffset;
}

/**
* internal use-only
* that method completes the creation of the code attribute by setting
* - the attribute_length
* - max_stack
* - max_locals
* - code_length
* - exception table
* - and debug attributes if necessary.
*
* @@param codeattributeoffset <code>int</code>
*/
public void completecodeattributeforclinit(int codeattributeoffset) {
// reinitialize the contents with the byte modified by the code stream
this.contents = this.codestream.bcodestream;
int localcontentsoffset = this.codestream.classfileoffset;
// codeattributeoffset is the position inside contents byte array before we started to write
// any information about the codeattribute
// that means that to write the attribute_length you need to offset by 2 the value of codeattributeoffset
// to get the right position, 6 for the max_stack etc...
int code_length = this.codestream.position;
if (code_length > 65535) {
this.codestream.methoddeclaration.scope.problemreporter().bytecodeexceeds64klimit(
this.codestream.methoddeclaration.scope.referencetype());
}
if (localcontentsoffset + 20 >= this.contents.length) {
resizecontents(20);
}
int max_stack = this.codestream.stackmax;
this.contents[codeattributeoffset + 6] = (byte) (max_stack >> 8);
this.contents[codeattributeoffset + 7] = (byte) max_stack;
int max_locals = this.codestream.maxlocals;
this.contents[codeattributeoffset + 8] = (byte) (max_locals >> 8);
this.contents[codeattributeoffset + 9] = (byte) max_locals;
this.contents[codeattributeoffset + 10] = (byte) (code_length >> 24);
this.contents[codeattributeoffset + 11] = (byte) (code_length >> 16);
this.contents[codeattributeoffset + 12] = (byte) (code_length >> 8);
this.contents[codeattributeoffset + 13] = (byte) code_length;

boolean addstackmaps = (this.produceattributes & classfileconstants.attr_stack_map_table) != 0;
// write the exception table
exceptionlabel[] exceptionlabels = this.codestream.exceptionlabels;
int exceptionhandlerscount = 0; // each label holds one handler per range (start/end contiguous)
for (int i = 0, length = this.codestream.exceptionlabelscounter; i < length; i++) {
exceptionhandlerscount += this.codestream.exceptionlabels[i].count / 2;
}
int exsize = exceptionhandlerscount * 8 + 2;
if (exsize + localcontentsoffset >= this.contents.length) {
resizecontents(exsize);
}
// there is no exception table, so we need to offset by 2 the current offset and move
// on the attribute generation
this.contents[localcontentsoffset++] = (byte) (exceptionhandlerscount >> 8);
this.contents[localcontentsoffset++] = (byte) exceptionhandlerscount;
for (int i = 0, max = this.codestream.exceptionlabelscounter; i < max; i++) {
exceptionlabel exceptionlabel = exceptionlabels[i];
if (exceptionlabel != null) {
int irange = 0, maxrange = exceptionlabel.count;
if ((maxrange & 1) != 0) {
this.codestream.methoddeclaration.scope.problemreporter().abortduetointernalerror(
messages.bind(messages.abort_invalidexceptionattribute, new string(this.codestream.methoddeclaration.selector)),
this.codestream.methoddeclaration);
}
while  (irange < maxrange) {
int start = exceptionlabel.ranges[irange++]; // even ranges are start positions
this.contents[localcontentsoffset++] = (byte) (start >> 8);
this.contents[localcontentsoffset++] = (byte) start;
int end = exceptionlabel.ranges[irange++]; // odd ranges are end positions
this.contents[localcontentsoffset++] = (byte) (end >> 8);
this.contents[localcontentsoffset++] = (byte) end;
int handlerpc = exceptionlabel.position;
this.contents[localcontentsoffset++] = (byte) (handlerpc >> 8);
this.contents[localcontentsoffset++] = (byte) handlerpc;
if (addstackmaps) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.addframeposition(handlerpc);
//						stackmapframecodestream.addexceptionmarker(handlerpc, exceptionlabel.exceptiontype);
}
if (exceptionlabel.exceptiontype == null) {
// any exception handler
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
} else {
int nameindex;
if (exceptionlabel.exceptiontype == typebinding.null) {
/* represents denote classnotfoundexception, see class literal access*/
nameindex = this.constantpool.literalindexfortype(constantpool.javalangclassnotfoundexceptionconstantpoolname);
} else {
nameindex = this.constantpool.literalindexfortype(exceptionlabel.exceptiontype);
}
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
}
}
}
}
// debug attributes
int codeattributeattributeoffset = localcontentsoffset;
int attributenumber = 0;
// leave two bytes for the attribute_length
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}

// first we handle the linenumber attribute
if ((this.produceattributes & classfileconstants.attr_lines) != 0) {
/* create and add the line number attribute (used for debugging)
* build the pairs of:
* 	(bytecodepc linenumber)
* according to the table of start line indexes and the pctosourcemap table
* contained into the codestream
*/
int[] pctosourcemaptable;
if (((pctosourcemaptable = this.codestream.pctosourcemap) != null)
&& (this.codestream.pctosourcemapsize != 0)) {
int linenumbernameindex =
this.constantpool.literalindex(attributenamesconstants.linenumbertablename);
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
this.contents[localcontentsoffset++] = (byte) (linenumbernameindex >> 8);
this.contents[localcontentsoffset++] = (byte) linenumbernameindex;
int linenumbertableoffset = localcontentsoffset;
localcontentsoffset += 6;
// leave space for attribute_length and line_number_table_length
int numberofentries = 0;
int length = this.codestream.pctosourcemapsize;
for (int i = 0; i < length;) {
// write the entry
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
int pc = pctosourcemaptable[i++];
this.contents[localcontentsoffset++] = (byte) (pc >> 8);
this.contents[localcontentsoffset++] = (byte) pc;
int linenumber = pctosourcemaptable[i++];
this.contents[localcontentsoffset++] = (byte) (linenumber >> 8);
this.contents[localcontentsoffset++] = (byte) linenumber;
numberofentries++;
}
// now we change the size of the line number attribute
int linenumberattr_length = numberofentries * 4 + 2;
this.contents[linenumbertableoffset++] = (byte) (linenumberattr_length >> 24);
this.contents[linenumbertableoffset++] = (byte) (linenumberattr_length >> 16);
this.contents[linenumbertableoffset++] = (byte) (linenumberattr_length >> 8);
this.contents[linenumbertableoffset++] = (byte) linenumberattr_length;
this.contents[linenumbertableoffset++] = (byte) (numberofentries >> 8);
this.contents[linenumbertableoffset++] = (byte) numberofentries;
attributenumber++;
}
}
// then we do the local variable attribute
if ((this.produceattributes & classfileconstants.attr_vars) != 0) {
int numberofentries = 0;
//		codeattribute.addlocalvariabletableattribute(this);
if ((this.codestream.pctosourcemap != null)
&& (this.codestream.pctosourcemapsize != 0)) {
int localvariablenameindex =
this.constantpool.literalindex(attributenamesconstants.localvariabletablename);
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
this.contents[localcontentsoffset++] = (byte) (localvariablenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) localvariablenameindex;
int localvariabletableoffset = localcontentsoffset;
localcontentsoffset += 6;

// leave space for attribute_length and local_variable_table_length
int nameindex;
int descriptorindex;

// used to remember the local variable with a generic type
int genericlocalvariablescounter = 0;
localvariablebinding[] genericlocalvariables = null;
int numberofgenericentries = 0;

for (int i = 0, max = this.codestream.alllocalscounter; i < max; i++) {
localvariablebinding localvariable = this.codestream.locals[i];
if (localvariable.declaration == null) continue;
final typebinding localvariabletypebinding = localvariable.type;
boolean isparameterizedtype = localvariabletypebinding.isparameterizedtype() || localvariabletypebinding.istypevariable();
if (localvariable.initializationcount != 0 && isparameterizedtype) {
if (genericlocalvariables == null) {
// we cannot have more than max locals
genericlocalvariables = new localvariablebinding[max];
}
genericlocalvariables[genericlocalvariablescounter++] = localvariable;
}
for (int j = 0; j < localvariable.initializationcount; j++) {
int startpc = localvariable.initializationpcs[j << 1];
int endpc = localvariable.initializationpcs[(j << 1) + 1];
if (startpc != endpc) { // only entries for non zero length
if (endpc == -1) {
localvariable.declaringscope.problemreporter().abortduetointernalerror(
messages.bind(messages.abort_invalidattribute, new string(localvariable.name)),
(astnode) localvariable.declaringscope.methodscope().referencecontext);
}
if (localcontentsoffset + 10 >= this.contents.length) {
resizecontents(10);
}
// now we can safely add the local entry
numberofentries++;
if (isparameterizedtype) {
numberofgenericentries++;
}
this.contents[localcontentsoffset++] = (byte) (startpc >> 8);
this.contents[localcontentsoffset++] = (byte) startpc;
int length = endpc - startpc;
this.contents[localcontentsoffset++] = (byte) (length >> 8);
this.contents[localcontentsoffset++] = (byte) length;
nameindex = this.constantpool.literalindex(localvariable.name);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
descriptorindex = this.constantpool.literalindex(localvariabletypebinding.signature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
int resolvedposition = localvariable.resolvedposition;
this.contents[localcontentsoffset++] = (byte) (resolvedposition >> 8);
this.contents[localcontentsoffset++] = (byte) resolvedposition;
}
}
}
int value = numberofentries * 10 + 2;
this.contents[localvariabletableoffset++] = (byte) (value >> 24);
this.contents[localvariabletableoffset++] = (byte) (value >> 16);
this.contents[localvariabletableoffset++] = (byte) (value >> 8);
this.contents[localvariabletableoffset++] = (byte) value;
this.contents[localvariabletableoffset++] = (byte) (numberofentries >> 8);
this.contents[localvariabletableoffset] = (byte) numberofentries;
attributenumber++;

if (genericlocalvariablescounter != 0) {
// add the local variable type table attribute
// reserve enough space
int maxofentries = 8 + numberofgenericentries * 10;

if (localcontentsoffset + maxofentries >= this.contents.length) {
resizecontents(maxofentries);
}
int localvariabletypenameindex =
this.constantpool.literalindex(attributenamesconstants.localvariabletypetablename);
this.contents[localcontentsoffset++] = (byte) (localvariabletypenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) localvariabletypenameindex;
value = numberofgenericentries * 10 + 2;
this.contents[localcontentsoffset++] = (byte) (value >> 24);
this.contents[localcontentsoffset++] = (byte) (value >> 16);
this.contents[localcontentsoffset++] = (byte) (value >> 8);
this.contents[localcontentsoffset++] = (byte) value;
this.contents[localcontentsoffset++] = (byte) (numberofgenericentries >> 8);
this.contents[localcontentsoffset++] = (byte) numberofgenericentries;
for (int i = 0; i < genericlocalvariablescounter; i++) {
localvariablebinding localvariable = genericlocalvariables[i];
for (int j = 0; j < localvariable.initializationcount; j++) {
int startpc = localvariable.initializationpcs[j << 1];
int endpc = localvariable.initializationpcs[(j << 1) + 1];
if (startpc != endpc) { // only entries for non zero length
// now we can safely add the local entry
this.contents[localcontentsoffset++] = (byte) (startpc >> 8);
this.contents[localcontentsoffset++] = (byte) startpc;
int length = endpc - startpc;
this.contents[localcontentsoffset++] = (byte) (length >> 8);
this.contents[localcontentsoffset++] = (byte) length;
nameindex = this.constantpool.literalindex(localvariable.name);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
descriptorindex = this.constantpool.literalindex(localvariable.type.generictypesignature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
int resolvedposition = localvariable.resolvedposition;
this.contents[localcontentsoffset++] = (byte) (resolvedposition >> 8);
this.contents[localcontentsoffset++] = (byte) resolvedposition;
}
}
}
attributenumber++;
}
}
}

if ((this.produceattributes & classfileconstants.attr_stack_map_table) != 0) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(null, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, true);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmaptableattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmaptablename);
this.contents[localcontentsoffset++] = (byte) (stackmaptableattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmaptableattributenameindex;

int stackmaptableattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
stackmapframe prevframe = null;
for (int j = 1; j < numberofframes; j++) {
// select next frame
prevframe = currentframe;
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
int offsetdelta = currentframe.getoffsetdelta(prevframe);
switch (currentframe.getframetype(prevframe)) {
case stackmapframe.append_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
int numberofdifferentlocals = currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 + numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int index = currentframe.getindexofdifferentlocals(numberofdifferentlocals);
int numberoflocals = currentframe.getnumberoflocals();
for (int i = index; i < currentframe.locals.length && numberofdifferentlocals > 0; i++) {
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberofdifferentlocals--;
}
}
break;
case stackmapframe.same_frame :
if (localcontentsoffset + 1 >= this.contents.length) {
resizecontents(1);
}
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_frame_extended :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
this.contents[localcontentsoffset++] = (byte) 251;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.chop_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
numberofdifferentlocals = -currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 - numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_locals_1_stack_items :
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[localcontentsoffset++] = (byte) (offsetdelta + 64);
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
case stackmapframe.same_locals_1_stack_items_extended :
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
this.contents[localcontentsoffset++] = (byte) 247;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
default :
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) 255;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}
}

numberofframes--;
if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmaptableattributelengthoffset - 4;
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmaptableattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

if ((this.produceattributes & classfileconstants.attr_stack_map) != 0) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(this.codestream.methoddeclaration.binding, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, false);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmapattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmapname);
this.contents[localcontentsoffset++] = (byte) (stackmapattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmapattributenameindex;

int stackmapattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
for (int j = 1; j < numberofframes; j++) {
// select next frame
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
int frameoffset = currentframe.pc;
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) (frameoffset >> 8);
this.contents[localcontentsoffset++] = (byte) frameoffset;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
int numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}

numberofframes--;
if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmapattributelengthoffset - 4;
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmapattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

// update the number of attributes
// ensure first that there is enough space available inside the contents array
if (codeattributeattributeoffset + 2 >= this.contents.length) {
resizecontents(2);
}
this.contents[codeattributeattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[codeattributeattributeoffset] = (byte) attributenumber;
// update the attribute length
int codeattributelength = localcontentsoffset - (codeattributeoffset + 6);
this.contents[codeattributeoffset + 2] = (byte) (codeattributelength >> 24);
this.contents[codeattributeoffset + 3] = (byte) (codeattributelength >> 16);
this.contents[codeattributeoffset + 4] = (byte) (codeattributelength >> 8);
this.contents[codeattributeoffset + 5] = (byte) codeattributelength;
this.contentsoffset = localcontentsoffset;
}

/**
* internal use-only
* that method completes the creation of the code attribute by setting
* - the attribute_length
* - max_stack
* - max_locals
* - code_length
* - exception table
* - and debug attributes if necessary.
*/
public void completecodeattributeforclinit(
int codeattributeoffset,
int problemline) {
// reinitialize the contents with the byte modified by the code stream
this.contents = this.codestream.bcodestream;
int localcontentsoffset = this.codestream.classfileoffset;
// codeattributeoffset is the position inside contents byte array before we started to write
// any information about the codeattribute
// that means that to write the attribute_length you need to offset by 2 the value of codeattributeoffset
// to get the right position, 6 for the max_stack etc...
int code_length = this.codestream.position;
if (code_length > 65535) {
this.codestream.methoddeclaration.scope.problemreporter().bytecodeexceeds64klimit(
this.codestream.methoddeclaration.scope.referencetype());
}
if (localcontentsoffset + 20 >= this.contents.length) {
resizecontents(20);
}
int max_stack = this.codestream.stackmax;
this.contents[codeattributeoffset + 6] = (byte) (max_stack >> 8);
this.contents[codeattributeoffset + 7] = (byte) max_stack;
int max_locals = this.codestream.maxlocals;
this.contents[codeattributeoffset + 8] = (byte) (max_locals >> 8);
this.contents[codeattributeoffset + 9] = (byte) max_locals;
this.contents[codeattributeoffset + 10] = (byte) (code_length >> 24);
this.contents[codeattributeoffset + 11] = (byte) (code_length >> 16);
this.contents[codeattributeoffset + 12] = (byte) (code_length >> 8);
this.contents[codeattributeoffset + 13] = (byte) code_length;

// write the exception table
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;

// debug attributes
int codeattributeattributeoffset = localcontentsoffset;
int attributenumber = 0; // leave two bytes for the attribute_length
localcontentsoffset += 2; // first we handle the linenumber attribute
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}

// first we handle the linenumber attribute
if ((this.produceattributes & classfileconstants.attr_lines) != 0) {
if (localcontentsoffset + 20 >= this.contents.length) {
resizecontents(20);
}
/* create and add the line number attribute (used for debugging)
* build the pairs of:
* (bytecodepc linenumber)
* according to the table of start line indexes and the pctosourcemap table
* contained into the codestream
*/
int linenumbernameindex =
this.constantpool.literalindex(attributenamesconstants.linenumbertablename);
this.contents[localcontentsoffset++] = (byte) (linenumbernameindex >> 8);
this.contents[localcontentsoffset++] = (byte) linenumbernameindex;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 6;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 1;
// first entry at pc = 0
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (problemline >> 8);
this.contents[localcontentsoffset++] = (byte) problemline;
// now we change the size of the line number attribute
attributenumber++;
}
// then we do the local variable attribute
if ((this.produceattributes & classfileconstants.attr_vars) != 0) {
int localvariablenameindex =
this.constantpool.literalindex(attributenamesconstants.localvariabletablename);
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
this.contents[localcontentsoffset++] = (byte) (localvariablenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) localvariablenameindex;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 2;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
attributenumber++;
}

if ((this.produceattributes & classfileconstants.attr_stack_map_table) != 0) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(null, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, true);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmaptableattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmaptablename);
this.contents[localcontentsoffset++] = (byte) (stackmaptableattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmaptableattributenameindex;

int stackmaptableattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
numberofframes = 0;
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
stackmapframe prevframe = null;
for (int j = 1; j < numberofframes; j++) {
// select next frame
prevframe = currentframe;
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
numberofframes++;
int offsetdelta = currentframe.getoffsetdelta(prevframe);
switch (currentframe.getframetype(prevframe)) {
case stackmapframe.append_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
int numberofdifferentlocals = currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 + numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int index = currentframe.getindexofdifferentlocals(numberofdifferentlocals);
int numberoflocals = currentframe.getnumberoflocals();
for (int i = index; i < currentframe.locals.length && numberofdifferentlocals > 0; i++) {
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberofdifferentlocals--;
}
}
break;
case stackmapframe.same_frame :
if (localcontentsoffset + 1 >= this.contents.length) {
resizecontents(1);
}
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_frame_extended :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
this.contents[localcontentsoffset++] = (byte) 251;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.chop_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
numberofdifferentlocals = -currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 - numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_locals_1_stack_items :
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[localcontentsoffset++] = (byte) (offsetdelta + 64);
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
case stackmapframe.same_locals_1_stack_items_extended :
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
this.contents[localcontentsoffset++] = (byte) 247;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
default :
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) 255;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}
}

if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmaptableattributelengthoffset - 4;
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmaptableattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

if ((this.produceattributes & classfileconstants.attr_stack_map) != 0) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(this.codestream.methoddeclaration.binding, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, false);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmapattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmapname);
this.contents[localcontentsoffset++] = (byte) (stackmapattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmapattributenameindex;

int stackmapattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
for (int j = 1; j < numberofframes; j++) {
// select next frame
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
int frameoffset = currentframe.pc;
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) (frameoffset >> 8);
this.contents[localcontentsoffset++] = (byte) frameoffset;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
int numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}

numberofframes--;
if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmapattributelengthoffset - 4;
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmapattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

// update the number of attributes
// ensure first that there is enough space available inside the contents array
if (codeattributeattributeoffset + 2 >= this.contents.length) {
resizecontents(2);
}
this.contents[codeattributeattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[codeattributeattributeoffset] = (byte) attributenumber;
// update the attribute length
int codeattributelength = localcontentsoffset - (codeattributeoffset + 6);
this.contents[codeattributeoffset + 2] = (byte) (codeattributelength >> 24);
this.contents[codeattributeoffset + 3] = (byte) (codeattributelength >> 16);
this.contents[codeattributeoffset + 4] = (byte) (codeattributelength >> 8);
this.contents[codeattributeoffset + 5] = (byte) codeattributelength;
this.contentsoffset = localcontentsoffset;
}

/**
*
*/
public void completecodeattributeformissingabstractproblemmethod(
methodbinding binding,
int codeattributeoffset,
int[] startlineindexes,
int problemline) {
// reinitialize the localcontents with the byte modified by the code stream
this.contents = this.codestream.bcodestream;
int localcontentsoffset = this.codestream.classfileoffset;
// codeattributeoffset is the position inside localcontents byte array before we started to write// any information about the codeattribute// that means that to write the attribute_length you need to offset by 2 the value of codeattributeoffset// to get the right position, 6 for the max_stack etc...
int max_stack = this.codestream.stackmax;
this.contents[codeattributeoffset + 6] = (byte) (max_stack >> 8);
this.contents[codeattributeoffset + 7] = (byte) max_stack;
int max_locals = this.codestream.maxlocals;
this.contents[codeattributeoffset + 8] = (byte) (max_locals >> 8);
this.contents[codeattributeoffset + 9] = (byte) max_locals;
int code_length = this.codestream.position;
this.contents[codeattributeoffset + 10] = (byte) (code_length >> 24);
this.contents[codeattributeoffset + 11] = (byte) (code_length >> 16);
this.contents[codeattributeoffset + 12] = (byte) (code_length >> 8);
this.contents[codeattributeoffset + 13] = (byte) code_length;
// write the exception table
if (localcontentsoffset + 50 >= this.contents.length) {
resizecontents(50);
}
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
// debug attributes
int codeattributeattributeoffset = localcontentsoffset;
int attributenumber = 0; // leave two bytes for the attribute_length
localcontentsoffset += 2; // first we handle the linenumber attribute
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}

if ((this.produceattributes & classfileconstants.attr_lines) != 0) {
if (localcontentsoffset + 12 >= this.contents.length) {
resizecontents(12);
}
/* create and add the line number attribute (used for debugging)
* build the pairs of:
* (bytecodepc linenumber)
* according to the table of start line indexes and the pctosourcemap table
* contained into the codestream
*/
int linenumbernameindex =
this.constantpool.literalindex(attributenamesconstants.linenumbertablename);
this.contents[localcontentsoffset++] = (byte) (linenumbernameindex >> 8);
this.contents[localcontentsoffset++] = (byte) linenumbernameindex;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 6;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 1;
if (problemline == 0) {
problemline = util.getlinenumber(binding.sourcestart(), startlineindexes, 0, startlineindexes.length-1);
}
// first entry at pc = 0
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (problemline >> 8);
this.contents[localcontentsoffset++] = (byte) problemline;
// now we change the size of the line number attribute
attributenumber++;
}

if ((this.produceattributes & classfileconstants.attr_stack_map_table) != 0) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(binding, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, false);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmaptableattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmaptablename);
this.contents[localcontentsoffset++] = (byte) (stackmaptableattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmaptableattributenameindex;

int stackmaptableattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
numberofframes = 0;
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
stackmapframe prevframe = null;
for (int j = 1; j < numberofframes; j++) {
// select next frame
prevframe = currentframe;
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
numberofframes++;
int offsetdelta = currentframe.getoffsetdelta(prevframe);
switch (currentframe.getframetype(prevframe)) {
case stackmapframe.append_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
int numberofdifferentlocals = currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 + numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int index = currentframe.getindexofdifferentlocals(numberofdifferentlocals);
int numberoflocals = currentframe.getnumberoflocals();
for (int i = index; i < currentframe.locals.length && numberofdifferentlocals > 0; i++) {
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberofdifferentlocals--;
}
}
break;
case stackmapframe.same_frame :
if (localcontentsoffset + 1 >= this.contents.length) {
resizecontents(1);
}
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_frame_extended :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
this.contents[localcontentsoffset++] = (byte) 251;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.chop_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
numberofdifferentlocals = -currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 - numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_locals_1_stack_items :
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[localcontentsoffset++] = (byte) (offsetdelta + 64);
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
case stackmapframe.same_locals_1_stack_items_extended :
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
this.contents[localcontentsoffset++] = (byte) 247;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
default :
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) 255;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}
}

if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmaptableattributelengthoffset - 4;
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmaptableattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

if ((this.produceattributes & classfileconstants.attr_stack_map) != 0) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(this.codestream.methoddeclaration.binding, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, false);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmapattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmapname);
this.contents[localcontentsoffset++] = (byte) (stackmapattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmapattributenameindex;

int stackmapattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
for (int j = 1; j < numberofframes; j++) {
// select next frame
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
int frameoffset = currentframe.pc;
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) (frameoffset >> 8);
this.contents[localcontentsoffset++] = (byte) frameoffset;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
int numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}

numberofframes--;
if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmapattributelengthoffset - 4;
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmapattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

// then we do the local variable attribute
// update the number of attributes// ensure first that there is enough space available inside the localcontents array
if (codeattributeattributeoffset + 2 >= this.contents.length) {
resizecontents(2);
}
this.contents[codeattributeattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[codeattributeattributeoffset] = (byte) attributenumber;
// update the attribute length
int codeattributelength = localcontentsoffset - (codeattributeoffset + 6);
this.contents[codeattributeoffset + 2] = (byte) (codeattributelength >> 24);
this.contents[codeattributeoffset + 3] = (byte) (codeattributelength >> 16);
this.contents[codeattributeoffset + 4] = (byte) (codeattributelength >> 8);
this.contents[codeattributeoffset + 5] = (byte) codeattributelength;
this.contentsoffset = localcontentsoffset;
}

/**
* internal use-only
* that method completes the creation of the code attribute by setting
* - the attribute_length
* - max_stack
* - max_locals
* - code_length
* - exception table
* - and debug attributes if necessary.
*
* @@param codeattributeoffset <code>int</code>
*/
public void completecodeattributeforproblemmethod(abstractmethoddeclaration method, methodbinding binding, int codeattributeoffset, int[] startlineindexes, int problemline) {
// reinitialize the localcontents with the byte modified by the code stream
this.contents = this.codestream.bcodestream;
int localcontentsoffset = this.codestream.classfileoffset;
// codeattributeoffset is the position inside localcontents byte array before we started to write// any information about the codeattribute// that means that to write the attribute_length you need to offset by 2 the value of codeattributeoffset// to get the right position, 6 for the max_stack etc...
int max_stack = this.codestream.stackmax;
this.contents[codeattributeoffset + 6] = (byte) (max_stack >> 8);
this.contents[codeattributeoffset + 7] = (byte) max_stack;
int max_locals = this.codestream.maxlocals;
this.contents[codeattributeoffset + 8] = (byte) (max_locals >> 8);
this.contents[codeattributeoffset + 9] = (byte) max_locals;
int code_length = this.codestream.position;
this.contents[codeattributeoffset + 10] = (byte) (code_length >> 24);
this.contents[codeattributeoffset + 11] = (byte) (code_length >> 16);
this.contents[codeattributeoffset + 12] = (byte) (code_length >> 8);
this.contents[codeattributeoffset + 13] = (byte) code_length;
// write the exception table
if (localcontentsoffset + 50 >= this.contents.length) {
resizecontents(50);
}

// write the exception table
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
// debug attributes
int codeattributeattributeoffset = localcontentsoffset;
int attributenumber = 0; // leave two bytes for the attribute_length
localcontentsoffset += 2; // first we handle the linenumber attribute
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}

if ((this.produceattributes & classfileconstants.attr_lines) != 0) {
if (localcontentsoffset + 20 >= this.contents.length) {
resizecontents(20);
}
/* create and add the line number attribute (used for debugging)
* build the pairs of:
* (bytecodepc linenumber)
* according to the table of start line indexes and the pctosourcemap table
* contained into the codestream
*/
int linenumbernameindex =
this.constantpool.literalindex(attributenamesconstants.linenumbertablename);
this.contents[localcontentsoffset++] = (byte) (linenumbernameindex >> 8);
this.contents[localcontentsoffset++] = (byte) linenumbernameindex;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 6;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 1;
if (problemline == 0) {
problemline = util.getlinenumber(binding.sourcestart(), startlineindexes, 0, startlineindexes.length-1);
}
// first entry at pc = 0
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (problemline >> 8);
this.contents[localcontentsoffset++] = (byte) problemline;
// now we change the size of the line number attribute
attributenumber++;
}
// then we do the local variable attribute
if ((this.produceattributes & classfileconstants.attr_vars) != 0) {
// compute the resolved position for the arguments of the method
int argsize;
int numberofentries = 0;
//		codeattribute.addlocalvariabletableattribute(this);
int localvariablenameindex =
this.constantpool.literalindex(attributenamesconstants.localvariabletablename);
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
this.contents[localcontentsoffset++] = (byte) (localvariablenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) localvariablenameindex;
int localvariabletableoffset = localcontentsoffset;
localcontentsoffset += 6;
// leave space for attribute_length and local_variable_table_length
int descriptorindex;
int nameindex;
sourcetypebinding declaringclassbinding = null;
final boolean methoddeclarationisstatic = this.codestream.methoddeclaration.isstatic();
if (!methoddeclarationisstatic) {
numberofentries++;
if (localcontentsoffset + 10 >= this.contents.length) {
resizecontents(10);
}
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (code_length >> 8);
this.contents[localcontentsoffset++] = (byte) code_length;
nameindex = this.constantpool.literalindex(constantpool.this);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
declaringclassbinding = (sourcetypebinding) this.codestream.methoddeclaration.binding.declaringclass;
descriptorindex =
this.constantpool.literalindex(declaringclassbinding.signature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
// the resolved position for this is always 0
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
}
// used to remember the local variable with a generic type
int genericlocalvariablescounter = 0;
localvariablebinding[] genericlocalvariables = null;
int numberofgenericentries = 0;

if (binding.isconstructor()) {
referencebinding declaringclass = binding.declaringclass;
if (declaringclass.isnestedtype()) {
nestedtypebinding methoddeclaringclass = (nestedtypebinding) declaringclass;
argsize = methoddeclaringclass.getenclosinginstancesslotsize();
syntheticargumentbinding[] syntheticarguments;
if ((syntheticarguments = methoddeclaringclass.syntheticenclosinginstances()) != null) {
for (int i = 0, max = syntheticarguments.length; i < max; i++) {
localvariablebinding localvariable = syntheticarguments[i];
final typebinding localvariabletypebinding = localvariable.type;
if (localvariabletypebinding.isparameterizedtype() || localvariabletypebinding.istypevariable()) {
if (genericlocalvariables == null) {
// we cannot have more than max locals
genericlocalvariables = new localvariablebinding[max];
}
genericlocalvariables[genericlocalvariablescounter++] = localvariable;
numberofgenericentries++;
}
if (localcontentsoffset + 10 >= this.contents.length) {
resizecontents(10);
}
// now we can safely add the local entry
numberofentries++;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (code_length >> 8);
this.contents[localcontentsoffset++] = (byte) code_length;
nameindex = this.constantpool.literalindex(localvariable.name);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
descriptorindex = this.constantpool.literalindex(localvariabletypebinding.signature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
int resolvedposition = localvariable.resolvedposition;
this.contents[localcontentsoffset++] = (byte) (resolvedposition >> 8);
this.contents[localcontentsoffset++] = (byte) resolvedposition;
}
}
} else {
argsize = 1;
}
} else {
argsize = binding.isstatic() ? 0 : 1;
}

int genericargumentscounter = 0;
int[] genericargumentsnameindexes = null;
int[] genericargumentsresolvedpositions = null;
typebinding[] genericargumentstypebindings = null;

if (method.binding != null) {
typebinding[] parameters = method.binding.parameters;
argument[] arguments = method.arguments;
if ((parameters != null) && (arguments != null)) {
for (int i = 0, max = parameters.length; i < max; i++) {
typebinding argumentbinding = parameters[i];
if (localcontentsoffset + 10 >= this.contents.length) {
resizecontents(10);
}
// now we can safely add the local entry
numberofentries++;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (code_length >> 8);
this.contents[localcontentsoffset++] = (byte) code_length;
nameindex = this.constantpool.literalindex(arguments[i].name);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
int resolvedposition = argsize;
if (argumentbinding.isparameterizedtype() || argumentbinding.istypevariable()) {
if (genericargumentscounter == 0) {
// we cannot have more than max locals
genericargumentsnameindexes = new int[max];
genericargumentsresolvedpositions = new int[max];
genericargumentstypebindings = new typebinding[max];
}
genericargumentsnameindexes[genericargumentscounter] = nameindex;
genericargumentsresolvedpositions[genericargumentscounter] = resolvedposition;
genericargumentstypebindings[genericargumentscounter++] = argumentbinding;
}
descriptorindex = this.constantpool.literalindex(argumentbinding.signature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
switch(argumentbinding.id) {
case typeids.t_long :
case typeids.t_double :
argsize += 2;
break;
default :
argsize++;
break;
}
this.contents[localcontentsoffset++] = (byte) (resolvedposition >> 8);
this.contents[localcontentsoffset++] = (byte) resolvedposition;
}
}
}
int value = numberofentries * 10 + 2;
this.contents[localvariabletableoffset++] = (byte) (value >> 24);
this.contents[localvariabletableoffset++] = (byte) (value >> 16);
this.contents[localvariabletableoffset++] = (byte) (value >> 8);
this.contents[localvariabletableoffset++] = (byte) value;
this.contents[localvariabletableoffset++] = (byte) (numberofentries >> 8);
this.contents[localvariabletableoffset] = (byte) numberofentries;
attributenumber++;

final boolean currentinstanceisgeneric =
!methoddeclarationisstatic
&& declaringclassbinding != null
&& declaringclassbinding.typevariables != binding.no_type_variables;
if (genericlocalvariablescounter != 0 || genericargumentscounter != 0 || currentinstanceisgeneric) {
// add the local variable type table attribute
numberofentries = numberofgenericentries + genericargumentscounter + (currentinstanceisgeneric ? 1 : 0);
// reserve enough space
int maxofentries = 8 + numberofentries * 10;
if (localcontentsoffset + maxofentries >= this.contents.length) {
resizecontents(maxofentries);
}
int localvariabletypenameindex =
this.constantpool.literalindex(attributenamesconstants.localvariabletypetablename);
this.contents[localcontentsoffset++] = (byte) (localvariabletypenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) localvariabletypenameindex;
value = numberofentries * 10 + 2;
this.contents[localcontentsoffset++] = (byte) (value >> 24);
this.contents[localcontentsoffset++] = (byte) (value >> 16);
this.contents[localcontentsoffset++] = (byte) (value >> 8);
this.contents[localcontentsoffset++] = (byte) value;
this.contents[localcontentsoffset++] = (byte) (numberofentries >> 8);
this.contents[localcontentsoffset++] = (byte) numberofentries;
if (currentinstanceisgeneric) {
numberofentries++;
this.contents[localcontentsoffset++] = 0; // the startpc for this is always 0
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (code_length >> 8);
this.contents[localcontentsoffset++] = (byte) code_length;
nameindex = this.constantpool.literalindex(constantpool.this);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
descriptorindex = this.constantpool.literalindex(declaringclassbinding.generictypesignature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
this.contents[localcontentsoffset++] = 0;// the resolved position for this is always 0
this.contents[localcontentsoffset++] = 0;
}

for (int i = 0; i < genericlocalvariablescounter; i++) {
localvariablebinding localvariable = genericlocalvariables[i];
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (code_length >> 8);
this.contents[localcontentsoffset++] = (byte) code_length;
nameindex = this.constantpool.literalindex(localvariable.name);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
descriptorindex = this.constantpool.literalindex(localvariable.type.generictypesignature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
int resolvedposition = localvariable.resolvedposition;
this.contents[localcontentsoffset++] = (byte) (resolvedposition >> 8);
this.contents[localcontentsoffset++] = (byte) resolvedposition;
}
for (int i = 0; i < genericargumentscounter; i++) {
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (code_length >> 8);
this.contents[localcontentsoffset++] = (byte) code_length;
nameindex = genericargumentsnameindexes[i];
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
descriptorindex = this.constantpool.literalindex(genericargumentstypebindings[i].generictypesignature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
int resolvedposition = genericargumentsresolvedpositions[i];
this.contents[localcontentsoffset++] = (byte) (resolvedposition >> 8);
this.contents[localcontentsoffset++] = (byte) resolvedposition;
}
attributenumber++;
}
}

if ((this.produceattributes & classfileconstants.attr_stack_map_table) != 0) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(binding, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, false);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmaptableattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmaptablename);
this.contents[localcontentsoffset++] = (byte) (stackmaptableattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmaptableattributenameindex;

int stackmaptableattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
numberofframes = 0;
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
stackmapframe prevframe = null;
for (int j = 1; j < numberofframes; j++) {
// select next frame
prevframe = currentframe;
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
numberofframes++;
int offsetdelta = currentframe.getoffsetdelta(prevframe);
switch (currentframe.getframetype(prevframe)) {
case stackmapframe.append_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
int numberofdifferentlocals = currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 + numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int index = currentframe.getindexofdifferentlocals(numberofdifferentlocals);
int numberoflocals = currentframe.getnumberoflocals();
for (int i = index; i < currentframe.locals.length && numberofdifferentlocals > 0; i++) {
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberofdifferentlocals--;
}
}
break;
case stackmapframe.same_frame :
if (localcontentsoffset + 1 >= this.contents.length) {
resizecontents(1);
}
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_frame_extended :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
this.contents[localcontentsoffset++] = (byte) 251;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.chop_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
numberofdifferentlocals = -currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 - numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_locals_1_stack_items :
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[localcontentsoffset++] = (byte) (offsetdelta + 64);
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
case stackmapframe.same_locals_1_stack_items_extended :
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
this.contents[localcontentsoffset++] = (byte) 247;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
default :
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) 255;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}
}

if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmaptableattributelengthoffset - 4;
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmaptableattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

if ((this.produceattributes & classfileconstants.attr_stack_map) != 0) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(this.codestream.methoddeclaration.binding, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, false);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmapattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmapname);
this.contents[localcontentsoffset++] = (byte) (stackmapattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmapattributenameindex;

int stackmapattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
for (int j = 1; j < numberofframes; j++) {
// select next frame
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
int frameoffset = currentframe.pc;
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) (frameoffset >> 8);
this.contents[localcontentsoffset++] = (byte) frameoffset;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
int numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}

numberofframes--;
if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmapattributelengthoffset - 4;
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmapattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

// update the number of attributes// ensure first that there is enough space available inside the localcontents array
if (codeattributeattributeoffset + 2 >= this.contents.length) {
resizecontents(2);
}
this.contents[codeattributeattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[codeattributeattributeoffset] = (byte) attributenumber;
// update the attribute length
int codeattributelength = localcontentsoffset - (codeattributeoffset + 6);
this.contents[codeattributeoffset + 2] = (byte) (codeattributelength >> 24);
this.contents[codeattributeoffset + 3] = (byte) (codeattributelength >> 16);
this.contents[codeattributeoffset + 4] = (byte) (codeattributelength >> 8);
this.contents[codeattributeoffset + 5] = (byte) codeattributelength;
this.contentsoffset = localcontentsoffset;
}

/**
* internal use-only
* that method completes the creation of the code attribute by setting
* - the attribute_length
* - max_stack
* - max_locals
* - code_length
* - exception table
* - and debug attributes if necessary.
*
* @@param binding org.eclipse.jdt.internal.compiler.lookup.syntheticaccessmethodbinding
* @@param codeattributeoffset <code>int</code>
*/
public void completecodeattributeforsyntheticmethod(
boolean hasexceptionhandlers,
syntheticmethodbinding binding,
int codeattributeoffset,
int[] startlineindexes) {
// reinitialize the contents with the byte modified by the code stream
this.contents = this.codestream.bcodestream;
int localcontentsoffset = this.codestream.classfileoffset;
// codeattributeoffset is the position inside contents byte array before we started to write
// any information about the codeattribute
// that means that to write the attribute_length you need to offset by 2 the value of codeattributeoffset
// to get the right position, 6 for the max_stack etc...
int max_stack = this.codestream.stackmax;
this.contents[codeattributeoffset + 6] = (byte) (max_stack >> 8);
this.contents[codeattributeoffset + 7] = (byte) max_stack;
int max_locals = this.codestream.maxlocals;
this.contents[codeattributeoffset + 8] = (byte) (max_locals >> 8);
this.contents[codeattributeoffset + 9] = (byte) max_locals;
int code_length = this.codestream.position;
this.contents[codeattributeoffset + 10] = (byte) (code_length >> 24);
this.contents[codeattributeoffset + 11] = (byte) (code_length >> 16);
this.contents[codeattributeoffset + 12] = (byte) (code_length >> 8);
this.contents[codeattributeoffset + 13] = (byte) code_length;
if ((localcontentsoffset + 40) >= this.contents.length) {
resizecontents(40);
}

boolean addstackmaps = (this.produceattributes & classfileconstants.attr_stack_map_table) != 0;
if (hasexceptionhandlers) {
// write the exception table
exceptionlabel[] exceptionlabels = this.codestream.exceptionlabels;
int exceptionhandlerscount = 0; // each label holds one handler per range (start/end contiguous)
for (int i = 0, length = this.codestream.exceptionlabelscounter; i < length; i++) {
exceptionhandlerscount += this.codestream.exceptionlabels[i].count / 2;
}
int exsize = exceptionhandlerscount * 8 + 2;
if (exsize + localcontentsoffset >= this.contents.length) {
resizecontents(exsize);
}
// there is no exception table, so we need to offset by 2 the current offset and move
// on the attribute generation
this.contents[localcontentsoffset++] = (byte) (exceptionhandlerscount >> 8);
this.contents[localcontentsoffset++] = (byte) exceptionhandlerscount;
for (int i = 0, max = this.codestream.exceptionlabelscounter; i < max; i++) {
exceptionlabel exceptionlabel = exceptionlabels[i];
if (exceptionlabel != null) {
int irange = 0, maxrange = exceptionlabel.count;
if ((maxrange & 1) != 0) {
this.referencebinding.scope.problemreporter().abortduetointernalerror(
messages.bind(messages.abort_invalidexceptionattribute, new string(binding.selector),
this.referencebinding.scope.problemreporter().referencecontext));
}
while  (irange < maxrange) {
int start = exceptionlabel.ranges[irange++]; // even ranges are start positions
this.contents[localcontentsoffset++] = (byte) (start >> 8);
this.contents[localcontentsoffset++] = (byte) start;
int end = exceptionlabel.ranges[irange++]; // odd ranges are end positions
this.contents[localcontentsoffset++] = (byte) (end >> 8);
this.contents[localcontentsoffset++] = (byte) end;
int handlerpc = exceptionlabel.position;
if (addstackmaps) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.addframeposition(handlerpc);
//							stackmapframecodestream.addexceptionmarker(handlerpc, exceptionlabel.exceptiontype);
}
this.contents[localcontentsoffset++] = (byte) (handlerpc >> 8);
this.contents[localcontentsoffset++] = (byte) handlerpc;
if (exceptionlabel.exceptiontype == null) {
// any exception handler
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
} else {
int nameindex;
switch(exceptionlabel.exceptiontype.id) {
case t_null :
/* represents classnotfoundexception, see class literal access*/
nameindex = this.constantpool.literalindexfortype(constantpool.javalangclassnotfoundexceptionconstantpoolname);
break;
case t_long :
/* represents nosuchfielderror, see switch table generation*/
nameindex = this.constantpool.literalindexfortype(constantpool.javalangnosuchfielderrorconstantpoolname);
break;
default:
nameindex = this.constantpool.literalindexfortype(exceptionlabel.exceptiontype);
}
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
}
}
}
}
} else {
// there is no exception table, so we need to offset by 2 the current offset and move
// on the attribute generation
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
}
// debug attributes
int codeattributeattributeoffset = localcontentsoffset;
int attributenumber = 0;
// leave two bytes for the attribute_length
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}

// first we handle the linenumber attribute
if ((this.produceattributes & classfileconstants.attr_lines) != 0) {
if (localcontentsoffset + 12 >= this.contents.length) {
resizecontents(12);
}
int index = 0;
int linenumbernameindex =
this.constantpool.literalindex(attributenamesconstants.linenumbertablename);
this.contents[localcontentsoffset++] = (byte) (linenumbernameindex >> 8);
this.contents[localcontentsoffset++] = (byte) linenumbernameindex;
int linenumbertableoffset = localcontentsoffset;
localcontentsoffset += 6;
// leave space for attribute_length and line_number_table_length
// seems like do would be better, but this preserves the existing behavior.
index = util.getlinenumber(binding.sourcestart, startlineindexes, 0, startlineindexes.length-1);
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = 0;
this.contents[localcontentsoffset++] = (byte) (index >> 8);
this.contents[localcontentsoffset++] = (byte) index;
// now we change the size of the line number attribute
this.contents[linenumbertableoffset++] = 0;
this.contents[linenumbertableoffset++] = 0;
this.contents[linenumbertableoffset++] = 0;
this.contents[linenumbertableoffset++] = 6;
this.contents[linenumbertableoffset++] = 0;
this.contents[linenumbertableoffset++] = 1;
attributenumber++;
}
// then we do the local variable attribute
if ((this.produceattributes & classfileconstants.attr_vars) != 0) {
int numberofentries = 0;
int localvariablenameindex =
this.constantpool.literalindex(attributenamesconstants.localvariabletablename);
if (localcontentsoffset + 8 > this.contents.length) {
resizecontents(8);
}
this.contents[localcontentsoffset++] = (byte) (localvariablenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) localvariablenameindex;
int localvariabletableoffset = localcontentsoffset;
localcontentsoffset += 6;
// leave space for attribute_length and local_variable_table_length
int nameindex;
int descriptorindex;

// used to remember the local variable with a generic type
int genericlocalvariablescounter = 0;
localvariablebinding[] genericlocalvariables = null;
int numberofgenericentries = 0;

for (int i = 0, max = this.codestream.alllocalscounter; i < max; i++) {
localvariablebinding localvariable = this.codestream.locals[i];
if (localvariable.declaration == null) continue;
final typebinding localvariabletypebinding = localvariable.type;
boolean isparameterizedtype = localvariabletypebinding.isparameterizedtype() || localvariabletypebinding.istypevariable();
if (localvariable.initializationcount != 0 && isparameterizedtype) {
if (genericlocalvariables == null) {
// we cannot have more than max locals
genericlocalvariables = new localvariablebinding[max];
}
genericlocalvariables[genericlocalvariablescounter++] = localvariable;
}
for (int j = 0; j < localvariable.initializationcount; j++) {
int startpc = localvariable.initializationpcs[j << 1];
int endpc = localvariable.initializationpcs[(j << 1) + 1];
if (startpc != endpc) { // only entries for non zero length
if (endpc == -1) {
localvariable.declaringscope.problemreporter().abortduetointernalerror(
messages.bind(messages.abort_invalidattribute, new string(localvariable.name)),
(astnode) localvariable.declaringscope.methodscope().referencecontext);
}
if (localcontentsoffset + 10 > this.contents.length) {
resizecontents(10);
}
// now we can safely add the local entry
numberofentries++;
if (isparameterizedtype) {
numberofgenericentries++;
}
this.contents[localcontentsoffset++] = (byte) (startpc >> 8);
this.contents[localcontentsoffset++] = (byte) startpc;
int length = endpc - startpc;
this.contents[localcontentsoffset++] = (byte) (length >> 8);
this.contents[localcontentsoffset++] = (byte) length;
nameindex = this.constantpool.literalindex(localvariable.name);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
descriptorindex = this.constantpool.literalindex(localvariabletypebinding.signature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
int resolvedposition = localvariable.resolvedposition;
this.contents[localcontentsoffset++] = (byte) (resolvedposition >> 8);
this.contents[localcontentsoffset++] = (byte) resolvedposition;
}
}
}
int value = numberofentries * 10 + 2;
this.contents[localvariabletableoffset++] = (byte) (value >> 24);
this.contents[localvariabletableoffset++] = (byte) (value >> 16);
this.contents[localvariabletableoffset++] = (byte) (value >> 8);
this.contents[localvariabletableoffset++] = (byte) value;
this.contents[localvariabletableoffset++] = (byte) (numberofentries >> 8);
this.contents[localvariabletableoffset] = (byte) numberofentries;
attributenumber++;

if (genericlocalvariablescounter != 0) {
// add the local variable type table attribute
int maxofentries = 8 + numberofgenericentries * 10;
// reserve enough space
if (localcontentsoffset + maxofentries >= this.contents.length) {
resizecontents(maxofentries);
}
int localvariabletypenameindex =
this.constantpool.literalindex(attributenamesconstants.localvariabletypetablename);
this.contents[localcontentsoffset++] = (byte) (localvariabletypenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) localvariabletypenameindex;
value = numberofgenericentries * 10 + 2;
this.contents[localcontentsoffset++] = (byte) (value >> 24);
this.contents[localcontentsoffset++] = (byte) (value >> 16);
this.contents[localcontentsoffset++] = (byte) (value >> 8);
this.contents[localcontentsoffset++] = (byte) value;
this.contents[localcontentsoffset++] = (byte) (numberofgenericentries >> 8);
this.contents[localcontentsoffset++] = (byte) numberofgenericentries;

for (int i = 0; i < genericlocalvariablescounter; i++) {
localvariablebinding localvariable = genericlocalvariables[i];
for (int j = 0; j < localvariable.initializationcount; j++) {
int startpc = localvariable.initializationpcs[j << 1];
int endpc = localvariable.initializationpcs[(j << 1) + 1];
if (startpc != endpc) { // only entries for non zero length
// now we can safely add the local entry
this.contents[localcontentsoffset++] = (byte) (startpc >> 8);
this.contents[localcontentsoffset++] = (byte) startpc;
int length = endpc - startpc;
this.contents[localcontentsoffset++] = (byte) (length >> 8);
this.contents[localcontentsoffset++] = (byte) length;
nameindex = this.constantpool.literalindex(localvariable.name);
this.contents[localcontentsoffset++] = (byte) (nameindex >> 8);
this.contents[localcontentsoffset++] = (byte) nameindex;
descriptorindex = this.constantpool.literalindex(localvariable.type.generictypesignature());
this.contents[localcontentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[localcontentsoffset++] = (byte) descriptorindex;
int resolvedposition = localvariable.resolvedposition;
this.contents[localcontentsoffset++] = (byte) (resolvedposition >> 8);
this.contents[localcontentsoffset++] = (byte) resolvedposition;
}
}
}
attributenumber++;
}
}

if (addstackmaps) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(binding, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, false);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmaptableattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmaptablename);
this.contents[localcontentsoffset++] = (byte) (stackmaptableattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmaptableattributenameindex;

int stackmaptableattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
stackmapframe prevframe = null;
for (int j = 1; j < numberofframes; j++) {
// select next frame
prevframe = currentframe;
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
int offsetdelta = currentframe.getoffsetdelta(prevframe);
switch (currentframe.getframetype(prevframe)) {
case stackmapframe.append_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
int numberofdifferentlocals = currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 + numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int index = currentframe.getindexofdifferentlocals(numberofdifferentlocals);
int numberoflocals = currentframe.getnumberoflocals();
for (int i = index; i < currentframe.locals.length && numberofdifferentlocals > 0; i++) {
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberofdifferentlocals--;
}
}
break;
case stackmapframe.same_frame :
if (localcontentsoffset + 1 >= this.contents.length) {
resizecontents(1);
}
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_frame_extended :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
this.contents[localcontentsoffset++] = (byte) 251;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.chop_frame :
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
numberofdifferentlocals = -currentframe.numberofdifferentlocals(prevframe);
this.contents[localcontentsoffset++] = (byte) (251 - numberofdifferentlocals);
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
break;
case stackmapframe.same_locals_1_stack_items :
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[localcontentsoffset++] = (byte) (offsetdelta + 64);
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
case stackmapframe.same_locals_1_stack_items_extended :
if (localcontentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
this.contents[localcontentsoffset++] = (byte) 247;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
if (currentframe.stackitems[0] == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(currentframe.stackitems[0].id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
verificationtypeinfo info = currentframe.stackitems[0];
byte tag = (byte) info.tag;
this.contents[localcontentsoffset++] = tag;
switch (tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
break;
default :
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) 255;
this.contents[localcontentsoffset++] = (byte) (offsetdelta >> 8);
this.contents[localcontentsoffset++] = (byte) offsetdelta;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}
}

numberofframes--;
if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmaptableattributelengthoffset - 4;
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmaptableattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmaptableattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

if ((this.produceattributes & classfileconstants.attr_stack_map) != 0) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
stackmapframecodestream.removeframeposition(code_length);
if (stackmapframecodestream.hasframepositions()) {
arraylist frames = new arraylist();
traverse(this.codestream.methoddeclaration.binding, max_locals, this.contents, codeattributeoffset + 14, code_length, frames, false);
int numberofframes = frames.size();
if (numberofframes > 1) {
int stackmaptableattributeoffset = localcontentsoffset;
// add the stack map table attribute
if (localcontentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int stackmapattributenameindex =
this.constantpool.literalindex(attributenamesconstants.stackmapname);
this.contents[localcontentsoffset++] = (byte) (stackmapattributenameindex >> 8);
this.contents[localcontentsoffset++] = (byte) stackmapattributenameindex;

int stackmapattributelengthoffset = localcontentsoffset;
// generate the attribute
localcontentsoffset += 4;
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
int numberofframesoffset = localcontentsoffset;
localcontentsoffset += 2;
if (localcontentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
stackmapframe currentframe = (stackmapframe) frames.get(0);
for (int j = 1; j < numberofframes; j++) {
// select next frame
currentframe = (stackmapframe) frames.get(j);
// generate current frame
// need to find differences between the current frame and the previous frame
int frameoffset = currentframe.pc;
// full_frame
if (localcontentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[localcontentsoffset++] = (byte) (frameoffset >> 8);
this.contents[localcontentsoffset++] = (byte) frameoffset;
int numberoflocaloffset = localcontentsoffset;
localcontentsoffset += 2; // leave two spots for number of locals
int numberoflocalentries = 0;
int numberoflocals = currentframe.getnumberoflocals();
int numberofentries = 0;
int localslength = currentframe.locals == null ? 0 : currentframe.locals.length;
for (int i = 0; i < localslength && numberoflocalentries < numberoflocals; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.locals[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
i++;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
i++;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
numberoflocalentries++;
}
numberofentries++;
}
if (localcontentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
this.contents[numberoflocaloffset++] = (byte) (numberofentries >> 8);
this.contents[numberoflocaloffset] = (byte) numberofentries;
int numberofstackitems = currentframe.numberofstackitems;
this.contents[localcontentsoffset++] = (byte) (numberofstackitems >> 8);
this.contents[localcontentsoffset++] = (byte) numberofstackitems;
for (int i = 0; i < numberofstackitems; i++) {
if (localcontentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
verificationtypeinfo info = currentframe.stackitems[i];
if (info == null) {
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_top;
} else {
switch(info.id()) {
case t_boolean :
case t_byte :
case t_char :
case t_int :
case t_short :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_integer;
break;
case t_float :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_float;
break;
case t_long :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_long;
break;
case t_double :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_double;
break;
case t_null :
this.contents[localcontentsoffset++] = (byte) verificationtypeinfo.item_null;
break;
default:
this.contents[localcontentsoffset++] = (byte) info.tag;
switch (info.tag) {
case verificationtypeinfo.item_uninitialized :
int offset = info.offset;
this.contents[localcontentsoffset++] = (byte) (offset >> 8);
this.contents[localcontentsoffset++] = (byte) offset;
break;
case verificationtypeinfo.item_object :
int indexfortype = this.constantpool.literalindexfortype(info.constantpoolname());
this.contents[localcontentsoffset++] = (byte) (indexfortype >> 8);
this.contents[localcontentsoffset++] = (byte) indexfortype;
}
}
}
}
}

numberofframes--;
if (numberofframes != 0) {
this.contents[numberofframesoffset++] = (byte) (numberofframes >> 8);
this.contents[numberofframesoffset] = (byte) numberofframes;

int attributelength = localcontentsoffset - stackmapattributelengthoffset - 4;
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[stackmapattributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[stackmapattributelengthoffset] = (byte) attributelength;
attributenumber++;
} else {
localcontentsoffset = stackmaptableattributeoffset;
}
}
}
}

// update the number of attributes
// ensure first that there is enough space available inside the contents array
if (codeattributeattributeoffset + 2 >= this.contents.length) {
resizecontents(2);
}
this.contents[codeattributeattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[codeattributeattributeoffset] = (byte) attributenumber;

// update the attribute length
int codeattributelength = localcontentsoffset - (codeattributeoffset + 6);
this.contents[codeattributeoffset + 2] = (byte) (codeattributelength >> 24);
this.contents[codeattributeoffset + 3] = (byte) (codeattributelength >> 16);
this.contents[codeattributeoffset + 4] = (byte) (codeattributelength >> 8);
this.contents[codeattributeoffset + 5] = (byte) codeattributelength;
this.contentsoffset = localcontentsoffset;
}

/**
* internal use-only
* that method completes the creation of the code attribute by setting
* - the attribute_length
* - max_stack
* - max_locals
* - code_length
* - exception table
* - and debug attributes if necessary.
*
* @@param binding org.eclipse.jdt.internal.compiler.lookup.syntheticaccessmethodbinding
* @@param codeattributeoffset <code>int</code>
*/
public void completecodeattributeforsyntheticmethod(
syntheticmethodbinding binding,
int codeattributeoffset,
int[] startlineindexes) {

this.completecodeattributeforsyntheticmethod(
false,
binding,
codeattributeoffset,
startlineindexes);
}

/**
* internal use-only
* complete the creation of a method info by setting up the number of attributes at the right offset.
*
* @@param methodattributeoffset <code>int</code>
* @@param attributenumber <code>int</code>
*/
public void completemethodinfo(
int methodattributeoffset,
int attributenumber) {
// update the number of attributes
this.contents[methodattributeoffset++] = (byte) (attributenumber >> 8);
this.contents[methodattributeoffset] = (byte) attributenumber;
}

/**
* internal use-only
* this methods returns a char[] representing the file name of the receiver
*
* @@return char[]
*/
public char[] filename() {
return this.constantpool.utf8cache.returnkeyfor(2);
}

private void generateannotation(annotation annotation, int currentoffset) {
int startingcontentsoffset = currentoffset;
if (this.contentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
typebinding annotationtypebinding = annotation.resolvedtype;
if (annotationtypebinding == null) {
this.contentsoffset = startingcontentsoffset;
return;
}
final int typeindex = this.constantpool.literalindex(annotationtypebinding.signature());
this.contents[this.contentsoffset++] = (byte) (typeindex >> 8);
this.contents[this.contentsoffset++] = (byte) typeindex;
if (annotation instanceof normalannotation) {
normalannotation normalannotation = (normalannotation) annotation;
membervaluepair[] membervaluepairs = normalannotation.membervaluepairs;
if (membervaluepairs != null) {
final int membervaluepairslength = membervaluepairs.length;
this.contents[this.contentsoffset++] = (byte) (membervaluepairslength >> 8);
this.contents[this.contentsoffset++] = (byte) membervaluepairslength;
for (int i = 0; i < membervaluepairslength; i++) {
membervaluepair membervaluepair = membervaluepairs[i];
if (this.contentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
final int elementnameindex = this.constantpool.literalindex(membervaluepair.name);
this.contents[this.contentsoffset++] = (byte) (elementnameindex >> 8);
this.contents[this.contentsoffset++] = (byte) elementnameindex;
methodbinding methodbinding = membervaluepair.binding;
if (methodbinding == null) {
this.contentsoffset = startingcontentsoffset;
} else {
try {
generateelementvalue(membervaluepair.value, methodbinding.returntype, startingcontentsoffset);
} catch(classcastexception e) {
this.contentsoffset = startingcontentsoffset;
} catch(shouldnotimplement e) {
this.contentsoffset = startingcontentsoffset;
}
}
}
} else {
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
}
} else if (annotation instanceof singlememberannotation) {
singlememberannotation singlememberannotation = (singlememberannotation) annotation;
// this is a single member annotation (one member value)
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 1;
if (this.contentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
final int elementnameindex = this.constantpool.literalindex(value);
this.contents[this.contentsoffset++] = (byte) (elementnameindex >> 8);
this.contents[this.contentsoffset++] = (byte) elementnameindex;
methodbinding methodbinding = singlememberannotation.membervaluepairs()[0].binding;
if (methodbinding == null) {
this.contentsoffset = startingcontentsoffset;
} else {
try {
generateelementvalue(singlememberannotation.membervalue, methodbinding.returntype, startingcontentsoffset);
} catch(classcastexception e) {
this.contentsoffset = startingcontentsoffset;
} catch(shouldnotimplement e) {
this.contentsoffset = startingcontentsoffset;
}
}
} else {
// this is a marker annotation (no member value pairs)
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
}
}

/**
* internal use-only
* that method generates the header of a code attribute.
* - the index inside the constant pool for the attribute name ("code")
* - leave some space for attribute_length(4), max_stack(2), max_locals(2), code_length(4).
*/
public void generatecodeattributeheader() {
if (this.contentsoffset + 20 >= this.contents.length) {
resizecontents(20);
}
int constantvaluenameindex =
this.constantpool.literalindex(attributenamesconstants.codename);
this.contents[this.contentsoffset++] = (byte) (constantvaluenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) constantvaluenameindex;
// leave space for attribute_length(4), max_stack(2), max_locals(2), code_length(4)
this.contentsoffset += 12;
}

private void generateelementvalue(
expression defaultvalue,
typebinding membervaluepairreturntype,
int attributeoffset) {
constant constant = defaultvalue.constant;
typebinding defaultvaluebinding = defaultvalue.resolvedtype;
if (defaultvaluebinding == null) {
this.contentsoffset = attributeoffset;
} else {
if (membervaluepairreturntype.isarraytype() && !defaultvaluebinding.isarraytype()) {
// automatic wrapping
if (this.contentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
this.contents[this.contentsoffset++] = (byte) '[';
this.contents[this.contentsoffset++] = (byte) 0;
this.contents[this.contentsoffset++] = (byte) 1;
}
if (constant != null && constant != constant.notaconstant) {
generateelementvalue(attributeoffset, defaultvalue, constant, membervaluepairreturntype.leafcomponenttype());
} else {
generateelementvaluefornonconstantexpression(defaultvalue, attributeoffset, defaultvaluebinding);
}
}
}

/**
* @@param attributeoffset
*/
private void generateelementvalue(int attributeoffset, expression defaultvalue, constant constant, typebinding binding) {
if (this.contentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
switch (binding.id) {
case t_boolean :
this.contents[this.contentsoffset++] = (byte) 'z';
int booleanvalueindex =
this.constantpool.literalindex(constant.booleanvalue() ? 1 : 0);
this.contents[this.contentsoffset++] = (byte) (booleanvalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) booleanvalueindex;
break;
case t_byte :
this.contents[this.contentsoffset++] = (byte) 'b';
int integervalueindex =
this.constantpool.literalindex(constant.intvalue());
this.contents[this.contentsoffset++] = (byte) (integervalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) integervalueindex;
break;
case t_char :
this.contents[this.contentsoffset++] = (byte) 'c';
integervalueindex =
this.constantpool.literalindex(constant.intvalue());
this.contents[this.contentsoffset++] = (byte) (integervalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) integervalueindex;
break;
case t_int :
this.contents[this.contentsoffset++] = (byte) 'i';
integervalueindex =
this.constantpool.literalindex(constant.intvalue());
this.contents[this.contentsoffset++] = (byte) (integervalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) integervalueindex;
break;
case t_short :
this.contents[this.contentsoffset++] = (byte) 's';
integervalueindex =
this.constantpool.literalindex(constant.intvalue());
this.contents[this.contentsoffset++] = (byte) (integervalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) integervalueindex;
break;
case t_float :
this.contents[this.contentsoffset++] = (byte) 'f';
int floatvalueindex =
this.constantpool.literalindex(constant.floatvalue());
this.contents[this.contentsoffset++] = (byte) (floatvalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) floatvalueindex;
break;
case t_double :
this.contents[this.contentsoffset++] = (byte) 'd';
int doublevalueindex =
this.constantpool.literalindex(constant.doublevalue());
this.contents[this.contentsoffset++] = (byte) (doublevalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) doublevalueindex;
break;
case t_long :
this.contents[this.contentsoffset++] = (byte) 'j';
int longvalueindex =
this.constantpool.literalindex(constant.longvalue());
this.contents[this.contentsoffset++] = (byte) (longvalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) longvalueindex;
break;
case t_javalangstring :
this.contents[this.contentsoffset++] = (byte) 's';
int stringvalueindex =
this.constantpool.literalindex(((stringconstant) constant).stringvalue().tochararray());
if (stringvalueindex == -1) {
if (!this.creatingproblemtype) {
// report an error and abort: will lead to a problem type classfile creation
typedeclaration typedeclaration = this.referencebinding.scope.referencecontext;
typedeclaration.scope.problemreporter().stringconstantisexceedingutf8limit(defaultvalue);
} else {
// already inside a problem type creation : no attribute
this.contentsoffset = attributeoffset;
}
} else {
this.contents[this.contentsoffset++] = (byte) (stringvalueindex >> 8);
this.contents[this.contentsoffset++] = (byte) stringvalueindex;
}
}
}

private void generateelementvaluefornonconstantexpression(expression defaultvalue, int attributeoffset, typebinding defaultvaluebinding) {
if (defaultvaluebinding != null) {
if (defaultvaluebinding.isenum()) {
if (this.contentsoffset + 5 >= this.contents.length) {
resizecontents(5);
}
this.contents[this.contentsoffset++] = (byte) 'e';
fieldbinding fieldbinding = null;
if (defaultvalue instanceof qualifiednamereference) {
qualifiednamereference namereference = (qualifiednamereference) defaultvalue;
fieldbinding = (fieldbinding) namereference.binding;
} else if (defaultvalue instanceof singlenamereference) {
singlenamereference namereference = (singlenamereference) defaultvalue;
fieldbinding = (fieldbinding) namereference.binding;
} else {
this.contentsoffset = attributeoffset;
}
if (fieldbinding != null) {
final int enumconstanttypenameindex = this.constantpool.literalindex(fieldbinding.type.signature());
final int enumconstantnameindex = this.constantpool.literalindex(fieldbinding.name);
this.contents[this.contentsoffset++] = (byte) (enumconstanttypenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) enumconstanttypenameindex;
this.contents[this.contentsoffset++] = (byte) (enumconstantnameindex >> 8);
this.contents[this.contentsoffset++] = (byte) enumconstantnameindex;
}
} else if (defaultvaluebinding.isannotationtype()) {
if (this.contentsoffset + 1 >= this.contents.length) {
resizecontents(1);
}
this.contents[this.contentsoffset++] = (byte) '@@';
generateannotation((annotation) defaultvalue, attributeoffset);
} else if (defaultvaluebinding.isarraytype()) {
// array type
if (this.contentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
this.contents[this.contentsoffset++] = (byte) '[';
if (defaultvalue instanceof arrayinitializer) {
arrayinitializer arrayinitializer = (arrayinitializer) defaultvalue;
int arraylength = arrayinitializer.expressions != null ? arrayinitializer.expressions.length : 0;
this.contents[this.contentsoffset++] = (byte) (arraylength >> 8);
this.contents[this.contentsoffset++] = (byte) arraylength;
for (int i = 0; i < arraylength; i++) {
generateelementvalue(arrayinitializer.expressions[i], defaultvaluebinding.leafcomponenttype(), attributeoffset);
}
} else {
this.contentsoffset = attributeoffset;
}
} else {
// class type
if (this.contentsoffset + 3 >= this.contents.length) {
resizecontents(3);
}
this.contents[this.contentsoffset++] = (byte) 'c';
if (defaultvalue instanceof classliteralaccess) {
classliteralaccess classliteralaccess = (classliteralaccess) defaultvalue;
final int classinfoindex = this.constantpool.literalindex(classliteralaccess.targettype.signature());
this.contents[this.contentsoffset++] = (byte) (classinfoindex >> 8);
this.contents[this.contentsoffset++] = (byte) classinfoindex;
} else {
this.contentsoffset = attributeoffset;
}
}
} else {
this.contentsoffset = attributeoffset;
}
}

/**
* internal use-only
* that method generates the attributes of a code attribute.
* they could be:
* - an exception attribute for each try/catch found inside the method
* - a deprecated attribute
* - a synthetic attribute for synthetic access methods
*
* it returns the number of attributes created for the code attribute.
*
* @@param methodbinding org.eclipse.jdt.internal.compiler.lookup.methodbinding
* @@return <code>int</code>
*/
public int generatemethodinfoattribute(methodbinding methodbinding) {
// leave two bytes for the attribute_number
this.contentsoffset += 2;
if (this.contentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
// now we can handle all the attribute for that method info:
// it could be:
// - a codeattribute
// - a exceptionattribute
// - a deprecatedattribute
// - a syntheticattribute

// exception attribute
referencebinding[] thrownsexceptions;
int attributenumber = 0;
if ((thrownsexceptions = methodbinding.thrownexceptions) != binding.no_exceptions) {
// the method has a throw clause. so we need to add an exception attribute
// check that there is enough space to write all the bytes for the exception attribute
int length = thrownsexceptions.length;
int exsize = 8 + length * 2;
if (exsize + this.contentsoffset >= this.contents.length) {
resizecontents(exsize);
}
int exceptionnameindex =
this.constantpool.literalindex(attributenamesconstants.exceptionsname);
this.contents[this.contentsoffset++] = (byte) (exceptionnameindex >> 8);
this.contents[this.contentsoffset++] = (byte) exceptionnameindex;
// the attribute length = length * 2 + 2 in case of a exception attribute
int attributelength = length * 2 + 2;
this.contents[this.contentsoffset++] = (byte) (attributelength >> 24);
this.contents[this.contentsoffset++] = (byte) (attributelength >> 16);
this.contents[this.contentsoffset++] = (byte) (attributelength >> 8);
this.contents[this.contentsoffset++] = (byte) attributelength;
this.contents[this.contentsoffset++] = (byte) (length >> 8);
this.contents[this.contentsoffset++] = (byte) length;
for (int i = 0; i < length; i++) {
int exceptionindex = this.constantpool.literalindexfortype(thrownsexceptions[i]);
this.contents[this.contentsoffset++] = (byte) (exceptionindex >> 8);
this.contents[this.contentsoffset++] = (byte) exceptionindex;
}
attributenumber++;
}
if (methodbinding.isdeprecated()) {
// deprecated attribute
// check that there is enough space to write the deprecated attribute
if (this.contentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
int deprecatedattributenameindex =
this.constantpool.literalindex(attributenamesconstants.deprecatedname);
this.contents[this.contentsoffset++] = (byte) (deprecatedattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) deprecatedattributenameindex;
// the length of a deprecated attribute is equals to 0
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;

attributenumber++;
}
if (this.targetjdk < classfileconstants.jdk1_5) {
if (methodbinding.issynthetic()) {
// synthetic attribute
// check that there is enough space to write the deprecated attribute
if (this.contentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
int syntheticattributenameindex =
this.constantpool.literalindex(attributenamesconstants.syntheticname);
this.contents[this.contentsoffset++] = (byte) (syntheticattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) syntheticattributenameindex;
// the length of a synthetic attribute is equals to 0
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;

attributenumber++;
}
if (methodbinding.isvarargs()) {
/*
* handle of the target jsr14 for varargs in the source
* varargs attribute
* check that there is enough space to write the deprecated attribute
*/
if (this.contentsoffset + 6 >= this.contents.length) {
resizecontents(6);
}
int varargsattributenameindex =
this.constantpool.literalindex(attributenamesconstants.varargsname);
this.contents[this.contentsoffset++] = (byte) (varargsattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) varargsattributenameindex;
// the length of a varargs attribute is equals to 0
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;

attributenumber++;
}
}
// add signature attribute
char[] genericsignature = methodbinding.genericsignature();
if (genericsignature != null) {
// check that there is enough space to write all the bytes for the field info corresponding
// to the @@fieldbinding
if (this.contentsoffset + 8 >= this.contents.length) {
resizecontents(8);
}
int signatureattributenameindex =
this.constantpool.literalindex(attributenamesconstants.signaturename);
this.contents[this.contentsoffset++] = (byte) (signatureattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) signatureattributenameindex;
// the length of a signature attribute is equals to 2
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 2;
int signatureindex =
this.constantpool.literalindex(genericsignature);
this.contents[this.contentsoffset++] = (byte) (signatureindex >> 8);
this.contents[this.contentsoffset++] = (byte) signatureindex;
attributenumber++;
}
if (this.targetjdk >= classfileconstants.jdk1_4) {
abstractmethoddeclaration methoddeclaration = methodbinding.sourcemethod();
if (methoddeclaration != null) {
annotation[] annotations = methoddeclaration.annotations;
if (annotations != null) {
attributenumber += generateruntimeannotations(annotations);
}
if ((methodbinding.tagbits & tagbits.hasparameterannotations) != 0) {
argument[] arguments = methoddeclaration.arguments;
if (arguments != null) {
attributenumber += generateruntimeannotationsforparameters(arguments);
}
}
}
}
if ((methodbinding.tagbits & tagbits.hasmissingtype) != 0) {
this.missingtypes = methodbinding.collectmissingtypes(this.missingtypes);
}
return attributenumber;
}

public int generatemethodinfoattribute(methodbinding methodbinding, annotationmethoddeclaration declaration) {
int attributesnumber = generatemethodinfoattribute(methodbinding);
int attributeoffset = this.contentsoffset;
if ((declaration.modifiers & classfileconstants.accannotationdefault) != 0) {
// add an annotation default attribute
int annotationdefaultnameindex =
this.constantpool.literalindex(attributenamesconstants.annotationdefaultname);
this.contents[this.contentsoffset++] = (byte) (annotationdefaultnameindex >> 8);
this.contents[this.contentsoffset++] = (byte) annotationdefaultnameindex;
int attributelengthoffset = this.contentsoffset;
this.contentsoffset += 4;
if (this.contentsoffset + 4 >= this.contents.length) {
resizecontents(4);
}
generateelementvalue(declaration.defaultvalue, declaration.binding.returntype, attributeoffset);
if (this.contentsoffset != attributeoffset) {
int attributelength = this.contentsoffset - attributelengthoffset - 4;
this.contents[attributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[attributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[attributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[attributelengthoffset++] = (byte) attributelength;
attributesnumber++;
}
}
return attributesnumber;
}
/**
* internal use-only
* that method generates the header of a method info:
* the header consists in:
* - the access flags
* - the name index of the method name inside the constant pool
* - the descriptor index of the signature of the method inside the constant pool.
*
* @@param methodbinding org.eclipse.jdt.internal.compiler.lookup.methodbinding
*/
public void generatemethodinfoheader(methodbinding methodbinding) {
generatemethodinfoheader(methodbinding, methodbinding.modifiers);
}
/**
* internal use-only
* that method generates the header of a method info:
* the header consists in:
* - the access flags
* - the name index of the method name inside the constant pool
* - the descriptor index of the signature of the method inside the constant pool.
*
* @@param methodbinding org.eclipse.jdt.internal.compiler.lookup.methodbinding
* @@param accessflags the access flags
*/
public void generatemethodinfoheader(methodbinding methodbinding, int accessflags) {
// check that there is enough space to write all the bytes for the method info corresponding
// to the @@methodbinding
this.methodcount++; // add one more method
if (this.contentsoffset + 10 >= this.contents.length) {
resizecontents(10);
}
if (this.targetjdk < classfileconstants.jdk1_5) {
// pre 1.5, synthetic is an attribute, not a modifier
// pre 1.5, varargs is an attribute, not a modifier (-target jsr14 mode)
accessflags &= ~(classfileconstants.accsynthetic | classfileconstants.accvarargs);
}
if ((methodbinding.tagbits & tagbits.clearprivatemodifier) != 0) {
accessflags &= ~classfileconstants.accprivate;
}
this.contents[this.contentsoffset++] = (byte) (accessflags >> 8);
this.contents[this.contentsoffset++] = (byte) accessflags;
int nameindex = this.constantpool.literalindex(methodbinding.selector);
this.contents[this.contentsoffset++] = (byte) (nameindex >> 8);
this.contents[this.contentsoffset++] = (byte) nameindex;
int descriptorindex = this.constantpool.literalindex(methodbinding.signature(this));
this.contents[this.contentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[this.contentsoffset++] = (byte) descriptorindex;
}

/**
* internal use-only
* that method generates the method info header of a clinit:
* the header consists in:
* - the access flags (always default access + static)
* - the name index of the method name (always <clinit>) inside the constant pool
* - the descriptor index of the signature (always ()v) of the method inside the constant pool.
*/
public void generatemethodinfoheaderforclinit() {
// check that there is enough space to write all the bytes for the method info corresponding
// to the @@methodbinding
this.methodcount++; // add one more method
if (this.contentsoffset + 10 >= this.contents.length) {
resizecontents(10);
}
this.contents[this.contentsoffset++] = (byte) ((classfileconstants.accdefault | classfileconstants.accstatic) >> 8);
this.contents[this.contentsoffset++] = (byte) (classfileconstants.accdefault | classfileconstants.accstatic);
int nameindex = this.constantpool.literalindex(constantpool.clinit);
this.contents[this.contentsoffset++] = (byte) (nameindex >> 8);
this.contents[this.contentsoffset++] = (byte) nameindex;
int descriptorindex =
this.constantpool.literalindex(constantpool.clinitsignature);
this.contents[this.contentsoffset++] = (byte) (descriptorindex >> 8);
this.contents[this.contentsoffset++] = (byte) descriptorindex;
// we know that we won't get more than 1 attribute: the code attribute
this.contents[this.contentsoffset++] = 0;
this.contents[this.contentsoffset++] = 1;
}

/**
* internal use-only
* generate the byte for problem method infos that correspond to missing abstract methods.
* http://dev.eclipse.org/bugs/show_bug.cgi?id=3179
*
* @@param methoddeclarations array of all missing abstract methods
*/
public void generatemissingabstractmethods(methoddeclaration[] methoddeclarations, compilationresult compilationresult) {
if (methoddeclarations != null) {
typedeclaration currentdeclaration = this.referencebinding.scope.referencecontext;
int typedeclarationsourcestart = currentdeclaration.sourcestart();
int typedeclarationsourceend = currentdeclaration.sourceend();
for (int i = 0, max = methoddeclarations.length; i < max; i++) {
methoddeclaration methoddeclaration = methoddeclarations[i];
methodbinding methodbinding = methoddeclaration.binding;
string readablename = new string(methodbinding.readablename());
categorizedproblem[] problems = compilationresult.problems;
int problemscount = compilationresult.problemcount;
for (int j = 0; j < problemscount; j++) {
categorizedproblem problem = problems[j];
if (problem != null
&& problem.getid() == iproblem.abstractmethodmustbeimplemented
&& problem.getmessage().indexof(readablename) != -1
&& problem.getsourcestart() >= typedeclarationsourcestart
&& problem.getsourceend() <= typedeclarationsourceend) {
// we found a match
addmissingabstractproblemmethod(methoddeclaration, methodbinding, problem, compilationresult);
}
}
}
}
}

private void generatemissingtypesattribute() {
int initialsize = this.missingtypes.size();
int[] missingtypesindexes = new int[initialsize];
int numberofmissingtypes = 0;
if (initialsize > 1) {
collections.sort(this.missingtypes, new comparator() {
public int compare(object o1, object o2) {
typebinding typebinding1 = (typebinding) o1;
typebinding typebinding2 = (typebinding) o2;
return charoperation.compareto(typebinding1.constantpoolname(), typebinding2.constantpoolname());
}
});
}
int previousindex = 0;
next: for (int i = 0; i < initialsize; i++) {
int missingtypeindex = this.constantpool.literalindexfortype((typebinding) this.missingtypes.get(i));
if (previousindex == missingtypeindex) {
continue next;
}
previousindex = missingtypeindex;
missingtypesindexes[numberofmissingtypes++] = missingtypeindex;
}
// we don't need to resize as we interate from 0 to numberofmissingtypes when recording the indexes in the .class file
int attributelength = numberofmissingtypes * 2 + 2;
if (this.contentsoffset + attributelength + 6 >= this.contents.length) {
resizecontents(attributelength + 6);
}
int missingtypesnameindex = this.constantpool.literalindex(attributenamesconstants.missingtypesname);
this.contents[this.contentsoffset++] = (byte) (missingtypesnameindex >> 8);
this.contents[this.contentsoffset++] = (byte) missingtypesnameindex;

// generate attribute length
this.contents[this.contentsoffset++] = (byte) (attributelength >> 24);
this.contents[this.contentsoffset++] = (byte) (attributelength >> 16);
this.contents[this.contentsoffset++] = (byte) (attributelength >> 8);
this.contents[this.contentsoffset++] = (byte) attributelength;

// generate number of missing types
this.contents[this.contentsoffset++] = (byte) (numberofmissingtypes >> 8);
this.contents[this.contentsoffset++] = (byte) numberofmissingtypes;
// generate entry for each missing type
for (int i = 0; i < numberofmissingtypes; i++) {
int missingtypeindex = missingtypesindexes[i];
this.contents[this.contentsoffset++] = (byte) (missingtypeindex >> 8);
this.contents[this.contentsoffset++] = (byte) missingtypeindex;
}
}

/**
* @@param annotations
* @@return the number of attributes created while dumping the annotations in the .class file
*/
private int generateruntimeannotations(final annotation[] annotations) {
int attributesnumber = 0;
final int length = annotations.length;
int visibleannotationscounter = 0;
int invisibleannotationscounter = 0;

for (int i = 0; i < length; i++) {
annotation annotation = annotations[i];
if (isruntimeinvisible(annotation)) {
invisibleannotationscounter++;
} else if (isruntimevisible(annotation)) {
visibleannotationscounter++;
}
}

int annotationattributeoffset = this.contentsoffset;
int constantpoffset = this.constantpool.currentoffset;
int constantpoolindex = this.constantpool.currentindex;
if (invisibleannotationscounter != 0) {
if (this.contentsoffset + 10 >= this.contents.length) {
resizecontents(10);
}
int runtimeinvisibleannotationsattributenameindex =
this.constantpool.literalindex(attributenamesconstants.runtimeinvisibleannotationsname);
this.contents[this.contentsoffset++] = (byte) (runtimeinvisibleannotationsattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) runtimeinvisibleannotationsattributenameindex;
int attributelengthoffset = this.contentsoffset;
this.contentsoffset += 4; // leave space for the attribute length

int annotationslengthoffset = this.contentsoffset;
this.contentsoffset += 2; // leave space for the annotations length

int counter = 0;
loop: for (int i = 0; i < length; i++) {
if (invisibleannotationscounter == 0) break loop;
annotation annotation = annotations[i];
if (isruntimeinvisible(annotation)) {
int currentannotationoffset = this.contentsoffset;
generateannotation(annotation, currentannotationoffset);
invisibleannotationscounter--;
if (this.contentsoffset != currentannotationoffset) {
counter++;
}
}
}
if (counter != 0) {
this.contents[annotationslengthoffset++] = (byte) (counter >> 8);
this.contents[annotationslengthoffset++] = (byte) counter;

int attributelength = this.contentsoffset - attributelengthoffset - 4;
this.contents[attributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[attributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[attributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[attributelengthoffset++] = (byte) attributelength;
attributesnumber++;
} else {
this.contentsoffset = annotationattributeoffset;
// reset the constant pool to its state before the clinit
this.constantpool.resetforattributename(attributenamesconstants.runtimeinvisibleannotationsname, constantpoolindex, constantpoffset);
}
}

annotationattributeoffset = this.contentsoffset;
constantpoffset = this.constantpool.currentoffset;
constantpoolindex = this.constantpool.currentindex;
if (visibleannotationscounter != 0) {
if (this.contentsoffset + 10 >= this.contents.length) {
resizecontents(10);
}
int runtimevisibleannotationsattributenameindex =
this.constantpool.literalindex(attributenamesconstants.runtimevisibleannotationsname);
this.contents[this.contentsoffset++] = (byte) (runtimevisibleannotationsattributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) runtimevisibleannotationsattributenameindex;
int attributelengthoffset = this.contentsoffset;
this.contentsoffset += 4; // leave space for the attribute length

int annotationslengthoffset = this.contentsoffset;
this.contentsoffset += 2; // leave space for the annotations length

int counter = 0;
loop: for (int i = 0; i < length; i++) {
if (visibleannotationscounter == 0) break loop;
annotation annotation = annotations[i];
if (isruntimevisible(annotation)) {
visibleannotationscounter--;
int currentannotationoffset = this.contentsoffset;
generateannotation(annotation, currentannotationoffset);
if (this.contentsoffset != currentannotationoffset) {
counter++;
}
}
}
if (counter != 0) {
this.contents[annotationslengthoffset++] = (byte) (counter >> 8);
this.contents[annotationslengthoffset++] = (byte) counter;

int attributelength = this.contentsoffset - attributelengthoffset - 4;
this.contents[attributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[attributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[attributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[attributelengthoffset++] = (byte) attributelength;
attributesnumber++;
} else {
this.contentsoffset = annotationattributeoffset;
this.constantpool.resetforattributename(attributenamesconstants.runtimevisibleannotationsname, constantpoolindex, constantpoffset);
}
}
return attributesnumber;
}

private int generateruntimeannotationsforparameters(argument[] arguments) {
final int argumentslength = arguments.length;
final int visible_index = 0;
final int invisible_index = 1;
int invisibleparametersannotationscounter = 0;
int visibleparametersannotationscounter = 0;
int[][] annotationscounters = new int[argumentslength][2];
for (int i = 0; i < argumentslength; i++) {
argument argument = arguments[i];
annotation[] annotations = argument.annotations;
if (annotations != null) {
for (int j = 0, max2 = annotations.length; j < max2; j++) {
annotation annotation = annotations[j];
if (isruntimeinvisible(annotation)) {
annotationscounters[i][invisible_index]++;
invisibleparametersannotationscounter++;
} else if (isruntimevisible(annotation)) {
annotationscounters[i][visible_index]++;
visibleparametersannotationscounter++;
}
}
}
}
int attributesnumber = 0;
int annotationattributeoffset = this.contentsoffset;
if (invisibleparametersannotationscounter != 0) {
int globalcounter = 0;
if (this.contentsoffset + 7 >= this.contents.length) {
resizecontents(7);
}
int attributenameindex =
this.constantpool.literalindex(attributenamesconstants.runtimeinvisibleparameterannotationsname);
this.contents[this.contentsoffset++] = (byte) (attributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) attributenameindex;
int attributelengthoffset = this.contentsoffset;
this.contentsoffset += 4; // leave space for the attribute length

this.contents[this.contentsoffset++] = (byte) argumentslength;
for (int i = 0; i < argumentslength; i++) {
if (this.contentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
if (invisibleparametersannotationscounter == 0) {
this.contents[this.contentsoffset++] = (byte) 0;
this.contents[this.contentsoffset++] = (byte) 0;
} else {
final int numberofinvisibleannotations = annotationscounters[i][invisible_index];
int invisibleannotationsoffset = this.contentsoffset;
// leave space for number of annotations
this.contentsoffset += 2;
int counter = 0;
if (numberofinvisibleannotations != 0) {
argument argument = arguments[i];
annotation[] annotations = argument.annotations;
for (int j = 0, max = annotations.length; j < max; j++) {
annotation annotation = annotations[j];
if (isruntimeinvisible(annotation)) {
int currentannotationoffset = this.contentsoffset;
generateannotation(annotation, currentannotationoffset);
if (this.contentsoffset != currentannotationoffset) {
counter++;
globalcounter++;
}
invisibleparametersannotationscounter--;
}
}
}
this.contents[invisibleannotationsoffset++] = (byte) (counter >> 8);
this.contents[invisibleannotationsoffset] = (byte) counter;
}
}
if (globalcounter != 0) {
int attributelength = this.contentsoffset - attributelengthoffset - 4;
this.contents[attributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[attributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[attributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[attributelengthoffset++] = (byte) attributelength;
attributesnumber++;
} else {
// if globalcounter is 0, this means that the code generation for all visible annotations failed
this.contentsoffset = annotationattributeoffset;
}
}
if (visibleparametersannotationscounter != 0) {
int globalcounter = 0;
if (this.contentsoffset + 7 >= this.contents.length) {
resizecontents(7);
}
int attributenameindex =
this.constantpool.literalindex(attributenamesconstants.runtimevisibleparameterannotationsname);
this.contents[this.contentsoffset++] = (byte) (attributenameindex >> 8);
this.contents[this.contentsoffset++] = (byte) attributenameindex;
int attributelengthoffset = this.contentsoffset;
this.contentsoffset += 4; // leave space for the attribute length

this.contents[this.contentsoffset++] = (byte) argumentslength;
for (int i = 0; i < argumentslength; i++) {
if (this.contentsoffset + 2 >= this.contents.length) {
resizecontents(2);
}
if (visibleparametersannotationscounter == 0) {
this.contents[this.contentsoffset++] = (byte) 0;
this.contents[this.contentsoffset++] = (byte) 0;
} else {
final int numberofvisibleannotations = annotationscounters[i][visible_index];
int visibleannotationsoffset = this.contentsoffset;
// leave space for number of annotations
this.contentsoffset += 2;
int counter = 0;
if (numberofvisibleannotations != 0) {
argument argument = arguments[i];
annotation[] annotations = argument.annotations;
for (int j = 0, max = annotations.length; j < max; j++) {
annotation annotation = annotations[j];
if (isruntimevisible(annotation)) {
int currentannotationoffset = this.contentsoffset;
generateannotation(annotation, currentannotationoffset);
if (this.contentsoffset != currentannotationoffset) {
counter++;
globalcounter++;
}
visibleparametersannotationscounter--;
}
}
}
this.contents[visibleannotationsoffset++] = (byte) (counter >> 8);
this.contents[visibleannotationsoffset] = (byte) counter;
}
}
if (globalcounter != 0) {
int attributelength = this.contentsoffset - attributelengthoffset - 4;
this.contents[attributelengthoffset++] = (byte) (attributelength >> 24);
this.contents[attributelengthoffset++] = (byte) (attributelength >> 16);
this.contents[attributelengthoffset++] = (byte) (attributelength >> 8);
this.contents[attributelengthoffset++] = (byte) attributelength;
attributesnumber++;
} else {
// if globalcounter is 0, this means that the code generation for all visible annotations failed
this.contentsoffset = annotationattributeoffset;
}
}
return attributesnumber;
}

/**
* external api
* answer the actual bytes of the class file
*
* this method encodes the receiver structure into a byte array which is the content of the classfile.
* returns the byte array that represents the encoded structure of the receiver.
*
* @@return byte[]
*/
public byte[] getbytes() {
if (this.bytes == null) {
this.bytes = new byte[this.headeroffset + this.contentsoffset];
system.arraycopy(this.header, 0, this.bytes, 0, this.headeroffset);
system.arraycopy(this.contents, 0, this.bytes, this.headeroffset, this.contentsoffset);
}
return this.bytes;
}
/**
* external api
* answer the compound name of the class file.
* @@return char[][]
* e.g. {{java}, {util}, {hashtable}}.
*/
public char[][] getcompoundname() {
return charoperation.spliton('/', filename());
}

private int getparameterscount(char[] methodsignature) {
int i = charoperation.indexof('(', methodsignature);
i++;
char currentcharacter = methodsignature[i];
if (currentcharacter == ')') {
return 0;
}
int result = 0;
while (true) {
currentcharacter = methodsignature[i];
if (currentcharacter == ')') {
return result;
}
switch (currentcharacter) {
case '[':
// array type
int scantype = scantype(methodsignature, i + 1);
result++;
i = scantype + 1;
break;
case 'l':
scantype = charoperation.indexof(';', methodsignature,
i + 1);
result++;
i = scantype + 1;
break;
case 'z':
case 'b':
case 'c':
case 'd':
case 'f':
case 'i':
case 'j':
case 's':
result++;
i++;
break;
default:
throw new illegalargumentexception();
}
}
}

private char[] getreturntype(char[] methodsignature) {
// skip type parameters
int paren = charoperation.lastindexof(')', methodsignature);
// there could be thrown exceptions behind, thus scan one type exactly
return charoperation.subarray(methodsignature, paren + 1,
methodsignature.length);
}


private final int i4at(byte[] reference, int relativeoffset,
int structoffset) {
int position = relativeoffset + structoffset;
return ((reference[position++] & 0xff) << 24)
+ ((reference[position++] & 0xff) << 16)
+ ((reference[position++] & 0xff) << 8)
+ (reference[position] & 0xff);
}

protected void initbytearrays() {
int members = this.referencebinding.methods().length + this.referencebinding.fields().length;
this.header = new byte[initial_header_size];
this.contents = new byte[members < 15 ? initial_contents_size : initial_header_size];
}

public void initialize(sourcetypebinding atype, classfile parentclassfile, boolean createproblemtype) {
// generate the magic numbers inside the header
this.header[this.headeroffset++] = (byte) (0xcafebabel >> 24);
this.header[this.headeroffset++] = (byte) (0xcafebabel >> 16);
this.header[this.headeroffset++] = (byte) (0xcafebabel >> 8);
this.header[this.headeroffset++] = (byte) (0xcafebabel >> 0);

long targetversion = this.targetjdk;
this.header[this.headeroffset++] = (byte) (targetversion >> 8); // minor high
this.header[this.headeroffset++] = (byte) (targetversion>> 0); // minor low
this.header[this.headeroffset++] = (byte) (targetversion >> 24); // major high
this.header[this.headeroffset++] = (byte) (targetversion >> 16); // major low

this.constantpooloffset = this.headeroffset;
this.headeroffset += 2;
this.constantpool.initialize(this);

// modifier manipulations for classfile
int accessflags = atype.getaccessflags();
if (atype.isprivate()) { // rewrite private to non-public
accessflags &= ~classfileconstants.accpublic;
}
if (atype.isprotected()) { // rewrite protected into public
accessflags |= classfileconstants.accpublic;
}
// clear all bits that are illegal for a class or an interface
accessflags
&= ~(
classfileconstants.accstrictfp
| classfileconstants.accprotected
| classfileconstants.accprivate
| classfileconstants.accstatic
| classfileconstants.accsynchronized
| classfileconstants.accnative);

// set the accsuper flag (has to be done after clearing accsynchronized - since same value)
if (!atype.isinterface()) { // class or enum
accessflags |= classfileconstants.accsuper;
}
if (atype.isanonymoustype()) {
accessflags &= ~classfileconstants.accfinal;
}
this.enclosingclassfile = parentclassfile;
// innerclasses get their names computed at code gen time

// now we continue to generate the bytes inside the contents array
this.contents[this.contentsoffset++] = (byte) (accessflags >> 8);
this.contents[this.contentsoffset++] = (byte) accessflags;
int classnameindex = this.constantpool.literalindexfortype(atype);
this.contents[this.contentsoffset++] = (byte) (classnameindex >> 8);
this.contents[this.contentsoffset++] = (byte) classnameindex;
int superclassnameindex;
if (atype.isinterface()) {
superclassnameindex = this.constantpool.literalindexfortype(constantpool.javalangobjectconstantpoolname);
} else {
superclassnameindex =
(atype.superclass == null ? 0 : this.constantpool.literalindexfortype(atype.superclass));
}
this.contents[this.contentsoffset++] = (byte) (superclassnameindex >> 8);
this.contents[this.contentsoffset++] = (byte) superclassnameindex;
referencebinding[] superinterfacesbinding = atype.superinterfaces();
int interfacescount = superinterfacesbinding.length;
this.contents[this.contentsoffset++] = (byte) (interfacescount >> 8);
this.contents[this.contentsoffset++] = (byte) interfacescount;
for (int i = 0; i < interfacescount; i++) {
int interfaceindex = this.constantpool.literalindexfortype(superinterfacesbinding[i]);
this.contents[this.contentsoffset++] = (byte) (interfaceindex >> 8);
this.contents[this.contentsoffset++] = (byte) interfaceindex;
}
this.creatingproblemtype = createproblemtype;

// retrieve the enclosing one guaranteed to be the one matching the propagated flow info
// 1ff9zbu: lfcom:all - local variable attributes busted (sanity check)
this.codestream.maxfieldcount = atype.scope.outermostclassscope().referencetype().maxfieldcount;
}

private void initializedefaultlocals(stackmapframe frame,
methodbinding methodbinding,
int maxlocals,
int codelength) {
if (maxlocals != 0) {
int resolvedposition = 0;
// take into account enum constructor synthetic name+ordinal
final boolean isconstructor = methodbinding.isconstructor();
if (isconstructor) {
localvariablebinding localvariablebinding = new localvariablebinding("this".tochararray(), methodbinding.declaringclass, 0, false); //$non-nls-1$
localvariablebinding.resolvedposition = 0;
this.codestream.record(localvariablebinding);
localvariablebinding.recordinitializationstartpc(0);
localvariablebinding.recordinitializationendpc(codelength);
frame.putlocal(resolvedposition, new verificationtypeinfo(
verificationtypeinfo.item_uninitialized_this,
methodbinding.declaringclass));
resolvedposition++;
} else if (!methodbinding.isstatic()) {
localvariablebinding localvariablebinding = new localvariablebinding("this".tochararray(), methodbinding.declaringclass, 0, false); //$non-nls-1$
localvariablebinding.resolvedposition = 0;
this.codestream.record(localvariablebinding);
localvariablebinding.recordinitializationstartpc(0);
localvariablebinding.recordinitializationendpc(codelength);
frame.putlocal(resolvedposition, new verificationtypeinfo(
verificationtypeinfo.item_object,
methodbinding.declaringclass));
resolvedposition++;
}

if (isconstructor) {
if (methodbinding.declaringclass.isenum()) {
localvariablebinding localvariablebinding = new localvariablebinding(" name".tochararray(), this.referencebinding.scope.getjavalangstring(), 0, false); //$non-nls-1$
localvariablebinding.resolvedposition = resolvedposition;
this.codestream.record(localvariablebinding);
localvariablebinding.recordinitializationstartpc(0);
localvariablebinding.recordinitializationendpc(codelength);

frame.putlocal(resolvedposition, new verificationtypeinfo(
typeids.t_javalangstring,
constantpool.javalangstringconstantpoolname));
resolvedposition++;

localvariablebinding = new localvariablebinding(" ordinal".tochararray(), typebinding.int, 0, false); //$non-nls-1$
localvariablebinding.resolvedposition = resolvedposition;
this.codestream.record(localvariablebinding);
localvariablebinding.recordinitializationstartpc(0);
localvariablebinding.recordinitializationendpc(codelength);
frame.putlocal(resolvedposition, new verificationtypeinfo(
typebinding.int));
resolvedposition++;
}

// take into account the synthetic parameters
if (methodbinding.declaringclass.isnestedtype()) {
referencebinding enclosinginstancetypes[];
if ((enclosinginstancetypes = methodbinding.declaringclass.syntheticenclosinginstancetypes()) != null) {
for (int i = 0, max = enclosinginstancetypes.length; i < max; i++) {
// an enclosinginstancetype can only be a reference
// binding. it cannot be
// longbinding or doublebinding
localvariablebinding localvariablebinding = new localvariablebinding((" enclosingtype" + i).tochararray(), enclosinginstancetypes[i], 0, false); //$non-nls-1$
localvariablebinding.resolvedposition = resolvedposition;
this.codestream.record(localvariablebinding);
localvariablebinding.recordinitializationstartpc(0);
localvariablebinding.recordinitializationendpc(codelength);

frame.putlocal(resolvedposition,
new verificationtypeinfo(enclosinginstancetypes[i]));
resolvedposition++;
}
}

typebinding[] arguments;
if ((arguments = methodbinding.parameters) != null) {
for (int i = 0, max = arguments.length; i < max; i++) {
final typebinding typebinding = arguments[i];
frame.putlocal(resolvedposition,
new verificationtypeinfo(typebinding));
switch (typebinding.id) {
case typeids.t_double:
case typeids.t_long:
resolvedposition += 2;
break;
default:
resolvedposition++;
}
}
}

syntheticargumentbinding syntheticarguments[];
if ((syntheticarguments = methodbinding.declaringclass.syntheticouterlocalvariables()) != null) {
for (int i = 0, max = syntheticarguments.length; i < max; i++) {
final typebinding typebinding = syntheticarguments[i].type;
localvariablebinding localvariablebinding = new localvariablebinding((" synthetic" + i).tochararray(), typebinding, 0, false); //$non-nls-1$
localvariablebinding.resolvedposition = resolvedposition;
this.codestream.record(localvariablebinding);
localvariablebinding.recordinitializationstartpc(0);
localvariablebinding.recordinitializationendpc(codelength);

frame.putlocal(resolvedposition,
new verificationtypeinfo(typebinding));
switch (typebinding.id) {
case typeids.t_double:
case typeids.t_long:
resolvedposition += 2;
break;
default:
resolvedposition++;
}
}
}
} else {
typebinding[] arguments;
if ((arguments = methodbinding.parameters) != null) {
for (int i = 0, max = arguments.length; i < max; i++) {
final typebinding typebinding = arguments[i];
frame.putlocal(resolvedposition,
new verificationtypeinfo(typebinding));
switch (typebinding.id) {
case typeids.t_double:
case typeids.t_long:
resolvedposition += 2;
break;
default:
resolvedposition++;
}
}
}
}
} else {
typebinding[] arguments;
if ((arguments = methodbinding.parameters) != null) {
for (int i = 0, max = arguments.length; i < max; i++) {
final typebinding typebinding = arguments[i];
frame.putlocal(resolvedposition,
new verificationtypeinfo(typebinding));
switch (typebinding.id) {
case typeids.t_double:
case typeids.t_long:
resolvedposition += 2;
break;
default:
resolvedposition++;
}
}
}
}
}
}

private void initializelocals(boolean isstatic, int currentpc, stackmapframe currentframe) {
verificationtypeinfo[] locals = currentframe.locals;
int localslength = locals.length;
int i = 0;
if (!isstatic) {
// we don't want to reset the first local if the method is not static
i = 1;
}
for (; i < localslength; i++) {
locals[i] = null;
}
i = 0;
locals: for (int max = this.codestream.alllocalscounter; i < max; i++) {
localvariablebinding localvariable = this.codestream.locals[i];
if (localvariable == null) continue;
int resolvedposition = localvariable.resolvedposition;
final typebinding localvariabletypebinding = localvariable.type;
inits: for (int j = 0; j < localvariable.initializationcount; j++) {
int startpc = localvariable.initializationpcs[j << 1];
int endpc = localvariable.initializationpcs[(j << 1) + 1];
if (currentpc < startpc) {
continue inits;
} else if (currentpc < endpc) {
// the current local is an active local
if (currentframe.locals[resolvedposition] == null) {
currentframe.locals[resolvedposition] =
new verificationtypeinfo(
localvariabletypebinding);
}
continue locals;
}
}
}
}

private boolean isruntimeinvisible(annotation annotation) {
final typebinding annotationbinding = annotation.resolvedtype;
if (annotationbinding == null) {
return false;
}
long metatagbits = annotationbinding.getannotationtagbits(); // could be forward reference
if ((metatagbits & tagbits.annotationretentionmask) == 0)
return true; // by default the retention is class

return (metatagbits & tagbits.annotationretentionmask) == tagbits.annotationclassretention;
}

private boolean isruntimevisible(annotation annotation) {
final typebinding annotationbinding = annotation.resolvedtype;
if (annotationbinding == null) {
return false;
}
long metatagbits = annotationbinding.getannotationtagbits();
if ((metatagbits & tagbits.annotationretentionmask) == 0)
return false; // by default the retention is class

return (metatagbits & tagbits.annotationretentionmask) == tagbits.annotationruntimeretention;
}

/**
* internal use-only
* returns the most enclosing classfile of the receiver. this is used know to store the constant pool name
* for all inner types of the receiver.
* @@return org.eclipse.jdt.internal.compiler.codegen.classfile
*/
public classfile outermostenclosingclassfile() {
classfile current = this;
while (current.enclosingclassfile != null)
current = current.enclosingclassfile;
return current;
}

public void recordinnerclasses(typebinding binding) {
if (this.innerclassesbindings == null) {
this.innerclassesbindings = new hashset(inner_classes_size);
}
referencebinding innerclass = (referencebinding) binding;
this.innerclassesbindings.add(innerclass.erasure());
referencebinding enclosingtype = innerclass.enclosingtype();
while (enclosingtype != null
&& enclosingtype.isnestedtype()) {
this.innerclassesbindings.add(enclosingtype.erasure());
enclosingtype = enclosingtype.enclosingtype();
}
}

public void reset(sourcetypebinding typebinding) {
// the code stream is reinitialized for each method
final compileroptions options = typebinding.scope.compileroptions();
this.referencebinding = typebinding;
this.isnestedtype = typebinding.isnestedtype();
this.targetjdk = options.targetjdk;
this.produceattributes = options.producedebugattributes;
if (this.targetjdk >= classfileconstants.jdk1_6) {
this.produceattributes |= classfileconstants.attr_stack_map_table;
} else if (this.targetjdk == classfileconstants.cldc_1_1) {
this.targetjdk = classfileconstants.jdk1_1; // put back 45.3
this.produceattributes |= classfileconstants.attr_stack_map;
}
this.bytes = null;
this.constantpool.reset();
this.codestream.reset(this);
this.constantpooloffset = 0;
this.contentsoffset = 0;
this.creatingproblemtype = false;
this.enclosingclassfile = null;
this.headeroffset = 0;
this.methodcount = 0;
this.methodcountoffset = 0;
if (this.innerclassesbindings != null) {
this.innerclassesbindings.clear();
}
this.missingtypes = null;
this.visitedtypes = null;
}

/**
* resize the pool contents
*/
private final void resizecontents(int minimalsize) {
int length = this.contents.length;
int toadd = length;
if (toadd < minimalsize)
toadd = minimalsize;
system.arraycopy(this.contents, 0, this.contents = new byte[length + toadd], 0, length);
}

private verificationtypeinfo retrievelocal(int currentpc, int resolvedposition) {
for (int i = 0, max = this.codestream.alllocalscounter; i < max; i++) {
localvariablebinding localvariable = this.codestream.locals[i];
if (localvariable == null) continue;
if (resolvedposition == localvariable.resolvedposition) {
inits: for (int j = 0; j < localvariable.initializationcount; j++) {
int startpc = localvariable.initializationpcs[j << 1];
int endpc = localvariable.initializationpcs[(j << 1) + 1];
if (currentpc < startpc) {
continue inits;
} else if (currentpc < endpc) {
// the current local is an active local
return new verificationtypeinfo(localvariable.type);
}
}
}
}
return null;
}

private int scantype(char[] methodsignature, int index) {
switch (methodsignature[index]) {
case '[':
// array type
return scantype(methodsignature, index + 1);
case 'l':
return charoperation.indexof(';', methodsignature, index + 1);
case 'z':
case 'b':
case 'c':
case 'd':
case 'f':
case 'i':
case 'j':
case 's':
return index;
default:
throw new illegalargumentexception();
}
}

/**
* internal use-only
* this methods leaves the space for method counts recording.
*/
public void setformethodinfos() {
// leave some space for the methodcount
this.methodcountoffset = this.contentsoffset;
this.contentsoffset += 2;
}

public void traverse(methodbinding methodbinding, int maxlocals, byte[] bytecodes, int codeoffset, int codelength, arraylist frames, boolean isclinit) {
stackmapframecodestream stackmapframecodestream = (stackmapframecodestream) this.codestream;
int[] framepositions = stackmapframecodestream.getframepositions();
int pc = codeoffset;
int index;
int[] constantpooloffsets = this.constantpool.offsets;
byte[] poolcontents = this.constantpool.poolcontent;

// set initial values for frame positions
int indexinframepositions = 0;
int framepositionslength = framepositions.length;
int currentframeposition = framepositions[0];

// set initial values for stack depth markers
int indexinstackdepthmarkers = 0;
stackdepthmarker[] stackdepthmarkers = stackmapframecodestream.getstackdepthmarkers();
int stackdepthmarkerslength = stackdepthmarkers == null ? 0 : stackdepthmarkers.length;
boolean hasstackdepthmarkers = stackdepthmarkerslength != 0;
stackdepthmarker stackdepthmarker = null;
if (hasstackdepthmarkers) {
stackdepthmarker = stackdepthmarkers[0];
}

// set initial values for stack markers (used only in cldc mode)
int indexinstackmarkers = 0;
stackmarker[] stackmarkers = stackmapframecodestream.getstackmarkers();
int stackmarkerslength = stackmarkers == null ? 0 : stackmarkers.length;
boolean hasstackmarkers = stackmarkerslength != 0;
stackmarker stackmarker = null;
if (hasstackmarkers) {
stackmarker = stackmarkers[0];
}

// set initial values for exception markers
int indexinexceptionmarkers = 0;
exceptionmarker[] exceptionmarkers= stackmapframecodestream.getexceptionmarkers();
int exceptionsmarkerslength = exceptionmarkers == null ? 0 : exceptionmarkers.length;
boolean hasexceptionmarkers = exceptionsmarkerslength != 0;
exceptionmarker exceptionmarker = null;
if (hasexceptionmarkers) {
exceptionmarker = exceptionmarkers[0];
}

stackmapframe frame = new stackmapframe(maxlocals);
if (!isclinit) {
initializedefaultlocals(frame, methodbinding, maxlocals, codelength);
}
frame.pc = -1;
frames.add(frame.duplicate());
while (true) {
int currentpc = pc - codeoffset;
if (hasstackmarkers && stackmarker.pc == currentpc) {
verificationtypeinfo[] infos = frame.stackitems;
verificationtypeinfo[] tempinfos = new verificationtypeinfo[frame.numberofstackitems];
system.arraycopy(infos, 0, tempinfos, 0, frame.numberofstackitems);
stackmarker.setinfos(tempinfos);
} else if (hasstackmarkers && stackmarker.destinationpc == currentpc) {
verificationtypeinfo[] infos = stackmarker.infos;
frame.stackitems = infos;
frame.numberofstackitems = infos.length;
indexinstackmarkers++;
if (indexinstackmarkers < stackmarkerslength) {
stackmarker = stackmarkers[indexinstackmarkers];
} else {
hasstackmarkers = false;
}
}
if (hasstackdepthmarkers && stackdepthmarker.pc == currentpc) {
typebinding typebinding = stackdepthmarker.typebinding;
if (typebinding != null) {
if (stackdepthmarker.delta > 0) {
frame.addstackitem(new verificationtypeinfo(typebinding));
} else {
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding);
}
} else {
frame.numberofstackitems--;
}
indexinstackdepthmarkers++;
if (indexinstackdepthmarkers < stackdepthmarkerslength) {
stackdepthmarker = stackdepthmarkers[indexinstackdepthmarkers];
} else {
hasstackdepthmarkers = false;
}
}
if (hasexceptionmarkers && exceptionmarker.pc == currentpc) {
frame.numberofstackitems = 0;
frame.addstackitem(new verificationtypeinfo(0, verificationtypeinfo.item_object, exceptionmarker.constantpoolname));
indexinexceptionmarkers++;
if (indexinexceptionmarkers < exceptionsmarkerslength) {
exceptionmarker = exceptionmarkers[indexinexceptionmarkers];
} else {
hasexceptionmarkers = false;
}
}
if (currentframeposition < currentpc) {
do {
indexinframepositions++;
if (indexinframepositions < framepositionslength) {
currentframeposition = framepositions[indexinframepositions];
} else {
// no more frame to generate
return;
}
} while (currentframeposition < currentpc);
}
if (currentframeposition == currentpc) {
// need to build a new frame and create a stack map attribute entry
stackmapframe currentframe = frame.duplicate();
currentframe.pc = currentpc;
// initialize locals
initializelocals(isclinit ? true : methodbinding.isstatic(), currentpc, currentframe);
// insert a new frame
frames.add(currentframe);
indexinframepositions++;
if (indexinframepositions < framepositionslength) {
currentframeposition = framepositions[indexinframepositions];
} else {
// no more frame to generate
return;
}
}
byte opcode = (byte) u1at(bytecodes, 0, pc);
switch (opcode) {
case opcodes.opc_nop:
pc++;
break;
case opcodes.opc_aconst_null:
frame.addstackitem(typebinding.null);
pc++;
break;
case opcodes.opc_iconst_m1:
case opcodes.opc_iconst_0:
case opcodes.opc_iconst_1:
case opcodes.opc_iconst_2:
case opcodes.opc_iconst_3:
case opcodes.opc_iconst_4:
case opcodes.opc_iconst_5:
frame.addstackitem(typebinding.int);
pc++;
break;
case opcodes.opc_lconst_0:
case opcodes.opc_lconst_1:
frame.addstackitem(typebinding.long);
pc++;
break;
case opcodes.opc_fconst_0:
case opcodes.opc_fconst_1:
case opcodes.opc_fconst_2:
frame.addstackitem(typebinding.float);
pc++;
break;
case opcodes.opc_dconst_0:
case opcodes.opc_dconst_1:
frame.addstackitem(typebinding.double);
pc++;
break;
case opcodes.opc_bipush:
frame.addstackitem(typebinding.byte);
pc += 2;
break;
case opcodes.opc_sipush:
frame.addstackitem(typebinding.short);
pc += 3;
break;
case opcodes.opc_ldc:
index = u1at(bytecodes, 1, pc);
switch (u1at(poolcontents, 0, constantpooloffsets[index])) {
case classfileconstants.stringtag:
frame
.addstackitem(new verificationtypeinfo(
typeids.t_javalangstring,
constantpool.javalangstringconstantpoolname));
break;
case classfileconstants.integertag:
frame.addstackitem(typebinding.int);
break;
case classfileconstants.floattag:
frame.addstackitem(typebinding.float);
break;
case classfileconstants.classtag:
frame.addstackitem(new verificationtypeinfo(
typeids.t_javalangclass,
constantpool.javalangclassconstantpoolname));
}
pc += 2;
break;
case opcodes.opc_ldc_w:
index = u2at(bytecodes, 1, pc);
switch (u1at(poolcontents, 0, constantpooloffsets[index])) {
case classfileconstants.stringtag:
frame
.addstackitem(new verificationtypeinfo(
typeids.t_javalangstring,
constantpool.javalangstringconstantpoolname));
break;
case classfileconstants.integertag:
frame.addstackitem(typebinding.int);
break;
case classfileconstants.floattag:
frame.addstackitem(typebinding.float);
break;
case classfileconstants.classtag:
frame.addstackitem(new verificationtypeinfo(
typeids.t_javalangclass,
constantpool.javalangclassconstantpoolname));
}
pc += 3;
break;
case opcodes.opc_ldc2_w:
index = u2at(bytecodes, 1, pc);
switch (u1at(poolcontents, 0, constantpooloffsets[index])) {
case classfileconstants.doubletag:
frame.addstackitem(typebinding.double);
break;
case classfileconstants.longtag:
frame.addstackitem(typebinding.long);
break;
}
pc += 3;
break;
case opcodes.opc_iload:
frame.addstackitem(typebinding.int);
pc += 2;
break;
case opcodes.opc_lload:
frame.addstackitem(typebinding.long);
pc += 2;
break;
case opcodes.opc_fload:
frame.addstackitem(typebinding.float);
pc += 2;
break;
case opcodes.opc_dload:
frame.addstackitem(typebinding.double);
pc += 2;
break;
case opcodes.opc_aload:
index = u1at(bytecodes, 1, pc);
verificationtypeinfo localsn = retrievelocal(currentpc, index);
frame.addstackitem(localsn);
pc += 2;
break;
case opcodes.opc_iload_0:
case opcodes.opc_iload_1:
case opcodes.opc_iload_2:
case opcodes.opc_iload_3:
frame.addstackitem(typebinding.int);
pc++;
break;
case opcodes.opc_lload_0:
case opcodes.opc_lload_1:
case opcodes.opc_lload_2:
case opcodes.opc_lload_3:
frame.addstackitem(typebinding.long);
pc++;
break;
case opcodes.opc_fload_0:
case opcodes.opc_fload_1:
case opcodes.opc_fload_2:
case opcodes.opc_fload_3:
frame.addstackitem(typebinding.float);
pc++;
break;
case opcodes.opc_dload_0:
case opcodes.opc_dload_1:
case opcodes.opc_dload_2:
case opcodes.opc_dload_3:
frame.addstackitem(typebinding.double);
pc++;
break;
case opcodes.opc_aload_0:
verificationtypeinfo locals0 = frame.locals[0];
// special case to handle uninitialized object
if (locals0 == null) {
locals0 = retrievelocal(currentpc, 0);
}
frame.addstackitem(locals0);
pc++;
break;
case opcodes.opc_aload_1:
verificationtypeinfo locals1 = retrievelocal(currentpc, 1);
frame.addstackitem(locals1);
pc++;
break;
case opcodes.opc_aload_2:
verificationtypeinfo locals2 = retrievelocal(currentpc, 2);
frame.addstackitem(locals2);
pc++;
break;
case opcodes.opc_aload_3:
verificationtypeinfo locals3 = retrievelocal(currentpc, 3);
frame.addstackitem(locals3);
pc++;
break;
case opcodes.opc_iaload:
frame.numberofstackitems -=2;
frame.addstackitem(typebinding.int);
pc++;
break;
case opcodes.opc_laload:
frame.numberofstackitems -=2;
frame.addstackitem(typebinding.long);
pc++;
break;
case opcodes.opc_faload:
frame.numberofstackitems -=2;
frame.addstackitem(typebinding.float);
pc++;
break;
case opcodes.opc_daload:
frame.numberofstackitems -=2;
frame.addstackitem(typebinding.double);
pc++;
break;
case opcodes.opc_aaload:
frame.numberofstackitems--;
frame.replacewithelementtype();
pc++;
break;
case opcodes.opc_baload:
frame.numberofstackitems -=2;
frame.addstackitem(typebinding.byte);
pc++;
break;
case opcodes.opc_caload:
frame.numberofstackitems -=2;
frame.addstackitem(typebinding.char);
pc++;
break;
case opcodes.opc_saload:
frame.numberofstackitems -=2;
frame.addstackitem(typebinding.short);
pc++;
break;
case opcodes.opc_istore:
case opcodes.opc_lstore:
case opcodes.opc_fstore:
case opcodes.opc_dstore:
frame.numberofstackitems--;
pc += 2;
break;
case opcodes.opc_astore:
index = u1at(bytecodes, 1, pc);
frame.numberofstackitems--;
pc += 2;
break;
case opcodes.opc_astore_0:
frame.locals[0] = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
pc++;
break;
case opcodes.opc_astore_1:
case opcodes.opc_astore_2:
case opcodes.opc_astore_3:
case opcodes.opc_istore_0:
case opcodes.opc_istore_1:
case opcodes.opc_istore_2:
case opcodes.opc_istore_3:
case opcodes.opc_lstore_0:
case opcodes.opc_lstore_1:
case opcodes.opc_lstore_2:
case opcodes.opc_lstore_3:
case opcodes.opc_fstore_0:
case opcodes.opc_fstore_1:
case opcodes.opc_fstore_2:
case opcodes.opc_fstore_3:
case opcodes.opc_dstore_0:
case opcodes.opc_dstore_1:
case opcodes.opc_dstore_2:
case opcodes.opc_dstore_3:
frame.numberofstackitems--;
pc++;
break;
case opcodes.opc_iastore:
case opcodes.opc_lastore:
case opcodes.opc_fastore:
case opcodes.opc_dastore:
case opcodes.opc_aastore:
case opcodes.opc_bastore:
case opcodes.opc_castore:
case opcodes.opc_sastore:
frame.numberofstackitems-=3;
pc++;
break;
case opcodes.opc_pop:
frame.numberofstackitems--;
pc++;
break;
case opcodes.opc_pop2:
int numberofstackitems = frame.numberofstackitems;
switch(frame.stackitems[numberofstackitems - 1].id()) {
case typeids.t_long :
case typeids.t_double :
frame.numberofstackitems--;
break;
default:
frame.numberofstackitems -= 2;
}
pc++;
break;
case opcodes.opc_dup:
frame.addstackitem(frame.stackitems[frame.numberofstackitems - 1]);
pc++;
break;
case opcodes.opc_dup_x1:
verificationtypeinfo info = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
verificationtypeinfo info2 = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
frame.addstackitem(info);
frame.addstackitem(info2);
frame.addstackitem(info);
pc++;
break;
case opcodes.opc_dup_x2:
info = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
info2 = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
switch(info2.id()) {
case typeids.t_long :
case typeids.t_double :
frame.addstackitem(info);
frame.addstackitem(info2);
frame.addstackitem(info);
break;
default:
numberofstackitems = frame.numberofstackitems;
verificationtypeinfo info3 = frame.stackitems[numberofstackitems - 1];
frame.numberofstackitems--;
frame.addstackitem(info);
frame.addstackitem(info3);
frame.addstackitem(info2);
frame.addstackitem(info);
}
pc++;
break;
case opcodes.opc_dup2:
info = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
switch(info.id()) {
case typeids.t_double :
case typeids.t_long :
frame.addstackitem(info);
frame.addstackitem(info);
break;
default:
info2 = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
frame.addstackitem(info2);
frame.addstackitem(info);
frame.addstackitem(info2);
frame.addstackitem(info);
}
pc++;
break;
case opcodes.opc_dup2_x1:
info = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
info2 = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
switch(info.id()) {
case typeids.t_double :
case typeids.t_long :
frame.addstackitem(info);
frame.addstackitem(info2);
frame.addstackitem(info);
break;
default:
verificationtypeinfo info3 = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
frame.addstackitem(info2);
frame.addstackitem(info);
frame.addstackitem(info3);
frame.addstackitem(info2);
frame.addstackitem(info);
}
pc++;
break;
case opcodes.opc_dup2_x2:
numberofstackitems = frame.numberofstackitems;
info = frame.stackitems[numberofstackitems - 1];
frame.numberofstackitems--;
info2 = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
switch(info.id()) {
case typeids.t_long :
case typeids.t_double :
switch(info2.id()) {
case typeids.t_long :
case typeids.t_double :
// form 4
frame.addstackitem(info);
frame.addstackitem(info2);
frame.addstackitem(info);
break;
default:
// form 2
numberofstackitems = frame.numberofstackitems;
verificationtypeinfo info3 = frame.stackitems[numberofstackitems - 1];
frame.numberofstackitems--;
frame.addstackitem(info);
frame.addstackitem(info3);
frame.addstackitem(info2);
frame.addstackitem(info);
}
break;
default:
numberofstackitems = frame.numberofstackitems;
verificationtypeinfo info3 = frame.stackitems[numberofstackitems - 1];
frame.numberofstackitems--;
switch(info3.id()) {
case typeids.t_long :
case typeids.t_double :
// form 3
frame.addstackitem(info2);
frame.addstackitem(info);
frame.addstackitem(info3);
frame.addstackitem(info2);
frame.addstackitem(info);
break;
default:
// form 1
numberofstackitems = frame.numberofstackitems;
verificationtypeinfo info4 = frame.stackitems[numberofstackitems - 1];
frame.numberofstackitems--;
frame.addstackitem(info2);
frame.addstackitem(info);
frame.addstackitem(info4);
frame.addstackitem(info3);
frame.addstackitem(info2);
frame.addstackitem(info);
}
}
pc++;
break;
case opcodes.opc_swap:
numberofstackitems = frame.numberofstackitems;
info = frame.stackitems[numberofstackitems - 1];
info2 = frame.stackitems[numberofstackitems - 2];
frame.stackitems[numberofstackitems - 1] = info2;
frame.stackitems[numberofstackitems - 2] = info;
pc++;
break;
case opcodes.opc_iadd:
case opcodes.opc_ladd:
case opcodes.opc_fadd:
case opcodes.opc_dadd:
case opcodes.opc_isub:
case opcodes.opc_lsub:
case opcodes.opc_fsub:
case opcodes.opc_dsub:
case opcodes.opc_imul:
case opcodes.opc_lmul:
case opcodes.opc_fmul:
case opcodes.opc_dmul:
case opcodes.opc_idiv:
case opcodes.opc_ldiv:
case opcodes.opc_fdiv:
case opcodes.opc_ddiv:
case opcodes.opc_irem:
case opcodes.opc_lrem:
case opcodes.opc_frem:
case opcodes.opc_drem:
case opcodes.opc_ishl:
case opcodes.opc_lshl:
case opcodes.opc_ishr:
case opcodes.opc_lshr:
case opcodes.opc_iushr:
case opcodes.opc_lushr:
case opcodes.opc_iand:
case opcodes.opc_land:
case opcodes.opc_ior:
case opcodes.opc_lor:
case opcodes.opc_ixor:
case opcodes.opc_lxor:
frame.numberofstackitems--;
pc++;
break;
case opcodes.opc_ineg:
case opcodes.opc_lneg:
case opcodes.opc_fneg:
case opcodes.opc_dneg:
pc++;
break;
case opcodes.opc_iinc:
pc += 3;
break;
case opcodes.opc_i2l:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.long);
pc++;
break;
case opcodes.opc_i2f:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.float);
pc++;
break;
case opcodes.opc_i2d:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.double);
pc++;
break;
case opcodes.opc_l2i:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.int);
pc++;
break;
case opcodes.opc_l2f:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.float);
pc++;
break;
case opcodes.opc_l2d:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.double);
pc++;
break;
case opcodes.opc_f2i:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.int);
pc++;
break;
case opcodes.opc_f2l:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.long);
pc++;
break;
case opcodes.opc_f2d:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.double);
pc++;
break;
case opcodes.opc_d2i:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.int);
pc++;
break;
case opcodes.opc_d2l:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.long);
pc++;
break;
case opcodes.opc_d2f:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.float);
pc++;
break;
case opcodes.opc_i2b:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.byte);
pc++;
break;
case opcodes.opc_i2c:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.char);
pc++;
break;
case opcodes.opc_i2s:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.short);
pc++;
break;
case opcodes.opc_lcmp:
case opcodes.opc_fcmpl:
case opcodes.opc_fcmpg:
case opcodes.opc_dcmpl:
case opcodes.opc_dcmpg:
frame.numberofstackitems-=2;
frame.addstackitem(typebinding.int);
pc++;
break;
case opcodes.opc_ifeq:
case opcodes.opc_ifne:
case opcodes.opc_iflt:
case opcodes.opc_ifge:
case opcodes.opc_ifgt:
case opcodes.opc_ifle:
frame.numberofstackitems--;
pc += 3;
break;
case opcodes.opc_if_icmpeq:
case opcodes.opc_if_icmpne:
case opcodes.opc_if_icmplt:
case opcodes.opc_if_icmpge:
case opcodes.opc_if_icmpgt:
case opcodes.opc_if_icmple:
case opcodes.opc_if_acmpeq:
case opcodes.opc_if_acmpne:
frame.numberofstackitems -= 2;
pc += 3;
break;
case opcodes.opc_goto:
pc += 3;
break;
case opcodes.opc_tableswitch:
pc++;
while (((pc - codeoffset) & 0x03) != 0) {
pc++;
}
pc += 4; // default
int low = i4at(bytecodes, 0, pc);
pc += 4;
int high = i4at(bytecodes, 0, pc);
pc += 4;
int length = high - low + 1;
pc += (length * 4);
frame.numberofstackitems--;
break;
case opcodes.opc_lookupswitch:
pc++;
while (((pc - codeoffset) & 0x03) != 0) {
pc++;
}
pc += 4; // default
int npairs = (int) u4at(bytecodes, 0, pc);
pc += (4 + npairs * 8);
frame.numberofstackitems--;
break;
case opcodes.opc_ireturn:
case opcodes.opc_lreturn:
case opcodes.opc_freturn:
case opcodes.opc_dreturn:
case opcodes.opc_areturn:
frame.numberofstackitems--;
pc++;
break;
case opcodes.opc_return:
pc++;
break;
case opcodes.opc_getstatic:
index = u2at(bytecodes, 1, pc);
int nameandtypeindex = u2at(poolcontents, 3,
constantpooloffsets[index]);
int utf8index = u2at(poolcontents, 3,
constantpooloffsets[nameandtypeindex]);
char[] descriptor = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
if (descriptor.length == 1) {
// base type
switch(descriptor[0]) {
case 'z':
frame.addstackitem(typebinding.boolean);
break;
case 'b':
frame.addstackitem(typebinding.byte);
break;
case 'c':
frame.addstackitem(typebinding.char);
break;
case 'd':
frame.addstackitem(typebinding.double);
break;
case 'f':
frame.addstackitem(typebinding.float);
break;
case 'i':
frame.addstackitem(typebinding.int);
break;
case 'j':
frame.addstackitem(typebinding.long);
break;
case 's':
frame.addstackitem(typebinding.short);
break;
}
} else if (descriptor[0] == '[') {
frame.addstackitem(new verificationtypeinfo(0, descriptor));
} else {
frame.addstackitem(new verificationtypeinfo(0, charoperation.subarray(descriptor, 1, descriptor.length - 1)));
}
pc += 3;
break;
case opcodes.opc_putstatic:
frame.numberofstackitems--;
pc += 3;
break;
case opcodes.opc_getfield:
index = u2at(bytecodes, 1, pc);
nameandtypeindex = u2at(poolcontents, 3,
constantpooloffsets[index]);
utf8index = u2at(poolcontents, 3,
constantpooloffsets[nameandtypeindex]);
descriptor = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
frame.numberofstackitems--;
if (descriptor.length == 1) {
// base type
switch(descriptor[0]) {
case 'z':
frame.addstackitem(typebinding.boolean);
break;
case 'b':
frame.addstackitem(typebinding.byte);
break;
case 'c':
frame.addstackitem(typebinding.char);
break;
case 'd':
frame.addstackitem(typebinding.double);
break;
case 'f':
frame.addstackitem(typebinding.float);
break;
case 'i':
frame.addstackitem(typebinding.int);
break;
case 'j':
frame.addstackitem(typebinding.long);
break;
case 's':
frame.addstackitem(typebinding.short);
break;
}
} else if (descriptor[0] == '[') {
frame.addstackitem(new verificationtypeinfo(0, descriptor));
} else {
frame.addstackitem(new verificationtypeinfo(0, charoperation.subarray(descriptor, 1, descriptor.length - 1)));
}
pc += 3;
break;
case opcodes.opc_putfield:
frame.numberofstackitems -= 2;
pc += 3;
break;
case opcodes.opc_invokevirtual:
index = u2at(bytecodes, 1, pc);
nameandtypeindex = u2at(poolcontents, 3,
constantpooloffsets[index]);
utf8index = u2at(poolcontents, 3,
constantpooloffsets[nameandtypeindex]);
descriptor = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
utf8index = u2at(poolcontents, 1,
constantpooloffsets[nameandtypeindex]);
char[] name = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
frame.numberofstackitems -= (getparameterscount(descriptor) + 1);
char[] returntype = getreturntype(descriptor);
if (returntype.length == 1) {
// base type
switch(returntype[0]) {
case 'z':
frame.addstackitem(typebinding.boolean);
break;
case 'b':
frame.addstackitem(typebinding.byte);
break;
case 'c':
frame.addstackitem(typebinding.char);
break;
case 'd':
frame.addstackitem(typebinding.double);
break;
case 'f':
frame.addstackitem(typebinding.float);
break;
case 'i':
frame.addstackitem(typebinding.int);
break;
case 'j':
frame.addstackitem(typebinding.long);
break;
case 's':
frame.addstackitem(typebinding.short);
break;
}
} else {
if (returntype[0] == '[') {
frame.addstackitem(new verificationtypeinfo(0, returntype));
} else {
frame.addstackitem(new verificationtypeinfo(0, charoperation.subarray(returntype, 1, returntype.length - 1)));
}
}
pc += 3;
break;
case opcodes.opc_invokespecial:
index = u2at(bytecodes, 1, pc);
nameandtypeindex = u2at(poolcontents, 3,
constantpooloffsets[index]);
utf8index = u2at(poolcontents, 3,
constantpooloffsets[nameandtypeindex]);
descriptor = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
utf8index = u2at(poolcontents, 1,
constantpooloffsets[nameandtypeindex]);
name = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
frame.numberofstackitems -= getparameterscount(descriptor);
if (charoperation.equals(constantpool.init, name)) {
// constructor
frame.stackitems[frame.numberofstackitems - 1].tag = verificationtypeinfo.item_object;
}
frame.numberofstackitems--;
returntype = getreturntype(descriptor);
if (returntype.length == 1) {
// base type
switch(returntype[0]) {
case 'z':
frame.addstackitem(typebinding.boolean);
break;
case 'b':
frame.addstackitem(typebinding.byte);
break;
case 'c':
frame.addstackitem(typebinding.char);
break;
case 'd':
frame.addstackitem(typebinding.double);
break;
case 'f':
frame.addstackitem(typebinding.float);
break;
case 'i':
frame.addstackitem(typebinding.int);
break;
case 'j':
frame.addstackitem(typebinding.long);
break;
case 's':
frame.addstackitem(typebinding.short);
break;
}
} else {
if (returntype[0] == '[') {
frame.addstackitem(new verificationtypeinfo(0, returntype));
} else {
frame.addstackitem(new verificationtypeinfo(0, charoperation.subarray(returntype, 1, returntype.length - 1)));
}
}
pc += 3;
break;
case opcodes.opc_invokestatic:
index = u2at(bytecodes, 1, pc);
nameandtypeindex = u2at(poolcontents, 3,
constantpooloffsets[index]);
utf8index = u2at(poolcontents, 3,
constantpooloffsets[nameandtypeindex]);
descriptor = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
utf8index = u2at(poolcontents, 1,
constantpooloffsets[nameandtypeindex]);
name = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
frame.numberofstackitems -= getparameterscount(descriptor);
returntype = getreturntype(descriptor);
if (returntype.length == 1) {
// base type
switch(returntype[0]) {
case 'z':
frame.addstackitem(typebinding.boolean);
break;
case 'b':
frame.addstackitem(typebinding.byte);
break;
case 'c':
frame.addstackitem(typebinding.char);
break;
case 'd':
frame.addstackitem(typebinding.double);
break;
case 'f':
frame.addstackitem(typebinding.float);
break;
case 'i':
frame.addstackitem(typebinding.int);
break;
case 'j':
frame.addstackitem(typebinding.long);
break;
case 's':
frame.addstackitem(typebinding.short);
break;
}
} else {
if (returntype[0] == '[') {
frame.addstackitem(new verificationtypeinfo(0, returntype));
} else {
frame.addstackitem(new verificationtypeinfo(0, charoperation.subarray(returntype, 1, returntype.length - 1)));
}
}
pc += 3;
break;
case opcodes.opc_invokeinterface:
index = u2at(bytecodes, 1, pc);
nameandtypeindex = u2at(poolcontents, 3,
constantpooloffsets[index]);
utf8index = u2at(poolcontents, 3,
constantpooloffsets[nameandtypeindex]);
descriptor = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
utf8index = u2at(poolcontents, 1,
constantpooloffsets[nameandtypeindex]);
name = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
// we don't need count and args
// u1at(bytecodes, 3, pc); // count
// u1at(bytecodes, 4, pc); // extra args
frame.numberofstackitems -= (getparameterscount(descriptor) + 1);
returntype = getreturntype(descriptor);
if (returntype.length == 1) {
// base type
switch(returntype[0]) {
case 'z':
frame.addstackitem(typebinding.boolean);
break;
case 'b':
frame.addstackitem(typebinding.byte);
break;
case 'c':
frame.addstackitem(typebinding.char);
break;
case 'd':
frame.addstackitem(typebinding.double);
break;
case 'f':
frame.addstackitem(typebinding.float);
break;
case 'i':
frame.addstackitem(typebinding.int);
break;
case 'j':
frame.addstackitem(typebinding.long);
break;
case 's':
frame.addstackitem(typebinding.short);
break;
}
} else {
if (returntype[0] == '[') {
frame.addstackitem(new verificationtypeinfo(0, returntype));
} else {
frame.addstackitem(new verificationtypeinfo(0, charoperation.subarray(returntype, 1, returntype.length - 1)));
}
}
pc += 5;
break;
case opcodes.opc_new:
index = u2at(bytecodes, 1, pc);
utf8index = u2at(poolcontents, 1,
constantpooloffsets[index]);
char[] classname = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
verificationtypeinfo verificationtypeinfo = new verificationtypeinfo(0, verificationtypeinfo.item_uninitialized, classname);
verificationtypeinfo.offset = currentpc;
frame.addstackitem(verificationtypeinfo);
pc += 3;
break;
case opcodes.opc_newarray:
char[] constantpoolname = null;
switch (u1at(bytecodes, 1, pc)) {
case classfileconstants.int_array :
constantpoolname = new char[] { '[', 'i' };
break;
case classfileconstants.byte_array :
constantpoolname = new char[] { '[', 'b' };
break;
case classfileconstants.boolean_array :
constantpoolname = new char[] { '[', 'z' };
break;
case classfileconstants.short_array :
constantpoolname = new char[] { '[', 's' };
break;
case classfileconstants.char_array :
constantpoolname = new char[] { '[', 'c' };
break;
case classfileconstants.long_array :
constantpoolname = new char[] { '[', 'j' };
break;
case classfileconstants.float_array :
constantpoolname = new char[] { '[', 'f' };
break;
case classfileconstants.double_array :
constantpoolname = new char[] { '[', 'd' };
break;
}
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typeids.t_javalangobject, constantpoolname);
pc += 2;
break;
case opcodes.opc_anewarray:
index = u2at(bytecodes, 1, pc);
utf8index = u2at(poolcontents, 1,
constantpooloffsets[index]);
classname = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
int classnamelength = classname.length;
if (classname[0] != '[') {
// this is a type name (class or interface). so we add appropriate '[', 'l' and ';'.
system.arraycopy(classname, 0, (constantpoolname = new char[classnamelength + 3]), 2, classnamelength);
constantpoolname[0] = '[';
constantpoolname[1] = 'l';
constantpoolname[classnamelength + 2] = ';';
} else {
// if class name is already an array, we just need to add one dimension
system.arraycopy(classname, 0, (constantpoolname = new char[classnamelength + 1]), 1, classnamelength);
constantpoolname[0] = '[';
}
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(0, constantpoolname);
pc += 3;
break;
case opcodes.opc_arraylength:
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.int);
pc++;
break;
case opcodes.opc_athrow:
frame.numberofstackitems--;
pc++;
break;
case opcodes.opc_checkcast:
index = u2at(bytecodes, 1, pc);
utf8index = u2at(poolcontents, 1,
constantpooloffsets[index]);
classname = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(0, classname);
pc += 3;
break;
case opcodes.opc_instanceof:
// no need to know the class index = u2at(bytecodes, 1, pc);
frame.stackitems[frame.numberofstackitems - 1] = new verificationtypeinfo(typebinding.int);
pc += 3;
break;
case opcodes.opc_monitorenter:
case opcodes.opc_monitorexit:
frame.numberofstackitems--;
pc++;
break;
case opcodes.opc_wide:
opcode = (byte) u1at(bytecodes, 1, pc);
if (opcode == opcodes.opc_iinc) {
// index = u2at(bytecodes, 2, pc);
// i2at(bytecodes, 4, pc); // const
// we don't need the index and the const value
pc += 6;
} else {
index = u2at(bytecodes, 2, pc);
// need to handle iload, fload, aload, lload, dload, istore, fstore, astore, lstore or dstore
switch(opcode) {
case opcodes.opc_iload :
frame.addstackitem(typebinding.int);
break;
case opcodes.opc_fload :
frame.addstackitem(typebinding.float);
break;
case opcodes.opc_aload :
localsn = frame.locals[index];
if (localsn == null) {
localsn = retrievelocal(currentpc, index);
}
frame.addstackitem(localsn);
break;
case opcodes.opc_lload :
frame.addstackitem(typebinding.long);
break;
case opcodes.opc_dload :
frame.addstackitem(typebinding.double);
break;
case opcodes.opc_istore :
frame.numberofstackitems--;
break;
case opcodes.opc_fstore :
frame.numberofstackitems--;
break;
case opcodes.opc_astore :
frame.locals[index] = frame.stackitems[frame.numberofstackitems - 1];
frame.numberofstackitems--;
break;
case opcodes.opc_lstore :
frame.numberofstackitems--;
break;
case opcodes.opc_dstore :
frame.numberofstackitems--;
break;
}
pc += 4;
}
break;
case opcodes.opc_multianewarray:
index = u2at(bytecodes, 1, pc);
utf8index = u2at(poolcontents, 1,
constantpooloffsets[index]);
classname = utf8at(poolcontents,
constantpooloffsets[utf8index] + 3, u2at(
poolcontents, 1,
constantpooloffsets[utf8index]));
int dimensions = u1at(bytecodes, 3, pc); // dimensions
frame.numberofstackitems -= dimensions;
classnamelength = classname.length;
constantpoolname = new char[classnamelength + dimensions];
for (int i = 0; i < dimensions; i++) {
constantpoolname[i] = '[';
}
system.arraycopy(classname, 0, constantpoolname, dimensions, classnamelength);
frame.addstackitem(new verificationtypeinfo(0, constantpoolname));
pc += 4;
break;
case opcodes.opc_ifnull:
case opcodes.opc_ifnonnull:
frame.numberofstackitems--;
pc += 3;
break;
case opcodes.opc_goto_w:
pc += 5;
break;
default: // should not occur
this.codestream.methoddeclaration.scope.problemreporter().abortduetointernalerror(
messages.bind(
messages.abort_invalidopcode,
new object[] {
new byte(opcode),
new integer(pc),
new string(methodbinding.shortreadablename()),
}),
this.codestream.methoddeclaration);
break;
}
if (pc >= (codelength + codeoffset)) {
break;
}
}
}

private final int u1at(byte[] reference, int relativeoffset,
int structoffset) {
return (reference[relativeoffset + structoffset] & 0xff);
}

private final int u2at(byte[] reference, int relativeoffset,
int structoffset) {
int position = relativeoffset + structoffset;
return ((reference[position++] & 0xff) << 8)
+ (reference[position] & 0xff);
}

private final long u4at(byte[] reference, int relativeoffset,
int structoffset) {
int position = relativeoffset + structoffset;
return (((reference[position++] & 0xffl) << 24)
+ ((reference[position++] & 0xff) << 16)
+ ((reference[position++] & 0xff) << 8) + (reference[position] & 0xff));
}

public char[] utf8at(byte[] reference, int absoluteoffset,
int bytesavailable) {
int length = bytesavailable;
char outputbuf[] = new char[bytesavailable];
int outputpos = 0;
int readoffset = absoluteoffset;

while (length != 0) {
int x = reference[readoffset++] & 0xff;
length--;
if ((0x80 & x) != 0) {
if ((x & 0x20) != 0) {
length -= 2;
x = ((x & 0xf) << 12)
| ((reference[readoffset++] & 0x3f) << 6)
| (reference[readoffset++] & 0x3f);
} else {
length--;
x = ((x & 0x1f) << 6) | (reference[readoffset++] & 0x3f);
}
}
outputbuf[outputpos++] = (char) x;
}

if (outputpos != bytesavailable) {
system.arraycopy(outputbuf, 0, (outputbuf = new char[outputpos]),
0, outputpos);
}
return outputbuf;
}
}
