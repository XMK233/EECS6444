/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.select;

/*
* selection node build by the parser in any case it was intending to
* reduce a field reference containing the cursor.
* e.g.
*
*	class x {
*    void foo() {
*      bar().[start]fred[end]
*    }
*  }
*
*	---> class x {
*         void foo() {
*           <selectonfieldreference:bar().fred>
*         }
*       }
*
*/

import org.eclipse.jdt.internal.compiler.ast.fieldreference;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;

public class selectiononfieldreference extends fieldreference {

public selectiononfieldreference(char[] source , long pos) {

super(source, pos);
}

public stringbuffer printexpression(int indent, stringbuffer output){

output.append("<selectiononfieldreference:");  //$non-nls-1$
return super.printexpression(0, output).append('>');
}

public typebinding resolvetype(blockscope scope) {

super.resolvetype(scope);
// tolerate some error cases
if (this.binding == null ||
!(this.binding.isvalidbinding() ||
this.binding.problemid() == problemreasons.notvisible
|| this.binding.problemid() == problemreasons.inheritednamehidesenclosingname
|| this.binding.problemid() == problemreasons.nonstaticreferenceinconstructorinvocation
|| this.binding.problemid() == problemreasons.nonstaticreferenceinstaticcontext))
throw new selectionnodefound();
else
throw new selectionnodefound(this.binding);
}
}
