/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

import java.util.hashmap;
import java.util.map;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.ast.astnode;
import org.eclipse.jdt.internal.compiler.ast.abstractmethoddeclaration;
import org.eclipse.jdt.internal.compiler.ast.abstractvariabledeclaration;
import org.eclipse.jdt.internal.compiler.ast.fielddeclaration;
import org.eclipse.jdt.internal.compiler.ast.qualifiedallocationexpression;
import org.eclipse.jdt.internal.compiler.ast.typedeclaration;
import org.eclipse.jdt.internal.compiler.ast.typeparameter;
import org.eclipse.jdt.internal.compiler.ast.typereference;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.env.accessrestriction;
import org.eclipse.jdt.internal.compiler.problem.abortcompilation;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;
import org.eclipse.jdt.internal.compiler.util.hashtableofobject;

public class classscope extends scope {

public typedeclaration referencecontext;
public typereference supertypereference;
java.util.arraylist deferredboundchecks;

public classscope(scope parent, typedeclaration context) {
super(scope.class_scope, parent);
this.referencecontext = context;
this.deferredboundchecks = null; // initialized if required
}

void buildanonymoustypebinding(sourcetypebinding enclosingtype, referencebinding supertype) {
localtypebinding anonymoustype = buildlocaltype(enclosingtype, supertype, enclosingtype.fpackage);
anonymoustype.modifiers |= extracompilermodifiers.acclocallyused; // tag all anonymous types as used locally
if (supertype.isinterface()) {
anonymoustype.superclass = getjavalangobject();
anonymoustype.superinterfaces = new referencebinding[] { supertype };
typereference typereference = this.referencecontext.allocation.type;
if (typereference != null) {
if ((supertype.tagbits & tagbits.hasdirectwildcard) != 0) {
problemreporter().supertypecannotusewildcard(anonymoustype, typereference, supertype);
anonymoustype.tagbits |= tagbits.hierarchyhasproblems;
anonymoustype.superinterfaces = binding.no_superinterfaces;
}
}
} else {
anonymoustype.superclass = supertype;
anonymoustype.superinterfaces = binding.no_superinterfaces;
typereference typereference = this.referencecontext.allocation.type;
if (typereference != null) { // no check for enum constant body
if (supertype.erasure().id == typeids.t_javalangenum) {
problemreporter().cannotextendenum(anonymoustype, typereference, supertype);
anonymoustype.tagbits |= tagbits.hierarchyhasproblems;
anonymoustype.superclass = getjavalangobject();
} else if (supertype.isfinal()) {
problemreporter().anonymousclasscannotextendfinalclass(typereference, supertype);
anonymoustype.tagbits |= tagbits.hierarchyhasproblems;
anonymoustype.superclass = getjavalangobject();
} else if ((supertype.tagbits & tagbits.hasdirectwildcard) != 0) {
problemreporter().supertypecannotusewildcard(anonymoustype, typereference, supertype);
anonymoustype.tagbits |= tagbits.hierarchyhasproblems;
anonymoustype.superclass = getjavalangobject();
}
}
}
connectmembertypes();
buildfieldsandmethods();
anonymoustype.faultintypesforfieldsandmethods();
anonymoustype.verifymethods(environment().methodverifier());
}

void buildfields() {
sourcetypebinding sourcetype = this.referencecontext.binding;
if (sourcetype.arefieldsinitialized()) return;
if (this.referencecontext.fields == null) {
sourcetype.setfields(binding.no_fields);
return;
}
// count the number of fields vs. initializers
fielddeclaration[] fields = this.referencecontext.fields;
int size = fields.length;
int count = 0;
for (int i = 0; i < size; i++) {
switch (fields[i].getkind()) {
case abstractvariabledeclaration.field:
case abstractvariabledeclaration.enum_constant:
count++;
}
}

// iterate the field declarations to create the bindings, lose all duplicates
fieldbinding[] fieldbindings = new fieldbinding[count];
hashtableofobject knownfieldnames = new hashtableofobject(count);
count = 0;
for (int i = 0; i < size; i++) {
fielddeclaration field = fields[i];
if (field.getkind() == abstractvariabledeclaration.initializer) {
if (sourcetype.isinterface())
problemreporter().interfacecannothaveinitializers(sourcetype, field);
} else {
fieldbinding fieldbinding = new fieldbinding(field, null, field.modifiers | extracompilermodifiers.accunresolved, sourcetype);
fieldbinding.id = count;
// field's type will be resolved when needed for top level types
checkandsetmodifiersforfield(fieldbinding, field);

if (knownfieldnames.containskey(field.name)) {
fieldbinding previousbinding = (fieldbinding) knownfieldnames.get(field.name);
if (previousbinding != null) {
for (int f = 0; f < i; f++) {
fielddeclaration previousfield = fields[f];
if (previousfield.binding == previousbinding) {
problemreporter().duplicatefieldintype(sourcetype, previousfield);
break;
}
}
}
knownfieldnames.put(field.name, null); // ensure that the duplicate field is found & removed
problemreporter().duplicatefieldintype(sourcetype, field);
field.binding = null;
} else {
knownfieldnames.put(field.name, fieldbinding);
// remember that we have seen a field with this name
fieldbindings[count++] = fieldbinding;
}
}
}
// remove duplicate fields
if (count != fieldbindings.length)
system.arraycopy(fieldbindings, 0, fieldbindings = new fieldbinding[count], 0, count);
sourcetype.tagbits &= ~(tagbits.arefieldssorted|tagbits.arefieldscomplete); // in case some static imports reached already into this type
sourcetype.setfields(fieldbindings);
}

void buildfieldsandmethods() {
buildfields();
buildmethods();

sourcetypebinding sourcetype = this.referencecontext.binding;
if (sourcetype.ismembertype() && !sourcetype.islocaltype())
((membertypebinding) sourcetype).checksyntheticargsandfields();

referencebinding[] membertypes = sourcetype.membertypes;
for (int i = 0, length = membertypes.length; i < length; i++)
((sourcetypebinding) membertypes[i]).scope.buildfieldsandmethods();
}

private localtypebinding buildlocaltype(sourcetypebinding enclosingtype, referencebinding anonymousoriginalsupertype, packagebinding packagebinding) {

this.referencecontext.scope = this;
this.referencecontext.staticinitializerscope = new methodscope(this, this.referencecontext, true);
this.referencecontext.initializerscope = new methodscope(this, this.referencecontext, false);

// build the binding or the local type
localtypebinding localtype = new localtypebinding(this, enclosingtype, innermostswitchcase(), anonymousoriginalsupertype);
this.referencecontext.binding = localtype;
checkandsetmodifiers();
buildtypevariables();

// look at member types
referencebinding[] membertypebindings = binding.no_member_types;
if (this.referencecontext.membertypes != null) {
int size = this.referencecontext.membertypes.length;
membertypebindings = new referencebinding[size];
int count = 0;
nextmember : for (int i = 0; i < size; i++) {
typedeclaration membercontext = this.referencecontext.membertypes[i];
switch(typedeclaration.kind(membercontext.modifiers)) {
case typedeclaration.interface_decl :
case typedeclaration.annotation_type_decl :
problemreporter().illegallocaltypedeclaration(membercontext);
continue nextmember;
}
referencebinding type = localtype;
// check that the member does not conflict with an enclosing type
do {
if (charoperation.equals(type.sourcename, membercontext.name)) {
problemreporter().typecollideswithenclosingtype(membercontext);
continue nextmember;
}
type = type.enclosingtype();
} while (type != null);
// check the member type does not conflict with another sibling member type
for (int j = 0; j < i; j++) {
if (charoperation.equals(this.referencecontext.membertypes[j].name, membercontext.name)) {
problemreporter().duplicatenestedtype(membercontext);
continue nextmember;
}
}
classscope memberscope = new classscope(this, this.referencecontext.membertypes[i]);
localtypebinding memberbinding = memberscope.buildlocaltype(localtype, null /* anonymous super type*/, packagebinding);
memberbinding.setasmembertype();
membertypebindings[count++] = memberbinding;
}
if (count != size)
system.arraycopy(membertypebindings, 0, membertypebindings = new referencebinding[count], 0, count);
}
localtype.membertypes = membertypebindings;
return localtype;
}

void buildlocaltypebinding(sourcetypebinding enclosingtype) {

localtypebinding localtype = buildlocaltype(enclosingtype, null /* anonymous super type*/, enclosingtype.fpackage);
connecttypehierarchy();
if (compileroptions().sourcelevel >= classfileconstants.jdk1_5) {
checkparameterizedtypebounds();
checkparameterizedsupertypecollisions();
}
buildfieldsandmethods();
localtype.faultintypesforfieldsandmethods();

this.referencecontext.binding.verifymethods(environment().methodverifier());
}

private void buildmembertypes(accessrestriction accessrestriction) {
sourcetypebinding sourcetype = this.referencecontext.binding;
referencebinding[] membertypebindings = binding.no_member_types;
if (this.referencecontext.membertypes != null) {
int length = this.referencecontext.membertypes.length;
membertypebindings = new referencebinding[length];
int count = 0;
nextmember : for (int i = 0; i < length; i++) {
typedeclaration membercontext = this.referencecontext.membertypes[i];
switch(typedeclaration.kind(membercontext.modifiers)) {
case typedeclaration.interface_decl :
case typedeclaration.annotation_type_decl :
if (sourcetype.isnestedtype()
&& sourcetype.isclass() // no need to check for enum, since implicitly static
&& !sourcetype.isstatic()) {
problemreporter().illegallocaltypedeclaration(membercontext);
continue nextmember;
}
break;
}
referencebinding type = sourcetype;
// check that the member does not conflict with an enclosing type
do {
if (charoperation.equals(type.sourcename, membercontext.name)) {
problemreporter().typecollideswithenclosingtype(membercontext);
continue nextmember;
}
type = type.enclosingtype();
} while (type != null);
// check that the member type does not conflict with another sibling member type
for (int j = 0; j < i; j++) {
if (charoperation.equals(this.referencecontext.membertypes[j].name, membercontext.name)) {
problemreporter().duplicatenestedtype(membercontext);
continue nextmember;
}
}

classscope memberscope = new classscope(this, membercontext);
membertypebindings[count++] = memberscope.buildtype(sourcetype, sourcetype.fpackage, accessrestriction);
}
if (count != length)
system.arraycopy(membertypebindings, 0, membertypebindings = new referencebinding[count], 0, count);
}
sourcetype.membertypes = membertypebindings;
}

void buildmethods() {
sourcetypebinding sourcetype = this.referencecontext.binding;
if (sourcetype.aremethodsinitialized()) return;

boolean isenum = typedeclaration.kind(this.referencecontext.modifiers) == typedeclaration.enum_decl;
if (this.referencecontext.methods == null && !isenum) {
this.referencecontext.binding.setmethods(binding.no_methods);
return;
}

// iterate the method declarations to create the bindings
abstractmethoddeclaration[] methods = this.referencecontext.methods;
int size = methods == null ? 0 : methods.length;
// look for <clinit> method
int clinitindex = -1;
for (int i = 0; i < size; i++) {
if (methods[i].isclinit()) {
clinitindex = i;
break;
}
}

int count = isenum ? 2 : 0; // reserve 2 slots for special enum methods: #values() and #valueof(string)
methodbinding[] methodbindings = new methodbinding[(clinitindex == -1 ? size : size - 1) + count];
// create special methods for enums
if (isenum) {
methodbindings[0] = sourcetype.addsyntheticenummethod(typeconstants.values); // add <enumtype>[] values()
methodbindings[1] = sourcetype.addsyntheticenummethod(typeconstants.valueof); // add <enumtype> valueof()
}
// create bindings for source methods
boolean hasnativemethods = false;
if (sourcetype.isabstract()) {
for (int i = 0; i < size; i++) {
if (i != clinitindex) {
methodscope scope = new methodscope(this, methods[i], false);
methodbinding methodbinding = scope.createmethod(methods[i]);
if (methodbinding != null) { // is null if binding could not be created
methodbindings[count++] = methodbinding;
hasnativemethods = hasnativemethods || methodbinding.isnative();
}
}
}
} else {
boolean hasabstractmethods = false;
for (int i = 0; i < size; i++) {
if (i != clinitindex) {
methodscope scope = new methodscope(this, methods[i], false);
methodbinding methodbinding = scope.createmethod(methods[i]);
if (methodbinding != null) { // is null if binding could not be created
methodbindings[count++] = methodbinding;
hasabstractmethods = hasabstractmethods || methodbinding.isabstract();
hasnativemethods = hasnativemethods || methodbinding.isnative();
}
}
}
if (hasabstractmethods)
problemreporter().abstractmethodinconcreteclass(sourcetype);
}
if (count != methodbindings.length)
system.arraycopy(methodbindings, 0, methodbindings = new methodbinding[count], 0, count);
sourcetype.tagbits &= ~(tagbits.aremethodssorted|tagbits.aremethodscomplete); // in case some static imports reached already into this type
sourcetype.setmethods(methodbindings);
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=243917, conservatively tag all methods and fields as
// being in use if there is a native method in the class.
if (hasnativemethods) {
for (int i = 0; i < methodbindings.length; i++) {
methodbindings[i].modifiers |= extracompilermodifiers.acclocallyused;
}
fieldbinding[] fields = sourcetype.unresolvedfields(); // https://bugs.eclipse.org/bugs/show_bug.cgi?id=301683
for (int i = 0; i < fields.length; i++) {
fields[i].modifiers |= extracompilermodifiers.acclocallyused;
}
}
}

sourcetypebinding buildtype(sourcetypebinding enclosingtype, packagebinding packagebinding, accessrestriction accessrestriction) {
// provide the typedeclaration with needed scopes
this.referencecontext.scope = this;
this.referencecontext.staticinitializerscope = new methodscope(this, this.referencecontext, true);
this.referencecontext.initializerscope = new methodscope(this, this.referencecontext, false);

if (enclosingtype == null) {
char[][] classname = charoperation.arrayconcat(packagebinding.compoundname, this.referencecontext.name);
this.referencecontext.binding = new sourcetypebinding(classname, packagebinding, this);
} else {
char[][] classname = charoperation.deepcopy(enclosingtype.compoundname);
classname[classname.length - 1] =
charoperation.concat(classname[classname.length - 1], this.referencecontext.name, '$');
referencebinding existingtype = packagebinding.gettype0(classname[classname.length - 1]);
if (existingtype != null) {
if (existingtype instanceof unresolvedreferencebinding) {
// its possible that a binarytype referenced the member type before its enclosing source type was built
// so just replace the unresolved type with a new member type
} else {
// report the error against the parent - its still safe to answer the member type
this.parent.problemreporter().duplicatenestedtype(this.referencecontext);
}
}
this.referencecontext.binding = new membertypebinding(classname, this, enclosingtype);
}

sourcetypebinding sourcetype = this.referencecontext.binding;
environment().setaccessrestriction(sourcetype, accessrestriction);
sourcetype.fpackage.addtype(sourcetype);
checkandsetmodifiers();
buildtypevariables();
buildmembertypes(accessrestriction);
return sourcetype;
}

private void buildtypevariables() {

sourcetypebinding sourcetype = this.referencecontext.binding;
typeparameter[] typeparameters = this.referencecontext.typeparameters;

// do not construct type variables if source < 1.5
if (typeparameters == null || compileroptions().sourcelevel < classfileconstants.jdk1_5) {
sourcetype.typevariables = binding.no_type_variables;
return;
}
sourcetype.typevariables = binding.no_type_variables; // safety

if (sourcetype.id == typeids.t_javalangobject) { // handle the case of redefining java.lang.object up front
problemreporter().objectcannotbegeneric(this.referencecontext);
return;
}
sourcetype.typevariables = createtypevariables(typeparameters, sourcetype);
sourcetype.modifiers |= extracompilermodifiers.accgenericsignature;
}

private void checkandsetmodifiers() {
sourcetypebinding sourcetype = this.referencecontext.binding;
int modifiers = sourcetype.modifiers;
if ((modifiers & extracompilermodifiers.accalternatemodifierproblem) != 0)
problemreporter().duplicatemodifierfortype(sourcetype);
referencebinding enclosingtype = sourcetype.enclosingtype();
boolean ismembertype = sourcetype.ismembertype();
if (ismembertype) {
modifiers |= (enclosingtype.modifiers & (extracompilermodifiers.accgenericsignature|classfileconstants.accstrictfp));
// checks for member types before local types to catch local members
if (enclosingtype.isinterface())
modifiers |= classfileconstants.accpublic;
if (sourcetype.isenum()) {
if (!enclosingtype.isstatic())
problemreporter().nonstaticcontextforenummembertype(sourcetype);
else
modifiers |= classfileconstants.accstatic;
}
if (enclosingtype.isviewedasdeprecated() && !sourcetype.isdeprecated())
modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
} else if (sourcetype.islocaltype()) {
if (sourcetype.isenum()) {
problemreporter().illegallocaltypedeclaration(this.referencecontext);
sourcetype.modifiers = 0;
return;
}
if (sourcetype.isanonymoustype()) {
modifiers |= classfileconstants.accfinal;
// set accenum flag for anonymous body of enum constants
if (this.referencecontext.allocation.type == null)
modifiers |= classfileconstants.accenum;
}
scope scope = this;
do {
switch (scope.kind) {
case method_scope :
methodscope methodscope = (methodscope) scope;
if (methodscope.isinsideinitializer()) {
sourcetypebinding type = ((typedeclaration) methodscope.referencecontext).binding;

// inside field declaration ? check field modifier to see if deprecated
if (methodscope.initializedfield != null) {
// currently inside this field initialization
if (methodscope.initializedfield.isviewedasdeprecated() && !sourcetype.isdeprecated())
modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
} else {
if (type.isstrictfp())
modifiers |= classfileconstants.accstrictfp;
if (type.isviewedasdeprecated() && !sourcetype.isdeprecated())
modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
}
} else {
methodbinding method = ((abstractmethoddeclaration) methodscope.referencecontext).binding;
if (method != null) {
if (method.isstrictfp())
modifiers |= classfileconstants.accstrictfp;
if (method.isviewedasdeprecated() && !sourcetype.isdeprecated())
modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
}
}
break;
case class_scope :
// local member
if (enclosingtype.isstrictfp())
modifiers |= classfileconstants.accstrictfp;
if (enclosingtype.isviewedasdeprecated() && !sourcetype.isdeprecated())
modifiers |= extracompilermodifiers.accdeprecatedimplicitly;
break;
}
scope = scope.parent;
} while (scope != null);
}

// after this point, tests on the 16 bits reserved.
int realmodifiers = modifiers & extracompilermodifiers.accjustflag;

if ((realmodifiers & classfileconstants.accinterface) != 0) { // interface and annotation type
// detect abnormal cases for interfaces
if (ismembertype) {
final int unexpected_modifiers =
~(classfileconstants.accpublic | classfileconstants.accprivate | classfileconstants.accprotected | classfileconstants.accstatic | classfileconstants.accabstract | classfileconstants.accinterface | classfileconstants.accstrictfp | classfileconstants.accannotation);
if ((realmodifiers & unexpected_modifiers) != 0) {
if ((realmodifiers & classfileconstants.accannotation) != 0)
problemreporter().illegalmodifierforannotationmembertype(sourcetype);
else
problemreporter().illegalmodifierformemberinterface(sourcetype);
}
/*
} else if (sourcetype.islocaltype()) { //interfaces cannot be defined inside a method
int unexpectedmodifiers = ~(accabstract | accinterface | accstrictfp);
if ((realmodifiers & unexpectedmodifiers) != 0)
problemreporter().illegalmodifierforlocalinterface(sourcetype);
*/
} else {
final int unexpected_modifiers = ~(classfileconstants.accpublic | classfileconstants.accabstract | classfileconstants.accinterface | classfileconstants.accstrictfp | classfileconstants.accannotation);
if ((realmodifiers & unexpected_modifiers) != 0) {
if ((realmodifiers & classfileconstants.accannotation) != 0)
problemreporter().illegalmodifierforannotationtype(sourcetype);
else
problemreporter().illegalmodifierforinterface(sourcetype);
}
}
/*
* accsynthetic must be set if the target is greater than 1.5. 1.5 vm don't support accsynthetics flag.
*/
if (sourcetype.sourcename == typeconstants.package_info_name && compileroptions().targetjdk > classfileconstants.jdk1_5) {
modifiers |= classfileconstants.accsynthetic;
}
modifiers |= classfileconstants.accabstract;
} else if ((realmodifiers & classfileconstants.accenum) != 0) {
// detect abnormal cases for enums
if (ismembertype) { // includes member types defined inside local types
final int unexpected_modifiers = ~(classfileconstants.accpublic | classfileconstants.accprivate | classfileconstants.accprotected | classfileconstants.accstatic | classfileconstants.accstrictfp | classfileconstants.accenum);
if ((realmodifiers & unexpected_modifiers) != 0) {
problemreporter().illegalmodifierformemberenum(sourcetype);
modifiers &= ~classfileconstants.accabstract; // avoid leaking abstract modifier
realmodifiers &= ~classfileconstants.accabstract;
//					modifiers &= ~(realmodifiers & unexpected_modifiers);
//					realmodifiers = modifiers & extracompilermodifiers.accjustflag;
}
} else if (sourcetype.islocaltype()) {
// each enum constant is an anonymous local type and its modifiers were already checked as an enum constant field
} else {
final int unexpected_modifiers = ~(classfileconstants.accpublic | classfileconstants.accstrictfp | classfileconstants.accenum);
if ((realmodifiers & unexpected_modifiers) != 0)
problemreporter().illegalmodifierforenum(sourcetype);
}
if (!sourcetype.isanonymoustype()) {
checkabstractenum: {
// does define abstract methods ?
if ((this.referencecontext.bits & astnode.hasabstractmethods) != 0) {
modifiers |= classfileconstants.accabstract;
break checkabstractenum;
}
// body of enum constant must implement any inherited abstract methods
// enum type needs to implement abstract methods if one of its constants does not supply a body
typedeclaration typedeclaration = this.referencecontext;
fielddeclaration[] fields = typedeclaration.fields;
int fieldslength = fields == null ? 0 : fields.length;
if (fieldslength == 0) break checkabstractenum; // has no constants so must implement the method itself
abstractmethoddeclaration[] methods = typedeclaration.methods;
int methodslength = methods == null ? 0 : methods.length;
// todo (kent) cannot tell that the superinterfaces are empty or that their methods are implemented
boolean definesabstractmethod = typedeclaration.superinterfaces != null;
for (int i = 0; i < methodslength && !definesabstractmethod; i++)
definesabstractmethod = methods[i].isabstract();
if (!definesabstractmethod) break checkabstractenum; // all methods have bodies
boolean needabstractbit = false;
for (int i = 0; i < fieldslength; i++) {
fielddeclaration fielddecl = fields[i];
if (fielddecl.getkind() == abstractvariabledeclaration.enum_constant) {
if (fielddecl.initialization instanceof qualifiedallocationexpression) {
needabstractbit = true;
} else {
break checkabstractenum;
}
}
}
// tag this enum as abstract since an abstract method must be implemented and all enum constants define an anonymous body
// as a result, each of its anonymous constants will see it as abstract and must implement each inherited abstract method
if (needabstractbit) {
modifiers |= classfileconstants.accabstract;
}
}
// final if no enum constant with anonymous body
checkfinalenum: {
typedeclaration typedeclaration = this.referencecontext;
fielddeclaration[] fields = typedeclaration.fields;
if (fields != null) {
for (int i = 0, fieldslength = fields.length; i < fieldslength; i++) {
fielddeclaration fielddecl = fields[i];
if (fielddecl.getkind() == abstractvariabledeclaration.enum_constant) {
if (fielddecl.initialization instanceof qualifiedallocationexpression) {
break checkfinalenum;
}
}
}
}
modifiers |= classfileconstants.accfinal;
}
}
} else {
// detect abnormal cases for classes
if (ismembertype) { // includes member types defined inside local types
final int unexpected_modifiers = ~(classfileconstants.accpublic | classfileconstants.accprivate | classfileconstants.accprotected | classfileconstants.accstatic | classfileconstants.accabstract | classfileconstants.accfinal | classfileconstants.accstrictfp);
if ((realmodifiers & unexpected_modifiers) != 0)
problemreporter().illegalmodifierformemberclass(sourcetype);
} else if (sourcetype.islocaltype()) {
final int unexpected_modifiers = ~(classfileconstants.accabstract | classfileconstants.accfinal | classfileconstants.accstrictfp);
if ((realmodifiers & unexpected_modifiers) != 0)
problemreporter().illegalmodifierforlocalclass(sourcetype);
} else {
final int unexpected_modifiers = ~(classfileconstants.accpublic | classfileconstants.accabstract | classfileconstants.accfinal | classfileconstants.accstrictfp);
if ((realmodifiers & unexpected_modifiers) != 0)
problemreporter().illegalmodifierforclass(sourcetype);
}

// check that final and abstract are not set together
if ((realmodifiers & (classfileconstants.accfinal | classfileconstants.accabstract)) == (classfileconstants.accfinal | classfileconstants.accabstract))
problemreporter().illegalmodifiercombinationfinalabstractforclass(sourcetype);
}

if (ismembertype) {
// test visibility modifiers inconsistency, isolate the accessors bits
if (enclosingtype.isinterface()) {
if ((realmodifiers & (classfileconstants.accprotected | classfileconstants.accprivate)) != 0) {
problemreporter().illegalvisibilitymodifierforinterfacemembertype(sourcetype);

// need to keep the less restrictive
if ((realmodifiers & classfileconstants.accprotected) != 0)
modifiers &= ~classfileconstants.accprotected;
if ((realmodifiers & classfileconstants.accprivate) != 0)
modifiers &= ~classfileconstants.accprivate;
}
} else {
int accessorbits = realmodifiers & (classfileconstants.accpublic | classfileconstants.accprotected | classfileconstants.accprivate);
if ((accessorbits & (accessorbits - 1)) > 1) {
problemreporter().illegalvisibilitymodifiercombinationformembertype(sourcetype);

// need to keep the less restrictive so disable protected/private as necessary
if ((accessorbits & classfileconstants.accpublic) != 0) {
if ((accessorbits & classfileconstants.accprotected) != 0)
modifiers &= ~classfileconstants.accprotected;
if ((accessorbits & classfileconstants.accprivate) != 0)
modifiers &= ~classfileconstants.accprivate;
} else if ((accessorbits & classfileconstants.accprotected) != 0 && (accessorbits & classfileconstants.accprivate) != 0) {
modifiers &= ~classfileconstants.accprivate;
}
}
}

// static modifier test
if ((realmodifiers & classfileconstants.accstatic) == 0) {
if (enclosingtype.isinterface())
modifiers |= classfileconstants.accstatic;
} else if (!enclosingtype.isstatic()) {
// error the enclosing type of a static field must be static or a top-level type
problemreporter().illegalstaticmodifierformembertype(sourcetype);
}
}

sourcetype.modifiers = modifiers;
}

/* this method checks the modifiers of a field.
*
* 9.3 & 8.3
* need to integrate the check for the final modifiers for nested types
*
* note : a scope is accessible by : fieldbinding.declaringclass.scope
*/
private void checkandsetmodifiersforfield(fieldbinding fieldbinding, fielddeclaration fielddecl) {
int modifiers = fieldbinding.modifiers;
final referencebinding declaringclass = fieldbinding.declaringclass;
if ((modifiers & extracompilermodifiers.accalternatemodifierproblem) != 0)
problemreporter().duplicatemodifierforfield(declaringclass, fielddecl);

if (declaringclass.isinterface()) {
final int implicit_modifiers = classfileconstants.accpublic | classfileconstants.accstatic | classfileconstants.accfinal;
// set the modifiers
modifiers |= implicit_modifiers;

// and then check that they are the only ones
if ((modifiers & extracompilermodifiers.accjustflag) != implicit_modifiers) {
if ((declaringclass.modifiers  & classfileconstants.accannotation) != 0)
problemreporter().illegalmodifierforannotationfield(fielddecl);
else
problemreporter().illegalmodifierforinterfacefield(fielddecl);
}
fieldbinding.modifiers = modifiers;
return;
} else if (fielddecl.getkind() == abstractvariabledeclaration.enum_constant) {
// check that they are not modifiers in source
if ((modifiers & extracompilermodifiers.accjustflag) != 0)
problemreporter().illegalmodifierforenumconstant(declaringclass, fielddecl);

// set the modifiers
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=267670. force all enumerators to be marked
// as used locally. we are unable to track the usage of these reliably as they could be used
// in non obvious ways via the synthesized methods values() and valueof(string) or by using
// enum.valueof(class<t>, string).
final int implicit_modifiers = classfileconstants.accpublic | classfileconstants.accstatic | classfileconstants.accfinal | classfileconstants.accenum | extracompilermodifiers.acclocallyused;
fieldbinding.modifiers|= implicit_modifiers;
return;
}

// after this point, tests on the 16 bits reserved.
int realmodifiers = modifiers & extracompilermodifiers.accjustflag;
final int unexpected_modifiers = ~(classfileconstants.accpublic | classfileconstants.accprivate | classfileconstants.accprotected | classfileconstants.accfinal | classfileconstants.accstatic | classfileconstants.acctransient | classfileconstants.accvolatile);
if ((realmodifiers & unexpected_modifiers) != 0) {
problemreporter().illegalmodifierforfield(declaringclass, fielddecl);
modifiers &= ~extracompilermodifiers.accjustflag | ~unexpected_modifiers;
}

int accessorbits = realmodifiers & (classfileconstants.accpublic | classfileconstants.accprotected | classfileconstants.accprivate);
if ((accessorbits & (accessorbits - 1)) > 1) {
problemreporter().illegalvisibilitymodifiercombinationforfield(declaringclass, fielddecl);

// need to keep the less restrictive so disable protected/private as necessary
if ((accessorbits & classfileconstants.accpublic) != 0) {
if ((accessorbits & classfileconstants.accprotected) != 0)
modifiers &= ~classfileconstants.accprotected;
if ((accessorbits & classfileconstants.accprivate) != 0)
modifiers &= ~classfileconstants.accprivate;
} else if ((accessorbits & classfileconstants.accprotected) != 0 && (accessorbits & classfileconstants.accprivate) != 0) {
modifiers &= ~classfileconstants.accprivate;
}
}

if ((realmodifiers & (classfileconstants.accfinal | classfileconstants.accvolatile)) == (classfileconstants.accfinal | classfileconstants.accvolatile))
problemreporter().illegalmodifiercombinationfinalvolatileforfield(declaringclass, fielddecl);

if (fielddecl.initialization == null && (modifiers & classfileconstants.accfinal) != 0)
modifiers |= extracompilermodifiers.accblankfinal;
fieldbinding.modifiers = modifiers;
}

public void checkparameterizedsupertypecollisions() {
// check for parameterized interface collisions (when different parameterizations occur)
sourcetypebinding sourcetype = this.referencecontext.binding;
referencebinding[] interfaces = sourcetype.superinterfaces;
map invocations = new hashmap(2);
referencebinding itssuperclass = sourcetype.isinterface() ? null : sourcetype.superclass;
nextinterface: for (int i = 0, length = interfaces.length; i < length; i++) {
referencebinding one =  interfaces[i];
if (one == null) continue nextinterface;
if (itssuperclass != null && haserasedcandidatescollisions(itssuperclass, one, invocations, sourcetype, this.referencecontext))
continue nextinterface;
nextotherinterface: for (int j = 0; j < i; j++) {
referencebinding two = interfaces[j];
if (two == null) continue nextotherinterface;
if (haserasedcandidatescollisions(one, two, invocations, sourcetype, this.referencecontext))
continue nextinterface;
}
}

typeparameter[] typeparameters = this.referencecontext.typeparameters;
nextvariable : for (int i = 0, paramlength = typeparameters == null ? 0 : typeparameters.length; i < paramlength; i++) {
typeparameter typeparameter = typeparameters[i];
typevariablebinding typevariable = typeparameter.binding;
if (typevariable == null || !typevariable.isvalidbinding()) continue nextvariable;

typereference[] boundrefs = typeparameter.bounds;
if (boundrefs != null) {
boolean checksuperclass = typevariable.firstbound == typevariable.superclass;
for (int j = 0, boundlength = boundrefs.length; j < boundlength; j++) {
typereference typeref = boundrefs[j];
typebinding supertype = typeref.resolvedtype;
if (supertype == null || !supertype.isvalidbinding()) continue;

// check against superclass
if (checksuperclass)
if (haserasedcandidatescollisions(supertype, typevariable.superclass, invocations, typevariable, typeref))
continue nextvariable;
// check against superinterfaces
for (int index = typevariable.superinterfaces.length; --index >= 0;)
if (haserasedcandidatescollisions(supertype, typevariable.superinterfaces[index], invocations, typevariable, typeref))
continue nextvariable;
}
}
}

referencebinding[] membertypes = this.referencecontext.binding.membertypes;
if (membertypes != null && membertypes != binding.no_member_types)
for (int i = 0, size = membertypes.length; i < size; i++)
((sourcetypebinding) membertypes[i]).scope.checkparameterizedsupertypecollisions();
}

private void checkforinheritedmembertypes(sourcetypebinding sourcetype) {
// search up the hierarchy of the sourcetype to see if any supertype defines a member type
// when no member types are defined, tag the sourcetype & each supertype with the hasnomembertypes bit
// assumes super types have already been checked & tagged
referencebinding currenttype = sourcetype;
referencebinding[] interfacestovisit = null;
int nextposition = 0;
do {
if (currenttype.hasmembertypes()) // avoid resolving member types eagerly
return;

referencebinding[] itsinterfaces = currenttype.superinterfaces();
// in code assist cases when source types are added late, may not be finished connecting hierarchy
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
if (interfacestovisit == null) {
interfacestovisit = itsinterfaces;
nextposition = interfacestovisit.length;
} else {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
} while ((currenttype = currenttype.superclass()) != null && (currenttype.tagbits & tagbits.hasnomembertypes) == 0);

if (interfacestovisit != null) {
// contains the interfaces between the sourcetype and any superclass, which was tagged as having no member types
boolean needtotag = false;
for (int i = 0; i < nextposition; i++) {
referencebinding aninterface = interfacestovisit[i];
if ((aninterface.tagbits & tagbits.hasnomembertypes) == 0) { // skip interface if it already knows it has no member types
if (aninterface.hasmembertypes()) // avoid resolving member types eagerly
return;

needtotag = true;
referencebinding[] itsinterfaces = aninterface.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
int itslength = itsinterfaces.length;
if (nextposition + itslength >= interfacestovisit.length)
system.arraycopy(interfacestovisit, 0, interfacestovisit = new referencebinding[nextposition + itslength + 5], 0, nextposition);
nextinterface : for (int a = 0; a < itslength; a++) {
referencebinding next = itsinterfaces[a];
for (int b = 0; b < nextposition; b++)
if (next == interfacestovisit[b]) continue nextinterface;
interfacestovisit[nextposition++] = next;
}
}
}
}

if (needtotag) {
for (int i = 0; i < nextposition; i++)
interfacestovisit[i].tagbits |= tagbits.hasnomembertypes;
}
}

// tag the sourcetype and all of its superclasses, unless they have already been tagged
currenttype = sourcetype;
do {
currenttype.tagbits |= tagbits.hasnomembertypes;
} while ((currenttype = currenttype.superclass()) != null && (currenttype.tagbits & tagbits.hasnomembertypes) == 0);
}

// perform deferred bound checks for parameterized type references (only done after hierarchy is connected)
public void  checkparameterizedtypebounds() {
for (int i = 0, l = this.deferredboundchecks == null ? 0 : this.deferredboundchecks.size(); i < l; i++)
((typereference) this.deferredboundchecks.get(i)).checkbounds(this);
this.deferredboundchecks = null;

referencebinding[] membertypes = this.referencecontext.binding.membertypes;
if (membertypes != null && membertypes != binding.no_member_types)
for (int i = 0, size = membertypes.length; i < size; i++)
((sourcetypebinding) membertypes[i]).scope.checkparameterizedtypebounds();
}

private void connectmembertypes() {
sourcetypebinding sourcetype = this.referencecontext.binding;
referencebinding[] membertypes = sourcetype.membertypes;
if (membertypes != null && membertypes != binding.no_member_types) {
for (int i = 0, size = membertypes.length; i < size; i++)
((sourcetypebinding) membertypes[i]).scope.connecttypehierarchy();
}
}
/*
our current belief based on available jck tests is:
inherited member types are visible as a potential superclass.
inherited interfaces are not visible when defining a superinterface.

error recovery story:
ensure the superclass is set to java.lang.object if a problem is detected
resolving the superclass.

answer false if an error was reported against the sourcetype.
*/
private boolean connectsuperclass() {
sourcetypebinding sourcetype = this.referencecontext.binding;
if (sourcetype.id == typeids.t_javalangobject) { // handle the case of redefining java.lang.object up front
sourcetype.superclass = null;
sourcetype.superinterfaces = binding.no_superinterfaces;
if (!sourcetype.isclass())
problemreporter().objectmustbeclass(sourcetype);
if (this.referencecontext.superclass != null || (this.referencecontext.superinterfaces != null && this.referencecontext.superinterfaces.length > 0))
problemreporter().objectcannothavesupertypes(sourcetype);
return true; // do not propagate object's hierarchy problems down to every subtype
}
if (this.referencecontext.superclass == null) {
if (sourcetype.isenum() && compileroptions().sourcelevel >= classfileconstants.jdk1_5) // do not connect if source < 1.5 as enum already got flagged as syntax error
return connectenumsuperclass();
sourcetype.superclass = getjavalangobject();
return !detecthierarchycycle(sourcetype, sourcetype.superclass, null);
}
typereference superclassref = this.referencecontext.superclass;
referencebinding superclass = findsupertype(superclassref);
if (superclass != null) { // is null if a cycle was detected cycle or a problem
if (!superclass.isclass() && (superclass.tagbits & tagbits.hasmissingtype) == 0) {
problemreporter().superclassmustbeaclass(sourcetype, superclassref, superclass);
} else if (superclass.isfinal()) {
problemreporter().classextendfinalclass(sourcetype, superclassref, superclass);
} else if ((superclass.tagbits & tagbits.hasdirectwildcard) != 0) {
problemreporter().supertypecannotusewildcard(sourcetype, superclassref, superclass);
} else if (superclass.erasure().id == typeids.t_javalangenum) {
problemreporter().cannotextendenum(sourcetype, superclassref, superclass);
} else if ((superclass.tagbits & tagbits.hierarchyhasproblems) != 0
|| !superclassref.resolvedtype.isvalidbinding()) {
sourcetype.superclass = superclass;
sourcetype.tagbits |= tagbits.hierarchyhasproblems; // propagate if missing supertype
return superclassref.resolvedtype.isvalidbinding(); // reported some error against the source type ?
} else {
// only want to reach here when no errors are reported
sourcetype.superclass = superclass;
return true;
}
}
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
sourcetype.superclass = getjavalangobject();
if ((sourcetype.superclass.tagbits & tagbits.beginhierarchycheck) == 0)
detecthierarchycycle(sourcetype, sourcetype.superclass, null);
return false; // reported some error against the source type
}

/**
*  enum x (implicitly) extends enum<x>
*/
private boolean connectenumsuperclass() {
sourcetypebinding sourcetype = this.referencecontext.binding;
referencebinding rootenumtype = getjavalangenum();
boolean foundcycle = detecthierarchycycle(sourcetype, rootenumtype, null);
// arity check for well-known enum<e>
typevariablebinding[] reftypevariables = rootenumtype.typevariables();
if (reftypevariables == binding.no_type_variables) { // check generic
problemreporter().nongenerictypecannotbeparameterized(0, null, rootenumtype, new typebinding[]{ sourcetype });
return false; // cannot reach here as abortcompilation is thrown
} else if (1 != reftypevariables.length) { // check arity
problemreporter().incorrectarityforparameterizedtype(null, rootenumtype, new typebinding[]{ sourcetype });
return false; // cannot reach here as abortcompilation is thrown
}
// check argument type compatibility
parameterizedtypebinding  supertype = environment().createparameterizedtype(
rootenumtype,
new typebinding[]{
environment().converttorawtype(sourcetype, false /*do not force conversion of enclosing types*/),
} ,
null);
sourcetype.tagbits |= (supertype.tagbits & tagbits.hierarchyhasproblems); // propagate if missing supertpye
sourcetype.superclass = supertype;
// bound check (in case of bogus definition of enum type)
if (reftypevariables[0].boundcheck(supertype, sourcetype) != typeconstants.ok) {
problemreporter().typemismatcherror(rootenumtype, reftypevariables[0], sourcetype, null);
}
return !foundcycle;
}

/*
our current belief based on available jck 1.3 tests is:
inherited member types are visible as a potential superclass.
inherited interfaces are visible when defining a superinterface.

error recovery story:
ensure the superinterfaces contain only valid visible interfaces.

answer false if an error was reported against the sourcetype.
*/
private boolean connectsuperinterfaces() {
sourcetypebinding sourcetype = this.referencecontext.binding;
sourcetype.superinterfaces = binding.no_superinterfaces;
if (this.referencecontext.superinterfaces == null) {
if (sourcetype.isannotationtype() && compileroptions().sourcelevel >= classfileconstants.jdk1_5) { // do not connect if source < 1.5 as annotation already got flagged as syntax error) {
referencebinding annotationtype = getjavalangannotationannotation();
boolean foundcycle = detecthierarchycycle(sourcetype, annotationtype, null);
sourcetype.superinterfaces = new referencebinding[] { annotationtype };
return !foundcycle;
}
return true;
}
if (sourcetype.id == typeids.t_javalangobject) // already handled the case of redefining java.lang.object
return true;

boolean noproblems = true;
int length = this.referencecontext.superinterfaces.length;
referencebinding[] interfacebindings = new referencebinding[length];
int count = 0;
nextinterface : for (int i = 0; i < length; i++) {
typereference superinterfaceref = this.referencecontext.superinterfaces[i];
referencebinding superinterface = findsupertype(superinterfaceref);
if (superinterface == null) { // detected cycle
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
noproblems = false;
continue nextinterface;
}

// check for simple interface collisions
// check for a duplicate interface once the name is resolved, otherwise we may be confused (i.e. a.b.i and c.d.i)
for (int j = 0; j < i; j++) {
if (interfacebindings[j] == superinterface) {
problemreporter().duplicatesuperinterface(sourcetype, superinterfaceref, superinterface);
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
noproblems = false;
continue nextinterface;
}
}
if (!superinterface.isinterface() && (superinterface.tagbits & tagbits.hasmissingtype) == 0) {
problemreporter().superinterfacemustbeaninterface(sourcetype, superinterfaceref, superinterface);
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
noproblems = false;
continue nextinterface;
} else if (superinterface.isannotationtype()){
problemreporter().annotationtypeusedassuperinterface(sourcetype, superinterfaceref, superinterface);
}
if ((superinterface.tagbits & tagbits.hasdirectwildcard) != 0) {
problemreporter().supertypecannotusewildcard(sourcetype, superinterfaceref, superinterface);
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
noproblems = false;
continue nextinterface;
}
if ((superinterface.tagbits & tagbits.hierarchyhasproblems) != 0
|| !superinterfaceref.resolvedtype.isvalidbinding()) {
sourcetype.tagbits |= tagbits.hierarchyhasproblems; // propagate if missing supertype
noproblems &= superinterfaceref.resolvedtype.isvalidbinding();
}
// only want to reach here when no errors are reported
interfacebindings[count++] = superinterface;
}
// hold onto all correctly resolved superinterfaces
if (count > 0) {
if (count != length)
system.arraycopy(interfacebindings, 0, interfacebindings = new referencebinding[count], 0, count);
sourcetype.superinterfaces = interfacebindings;
}
return noproblems;
}

void connecttypehierarchy() {
sourcetypebinding sourcetype = this.referencecontext.binding;
if ((sourcetype.tagbits & tagbits.beginhierarchycheck) == 0) {
sourcetype.tagbits |= tagbits.beginhierarchycheck;
boolean noproblems = connectsuperclass();
noproblems &= connectsuperinterfaces();
sourcetype.tagbits |= tagbits.endhierarchycheck;
noproblems &= connecttypevariables(this.referencecontext.typeparameters, false);
sourcetype.tagbits |= tagbits.typevariablesareconnected;
if (noproblems && sourcetype.ishierarchyinconsistent())
problemreporter().hierarchyhasproblems(sourcetype);
}
connectmembertypes();
lookupenvironment env = environment();
try {
env.missingclassfilelocation = this.referencecontext;
checkforinheritedmembertypes(sourcetype);
} catch (abortcompilation e) {
e.updatecontext(this.referencecontext, referencecompilationunit().compilationresult);
throw e;
} finally {
env.missingclassfilelocation = null;
}
}

private void connecttypehierarchywithoutmembers() {
// must ensure the imports are resolved
if (this.parent instanceof compilationunitscope) {
if (((compilationunitscope) this.parent).imports == null)
((compilationunitscope) this.parent).checkandsetimports();
} else if (this.parent instanceof classscope) {
// ensure that the enclosing type has already been checked
((classscope) this.parent).connecttypehierarchywithoutmembers();
}

// double check that the hierarchy search has not already begun...
sourcetypebinding sourcetype = this.referencecontext.binding;
if ((sourcetype.tagbits & tagbits.beginhierarchycheck) != 0)
return;

sourcetype.tagbits |= tagbits.beginhierarchycheck;
boolean noproblems = connectsuperclass();
noproblems &= connectsuperinterfaces();
sourcetype.tagbits |= tagbits.endhierarchycheck;
noproblems &= connecttypevariables(this.referencecontext.typeparameters, false);
sourcetype.tagbits |= tagbits.typevariablesareconnected;
if (noproblems && sourcetype.ishierarchyinconsistent())
problemreporter().hierarchyhasproblems(sourcetype);
}

public boolean detecthierarchycycle(typebinding supertype, typereference reference) {
if (!(supertype instanceof referencebinding)) return false;

if (reference == this.supertypereference) { // see findsupertype()
if (supertype.istypevariable())
return false; // error case caught in resolvesupertype()
// abstract class x<k,v> implements java.util.map<k,v>
//    static abstract class m<k,v> implements entry<k,v>
if (supertype.isparameterizedtype())
supertype = ((parameterizedtypebinding) supertype).generictype();
compilationunitscope().recordsupertypereference(supertype); // to record supertypes
return detecthierarchycycle(this.referencecontext.binding, (referencebinding) supertype, reference);
}
// reinstate the code deleted by the fix for https://bugs.eclipse.org/bugs/show_bug.cgi?id=205235
// for details, see https://bugs.eclipse.org/bugs/show_bug.cgi?id=294057.
if ((supertype.tagbits & tagbits.beginhierarchycheck) == 0 && supertype instanceof sourcetypebinding)
// ensure if this is a source superclass that it has already been checked
((sourcetypebinding) supertype).scope.connecttypehierarchywithoutmembers();

return false;
}

// answer whether a cycle was found between the sourcetype & the supertype
private boolean detecthierarchycycle(sourcetypebinding sourcetype, referencebinding supertype, typereference reference) {
if (supertype.israwtype())
supertype = ((rawtypebinding) supertype).generictype();
// by this point the supertype must be a binary or source type

if (sourcetype == supertype) {
problemreporter().hierarchycircularity(sourcetype, supertype, reference);
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
return true;
}

if (supertype.ismembertype()) {
referencebinding current = supertype.enclosingtype();
do {
if (current.ishierarchybeingactivelyconnected() && current == sourcetype) {
problemreporter().hierarchycircularity(sourcetype, current, reference);
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
current.tagbits |= tagbits.hierarchyhasproblems;
return true;
}
} while ((current = current.enclosingtype()) != null);
}

if (supertype.isbinarybinding()) {
// force its superclass & superinterfaces to be found... 2 possibilities exist - the source type is included in the hierarchy of:
//		- a binary type... this case must be caught & reported here
//		- another source type... this case is reported against the other source type
boolean hascycle = false;
referencebinding parenttype = supertype.superclass();
if (parenttype != null) {
if (sourcetype == parenttype) {
problemreporter().hierarchycircularity(sourcetype, supertype, reference);
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
supertype.tagbits |= tagbits.hierarchyhasproblems;
return true;
}
if (parenttype.isparameterizedtype())
parenttype = ((parameterizedtypebinding) parenttype).generictype();
hascycle |= detecthierarchycycle(sourcetype, parenttype, reference);
if ((parenttype.tagbits & tagbits.hierarchyhasproblems) != 0) {
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
parenttype.tagbits |= tagbits.hierarchyhasproblems; // propagate down the hierarchy
}
}

referencebinding[] itsinterfaces = supertype.superinterfaces();
if (itsinterfaces != null && itsinterfaces != binding.no_superinterfaces) {
for (int i = 0, length = itsinterfaces.length; i < length; i++) {
referencebinding aninterface = itsinterfaces[i];
if (sourcetype == aninterface) {
problemreporter().hierarchycircularity(sourcetype, supertype, reference);
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
supertype.tagbits |= tagbits.hierarchyhasproblems;
return true;
}
if (aninterface.isparameterizedtype())
aninterface = ((parameterizedtypebinding) aninterface).generictype();
hascycle |= detecthierarchycycle(sourcetype, aninterface, reference);
if ((aninterface.tagbits & tagbits.hierarchyhasproblems) != 0) {
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
supertype.tagbits |= tagbits.hierarchyhasproblems;
}
}
}
return hascycle;
}

if (supertype.ishierarchybeingactivelyconnected()) {
org.eclipse.jdt.internal.compiler.ast.typereference ref = ((sourcetypebinding) supertype).scope.supertypereference;
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=133071
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=121734
if (ref != null && (ref.resolvedtype == null || ((referencebinding) ref.resolvedtype).ishierarchybeingactivelyconnected())) {
problemreporter().hierarchycircularity(sourcetype, supertype, reference);
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
supertype.tagbits |= tagbits.hierarchyhasproblems;
return true;
}
}
if ((supertype.tagbits & tagbits.beginhierarchycheck) == 0)
// ensure if this is a source superclass that it has already been checked
((sourcetypebinding) supertype).scope.connecttypehierarchywithoutmembers();
if ((supertype.tagbits & tagbits.hierarchyhasproblems) != 0)
sourcetype.tagbits |= tagbits.hierarchyhasproblems;
return false;
}

private referencebinding findsupertype(typereference typereference) {
compilationunitscope unitscope = compilationunitscope();
lookupenvironment env = unitscope.environment;
try {
env.missingclassfilelocation = typereference;
typereference.abouttoresolve(this); // allows us to trap completion & selection nodes
unitscope.recordqualifiedreference(typereference.gettypename());
this.supertypereference = typereference;
referencebinding supertype = (referencebinding) typereference.resolvesupertype(this);
return supertype;
} catch (abortcompilation e) {
sourcetypebinding sourcetype = this.referencecontext.binding;
if (sourcetype.superinterfaces == null)  sourcetype.superinterfaces = binding.no_superinterfaces; // be more resilient for hierarchies (144976)
e.updatecontext(typereference, referencecompilationunit().compilationresult);
throw e;
} finally {
env.missingclassfilelocation = null;
this.supertypereference = null;
}
}

/* answer the problem reporter to use for raising new problems.
*
* note that as a side-effect, this updates the current reference context
* (unit, type or method) in case the problem handler decides it is necessary
* to abort.
*/
public problemreporter problemreporter() {
methodscope outermethodscope;
if ((outermethodscope = outermostmethodscope()) == null) {
problemreporter problemreporter = referencecompilationunit().problemreporter;
problemreporter.referencecontext = this.referencecontext;
return problemreporter;
}
return outermethodscope.problemreporter();
}

/* answer the reference type of this scope.
* it is the nearest enclosing type of this scope.
*/
public typedeclaration referencetype() {
return this.referencecontext;
}

public string tostring() {
if (this.referencecontext != null)
return "--- class scope ---\n\n"  //$non-nls-1$
+ this.referencecontext.binding.tostring();
return "--- class scope ---\n\n binding not initialized" ; //$non-nls-1$
}
}
