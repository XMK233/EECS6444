/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

public abstract class numberliteral extends literal {

char[] source;

public numberliteral(char[] token, int s, int e) {
this(s,e) ;
this.source = token ;
}

public numberliteral(int s, int e) {
super (s,e) ;
}

public boolean isvalidjavastatement(){
return false ;
}

public char[] source(){
return this.source;
}
}
