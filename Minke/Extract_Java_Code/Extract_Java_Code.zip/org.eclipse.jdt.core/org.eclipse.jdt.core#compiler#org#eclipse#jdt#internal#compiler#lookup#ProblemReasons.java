/*******************************************************************************
* copyright (c) 2000, 2006 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

public interface problemreasons {
final int noerror = 0;
final int notfound = 1;
final int notvisible = 2;
final int ambiguous = 3;
final int internalnameprovided = 4; // used if an internal name is used in source
final int inheritednamehidesenclosingname = 5;
final int nonstaticreferenceinconstructorinvocation = 6;
final int nonstaticreferenceinstaticcontext = 7;
final int receivertypenotvisible = 8;
final int illegalsupertypevariable = 9;
final int parameterboundmismatch = 10; // for generic method
final int typeparameteraritymismatch = 11; // for generic method
final int parameterizedmethodtypemismatch = 12; // for generic method
final int typeargumentsforrawgenericmethod = 13; // for generic method
final int invalidtypeforstaticimport = 14;
}
