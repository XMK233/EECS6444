package org.eclipse.jdt.internal.compiler;

/*
* (c) copyright ibm corp. 2000, 2001.
* all rights reserved.
*/
import org.eclipse.jdt.internal.compiler.env.*;

public interface ihierarchyrequestor {
/**
* connect the supplied type to its superclass & superinterfaces.
* the superclass & superinterfaces are the identical binary or source types as
* supplied by the name environment.
*/

public void connect(igenerictype suppliedtype, igenerictype superclass, igenerictype[] superinterfaces);
}
