/*******************************************************************************
* copyright (c) 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist.impl;

import java.util.map;

import org.eclipse.core.runtime.iprogressmonitor;
import org.eclipse.jdt.core.icompilationunit;
import org.eclipse.jdt.core.iimportcontainer;
import org.eclipse.jdt.core.ipackagedeclaration;
import org.eclipse.jdt.core.itype;
import org.eclipse.jdt.core.javamodelexception;
import org.eclipse.jdt.core.workingcopyowner;
import org.eclipse.jdt.internal.core.compilationunit;
import org.eclipse.jdt.internal.core.javaelementinfo;
import org.eclipse.jdt.internal.core.packagefragment;

public class assistcompilationunit extends compilationunit {
private map infocache;
private map bindingcache;
public assistcompilationunit(icompilationunit compilationunit, workingcopyowner owner, map bindingcache, map infocache) {
super((packagefragment)compilationunit.getparent(), compilationunit.getelementname(), owner);
this.bindingcache = bindingcache;
this.infocache = infocache;
}

public object getelementinfo(iprogressmonitor monitor) throws javamodelexception {
return this.infocache.get(this);
}

public iimportcontainer getimportcontainer() {
return new assistimportcontainer(this, this.infocache);
}

public ipackagedeclaration getpackagedeclaration(string pkg) {
return new assistpackagedeclaration(this, pkg, this.infocache);
}

public itype gettype(string typename) {
return new assistsourcetype(this, typename, this.bindingcache, this.infocache);
}

public boolean haschildren() throws javamodelexception {
javaelementinfo info = (javaelementinfo)this.infocache.get(this);
return info.getchildren().length > 0;
}
}
