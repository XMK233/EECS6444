/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.lookup.*;


public class javadocreturnstatement extends returnstatement {

public javadocreturnstatement(int s, int e) {
super(null, s, e);
this.bits |= (astnode.insidejavadoc | astnode.empty);
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.statement#resolve(org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void resolve(blockscope scope) {
methodscope methodscope = scope.methodscope();
methodbinding methodbinding = null;
typebinding methodtype =
(methodscope.referencecontext instanceof abstractmethoddeclaration)
? ((methodbinding = ((abstractmethoddeclaration) methodscope.referencecontext).binding) == null
? null
: methodbinding.returntype)
: typebinding.void;
if (methodtype == null || methodtype == typebinding.void) {
scope.problemreporter().javadocunexpectedtag(this.sourcestart, this.sourceend);
} else if ((this.bits & astnode.empty) != 0) {
scope.problemreporter().javadocemptyreturntag(this.sourcestart, this.sourceend, scope.getdeclarationmodifiers());
}
}

/* (non-javadoc)
* @@see org.eclipse.jdt.internal.compiler.ast.statement#printstatement(int, java.lang.stringbuffer)
*/
public stringbuffer printstatement(int tab, stringbuffer output) {
printindent(tab, output).append("return"); //$non-nls-1$
if ((this.bits & astnode.empty) == 0)
output.append(' ').append(" <not empty>"); //$non-nls-1$
return output;
}

/* (non-javadoc)
* redefine to capture javadoc specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.astvisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(astvisitor visitor, blockscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
/* (non-javadoc)
* redefine to capture javadoc specific signatures
* @@see org.eclipse.jdt.internal.compiler.ast.astnode#traverse(org.eclipse.jdt.internal.compiler.astvisitor, org.eclipse.jdt.internal.compiler.lookup.blockscope)
*/
public void traverse(astvisitor visitor, classscope scope) {
visitor.visit(this, scope);
visitor.endvisit(this, scope);
}
}
