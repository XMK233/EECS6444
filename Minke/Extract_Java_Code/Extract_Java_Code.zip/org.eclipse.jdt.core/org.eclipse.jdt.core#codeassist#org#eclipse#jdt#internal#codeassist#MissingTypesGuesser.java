/*******************************************************************************
* copyright (c) 2006, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.codeassist;

import java.util.arraylist;
import java.util.hashmap;
import java.util.set;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.search.ijavasearchconstants;
import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.ast.*;
import org.eclipse.jdt.internal.compiler.env.accessrestriction;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.classscope;
import org.eclipse.jdt.internal.compiler.lookup.problemreasons;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.scope;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.util.hashtableofobjecttoint;
import org.eclipse.jdt.internal.core.searchableenvironment;

public class missingtypesguesser extends astvisitor {
public static interface guessedtyperequestor {
public void accept(
typebinding guessedtype,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends,
boolean hasproblems);

}

private static class resolutioncleaner extends astvisitor {
private hashtableofobjecttoint bitsmap = new hashtableofobjecttoint();
private boolean firstcall = true;

public resolutioncleaner(){
super();
}

private void cleanup(typereference typereference) {
if (this.firstcall) {
this.bitsmap.put(typereference, typereference.bits);
} else {
typereference.bits = this.bitsmap.get(typereference);
}
typereference.resolvedtype = null;
}

private void cleanup(parameterizedsingletypereference typereference) {
this.cleanup((typereference)typereference);
typereference.bits &= ~astnode.didresolve;
}

private void cleanup(parameterizedqualifiedtypereference typereference) {
this.cleanup((typereference)typereference);
typereference.bits &= ~astnode.didresolve;
}

public void cleanup(typereference convertedtype, blockscope scope) {
convertedtype.traverse(this, scope);
this.firstcall = false;
}

public void cleanup(typereference convertedtype, classscope scope) {
convertedtype.traverse(this, scope);
this.firstcall = false;
}

public boolean visit(singletypereference singletypereference, blockscope scope) {
this.cleanup(singletypereference);
return true;
}

public boolean visit(singletypereference singletypereference, classscope scope) {
this.cleanup(singletypereference);
return true;
}

public boolean visit(wildcard wildcard, blockscope scope) {
this.cleanup(wildcard);
return true;
}

public boolean visit(wildcard wildcard, classscope scope) {
this.cleanup(wildcard);
return true;
}

public boolean visit(arraytypereference arraytypereference, blockscope scope) {
this.cleanup(arraytypereference);
return true;
}

public boolean visit(arraytypereference arraytypereference, classscope scope) {
this.cleanup(arraytypereference);
return true;
}

public boolean visit(parameterizedsingletypereference parameterizedsingletypereference, blockscope scope) {
this.cleanup(parameterizedsingletypereference);
return true;
}

public boolean visit(parameterizedsingletypereference parameterizedsingletypereference, classscope scope) {
this.cleanup(parameterizedsingletypereference);
return true;
}

public boolean visit(qualifiedtypereference qualifiedtypereference, blockscope scope) {
this.cleanup(qualifiedtypereference);
return true;
}

public boolean visit(qualifiedtypereference qualifiedtypereference, classscope scope) {
this.cleanup(qualifiedtypereference);
return true;
}

public boolean visit(arrayqualifiedtypereference arrayqualifiedtypereference, blockscope scope) {
this.cleanup(arrayqualifiedtypereference);
return true;
}

public boolean visit(arrayqualifiedtypereference arrayqualifiedtypereference, classscope scope) {
this.cleanup(arrayqualifiedtypereference);
return true;
}

public boolean visit(parameterizedqualifiedtypereference parameterizedqualifiedtypereference, blockscope scope) {
this.cleanup(parameterizedqualifiedtypereference);
return true;
}

public boolean visit(parameterizedqualifiedtypereference parameterizedqualifiedtypereference, classscope scope) {
this.cleanup(parameterizedqualifiedtypereference);
return true;
}

}

private completionengine.completionproblemfactory problemfactory ;
private  searchableenvironment nameenvironment;

private hashmap substituedtypes;
private hashmap originaltypes;
private int combinationscount;

public missingtypesguesser(completionengine completionengine) {
this.problemfactory = completionengine.problemfactory;
this.nameenvironment = completionengine.nameenvironment;
}

private boolean computemissingelements(
qualifiedtypereference[] substituedtypenodes,
char[][][] originaltypenames,
binding[] missingelements,
int[] missingelementsstarts,
int[] missingelementsends) {
int length = substituedtypenodes.length;

for (int i = 0; i < length; i++) {
typereference substituedtype = substituedtypenodes[i];
if (substituedtype.resolvedtype == null) return false;
referencebinding erasure = (referencebinding)substituedtype.resolvedtype.leafcomponenttype().erasure();
binding missingelement;
int depthtoremove = originaltypenames[i].length - 1 ;
if (depthtoremove == 0) {
missingelement = erasure;
} else {
int depth = erasure.depth() + 1;

if (depth > depthtoremove) {
missingelement = erasure.enclosingtypeat(depthtoremove);
} else {
return false;
///////////////////////////////////////////////////////////
//// uncomment the following code to return missing package
///////////////////////////////////////////////////////////
//depthtoremove -= depth;
//packagebinding packagebinding = erasure.getpackage();
//while(depthtoremove > 0) {
//	packagebinding = packagebinding.parent;
//	depthtoremove--;
//}
//missingelement = packagebinding;
}
}

missingelements[i] = missingelement;
missingelementsstarts[i] = substituedtype.sourcestart;
missingelementsends[i] = substituedtype.sourceend + 1;

}

return true;
}

private typereference convert(arrayqualifiedtypereference typeref) {
if (typeref.resolvedtype != null) {
if (typeref.resolvedtype.isvalidbinding()) {
arrayqualifiedtypereference convertedtype =
new arrayqualifiedtypereference(
typeref.tokens,
typeref.dimensions(),
typeref.sourcepositions);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = typeref.sourceend;
return convertedtype;
} else if((typeref.resolvedtype.problemid() & problemreasons.notfound) != 0) {
// only the first token must be resolved
if(((referencebinding)typeref.resolvedtype.leafcomponenttype()).compoundname.length != 1) return null;

char[][] typename = typeref.gettypename();
char[][][] typenames = findtypenames(typename);
if(typenames == null || typenames.length == 0) return null;
arrayqualifiedtypereference convertedtype =
new arrayqualifiedtypereference(
typenames[0],
typeref.dimensions(),
new long[typenames[0].length]);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = (int)(typeref.sourcepositions[0] & 0x00000000ffffffffl);
this.substituedtypes.put(convertedtype, typenames);
this.originaltypes.put(convertedtype, typename);
this.combinationscount *= typenames.length;
return convertedtype;
}
}
return null;
}

private typereference convert(arraytypereference typeref) {
if (typeref.resolvedtype != null) {
if (typeref.resolvedtype.isvalidbinding()) {
arraytypereference convertedtype =
new arraytypereference(
typeref.token,
typeref.dimensions,
0);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = typeref.originalsourceend;
return convertedtype;
} else if((typeref.resolvedtype.problemid() & problemreasons.notfound) != 0) {
char[][] typename = typeref.gettypename();
char[][][] typenames = findtypenames(typename);
if(typenames == null || typenames.length == 0) return null;
arrayqualifiedtypereference convertedtype =
new arrayqualifiedtypereference(
typenames[0],
typeref.dimensions,
new long[typenames[0].length]);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = typeref.originalsourceend;
this.substituedtypes.put(convertedtype, typenames);
this.originaltypes.put(convertedtype, typename);
this.combinationscount *= typenames.length;
return convertedtype;
}
}
return null;
}

private typereference convert(parameterizedqualifiedtypereference typeref) {
if (typeref.resolvedtype != null) {
typereference[][] typearguments = typeref.typearguments;
int length = typearguments.length;
typereference[][] convertedtypearguments = new typereference[length][];
next : for (int i = 0; i < length; i++) {
if (typearguments[i] == null) continue next;
int length2 = typearguments[i].length;
convertedtypearguments[i] = new typereference[length2];
for (int j = 0; j < length2; j++) {
convertedtypearguments[i][j] = convert(typearguments[i][j]);
if (convertedtypearguments[i][j] == null) return null;
}
}

if (typeref.resolvedtype.isvalidbinding()) {
parameterizedqualifiedtypereference convertedtype =
new parameterizedqualifiedtypereference(
typeref.tokens,
convertedtypearguments,
typeref.dimensions(),
new long[typeref.tokens.length]);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = typeref.sourceend;
return convertedtype;
} else if((typeref.resolvedtype.problemid() & problemreasons.notfound) != 0) {
// only the first token must be resolved
if(((referencebinding)typeref.resolvedtype.leafcomponenttype()).compoundname.length != 1) return null;

char[][] typename = typeref.gettypename();
char[][][] typenames = findtypenames(typename);
if(typenames == null || typenames.length == 0) return null;

typereference[][] newconvertedtypearguments = new typereference[typenames[0].length][];
for (int k = newconvertedtypearguments.length - 1, l = convertedtypearguments.length -1; k > -1 && l > -1;) {
newconvertedtypearguments[k] = convertedtypearguments[l];
k--;
l--;
}

parameterizedqualifiedtypereference convertedtype =
new parameterizedqualifiedtypereference(
typenames[0],
newconvertedtypearguments,
typeref.dimensions(),
new long[typenames[0].length]);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = (int)(typeref.sourcepositions[0] & 0x00000000ffffffffl);
this.substituedtypes.put(convertedtype, typenames);
this.originaltypes.put(convertedtype, typename);
this.combinationscount *= typenames.length;
return convertedtype;
}
}
return null;
}

private typereference convert(parameterizedsingletypereference typeref) {
if (typeref.resolvedtype != null) {
typereference[] typearguments = typeref.typearguments;
int length = typearguments.length;
typereference[] convertedtypearguments = new typereference[length];
for (int i = 0; i < length; i++) {
convertedtypearguments[i] = convert(typearguments[i]);
if(convertedtypearguments[i] == null) return null;
}

if (typeref.resolvedtype.isvalidbinding()) {
parameterizedsingletypereference convertedtype =
new parameterizedsingletypereference(
typeref.token,
convertedtypearguments,
typeref.dimensions,
0);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = typeref.sourceend;
return convertedtype;
} else if((typeref.resolvedtype.problemid() & problemreasons.notfound) != 0) {
char[][] typename = typeref.gettypename();
char[][][] typenames = findtypenames(typename);
if(typenames == null || typenames.length == 0) return null;

typereference[][] allconvertedtypearguments = new typereference[typenames[0].length][];
allconvertedtypearguments[allconvertedtypearguments.length - 1] = convertedtypearguments;

parameterizedqualifiedtypereference convertedtype =
new parameterizedqualifiedtypereference(
typenames[0],
allconvertedtypearguments,
typeref.dimensions,
new long[typenames[0].length]);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = typeref.sourceend;
this.substituedtypes.put(convertedtype, typenames);
this.originaltypes.put(convertedtype, typename);
this.combinationscount *= typenames.length;
return convertedtype;
}
}
return null;
}

private typereference convert(qualifiedtypereference typeref) {
if (typeref.resolvedtype != null) {
if (typeref.resolvedtype.isvalidbinding()) {
qualifiedtypereference convertedtype = new qualifiedtypereference(typeref.tokens, typeref.sourcepositions);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = typeref.sourceend;
return convertedtype;
} else if((typeref.resolvedtype.problemid() & problemreasons.notfound) != 0) {
// only the first token must be resolved
if(((referencebinding)typeref.resolvedtype).compoundname.length != 1) return null;

char[][] typename = typeref.gettypename();
char[][][] typenames = findtypenames(typename);
if(typenames == null || typenames.length == 0) return null;
qualifiedtypereference convertedtype = new qualifiedtypereference(typenames[0], new long[typenames[0].length]);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = (int)(typeref.sourcepositions[0] & 0x00000000ffffffffl);
this.substituedtypes.put(convertedtype, typenames);
this.originaltypes.put(convertedtype, typename);
this.combinationscount *= typenames.length;
return convertedtype;
}
}
return null;
}

private typereference convert(singletypereference typeref) {
if (typeref.resolvedtype != null) {
if (typeref.resolvedtype.isvalidbinding()) {
singletypereference convertedtype = new singletypereference(typeref.token, 0);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = typeref.sourceend;
return convertedtype;
} else if((typeref.resolvedtype.problemid() & problemreasons.notfound) != 0) {
char[][] typename = typeref.gettypename();
char[][][] typenames = findtypenames(typename);
if(typenames == null || typenames.length == 0) return null;
qualifiedtypereference convertedtype = new qualifiedtypereference(typenames[0], new long[typenames[0].length]);
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = typeref.sourceend;
this.substituedtypes.put(convertedtype, typenames);
this.originaltypes.put(convertedtype, typename);
this.combinationscount *= typenames.length;
return convertedtype;
}
}
return null;
}

private typereference convert(typereference typeref) {
if (typeref instanceof parameterizedsingletypereference) {
return convert((parameterizedsingletypereference)typeref);
} else if(typeref instanceof parameterizedqualifiedtypereference) {
return convert((parameterizedqualifiedtypereference)typeref);
} else if (typeref instanceof arraytypereference) {
return convert((arraytypereference)typeref);
} else if(typeref instanceof arrayqualifiedtypereference) {
return convert((arrayqualifiedtypereference)typeref);
} else if(typeref instanceof wildcard) {
return convert((wildcard)typeref);
} else if (typeref instanceof singletypereference) {
return convert((singletypereference)typeref);
} else if (typeref instanceof qualifiedtypereference) {
return convert((qualifiedtypereference)typeref);
}
return null;
}

private typereference convert(wildcard typeref) {
typereference bound = typeref.bound;
typereference convertedbound = null;
if (bound != null) {
convertedbound = convert(bound);
if (convertedbound == null) return null;
}
wildcard convertedtype = new wildcard(typeref.kind);
convertedtype.bound = convertedbound;
convertedtype.sourcestart = typeref.sourcestart;
convertedtype.sourceend = typeref.sourceend;
return convertedtype;
}

private char[][][] findtypenames(char[][] missingtypename) {
char[] missingsimplename = missingtypename[missingtypename.length - 1];
final boolean isqualified = missingtypename.length > 1;
final char[] missingfullyqualifiedname =
isqualified ? charoperation.concatwith(missingtypename, '.') : null;
final arraylist results = new arraylist();
isearchrequestor storage = new isearchrequestor() {
public void acceptconstructor(
int modifiers,
char[] simpletypename,
int parametercount,
char[] signature,
char[][] parametertypes,
char[][] parameternames,
int typemodifiers,
char[] packagename,
int extraflags,
string path,
accessrestriction access) {
// constructors aren't searched
}
public void acceptpackage(char[] packagename) {
// package aren't searched
}
public void accepttype(
char[] packagename,
char[] typename,
char[][] enclosingtypenames,
int modifiers,
accessrestriction accessrestriction) {
char[] fullyqualifiedname = charoperation.concat(packagename, charoperation.concat(charoperation.concatwith(enclosingtypenames, '.'), typename, '.'), '.');
if (isqualified && !charoperation.endswith(fullyqualifiedname, missingfullyqualifiedname)) return;
char[][] compoundname = charoperation.spliton('.', fullyqualifiedname);
results.add(compoundname);
}

};
this.nameenvironment.findexacttypes(missingsimplename, true, ijavasearchconstants.type, storage);
if(results.size() == 0) return null;
return (char[][][])results.toarray(new char[results.size()][0][0]);
}

private char[][] getoriginal(typereference typeref) {
return (char[][])this.originaltypes.get(typeref);
}

private qualifiedtypereference[] getsubstituedtypes() {
set types = this.substituedtypes.keyset();
return (qualifiedtypereference[]) types.toarray(new qualifiedtypereference[types.size()]);
}

private char[][][] getsubstitution(typereference typeref) {
return (char[][][])this.substituedtypes.get(typeref);
}

public void guess(typereference typeref, scope scope, guessedtyperequestor requestor) {
this.substituedtypes = new hashmap();
this.originaltypes = new hashmap();
this.combinationscount = 1;

typereference convertedtype = convert(typeref);

if(convertedtype == null) return;

qualifiedtypereference[] substituedtypenodes = getsubstituedtypes();
int length = substituedtypenodes.length;

int[] substitutionsindexes = new int[substituedtypenodes.length];
char[][][][] subtitutions = new char[substituedtypenodes.length][][][];
char[][][] originaltypenames = new char[substituedtypenodes.length][][];
for (int i = 0; i < substituedtypenodes.length; i++) {
subtitutions[i] = getsubstitution(substituedtypenodes[i]);
originaltypenames[i] = getoriginal(substituedtypenodes[i]);
}

resolutioncleaner resolutioncleaner = new resolutioncleaner();
for (int i = 0; i < this.combinationscount; i++) {

nextsubstitution(substituedtypenodes, subtitutions, substitutionsindexes);


this.problemfactory.startcheckingproblems();
typebinding guessedtype = null;
switch (scope.kind) {
case scope.method_scope :
case scope.block_scope :
resolutioncleaner.cleanup(convertedtype, (blockscope)scope);
guessedtype = convertedtype.resolvetype((blockscope)scope);
break;
case scope.class_scope :
resolutioncleaner.cleanup(convertedtype, (classscope)scope);
guessedtype = convertedtype.resolvetype((classscope)scope);
break;
}
this.problemfactory.stopcheckingproblems();
if (!this.problemfactory.hasforbiddenproblems) {
if (guessedtype != null) {
binding[] missingelements = new binding[length];
int[] missingelementsstarts = new int[length];
int[] missingelementsends = new int[length];

if(computemissingelements(
substituedtypenodes,
originaltypenames,
missingelements,
missingelementsstarts,
missingelementsends)) {
requestor.accept(
guessedtype.capture(scope, typeref.sourceend),
missingelements,
missingelementsstarts,
missingelementsends,
this.problemfactory.hasallowedproblems);
}
}
}
}
}
private void nextsubstitution(
qualifiedtypereference[] substituedtypenodes,
char[][][][] subtitutions,
int[] substitutionsindexes) {
int length = substituedtypenodes.length;

done : for (int i = 0; i < length; i++) {
if(substitutionsindexes[i] < subtitutions[i].length - 1) {
substitutionsindexes[i]++;
break done;
} else {
substitutionsindexes[i] = 0;
}
}

for (int i = 0; i < length; i++) {
qualifiedtypereference qualifiedtypereference = substituedtypenodes[i];
qualifiedtypereference.tokens = subtitutions[i][substitutionsindexes[i]];
qualifiedtypereference.sourcepositions = new long[qualifiedtypereference.tokens.length];
if(qualifiedtypereference instanceof parameterizedqualifiedtypereference) {
parameterizedqualifiedtypereference parameterizedqualifiedtypereference =
(parameterizedqualifiedtypereference)qualifiedtypereference;
typereference[][] typearguments = parameterizedqualifiedtypereference.typearguments;
typereference[][] newtypearguments = new typereference[qualifiedtypereference.tokens.length][];
for (int j = newtypearguments.length - 1, k = typearguments.length -1; j > -1 && k > -1;) {
newtypearguments[j] = typearguments[k];
j--;
k--;
}
}
}
}
}
