/*******************************************************************************
* copyright (c) 2006, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.batch;

import java.io.file;
import java.io.inputstream;
import java.io.ioexception;
import java.util.zip.zipentry;

import org.eclipse.jdt.internal.compiler.env.accessruleset;
import org.eclipse.jdt.internal.compiler.env.nameenvironmentanswer;
import org.eclipse.jdt.internal.compiler.util.util;

public class classpathsourcejar extends classpathjar {
private string encoding;

public classpathsourcejar(file file, boolean closezipfileatend,
accessruleset accessruleset, string encoding,
string destinationpath) {
super(file, closezipfileatend, accessruleset, destinationpath);
this.encoding = encoding;
}

public nameenvironmentanswer findclass(char[] typename, string qualifiedpackagename, string qualifiedbinaryfilename, boolean asbinaryonly) {
if (!ispackage(qualifiedpackagename))
return null; // most common case

zipentry sourceentry = this.zipfile.getentry(qualifiedbinaryfilename.substring(0, qualifiedbinaryfilename.length() - 6)  + suffix_string_java);
if (sourceentry != null) {
try {
inputstream stream = null;
char[] contents = null;
try {
stream = this.zipfile.getinputstream(sourceentry);
contents = util.getinputstreamaschararray(stream, -1, this.encoding);
} finally {
if (stream != null)
stream.close();
}
return new nameenvironmentanswer(
new compilationunit(
contents,
qualifiedbinaryfilename.substring(0, qualifiedbinaryfilename.length() - 6) + suffix_string_java,
this.encoding,
this.destinationpath),
fetchaccessrestriction(qualifiedbinaryfilename));
} catch (ioexception e) {
// treat as if source file is missing
}
}
return null;
}
public nameenvironmentanswer findclass(char[] typename, string qualifiedpackagename, string qualifiedbinaryfilename) {
return findclass(typename, qualifiedpackagename, qualifiedbinaryfilename, false);
}
}
