/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*     tom tromey - contribution for bug 125961
*     tom tromey - contribution for bug 159641
*     benjamin muskalla - contribution for bug 239066
*     stephan herrmann  - contribution for bug 236385
*     stephan herrmann  - contribution for bug 295551
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.batch;

import java.io.bufferedinputstream;
import java.io.bytearrayinputstream;
import java.io.file;
import java.io.fileinputstream;
import java.io.filenotfoundexception;
import java.io.fileoutputstream;
import java.io.filenamefilter;
import java.io.ioexception;
import java.io.inputstreamreader;
import java.io.linenumberreader;
import java.io.outputstreamwriter;
import java.io.printwriter;
import java.io.stringreader;
import java.io.stringwriter;
import java.io.unsupportedencodingexception;
import java.lang.reflect.field;
import java.text.dateformat;
import java.text.messageformat;
import java.util.arraylist;
import java.util.arrays;
import java.util.comparator;
import java.util.date;
import java.util.hashmap;
import java.util.hashset;
import java.util.iterator;
import java.util.list;
import java.util.locale;
import java.util.map;
import java.util.missingresourceexception;
import java.util.properties;
import java.util.resourcebundle;
import java.util.set;
import java.util.stringtokenizer;

import org.eclipse.jdt.core.compiler.categorizedproblem;
import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.core.compiler.compilationprogress;
import org.eclipse.jdt.core.compiler.iproblem;
import org.eclipse.jdt.core.compiler.batch.batchcompiler;
import org.eclipse.jdt.internal.compiler.abstractannotationprocessormanager;
import org.eclipse.jdt.internal.compiler.classfile;
import org.eclipse.jdt.internal.compiler.compilationresult;
import org.eclipse.jdt.internal.compiler.compiler;
import org.eclipse.jdt.internal.compiler.icompilerrequestor;
import org.eclipse.jdt.internal.compiler.ierrorhandlingpolicy;
import org.eclipse.jdt.internal.compiler.iproblemfactory;
import org.eclipse.jdt.internal.compiler.batch.filesystem.classpath;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.env.accessrestriction;
import org.eclipse.jdt.internal.compiler.env.accessrule;
import org.eclipse.jdt.internal.compiler.env.accessruleset;
import org.eclipse.jdt.internal.compiler.env.icompilationunit;
import org.eclipse.jdt.internal.compiler.impl.compileroptions;
import org.eclipse.jdt.internal.compiler.impl.compilerstats;
import org.eclipse.jdt.internal.compiler.lookup.lookupenvironment;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.problem.defaultproblemfactory;
import org.eclipse.jdt.internal.compiler.problem.problemreporter;
import org.eclipse.jdt.internal.compiler.problem.problemseverities;
import org.eclipse.jdt.internal.compiler.util.genericxmlwriter;
import org.eclipse.jdt.internal.compiler.util.hashtableofint;
import org.eclipse.jdt.internal.compiler.util.hashtableofobject;
import org.eclipse.jdt.internal.compiler.util.messages;
import org.eclipse.jdt.internal.compiler.util.suffixconstants;
import org.eclipse.jdt.internal.compiler.util.util;

public class main implements problemseverities, suffixconstants {
public static class logger {
private printwriter err;
private printwriter log;
private main main;
private printwriter out;
private hashmap parameters;
int tagbits;
private static final string class = "class"; //$non-nls-1$
private static final string class_file = "classfile"; //$non-nls-1$
private static final string classpath = "classpath"; //$non-nls-1$
private static final string classpath_file = "file"; //$non-nls-1$
private static final string classpath_folder = "folder"; //$non-nls-1$
private static final string classpath_id = "id"; //$non-nls-1$
private static final string classpath_jar = "jar"; //$non-nls-1$
private static final string classpaths = "classpaths"; //$non-nls-1$
private static final string command_line_argument = "argument"; //$non-nls-1$
private static final string command_line_arguments = "command_line"; //$non-nls-1$
private static final string compiler = "compiler"; //$non-nls-1$
private static final string compiler_copyright = "copyright"; //$non-nls-1$
private static final string compiler_name = "name"; //$non-nls-1$
private static final string compiler_version = "version"; //$non-nls-1$
public static final int emacs = 2;
private static final string error = "error"; //$non-nls-1$
private static final string error_tag = "error"; //$non-nls-1$
private static final string warning_tag = "warning"; //$non-nls-1$
private static final string exception = "exception"; //$non-nls-1$
private static final string extra_problem_tag = "extra_problem"; //$non-nls-1$
private static final string extra_problems = "extra_problems"; //$non-nls-1$
private static final hashtableofint field_table = new hashtableofint();
private static final string key = "key"; //$non-nls-1$
private static final string message = "message"; //$non-nls-1$
private static final string number_of_classfiles = "number_of_classfiles"; //$non-nls-1$
private static final string number_of_errors = "errors"; //$non-nls-1$
private static final string number_of_lines = "number_of_lines"; //$non-nls-1$
private static final string number_of_problems = "problems"; //$non-nls-1$
private static final string number_of_tasks = "tasks"; //$non-nls-1$
private static final string number_of_warnings = "warnings"; //$non-nls-1$
private static final string option = "option"; //$non-nls-1$
private static final string options = "options"; //$non-nls-1$
private static final string output = "output"; //$non-nls-1$
private static final string package = "package"; //$non-nls-1$
private static final string path = "path"; //$non-nls-1$
private static final string problem_argument = "argument"; //$non-nls-1$
private static final string problem_argument_value = "value"; //$non-nls-1$
private static final string problem_arguments = "arguments"; //$non-nls-1$
private static final string problem_category_id = "categoryid"; //$non-nls-1$
private static final string id = "id"; //$non-nls-1$
private static final string problem_id = "problemid"; //$non-nls-1$
private static final string problem_line = "line"; //$non-nls-1$
private static final string problem_option_key = "optionkey"; //$non-nls-1$
private static final string problem_message = "message"; //$non-nls-1$
private static final string problem_severity = "severity"; //$non-nls-1$
private static final string problem_source_end = "charend"; //$non-nls-1$
private static final string problem_source_start = "charstart"; //$non-nls-1$
private static final string problem_summary = "problem_summary"; //$non-nls-1$
private static final string problem_tag = "problem"; //$non-nls-1$
private static final string problems = "problems"; //$non-nls-1$
private static final string source = "source"; //$non-nls-1$
private static final string source_context = "source_context"; //$non-nls-1$
private static final string source_end = "sourceend"; //$non-nls-1$
private static final string source_start = "sourcestart"; //$non-nls-1$
private static final string sources = "sources"; //$non-nls-1$

private static final string stats = "stats"; //$non-nls-1$

private static final string task = "task"; //$non-nls-1$
private static final string tasks = "tasks"; //$non-nls-1$
private static final string time = "time"; //$non-nls-1$
private static final string value = "value"; //$non-nls-1$
private static final string warning = "warning"; //$non-nls-1$
public static final int xml = 1;
private static final string xml_dtd_declaration = "<!doctype compiler public \"-//eclipse.org//dtd eclipse jdt 3.2.004 compiler//en\" \"http://www.eclipse.org/jdt/core/compiler_32_004.dtd\">"; //$non-nls-1$
static {
try {
class c = iproblem.class;
field[] fields = c.getfields();
for (int i = 0, max = fields.length; i < max; i++) {
field field = fields[i];
if (field.gettype().equals(integer.type)) {
integer value = (integer) field.get(null);
int key2 = value.intvalue() & iproblem.ignorecategoriesmask;
if (key2 == 0) {
key2 = integer.max_value;
}
logger.field_table.put(key2, field.getname());
}
}
} catch (securityexception e) {
e.printstacktrace();
} catch (illegalargumentexception e) {
e.printstacktrace();
} catch (illegalaccessexception e) {
e.printstacktrace();
}
}
public logger(main main, printwriter out, printwriter err) {
this.out = out;
this.err = err;
this.parameters = new hashmap();
this.main = main;
}

public string buildfilename(
string outputpath,
string relativefilename) {
char fileseparatorchar = file.separatorchar;
string fileseparator = file.separator;

outputpath = outputpath.replace('/', fileseparatorchar);
// to be able to pass the mkdirs() method we need to remove the extra file separator at the end of the outdir name
stringbuffer outdir = new stringbuffer(outputpath);
if (!outputpath.endswith(fileseparator)) {
outdir.append(fileseparator);
}
stringtokenizer tokenizer =
new stringtokenizer(relativefilename, fileseparator);
string token = tokenizer.nexttoken();
while (tokenizer.hasmoretokens()) {
outdir.append(token).append(fileseparator);
token = tokenizer.nexttoken();
}
// token contains the last one
return outdir.append(token).tostring();
}

public void close() {
if (this.log != null) {
if ((this.tagbits & logger.xml) != 0) {
endtag(logger.compiler);
flush();
}
this.log.close();
}
}

/**
*
*/
public void compiling() {
printlnout(this.main.bind("progress.compiling")); //$non-nls-1$
}
private void endloggingextraproblems() {
endtag(logger.extra_problems);
}
/**
* used to stop logging problems.
* only use in xml mode.
*/
private void endloggingproblems() {
endtag(logger.problems);
}
public void endloggingsource() {
if ((this.tagbits & logger.xml) != 0) {
endtag(logger.source);
}
}

public void endloggingsources() {
if ((this.tagbits & logger.xml) != 0) {
endtag(logger.sources);
}
}

public void endloggingtasks() {
if ((this.tagbits & logger.xml) != 0) {
endtag(logger.tasks);
}
}
private void endtag(string name) {
if (this.log != null) {
((genericxmlwriter) this.log).endtag(name, true, true);
}
}
private string errorreportsource(categorizedproblem problem, char[] unitsource, int bits) {
//extra from the source the innacurate     token
//and "highlight" it using some underneath ^^^^^
//put some context around too.

//this code assumes that the font used in the console is fixed size

//sanity .....
int startposition = problem.getsourcestart();
int endposition = problem.getsourceend();
if (unitsource == null) {
if (problem.getoriginatingfilename() != null) {
try {
unitsource = util.getfilecharcontent(new file(new string(problem.getoriginatingfilename())), null);
} catch (ioexception e) {
// ignore;
}
}
}
int length = unitsource == null ? 0 : unitsource.length;
if ((startposition > endposition)
|| ((startposition < 0) && (endposition < 0))
|| length == 0)
return messages.problem_nosourceinformation;

stringbuffer errorbuffer = new stringbuffer();
if ((bits & main.logger.emacs) == 0) {
errorbuffer.append(' ').append(messages.bind(messages.problem_atline, string.valueof(problem.getsourcelinenumber())));
errorbuffer.append(util.line_separator);
}
errorbuffer.append('\t');

char c;
final char space = '\u0020';
final char mark = '^';
final char tab = '\t';
//the next code tries to underline the token.....
//it assumes (for a good display) that token source does not
//contain any \r \n. this is false on statements !
//(the code still works but the display is not optimal !)

// expand to line limits
int begin;
int end;
for (begin = startposition >= length ? length - 1 : startposition; begin > 0; begin--) {
if ((c = unitsource[begin - 1]) == '\n' || c == '\r') break;
}
for (end = endposition >= length ? length - 1 : endposition ; end+1 < length; end++) {
if ((c = unitsource[end + 1]) == '\r' || c == '\n') break;
}

// trim left and right spaces/tabs
while ((c = unitsource[begin]) == ' ' || c == '\t') begin++;
//while ((c = unitsource[end]) == ' ' || c == '\t') end--; todo (philippe) should also trim right, but all tests are to be updated

// copy source
errorbuffer.append(unitsource, begin, end-begin+1);
errorbuffer.append(util.line_separator).append("\t"); //$non-nls-1$

// compute underline
for (int i = begin; i <startposition; i++) {
errorbuffer.append((unitsource[i] == tab) ? tab : space);
}
for (int i = startposition; i <= (endposition >= length ? length - 1 : endposition); i++) {
errorbuffer.append(mark);
}
return errorbuffer.tostring();
}

private void extractcontext(categorizedproblem problem, char[] unitsource) {
//sanity .....
int startposition = problem.getsourcestart();
int endposition = problem.getsourceend();
if (unitsource == null) {
if (problem.getoriginatingfilename() != null) {
try {
unitsource = util.getfilecharcontent(new file(new string(problem.getoriginatingfilename())), null);
} catch(ioexception e) {
// ignore
}
}
}
int length = unitsource== null ? 0 : unitsource.length;
if ((startposition > endposition)
|| ((startposition < 0) && (endposition < 0))
|| (length <= 0)
|| (endposition > length)) {
this.parameters.put(logger.value, messages.problem_nosourceinformation);
this.parameters.put(logger.source_start, "-1"); //$non-nls-1$
this.parameters.put(logger.source_end, "-1"); //$non-nls-1$
printtag(logger.source_context, this.parameters, true, true);
return;
}

char c;
//the next code tries to underline the token.....
//it assumes (for a good display) that token source does not
//contain any \r \n. this is false on statements !
//(the code still works but the display is not optimal !)

// expand to line limits
int begin, end;
for (begin = startposition >= length ? length - 1 : startposition; begin > 0; begin--) {
if ((c = unitsource[begin - 1]) == '\n' || c == '\r') break;
}
for (end = endposition >= length ? length - 1 : endposition ; end+1 < length; end++) {
if ((c = unitsource[end + 1]) == '\r' || c == '\n') break;
}

// trim left and right spaces/tabs
while ((c = unitsource[begin]) == ' ' || c == '\t') begin++;
while ((c = unitsource[end]) == ' ' || c == '\t') end--;

// copy source
stringbuffer buffer = new stringbuffer();
buffer.append(unitsource, begin, end - begin + 1);

this.parameters.put(logger.value, string.valueof(buffer));
this.parameters.put(logger.source_start, integer.tostring(startposition - begin));
this.parameters.put(logger.source_end, integer.tostring(endposition - begin));
printtag(logger.source_context, this.parameters, true, true);
}
public void flush() {
this.out.flush();
this.err.flush();
if (this.log != null) {
this.log.flush();
}
}

private string getfieldname(int id) {
int key2 = id & iproblem.ignorecategoriesmask;
if (key2 == 0) {
key2 = integer.max_value;
}
return (string) logger.field_table.get(key2);
}

// find out an option name controlling a given problemid
private string getproblemoptionkey(int problemid) {
int irritant = problemreporter.getirritant(problemid);
return compileroptions.optionkeyfromirritant(irritant);
}

public void logaverage() {
arrays.sort(this.main.compilerstats);
long linecount = this.main.compilerstats[0].linecount;
final int length = this.main.maxrepetition;
long sum = 0;
long parsesum = 0, resolvesum = 0, analyzesum = 0, generatesum = 0;
for (int i = 1, max = length - 1; i < max; i++) {
compilerstats stats = this.main.compilerstats[i];
sum += stats.elapsedtime();
parsesum += stats.parsetime;
resolvesum += stats.resolvetime;
analyzesum += stats.analyzetime;
generatesum += stats.generatetime;
}
long time = sum / (length - 2);
long parsetime = parsesum/(length - 2);
long resolvetime = resolvesum/(length - 2);
long analyzetime = analyzesum/(length - 2);
long generatetime = generatesum/(length - 2);
printlnout(this.main.bind(
"compile.averagetime", //$non-nls-1$
new string[] {
string.valueof(linecount),
string.valueof(time),
string.valueof(((int) (linecount * 10000.0 / time)) / 10.0),
}));
if ((this.main.timing & main.timing_detailed) != 0) {
printlnout(
this.main.bind("compile.detailedtime", //$non-nls-1$
new string[] {
string.valueof(parsetime),
string.valueof(((int) (parsetime * 1000.0 / time)) / 10.0),
string.valueof(resolvetime),
string.valueof(((int) (resolvetime * 1000.0 / time)) / 10.0),
string.valueof(analyzetime),
string.valueof(((int) (analyzetime * 1000.0 / time)) / 10.0),
string.valueof(generatetime),
string.valueof(((int) (generatetime * 1000.0 / time)) / 10.0),
}));
}
}
public void logclassfile(boolean generatepackagesstructure, string outputpath, string relativefilename) {
if ((this.tagbits & logger.xml) != 0) {
string filename = null;
if (generatepackagesstructure) {
filename = buildfilename(outputpath, relativefilename);
} else {
char fileseparatorchar = file.separatorchar;
string fileseparator = file.separator;
// first we ensure that the outputpath exists
outputpath = outputpath.replace('/', fileseparatorchar);
// to be able to pass the mkdirs() method we need to remove the extra file separator at the end of the outdir name
int indexofpackageseparator = relativefilename.lastindexof(fileseparatorchar);
if (indexofpackageseparator == -1) {
if (outputpath.endswith(fileseparator)) {
filename = outputpath + relativefilename;
} else {
filename = outputpath + fileseparator + relativefilename;
}
} else {
int length = relativefilename.length();
if (outputpath.endswith(fileseparator)) {
filename = outputpath + relativefilename.substring(indexofpackageseparator + 1, length);
} else {
filename = outputpath + fileseparator + relativefilename.substring(indexofpackageseparator + 1, length);
}
}
}
file f = new file(filename);
try {
this.parameters.put(logger.path, f.getcanonicalpath());
printtag(logger.class_file, this.parameters, true, true);
} catch (ioexception e) {
lognoclassfilecreated(outputpath, relativefilename, e);
}
}
}
public void logclasspath(filesystem.classpath[] classpaths) {
if (classpaths == null) return;
if ((this.tagbits & logger.xml) != 0) {
final int length = classpaths.length;
if (length != 0) {
// generate xml output
printtag(logger.classpaths, null, true, false);
for (int i = 0; i < length; i++) {
string classpath = classpaths[i].getpath();
this.parameters.put(logger.path, classpath);
file f = new file(classpath);
string id = null;
if (f.isfile()) {
if (util.ispotentialziparchive(classpath)) {
id = logger.classpath_jar;
} else {
id = logger.classpath_file;
}
} else if (f.isdirectory()) {
id = logger.classpath_folder;
}
if (id != null) {
this.parameters.put(logger.classpath_id, id);
printtag(logger.classpath, this.parameters, true, true);
}
}
endtag(logger.classpaths);
}
}

}

public void logcommandlinearguments(string[] commandlinearguments) {
if (commandlinearguments == null) return;
if ((this.tagbits & logger.xml) != 0) {
final int length = commandlinearguments.length;
if (length != 0) {
// generate xml output
printtag(logger.command_line_arguments, null, true, false);
for (int i = 0; i < length; i++) {
this.parameters.put(logger.value, commandlinearguments[i]);
printtag(logger.command_line_argument, this.parameters, true, true);
}
endtag(logger.command_line_arguments);
}
}
}

/**
* @@param e the given exception to log
*/
public void logexception(exception e) {
stringwriter writer = new stringwriter();
printwriter printwriter = new printwriter(writer);
e.printstacktrace(printwriter);
printwriter.flush();
printwriter.close();
final string stacktrace = writer.tostring();
if ((this.tagbits & logger.xml) != 0) {
linenumberreader reader = new linenumberreader(new stringreader(stacktrace));
string line;
int i = 0;
stringbuffer buffer = new stringbuffer();
string message = e.getmessage();
if (message != null) {
buffer.append(message).append(util.line_separator);
}
try {
while ((line = reader.readline()) != null && i < 4) {
buffer.append(line).append(util.line_separator);
i++;
}
reader.close();
} catch (ioexception e1) {
// ignore
}
message = buffer.tostring();
this.parameters.put(logger.message, message);
this.parameters.put(logger.class, e.getclass());
printtag(logger.exception, this.parameters, true, true);
}
string message = e.getmessage();
if (message == null) {
this.printlnerr(stacktrace);
} else {
this.printlnerr(message);
}
}

private void logextraproblem(categorizedproblem problem, int localerrorcount, int globalerrorcount) {
char[] originatingfilename = problem.getoriginatingfilename();
string filename =
originatingfilename == null
? this.main.bind("requestor.nofilenamespecified")//$non-nls-1$
: new string(originatingfilename);
if ((this.tagbits & logger.emacs) != 0) {
string result = filename
+ ":" //$non-nls-1$
+ problem.getsourcelinenumber()
+ ": " //$non-nls-1$
+ (problem.iserror() ? this.main.bind("output.emacs.error") : this.main.bind("output.emacs.warning")) //$non-nls-1$ //$non-nls-2$
+ ": " //$non-nls-1$
+ problem.getmessage();
this.printlnerr(result);
final string errorreportsource = errorreportsource(problem, null, this.tagbits);
this.printlnerr(errorreportsource);
} else {
if (localerrorcount == 0) {
this.printlnerr("----------"); //$non-nls-1$
}
printerr(problem.iserror() ?
this.main.bind(
"requestor.error", //$non-nls-1$
integer.tostring(globalerrorcount),
new string(filename))
: this.main.bind(
"requestor.warning", //$non-nls-1$
integer.tostring(globalerrorcount),
new string(filename)));
final string errorreportsource = errorreportsource(problem, null, 0);
this.printlnerr(errorreportsource);
this.printlnerr(problem.getmessage());
this.printlnerr("----------"); //$non-nls-1$
}
}

public void loggingextraproblems(main currentmain) {
arraylist problems = currentmain.extraproblems;
final int count = problems.size();
int localerrorcount = 0;
int localproblemcount = 0;
if (count != 0) {
int errors = 0;
int warnings = 0;
for (int i = 0; i < count; i++) {
categorizedproblem problem = (categorizedproblem) problems.get(i);
if (problem != null) {
currentmain.globalproblemscount++;
logextraproblem(problem, localproblemcount, currentmain.globalproblemscount);
localproblemcount++;
if (problem.iserror()) {
localerrorcount++;
errors++;
currentmain.globalerrorscount++;
} else if (problem.iswarning()) {
currentmain.globalwarningscount++;
warnings++;
}
}
}
if ((this.tagbits & logger.xml) != 0) {
if ((errors + warnings) != 0) {
startloggingextraproblems(count);
for (int i = 0; i < count; i++) {
categorizedproblem problem = (categorizedproblem) problems.get(i);
if (problem!= null) {
if (problem.getid() != iproblem.task) {
logxmlextraproblem(problem, localproblemcount, currentmain.globalproblemscount);
}
}
}
endloggingextraproblems();
}
}
}
}

public void logincorrectvmversionforannotationprocessing() {
if ((this.tagbits & logger.xml) != 0) {
this.parameters.put(logger.message, this.main.bind("configure.incorrectvmversionforapt")); //$non-nls-1$
printtag(logger.error_tag, this.parameters, true, true);
}
this.printlnerr(this.main.bind("configure.incorrectvmversionforapt")); //$non-nls-1$
}

/**
*
*/
public void lognoclassfilecreated(string outputdir, string relativefilename, ioexception e) {
if ((this.tagbits & logger.xml) != 0) {
this.parameters.put(logger.message, this.main.bind("output.noclassfilecreated", //$non-nls-1$
new string[] {
outputdir,
relativefilename,
e.getmessage()
}));
printtag(logger.error_tag, this.parameters, true, true);
}
this.printlnerr(this.main.bind("output.noclassfilecreated", //$non-nls-1$
new string[] {
outputdir,
relativefilename,
e.getmessage()
}));
}

/**
* @@param exportedclassfilescounter
*/
public void lognumberofclassfilesgenerated(int exportedclassfilescounter) {
if ((this.tagbits & logger.xml) != 0) {
this.parameters.put(logger.value, new integer(exportedclassfilescounter));
printtag(logger.number_of_classfiles, this.parameters, true, true);
}
if (exportedclassfilescounter == 1) {
printlnout(this.main.bind("compile.oneclassfilegenerated")); //$non-nls-1$
} else {
printlnout(this.main.bind("compile.severalclassfilesgenerated", //$non-nls-1$
string.valueof(exportedclassfilescounter)));
}
}

/**
* @@param options the given compiler options
*/
public void logoptions(map options) {
if ((this.tagbits & logger.xml) != 0) {
printtag(logger.options, null, true, false);
final set entriesset = options.entryset();
object[] entries = entriesset.toarray();
arrays.sort(entries, new comparator() {
public int compare(object o1, object o2) {
map.entry entry1 = (map.entry) o1;
map.entry entry2 = (map.entry) o2;
return ((string) entry1.getkey()).compareto((string) entry2.getkey());
}
});
for (int i = 0, max = entries.length; i < max; i++) {
map.entry entry = (map.entry) entries[i];
string key = (string) entry.getkey();
this.parameters.put(logger.key, key);
this.parameters.put(logger.value, entry.getvalue());
printtag(logger.option, this.parameters, true, true);
}
endtag(logger.options);
}
}

/**
* @@param error the given error
*/
public void logpendingerror(string error) {
if ((this.tagbits & logger.xml) != 0) {
this.parameters.put(logger.message, error);
printtag(logger.error_tag, this.parameters, true, true);
}
this.printlnerr(error);
}

/**
* @@param message the given message
*/
public void logwarning(string message) {
if ((this.tagbits & logger.xml) != 0) {
this.parameters.put(logger.message, message);
printtag(logger.warning_tag, this.parameters, true, true);
}
this.printlnout(message);
}

private void logproblem(categorizedproblem problem, int localerrorcount,
int globalerrorcount, char[] unitsource) {
if ((this.tagbits & logger.emacs) != 0) {
string result = (new string(problem.getoriginatingfilename())
+ ":" //$non-nls-1$
+ problem.getsourcelinenumber()
+ ": " //$non-nls-1$
+ (problem.iserror() ? this.main.bind("output.emacs.error") : this.main.bind("output.emacs.warning")) //$non-nls-1$ //$non-nls-2$
+ ": " //$non-nls-1$
+ problem.getmessage());
this.printlnerr(result);
final string errorreportsource = errorreportsource(problem, unitsource, this.tagbits);
if (errorreportsource.length() != 0) this.printlnerr(errorreportsource);
} else {
if (localerrorcount == 0) {
this.printlnerr("----------"); //$non-nls-1$
}
printerr(problem.iserror() ?
this.main.bind(
"requestor.error", //$non-nls-1$
integer.tostring(globalerrorcount),
new string(problem.getoriginatingfilename()))
: this.main.bind(
"requestor.warning", //$non-nls-1$
integer.tostring(globalerrorcount),
new string(problem.getoriginatingfilename())));
try {
final string errorreportsource = errorreportsource(problem, unitsource, 0);
this.printlnerr(errorreportsource);
this.printlnerr(problem.getmessage());
} catch (exception e) {
this.printlnerr(this.main.bind(
"requestor.notretrieveerrormessage", problem.tostring())); //$non-nls-1$
}
this.printlnerr("----------"); //$non-nls-1$
}
}

public int logproblems(categorizedproblem[] problems, char[] unitsource, main currentmain) {
final int count = problems.length;
int localerrorcount = 0;
int localproblemcount = 0;
if (count != 0) {
int errors = 0;
int warnings = 0;
int tasks = 0;
for (int i = 0; i < count; i++) {
categorizedproblem problem = problems[i];
if (problem != null) {
currentmain.globalproblemscount++;
logproblem(problem, localproblemcount, currentmain.globalproblemscount, unitsource);
localproblemcount++;
if (problem.iserror()) {
localerrorcount++;
errors++;
currentmain.globalerrorscount++;
} else if (problem.getid() == iproblem.task) {
currentmain.globaltaskscount++;
tasks++;
} else {
currentmain.globalwarningscount++;
warnings++;
}
}
}
if ((this.tagbits & logger.xml) != 0) {
if ((errors + warnings) != 0) {
startloggingproblems(errors, warnings);
for (int i = 0; i < count; i++) {
categorizedproblem problem = problems[i];
if (problem!= null) {
if (problem.getid() != iproblem.task) {
logxmlproblem(problem, unitsource);
}
}
}
endloggingproblems();
}
if (tasks != 0) {
startloggingtasks(tasks);
for (int i = 0; i < count; i++) {
categorizedproblem problem = problems[i];
if (problem!= null) {
if (problem.getid() == iproblem.task) {
logxmltask(problem, unitsource);
}
}
}
endloggingtasks();
}
}
}
return localerrorcount;
}

/**
* @@param globalproblemscount
* @@param globalerrorscount
* @@param globalwarningscount
*/
public void logproblemssummary(int globalproblemscount,
int globalerrorscount, int globalwarningscount, int globaltaskscount) {
if ((this.tagbits & logger.xml) != 0) {
// generate xml
this.parameters.put(logger.number_of_problems, new integer(globalproblemscount));
this.parameters.put(logger.number_of_errors, new integer(globalerrorscount));
this.parameters.put(logger.number_of_warnings, new integer(globalwarningscount));
this.parameters.put(logger.number_of_tasks, new integer(globaltaskscount));
printtag(logger.problem_summary, this.parameters, true, true);
}
if (globalproblemscount == 1) {
string message = null;
if (globalerrorscount == 1) {
message = this.main.bind("compile.oneerror"); //$non-nls-1$
} else {
message = this.main.bind("compile.onewarning"); //$non-nls-1$
}
printerr(this.main.bind("compile.oneproblem", message)); //$non-nls-1$
} else {
string errormessage = null;
string warningmessage = null;
if (globalerrorscount > 0) {
if (globalerrorscount == 1) {
errormessage = this.main.bind("compile.oneerror"); //$non-nls-1$
} else {
errormessage = this.main.bind("compile.severalerrors", string.valueof(globalerrorscount)); //$non-nls-1$
}
}
int warningsnumber = globalwarningscount + globaltaskscount;
if (warningsnumber > 0) {
if (warningsnumber == 1) {
warningmessage = this.main.bind("compile.onewarning"); //$non-nls-1$
} else {
warningmessage = this.main.bind("compile.severalwarnings", string.valueof(warningsnumber)); //$non-nls-1$
}
}
if (errormessage == null || warningmessage == null) {
if (errormessage == null) {
printerr(this.main.bind(
"compile.severalproblemserrorsorwarnings", //$non-nls-1$
string.valueof(globalproblemscount),
warningmessage));
} else {
printerr(this.main.bind(
"compile.severalproblemserrorsorwarnings", //$non-nls-1$
string.valueof(globalproblemscount),
errormessage));
}
} else {
printerr(this.main.bind(
"compile.severalproblemserrorsandwarnings", //$non-nls-1$
new string[] {
string.valueof(globalproblemscount),
errormessage,
warningmessage
}));
}
}
if ((this.tagbits & logger.emacs) != 0) {
this.printlnerr();
}
}

/**
*
*/
public void logprogress() {
printout('.');
}

/**
* @@param i
*            the current repetition number
* @@param repetitions
*            the given number of repetitions
*/
public void logrepetition(int i, int repetitions) {
printlnout(this.main.bind("compile.repetition", //$non-nls-1$
string.valueof(i + 1), string.valueof(repetitions)));
}
/**
* @@param compilerstats
*/
public void logtiming(compilerstats compilerstats) {
long time = compilerstats.elapsedtime();
long linecount = compilerstats.linecount;
if ((this.tagbits & logger.xml) != 0) {
this.parameters.put(logger.value, new long(time));
printtag(logger.time, this.parameters, true, true);
this.parameters.put(logger.value, new long(linecount));
printtag(logger.number_of_lines, this.parameters, true, true);
}
if (linecount != 0) {
printlnout(
this.main.bind("compile.instanttime", //$non-nls-1$
new string[] {
string.valueof(linecount),
string.valueof(time),
string.valueof(((int) (linecount * 10000.0 / time)) / 10.0),
}));
} else {
printlnout(
this.main.bind("compile.totaltime", //$non-nls-1$
new string[] {
string.valueof(time),
}));
}
if ((this.main.timing & main.timing_detailed) != 0) {
printlnout(
this.main.bind("compile.detailedtime", //$non-nls-1$
new string[] {
string.valueof(compilerstats.parsetime),
string.valueof(((int) (compilerstats.parsetime * 1000.0 / time)) / 10.0),
string.valueof(compilerstats.resolvetime),
string.valueof(((int) (compilerstats.resolvetime * 1000.0 / time)) / 10.0),
string.valueof(compilerstats.analyzetime),
string.valueof(((int) (compilerstats.analyzetime * 1000.0 / time)) / 10.0),
string.valueof(compilerstats.generatetime),
string.valueof(((int) (compilerstats.generatetime * 1000.0 / time)) / 10.0),
}));
}
}

/**
* print the usage of the compiler
* @@param usage
*/
public void logusage(string usage) {
printlnout(usage);
}

/**
* print the version of the compiler in the log and/or the out field
*/
public void logversion(final boolean printtoout) {
if (this.log != null && (this.tagbits & logger.xml) == 0) {
final string version = this.main.bind("misc.version", //$non-nls-1$
new string[] {
this.main.bind("compiler.name"), //$non-nls-1$
this.main.bind("compiler.version"), //$non-nls-1$
this.main.bind("compiler.copyright") //$non-nls-1$
}
);
this.log.println("# " + version); //$non-nls-1$
if (printtoout) {
this.out.println(version);
this.out.flush();
}
} else if (printtoout) {
final string version = this.main.bind("misc.version", //$non-nls-1$
new string[] {
this.main.bind("compiler.name"), //$non-nls-1$
this.main.bind("compiler.version"), //$non-nls-1$
this.main.bind("compiler.copyright") //$non-nls-1$
}
);
this.out.println(version);
this.out.flush();
}
}

/**
* print the usage of wrong jdk
*/
public void logwrongjdk() {
if ((this.tagbits & logger.xml) != 0) {
this.parameters.put(logger.message, this.main.bind("configure.requiresjdk1.2orabove")); //$non-nls-1$
printtag(logger.error, this.parameters, true, true);
}
this.printlnerr(this.main.bind("configure.requiresjdk1.2orabove")); //$non-nls-1$
}

private void logxmlextraproblem(categorizedproblem problem, int globalerrorcount, int localerrorcount) {
final int sourcestart = problem.getsourcestart();
final int sourceend = problem.getsourceend();
boolean iserror = problem.iserror();
this.parameters.put(logger.problem_severity, iserror ? logger.error : logger.warning);
this.parameters.put(logger.problem_line, new integer(problem.getsourcelinenumber()));
this.parameters.put(logger.problem_source_start, new integer(sourcestart));
this.parameters.put(logger.problem_source_end, new integer(sourceend));
printtag(logger.extra_problem_tag, this.parameters, true, false);
this.parameters.put(logger.value, problem.getmessage());
printtag(logger.problem_message, this.parameters, true, true);
extractcontext(problem, null);
endtag(logger.extra_problem_tag);
}
/**
* @@param problem
*            the given problem to log
* @@param unitsource
*            the given unit source
*/
private void logxmlproblem(categorizedproblem problem, char[] unitsource) {
final int sourcestart = problem.getsourcestart();
final int sourceend = problem.getsourceend();
final int id = problem.getid();
this.parameters.put(logger.id, getfieldname(id)); // id as field name
this.parameters.put(logger.problem_id, new integer(id)); // id as numeric value
boolean iserror = problem.iserror();
int severity = iserror ? problemseverities.error : problemseverities.warning;
this.parameters.put(logger.problem_severity, iserror ? logger.error : logger.warning);
this.parameters.put(logger.problem_line, new integer(problem.getsourcelinenumber()));
this.parameters.put(logger.problem_source_start, new integer(sourcestart));
this.parameters.put(logger.problem_source_end, new integer(sourceend));
string problemoptionkey = getproblemoptionkey(id);
if (problemoptionkey != null) {
this.parameters.put(logger.problem_option_key, problemoptionkey);
}
int categoryid = problemreporter.getproblemcategory(severity, id);
this.parameters.put(logger.problem_category_id, new integer(categoryid));
printtag(logger.problem_tag, this.parameters, true, false);
this.parameters.put(logger.value, problem.getmessage());
printtag(logger.problem_message, this.parameters, true, true);
extractcontext(problem, unitsource);
string[] arguments = problem.getarguments();
final int length = arguments.length;
if (length != 0) {
printtag(logger.problem_arguments, null, true, false);
for (int i = 0; i < length; i++) {
this.parameters.put(logger.problem_argument_value, arguments[i]);
printtag(logger.problem_argument, this.parameters, true, true);
}
endtag(logger.problem_arguments);
}
endtag(logger.problem_tag);
}
/**
* @@param problem
*            the given problem to log
* @@param unitsource
*            the given unit source
*/
private void logxmltask(categorizedproblem problem, char[] unitsource) {
this.parameters.put(logger.problem_line, new integer(problem.getsourcelinenumber()));
this.parameters.put(logger.problem_source_start, new integer(problem.getsourcestart()));
this.parameters.put(logger.problem_source_end, new integer(problem.getsourceend()));
string problemoptionkey = getproblemoptionkey(problem.getid());
if (problemoptionkey != null) {
this.parameters.put(logger.problem_option_key, problemoptionkey);
}
printtag(logger.task, this.parameters, true, false);
this.parameters.put(logger.value, problem.getmessage());
printtag(logger.problem_message, this.parameters, true, true);
extractcontext(problem, unitsource);
endtag(logger.task);
}

private void printerr(string s) {
this.err.print(s);
if ((this.tagbits & logger.xml) == 0 && this.log != null) {
this.log.print(s);
}
}

private void printlnerr() {
this.err.println();
if ((this.tagbits & logger.xml) == 0 && this.log != null) {
this.log.println();
}
}

private void printlnerr(string s) {
this.err.println(s);
if ((this.tagbits & logger.xml) == 0 && this.log != null) {
this.log.println(s);
}
}

private void printlnout(string s) {
this.out.println(s);
if ((this.tagbits & logger.xml) == 0 && this.log != null) {
this.log.println(s);
}
}

/**
*
*/
public void printnewline() {
this.out.println();
}

private void printout(char c) {
this.out.print(c);
}

public void printstats() {
final boolean istimed = (this.main.timing & timing_enabled) != 0;
if ((this.tagbits & logger.xml) != 0) {
printtag(logger.stats, null, true, false);
}
if (istimed) {
compilerstats compilerstats = this.main.batchcompiler.stats;
compilerstats.starttime = this.main.starttime; // also include batch initialization times
compilerstats.endtime = system.currenttimemillis(); // also include batch output times
logtiming(compilerstats);
}
if (this.main.globalproblemscount > 0) {
logproblemssummary(this.main.globalproblemscount, this.main.globalerrorscount, this.main.globalwarningscount, this.main.globaltaskscount);
}
if (this.main.exportedclassfilescounter != 0
&& (this.main.showprogress || istimed || this.main.verbose)) {
lognumberofclassfilesgenerated(this.main.exportedclassfilescounter);
}
if ((this.tagbits & logger.xml) != 0) {
endtag(logger.stats);
}
}

private void printtag(string name, hashmap params, boolean insertnewline, boolean closetag) {
if (this.log != null) {
((genericxmlwriter) this.log).printtag(name, this.parameters, true, insertnewline, closetag);
}
this.parameters.clear();
}

public void setemacs() {
this.tagbits |= logger.emacs;
}
public void setlog(string logfilename) {
final date date = new date();
final dateformat dateformat = dateformat.getdatetimeinstance(dateformat.short, dateformat.long, locale.getdefault());
try {
int index = logfilename.lastindexof('.');
if (index != -1) {
if (logfilename.substring(index).tolowercase().equals(".xml")) { //$non-nls-1$
this.log = new genericxmlwriter(new outputstreamwriter(new fileoutputstream(logfilename, false), util.utf_8), util.line_separator, true);
this.tagbits |= logger.xml;
// insert time stamp as comment
this.log.println("<!-- " + dateformat.format(date) + " -->");//$non-nls-1$//$non-nls-2$
this.log.println(logger.xml_dtd_declaration);
this.parameters.put(logger.compiler_name, this.main.bind("compiler.name")); //$non-nls-1$
this.parameters.put(logger.compiler_version, this.main.bind("compiler.version")); //$non-nls-1$
this.parameters.put(logger.compiler_copyright, this.main.bind("compiler.copyright")); //$non-nls-1$
printtag(logger.compiler, this.parameters, true, false);
} else {
this.log = new printwriter(new fileoutputstream(logfilename, false));
this.log.println("# " + dateformat.format(date));//$non-nls-1$
}
} else {
this.log = new printwriter(new fileoutputstream(logfilename, false));
this.log.println("# " + dateformat.format(date));//$non-nls-1$
}
} catch (filenotfoundexception e) {
throw new illegalargumentexception(this.main.bind("configure.cannotopenlog", logfilename)); //$non-nls-1$
} catch (unsupportedencodingexception e) {
throw new illegalargumentexception(this.main.bind("configure.cannotopenloginvalidencoding", logfilename)); //$non-nls-1$
}
}
private void startloggingextraproblems(int count) {
this.parameters.put(logger.number_of_problems, new integer(count));
printtag(logger.extra_problems, this.parameters, true, false);
}

/**
* used to start logging problems.
* only use in xml mode.
*/
private void startloggingproblems(int errors, int warnings) {
this.parameters.put(logger.number_of_problems, new integer(errors + warnings));
this.parameters.put(logger.number_of_errors, new integer(errors));
this.parameters.put(logger.number_of_warnings, new integer(warnings));
printtag(logger.problems, this.parameters, true, false);
}

public void startloggingsource(compilationresult compilationresult) {
if ((this.tagbits & logger.xml) != 0) {
icompilationunit compilationunit = compilationresult.compilationunit;
if (compilationunit != null) {
char[] filename = compilationunit.getfilename();
file f = new file(new string(filename));
if (filename != null) {
this.parameters.put(logger.path, f.getabsolutepath());
}
char[][] packagename = compilationresult.packagename;
if (packagename != null) {
this.parameters.put(
logger.package,
new string(charoperation.concatwith(packagename, file.separatorchar)));
}
compilationunit unit = (compilationunit) compilationunit;
string destinationpath = unit.destinationpath;
if (destinationpath == null) {
destinationpath = this.main.destinationpath;
}
if (destinationpath != null && destinationpath != none) {
if (file.separatorchar == '/') {
this.parameters.put(logger.output, destinationpath);
} else {
this.parameters.put(logger.output, destinationpath.replace('/', file.separatorchar));
}
}
}
printtag(logger.source, this.parameters, true, false);
}
}

public void startloggingsources() {
if ((this.tagbits & logger.xml) != 0) {
printtag(logger.sources, null, true, false);
}
}

public void startloggingtasks(int tasks) {
if ((this.tagbits & logger.xml) != 0) {
this.parameters.put(logger.number_of_tasks, new integer(tasks));
printtag(logger.tasks, this.parameters, true, false);
}
}
}

/**
* resource bundle factory to share bundles for the same locale
*/
public static class resourcebundlefactory {
private static hashmap cache = new hashmap();
public static synchronized resourcebundle getbundle(locale locale) {
resourcebundle bundle = (resourcebundle) cache.get(locale);
if (bundle == null) {
bundle = resourcebundle.getbundle(main.bundlename, locale);
cache.put(locale, bundle);
}
return bundle;
}
}
// javadoc analysis tuning
boolean enablejavadocon;

boolean warnjavadocon;
boolean warnalljavadocon;

public compiler batchcompiler;
/* bundle containing messages */
public resourcebundle bundle;
protected filesystem.classpath[] checkedclasspaths;

public locale compilerlocale;
public compileroptions compileroptions; // read-only
public compilationprogress progress;
public string destinationpath;
public string[] destinationpaths;
// destination path for compilation units that get no more specific
// one (through directory arguments or various classpath options);
// coding is:
// == null: unspecified, write class files close to their respective
//          source files;
// == main.none: absorbent element, do not output class files;
// else: use as the path of the directory into which class files must
//       be written.
private boolean didspecifysource;
private boolean didspecifytarget;
public string[] encodings;
public int exportedclassfilescounter;
public string[] filenames;
public string[] classnames;
// overrides of destinationpath on a directory argument basis
public int globalerrorscount;
public int globalproblemscount;
public int globaltaskscount;
public int globalwarningscount;

private file javahomecache;

private boolean javahomechecked = false;
public long linecount0;

public string log;

public logger logger;
public int maxproblems;
public map options;
protected printwriter out;
public boolean proceed = true;
public boolean proceedonerror = false;
public boolean producerefinfo = false;
public int currentrepetition, maxrepetition;
public boolean showprogress = false;
public long starttime;
public arraylist pendingerrors;
public boolean systemexitwhenfinished = true;

public static final int timing_disabled = 0;
public static final int timing_enabled = 1;
public static final int timing_detailed = 2;

public int timing = timing_disabled;
public compilerstats[] compilerstats;
public boolean verbose = false;
private string[] expandedcommandline;

private printwriter err;

arraylist extraproblems;
public final static string bundlename = "org.eclipse.jdt.internal.compiler.batch.messages"; //$non-nls-1$
// two uses: recognize 'none' in options; code the singleton none
// for the '-d none' option (wherever it may be found)
public static final int default_size_classpath = 4;

public static final string none = "none"; //$non-nls-1$

/**
* @@deprecated - use {@@link batchcompiler#compile(string, printwriter, printwriter, compilationprogress)} instead
* 						  e.g. batchcompiler.compile(commandline, new printwriter(system.out), new printwriter(system.err), null);
*/
public static boolean compile(string commandline) {
return new main(new printwriter(system.out), new printwriter(system.err), false /* systemexit */, null /* options */, null /* progress */).compile(tokenize(commandline));
}

/**
* @@deprecated - use {@@link batchcompiler#compile(string, printwriter, printwriter, compilationprogress)} instead
*                       e.g. batchcompiler.compile(commandline, outwriter, errwriter, null);
*/
public static boolean compile(string commandline, printwriter outwriter, printwriter errwriter) {
return new main(outwriter, errwriter, false /* systemexit */, null /* options */, null /* progress */).compile(tokenize(commandline));
}

/*
* internal api for public api batchcompiler#compile(string[], printwriter, printwriter, compilationprogress)
*/
public static boolean compile(string[] commandlinearguments, printwriter outwriter, printwriter errwriter, compilationprogress progress) {
return new main(outwriter, errwriter, false /* systemexit */, null /* options */, progress).compile(commandlinearguments);
}
public static file[][] getlibrariesfiles(file[] files) {
filenamefilter filter = new filenamefilter() {
public boolean accept(file dir, string name) {
return util.ispotentialziparchive(name);
}
};
final int fileslength = files.length;
file[][] result = new file[fileslength][];
for (int i = 0; i < fileslength; i++) {
file currentfile = files[i];
if (currentfile.exists() && currentfile.isdirectory()) {
result[i] = currentfile.listfiles(filter);
}
}
return result;
}

public static void main(string[] argv) {
new main(new printwriter(system.out), new printwriter(system.err), true/*systemexit*/, null/*options*/, null/*progress*/).compile(argv);
}

public static string[] tokenize(string commandline) {

int count = 0;
string[] arguments = new string[10];
stringtokenizer tokenizer = new stringtokenizer(commandline, " \"", true); //$non-nls-1$
string token = util.empty_string;
boolean insidequotes = false;
boolean startnewtoken = true;

// take care to quotes on the command line
// 'xxx "aaa bbb";ccc yyy' --->  {"xxx", "aaa bbb;ccc", "yyy" }
// 'xxx "aaa bbb;ccc" yyy' --->  {"xxx", "aaa bbb;ccc", "yyy" }
// 'xxx "aaa bbb";"ccc" yyy' --->  {"xxx", "aaa bbb;ccc", "yyy" }
// 'xxx/"aaa bbb";"ccc" yyy' --->  {"xxx/aaa bbb;ccc", "yyy" }
while (tokenizer.hasmoretokens()) {
token = tokenizer.nexttoken();

if (token.equals(" ")) { //$non-nls-1$
if (insidequotes) {
arguments[count - 1] += token;
startnewtoken = false;
} else {
startnewtoken = true;
}
} else if (token.equals("\"")) { //$non-nls-1$
if (!insidequotes && startnewtoken) {
if (count == arguments.length)
system.arraycopy(arguments, 0, (arguments = new string[count * 2]), 0, count);
arguments[count++] = util.empty_string;
}
insidequotes = !insidequotes;
startnewtoken = false;
} else {
if (insidequotes) {
arguments[count - 1] += token;
} else {
if (token.length() > 0 && !startnewtoken) {
arguments[count - 1] += token;
} else {
if (count == arguments.length)
system.arraycopy(arguments, 0, (arguments = new string[count * 2]), 0, count);
string trimmedtoken = token.trim();
if (trimmedtoken.length() != 0) {
arguments[count++] = trimmedtoken;
}
}
}
startnewtoken = false;
}
}
system.arraycopy(arguments, 0, arguments = new string[count], 0, count);
return arguments;
}

/**
* @@deprecated - use {@@link #main(printwriter, printwriter, boolean, map, compilationprogress)} instead
*                       e.g. main(outwriter, errwriter, systemexitwhenfinished, null, null)
*/
public main(printwriter outwriter, printwriter errwriter, boolean systemexitwhenfinished) {
this(outwriter, errwriter, systemexitwhenfinished, null /* options */, null /* progress */);
}

/**
* @@deprecated - use {@@link #main(printwriter, printwriter, boolean, map, compilationprogress)} instead
*                       e.g. main(outwriter, errwriter, systemexitwhenfinished, customdefaultoptions, null)
*/
public main(printwriter outwriter, printwriter errwriter, boolean systemexitwhenfinished, map customdefaultoptions) {
this(outwriter, errwriter, systemexitwhenfinished, customdefaultoptions, null /* progress */);
}

public main(printwriter outwriter, printwriter errwriter, boolean systemexitwhenfinished, map customdefaultoptions, compilationprogress compilationprogress) {
this.initialize(outwriter, errwriter, systemexitwhenfinished, customdefaultoptions, compilationprogress);
this.relocalize();
}

public void addextraproblems(categorizedproblem problem) {
if (this.extraproblems == null) {
this.extraproblems = new arraylist();
}
this.extraproblems.add(problem);
}
protected void addnewentry(arraylist paths, string currentclasspathname,
arraylist currentrulespecs, string customencoding,
string destpath, boolean issourceonly,
boolean rejectdestinationpathonjars) {

int rulesspecssize = currentrulespecs.size();
accessruleset accessruleset = null;
if (rulesspecssize != 0) {
accessrule[] accessrules = new accessrule[currentrulespecs.size()];
boolean rulesok = true;
iterator i = currentrulespecs.iterator();
int j = 0;
while (i.hasnext()) {
string rulespec = (string) i.next();
char key = rulespec.charat(0);
string pattern = rulespec.substring(1);
if (pattern.length() > 0) {
switch (key) {
case '+':
accessrules[j++] = new accessrule(pattern
.tochararray(), 0);
break;
case '~':
accessrules[j++] = new accessrule(pattern
.tochararray(),
iproblem.discouragedreference);
break;
case '-':
accessrules[j++] = new accessrule(pattern
.tochararray(),
iproblem.forbiddenreference);
break;
case '?':
accessrules[j++] = new accessrule(pattern
.tochararray(),
iproblem.forbiddenreference, true/*keep looking for accessible type*/);
break;
default:
rulesok = false;
}
} else {
rulesok = false;
}
}
if (rulesok) {
accessruleset = new accessruleset(accessrules, accessrestriction.command_line, currentclasspathname);
} else {
if (currentclasspathname.length() != 0) {
// we go on anyway
addpendingerrors(this.bind("configure.incorrectclasspath", currentclasspathname));//$non-nls-1$
}
return;
}
}
if (none.equals(destpath)) {
destpath = none; // keep == comparison valid
}
if (rejectdestinationpathonjars && destpath != null &&
util.ispotentialziparchive(currentclasspathname)) {
throw new illegalargumentexception(
this.bind("configure.unexpecteddestinationpathentryfile", //$non-nls-1$
currentclasspathname));
}
filesystem.classpath currentclasspath = filesystem.getclasspath(
currentclasspathname,
customencoding,
issourceonly,
accessruleset,
destpath);
if (currentclasspath != null) {
paths.add(currentclasspath);
} else if (currentclasspathname.length() != 0) {
// we go on anyway
addpendingerrors(this.bind("configure.incorrectclasspath", currentclasspathname));//$non-nls-1$
}
}
void addpendingerrors(string message) {
if (this.pendingerrors == null) {
this.pendingerrors = new arraylist();
}
this.pendingerrors.add(message);
}
/*
* lookup the message with the given id in this catalog
*/
public string bind(string id) {
return bind(id, (string[]) null);
}
/*
* lookup the message with the given id in this catalog and bind its
* substitution locations with the given string.
*/
public string bind(string id, string binding) {
return bind(id, new string[] { binding });
}

/*
* lookup the message with the given id in this catalog and bind its
* substitution locations with the given strings.
*/
public string bind(string id, string binding1, string binding2) {
return bind(id, new string[] { binding1, binding2 });
}

/*
* lookup the message with the given id in this catalog and bind its
* substitution locations with the given string values.
*/
public string bind(string id, string[] arguments) {
if (id == null)
return "no message available"; //$non-nls-1$
string message = null;
try {
message = this.bundle.getstring(id);
} catch (missingresourceexception e) {
// if we got an exception looking for the message, fail gracefully by just returning
// the id we were looking for.  in most cases this is semi-informative so is not too bad.
return "missing message: " + id + " in: " + main.bundlename; //$non-nls-2$ //$non-nls-1$
}
return messageformat.format(message, arguments);
}
/**
* return true if and only if the running vm supports the given minimal version.
*
* <p>this only checks the major version, since the minor version is always 0 (at least for the useful cases).</p>
* <p>the given minimalsupportedversion is one of the constants:</p>
* <ul>
* <li><code>org.eclipse.jdt.internal.compiler.classfmt.classfileconstants.jdk1_1</code></li>
* <li><code>org.eclipse.jdt.internal.compiler.classfmt.classfileconstants.jdk1_2</code></li>
* <li><code>org.eclipse.jdt.internal.compiler.classfmt.classfileconstants.jdk1_3</code></li>
* <li><code>org.eclipse.jdt.internal.compiler.classfmt.classfileconstants.jdk1_4</code></li>
* <li><code>org.eclipse.jdt.internal.compiler.classfmt.classfileconstants.jdk1_5</code></li>
* <li><code>org.eclipse.jdt.internal.compiler.classfmt.classfileconstants.jdk1_6</code></li>
* <li><code>org.eclipse.jdt.internal.compiler.classfmt.classfileconstants.jdk1_7</code></li>
* </ul>
* @@param minimalsupportedversion the given minimal version
* @@return true if and only if the running vm supports the given minimal version, false otherwise
*/
private boolean checkvmversion(long minimalsupportedversion) {
// the format of this property is supposed to be xx.x where x are digits.
string classfileversion = system.getproperty("java.class.version"); //$non-nls-1$
if (classfileversion == null) {
// by default we don't support a class file version we cannot recognize
return false;
}
int index = classfileversion.indexof('.');
if (index == -1) {
// by default we don't support a class file version we cannot recognize
return false;
}
int majorversion;
try {
majorversion = integer.parseint(classfileversion.substring(0, index));
} catch (numberformatexception e) {
// by default we don't support a class file version we cannot recognize
return false;
}
switch(majorversion) {
case 45 : // 1.0 and 1.1
return classfileconstants.jdk1_1 >= minimalsupportedversion;
case 46 : // 1.2
return classfileconstants.jdk1_2 >= minimalsupportedversion;
case 47 : // 1.3
return classfileconstants.jdk1_3 >= minimalsupportedversion;
case 48 : // 1.4
return classfileconstants.jdk1_4 >= minimalsupportedversion;
case 49 : // 1.5
return classfileconstants.jdk1_5 >= minimalsupportedversion;
case 50 : // 1.6
return classfileconstants.jdk1_6 >= minimalsupportedversion;
case 51 : // 1.7
return classfileconstants.jdk1_7 >= minimalsupportedversion;
}
// unknown version
return false;
}
/*
*  low-level api performing the actual compilation
*/
public boolean compile(string[] argv) {

// decode command line arguments
try {
configure(argv);
if (this.progress != null)
this.progress.begin(this.filenames == null ? 0 : this.filenames.length * this.maxrepetition);
if (this.proceed) {
//				if (this.verbose) {
//					system.out.println(new compileroptions(this.options));
//				}
if (this.showprogress) this.logger.compiling();
for (this.currentrepetition = 0; this.currentrepetition < this.maxrepetition; this.currentrepetition++) {
this.globalproblemscount = 0;
this.globalerrorscount = 0;
this.globalwarningscount = 0;
this.globaltaskscount = 0;
this.exportedclassfilescounter = 0;

if (this.maxrepetition > 1) {
this.logger.flush();
this.logger.logrepetition(this.currentrepetition, this.maxrepetition);
}
// request compilation
performcompilation();
}
if (this.compilerstats != null) {
this.logger.logaverage();
}
if (this.showprogress) this.logger.printnewline();
}
if (this.systemexitwhenfinished) {
this.logger.flush();
this.logger.close();
system.exit(this.globalerrorscount > 0 ? -1 : 0);
}
} catch (illegalargumentexception e) {
this.logger.logexception(e);
if (this.systemexitwhenfinished) {
this.logger.flush();
this.logger.close();
system.exit(-1);
}
return false;
} catch (runtimeexception e) { // internal compiler failure
this.logger.logexception(e);
if (this.systemexitwhenfinished) {
this.logger.flush();
this.logger.close();
system.exit(-1);
}
return false;
} finally {
this.logger.flush();
this.logger.close();
if (this.progress != null)
this.progress.done();
}
if (this.globalerrorscount == 0 && (this.progress == null || !this.progress.iscanceled()))
return true;
return false;
}

/*
decode the command line arguments
*/
public void configure(string[] argv) {

if ((argv == null) || (argv.length == 0)) {
printusage();
return;
}

final int inside_classpath_start = 1;
final int inside_destination_path = 3;
final int inside_target = 4;
final int inside_log = 5;
final int inside_repetition = 6;
final int inside_source = 7;
final int inside_default_encoding = 8;
final int inside_bootclasspath_start = 9;
final int inside_max_problems = 11;
final int inside_ext_dirs = 12;
final int inside_source_path_start = 13;
final int inside_endorsed_dirs = 15;
final int inside_source_directory_destination_path = 16;
final int inside_processor_path_start = 17;
final int inside_processor_start = 18;
final int inside_s_start = 19;
final int inside_class_names = 20;
final int inside_warnings_properties = 21;

final int default = 0;
arraylist bootclasspaths = new arraylist(default_size_classpath);
string sourcepathclasspatharg = null;
arraylist sourcepathclasspaths = new arraylist(default_size_classpath);
arraylist classpaths = new arraylist(default_size_classpath);
arraylist extdirsclasspaths = null;
arraylist endorseddirclasspaths = null;

int index = -1;
int filescount = 0;
int classcount = 0;
int argcount = argv.length;
int mode = default;
this.maxrepetition = 0;
boolean printusagerequired = false;
string usagesection = null;
boolean printversionrequired = false;

boolean didspecifydeprecation = false;
boolean didspecifycompliance = false;
boolean didspecifydisabledannotationprocessing = false;

string customencoding = null;
string customdestinationpath = null;
string currentsourcedirectory = null;
string currentarg = util.empty_string;

set specifiedencodings = null;

// expand the command line if necessary
boolean needexpansion = false;
loop: for (int i = 0; i < argcount; i++) {
if (argv[i].startswith("@@")) { //$non-nls-1$
needexpansion = true;
break loop;
}
}

string[] newcommandlineargs = null;
if (needexpansion) {
newcommandlineargs = new string[argcount];
index = 0;
for (int i = 0; i < argcount; i++) {
string[] newargs = null;
string arg = argv[i].trim();
if (arg.startswith("@@")) { //$non-nls-1$
try {
linenumberreader reader = new linenumberreader(new stringreader(new string(util.getfilecharcontent(new file(arg.substring(1)), null))));
stringbuffer buffer = new stringbuffer();
string line;
while((line = reader.readline()) != null) {
line = line.trim();
if (!line.startswith("#")) { //$non-nls-1$
buffer.append(line).append(" "); //$non-nls-1$
}
}
newargs = tokenize(buffer.tostring());
} catch(ioexception e) {
throw new illegalargumentexception(
this.bind("configure.invalidexpansionargumentname", arg)); //$non-nls-1$
}
}
if (newargs != null) {
int newcommandlineargslength = newcommandlineargs.length;
int newargslength = newargs.length;
system.arraycopy(newcommandlineargs, 0, (newcommandlineargs = new string[newcommandlineargslength + newargslength - 1]), 0, index);
system.arraycopy(newargs, 0, newcommandlineargs, index, newargslength);
index += newargslength;
} else {
newcommandlineargs[index++] = arg;
}
}
index = -1;
} else {
newcommandlineargs = argv;
for (int i = 0; i < argcount; i++) {
newcommandlineargs[i] = newcommandlineargs[i].trim();
}
}
argcount = newcommandlineargs.length;
this.expandedcommandline = newcommandlineargs;
while (++index < argcount) {

if (customencoding != null) {
throw new illegalargumentexception(
this.bind("configure.unexpectedcustomencoding", currentarg, customencoding)); //$non-nls-1$
}

currentarg = newcommandlineargs[index];

switch(mode) {
case default :
if (currentarg.startswith("[")) { //$non-nls-1$
throw new illegalargumentexception(
this.bind("configure.unexpectedbracket", //$non-nls-1$
currentarg));
}

if (currentarg.endswith("]")) { //$non-nls-1$
// look for encoding specification
int encodingstart = currentarg.indexof('[') + 1;
if (encodingstart <= 1) {
throw new illegalargumentexception(
this.bind("configure.unexpectedbracket", currentarg)); //$non-nls-1$
}
int encodingend = currentarg.length() - 1;
if (encodingstart >= 1) {
if (encodingstart < encodingend) {
customencoding = currentarg.substring(encodingstart, encodingend);
try { // ensure encoding is supported
new inputstreamreader(new bytearrayinputstream(new byte[0]), customencoding);
} catch (unsupportedencodingexception e) {
throw new illegalargumentexception(
this.bind("configure.unsupportedencoding", customencoding)); //$non-nls-1$
}
}
currentarg = currentarg.substring(0, encodingstart - 1);
}
}

if (currentarg.endswith(suffixconstants.suffix_string_java)) {
if (this.filenames == null) {
this.filenames = new string[argcount - index];
this.encodings = new string[argcount - index];
this.destinationpaths = new string[argcount - index];
} else if (filescount == this.filenames.length) {
int length = this.filenames.length;
system.arraycopy(
this.filenames,
0,
(this.filenames = new string[length + argcount - index]),
0,
length);
system.arraycopy(
this.encodings,
0,
(this.encodings = new string[length + argcount - index]),
0,
length);
system.arraycopy(
this.destinationpaths,
0,
(this.destinationpaths = new string[length + argcount - index]),
0,
length);
}
this.filenames[filescount] = currentarg;
this.encodings[filescount++] = customencoding;
// destination path cannot be specified upon an individual file
customencoding = null;
mode = default;
continue;
}
if (currentarg.equals("-log")) { //$non-nls-1$
if (this.log != null)
throw new illegalargumentexception(
this.bind("configure.duplicatelog", currentarg)); //$non-nls-1$
mode = inside_log;
continue;
}
if (currentarg.equals("-repeat")) { //$non-nls-1$
if (this.maxrepetition > 0)
throw new illegalargumentexception(
this.bind("configure.duplicaterepeat", currentarg)); //$non-nls-1$
mode = inside_repetition;
continue;
}
if (currentarg.equals("-maxproblems")) { //$non-nls-1$
if (this.maxproblems > 0)
throw new illegalargumentexception(
this.bind("configure.duplicatemaxproblems", currentarg)); //$non-nls-1$
mode = inside_max_problems;
continue;
}
if (currentarg.equals("-source")) { //$non-nls-1$
mode = inside_source;
continue;
}
if (currentarg.equals("-encoding")) { //$non-nls-1$
mode = inside_default_encoding;
continue;
}
if (currentarg.equals("-1.3")) { //$non-nls-1$
if (didspecifycompliance) {
throw new illegalargumentexception(
this.bind("configure.duplicatecompliance", currentarg));//$non-nls-1$
}
didspecifycompliance = true;
this.options.put(compileroptions.option_compliance, compileroptions.version_1_3);
mode = default;
continue;
}
if (currentarg.equals("-1.4")) { //$non-nls-1$
if (didspecifycompliance) {
throw new illegalargumentexception(
this.bind("configure.duplicatecompliance", currentarg)); //$non-nls-1$
}
didspecifycompliance = true;
this.options.put(compileroptions.option_compliance, compileroptions.version_1_4);
mode = default;
continue;
}
if (currentarg.equals("-1.5") || currentarg.equals("-5") || currentarg.equals("-5.0")) { //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
if (didspecifycompliance) {
throw new illegalargumentexception(
this.bind("configure.duplicatecompliance", currentarg)); //$non-nls-1$
}
didspecifycompliance = true;
this.options.put(compileroptions.option_compliance, compileroptions.version_1_5);
mode = default;
continue;
}
if (currentarg.equals("-1.6") || currentarg.equals("-6") || currentarg.equals("-6.0")) { //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
if (didspecifycompliance) {
throw new illegalargumentexception(
this.bind("configure.duplicatecompliance", currentarg)); //$non-nls-1$
}
didspecifycompliance = true;
this.options.put(compileroptions.option_compliance, compileroptions.version_1_6);
mode = default;
continue;
}
if (currentarg.equals("-1.7") || currentarg.equals("-7") || currentarg.equals("-7.0")) { //$non-nls-1$ //$non-nls-2$ //$non-nls-3$
if (didspecifycompliance) {
throw new illegalargumentexception(
this.bind("configure.duplicatecompliance", currentarg)); //$non-nls-1$
}
didspecifycompliance = true;
this.options.put(compileroptions.option_compliance, compileroptions.version_1_7);
mode = default;
continue;
}
if (currentarg.equals("-d")) { //$non-nls-1$
if (this.destinationpath != null) {
stringbuffer errormessage = new stringbuffer();
errormessage.append(currentarg);
if ((index + 1) < argcount) {
errormessage.append(' ');
errormessage.append(newcommandlineargs[index + 1]);
}
throw new illegalargumentexception(
this.bind("configure.duplicateoutputpath", errormessage.tostring())); //$non-nls-1$
}
mode = inside_destination_path;
continue;
}
if (currentarg.equals("-classpath") //$non-nls-1$
|| currentarg.equals("-cp")) { //$non-nls-1$
mode = inside_classpath_start;
continue;
}
if (currentarg.equals("-bootclasspath")) {//$non-nls-1$
if (bootclasspaths.size() > 0) {
stringbuffer errormessage = new stringbuffer();
errormessage.append(currentarg);
if ((index + 1) < argcount) {
errormessage.append(' ');
errormessage.append(newcommandlineargs[index + 1]);
}
throw new illegalargumentexception(
this.bind("configure.duplicatebootclasspath", errormessage.tostring())); //$non-nls-1$
}
mode = inside_bootclasspath_start;
continue;
}
if (currentarg.equals("-sourcepath")) {//$non-nls-1$
if (sourcepathclasspatharg != null) {
stringbuffer errormessage = new stringbuffer();
errormessage.append(currentarg);
if ((index + 1) < argcount) {
errormessage.append(' ');
errormessage.append(newcommandlineargs[index + 1]);
}
throw new illegalargumentexception(
this.bind("configure.duplicatesourcepath", errormessage.tostring())); //$non-nls-1$
}
mode = inside_source_path_start;
continue;
}
if (currentarg.equals("-extdirs")) {//$non-nls-1$
if (extdirsclasspaths != null) {
stringbuffer errormessage = new stringbuffer();
errormessage.append(currentarg);
if ((index + 1) < argcount) {
errormessage.append(' ');
errormessage.append(newcommandlineargs[index + 1]);
}
throw new illegalargumentexception(
this.bind("configure.duplicateextdirs", errormessage.tostring())); //$non-nls-1$
}
mode = inside_ext_dirs;
continue;
}
if (currentarg.equals("-endorseddirs")) { //$non-nls-1$
if (endorseddirclasspaths != null) {
stringbuffer errormessage = new stringbuffer();
errormessage.append(currentarg);
if ((index + 1) < argcount) {
errormessage.append(' ');
errormessage.append(newcommandlineargs[index + 1]);
}
throw new illegalargumentexception(
this.bind("configure.duplicateendorseddirs", errormessage.tostring())); //$non-nls-1$
}
mode = inside_endorsed_dirs;
continue;
}
if (currentarg.equals("-progress")) { //$non-nls-1$
mode = default;
this.showprogress = true;
continue;
}
if (currentarg.startswith("-proceedonerror")) { //$non-nls-1$
mode = default;
int length = currentarg.length();
if (length > 15) {
if (currentarg.equals("-proceedonerror:fatal")) { //$non-nls-1$
this.options.put(compileroptions.option_fataloptionalerror, compileroptions.enabled);
} else {
throw new illegalargumentexception(
this.bind("configure.invalidwarningconfiguration", currentarg)); //$non-nls-1$
}
} else {
this.options.put(compileroptions.option_fataloptionalerror, compileroptions.disabled);
}
this.proceedonerror = true;
continue;
}
if (currentarg.equals("-time")) { //$non-nls-1$
mode = default;
this.timing = timing_enabled;
continue;
}
if (currentarg.equals("-time:detail")) { //$non-nls-1$
mode = default;
this.timing = timing_enabled|timing_detailed;
continue;
}
if (currentarg.equals("-version") //$non-nls-1$
|| currentarg.equals("-v")) { //$non-nls-1$
this.logger.logversion(true);
this.proceed = false;
return;
}
if (currentarg.equals("-showversion")) { //$non-nls-1$
printversionrequired = true;
mode = default;
continue;
}
if ("-deprecation".equals(currentarg)) { //$non-nls-1$
didspecifydeprecation = true;
this.options.put(compileroptions.option_reportdeprecation, compileroptions.warning);
mode = default;
continue;
}
if (currentarg.equals("-help") || currentarg.equals("-?")) { //$non-nls-1$ //$non-nls-2$
printusagerequired = true;
mode = default;
continue;
}
if (currentarg.equals("-help:warn") || //$non-nls-1$
currentarg.equals("-?:warn")) { //$non-nls-1$
printusagerequired = true;
usagesection = "misc.usage.warn"; //$non-nls-1$
continue;
}
if (currentarg.equals("-noexit")) { //$non-nls-1$
this.systemexitwhenfinished = false;
mode = default;
continue;
}
if (currentarg.equals("-verbose")) { //$non-nls-1$
this.verbose = true;
mode = default;
continue;
}
if (currentarg.equals("-referenceinfo")) { //$non-nls-1$
this.producerefinfo = true;
mode = default;
continue;
}
if (currentarg.equals("-inlinejsr")) { //$non-nls-1$
mode = default;
this.options.put(
compileroptions.option_inlinejsr,
compileroptions.enabled);
continue;
}
if (currentarg.startswith("-g")) { //$non-nls-1$
mode = default;
string debugoption = currentarg;
int length = currentarg.length();
if (length == 2) {
this.options.put(
compileroptions.option_localvariableattribute,
compileroptions.generate);
this.options.put(
compileroptions.option_linenumberattribute,
compileroptions.generate);
this.options.put(
compileroptions.option_sourcefileattribute,
compileroptions.generate);
continue;
}
if (length > 3) {
this.options.put(
compileroptions.option_localvariableattribute,
compileroptions.do_not_generate);
this.options.put(
compileroptions.option_linenumberattribute,
compileroptions.do_not_generate);
this.options.put(
compileroptions.option_sourcefileattribute,
compileroptions.do_not_generate);
if (length == 7 && debugoption.equals("-g:" + none)) //$non-nls-1$
continue;
stringtokenizer tokenizer =
new stringtokenizer(debugoption.substring(3, debugoption.length()), ","); //$non-nls-1$
while (tokenizer.hasmoretokens()) {
string token = tokenizer.nexttoken();
if (token.equals("vars")) { //$non-nls-1$
this.options.put(
compileroptions.option_localvariableattribute,
compileroptions.generate);
} else if (token.equals("lines")) { //$non-nls-1$
this.options.put(
compileroptions.option_linenumberattribute,
compileroptions.generate);
} else if (token.equals("source")) { //$non-nls-1$
this.options.put(
compileroptions.option_sourcefileattribute,
compileroptions.generate);
} else {
throw new illegalargumentexception(
this.bind("configure.invaliddebugoption", debugoption)); //$non-nls-1$
}
}
continue;
}
throw new illegalargumentexception(
this.bind("configure.invaliddebugoption", debugoption)); //$non-nls-1$
}
if (currentarg.startswith("-nowarn")) { //$non-nls-1$
disablewarnings();
mode = default;
continue;
}
if (currentarg.startswith("-warn")) { //$non-nls-1$
mode = default;
string warningoption = currentarg;
int length = currentarg.length();
if (length == 10 && warningoption.equals("-warn:" + none)) { //$non-nls-1$
disablewarnings();
continue;
}
if (length <= 6) {
throw new illegalargumentexception(
this.bind("configure.invalidwarningconfiguration", warningoption)); //$non-nls-1$
}
int warntokenstart;
boolean isenabling, allowplusorminus;
switch (warningoption.charat(6)) {
case '+' :
warntokenstart = 7;
isenabling = true;
allowplusorminus = true;
break;
case '-' :
warntokenstart = 7;
isenabling = false; // specified warnings are disabled
allowplusorminus = true;
break;
default:
disablewarnings();
warntokenstart = 6;
isenabling = true;
allowplusorminus = false;
}

stringtokenizer tokenizer =
new stringtokenizer(warningoption.substring(warntokenstart, warningoption.length()), ","); //$non-nls-1$
int tokencounter = 0;

if (didspecifydeprecation) {  // deprecation could have also been set through -deprecation option
this.options.put(compileroptions.option_reportdeprecation, compileroptions.warning);
}

while (tokenizer.hasmoretokens()) {
string token = tokenizer.nexttoken();
tokencounter++;
switch(token.charat(0)) {
case '+' :
if (allowplusorminus) {
isenabling = true;
token = token.substring(1);
} else {
throw new illegalargumentexception(
this.bind("configure.invalidusageofplusoption", token)); //$non-nls-1$
}
break;
case '-' :
if (allowplusorminus) {
isenabling = false;
token = token.substring(1);
} else {
throw new illegalargumentexception(
this.bind("configure.invalidusageofminusoption", token)); //$non-nls-1$
}
}
handlewarningtoken(token, isenabling);
}
if (tokencounter == 0) {
throw new illegalargumentexception(
this.bind("configure.invalidwarningoption", currentarg)); //$non-nls-1$
}
continue;
}
if (currentarg.startswith("-err")) { //$non-nls-1$
mode = default;
string erroroption = currentarg;
int length = currentarg.length();
if (length <= 5) {
throw new illegalargumentexception(
this.bind("configure.invaliderrorconfiguration", erroroption)); //$non-nls-1$
}
int errortokenstart;
boolean isenabling, allowplusorminus;
switch (erroroption.charat(5)) {
case '+' :
errortokenstart = 6;
isenabling = true;
allowplusorminus = true;
break;
case '-' :
errortokenstart = 6;
isenabling = false; // specified errors are disabled
allowplusorminus = true;
break;
default:
disableerrors();
errortokenstart = 5;
isenabling = true;
allowplusorminus = false;
}

stringtokenizer tokenizer =
new stringtokenizer(erroroption.substring(errortokenstart, erroroption.length()), ","); //$non-nls-1$
int tokencounter = 0;

while (tokenizer.hasmoretokens()) {
string token = tokenizer.nexttoken();
tokencounter++;
switch(token.charat(0)) {
case '+' :
if (allowplusorminus) {
isenabling = true;
token = token.substring(1);
} else {
throw new illegalargumentexception(
this.bind("configure.invalidusageofplusoption", token)); //$non-nls-1$
}
break;
case '-' :
if (allowplusorminus) {
isenabling = false;
token = token.substring(1);
} else {
throw new illegalargumentexception(
this.bind("configure.invalidusageofminusoption", token)); //$non-nls-1$
}
break;
}
handleerrortoken(token, isenabling);
}
if (tokencounter == 0) {
throw new illegalargumentexception(
this.bind("configure.invaliderroroption", currentarg)); //$non-nls-1$
}
continue;
}
if (currentarg.equals("-target")) { //$non-nls-1$
mode = inside_target;
continue;
}
if (currentarg.equals("-preservealllocals")) { //$non-nls-1$
this.options.put(
compileroptions.option_preserveunusedlocal,
compileroptions.preserve);
mode = default;
continue;
}
if (currentarg.equals("-enablejavadoc")) {//$non-nls-1$
mode = default;
this.enablejavadocon = true;
continue;
}
if (currentarg.equals("-xemacs")) { //$non-nls-1$
mode = default;
this.logger.setemacs();
continue;
}
// annotation processing
if (currentarg.startswith("-a")) { //$non-nls-1$
mode = default;
continue;
}
if (currentarg.equals("-processorpath")) { //$non-nls-1$
mode = inside_processor_path_start;
continue;
}
if (currentarg.equals("-processor")) { //$non-nls-1$
mode = inside_processor_start;
continue;
}
if (currentarg.equals("-proc:only")) { //$non-nls-1$
this.options.put(
compileroptions.option_generateclassfiles,
compileroptions.disabled);
mode = default;
continue;
}
if (currentarg.equals("-proc:none")) { //$non-nls-1$
didspecifydisabledannotationprocessing = true;
this.options.put(
compileroptions.option_process_annotations,
compileroptions.disabled);
mode = default;
continue;
}
if (currentarg.equals("-s")) { //$non-nls-1$
mode = inside_s_start;
continue;
}
if (currentarg.equals("-xprintprocessorinfo") //$non-nls-1$
|| currentarg.equals("-xprintrounds")) { //$non-nls-1$
mode = default;
continue;
}
// tolerated javac options - quietly filtered out
if (currentarg.startswith("-x")) { //$non-nls-1$
mode = default;
continue;
}
if (currentarg.startswith("-j")) { //$non-nls-1$
mode = default;
continue;
}
if (currentarg.equals("-o")) { //$non-nls-1$
mode = default;
continue;
}
if (currentarg.equals("-classnames")) { //$non-nls-1$
mode = inside_class_names;
continue;
}
if (currentarg.equals("-properties")) { //$non-nls-1$
mode = inside_warnings_properties;
continue;
}
break;
case inside_target :
if (this.didspecifytarget) {
throw new illegalargumentexception(
this.bind("configure.duplicatetarget", currentarg));//$non-nls-1$
}
this.didspecifytarget = true;
if (currentarg.equals("1.1")) { //$non-nls-1$
this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_1);
} else if (currentarg.equals("1.2")) { //$non-nls-1$
this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_2);
} else if (currentarg.equals("1.3")) { //$non-nls-1$
this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_3);
} else if (currentarg.equals("1.4")) { //$non-nls-1$
this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_4);
} else if (currentarg.equals("1.5") || currentarg.equals("5") || currentarg.equals("5.0")) { //$non-nls-1$//$non-nls-2$ //$non-nls-3$
this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_5);
} else if (currentarg.equals("1.6") || currentarg.equals("6") || currentarg.equals("6.0")) { //$non-nls-1$//$non-nls-2$ //$non-nls-3$
this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_6);
} else if (currentarg.equals("1.7") || currentarg.equals("7") || currentarg.equals("7.0")) { //$non-nls-1$//$non-nls-2$ //$non-nls-3$
this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_7);
} else if (currentarg.equals("jsr14")) { //$non-nls-1$
this.options.put(compileroptions.option_targetplatform, compileroptions.version_jsr14);
} else if (currentarg.equals("cldc1.1")) { //$non-nls-1$
this.options.put(compileroptions.option_targetplatform, compileroptions.version_cldc1_1);
this.options.put(compileroptions.option_inlinejsr, compileroptions.enabled);
}else {
throw new illegalargumentexception(this.bind("configure.targetjdk", currentarg)); //$non-nls-1$
}
mode = default;
continue;
case inside_log :
this.log = currentarg;
mode = default;
continue;
case inside_repetition :
try {
this.maxrepetition = integer.parseint(currentarg);
if (this.maxrepetition <= 0) {
throw new illegalargumentexception(this.bind("configure.repetition", currentarg)); //$non-nls-1$
}
} catch (numberformatexception e) {
throw new illegalargumentexception(this.bind("configure.repetition", currentarg)); //$non-nls-1$
}
mode = default;
continue;
case inside_max_problems :
try {
this.maxproblems = integer.parseint(currentarg);
if (this.maxproblems <= 0) {
throw new illegalargumentexception(this.bind("configure.maxproblems", currentarg)); //$non-nls-1$
}
this.options.put(compileroptions.option_maxproblemperunit, currentarg);
} catch (numberformatexception e) {
throw new illegalargumentexception(this.bind("configure.maxproblems", currentarg)); //$non-nls-1$
}
mode = default;
continue;
case inside_source :
if (this.didspecifysource) {
throw new illegalargumentexception(
this.bind("configure.duplicatesource", currentarg));//$non-nls-1$
}
this.didspecifysource = true;
if (currentarg.equals("1.3")) { //$non-nls-1$
this.options.put(compileroptions.option_source, compileroptions.version_1_3);
} else if (currentarg.equals("1.4")) { //$non-nls-1$
this.options.put(compileroptions.option_source, compileroptions.version_1_4);
} else if (currentarg.equals("1.5") || currentarg.equals("5") || currentarg.equals("5.0")) { //$non-nls-1$//$non-nls-2$ //$non-nls-3$
this.options.put(compileroptions.option_source, compileroptions.version_1_5);
} else if (currentarg.equals("1.6") || currentarg.equals("6") || currentarg.equals("6.0")) { //$non-nls-1$//$non-nls-2$ //$non-nls-3$
this.options.put(compileroptions.option_source, compileroptions.version_1_6);
} else if (currentarg.equals("1.7") || currentarg.equals("7") || currentarg.equals("7.0")) { //$non-nls-1$//$non-nls-2$ //$non-nls-3$
this.options.put(compileroptions.option_source, compileroptions.version_1_7);
} else {
throw new illegalargumentexception(this.bind("configure.source", currentarg)); //$non-nls-1$
}
mode = default;
continue;
case inside_default_encoding :
if (specifiedencodings != null) {
// check already defined encoding
if (!specifiedencodings.contains(currentarg)) {
if (specifiedencodings.size() > 1) {
this.logger.logwarning(
this.bind("configure.differentencodings", //$non-nls-1$
currentarg,
getallencodings(specifiedencodings)));
} else {
this.logger.logwarning(
this.bind("configure.differentencoding", //$non-nls-1$
currentarg,
getallencodings(specifiedencodings)));
}
}
} else {
specifiedencodings = new hashset();
}
try { // ensure encoding is supported
new inputstreamreader(new bytearrayinputstream(new byte[0]), currentarg);
} catch (unsupportedencodingexception e) {
throw new illegalargumentexception(
this.bind("configure.unsupportedencoding", currentarg)); //$non-nls-1$
}
specifiedencodings.add(currentarg);
this.options.put(compileroptions.option_encoding, currentarg);
mode = default;
continue;
case inside_destination_path :
setdestinationpath(currentarg.equals(none) ? none : currentarg);
mode = default;
continue;
case inside_classpath_start:
mode = default;
index += processpaths(newcommandlineargs, index, currentarg, classpaths);
continue;
case inside_bootclasspath_start:
mode = default;
index += processpaths(newcommandlineargs, index, currentarg, bootclasspaths);
continue;
case inside_source_path_start:
mode = default;
string[] sourcepaths = new string[1];
index += processpaths(newcommandlineargs, index, currentarg, sourcepaths);
sourcepathclasspatharg = sourcepaths[0];
continue;
case inside_ext_dirs:
if (currentarg.indexof("[-d") != -1) { //$non-nls-1$
throw new illegalargumentexception(
this.bind("configure.unexpecteddestinationpathentry", //$non-nls-1$
"-extdir")); //$non-nls-1$
}
stringtokenizer tokenizer = new stringtokenizer(currentarg,	file.pathseparator, false);
extdirsclasspaths = new arraylist(default_size_classpath);
while (tokenizer.hasmoretokens())
extdirsclasspaths.add(tokenizer.nexttoken());
mode = default;
continue;
case inside_endorsed_dirs:
if (currentarg.indexof("[-d") != -1) { //$non-nls-1$
throw new illegalargumentexception(
this.bind("configure.unexpecteddestinationpathentry", //$non-nls-1$
"-endorseddirs")); //$non-nls-1$
}				tokenizer = new stringtokenizer(currentarg,	file.pathseparator, false);
endorseddirclasspaths = new arraylist(default_size_classpath);
while (tokenizer.hasmoretokens())
endorseddirclasspaths.add(tokenizer.nexttoken());
mode = default;
continue;
case inside_source_directory_destination_path:
if (currentarg.endswith("]")) { //$non-nls-1$
customdestinationpath = currentarg.substring(0,
currentarg.length() - 1);
} else {
throw new illegalargumentexception(
this.bind("configure.incorrectdestinationpathentry", //$non-nls-1$
"[-d " + currentarg)); //$non-nls-1$
}
break;
case inside_processor_path_start :
// nothing to do here. this is consumed again by the annotationprocessormanager
mode = default;
continue;
case inside_processor_start :
// nothing to do here. this is consumed again by the annotationprocessormanager
mode = default;
continue;
case inside_s_start :
// nothing to do here. this is consumed again by the annotationprocessormanager
mode = default;
continue;
case inside_class_names :
tokenizer = new stringtokenizer(currentarg, ","); //$non-nls-1$
if (this.classnames == null) {
this.classnames = new string[default_size_classpath];
}
while (tokenizer.hasmoretokens()) {
if (this.classnames.length == classcount) {
// resize
system.arraycopy(
this.classnames,
0,
(this.classnames = new string[classcount * 2]),
0,
classcount);
}
this.classnames[classcount++] = tokenizer.nexttoken();
}
mode = default;
continue;
case inside_warnings_properties :
initializewarnings(currentarg);
mode = default;
continue;
}

// default is input directory, if no custom destination path exists
if (customdestinationpath == null) {
if (file.separatorchar != '/') {
currentarg = currentarg.replace('/', file.separatorchar);
}
if (currentarg.endswith("[-d")) { //$non-nls-1$
currentsourcedirectory = currentarg.substring(0,
currentarg.length() - 3);
mode = inside_source_directory_destination_path;
continue;
}
currentsourcedirectory = currentarg;
}
file dir = new file(currentsourcedirectory);
if (!dir.isdirectory()) {
throw new illegalargumentexception(
this.bind("configure.unrecognizedoption", currentsourcedirectory)); //$non-nls-1$
}
string[] result = filefinder.find(dir, suffixconstants.suffix_string_java);
if (none.equals(customdestinationpath)) {
customdestinationpath = none; // ensure == comparison
}
if (this.filenames != null) {
// some source files were specified explicitly
int length = result.length;
system.arraycopy(
this.filenames,
0,
(this.filenames = new string[length + filescount]),
0,
filescount);
system.arraycopy(
this.encodings,
0,
(this.encodings = new string[length + filescount]),
0,
filescount);
system.arraycopy(
this.destinationpaths,
0,
(this.destinationpaths = new string[length + filescount]),
0,
filescount);
system.arraycopy(result, 0, this.filenames, filescount, length);
for (int i = 0; i < length; i++) {
this.encodings[filescount + i] = customencoding;
this.destinationpaths[filescount + i] = customdestinationpath;
}
filescount += length;
customencoding = null;
customdestinationpath = null;
currentsourcedirectory = null;
} else {
this.filenames = result;
filescount = this.filenames.length;
this.encodings = new string[filescount];
this.destinationpaths = new string[filescount];
for (int i = 0; i < filescount; i++) {
this.encodings[i] = customencoding;
this.destinationpaths[i] = customdestinationpath;
}
customencoding = null;
customdestinationpath = null;
currentsourcedirectory = null;
}
mode = default;
continue;
}

// set doccommentsupport, with appropriate side effects on defaults if
// javadoc is not enabled
if (this.enablejavadocon) {
this.options.put(
compileroptions.option_doccommentsupport,
compileroptions.enabled);
} else if (this.warnjavadocon || this.warnalljavadocon) {
this.options.put(
compileroptions.option_doccommentsupport,
compileroptions.enabled);
// override defaults: references that are embedded in javadoc are ignored
// from the perspective of parameters and thrown exceptions usage
this.options.put(
compileroptions.option_reportunusedparameterincludedoccommentreference,
compileroptions.disabled);
this.options.put(
compileroptions.option_reportunuseddeclaredthrownexceptionincludedoccommentreference,
compileroptions.disabled);
}
// configure warnings for javadoc contents
if (this.warnjavadocon) {
this.options.put(
compileroptions.option_reportinvalidjavadoctags,
compileroptions.enabled);
this.options.put(
compileroptions.option_reportinvalidjavadoctagsdeprecatedref,
compileroptions.enabled);
this.options.put(
compileroptions.option_reportinvalidjavadoctagsnotvisibleref,
compileroptions.enabled);
this.options.put(
compileroptions.option_reportmissingjavadoctagsvisibility,
compileroptions.private);
}

if (printusagerequired || (filescount == 0 && classcount == 0)) {
if (usagesection ==  null) {
printusage(); // default
} else {
printusage(usagesection);
}
this.proceed = false;
return;
}

if (this.log != null) {
this.logger.setlog(this.log);
} else {
this.showprogress = false;
}
this.logger.logversion(printversionrequired);

validateoptions(didspecifycompliance);

// enable annotation processing by default in batch mode when compliance is at least 1.6
// see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=185768
if (!didspecifydisabledannotationprocessing
&& compileroptions.versiontojdklevel(this.options.get(compileroptions.option_compliance)) >= classfileconstants.jdk1_6) {
this.options.put(compileroptions.option_process_annotations, compileroptions.enabled);
}

this.logger.logcommandlinearguments(newcommandlineargs);
this.logger.logoptions(this.options);

if (this.maxrepetition == 0) {
this.maxrepetition = 1;
}
if (this.maxrepetition >= 3 && (this.timing & timing_enabled) != 0) {
this.compilerstats = new compilerstats[this.maxrepetition];
}

if (filescount != 0) {
system.arraycopy(
this.filenames,
0,
(this.filenames = new string[filescount]),
0,
filescount);
}

if (classcount != 0) {
system.arraycopy(
this.classnames,
0,
(this.classnames = new string[classcount]),
0,
classcount);
}

setpaths(bootclasspaths,
sourcepathclasspatharg,
sourcepathclasspaths,
classpaths,
extdirsclasspaths,
endorseddirclasspaths,
customencoding);

if (specifiedencodings != null && specifiedencodings.size() > 1) {
this.logger.logwarning(this.bind("configure.multipleencodings", //$non-nls-1$
(string) this.options.get(compileroptions.option_encoding),
getallencodings(specifiedencodings)));
}
if (this.pendingerrors != null) {
for (iterator iterator = this.pendingerrors.iterator(); iterator.hasnext(); ) {
string message = (string) iterator.next();
this.logger.logpendingerror(message);
}
this.pendingerrors = null;
}
}
private static string getallencodings(set encodings) {
int size = encodings.size();
string[] allencodings = new string[size];
encodings.toarray(allencodings);
arrays.sort(allencodings);
stringbuffer buffer = new stringbuffer();
for (int i = 0; i < size; i++) {
if (i > 0) {
buffer.append(", "); //$non-nls-1$
}
buffer.append(allencodings[i]);
}
return string.valueof(buffer);
}

private void initializewarnings(string propertiesfile) {
file file = new file(propertiesfile);
if (!file.exists()) {
throw new illegalargumentexception(this.bind("configure.missingwarningspropertiesfile", propertiesfile)); //$non-nls-1$
}
bufferedinputstream stream = null;
properties properties = null;
try {
stream = new bufferedinputstream(new fileinputstream(propertiesfile));
properties = new properties();
properties.load(stream);
} catch(ioexception e) {
e.printstacktrace();
throw new illegalargumentexception(this.bind("configure.ioexceptionwarningspropertiesfile", propertiesfile)); //$non-nls-1$
} finally {
if (stream != null) {
try {
stream.close();
} catch(ioexception e) {
// ignore
}
}
}
for (iterator iterator = properties.entryset().iterator(); iterator.hasnext(); ) {
map.entry entry = (map.entry) iterator.next();
final string key = (string) entry.getkey();
if (key.startswith("org.eclipse.jdt.core.compiler.problem")) { //$non-nls-1$
this.options.put(key, entry.getvalue());
}
}
}
protected void disablewarnings() {
object[] entries = this.options.entryset().toarray();
for (int i = 0, max = entries.length; i < max; i++) {
map.entry entry = (map.entry) entries[i];
if (!(entry.getkey() instanceof string))
continue;
if (!(entry.getvalue() instanceof string))
continue;
if (((string) entry.getvalue()).equals(compileroptions.warning)) {
this.options.put(entry.getkey(), compileroptions.ignore);
}
}
this.options.put(compileroptions.option_tasktags, util.empty_string);
}
protected void disableerrors() {
object[] entries = this.options.entryset().toarray();
for (int i = 0, max = entries.length; i < max; i++) {
map.entry entry = (map.entry) entries[i];
if (!(entry.getkey() instanceof string))
continue;
if (!(entry.getvalue() instanceof string))
continue;
if (((string) entry.getvalue()).equals(compileroptions.error)) {
this.options.put(entry.getkey(), compileroptions.ignore);
}
}
}
public string extractdestinationpathfromsourcefile(compilationresult result) {
icompilationunit compilationunit = result.compilationunit;
if (compilationunit != null) {
char[] filename = compilationunit.getfilename();
int lastindex = charoperation.lastindexof(java.io.file.separatorchar, filename);
if (lastindex != -1) {
final string outputpathname = new string(filename, 0, lastindex);
final file output = new file(outputpathname);
if (output.exists() && output.isdirectory()) {
return outputpathname;
}
}
}
return system.getproperty("user.dir"); //$non-nls-1$
}
/*
* answer the component to which will be handed back compilation results from the compiler
*/
public icompilerrequestor getbatchrequestor() {
return new icompilerrequestor() {
int linedelta = 0;
public void acceptresult(compilationresult compilationresult) {
if (compilationresult.lineseparatorpositions != null) {
int unitlinecount = compilationresult.lineseparatorpositions.length;
this.linedelta += unitlinecount;
if (main.this.showprogress && this.linedelta > 2000) {
// in -log mode, dump a dot every 2000 lines compiled
main.this.logger.logprogress();
this.linedelta = 0;
}
}
main.this.logger.startloggingsource(compilationresult);
if (compilationresult.hasproblems() || compilationresult.hastasks()) {
main.this.logger.logproblems(compilationresult.getallproblems(), compilationresult.compilationunit.getcontents(), main.this);
}
outputclassfiles(compilationresult);
main.this.logger.endloggingsource();
}
};
}
/*
*  build the set of compilation source units
*/
public compilationunit[] getcompilationunits() {
int filecount = this.filenames.length;
compilationunit[] units = new compilationunit[filecount];
hashtableofobject knownfilenames = new hashtableofobject(filecount);

string defaultencoding = (string) this.options.get(compileroptions.option_encoding);
if (util.empty_string.equals(defaultencoding))
defaultencoding = null;

for (int i = 0; i < filecount; i++) {
char[] charname = this.filenames[i].tochararray();
if (knownfilenames.get(charname) != null)
throw new illegalargumentexception(this.bind("unit.more", this.filenames[i])); //$non-nls-1$
knownfilenames.put(charname, charname);
file file = new file(this.filenames[i]);
if (!file.exists())
throw new illegalargumentexception(this.bind("unit.missing", this.filenames[i])); //$non-nls-1$
string encoding = this.encodings[i];
if (encoding == null)
encoding = defaultencoding;
units[i] = new compilationunit(null, this.filenames[i], encoding,
this.destinationpaths[i]);
}
return units;
}

/*
*  low-level api performing the actual compilation
*/
public ierrorhandlingpolicy gethandlingpolicy() {

// passes the initial set of files to the batch oracle (to avoid finding more than once the same units when case insensitive match)
return new ierrorhandlingpolicy() {
public boolean proceedonerrors() {
return main.this.proceedonerror; // stop if there are some errors
}
public boolean stoponfirsterror() {
return false;
}
};
}

/*
* external api
*/
public file getjavahome() {
if (!this.javahomechecked) {
this.javahomechecked = true;
this.javahomecache = util.getjavahome();
}
return this.javahomecache;
}

public filesystem getlibraryaccess() {
return new filesystem(this.checkedclasspaths, this.filenames);
}

/*
*  low-level api performing the actual compilation
*/
public iproblemfactory getproblemfactory() {
return new defaultproblemfactory(this.compilerlocale);
}

/*
* external api
*/
protected arraylist handlebootclasspath(arraylist bootclasspaths, string customencoding) {
final int bootclasspathssize = bootclasspaths == null ? 0 : bootclasspaths.size();
if (bootclasspathssize != 0) {
string[] paths = new string[bootclasspathssize];
bootclasspaths.toarray(paths);
bootclasspaths.clear();
for (int i = 0; i < bootclasspathssize; i++) {
processpathentries(default_size_classpath, bootclasspaths,
paths[i], customencoding, false, true);
}
} else {
bootclasspaths = new arraylist(default_size_classpath);
try {
util.collectrunningvmbootclasspath(bootclasspaths);
} catch(illegalstateexception e) {
this.logger.logwrongjdk();
this.proceed = false;
return null;
}
}
return bootclasspaths;
}

/*
* external api
*/
protected arraylist handleclasspath(arraylist classpaths, string customencoding) {
final int classpathssize = classpaths == null ? 0 : classpaths.size();
if (classpathssize != 0) {
string[] paths = new string[classpathssize];
classpaths.toarray(paths);
classpaths.clear();
for (int i = 0; i < classpathssize; i++) {
processpathentries(default_size_classpath, classpaths, paths[i],
customencoding, false, true);
}
} else {
// no user classpath specified.
classpaths = new arraylist(default_size_classpath);
string classprop = system.getproperty("java.class.path"); //$non-nls-1$
if ((classprop == null) || (classprop.length() == 0)) {
addpendingerrors(this.bind("configure.noclasspath")); //$non-nls-1$
final classpath classpath = filesystem.getclasspath(system.getproperty("user.dir"), customencoding, null);//$non-nls-1$
if (classpath != null) {
classpaths.add(classpath);
}
} else {
stringtokenizer tokenizer = new stringtokenizer(classprop, file.pathseparator);
string token;
while (tokenizer.hasmoretokens()) {
token = tokenizer.nexttoken();
filesystem.classpath currentclasspath = filesystem
.getclasspath(token, customencoding, null);
if (currentclasspath != null) {
classpaths.add(currentclasspath);
} else if (token.length() != 0) {
addpendingerrors(this.bind("configure.incorrectclasspath", token));//$non-nls-1$
}
}
}
}
arraylist result = new arraylist();
hashmap knownnames = new hashmap();
filesystem.classpathsectionproblemreporter problemreporter =
new filesystem.classpathsectionproblemreporter() {
public void invalidclasspathsection(string jarfilepath) {
addpendingerrors(bind("configure.invalidclasspathsection", jarfilepath)); //$non-nls-1$
}
public void multipleclasspathsections(string jarfilepath) {
addpendingerrors(bind("configure.multipleclasspathsections", jarfilepath)); //$non-nls-1$
}
};
while (! classpaths.isempty()) {
classpath current = (classpath) classpaths.remove(0);
string currentpath = current.getpath();
if (knownnames.get(currentpath) == null) {
knownnames.put(currentpath, current);
result.add(current);
list linkedjars = current.fetchlinkedjars(problemreporter);
if (linkedjars != null) {
classpaths.addall(0, linkedjars);
}
}
}
return result;
}
/*
* external api
*/
protected arraylist handleendorseddirs(arraylist endorseddirclasspaths) {
final file javahome = getjavahome();
/*
* feed endorseddirclasspath according to:
* - -endorseddirs first if present;
* - else java.endorsed.dirs if defined;
* - else default extensions directory for the platform. (/lib/endorsed)
*/
if (endorseddirclasspaths == null) {
endorseddirclasspaths = new arraylist(default_size_classpath);
string endorseddirsstr = system.getproperty("java.endorsed.dirs"); //$non-nls-1$
if (endorseddirsstr == null) {
if (javahome != null) {
endorseddirclasspaths.add(javahome.getabsolutepath() + "/lib/endorsed"); //$non-nls-1$
}
} else {
stringtokenizer tokenizer = new stringtokenizer(endorseddirsstr, file.pathseparator);
while (tokenizer.hasmoretokens()) {
endorseddirclasspaths.add(tokenizer.nexttoken());
}
}
}

/*
* feed extdirsclasspath with the entries found into the directories listed by
* extdirsnames.
*/
if (endorseddirclasspaths.size() != 0) {
file[] directoriestocheck = new file[endorseddirclasspaths.size()];
for (int i = 0; i < directoriestocheck.length; i++)
directoriestocheck[i] = new file((string) endorseddirclasspaths.get(i));
endorseddirclasspaths.clear();
file[][] endorseddirsjars = getlibrariesfiles(directoriestocheck);
if (endorseddirsjars != null) {
for (int i = 0, max = endorseddirsjars.length; i < max; i++) {
file[] current = endorseddirsjars[i];
if (current != null) {
for (int j = 0, max2 = current.length; j < max2; j++) {
filesystem.classpath classpath =
filesystem.getclasspath(
current[j].getabsolutepath(),
null, null);
if (classpath != null) {
endorseddirclasspaths.add(classpath);
}
}
} else if (directoriestocheck[i].isfile()) {
addpendingerrors(
this.bind(
"configure.incorrectendorseddirsentry", //$non-nls-1$
directoriestocheck[i].getabsolutepath()));
}
}
}
}
return endorseddirclasspaths;
}

/*
* external api
* handle extdirs processing
*/
protected arraylist handleextdirs(arraylist extdirsclasspaths) {
final file javahome = getjavahome();

/*
* feed extdirclasspath according to:
* - -extdirs first if present;
* - else java.ext.dirs if defined;
* - else default extensions directory for the platform.
*/
if (extdirsclasspaths == null) {
extdirsclasspaths = new arraylist(default_size_classpath);
string extdirsstr = system.getproperty("java.ext.dirs"); //$non-nls-1$
if (extdirsstr == null) {
extdirsclasspaths.add(javahome.getabsolutepath() + "/lib/ext"); //$non-nls-1$
} else {
stringtokenizer tokenizer = new stringtokenizer(extdirsstr, file.pathseparator);
while (tokenizer.hasmoretokens())
extdirsclasspaths.add(tokenizer.nexttoken());
}
}

/*
* feed extdirsclasspath with the entries found into the directories listed by
* extdirsnames.
*/
if (extdirsclasspaths.size() != 0) {
file[] directoriestocheck = new file[extdirsclasspaths.size()];
for (int i = 0; i < directoriestocheck.length; i++)
directoriestocheck[i] = new file((string) extdirsclasspaths.get(i));
extdirsclasspaths.clear();
file[][] extdirsjars = getlibrariesfiles(directoriestocheck);
if (extdirsjars != null) {
for (int i = 0, max = extdirsjars.length; i < max; i++) {
file[] current = extdirsjars[i];
if (current != null) {
for (int j = 0, max2 = current.length; j < max2; j++) {
filesystem.classpath classpath =
filesystem.getclasspath(
current[j].getabsolutepath(),
null, null);
if (classpath != null) {
extdirsclasspaths.add(classpath);
}
}
} else if (directoriestocheck[i].isfile()) {
addpendingerrors(this.bind(
"configure.incorrectextdirsentry", //$non-nls-1$
directoriestocheck[i].getabsolutepath()));
}
}
}
}

return extdirsclasspaths;
}

/*
* external api
* handle a single warning token.
*/
protected void handlewarningtoken(string token, boolean isenabling) {
handleerrororwarningtoken(token, isenabling, problemseverities.warning);
}
protected void handleerrortoken(string token, boolean isenabling) {
handleerrororwarningtoken(token, isenabling, problemseverities.error);
}
private void setseverity(string compileroptions, int severity, boolean isenabling) {
if (isenabling) {
switch(severity) {
case problemseverities.error :
this.options.put(compileroptions, compileroptions.error);
break;
case problemseverities.warning :
this.options.put(compileroptions, compileroptions.warning);
break;
default:
this.options.put(compileroptions, compileroptions.ignore);
}
} else {
switch(severity) {
case problemseverities.error :
string currentvalue = (string) this.options.get(compileroptions);
if (compileroptions.error.equals(currentvalue)) {
this.options.put(compileroptions, compileroptions.ignore);
}
break;
case problemseverities.warning :
currentvalue = (string) this.options.get(compileroptions);
if (compileroptions.warning.equals(currentvalue)) {
this.options.put(compileroptions, compileroptions.ignore);
}
break;
default:
this.options.put(compileroptions, compileroptions.ignore);
}
}
}
private void handleerrororwarningtoken(string token, boolean isenabling, int severity) {
if (token.length() == 0) return;
switch(token.charat(0)) {
case 'a' :
if (token.equals("alldeprecation")) { //$non-nls-1$
setseverity(compileroptions.option_reportdeprecation, severity, isenabling);
this.options.put(
compileroptions.option_reportdeprecationindeprecatedcode,
isenabling ? compileroptions.enabled : compileroptions.disabled);
this.options.put(
compileroptions.option_reportdeprecationwhenoverridingdeprecatedmethod,
isenabling ? compileroptions.enabled : compileroptions.disabled);
return;
} else if (token.equals("alljavadoc")) { //$non-nls-1$
this.warnalljavadocon = this.warnjavadocon = isenabling;
setseverity(compileroptions.option_reportinvalidjavadoc, severity, isenabling);
setseverity(compileroptions.option_reportmissingjavadoctags, severity, isenabling);
setseverity(compileroptions.option_reportmissingjavadoccomments, severity, isenabling);
return;
} else if (token.equals("assertidentifier")) { //$non-nls-1$
setseverity(compileroptions.option_reportassertidentifier, severity, isenabling);
return;
} else if (token.equals("alldeadcode")) { //$non-nls-1$
setseverity(compileroptions.option_reportdeadcode, severity, isenabling);
this.options.put(
compileroptions.option_reportdeadcodeintrivialifstatement,
isenabling ? compileroptions.enabled : compileroptions.disabled);
return;
} else if (token.equals("allover-ann")) { //$non-nls-1$
setseverity(compileroptions.option_reportmissingoverrideannotation, severity, isenabling);
this.options.put(
compileroptions.option_reportmissingoverrideannotationforinterfacemethodimplementation,
isenabling ? compileroptions.enabled : compileroptions.disabled);
return;
}
break;
case 'b' :
if (token.equals("boxing")) { //$non-nls-1$
setseverity(compileroptions.option_reportautoboxing, severity, isenabling);
return;
}
break;
case 'c' :
if (token.equals("constructorname")) { //$non-nls-1$
setseverity(compileroptions.option_reportmethodwithconstructorname, severity, isenabling);
return;
} else if (token.equals("conditionassign")) { //$non-nls-1$
setseverity(compileroptions.option_reportpossibleaccidentalbooleanassignment, severity, isenabling);
return;
} else if (token.equals("compareidentical")) { //$non-nls-1$
setseverity(compileroptions.option_reportcomparingidentical, severity, isenabling);
return;
} else if (token.equals("charconcat") /*|| token.equals("noimplicitstringconversion")/*backward compatible*/) {//$non-nls-1$
setseverity(compileroptions.option_reportnoimplicitstringconversion, severity, isenabling);
return;
}
break;
case 'd' :
if (token.equals("deprecation")) { //$non-nls-1$
setseverity(compileroptions.option_reportdeprecation, severity, isenabling);
this.options.put(
compileroptions.option_reportdeprecationindeprecatedcode,
compileroptions.disabled);
this.options.put(
compileroptions.option_reportdeprecationwhenoverridingdeprecatedmethod,
compileroptions.disabled);
return;
} else if (token.equals("dep-ann")) { //$non-nls-1$
setseverity(compileroptions.option_reportmissingdeprecatedannotation, severity, isenabling);
return;
} else if (token.equals("discouraged")) { //$non-nls-1$
setseverity(compileroptions.option_reportdiscouragedreference, severity, isenabling);
return;
} else if (token.equals("deadcode")) { //$non-nls-1$
setseverity(compileroptions.option_reportdeadcode, severity, isenabling);
this.options.put(
compileroptions.option_reportdeadcodeintrivialifstatement,
compileroptions.disabled);
return;
}
break;
case 'e' :
if (token.equals("enumswitch") //$non-nls-1$
|| token.equals("incomplete-switch")) { //$non-nls-1$
setseverity(compileroptions.option_reportincompleteenumswitch, severity, isenabling);
return;
} else if (token.equals("emptyblock")) {//$non-nls-1$
setseverity(compileroptions.option_reportundocumentedemptyblock, severity, isenabling);
return;
} else if (token.equals("enumidentifier")) { //$non-nls-1$
setseverity(compileroptions.option_reportenumidentifier, severity, isenabling);
return;
}
break;
case 'f' :
if (token.equals("fieldhiding")) { //$non-nls-1$
setseverity(compileroptions.option_reportfieldhiding, severity, isenabling);
return;
} else if (token.equals("finalbound")) {//$non-nls-1$
setseverity(compileroptions.option_reportfinalparameterbound, severity, isenabling);
return;
} else if (token.equals("finally")) { //$non-nls-1$
setseverity(compileroptions.option_reportfinallyblocknotcompletingnormally, severity, isenabling);
return;
} else if (token.equals("forbidden")) { //$non-nls-1$
setseverity(compileroptions.option_reportforbiddenreference, severity, isenabling);
return;
} else if (token.equals("fallthrough")) { //$non-nls-1$
setseverity(compileroptions.option_reportfallthroughcase, severity, isenabling);
return;
}
break;
case 'h' :
if (token.equals("hiding")) { //$non-nls-1$
setseverity(compileroptions.option_reporthiddencatchblock, severity, isenabling);
setseverity(compileroptions.option_reportlocalvariablehiding, severity, isenabling);
setseverity(compileroptions.option_reportfieldhiding, severity, isenabling);
setseverity(compileroptions.option_reporttypeparameterhiding, severity, isenabling);
return;
} else if (token.equals("hashcode")) { //$non-nls-1$
setseverity(compileroptions.option_reportmissinghashcodemethod, severity, isenabling);
return;
}
break;
case 'i' :
if (token.equals("indirectstatic")) { //$non-nls-1$
setseverity(compileroptions.option_reportindirectstaticaccess, severity, isenabling);
return;
} else if (token.equals("intfnoninherited") || token.equals("interfacenoninherited")/*backward compatible*/) { //$non-nls-1$ //$non-nls-2$
setseverity(compileroptions.option_reportincompatiblenoninheritedinterfacemethod, severity, isenabling);
return;
} else if (token.equals("intfannotation")) { //$non-nls-1$
setseverity(compileroptions.option_reportannotationsuperinterface, severity, isenabling);
return;
} else if (token.equals("intfredundant") /*|| token.equals("redundantsuperinterface")*/) { //$non-nls-1$
setseverity(compileroptions.option_reportredundantsuperinterface, severity, isenabling);
return;
}
break;
case 'j' :
if (token.equals("javadoc")) {//$non-nls-1$
this.warnjavadocon = isenabling;
setseverity(compileroptions.option_reportinvalidjavadoc, severity, isenabling);
setseverity(compileroptions.option_reportmissingjavadoctags, severity, isenabling);
return;
}
break;
case 'l' :
if (token.equals("localhiding")) { //$non-nls-1$
setseverity(compileroptions.option_reportlocalvariablehiding, severity, isenabling);
return;
}
break;
case 'm' :
if (token.equals("maskedcatchblock") || token.equals("maskedcatchblocks")/*backward compatible*/) { //$non-nls-1$ //$non-nls-2$
setseverity(compileroptions.option_reporthiddencatchblock, severity, isenabling);
return;
}
break;
case 'n' :
if (token.equals("nls")) { //$non-nls-1$
setseverity(compileroptions.option_reportnonexternalizedstringliteral, severity, isenabling);
return;
} else if (token.equals("noeffectassign")) { //$non-nls-1$
setseverity(compileroptions.option_reportnoeffectassignment, severity, isenabling);
return;
} else if (/*token.equals("charconcat") ||*/ token.equals("noimplicitstringconversion")/*backward compatible*/) {//$non-nls-1$
setseverity(compileroptions.option_reportnoimplicitstringconversion, severity, isenabling);
return;
} else if (token.equals("null")) { //$non-nls-1$
setseverity(compileroptions.option_reportnullreference, severity, isenabling);
setseverity(compileroptions.option_reportpotentialnullreference, severity, isenabling);
setseverity(compileroptions.option_reportredundantnullcheck, severity, isenabling);
return;
} else if (token.equals("nulldereference")) { //$non-nls-1$
setseverity(compileroptions.option_reportnullreference, severity, isenabling);
if (!isenabling) {
setseverity(compileroptions.option_reportpotentialnullreference, problemseverities.ignore, isenabling);
setseverity(compileroptions.option_reportredundantnullcheck, problemseverities.ignore, isenabling);
}
return;
}
break;
case 'o' :
if (token.equals("over-sync") /*|| token.equals("syncoverride")*/) { //$non-nls-1$
setseverity(compileroptions.option_reportmissingsynchronizedoninheritedmethod, severity, isenabling);
return;
} else if (token.equals("over-ann")) { //$non-nls-1$
setseverity(compileroptions.option_reportmissingoverrideannotation, severity, isenabling);
this.options.put(
compileroptions.option_reportmissingoverrideannotationforinterfacemethodimplementation,
compileroptions.disabled);
return;
}
break;
case 'p' :
if (token.equals("pkgdefaultmethod") || token.equals("packagedefaultmethod")/*backward compatible*/ ) { //$non-nls-1$ //$non-nls-2$
setseverity(compileroptions.option_reportoverridingpackagedefaultmethod, severity, isenabling);
return;
} else if (token.equals("paramassign")) { //$non-nls-1$
setseverity(compileroptions.option_reportparameterassignment, severity, isenabling);
return;
}
break;
case 'r' :
if (token.equals("raw")) {//$non-nls-1$
setseverity(compileroptions.option_reportrawtypereference, severity, isenabling);
return;
} else if (/*token.equals("intfredundant") ||*/ token.equals("redundantsuperinterface")) { //$non-nls-1$
setseverity(compileroptions.option_reportredundantsuperinterface, severity, isenabling);
return;
}
break;
case 's' :
if (token.equals("specialparamhiding")) { //$non-nls-1$
this.options.put(
compileroptions.option_reportspecialparameterhidingfield,
isenabling ? compileroptions.enabled : compileroptions.disabled);
return;
} else if (token.equals("syntheticaccess") || token.equals("synthetic-access")) { //$non-nls-1$ //$non-nls-2$
setseverity(compileroptions.option_reportsyntheticaccessemulation, severity, isenabling);
return;
} else if (token.equals("staticreceiver")) { //$non-nls-1$
setseverity(compileroptions.option_reportnonstaticaccesstostatic, severity, isenabling);
return;
} else 	if (/*token.equals("over-sync") ||*/ token.equals("syncoverride")) { //$non-nls-1$
setseverity(compileroptions.option_reportmissingsynchronizedoninheritedmethod, severity, isenabling);
return;
} else if (token.equals("semicolon")) {//$non-nls-1$
setseverity(compileroptions.option_reportemptystatement, severity, isenabling);
return;
} else if (token.equals("serial")) {//$non-nls-1$
setseverity(compileroptions.option_reportmissingserialversion, severity, isenabling);
return;
} else if (token.equals("suppress")) {//$non-nls-1$
switch(severity) {
case problemseverities.warning :
this.options.put(
compileroptions.option_suppresswarnings,
isenabling ? compileroptions.enabled : compileroptions.disabled);
this.options.put(
compileroptions.option_suppressoptionalerrors,
compileroptions.disabled);
break;
case problemseverities.error :
this.options.put(
compileroptions.option_suppresswarnings,
isenabling ? compileroptions.enabled : compileroptions.disabled);
this.options.put(
compileroptions.option_suppressoptionalerrors,
isenabling ? compileroptions.enabled : compileroptions.disabled);
}
return;
} else if (token.equals("static-access")) { //$non-nls-1$
setseverity(compileroptions.option_reportnonstaticaccesstostatic, severity, isenabling);
setseverity(compileroptions.option_reportindirectstaticaccess, severity, isenabling);
return;
} else if (token.equals("super")) { //$non-nls-1$
setseverity(compileroptions.option_reportoverridingmethodwithoutsuperinvocation, severity, isenabling);
return;
}
break;
case 't' :
if (token.startswith("tasks")) { //$non-nls-1$
string tasktags = util.empty_string;
int start = token.indexof('(');
int end = token.indexof(')');
if (start >= 0 && end >= 0 && start < end){
tasktags = token.substring(start+1, end).trim();
tasktags = tasktags.replace('|',',');
}
if (tasktags.length() == 0){
throw new illegalargumentexception(this.bind("configure.invalidtasktag", token)); //$non-nls-1$
}
this.options.put(
compileroptions.option_tasktags,
isenabling ? tasktags : util.empty_string);

setseverity(compileroptions.option_reporttasks, severity, isenabling);
return;
} else if (token.equals("typehiding")) { //$non-nls-1$
setseverity(compileroptions.option_reporttypeparameterhiding, severity, isenabling);
return;
}
break;
case 'u' :
if (token.equals("unusedlocal") || token.equals("unusedlocals")/*backward compatible*/) { //$non-nls-1$ //$non-nls-2$
setseverity(compileroptions.option_reportunusedlocal, severity, isenabling);
return;
} else if (token.equals("unusedargument") || token.equals("unusedarguments")/*backward compatible*/) { //$non-nls-1$ //$non-nls-2$
setseverity(compileroptions.option_reportunusedparameter, severity, isenabling);
return;
} else if (token.equals("unusedimport") || token.equals("unusedimports")/*backward compatible*/) { //$non-nls-1$ //$non-nls-2$
setseverity(compileroptions.option_reportunusedimport, severity, isenabling);
return;
} else if (token.equals("unusedallocation")) { //$non-nls-1$
setseverity(compileroptions.option_reportunusedobjectallocation, severity, isenabling);
return;
} else if (token.equals("unusedprivate")) { //$non-nls-1$
setseverity(compileroptions.option_reportunusedprivatemember, severity, isenabling);
return;
} else if (token.equals("unusedlabel")) { //$non-nls-1$
setseverity(compileroptions.option_reportunusedlabel, severity, isenabling);
return;
} else if (token.equals("uselesstypecheck")) {//$non-nls-1$
setseverity(compileroptions.option_reportunnecessarytypecheck, severity, isenabling);
return;
} else if (token.equals("unchecked") || token.equals("unsafe")) {//$non-nls-1$ //$non-nls-2$
setseverity(compileroptions.option_reportuncheckedtypeoperation, severity, isenabling);
return;
} else if (token.equals("unnecessaryelse")) {//$non-nls-1$
setseverity(compileroptions.option_reportunnecessaryelse, severity, isenabling);
return;
} else if (token.equals("unusedthrown")) { //$non-nls-1$
setseverity(compileroptions.option_reportunuseddeclaredthrownexception, severity, isenabling);
return;
} else if (token.equals("unqualifiedfield") || token.equals("unqualified-field-access")) { //$non-nls-1$ //$non-nls-2$
setseverity(compileroptions.option_reportunqualifiedfieldaccess, severity, isenabling);
return;
} else if (token.equals("unused")) { //$non-nls-1$
setseverity(compileroptions.option_reportunusedlocal, severity, isenabling);
setseverity(compileroptions.option_reportunusedparameter, severity, isenabling);
setseverity(compileroptions.option_reportunusedimport, severity, isenabling);
setseverity(compileroptions.option_reportunusedprivatemember, severity, isenabling);
setseverity(compileroptions.option_reportunuseddeclaredthrownexception, severity, isenabling);
setseverity(compileroptions.option_reportunusedlabel, severity, isenabling);
setseverity(compileroptions.option_reportunusedtypeargumentsformethodinvocation, severity, isenabling);
return;
} else if (token.equals("unusedtypeargs")) { //$non-nls-1$
setseverity(compileroptions.option_reportunusedtypeargumentsformethodinvocation, severity, isenabling);
return;
}
break;
case 'v' :
if (token.equals("varargscast")) { //$non-nls-1$
setseverity(compileroptions.option_reportvarargsargumentneedcast, severity, isenabling);
return;
}
break;
case 'w' :
if (token.equals("warningtoken")) {//$non-nls-1$
setseverity(compileroptions.option_reportunhandledwarningtoken, severity, isenabling);
setseverity(compileroptions.option_reportunusedwarningtoken, severity, isenabling);
return;
}
break;
}
string message = null;
switch(severity) {
case problemseverities.warning :
message = this.bind("configure.invalidwarning", token); //$non-nls-1$
break;
case problemseverities.error :
message = this.bind("configure.invaliderror", token); //$non-nls-1$
}
addpendingerrors(message);
}
/**
* @@deprecated - use {@@link #initialize(printwriter, printwriter, boolean, map, compilationprogress)} instead
*                       e.g. initialize(outwriter, errwriter, systemexit, null, null)
*/
protected void initialize(printwriter outwriter, printwriter errwriter, boolean systemexit) {
this.initialize(outwriter, errwriter, systemexit, null /* options */, null /* progress */);
}
/**
* @@deprecated - use {@@link #initialize(printwriter, printwriter, boolean, map, compilationprogress)} instead
*                       e.g. initialize(outwriter, errwriter, systemexit, customdefaultoptions, null)
*/
protected void initialize(printwriter outwriter, printwriter errwriter, boolean systemexit, map customdefaultoptions) {
this.initialize(outwriter, errwriter, systemexit, customdefaultoptions, null /* progress */);
}
protected void initialize(printwriter outwriter, printwriter errwriter, boolean systemexit, map customdefaultoptions, compilationprogress compilationprogress) {
this.logger = new logger(this, outwriter, errwriter);
this.proceed = true;
this.out = outwriter;
this.err = errwriter;
this.systemexitwhenfinished = systemexit;
this.options = new compileroptions().getmap();

this.progress = compilationprogress;
if (customdefaultoptions != null) {
this.didspecifysource = customdefaultoptions.get(compileroptions.option_source) != null;
this.didspecifytarget = customdefaultoptions.get(compileroptions.option_targetplatform) != null;
for (iterator iter = customdefaultoptions.entryset().iterator(); iter.hasnext();) {
map.entry entry = (map.entry) iter.next();
this.options.put(entry.getkey(), entry.getvalue());
}
} else {
this.didspecifysource = false;
this.didspecifytarget = false;
}
this.classnames = null;
}
protected void initializeannotationprocessormanager() {
try {
class c = class.forname("org.eclipse.jdt.internal.compiler.apt.dispatch.batchannotationprocessormanager"); //$non-nls-1$
abstractannotationprocessormanager annotationmanager = (abstractannotationprocessormanager) c.newinstance();
annotationmanager.configure(this, this.expandedcommandline);
annotationmanager.seterr(this.err);
annotationmanager.setout(this.out);
this.batchcompiler.annotationprocessormanager = annotationmanager;
} catch (classnotfoundexception e) {
// ignore
} catch (instantiationexception e) {
// should not happen
throw new org.eclipse.jdt.internal.compiler.problem.abortcompilation();
} catch (illegalaccessexception e) {
// should not happen
throw new org.eclipse.jdt.internal.compiler.problem.abortcompilation();
} catch(unsupportedclassversionerror e) {
// report a warning
this.logger.logincorrectvmversionforannotationprocessing();
}
}

// dump classfiles onto disk for all compilation units that where successful
// and do not carry a -d none spec, either directly or inherited from main.
public void outputclassfiles(compilationresult unitresult) {
if (!((unitresult == null) || (unitresult.haserrors() && !this.proceedonerror))) {
classfile[] classfiles = unitresult.getclassfiles();
string currentdestinationpath = null;
boolean generateclasspathstructure = false;
compilationunit compilationunit =
(compilationunit) unitresult.compilationunit;
if (compilationunit.destinationpath == null) {
if (this.destinationpath == null) {
currentdestinationpath =
extractdestinationpathfromsourcefile(unitresult);
} else if (this.destinationpath != none) {
currentdestinationpath = this.destinationpath;
generateclasspathstructure = true;
} // else leave currentdestinationpath null
} else if (compilationunit.destinationpath != none) {
currentdestinationpath = compilationunit.destinationpath;
generateclasspathstructure = true;
} // else leave currentdestinationpath null
if (currentdestinationpath != null) {
for (int i = 0, filecount = classfiles.length; i < filecount; i++) {
// retrieve the key and the corresponding classfile
classfile classfile = classfiles[i];
char[] filename = classfile.filename();
int length = filename.length;
char[] relativename = new char[length + 6];
system.arraycopy(filename, 0, relativename, 0, length);
system.arraycopy(suffixconstants.suffix_class, 0, relativename, length, 6);
charoperation.replace(relativename, '/', file.separatorchar);
string relativestringname = new string(relativename);
try {
if (this.compileroptions.verbose)
this.out.println(
messages.bind(
messages.compilation_write,
new string[] {
string.valueof(this.exportedclassfilescounter+1),
relativestringname
}));
util.writetodisk(
generateclasspathstructure,
currentdestinationpath,
relativestringname,
classfile);
this.logger.logclassfile(
generateclasspathstructure,
currentdestinationpath,
relativestringname);
this.exportedclassfilescounter++;
} catch (ioexception e) {
this.logger.lognoclassfilecreated(currentdestinationpath, relativestringname, e);
}
}
this.batchcompiler.lookupenvironment.releaseclassfiles(classfiles);
}
}
}
/*
*  low-level api performing the actual compilation
*/
public void performcompilation() {

this.starttime = system.currenttimemillis();

filesystem environment = getlibraryaccess();
this.compileroptions = new compileroptions(this.options);
this.compileroptions.performmethodsfullrecovery = false;
this.compileroptions.performstatementsrecovery = false;
this.batchcompiler =
new compiler(
environment,
gethandlingpolicy(),
this.compileroptions,
getbatchrequestor(),
getproblemfactory(),
this.out,
this.progress);
this.batchcompiler.remainingiterations = this.maxrepetition-this.currentrepetition/*remaining iterations including this one*/;
// temporary code to allow the compiler to revert to a single thread
string setting = system.getproperty("jdt.compiler.usesinglethread"); //$non-nls-1$
this.batchcompiler.usesinglethread = setting != null && setting.equals("true"); //$non-nls-1$

if (this.compileroptions.compliancelevel >= classfileconstants.jdk1_6
&& this.compileroptions.processannotations) {
if (checkvmversion(classfileconstants.jdk1_6)) {
initializeannotationprocessormanager();
if (this.classnames != null) {
this.batchcompiler.setbinarytypes(processclassnames(this.batchcompiler.lookupenvironment));
}
} else {
// report a warning
this.logger.logincorrectvmversionforannotationprocessing();
}
}

// set the non-externally configurable options.
this.compileroptions.verbose = this.verbose;
this.compileroptions.producereferenceinfo = this.producerefinfo;
try {
this.logger.startloggingsources();
this.batchcompiler.compile(getcompilationunits());
} finally {
this.logger.endloggingsources();
}

if (this.extraproblems != null) {
this.logger.loggingextraproblems(this);
this.extraproblems = null;
}
if (this.compilerstats != null) {
this.compilerstats[this.currentrepetition] = this.batchcompiler.stats;
}
this.logger.printstats();

// cleanup
environment.cleanup();
}
public void printusage() {
printusage("misc.usage"); //$non-nls-1$
}
private void printusage(string sectionid) {
this.logger.logusage(
this.bind(
sectionid,
new string[] {
system.getproperty("path.separator"), //$non-nls-1$
this.bind("compiler.name"), //$non-nls-1$
this.bind("compiler.version"), //$non-nls-1$
this.bind("compiler.copyright") //$non-nls-1$
}));
this.logger.flush();
}
private referencebinding[] processclassnames(lookupenvironment environment) {
// check for .class file presence in case of apt processing
int length = this.classnames.length;
referencebinding[] referencebindings = new referencebinding[length];
for (int i = 0; i < length; i++) {
string currentname = this.classnames[i];
char[][] compoundname = null;
if (currentname.indexof('.') != -1) {
// consider names with '.' as fully qualified names
char[] typename = currentname.tochararray();
compoundname = charoperation.spliton('.', typename);
} else {
compoundname = new char[][] { currentname.tochararray() };
}
referencebinding type = environment.gettype(compoundname);
if (type != null && type.isvalidbinding()) {
if (type.isbinarybinding()) {
referencebindings[i] = type;
}
} else {
throw new illegalargumentexception(
this.bind("configure.invalidclassname", currentname));//$non-nls-1$
}
}
return referencebindings;
}
/*
* external api
*/
public void processpathentries(final int defaultsize, final arraylist paths,
final string currentpath, string customencoding, boolean issourceonly,
boolean rejectdestinationpathonjars) {
string currentclasspathname = null;
string currentdestinationpath = null;
arraylist currentrulespecs = new arraylist(defaultsize);
stringtokenizer tokenizer = new stringtokenizer(currentpath,
file.pathseparator + "[]", true); //$non-nls-1$
arraylist tokens = new arraylist();
while (tokenizer.hasmoretokens()) {
tokens.add(tokenizer.nexttoken());
}
// state machine
final int start = 0;
final int readytoclose = 1;
// 'path' 'path1[rule];path2'
final int readytocloseendingwithrules = 2;
// 'path[rule]' 'path1;path2[rule]'
final int readytocloseorotherentry = 3;
// 'path[rule];' 'path;' 'path1;path2;'
final int rulesneedanotherrule = 4;
// 'path[rule1;'
final int rulesstart = 5;
// 'path[' 'path1;path2['
final int rulesreadytoclose = 6;
// 'path[rule' 'path[rule1;rule2'
final int destinationpathreadytoclose = 7;
// 'path[-d bin'
final int readytocloseendingwithdestinationpath = 8;
// 'path[-d bin]' 'path[rule][-d bin]'
final int destinationpathstart = 9;
// 'path[rule]['
final int bracketopened = 10;
// '.*[.*'
final int bracketclosed = 11;
// '.*([.*])+'

final int error = 99;
int state = start;
string token = null;
int cursor = 0, tokensnb = tokens.size(), bracket = -1;
while (cursor < tokensnb && state != error) {
token = (string) tokens.get(cursor++);
if (token.equals(file.pathseparator)) {
switch (state) {
case start:
case readytocloseorotherentry:
case bracketopened:
break;
case readytoclose:
case readytocloseendingwithrules:
case readytocloseendingwithdestinationpath:
state = readytocloseorotherentry;
addnewentry(paths, currentclasspathname, currentrulespecs,
customencoding, currentdestinationpath, issourceonly,
rejectdestinationpathonjars);
currentrulespecs.clear();
break;
case rulesreadytoclose:
state = rulesneedanotherrule;
break;
case destinationpathreadytoclose:
throw new illegalargumentexception(
this.bind("configure.incorrectdestinationpathentry", //$non-nls-1$
currentpath));
case bracketclosed:
cursor = bracket + 1;
state = rulesstart;
break;
default:
state = error;
}
} else if (token.equals("[")) { //$non-nls-1$
switch (state) {
case start:
currentclasspathname = ""; //$non-nls-1$
//$fall-through$
case readytoclose:
bracket = cursor - 1;
//$fall-through$
case bracketclosed:
state = bracketopened;
break;
case readytocloseendingwithrules:
state = destinationpathstart;
break;
case readytocloseendingwithdestinationpath:
state = rulesstart;
break;
case bracketopened:
default:
state = error;
}
} else if (token.equals("]")) { //$non-nls-1$
switch (state) {
case rulesreadytoclose:
state = readytocloseendingwithrules;
break;
case destinationpathreadytoclose:
state = readytocloseendingwithdestinationpath;
break;
case bracketopened:
state = bracketclosed;
break;
case bracketclosed:
default:
state = error;
}
} else {
// regular word
switch (state) {
case start:
case readytocloseorotherentry:
state = readytoclose;
currentclasspathname = token;
break;
case rulesstart:
if (token.startswith("-d ")) { //$non-nls-1$
if (currentdestinationpath != null) {
throw new illegalargumentexception(
this.bind("configure.duplicatedestinationpathentry", //$non-nls-1$
currentpath));
}
currentdestinationpath = token.substring(3).trim();
state = destinationpathreadytoclose;
break;
} // else we proceed with a rule
//$fall-through$
case rulesneedanotherrule:
if (currentdestinationpath != null) {
throw new illegalargumentexception(
this.bind("configure.accessruleafterdestinationpath", //$non-nls-1$
currentpath));
}
state = rulesreadytoclose;
currentrulespecs.add(token);
break;
case destinationpathstart:
if (!token.startswith("-d ")) { //$non-nls-1$
state = error;
} else {
currentdestinationpath = token.substring(3).trim();
state = destinationpathreadytoclose;
}
break;
case bracketclosed:
for (int i = bracket; i < cursor ; i++) {
currentclasspathname += (string) tokens.get(i);
}
state = readytoclose;
break;
case bracketopened:
break;
default:
state = error;
}
}
if (state == bracketclosed && cursor == tokensnb) {
cursor = bracket + 1;
state = rulesstart;
}
}
switch(state) {
case readytocloseorotherentry:
break;
case readytoclose:
case readytocloseendingwithrules:
case readytocloseendingwithdestinationpath:
addnewentry(paths, currentclasspathname, currentrulespecs,
customencoding, currentdestinationpath, issourceonly,
rejectdestinationpathonjars);
break;
case bracketopened:
case bracketclosed:
default :
// we go on anyway
if (currentpath.length() != 0) {
addpendingerrors(this.bind("configure.incorrectclasspath", currentpath));//$non-nls-1$
}
}
}

private int processpaths(string[] args, int index, string currentarg, arraylist paths) {
int localindex = index;
int count = 0;
for (int i = 0, max = currentarg.length(); i < max; i++) {
switch(currentarg.charat(i)) {
case '[' :
count++;
break;
case ']' :
count--;
break;
}
}
if (count == 0) {
paths.add(currentarg);
} else if (count > 1) {
throw new illegalargumentexception(
this.bind("configure.unexpectedbracket", //$non-nls-1$
currentarg));
} else {
stringbuffer currentpath = new stringbuffer(currentarg);
while (true) {
if (localindex >= args.length) {
throw new illegalargumentexception(
this.bind("configure.unexpectedbracket", //$non-nls-1$
currentarg));
}
localindex++;
string nextarg = args[localindex];
for (int i = 0, max = nextarg.length(); i < max; i++) {
switch(nextarg.charat(i)) {
case '[' :
if (count > 1) {
throw new illegalargumentexception(
this.bind("configure.unexpectedbracket", //$non-nls-1$
nextarg));
}
count++;
break;
case ']' :
count--;
break;
}
}
if (count == 0) {
currentpath.append(' ');
currentpath.append(nextarg);
paths.add(currentpath.tostring());
return localindex - index;
} else if (count < 0) {
throw new illegalargumentexception(
this.bind("configure.unexpectedbracket", //$non-nls-1$
nextarg));
} else {
currentpath.append(' ');
currentpath.append(nextarg);
}
}

}
return localindex - index;
}
private int processpaths(string[] args, int index, string currentarg, string[] paths) {
int localindex = index;
int count = 0;
for (int i = 0, max = currentarg.length(); i < max; i++) {
switch(currentarg.charat(i)) {
case '[' :
count++;
break;
case ']' :
count--;
break;
}
}
if (count == 0) {
paths[0] = currentarg;
} else {
stringbuffer currentpath = new stringbuffer(currentarg);
while (true) {
localindex++;
if (localindex >= args.length) {
throw new illegalargumentexception(
this.bind("configure.unexpectedbracket", //$non-nls-1$
currentarg));
}
string nextarg = args[localindex];
for (int i = 0, max = nextarg.length(); i < max; i++) {
switch(nextarg.charat(i)) {
case '[' :
if (count > 1) {
throw new illegalargumentexception(
this.bind("configure.unexpectedbracket", //$non-nls-1$
currentarg));
}
count++;
break;
case ']' :
count--;
break;
}
}
if (count == 0) {
currentpath.append(' ');
currentpath.append(nextarg);
paths[0] = currentpath.tostring();
return localindex - index;
} else if (count < 0) {
throw new illegalargumentexception(
this.bind("configure.unexpectedbracket", //$non-nls-1$
currentarg));
} else {
currentpath.append(' ');
currentpath.append(nextarg);
}
}

}
return localindex - index;
}
/**
* creates a nls catalog for the given locale.
*/
public void relocalize() {
relocalize(locale.getdefault());
}

private void relocalize(locale locale) {
this.compilerlocale = locale;
try {
this.bundle = resourcebundlefactory.getbundle(locale);
} catch(missingresourceexception e) {
system.out.println("missing resource : " + main.bundlename.replace('.', '/') + ".properties for locale " + locale); //$non-nls-1$//$non-nls-2$
throw e;
}
}
/*
* external api
*/
public void setdestinationpath(string dest) {
this.destinationpath = dest;
}
/*
* external api
*/
public void setlocale(locale locale) {
relocalize(locale);
}
/*
* external api
*/
protected void setpaths(arraylist bootclasspaths,
string sourcepathclasspatharg,
arraylist sourcepathclasspaths,
arraylist classpaths,
arraylist extdirsclasspaths,
arraylist endorseddirclasspaths,
string customencoding) {

// process bootclasspath, classpath and sourcepaths
bootclasspaths = handlebootclasspath(bootclasspaths, customencoding);

classpaths = handleclasspath(classpaths, customencoding);

if (sourcepathclasspatharg != null) {
processpathentries(default_size_classpath, sourcepathclasspaths,
sourcepathclasspatharg, customencoding, true, false);
}

/*
* feed endorseddirclasspath according to:
* - -extdirs first if present;
* - else java.ext.dirs if defined;
* - else default extensions directory for the platform.
*/
extdirsclasspaths = handleextdirs(extdirsclasspaths);

endorseddirclasspaths = handleendorseddirs(endorseddirclasspaths);

/*
* concatenate classpath entries
* we put the bootclasspath at the beginning of the classpath
* entries, followed by the extension libraries, followed by
* the sourcepath followed by the classpath.  all classpath
* entries are searched for both sources and binaries except
* the sourcepath entries which are searched for sources only.
*/
bootclasspaths.addall(endorseddirclasspaths);
bootclasspaths.addall(extdirsclasspaths);
bootclasspaths.addall(sourcepathclasspaths);
bootclasspaths.addall(classpaths);
classpaths = bootclasspaths;
classpaths = filesystem.classpathnormalizer.normalize(classpaths);
this.checkedclasspaths = new filesystem.classpath[classpaths.size()];
classpaths.toarray(this.checkedclasspaths);
this.logger.logclasspath(this.checkedclasspaths);
}
protected void validateoptions(boolean didspecifycompliance) {
if (didspecifycompliance) {
object version = this.options.get(compileroptions.option_compliance);
if (compileroptions.version_1_3.equals(version)) {
if (!this.didspecifysource) this.options.put(compileroptions.option_source, compileroptions.version_1_3);
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_1);
} else if (compileroptions.version_1_4.equals(version)) {
if (this.didspecifysource) {
object source = this.options.get(compileroptions.option_source);
if (compileroptions.version_1_3.equals(source)) {
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_2);
} else if (compileroptions.version_1_4.equals(source)) {
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_4);
}
} else {
this.options.put(compileroptions.option_source, compileroptions.version_1_3);
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_2);
}
} else if (compileroptions.version_1_5.equals(version)) {
if (this.didspecifysource) {
object source = this.options.get(compileroptions.option_source);
if (compileroptions.version_1_3.equals(source)
|| compileroptions.version_1_4.equals(source)) {
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_4);
} else if (compileroptions.version_1_5.equals(source)) {
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_5);
}
} else {
this.options.put(compileroptions.option_source, compileroptions.version_1_5);
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_5);
}
} else if (compileroptions.version_1_6.equals(version)) {
if (this.didspecifysource) {
object source = this.options.get(compileroptions.option_source);
if (compileroptions.version_1_3.equals(source)
|| compileroptions.version_1_4.equals(source)) {
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_4);
} else if (compileroptions.version_1_5.equals(source)
|| compileroptions.version_1_6.equals(source)) {
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_6);
}
} else {
this.options.put(compileroptions.option_source, compileroptions.version_1_6);
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_6);
}
} else if (compileroptions.version_1_7.equals(version)) {
if (this.didspecifysource) {
object source = this.options.get(compileroptions.option_source);
if (compileroptions.version_1_3.equals(source)
|| compileroptions.version_1_4.equals(source)) {
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_4);
} else if (compileroptions.version_1_5.equals(source)
|| compileroptions.version_1_6.equals(source)) {
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_6);
} else if (compileroptions.version_1_7.equals(source)) {
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_7);
}
} else {
this.options.put(compileroptions.option_source, compileroptions.version_1_7);
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_7);
}
}
} else if (this.didspecifysource) {
object version = this.options.get(compileroptions.option_source);
// default is source 1.3 target 1.2 and compliance 1.4
if (compileroptions.version_1_4.equals(version)) {
if (!didspecifycompliance) this.options.put(compileroptions.option_compliance, compileroptions.version_1_4);
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_4);
} else if (compileroptions.version_1_5.equals(version)) {
if (!didspecifycompliance) this.options.put(compileroptions.option_compliance, compileroptions.version_1_5);
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_5);
} else if (compileroptions.version_1_6.equals(version)) {
if (!didspecifycompliance) this.options.put(compileroptions.option_compliance, compileroptions.version_1_6);
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_6);
} else if (compileroptions.version_1_7.equals(version)) {
if (!didspecifycompliance) this.options.put(compileroptions.option_compliance, compileroptions.version_1_7);
if (!this.didspecifytarget) this.options.put(compileroptions.option_targetplatform, compileroptions.version_1_7);
}
}

final object sourceversion = this.options.get(compileroptions.option_source);
final object compliance = this.options.get(compileroptions.option_compliance);
if (sourceversion.equals(compileroptions.version_1_7)
&& compileroptions.versiontojdklevel(compliance) < classfileconstants.jdk1_7) {
// compliance must be 1.7 if source is 1.7
throw new illegalargumentexception(this.bind("configure.incompatiblecomplianceforsource", (string)this.options.get(compileroptions.option_compliance), compileroptions.version_1_7)); //$non-nls-1$
} else if (sourceversion.equals(compileroptions.version_1_6)
&& compileroptions.versiontojdklevel(compliance) < classfileconstants.jdk1_6) {
// compliance must be 1.6 if source is 1.6
throw new illegalargumentexception(this.bind("configure.incompatiblecomplianceforsource", (string)this.options.get(compileroptions.option_compliance), compileroptions.version_1_6)); //$non-nls-1$
} else if (sourceversion.equals(compileroptions.version_1_5)
&& compileroptions.versiontojdklevel(compliance) < classfileconstants.jdk1_5) {
// compliance must be 1.5 if source is 1.5
throw new illegalargumentexception(this.bind("configure.incompatiblecomplianceforsource", (string)this.options.get(compileroptions.option_compliance), compileroptions.version_1_5)); //$non-nls-1$
} else if (sourceversion.equals(compileroptions.version_1_4)
&& compileroptions.versiontojdklevel(compliance) < classfileconstants.jdk1_4) {
// compliance must be 1.4 if source is 1.4
throw new illegalargumentexception(this.bind("configure.incompatiblecomplianceforsource", (string)this.options.get(compileroptions.option_compliance), compileroptions.version_1_4)); //$non-nls-1$
}

// check and set compliance/source/target compatibilities
if (this.didspecifytarget) {
final object targetversion = this.options.get(compileroptions.option_targetplatform);
// tolerate jsr14 target
if (compileroptions.version_jsr14.equals(targetversion)) {
// expecting source >= 1.5
if (compileroptions.versiontojdklevel(sourceversion) < classfileconstants.jdk1_5) {
throw new illegalargumentexception(this.bind("configure.incompatibletargetforgenericsource", (string) targetversion, (string) sourceversion)); //$non-nls-1$
}
} else if (compileroptions.version_cldc1_1.equals(targetversion)) {
if (this.didspecifysource && compileroptions.versiontojdklevel(sourceversion) >= classfileconstants.jdk1_4) {
throw new illegalargumentexception(this.bind("configure.incompatiblesourceforcldctarget", (string) targetversion, (string) sourceversion)); //$non-nls-1$
}
if (compileroptions.versiontojdklevel(compliance) >= classfileconstants.jdk1_5) {
throw new illegalargumentexception(this.bind("configure.incompatiblecomplianceforcldctarget", (string) targetversion, (string) sourceversion)); //$non-nls-1$
}
} else {
// target must be 1.7 if source is 1.7
if (compileroptions.versiontojdklevel(sourceversion) >= classfileconstants.jdk1_7
&& compileroptions.versiontojdklevel(targetversion) < classfileconstants.jdk1_7){
throw new illegalargumentexception(this.bind("configure.incompatibletargetforsource", (string) targetversion, compileroptions.version_1_7)); //$non-nls-1$
}
// target must be 1.6 if source is 1.6
if (compileroptions.versiontojdklevel(sourceversion) >= classfileconstants.jdk1_6
&& compileroptions.versiontojdklevel(targetversion) < classfileconstants.jdk1_6){
throw new illegalargumentexception(this.bind("configure.incompatibletargetforsource", (string) targetversion, compileroptions.version_1_6)); //$non-nls-1$
}
// target must be 1.5 if source is 1.5
if (compileroptions.versiontojdklevel(sourceversion) >= classfileconstants.jdk1_5
&& compileroptions.versiontojdklevel(targetversion) < classfileconstants.jdk1_5){
throw new illegalargumentexception(this.bind("configure.incompatibletargetforsource", (string) targetversion, compileroptions.version_1_5)); //$non-nls-1$
}
// target must be 1.4 if source is 1.4
if (compileroptions.versiontojdklevel(sourceversion) >= classfileconstants.jdk1_4
&& compileroptions.versiontojdklevel(targetversion) < classfileconstants.jdk1_4){
throw new illegalargumentexception(this.bind("configure.incompatibletargetforsource", (string) targetversion, compileroptions.version_1_4)); //$non-nls-1$
}
// target cannot be greater than compliance level
if (compileroptions.versiontojdklevel(compliance) < compileroptions.versiontojdklevel(targetversion)){
throw new illegalargumentexception(this.bind("configure.incompatiblecompliancefortarget", (string)this.options.get(compileroptions.option_compliance), (string) targetversion)); //$non-nls-1$
}
}
}
}
}
