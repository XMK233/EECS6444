/*******************************************************************************
* copyright (c) 2000, 2010 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.impl.*;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.*;
import org.eclipse.jdt.internal.compiler.flow.*;
import org.eclipse.jdt.internal.compiler.lookup.*;

public class equalexpression extends binaryexpression {

public equalexpression(expression left, expression right,int operator) {
super(left,right,operator);
}
private void checknullcomparison(blockscope scope, flowcontext flowcontext, flowinfo flowinfo, flowinfo initswhentrue, flowinfo initswhenfalse) {

localvariablebinding local = this.left.localvariablebinding();
if (local != null && (local.type.tagbits & tagbits.isbasetype) == 0) {
checkvariablecomparison(scope, flowcontext, flowinfo, initswhentrue, initswhenfalse, local, this.right.nullstatus(flowinfo), this.left);
}
local = this.right.localvariablebinding();
if (local != null && (local.type.tagbits & tagbits.isbasetype) == 0) {
checkvariablecomparison(scope, flowcontext, flowinfo, initswhentrue, initswhenfalse, local, this.left.nullstatus(flowinfo), this.right);
}
}
private void checkvariablecomparison(blockscope scope, flowcontext flowcontext, flowinfo flowinfo, flowinfo initswhentrue, flowinfo initswhenfalse, localvariablebinding local, int nullstatus, expression reference) {
switch (nullstatus) {
case flowinfo.null :
if (((this.bits & operatormask) >> operatorshift) == equal_equal) {
flowcontext.recordusingnullreference(scope, local, reference,
flowcontext.can_only_null_non_null | flowcontext.in_comparison_null, flowinfo);
initswhentrue.markascomparedequaltonull(local); // from thereon it is set
initswhenfalse.markascomparedequaltononnull(local); // from thereon it is set
} else {
flowcontext.recordusingnullreference(scope, local, reference,
flowcontext.can_only_null_non_null | flowcontext.in_comparison_non_null, flowinfo);
initswhentrue.markascomparedequaltononnull(local); // from thereon it is set
initswhenfalse.markascomparedequaltonull(local); // from thereon it is set
}
if ((flowcontext.tagbits & flowcontext.hide_null_comparison_warning) != 0) {
flowinfo.markedasnullornonnullinassertexpression(local);
}
break;
case flowinfo.non_null :
if (((this.bits & operatormask) >> operatorshift) == equal_equal) {
flowcontext.recordusingnullreference(scope, local, reference,
flowcontext.can_only_null | flowcontext.in_comparison_non_null, flowinfo);
initswhentrue.markascomparedequaltononnull(local); // from thereon it is set
} else {
flowcontext.recordusingnullreference(scope, local, reference,
flowcontext.can_only_null | flowcontext.in_comparison_null, flowinfo);
}
break;
}
// we do not impact enclosing try context because this kind of protection
// does not preclude the variable from being null in an enclosing scope
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
flowinfo result;
if (((this.bits & operatormask) >> operatorshift) == equal_equal) {
if ((this.left.constant != constant.notaconstant) && (this.left.constant.typeid() == t_boolean)) {
if (this.left.constant.booleanvalue()) { //  true == anything
//  this is equivalent to the right argument inits
result = this.right.analysecode(currentscope, flowcontext, flowinfo);
} else { // false == anything
//  this is equivalent to the right argument inits negated
result = this.right.analysecode(currentscope, flowcontext, flowinfo).asnegatedcondition();
}
}
else if ((this.right.constant != constant.notaconstant) && (this.right.constant.typeid() == t_boolean)) {
if (this.right.constant.booleanvalue()) { //  anything == true
//  this is equivalent to the left argument inits
result = this.left.analysecode(currentscope, flowcontext, flowinfo);
} else { // anything == false
//  this is equivalent to the right argument inits negated
result = this.left.analysecode(currentscope, flowcontext, flowinfo).asnegatedcondition();
}
}
else {
result = this.right.analysecode(
currentscope, flowcontext,
this.left.analysecode(currentscope, flowcontext, flowinfo).unconditionalinits()).unconditionalinits();
}
} else { //not_equal :
if ((this.left.constant != constant.notaconstant) && (this.left.constant.typeid() == t_boolean)) {
if (!this.left.constant.booleanvalue()) { //  false != anything
//  this is equivalent to the right argument inits
result = this.right.analysecode(currentscope, flowcontext, flowinfo);
} else { // true != anything
//  this is equivalent to the right argument inits negated
result = this.right.analysecode(currentscope, flowcontext, flowinfo).asnegatedcondition();
}
}
else if ((this.right.constant != constant.notaconstant) && (this.right.constant.typeid() == t_boolean)) {
if (!this.right.constant.booleanvalue()) { //  anything != false
//  this is equivalent to the right argument inits
result = this.left.analysecode(currentscope, flowcontext, flowinfo);
} else { // anything != true
//  this is equivalent to the right argument inits negated
result = this.left.analysecode(currentscope, flowcontext, flowinfo).asnegatedcondition();
}
}
else {
result = this.right.analysecode(
currentscope, flowcontext,
this.left.analysecode(currentscope, flowcontext, flowinfo).unconditionalinits()).
/* unneeded since we flatten it: asnegatedcondition(). */
unconditionalinits();
}
}
if (result instanceof unconditionalflowinfo &&
(result.tagbits & flowinfo.unreachable) == 0) { // the flow info is flat
result = flowinfo.conditional(result.copy(), result.copy());
// todo (maxime) check, reintroduced copy
}
checknullcomparison(currentscope, flowcontext, result, result.initswhentrue(), result.initswhenfalse());
return result;
}

public final void computeconstant(typebinding lefttype, typebinding righttype) {
if ((this.left.constant != constant.notaconstant) && (this.right.constant != constant.notaconstant)) {
this.constant =
constant.computeconstantoperationequal_equal(
this.left.constant,
lefttype.id,
this.right.constant,
righttype.id);
if (((this.bits & operatormask) >> operatorshift) == not_equal)
this.constant = booleanconstant.fromvalue(!this.constant.booleanvalue());
} else {
this.constant = constant.notaconstant;
// no optimization for null == null
}
}
/**
* normal == or != code generation.
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
* @@param valuerequired boolean
*/
public void generatecode(blockscope currentscope, codestream codestream, boolean valuerequired) {

int pc = codestream.position;
if (this.constant != constant.notaconstant) {
if (valuerequired)
codestream.generateconstant(this.constant, this.implicitconversion);
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}

if ((this.left.implicitconversion & compile_type_mask) /*compile-time*/ == t_boolean) {
generatebooleanequal(currentscope, codestream, valuerequired);
} else {
generatenonbooleanequal(currentscope, codestream, valuerequired);
}
if (valuerequired) {
codestream.generateimplicitconversion(this.implicitconversion);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}
/**
* boolean operator code generation
*	optimized operations are: == and !=
*/
public void generateoptimizedboolean(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {

if (this.constant != constant.notaconstant) {
super.generateoptimizedboolean(currentscope, codestream, truelabel, falselabel, valuerequired);
return;
}
if (((this.bits & operatormask) >> operatorshift) == equal_equal) {
if ((this.left.implicitconversion & compile_type_mask) /*compile-time*/ == t_boolean) {
generateoptimizedbooleanequal(currentscope, codestream, truelabel, falselabel, valuerequired);
} else {
generateoptimizednonbooleanequal(currentscope, codestream, truelabel, falselabel, valuerequired);
}
} else {
if ((this.left.implicitconversion & compile_type_mask) /*compile-time*/ == t_boolean) {
generateoptimizedbooleanequal(currentscope, codestream, falselabel, truelabel, valuerequired);
} else {
generateoptimizednonbooleanequal(currentscope, codestream, falselabel, truelabel, valuerequired);
}
}
}

/**
* boolean generation for == with boolean operands
*
* note this code does not optimize conditional constants !!!!
*/
public void generatebooleanequal(blockscope currentscope, codestream codestream, boolean valuerequired) {

// optimized cases: <something equivalent to true> == x, <something equivalent to false> == x,
// optimized cases: <something equivalent to false> != x, <something equivalent to true> != x,
boolean isequaloperator = ((this.bits & operatormask) >> operatorshift) == equal_equal;
constant cst = this.left.optimizedbooleanconstant();
if (cst != constant.notaconstant) {
constant rightcst = this.right.optimizedbooleanconstant();
if (rightcst != constant.notaconstant) {
// <something equivalent to true> == <something equivalent to true>, <something equivalent to false> != <something equivalent to true>
// <something equivalent to true> == <something equivalent to false>, <something equivalent to false> != <something equivalent to false>
this.left.generatecode(currentscope, codestream, false);
this.right.generatecode(currentscope, codestream, false);
if (valuerequired) {
boolean leftbool = cst.booleanvalue();
boolean rightbool = rightcst.booleanvalue();
if (isequaloperator) {
if (leftbool == rightbool) {
codestream.iconst_1();
} else {
codestream.iconst_0();
}
} else {
if (leftbool != rightbool) {
codestream.iconst_1();
} else {
codestream.iconst_0();
}
}
}
} else if (cst.booleanvalue() == isequaloperator) {
// <something equivalent to true> == x, <something equivalent to false> != x
this.left.generatecode(currentscope, codestream, false);
this.right.generatecode(currentscope, codestream, valuerequired);
} else {
// <something equivalent to false> == x, <something equivalent to true> != x
if (valuerequired) {
branchlabel falselabel = new branchlabel(codestream);
this.left.generatecode(currentscope, codestream, false);
this.right.generateoptimizedboolean(currentscope, codestream, null, falselabel, valuerequired);
// comparison is true
codestream.iconst_0();
if ((this.bits & isreturnedvalue) != 0){
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
// comparison is false
falselabel.place();
codestream.iconst_1();
} else {
branchlabel endlabel = new branchlabel(codestream);
codestream.goto_(endlabel);
codestream.decrstacksize(1);
// comparison is false
falselabel.place();
codestream.iconst_1();
endlabel.place();
}
} else {
this.left.generatecode(currentscope, codestream, false);
this.right.generatecode(currentscope, codestream, false);
}
//				left.generatecode(currentscope, codestream, false);
//				right.generatecode(currentscope, codestream, valuerequired);
//				if (valuerequired) {
//					codestream.iconst_1();
//					codestream.ixor(); // negate
//				}
}
return;
}
cst = this.right.optimizedbooleanconstant();
if (cst != constant.notaconstant) {
if (cst.booleanvalue() == isequaloperator) {
// x == <something equivalent to true>, x != <something equivalent to false>
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, false);
} else {
// x == <something equivalent to false>, x != <something equivalent to true>
if (valuerequired) {
branchlabel falselabel = new branchlabel(codestream);
this.left.generateoptimizedboolean(currentscope, codestream, null, falselabel, valuerequired);
this.right.generatecode(currentscope, codestream, false);
// comparison is true
codestream.iconst_0();
if ((this.bits & isreturnedvalue) != 0){
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
// comparison is false
falselabel.place();
codestream.iconst_1();
} else {
branchlabel endlabel = new branchlabel(codestream);
codestream.goto_(endlabel);
codestream.decrstacksize(1);
// comparison is false
falselabel.place();
codestream.iconst_1();
endlabel.place();
}
} else {
this.left.generatecode(currentscope, codestream, false);
this.right.generatecode(currentscope, codestream, false);
}
//				left.generatecode(currentscope, codestream, valuerequired);
//				right.generatecode(currentscope, codestream, false);
//				if (valuerequired) {
//					codestream.iconst_1();
//					codestream.ixor(); // negate
//				}
}
return;
}
// default case
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);

if (valuerequired) {
if (isequaloperator) {
branchlabel falselabel;
codestream.if_icmpne(falselabel = new branchlabel(codestream));
// comparison is true
codestream.iconst_1();
if ((this.bits & isreturnedvalue) != 0){
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
// comparison is false
falselabel.place();
codestream.iconst_0();
} else {
branchlabel endlabel = new branchlabel(codestream);
codestream.goto_(endlabel);
codestream.decrstacksize(1);
// comparison is false
falselabel.place();
codestream.iconst_0();
endlabel.place();
}
} else {
codestream.ixor();
}
}
}

/**
* boolean generation for == with boolean operands
*
* note this code does not optimize conditional constants !!!!
*/
public void generateoptimizedbooleanequal(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {

// optimized cases: true == x, false == x
if (this.left.constant != constant.notaconstant) {
boolean inline = this.left.constant.booleanvalue();
this.right.generateoptimizedboolean(currentscope, codestream, (inline ? truelabel : falselabel), (inline ? falselabel : truelabel), valuerequired);
return;
} // optimized cases: x == true, x == false
if (this.right.constant != constant.notaconstant) {
boolean inline = this.right.constant.booleanvalue();
this.left.generateoptimizedboolean(currentscope, codestream, (inline ? truelabel : falselabel), (inline ? falselabel : truelabel), valuerequired);
return;
}
// default case
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
codestream.if_icmpeq(truelabel);
}
} else {
// implicit falling through the true case
if (truelabel == null) {
codestream.if_icmpne(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
// reposition the endpc
codestream.updatelastrecordedendpc(currentscope, codestream.position);
}
/**
* boolean generation for == with non-boolean operands
*
*/
public void generatenonbooleanequal(blockscope currentscope, codestream codestream, boolean valuerequired) {

boolean isequaloperator = ((this.bits & operatormask) >> operatorshift) == equal_equal;
if (((this.left.implicitconversion & implicit_conversion_mask) >> 4) == t_int) {
constant cst;
if ((cst = this.left.constant) != constant.notaconstant && cst.intvalue() == 0) {
// optimized case: 0 == x, 0 != x
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
branchlabel falselabel = new branchlabel(codestream);
if (isequaloperator) {
codestream.ifne(falselabel);
} else {
codestream.ifeq(falselabel);
}
// comparison is true
codestream.iconst_1();
if ((this.bits & isreturnedvalue) != 0){
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
// comparison is false
falselabel.place();
codestream.iconst_0();
} else {
branchlabel endlabel = new branchlabel(codestream);
codestream.goto_(endlabel);
codestream.decrstacksize(1);
// comparison is false
falselabel.place();
codestream.iconst_0();
endlabel.place();
}
}
return;
}
if ((cst = this.right.constant) != constant.notaconstant && cst.intvalue() == 0) {
// optimized case: x == 0, x != 0
this.left.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
branchlabel falselabel = new branchlabel(codestream);
if (isequaloperator) {
codestream.ifne(falselabel);
} else {
codestream.ifeq(falselabel);
}
// comparison is true
codestream.iconst_1();
if ((this.bits & isreturnedvalue) != 0){
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
// comparison is false
falselabel.place();
codestream.iconst_0();
} else {
branchlabel endlabel = new branchlabel(codestream);
codestream.goto_(endlabel);
codestream.decrstacksize(1);
// comparison is false
falselabel.place();
codestream.iconst_0();
endlabel.place();
}
}
return;
}
}

// null cases
if (this.right instanceof nullliteral) {
if (this.left instanceof nullliteral) {
// null == null, null != null
if (valuerequired) {
if (isequaloperator) {
codestream.iconst_1();
} else {
codestream.iconst_0();
}
}
} else {
// x == null, x != null
this.left.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
branchlabel falselabel = new branchlabel(codestream);
if (isequaloperator) {
codestream.ifnonnull(falselabel);
} else {
codestream.ifnull(falselabel);
}
// comparison is true
codestream.iconst_1();
if ((this.bits & isreturnedvalue) != 0){
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
// comparison is false
falselabel.place();
codestream.iconst_0();
} else {
branchlabel endlabel = new branchlabel(codestream);
codestream.goto_(endlabel);
codestream.decrstacksize(1);
// comparison is false
falselabel.place();
codestream.iconst_0();
endlabel.place();
}
}
}
return;
} else if (this.left instanceof nullliteral) {
// null = x, null != x
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
branchlabel falselabel = new branchlabel(codestream);
if (isequaloperator) {
codestream.ifnonnull(falselabel);
} else {
codestream.ifnull(falselabel);
}
// comparison is true
codestream.iconst_1();
if ((this.bits & isreturnedvalue) != 0){
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
// comparison is false
falselabel.place();
codestream.iconst_0();
} else {
branchlabel endlabel = new branchlabel(codestream);
codestream.goto_(endlabel);
codestream.decrstacksize(1);
// comparison is false
falselabel.place();
codestream.iconst_0();
endlabel.place();
}
}
return;
}

// default case
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
branchlabel falselabel = new branchlabel(codestream);
if (isequaloperator) {
switch ((this.left.implicitconversion & implicit_conversion_mask) >> 4) { // operand runtime type
case t_int :
codestream.if_icmpne(falselabel);
break;
case t_float :
codestream.fcmpl();
codestream.ifne(falselabel);
break;
case t_long :
codestream.lcmp();
codestream.ifne(falselabel);
break;
case t_double :
codestream.dcmpl();
codestream.ifne(falselabel);
break;
default :
codestream.if_acmpne(falselabel);
}
} else {
switch ((this.left.implicitconversion & implicit_conversion_mask) >> 4) { // operand runtime type
case t_int :
codestream.if_icmpeq(falselabel);
break;
case t_float :
codestream.fcmpl();
codestream.ifeq(falselabel);
break;
case t_long :
codestream.lcmp();
codestream.ifeq(falselabel);
break;
case t_double :
codestream.dcmpl();
codestream.ifeq(falselabel);
break;
default :
codestream.if_acmpeq(falselabel);
}
}
// comparison is true
codestream.iconst_1();
if ((this.bits & isreturnedvalue) != 0){
codestream.generateimplicitconversion(this.implicitconversion);
codestream.generatereturnbytecode(this);
// comparison is false
falselabel.place();
codestream.iconst_0();
} else {
branchlabel endlabel = new branchlabel(codestream);
codestream.goto_(endlabel);
codestream.decrstacksize(1);
// comparison is false
falselabel.place();
codestream.iconst_0();
endlabel.place();
}
}
}

/**
* boolean generation for == with non-boolean operands
*
*/
public void generateoptimizednonbooleanequal(blockscope currentscope, codestream codestream, branchlabel truelabel, branchlabel falselabel, boolean valuerequired) {

int pc = codestream.position;
constant inline;
if ((inline = this.right.constant) != constant.notaconstant) {
// optimized case: x == 0
if ((((this.left.implicitconversion & implicit_conversion_mask) >> 4) == t_int) && (inline.intvalue() == 0)) {
this.left.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
codestream.ifeq(truelabel);
}
} else {
// implicit falling through the true case
if (truelabel == null) {
codestream.ifne(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
}
if ((inline = this.left.constant) != constant.notaconstant) {
// optimized case: 0 == x
if ((((this.left.implicitconversion & implicit_conversion_mask) >> 4) == t_int)
&& (inline.intvalue() == 0)) {
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
codestream.ifeq(truelabel);
}
} else {
// implicit falling through the true case
if (truelabel == null) {
codestream.ifne(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}
}
// null cases
// optimized case: x == null
if (this.right instanceof nullliteral) {
if (this.left instanceof nullliteral) {
// null == null
if (valuerequired) {
if (falselabel == null) {
// implicit falling through the false case
if (truelabel != null) {
codestream.goto_(truelabel);
}
}
}
} else {
this.left.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
codestream.ifnull(truelabel);
}
} else {
// implicit falling through the true case
if (truelabel == null) {
codestream.ifnonnull(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
} else if (this.left instanceof nullliteral) { // optimized case: null == x
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
codestream.ifnull(truelabel);
}
} else {
// implicit falling through the true case
if (truelabel == null) {
codestream.ifnonnull(falselabel);
} else {
// no implicit fall through true/false --> should never occur
}
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
return;
}

// default case
this.left.generatecode(currentscope, codestream, valuerequired);
this.right.generatecode(currentscope, codestream, valuerequired);
if (valuerequired) {
if (falselabel == null) {
if (truelabel != null) {
// implicit falling through the false case
switch ((this.left.implicitconversion & implicit_conversion_mask) >> 4) { // operand runtime type
case t_int :
codestream.if_icmpeq(truelabel);
break;
case t_float :
codestream.fcmpl();
codestream.ifeq(truelabel);
break;
case t_long :
codestream.lcmp();
codestream.ifeq(truelabel);
break;
case t_double :
codestream.dcmpl();
codestream.ifeq(truelabel);
break;
default :
codestream.if_acmpeq(truelabel);
}
}
} else {
// implicit falling through the true case
if (truelabel == null) {
switch ((this.left.implicitconversion & implicit_conversion_mask) >> 4) { // operand runtime type
case t_int :
codestream.if_icmpne(falselabel);
break;
case t_float :
codestream.fcmpl();
codestream.ifne(falselabel);
break;
case t_long :
codestream.lcmp();
codestream.ifne(falselabel);
break;
case t_double :
codestream.dcmpl();
codestream.ifne(falselabel);
break;
default :
codestream.if_acmpne(falselabel);
}
} else {
// no implicit fall through true/false --> should never occur
}
}
}
codestream.recordpositionsfrom(pc, this.sourcestart);
}
public boolean iscompactableoperation() {
return false;
}
public typebinding resolvetype(blockscope scope) {

boolean leftiscast, rightiscast;
if ((leftiscast = this.left instanceof castexpression) == true) this.left.bits |= disableunnecessarycastcheck; // will check later on
typebinding originallefttype = this.left.resolvetype(scope);

if ((rightiscast = this.right instanceof castexpression) == true) this.right.bits |= disableunnecessarycastcheck; // will check later on
typebinding originalrighttype = this.right.resolvetype(scope);

// always return booleanbinding
if (originallefttype == null || originalrighttype == null){
this.constant = constant.notaconstant;
return null;
}

// autoboxing support
boolean use15specifics = scope.compileroptions().sourcelevel >= classfileconstants.jdk1_5;
typebinding lefttype = originallefttype, righttype = originalrighttype;
if (use15specifics) {
if (lefttype != typebinding.null && lefttype.isbasetype()) {
if (!righttype.isbasetype()) {
righttype = scope.environment().computeboxingtype(righttype);
}
} else {
if (righttype != typebinding.null && righttype.isbasetype()) {
lefttype = scope.environment().computeboxingtype(lefttype);
}
}
}
// both base type
if (lefttype.isbasetype() && righttype.isbasetype()) {
int lefttypeid = lefttype.id;
int righttypeid = righttype.id;

// the code is an int
// (cast)  left   == (cast)  right --> result
//  0000   0000       0000   0000      0000
//  <<16   <<12       <<8    <<4       <<0
int operatorsignature = operatorsignatures[equal_equal][ (lefttypeid << 4) + righttypeid];
this.left.computeconversion(scope, typebinding.wellknowntype(scope, (operatorsignature >>> 16) & 0x0000f), originallefttype);
this.right.computeconversion(scope, typebinding.wellknowntype(scope, (operatorsignature >>> 8) & 0x0000f), originalrighttype);
this.bits |= operatorsignature & 0xf;
if ((operatorsignature & 0x0000f) == t_undefined) {
this.constant = constant.notaconstant;
scope.problemreporter().invalidoperator(this, lefttype, righttype);
return null;
}
// check need for operand cast
if (leftiscast || rightiscast) {
castexpression.checkneedforargumentcasts(scope, equal_equal, operatorsignature, this.left, lefttype.id, leftiscast, this.right, righttype.id, rightiscast);
}
computeconstant(lefttype, righttype);

// check whether comparing identical expressions
binding leftdirect = expression.getdirectbinding(this.left);
if (leftdirect != null && leftdirect == expression.getdirectbinding(this.right)) {
if (lefttypeid != typeids.t_double && lefttypeid != typeids.t_float
&&(!(this.right instanceof assignment))) // https://bugs.eclipse.org/bugs/show_bug.cgi?id=281776
scope.problemreporter().comparingidenticalexpressions(this);
} else if (this.constant != constant.notaconstant) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=276740
int operator = (this.bits & operatormask) >> operatorshift;
if ((operator == equal_equal && this.constant == booleanconstant.fromvalue(true))
|| (operator == not_equal && this.constant == booleanconstant.fromvalue(false)))
scope.problemreporter().comparingidenticalexpressions(this);
}
return this.resolvedtype = typebinding.boolean;
}

// object references
// spec 15.20.3
if ((!lefttype.isbasetype() || lefttype == typebinding.null) // cannot compare: object == (int)0
&& (!righttype.isbasetype() || righttype == typebinding.null)
&& (checkcasttypescompatibility(scope, lefttype, righttype, null)
|| checkcasttypescompatibility(scope, righttype, lefttype, null))) {

// (special case for string)
if ((righttype.id == t_javalangstring) && (lefttype.id == t_javalangstring)) {
computeconstant(lefttype, righttype);
} else {
this.constant = constant.notaconstant;
}
typebinding objecttype = scope.getjavalangobject();
this.left.computeconversion(scope, objecttype, lefttype);
this.right.computeconversion(scope, objecttype, righttype);
// check need for operand cast
boolean unnecessaryleftcast = (this.left.bits & unnecessarycast) != 0;
boolean unnecessaryrightcast = (this.right.bits & unnecessarycast) != 0;
if (unnecessaryleftcast || unnecessaryrightcast) {
typebinding alternatelefttype = unnecessaryleftcast ? ((castexpression)this.left).expression.resolvedtype : lefttype;
typebinding alternaterighttype = unnecessaryrightcast ? ((castexpression)this.right).expression.resolvedtype : righttype;
if (checkcasttypescompatibility(scope, alternatelefttype, alternaterighttype, null)
|| checkcasttypescompatibility(scope, alternaterighttype, alternatelefttype, null)) {
if (unnecessaryleftcast) scope.problemreporter().unnecessarycast((castexpression)this.left);
if (unnecessaryrightcast) scope.problemreporter().unnecessarycast((castexpression)this.right);
}
}
// check whether comparing identical expressions
binding leftdirect = expression.getdirectbinding(this.left);
if (leftdirect != null && leftdirect == expression.getdirectbinding(this.right)) {
if (!(this.right instanceof assignment)) {
scope.problemreporter().comparingidenticalexpressions(this);
}
}
return this.resolvedtype = typebinding.boolean;
}
this.constant = constant.notaconstant;
scope.problemreporter().notcompatibletypeserror(this, lefttype, righttype);
return null;
}
public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
this.left.traverse(visitor, scope);
this.right.traverse(visitor, scope);
}
visitor.endvisit(this, scope);
}
}
