/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.classfmt.classfileconstants;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.codegen.opcodes;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.lookup.binding;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;
import org.eclipse.jdt.internal.compiler.lookup.extracompilermodifiers;
import org.eclipse.jdt.internal.compiler.lookup.invocationsite;
import org.eclipse.jdt.internal.compiler.lookup.localtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.methodbinding;
import org.eclipse.jdt.internal.compiler.lookup.methodscope;
import org.eclipse.jdt.internal.compiler.lookup.problemmethodbinding;
import org.eclipse.jdt.internal.compiler.lookup.rawtypebinding;
import org.eclipse.jdt.internal.compiler.lookup.referencebinding;
import org.eclipse.jdt.internal.compiler.lookup.sourcetypebinding;
import org.eclipse.jdt.internal.compiler.lookup.tagbits;
import org.eclipse.jdt.internal.compiler.lookup.typebinding;
import org.eclipse.jdt.internal.compiler.lookup.typeconstants;
import org.eclipse.jdt.internal.compiler.lookup.typeids;
import org.eclipse.jdt.internal.compiler.lookup.variablebinding;

public class explicitconstructorcall extends statement implements invocationsite {

public expression[] arguments;
public expression qualification;
public methodbinding binding;							// exact binding resulting from lookup
methodbinding syntheticaccessor;						// synthetic accessor for inner-emulation
public int accessmode;
public typereference[] typearguments;
public typebinding[] generictypearguments;

public final static int implicitsuper = 1;
public final static int super = 2;
public final static int this = 3;

public variablebinding[][] implicitarguments;

// todo remove once domparser is activated
public int typeargumentssourcestart;

public explicitconstructorcall(int accessmode) {
this.accessmode = accessmode;
}

public flowinfo analysecode(blockscope currentscope, flowcontext flowcontext, flowinfo flowinfo) {
// must verify that exceptions potentially thrown by this expression are caught in the method.

try {
((methodscope) currentscope).isconstructorcall = true;

// process enclosing instance
if (this.qualification != null) {
flowinfo =
this.qualification
.analysecode(currentscope, flowcontext, flowinfo)
.unconditionalinits();
}
// process arguments
if (this.arguments != null) {
for (int i = 0, max = this.arguments.length; i < max; i++) {
flowinfo =
this.arguments[i]
.analysecode(currentscope, flowcontext, flowinfo)
.unconditionalinits();
}
}

referencebinding[] thrownexceptions;
if ((thrownexceptions = this.binding.thrownexceptions) != binding.no_exceptions) {
if ((this.bits & astnode.unchecked) != 0 && this.generictypearguments == null) {
// https://bugs.eclipse.org/bugs/show_bug.cgi?id=277643, align with javac on jls 15.12.2.6
thrownexceptions = currentscope.environment().converttorawtypes(this.binding.thrownexceptions, true, true);
}
// check exceptions
flowcontext.checkexceptionhandlers(
thrownexceptions,
(this.accessmode == explicitconstructorcall.implicitsuper)
? (astnode) currentscope.methodscope().referencecontext
: (astnode) this,
flowinfo,
currentscope);
}
manageenclosinginstanceaccessifnecessary(currentscope, flowinfo);
managesyntheticaccessifnecessary(currentscope, flowinfo);
return flowinfo;
} finally {
((methodscope) currentscope).isconstructorcall = false;
}
}

/**
* constructor call code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {
if ((this.bits & astnode.isreachable) == 0) {
return;
}
try {
((methodscope) currentscope).isconstructorcall = true;

int pc = codestream.position;
codestream.aload_0();

methodbinding codegenbinding = this.binding.original();
referencebinding targettype = codegenbinding.declaringclass;

// special name&ordinal argument generation for enum constructors
if (targettype.erasure().id == typeids.t_javalangenum || targettype.isenum()) {
codestream.aload_1(); // pass along name param as name arg
codestream.iload_2(); // pass along ordinal param as ordinal arg
}
// handling innerclass constructor invocation
// handling innerclass instance allocation - enclosing instance arguments
if (targettype.isnestedtype()) {
codestream.generatesyntheticenclosinginstancevalues(
currentscope,
targettype,
(this.bits & astnode.discardenclosinginstance) != 0 ? null : this.qualification,
this);
}
// generate arguments
generatearguments(this.binding, this.arguments, currentscope, codestream);

// handling innerclass instance allocation - outer local arguments
if (targettype.isnestedtype()) {
codestream.generatesyntheticouterargumentvalues(
currentscope,
targettype,
this);
}
if (this.syntheticaccessor != null) {
// synthetic accessor got some extra arguments appended to its signature, which need values
for (int i = 0,
max = this.syntheticaccessor.parameters.length - codegenbinding.parameters.length;
i < max;
i++) {
codestream.aconst_null();
}
codestream.invoke(opcodes.opc_invokespecial, this.syntheticaccessor, null /* default declaringclass */);
} else {
codestream.invoke(opcodes.opc_invokespecial, codegenbinding, null /* default declaringclass */);
}
codestream.recordpositionsfrom(pc, this.sourcestart);
} finally {
((methodscope) currentscope).isconstructorcall = false;
}
}

/**
* @@see org.eclipse.jdt.internal.compiler.lookup.invocationsite#generictypearguments()
*/
public typebinding[] generictypearguments() {
return this.generictypearguments;
}

public boolean isimplicitsuper() {
return (this.accessmode == explicitconstructorcall.implicitsuper);
}

public boolean issuperaccess() {
return this.accessmode != explicitconstructorcall.this;
}

public boolean istypeaccess() {
return true;
}

/* inner emulation consists in either recording a dependency
* link only, or performing one level of propagation.
*
* dependency mechanism is used whenever dealing with source target
* types, since by the time we reach them, we might not yet know their
* exact need.
*/
void manageenclosinginstanceaccessifnecessary(blockscope currentscope, flowinfo flowinfo) {
referencebinding supertypeerasure = (referencebinding) this.binding.declaringclass.erasure();

if ((flowinfo.tagbits & flowinfo.unreachable) == 0)	{
// perform some emulation work in case there is some and we are inside a local type only
if (supertypeerasure.isnestedtype()
&& currentscope.enclosingsourcetype().islocaltype()) {

if (supertypeerasure.islocaltype()) {
((localtypebinding) supertypeerasure).addinneremulationdependent(currentscope, this.qualification != null);
} else {
// locally propagate, since we already now the desired shape for sure
currentscope.propagateinneremulation(supertypeerasure, this.qualification != null);
}
}
}
}

public void managesyntheticaccessifnecessary(blockscope currentscope, flowinfo flowinfo) {
if ((flowinfo.tagbits & flowinfo.unreachable) == 0)	{
// if constructor from parameterized type got found, use the original constructor at codegen time
methodbinding codegenbinding = this.binding.original();

// perform some emulation work in case there is some and we are inside a local type only
if (this.binding.isprivate() && this.accessmode != explicitconstructorcall.this) {
referencebinding declaringclass = codegenbinding.declaringclass;
// from 1.4 on, local type constructor can lose their private flag to ease emulation
if ((declaringclass.tagbits & tagbits.islocaltype) != 0 && currentscope.compileroptions().compliancelevel >= classfileconstants.jdk1_4) {
// constructor will not be dumped as private, no emulation required thus
codegenbinding.tagbits |= tagbits.clearprivatemodifier;
} else {
this.syntheticaccessor = ((sourcetypebinding) declaringclass).addsyntheticmethod(codegenbinding, issuperaccess());
currentscope.problemreporter().needtoemulatemethodaccess(codegenbinding, this);
}
}
}
}

public stringbuffer printstatement(int indent, stringbuffer output) {
printindent(indent, output);
if (this.qualification != null) this.qualification.printexpression(0, output).append('.');
if (this.typearguments != null) {
output.append('<');
int max = this.typearguments.length - 1;
for (int j = 0; j < max; j++) {
this.typearguments[j].print(0, output);
output.append(", ");//$non-nls-1$
}
this.typearguments[max].print(0, output);
output.append('>');
}
if (this.accessmode == explicitconstructorcall.this) {
output.append("this("); //$non-nls-1$
} else {
output.append("super("); //$non-nls-1$
}
if (this.arguments != null) {
for (int i = 0; i < this.arguments.length; i++) {
if (i > 0) output.append(", "); //$non-nls-1$
this.arguments[i].printexpression(0, output);
}
}
return output.append(");"); //$non-nls-1$
}

public void resolve(blockscope scope) {
// the return type should be void for a constructor.
// the test is made into getconstructor

// mark the fact that we are in a constructor call.....
// unmark at all returns
methodscope methodscope = scope.methodscope();
try {
abstractmethoddeclaration methoddeclaration = methodscope.referencemethod();
if (methoddeclaration == null
|| !methoddeclaration.isconstructor()
|| ((constructordeclaration) methoddeclaration).constructorcall != this) {
scope.problemreporter().invalidexplicitconstructorcall(this);
// fault-tolerance
if (this.qualification != null) {
this.qualification.resolvetype(scope);
}
if (this.typearguments != null) {
for (int i = 0, max = this.typearguments.length; i < max; i++) {
this.typearguments[i].resolvetype(scope, true /* check bounds*/);
}
}
if (this.arguments != null) {
for (int i = 0, max = this.arguments.length; i < max; i++) {
this.arguments[i].resolvetype(scope);
}
}
return;
}
methodscope.isconstructorcall = true;
referencebinding receivertype = scope.enclosingreceivertype();
boolean rcvhaserror = false;
if (this.accessmode != explicitconstructorcall.this) {
receivertype = receivertype.superclass();
typereference superclassref = scope.referencetype().superclass;
if (superclassref != null && superclassref.resolvedtype != null && !superclassref.resolvedtype.isvalidbinding()) {
rcvhaserror = true;
}
}
if (receivertype != null) {
// prevent (explicit) super constructor invocation from within enum
if (this.accessmode == explicitconstructorcall.super && receivertype.erasure().id == typeids.t_javalangenum) {
scope.problemreporter().cannotinvokesuperconstructorinenum(this, methodscope.referencemethod().binding);
}
// qualification should be from the type of the enclosingtype
if (this.qualification != null) {
if (this.accessmode != explicitconstructorcall.super) {
scope.problemreporter().unnecessaryenclosinginstancespecification(
this.qualification,
receivertype);
}
if (!rcvhaserror) {
referencebinding enclosingtype = receivertype.enclosingtype();
if (enclosingtype == null) {
scope.problemreporter().unnecessaryenclosinginstancespecification(this.qualification, receivertype);
this.bits |= astnode.discardenclosinginstance;
} else {
typebinding qtb = this.qualification.resolvetypeexpecting(scope, enclosingtype);
this.qualification.computeconversion(scope, qtb, qtb);
}
}
}
}
// resolve type arguments (for generic constructor call)
if (this.typearguments != null) {
boolean arghaserror = scope.compileroptions().sourcelevel < classfileconstants.jdk1_5;
int length = this.typearguments.length;
this.generictypearguments = new typebinding[length];
for (int i = 0; i < length; i++) {
typereference typereference = this.typearguments[i];
if ((this.generictypearguments[i] = typereference.resolvetype(scope, true /* check bounds*/)) == null) {
arghaserror = true;
}
if (arghaserror && typereference instanceof wildcard) {
scope.problemreporter().illegalusageofwildcard(typereference);
}
}
if (arghaserror) {
if (this.arguments != null) { // still attempt to resolve arguments
for (int i = 0, max = this.arguments.length; i < max; i++) {
this.arguments[i].resolvetype(scope);
}
}
return;
}
}
// arguments buffering for the method lookup
typebinding[] argumenttypes = binding.no_parameters;
boolean argscontaincast = false;
if (this.arguments != null) {
boolean arghaserror = false; // typechecks all arguments
int length = this.arguments.length;
argumenttypes = new typebinding[length];
for (int i = 0; i < length; i++) {
expression argument = this.arguments[i];
if (argument instanceof castexpression) {
argument.bits |= astnode.disableunnecessarycastcheck; // will check later on
argscontaincast = true;
}
if ((argumenttypes[i] = argument.resolvetype(scope)) == null) {
arghaserror = true;
}
}
if (arghaserror) {
if (receivertype == null) {
return;
}
// record a best guess, for clients who need hint about possible contructor match
typebinding[] pseudoargs = new typebinding[length];
for (int i = length; --i >= 0;) {
pseudoargs[i] = argumenttypes[i] == null ? typebinding.null : argumenttypes[i]; // replace args with errors with null type
}
this.binding = scope.findmethod(receivertype, typeconstants.init, pseudoargs, this);
if (this.binding != null && !this.binding.isvalidbinding()) {
methodbinding closestmatch = ((problemmethodbinding)this.binding).closestmatch;
// record the closest match, for clients who may still need hint about possible method match
if (closestmatch != null) {
if (closestmatch.original().typevariables != binding.no_type_variables) { // generic method
// shouldn't return generic method outside its context, rather convert it to raw method (175409)
closestmatch = scope.environment().createparameterizedgenericmethod(closestmatch.original(), (rawtypebinding)null);
}
this.binding = closestmatch;
methodbinding closestmatchoriginal = closestmatch.original();
if (closestmatchoriginal.isorenclosedbyprivatetype() && !scope.isdefinedinmethod(closestmatchoriginal)) {
// ignore cases where method is used from within inside itself (e.g. direct recursions)
closestmatchoriginal.modifiers |= extracompilermodifiers.acclocallyused;
}
}
}
return;
}
} else if (receivertype.erasure().id == typeids.t_javalangenum) {
// todo (philippe) get rid of once well-known binding is available
argumenttypes = new typebinding[] { scope.getjavalangstring(), typebinding.int };
}
if (receivertype == null) {
return;
}
if ((this.binding = scope.getconstructor(receivertype, argumenttypes, this)).isvalidbinding()) {
if ((this.binding.tagbits & tagbits.hasmissingtype) != 0) {
if (!methodscope.enclosingsourcetype().isanonymoustype()) {
scope.problemreporter().missingtypeinconstructor(this, this.binding);
}
}
if (ismethodusedeprecated(this.binding, scope, this.accessmode != explicitconstructorcall.implicitsuper)) {
scope.problemreporter().deprecatedmethod(this.binding, this);
}
if (checkinvocationarguments(scope, null, receivertype, this.binding, this.arguments, argumenttypes, argscontaincast, this)) {
this.bits |= astnode.unchecked;
}
if (this.binding.isorenclosedbyprivatetype()) {
this.binding.original().modifiers |= extracompilermodifiers.acclocallyused;
}
if (this.typearguments != null
&& this.binding.original().typevariables == binding.no_type_variables) {
scope.problemreporter().unnecessarytypeargumentsformethodinvocation(this.binding, this.generictypearguments, this.typearguments);
}
} else {
if (this.binding.declaringclass == null) {
this.binding.declaringclass = receivertype;
}
if (rcvhaserror)
return;
scope.problemreporter().invalidconstructor(this, this.binding);
}
} finally {
methodscope.isconstructorcall = false;
}
}

public void setactualreceivertype(referencebinding receivertype) {
// ignored
}

public void setdepth(int depth) {
// ignore for here
}

public void setfieldindex(int depth) {
// ignore for here
}

public void traverse(astvisitor visitor, blockscope scope) {
if (visitor.visit(this, scope)) {
if (this.qualification != null) {
this.qualification.traverse(visitor, scope);
}
if (this.typearguments != null) {
for (int i = 0, typeargumentslength = this.typearguments.length; i < typeargumentslength; i++) {
this.typearguments[i].traverse(visitor, scope);
}
}
if (this.arguments != null) {
for (int i = 0, argumentlength = this.arguments.length; i < argumentlength; i++)
this.arguments[i].traverse(visitor, scope);
}
}
visitor.endvisit(this, scope);
}
}
