/*******************************************************************************
* copyright (c) 2000, 2003 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the common public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/cpl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.astvisitor;
import org.eclipse.jdt.internal.compiler.codegen.codestream;
import org.eclipse.jdt.internal.compiler.flow.flowcontext;
import org.eclipse.jdt.internal.compiler.flow.flowinfo;
import org.eclipse.jdt.internal.compiler.lookup.blockscope;

public class iteratorforstatement extends statement {

public expression collection;
public localdeclaration localdeclaration;

public statement action;

// we always need a new scope.
public blockscope scope;

public iteratorforstatement(
localdeclaration localdeclaration,
expression collection,
statement action,
int start,
int end) {

this.localdeclaration = localdeclaration;
this.collection = collection;
this.sourcestart = start;
this.sourceend = end;
this.action = action;
// remember useful empty statement
if (action instanceof emptystatement) action.bits |= isusefulemptystatementmask;
}

public flowinfo analysecode(
blockscope currentscope,
flowcontext flowcontext,
flowinfo flowinfo) {
// todo to be completed
return flowinfo;
}

/**
* for statement code generation
*
* @@param currentscope org.eclipse.jdt.internal.compiler.lookup.blockscope
* @@param codestream org.eclipse.jdt.internal.compiler.codegen.codestream
*/
public void generatecode(blockscope currentscope, codestream codestream) {
// todo to be completed
}

public stringbuffer printstatement(int tab, stringbuffer output) {

printindent(tab, output).append("for ("); //$non-nls-1$
this.localdeclaration.print(0, output);
output.append(" : ");//$non-nls-1$
this.collection.print(0, output).append(") "); //$non-nls-1$
//block
if (action == null)
output.append(';');
else {
output.append('\n');
action.printstatement(tab + 1, output); //$non-nls-1$
}
return output;
}

public void resetstateforcodegeneration() {
// todo to be completed
}

public void resolve(blockscope upperscope) {
// todo to be completed
}

public void traverse(
astvisitor visitor,
blockscope blockscope) {

if (visitor.visit(this, blockscope)) {
this.localdeclaration.traverse(visitor, scope);
this.collection.traverse(visitor, scope);
if (action != null) {
action.traverse(visitor, scope);
}
}
visitor.endvisit(this, blockscope);
}
}
