/*******************************************************************************
* copyright (c) 2000, 2009 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.lookup;

// todo should rename into typenames (once extracted last non name constants)
public interface typeconstants {

char[] java = "java".tochararray(); //$non-nls-1$
char[] lang = "lang".tochararray(); //$non-nls-1$
char[] io = "io".tochararray(); //$non-nls-1$
char[] util = "util".tochararray(); //$non-nls-1$
char[] annotation = "annotation".tochararray(); //$non-nls-1$
char[] reflect = "reflect".tochararray(); //$non-nls-1$
char[] length = "length".tochararray(); //$non-nls-1$
char[] clone = "clone".tochararray(); //$non-nls-1$
char[] equals = "equals".tochararray(); //$non-nls-1$
char[] getclass = "getclass".tochararray(); //$non-nls-1$
char[] hashcode = "hashcode".tochararray(); //$non-nls-1$
char[] object = "object".tochararray(); //$non-nls-1$
char[] main = "main".tochararray(); //$non-nls-1$
char[] serialversionuid = "serialversionuid".tochararray(); //$non-nls-1$
char[] serialpersistentfields = "serialpersistentfields".tochararray(); //$non-nls-1$
char[] readresolve = "readresolve".tochararray(); //$non-nls-1$
char[] writereplace = "writereplace".tochararray(); //$non-nls-1$
char[] readobject = "readobject".tochararray(); //$non-nls-1$
char[] writeobject = "writeobject".tochararray(); //$non-nls-1$
char[] chararray_java_lang_object = "java.lang.object".tochararray(); //$non-nls-1$
char[] chararray_java_lang_enum = "java.lang.enum".tochararray(); //$non-nls-1$
char[] chararray_java_lang_annotation_annotation = "java.lang.annotation.annotation".tochararray(); //$non-nls-1$
char[] chararray_java_io_objectinputstream = "java.io.objectinputstream".tochararray(); //$non-nls-1$
char[] chararray_java_io_objectoutputstream = "java.io.objectoutputstream".tochararray(); //$non-nls-1$
char[] chararray_java_io_objectstreamfield = "java.io.objectstreamfield".tochararray(); //$non-nls-1$
char[] anonym_prefix = "new ".tochararray(); //$non-nls-1$
char[] anonym_suffix = "(){}".tochararray(); //$non-nls-1$
char[] wildcard_name = { '?' };
char[] wildcard_super = " super ".tochararray(); //$non-nls-1$
char[] wildcard_extends = " extends ".tochararray(); //$non-nls-1$
char[] wildcard_minus = { '-' };
char[] wildcard_star = { '*' };
char[] wildcard_plus = { '+' };
char[] wildcard_capture_name_prefix = "capture#".tochararray(); //$non-nls-1$
char[] wildcard_capture_name_suffix = "-of ".tochararray(); //$non-nls-1$
char[] wildcard_capture = { '!' };
char[] byte = "byte".tochararray(); //$non-nls-1$
char[] short = "short".tochararray(); //$non-nls-1$
char[] int = "int".tochararray(); //$non-nls-1$
char[] long = "long".tochararray(); //$non-nls-1$
char[] float = "float".tochararray(); //$non-nls-1$
char[] double = "double".tochararray(); //$non-nls-1$
char[] char = "char".tochararray(); //$non-nls-1$
char[] boolean = "boolean".tochararray(); //$non-nls-1$
char[] null = "null".tochararray(); //$non-nls-1$
char[] void = "void".tochararray(); //$non-nls-1$
char[] value = "value".tochararray(); //$non-nls-1$
char[] values = "values".tochararray(); //$non-nls-1$
char[] valueof = "valueof".tochararray(); //$non-nls-1$
char[] upper_source = "source".tochararray(); //$non-nls-1$
char[] upper_class = "class".tochararray(); //$non-nls-1$
char[] upper_runtime = "runtime".tochararray(); //$non-nls-1$
char[] annotation_prefix = "@@".tochararray(); //$non-nls-1$
char[] annotation_suffix = "()".tochararray(); //$non-nls-1$
char[] type = "type".tochararray(); //$non-nls-1$
char[] upper_field = "field".tochararray(); //$non-nls-1$
char[] upper_method = "method".tochararray(); //$non-nls-1$
char[] upper_parameter = "parameter".tochararray(); //$non-nls-1$
char[] upper_constructor = "constructor".tochararray(); //$non-nls-1$
char[] upper_local_variable = "local_variable".tochararray(); //$non-nls-1$
char[] upper_annotation_type = "annotation_type".tochararray(); //$non-nls-1$
char[] upper_package = "package".tochararray(); //$non-nls-1$

// constant compound names
char[][] java_lang = {java, lang};
char[][] java_io = {java, io};
char[][] java_lang_annotation_annotation = {java, lang, annotation, "annotation".tochararray()}; //$non-nls-1$
char[][] java_lang_assertionerror = {java, lang, "assertionerror".tochararray()}; //$non-nls-1$
char[][] java_lang_class = {java, lang, "class".tochararray()}; //$non-nls-1$
char[][] java_lang_classnotfoundexception = {java, lang, "classnotfoundexception".tochararray()}; //$non-nls-1$
char[][] java_lang_cloneable = {java, lang, "cloneable".tochararray()}; //$non-nls-1$
char[][] java_lang_enum = {java, lang, "enum".tochararray()}; //$non-nls-1$
char[][] java_lang_exception = {java, lang, "exception".tochararray()}; //$non-nls-1$
char[][] java_lang_error = {java, lang, "error".tochararray()}; //$non-nls-1$
char[][] java_lang_illegalargumentexception = {java, lang, "illegalargumentexception".tochararray()}; //$non-nls-1$
char[][] java_lang_iterable = {java, lang, "iterable".tochararray()}; //$non-nls-1$
char[][] java_lang_noclassdeferror = {java, lang, "noclassdeferror".tochararray()}; //$non-nls-1$
char[][] java_lang_object = {java, lang, object};
char[][] java_lang_string = {java, lang, "string".tochararray()}; //$non-nls-1$
char[][] java_lang_stringbuffer = {java, lang, "stringbuffer".tochararray()}; //$non-nls-1$
char[][] java_lang_stringbuilder = {java, lang, "stringbuilder".tochararray()}; //$non-nls-1$
char[][] java_lang_system = {java, lang, "system".tochararray()}; //$non-nls-1$
char[][] java_lang_runtimeexception = {java, lang, "runtimeexception".tochararray()}; //$non-nls-1$
char[][] java_lang_throwable = {java, lang, "throwable".tochararray()}; //$non-nls-1$
char[][] java_lang_reflect_constructor = {java, lang, reflect, "constructor".tochararray()}; //$non-nls-1$
char[][] java_io_printstream = {java, io, "printstream".tochararray()}; //$non-nls-1$
char[][] java_io_serializable = {java, io, "serializable".tochararray()}; //$non-nls-1$
char[][] java_lang_byte = {java, lang, "byte".tochararray()}; //$non-nls-1$
char[][] java_lang_short = {java, lang, "short".tochararray()}; //$non-nls-1$
char[][] java_lang_character = {java, lang, "character".tochararray()}; //$non-nls-1$
char[][] java_lang_integer = {java, lang, "integer".tochararray()}; //$non-nls-1$
char[][] java_lang_long = {java, lang, "long".tochararray()}; //$non-nls-1$
char[][] java_lang_float = {java, lang, "float".tochararray()}; //$non-nls-1$
char[][] java_lang_double = {java, lang, "double".tochararray()}; //$non-nls-1$
char[][] java_lang_boolean = {java, lang, "boolean".tochararray()}; //$non-nls-1$
char[][] java_lang_void = {java, lang, "void".tochararray()}; //$non-nls-1$
char[][] java_util_collection = {java, util, "collection".tochararray()}; //$non-nls-1$
char[][] java_util_iterator = {java, util, "iterator".tochararray()}; //$non-nls-1$
char[][] java_lang_deprecated = {java, lang, "deprecated".tochararray()}; //$non-nls-1$
char[][] java_lang_annotation_documented = {java, lang, annotation, "documented".tochararray()}; //$non-nls-1$
char[][] java_lang_annotation_inherited = {java, lang, annotation, "inherited".tochararray()}; //$non-nls-1$
char[][] java_lang_override = {java, lang, "override".tochararray()}; //$non-nls-1$
char[][] java_lang_annotation_retention = {java, lang, annotation, "retention".tochararray()}; //$non-nls-1$
char[][] java_lang_suppresswarnings = {java, lang, "suppresswarnings".tochararray()}; //$non-nls-1$
char[][] java_lang_annotation_target = {java, lang, annotation, "target".tochararray()}; //$non-nls-1$
char[][] java_lang_annotation_retentionpolicy = {java, lang, annotation, "retentionpolicy".tochararray()}; //$non-nls-1$
char[][] java_lang_annotation_elementtype = {java, lang, annotation, "elementtype".tochararray()}; //$non-nls-1$
char[][] java_lang_reflect_field = new char[][] {java, lang, reflect, "field".tochararray()}; //$non-nls-1$
char[][] java_lang_reflect_method = new char[][] {java, lang, reflect, "method".tochararray()}; //$non-nls-1$
char[][] java_io_objectstreamexception = new char[][] { java, io, "objectstreamexception".tochararray()};//$non-nls-1$
char[][] java_io_externalizable = {java, io, "externalizable".tochararray()}; //$non-nls-1$
char[][] java_io_ioexception = new char[][] { java, io, "ioexception".tochararray()};//$non-nls-1$
char[][] java_io_objectoutputstream = new char[][] { java, io, "objectoutputstream".tochararray()}; //$non-nls-1$
char[][] java_io_objectinputstream = new char[][] { java, io, "objectinputstream".tochararray()}; //$non-nls-1$
// javax.rmi.corba.stub
char[][] javax_rmi_corba_stub = new char[][] {
"javax".tochararray(), //$non-nls-1$
"rmi".tochararray(), //$non-nls-1$
"corba".tochararray(), //$non-nls-1$
"stub".tochararray(), //$non-nls-1$
};

// constraints for generic type argument inference
int constraint_equal = 0;		// actual = formal
int constraint_extends = 1;	// actual << formal
int constraint_super = 2;		// actual >> formal

// constants used to perform bound checks
int ok = 0;
int unchecked = 1;
int mismatch = 2;

// synthetics
char[] init = "<init>".tochararray(); //$non-nls-1$
char[] clinit = "<clinit>".tochararray(); //$non-nls-1$
char[] synthetic_switch_enum_table = "$switch_table$".tochararray(); //$non-nls-1$
char[] synthetic_enum_values = "enum$values".tochararray(); //$non-nls-1$
char[] synthetic_assert_disabled = "$assertionsdisabled".tochararray(); //$non-nls-1$
char[] synthetic_class = "class$".tochararray(); //$non-nls-1$
char[] synthetic_outer_local_prefix = "val$".tochararray(); //$non-nls-1$
char[] synthetic_enclosing_instance_prefix = "this$".tochararray(); //$non-nls-1$
char[] synthetic_access_method_prefix =  "access$".tochararray(); //$non-nls-1$

// synthetic package-info name
public static final char[] package_info_name = "package-info".tochararray(); //$non-nls-1$
}
