/*******************************************************************************
* copyright (c) 2000, 2008 ibm corporation and others.
* all rights reserved. this program and the accompanying materials
* are made available under the terms of the eclipse public license v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* contributors:
*     ibm corporation - initial api and implementation
*******************************************************************************/
package org.eclipse.jdt.internal.compiler.batch;

import java.io.file;

import org.eclipse.jdt.core.compiler.charoperation;
import org.eclipse.jdt.internal.compiler.env.accessrestriction;
import org.eclipse.jdt.internal.compiler.env.accessruleset;
import org.eclipse.jdt.internal.compiler.util.suffixconstants;

public abstract class classpathlocation implements filesystem.classpath,
suffixconstants {

public static final int source = 1;
public static final int binary = 2;

string path;
char[] normalizedpath;
public accessruleset accessruleset;

public string destinationpath;
// destination path for compilation units that are reached through this
// classpath location; the coding is consistent with the one of
// main.destinationpath:
// == null: unspecified, use whatever value is set by the enclosing
//          context, id est main;
// == main.none: absorbent element, do not output class files;
// else: use as the path of the directory into which class files must
//       be written.
// potentially carried by any entry that contains to be compiled files

protected classpathlocation(accessruleset accessruleset,
string destinationpath) {
this.accessruleset = accessruleset;
this.destinationpath = destinationpath;
}

/**
* return the first access rule which is violated when accessing a given
* type, or null if no 'non accessible' access rule applies.
*
* @@param qualifiedbinaryfilename
*            tested type specification, formed as:
*            "org/eclipse/jdt/core/javacore.class"; on systems that
*            use \ as file.separator, the
*            "org\eclipse\jdt\core\javacore.class" is accepted as well
* @@return the first access rule which is violated when accessing a given
*         type, or null if none applies
*/
protected accessrestriction fetchaccessrestriction(string qualifiedbinaryfilename) {
if (this.accessruleset == null)
return null;
char [] qualifiedtypename = qualifiedbinaryfilename.
substring(0, qualifiedbinaryfilename.length() - suffix_class.length)
.tochararray();
if (file.separatorchar == '\\') {
charoperation.replace(qualifiedtypename, file.separatorchar, '/');
}
return this.accessruleset.getviolatedrestriction(qualifiedtypename);
}
}
